/**
 * Extension of the API - Ext.form.Combobox, to build  the combo with two triggers
 * 
 * Start point :  Ext.ux.form.TwinCombo, Ext.ux.TwinTriggerCombo(ExtJS forums)
 * 
 * @class Ext.ux.TwinCombo
 * @extends Ext.form.ComboBox
 */
Ext.define('Ext.ux.TwinCombo',{  
  extend:'Ext.form.field.ComboBox',
  alias: ['widget.twinCombo', 'twinCombo'],
  
  initComponent: function(){
  	 Ext.ux.TwinCombo.superclass.initComponent.call(this);
  },
 
  getTrigger: function(){
     Ext.ux.TwinCombo.superclass.getTrigger.call(this);
  },
  initTrigger: function(){  	
     Ext.ux.TwinCombo.superclass.initTrigger.call(this);
  },
  
  onTrigger1Click: function() {
  	Ext.ux.TwinCombo.superclass.onTriggerClick.call(this);
  },
  
  onTrigger2Click: function() {
     Ext.ux.TwinCombo.superclass.onTrigger2Click.call(this);
  },
  validationEvent: false,
  validateOnBlur: false,
  
  clearValue: function(){
    if(this.hiddenField){
      this.hiddenField.value = '';
    }
    this.hasFocus = false;
    this.setRawValue('');
    this.lastSelectionText = '';
    this.applyEmptyText();
    this.value = '';      
  }
});

  /*
 $Revision: 1.5 $
 $Modtime: 10.08.23 14:01 $
 $Date: 2011/08/17 11:27:16 $
 $Author: hstaeck $
 $viaMEDICI Release: 3.7 $
 */ 