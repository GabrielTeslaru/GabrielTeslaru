// Create user extensions namespace (Ext.ux)
//Ext.namespace('Ext.ux');
 
/**
  * Ext.ux.IconCombo Extension Class
  *
  * @author  Jozef Sakalos
  * @version 1.0
  *
  * @class Ext.ux.IconCombo
  * @extends Ext.form.ComboBox
  * @constructor
  * @param {Object} config Configuration options
  */
Ext.define('Ext.ux.IconCombo',{
  
  
  extend:'Ext.form.field.ComboBox',

  qtipPrefix: /*config.qtipPrefix ||*/ "",
  qtipWithValue: /*config.qtipWithValue||*/ false, 
  qtipLastId: "",
  xtype:'iconcombo',
 
  
  //indicates if the Dscr should be used in the pickerlist besides the icon
  useDscrPicker:false,
  
  //indicates if the Dscr should be used in the input field element besides the icon
  useDscrField:false, //not in use yet!
    
   //  >>> PROD V3.7 Start (6903) <<< 
    listBeenExpanded:false,
    listeners:{
//    on({
       render:{
          scope:this,
          fn: function(cmp){
             // IE7 needed
             var trigger = cmp.el.down('div.x-form-trigger-wrap');
             if(trigger){
                if(cmp.triggerCls){
                   trigger.addCls(cmp.triggerCls);
                }
             }
          }
       },
//    
        renderX:{scope:this, fn:function(cmp) {//I'm not sure why we need this??
          
            var wrap = cmp.el.up('div.x-form-field-wrap');//this.el.up('div.x-form-field-wrap');
            wrap.iconComboCmpId =this.id;
            
            wrap.on('click',function(event){
             var  temp =  Ext.getCmp(this.iconComboCmpId);
                
             temp.focus();
             if (!this.listBeenExpanded){
              
              if ( // Detecting click was on inputFiled and not on trigger
                  (event && event.target && event.target.tagName && event.target.tagName=="INPUT")
               || (event && event.target && event.target.tagName && event.target.tagName=="DIV") // IE only
             //|| (event && event.target && event.target.id && event.target.id==temp.id)// FF onnly obsolete 
              ){
                temp.onTriggerClick();
                this.listBeenExpanded = true;
              }
             }
             else{
              temp.expand();
              }
    //  >>> PROD V3.7 End (6903) <<< 
            });
            
            this.wrap.applyStyles({position:'relative'});
            this.el.addCls('x-icon-combo-input');
            this.flag = Ext.DomHelper.append(wrap, {
                tag: 'div', style:'position:absolute'
            });
        }}
//    })
    },
    
    createPicker: function() {//new for ext4 !      

        var me = this,
            picker,
            menuCls = Ext.baseCSSPrefix + 'menu',
            opts = Ext.apply({
                selModel: {
                    mode: me.multiSelect ? 'SIMPLE' : 'SINGLE'
                },
                floating: true,
                hidden: true,
                ownerCt: me.ownerCt,
                cls: me.el.up('.' + menuCls) ? menuCls : '',
                store: me.store,
                displayField: me.displayField,
                focusOnToFront: false,
                pageSize: me.pageSize
            }, me.listConfig, me.defaultListConfig);

            //  >>> PROD V3.9 Start (10507) <<< 
            opts.maxHeight =300;
            //  >>> PROD V3.9 Ende (10507) <<< 
            //  >>> PROD V3.9 Start (10615) <<< 
            opts.itemTpl = this.getInnerTpl(me);
            picker = me.picker = Ext.create('Ext.view.BoundList', opts);
            //  >>> PROD V3.9 Ende (10615) <<< 
        
        me.mon(picker, {
            itemclick: me.onItemClick,
            refresh: me.onListRefresh,
            scope: me
        });

        me.mon(picker.getSelectionModel(), {
            selectionChange: me.onListSelectionChange,
            scope: me
        });

        return picker;
    },
    
    /*
    getRawValue : function(){
        var v = this.value;
        if(v === this.emptyText){
            v = '';
        }
        return v;
    },
    
    */
    qtipLeftMarginX: /&nbsp;/g,

//  >>> PROD V3.9 Start (10615) <<<    
    getInnerTpl: function(me){
      var displayFieldVar ='';
      if(this.useDscrPicker){
        displayFieldVar = '{'+me.displayField +'} ';
      }  
     var itemTpl = 
      '<div class=" {'+ me.iconClsField+ '}"  style="position:absolute;top:3px;width:28px !important;" >&nbsp;</div>'
      +'<div style="padding-left:28px;background-position:3px;" >'+displayFieldVar +' </div>';
      return itemTpl;
    },
//  >>> PROD V3.9 End (10615) <<<
    
    qtipAddValue: function() {
      try{                
         var currentDscr = this.getValue();
    	 if(!currentDscr){
    		 currentDscr="";
    	 } 
         if(currentDscr != null){
           var selectedValue = ""+this.getValue();
           this.store.findBy(   function(record){
               var totalCount = this.getCount();
               var records = this.getRange();
               //  >>> PROD V3.9 Start (10507) <<< 
               var i;
               for ( i = 0; i < totalCount; i++) {
               //  >>> PROD V3.9 End (10507) <<<  
                  if (records[i].get('value') == selectedValue) {
                    dscrFound = true;
                    currentDscr= records[i].get('dscr');
                    return true;
                  }
                }// eo loop
          });
         if(currentDscr != null){
        	 currentDscr = currentDscr.replace(this.qtipLeftMarginX,"");
         }
           var el = this.getEl();
          if(el){
           this.qtipLastId = extVia.ui.cmp.factory.component.createToolTip({
              target: el,
              html: this.qtipPrefix+" "+currentDscr
            }, this.qtipLastId).id;
          }
        }
      }catch(vEx){      
        extVia.util.Log.showNotification({    
            status:"Debug",  
            title: extVia.ui.page.strings.get('Status.Debug'),
            html:  "Ext.ux.IconCombo.qtipAddValue store.findBy Dscr  "+ vEx
          });
      }
      

    },
    
    setIconCls: function() {
      var origValue = this.getValue();
      //  >>> PROD V3.7 Start (7601) <<< 
      var rec = this.store.findRecord(this.valueField, origValue, null, null, true);
      //  >>> PROD V3.7 End (7601) <<< 
      if(!this.rendered){
        return;
      }
      if(rec) {
        this.viaValue = this.bodyEl.dom.children[1].value;
        this.bodyEl.dom.children[1].value  = ""; //text in der Anzeige leer setzen
     
        
        if(Ext.isIE){//in IE classList doesn't exist
          var lastClass = this.bodyEl.dom.children[1].lastIconClass;
          this.bodyEl.dom.children[1].className = this.bodyEl.dom.children[1].className.replace(lastClass,"");
          this.bodyEl.dom.children[1].className += " "+rec.get(this.iconClsField);
          
        }else{
          
          var oldCSS = this.bodyEl.dom.children[1].lastIconClass;
          if(oldCSS && oldCSS != null && oldCSS.length > 0){
            this.bodyEl.dom.children[1].classList.remove(oldCSS); //remove the last used icon css class
          
          }
          var newCSS = rec.get(this.iconClsField);
          if(newCSS && newCSS != null && newCSS.length > 0){
            this.bodyEl.dom.children[1].classList.add(newCSS); // set new icon css class
          
          }
          
        }
        
        this.bodyEl.dom.children[1].lastIconClass = rec.get(this.iconClsField); // memorize the css class
        this.clearValue(); 
        
        
        
        // this is needed for qtipAddValue()
        this.inputEl.dom.value = rec.raw[1];     
        if (this.qtipWithValue){      
          this.qtipAddValue();
            
        }
        if(origValue){
          this.value = origValue;
        }
        this.inputEl.dom.value = "";
        // end
      }
    },
 
    setValue: function(record) {// from Ext4 API -> The value(s) to be set. Can be either a single String or Ext.data.Model, or an Array of Strings or Models.
      this.superclass.setValue.call(this, record); //newValue
      this.setIconCls();
    },
    
    getXType:function(){//workaround EXT4 -> getXType() returns 'undefined'
      return this.xtype;//superclass.getXType();
    }
 
}); // end of extend
 
// end of file



  /*
 $Revision: 1.40 $
 $Modtime: 08.09.23 14:01 $
 $Date: 2014/08/19 16:14:12 $
 $Author: slederer $
 $viaMEDICI Release: 3.7 $
 */
