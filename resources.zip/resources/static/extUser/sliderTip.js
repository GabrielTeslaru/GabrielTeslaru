/*!
 * Ext JS Library 3.0.0
 * Copyright(c) 2006-2009 Ext JS, LLC
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
/**
 * @class Ext.ux.SliderTip
 * @extends Ext.Tip
 * Simple plugin for using an Ext.Tip with a slider to show the slider value
 */
 
 Ext.define('Ext.ux.SliderTip', {
    extend: 'Ext.tip.Tip', 
    alias: 'widget.sliderTip',
    minWidth: 10,
    offsets : [0, -10],
    constructor: function(config){
        Ext.apply(this, config);
    },
    init : function(slider){
        //slider.on('dragstart', this.onSlide, this);
       // slider.on('drag', this.onSlide, this);
        //slider.on('dragend', this.hide, this);
        //slider.on('destroy', this.destroy, this);
        slider.on('change', this.updateVal, this);
    },

    onSlide : function(slider){
        this.show();
        this.body.update(this.getText(slider));
        this.doAutoWidth();
        this.el.alignTo(slider.thumb, 'b-t?', this.offsets);
        this.update(this.getText(slider));
    },

    getText : function(slider){
        return String(slider.getValue());
    },
    updateVal: function(slider) {        
         this.setValue(slider.getValue()); 
         slider.value = slider.getValue();
         Ext.getCmp(this.id).setValue(this.getText(slider));
    }
});
/*
 $Revision: 1.7 $
 $Modtime: 10.08.23 14:01 $
 $Date: 2011/11/24 14:25:07 $
 $Author: vbucur $
 $viaMEDICI Release: 3.7 $
 */ 