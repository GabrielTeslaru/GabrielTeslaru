Ext.namespace('extVia.locales' ,'extVia.customTab.locales');
/**
 * @class customTab
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2017/07/18 09:42:06 $
 *            $Revision: 1.1 $
 */





extVia.customTab.locales = {
        appName:'customTab',
        modul:'customTab',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.customTab.locales);



/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 18.07.17 09:39 $ 
 * $Date: 2017/07/18 09:42:06 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 