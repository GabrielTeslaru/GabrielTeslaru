Ext.namespace('extVia.locales' ,'extVia.workflow.locales');
/**
 * @class extVia.versionsProto.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2017/03/22 10:44:00 $
 *            $Revision: 1.4 $
 */





extVia.workflow.locales = {
        appName:'workflows',
        //modul:'&Uuml;berg&auml;nge',
        modul:'Workflow',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.workflow.locales);



/*
 * 
 * $Revision: 1.4 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2017/03/22 10:44:00 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 