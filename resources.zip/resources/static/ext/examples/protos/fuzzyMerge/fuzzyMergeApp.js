/**
 * 
 */
Ext.application({
    name: 'fuzzyMerge',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      //var centerWidth = centerPan.getWidth()-50;
      var centerHeight = centerPan.getHeight()-92; // ohne pagetoolbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=86;
      }
      if (cfg && cfg.hasSubtabs){
        //centerHeight-=86;
        var jslintSomething;
      }      
      return centerHeight;
    },
    
    getWestListHeight : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
      return westHeight;
    },
    

    showEditor: function() {
      extVia.notify({action: 'show Editor '  , mssg:  'Wo isser ?'}); 
    },
    
    
    
    initWest: function() {

      var me = this;
      
      Ext.create('Ext.data.Store', {
         storeId:'whateverStore',
         fields:['id', 'epobType', 'name', 'status', 'responsible'],
         data:{'items':[
             {id:'1', epobType:'Product', name:'Flow 1', status:'Warnung', responsible:'Ernie'  },
             {id:'2', epobType:'Image', name:'Bilder hochladen', status:'', responsible:'Oskar'  },
             {id:'3', epobType:'Video', name:'Welt retten', status:'Start', responsible:'Grobi'  },
             {id:'4', epobType:'User', name:'Kuchen backen', status:'Danger', responsible:''  },
             {id:'5', epobType:'Attribute', name:'Datenbank zerstören', status:'Success', responsible:''  },
             {id:'6', epobType:'Product', name:'Produkte pflegen', status:'Wait', responsible:''  }
         ]},
         proxy: {
             type: 'memory',
             reader: {
                 type: 'json',
                 root: 'items'
             }
         }
       });

       var epobTypeRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
         };
       var statusRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon_'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
         };

        var whateverGrid = Ext.create('Ext.grid.Panel', {
          itemId:'whateverGrid',
              width: 400,
              border:false,
              store: Ext.data.StoreManager.lookup('whateverStore'),
              columns: [
                   { header: 'Typ',  dataIndex: 'epobType', width:32, renderer:epobTypeRenderer },
                   { header: 'Name',  dataIndex: 'name' ,  flex: 1},
                   { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
                   { header: 'Verantwortliche', dataIndex: 'client', 
                     renderer: function(){
                       var clientsHtml = 
                         '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
                           '<span class="xty_tag" title="Muppets">Muppets</span>' +
                           '<span class="xty_tag" title="Puppets" >Puppets</span>' +
                         '</span>';
                       return clientsHtml;
                     }
                   },
                 { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
           ],
           height: 200,
               listeners:{
                itemdblclick: function( view, record, item, index, evt, eOpts ){
                 me.showEditor(record);
                }
               
               }
          
       });

         var whateverList = {
             title:'Whatever',
             itemId:'whateverList',
             height: me.getWestListHeight(),
             tbar:[
             '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'Löschen', handler: me.deleteEpobDialog}
             ],
             items:[ whateverGrid ] ,
             bbar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
          };
  
         
         
         
         var structureTreeStore = Ext.create('Ext.data.TreeStore', {
           root: {
               expanded: true,

               text: "Bohrmaschine",
               iconCls:'xty_epobProduct',
               children: [
                   { text: "Audios"},
                   { text: "Bilder", expanded: true, children: [
                       { text: "book report", leaf: true, iconCls:'xty_epobImage' },
                       { text: "alegrbra", leaf: true,  iconCls:'xty_epobImage'}
                   ] },
                   { text: "Texte"}
               ]
           }
       });

       var structureTreePanel = Ext.create('Ext.tree.Panel', {
           title: 'Produktstruktur',
           useArrows : true,  
           viewConfig: {
             plugins: {
                 ptype: 'treeviewdragdrop'
             }
           },
           itemId:'structureTreeTab',
           border:false,
           store: structureTreeStore,
           tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign'}]
       });
         
         
         
         var structureTreeTab = { 
                title:'Produktstruktur', 
                itemId:'structureTreeTab',
                tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign'}],
                items:[structureTreePanel]
          }; 
 
         var hierarchyTab = extVia.hierarchy.statics.getHierarchyTabCfg({});
         
         var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
             tabBar:{ 
               tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
               handler:function(button){
                 var activeTab = button.ownerCt.ownerCt.getActiveTab();
                   extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                 }
                }
               ]
             },
             items:[structureTreePanel, hierarchyTab, whateverList]
             });
            extVia.regApp.myRaster.addToWest(tabPanWest);

    },
    
    
    
    launch: function() {
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      var me = this;
      var  modulDscr = 'Fuzzy Merge';


      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.constants.raster.mainWestWidth = 360;
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);


       me.initWest();
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
        handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
        iconCls:'x-tool x-tool-refresh'}]  } 
      });

      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      
      
      // if you ned an extra App Panel:  fuzzyMerge-Module
       var fuzzyModuleAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'fuzzyMerge modul', epobDscr:null,  pgjobButtons: [{itemId:'search', scale:'large', xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}}] } );
       var fuzzyModulePanel = {title:'fuzzyMerge modul', tbar: fuzzyModuleAppbar, items:[] };
       tabPanCenter.addAndActivate(fuzzyModulePanel);

      // ProductEditor - prodEditor

     var prodEdiBoxDefaults = { labelWidth : 180, width : 460,  msgTarget:'side',  xtype:'textfield',   margin:'4 0 4 4' };

     var prodEditorSubTabsPanelCfg =     { 
        xtype:'tabpanel',
        itemId:'editorSubTabsPanel',
        border:false, 
        margin : '0 0 0 0', 
        cls:'xty_prodEditorTabPanel', 
        activeTab:  3, 
        tabBar:{cls:'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl'},
        defaults:{ // defaults for tab-panels
                   border:false,
                   autoScroll:true, height: me.getEditorSubTabHeight(), 
                   defaults:{ // defaults for boxes
                    xtype:'form', width:580, margin:'24 24 24 24',
                    defaults:{ // defaults for box-items
                    labelWidth : 180,
                    width : 380,
                    msgTarget:'side',
                    xtype:'textfield', 
                    margin:'4 0 4 4'
                     }
                   }
                },
        items:[
          {title:'Produkt', items:[
            { xtype:'form', title:'Metadaten', itemId:'metadata',  collapsible:true,
              defaults:prodEdiBoxDefaults, items:[{fieldLabel:'Name', value:'Bohrmaschine'}]
            },
            { xtype:'form', title:'Änderungsinfo', itemId:'changeInfo', defaults:prodEdiBoxDefaults,
             items:[  { itemId:'changeDate', xtype:'displayfield', fieldLabel:'Anlage', value:'heute' }, { itemId:'creationDate', xtype:'displayfield', fieldLabel:'letzt Änderung', value:'' }]
            }
           ]
          },
          {title:'Attribute',  items:[  ]},
          {title:'Elemente',  items:[  ]},
          {title:'fuzzy Merge',  items:[  ]}
        ]
      };  


      
      var epob = {epobId:'drill_1', dscr:'Bohrmaschine', epobType:'Product'};
      
      var prodEditorPagetoolbarButtons =  [{itemId:'save'},{itemId:'export'},{itemId:'collectionAddTo'},{xtype:'splitbutton', itemId:'versioning-create'}] ;
      var prodEditorAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Produktpflege' , epobDscr: epob.dscr,    
        pgjobButtons: [  
          {
            xtype: 'buttongroup',
            itemId:'contentSwitcherBtnGrp',
            items:[
              {iconCls : 'xty_icon_en', cls:'xty_language-chooser', itemId:'language',tooltip:'Sprache',height:22, width:22, scale: 'small'}
            ]
           }
          ], pagetoolbarButtons: prodEditorPagetoolbarButtons, breadcrumb:'Metabo/Elektrowerkzeuge/Akkuger&aumlte/Akku-Bohrschrauber' } );
   
      var prodEditorPanel  = {title: epob.dscr, closable:true, tbar: prodEditorAppbar,
        items:[prodEditorSubTabsPanelCfg  ] 
      };
      tabPanCenter.addAndActivate(prodEditorPanel);    

 
      

      
      
    }
});



/*
 * 
 * $Revision: 1.2.6.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/06/25 16:33:33 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
