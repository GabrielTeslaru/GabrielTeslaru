Ext.define('extVia.assistance.chatbot.Chatbot.statics', {
  statics:{
    
  
   /**
    * 
    */
   initFirebaseDB: function() {
     var database = null;

     
     return database;
   },
   
   /**
    * 
    */
   startCommandListener: function(cfg) {
     var userId = cfg.userId;
     var userInitials = cfg.userInitials;
     var langISO = cfg.langISO;

     var me = this;

 
     /**
      * Actually we are writing data via firebase fulfillment script,
      * but we can use following fn to write some data from EPIM to RealtimeDB
      * {action:'OpenProductMaintenance', value:'1bar'}
      */
     function writeToRealtimeDB() {


     }

     /**
      * 
      */
     function readFromRealtimeDB() {
       

     }
     


     /**
      * 
      */
     function startRealtimeDBTimer() {

     }
     

    
  },
   

//  
//  /**
//    * Creates a ChatbotButton in the bottom area
//    */
//   createChatbotButton: function(cfg){
//     var me = this; 
//     
//     var chatbotButton = extVia.assistance.chatbot.View.statics.createChatbotButton(cfg);
//     
////     
////     
////     var centerPan = extVia.regApp.myRaster.getCenter();
////     var centerRight = centerPan.getEl().getRight();      
////     var centerBottom = centerPan.getEl().getBottom();         
////     var posX = centerRight-66;
////     var posY = centerBottom-60;
////
////     var chatbotButton = Ext.create('Ext.Button', {
////       style:'z-index: 9999; position: absolute; opacssity: 0; border-radius:0px; visibility:hidden;',
////       bodyStyle:'font-size:32px;',
////       cls:'xty_chatbot-btn hvr-glow hvr-wobble-vertical',
////       //text:' [&middot; &middot;] ',
////       text:'  &#129302;  ',
////       renderTo: Ext.getBody(),
////       enableToggle:true,
////       
////       pressedCls:'chatbot-btn-pressed',
////       
////       x: posX,
////       y: posY,       
////       width:48, height:48,
////       handler: function(btn) {
////         if (!btn.pressed){ 
////           me.chatbotPanel.hideMe();
////           
////           btn.setTextDelayed(' &#129302; ',  false, 50); 
////         }
////         else{ 
////           me.startChat(cfg); 
////           btn.removeCls('hvr-wobble-vertical'); 
////           btn.setTextDelayed(' ✕  ', true, 300);
////         }
////       },
////       showMe: function(){
////         var me = this;
////         me.getEl().slideIn('tl',{duration: 2000 , easing: 'elasticIn'  });
//////         me.getEl().animate({
//////          duration: 500,
//////           to: {
//////               opacity: 1
//////           }
//////          });
////       },
////       setTextDelayed: function(text, pressed, delay){
////         var btn = this;
////         var showChatbotPanelTask2 = new Ext.util.DelayedTask(function(){ 
////           if (pressed){
////             btn.addCls('xty_chatbot-btn-pressed '); 
////           }
////           else{
////             btn.addCls('hvr-wobble-vertical'); 
////             btn.removeCls('xty_chatbot-btn-pressed'); 
////           }
////           btn.setText(text);
////         });
////         showChatbotPanelTask2.delay(550); 
////       }
////       
////   });
//     
//     chatbotButton.showMe();
//     
//   },
   
   chatbotPanel: null,
   startChat: function(cfg){
     var me = this; 

     var chatbotPanel = me.chatbotPanel;
     if (!chatbotPanel){
       chatbotPanel = extVia.assistance.chatbot.View.statics.createChatbotPanel(cfg);
       me.chatbotPanel = chatbotPanel;
     }
     chatbotPanel.showMe();
     
     
     me.startCommandListener(cfg);
     
    }
   }
});