

/**
 * Provides acces sto modules, opens whtas needed for a module them in West(lists, trees), Center (editors) etc.
 */
Ext.define('extVia.accessArea.modules.access', {
    statics: {
    
    openLanguageModule: function(cfg, epob){
      
     var westTabPan = extVia.regApp.myRaster.getWestTabPanel();
     westTabPan.addAndActivate(extVia.accessArea.baseSet.getBaseSetTabCfg({store:  extVia.stores.initLanguageStore(), columnRenderers:{name:'dscr'}, dataIndexes:{name:'dscr',id:'countryLangId', icon:'iso2'},   ownerCtHeight:westTabPan.getHeight(),epobTypeId:extVia.enums.EpimObjects.LANGUAGE.id}));  

   
     var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
     var adminEditorTab = centerTabPan.addAndActivate(extVia.editor.baseEditor.statics.getAdminEpobEditorPanelCfg({pgjobDscr:'System Sprache', pgjobEpobDscr:'neu anlegen'},{}));
    }
    
    
    }
});


Ext.define('extVia.accessArea.baseSet', {
    statics: {
    
    getBaseSetTabCfg: function(cfg){
      
      var epobTypeId = cfg.epobTypeId;
      var epobType =  extVia.module.epob.getEpobKeyFromTypeId(epobTypeId);
      cfg.epobType = epobType;      
      var epobTypeDscrP = extVia.module.epob.getEpobTypeDscrFromTypeId(epobTypeId, "P") ;  
      cfg.epobTypeDscrP = epobTypeDscrP;  
      
      var baseSetItems = extVia.accessArea.baseSet.getBaseSetCfg(cfg);
      
      var baseSetTabCfg ={  
                 title:  epobTypeDscrP,
                 itemId : 'baseSetTab_'+epobType,
                 refresh:function(){alert("refresh on "+this.title)},
                 preferences:function(){alert("einstellungen on "+this.title)},
                 border:false,
                 margins : '0 0 0 0',
                 layout:'fit',
                 tbar:{
                  defaults:{
                    scale:'small'
                  },
                  items:[
	                    //{text:'System '+epobTypeDscrP},
                        '->',
	                    {iconCls:' xty_pgtoolbar-edit'},
                        {iconCls:' xty_pgtoolbar-new'},
	                    {iconCls:' xty_pgtoolbar-delete'}
                         //{iconCls:' xty_pgtoolbar-list'},
	                    //{xtype:'splitbutton',iconCls:' xty_pgtoolbar-thumbsBig'}
                    ]
                    },
                 //bbar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}],
                 items: baseSetItems   
               };

      return baseSetTabCfg; 
    },
    
    
    getBaseSetCfg: function(cfg){

      var epobTypeId = cfg.epobTypeId;
      var epobType = cfg.epobType?cfg.epobType: extVia.module.epob.getEpobKeyFromTypeId(epobTypeId);
      var epobTypeDscrP =cfg.epobTypeDscrP?cfg.epobTypeDscrP: extVia.module.epob.getEpobTypeDscrFromTypeId(epobTypeId, "P") ;   

      //var languageNameColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {return '<span>' +value+' </span><span style="color:#888"> '+record.get('countryLangId')+'</span>';};
      
      var  baseSetIDColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
        return '<span style="color:#888"> '+value+'</span>';
      };
      
      
      
      var baseSetStatusColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
        return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
      };
      var baseSetDatatypeColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
        return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;'+value+'</div>';
      };
      

      var baseSetCfg  = { 
        xtype:'grid',
        tiXXtle:  epobTypeDscrP,
        itemId : 'baseSetGrid_'+epobType,
        border:false,
        style:'border-bottom:1px solid #99BCE8;',
        bbar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}],
        height:cfg.ownerCtHeight-128,

        emptyText:"keine "+epobTypeDscrP+' am start',
        store:cfg.store,
        columns:[
        //{header:'Typ'},// needed for mixed Sets
        {header:'Flag', width:32, dataIndex: cfg.dataIndexes.icon,  renderer:baseSetStatusColumnRenderer},
        {header:'Name', flex:1, dataIndex: cfg.dataIndexes.name},
        {header:'Id', width:64, dataIndex: cfg.dataIndexes.id, renderer:baseSetIDColumnRenderer},
        {header:'Status', dataIndex: cfg.dataIndexes.status, width:32, hidden: true}
        
        ]
            
      }
      
      var detailPanel = {
       xtype:'panel',
       border:false,bodyBorder:false,
       //style:'border-top:1px solid gold;',
       //title:'detailPanel',
       //collapsible:true,
       defaults:{margin:'8 4 4 8'},
       items:[
       { xtype:'displayfield', itemId:'name',   fieldLabel:'Name', value:'' },  
       { xtype:'displayfield', itemId:'status', fieldLabel:'Status', value:'' },
       { xtype:'displayfield',  itemId:'icon', fieldLabel:'', value:'', hideEmptyLabel:false}
       
       ],
       width:330 
      }
      
      

      return [baseSetCfg, detailPanel]; 
    }
    
    
    }
});
