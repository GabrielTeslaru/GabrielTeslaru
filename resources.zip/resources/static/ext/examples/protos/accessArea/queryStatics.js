
   /**
   * highlights the searchedValue inside displayValues of an autoCompleteBox
   * @param  {String} textStr  the displayValue
   * @param  {Boolean} outermatchHighlighting  the highlightingMode
   * @param  {String} boundlistId  
   * @return  {String} formattedStr 
   */
   extVia.formatAutoCompleteText = function (textStr, outermatchHighlighting  , boundlistId, boundlistParentId) {
    var formattedStr = textStr;
    try{ 
          //var combo = Ext.getCmp(boundlistParentId).items[0];
          
          var searchVal = extVia.currentRawValue;// workaround in set store filters
          searchVal = searchVal.replace( /[*%]/g, ".*");
          var valX  = new RegExp("("+searchVal+")", 'i');
		  // if googleHighlighting
		  if(outermatchHighlighting){	     
			 // whats not found
			 //formattedStr = formattedStr.replace(valX,"</b>$1<b style='background:#eaf4f9'>");
		     //formattedStr = "<b style='background:#eaf4f9'>"+formattedStr+"</b>"			 
			 // whats left
			 formattedStr = formattedStr.replace(valX,"$1<b style='background:#f4fbba' class='xty_hit'>");
			 formattedStr = formattedStr+"</b>"
		  }
		  else {
		  	// whats found
		  	formattedStr = formattedStr.replace(valX,"<span style='background:#f4fbba;' class='xty_hit'>$1</span>");
		  } 
    }catch(ex){ }
    return formattedStr;
  };   




Ext.define('extVia.query.statics', {
    statics: {

	getQueryTabCfg : function(){
		var queryTabCfg = 	    		
	       {  
	    	   title: locales.search,
	    	   moveHoriz:function(){alert("do my query moveHoriz");},
	    	   id : 'recherche',
	    	   itemId : 'recherche',
	    	   border:false,
	    	   margins : '0 0 0 0',
	           items:[
	              extVia.query.statics.initQueryQuickPanel()
	              //extVia.query.statics.initElastictQueryExtendedPanel()
	    	   ]
	    	 } ;
		return queryTabCfg;
	},
	
	
//    
//	getQueryTabCfg : function(){
//		return  extVia.query.statics.getElastictQueryTabCfg();
//	},  
	
	
	getSearchButtonCfg : function(cfg){
		
        
      return   {
          xtype: 'splitbutton', 
          itemId: 'searchButton', 
          name: 'searchButton', 
          tooltip: extVia.locales.search,
          scale: 'large',
          iconCls: 'xty_pgtoolbar-search',
          margin: '4 0 0 10',
          style:'padding-top:8px;',
          width: 58,
          height: 50,
          rowspan: 2,
          colspan: 1,
          
          menu: cfg.searchButtonMenuOFF?null: {items:[
 
                       {text: 'Suchbegriff(e)', iconCls:'xty_menu_contains',id:'searchterm',
                    	   
                       	menu:{
                        	   defaults:{
                   			   handler:function(item){
                   				   //alert(item.parentMenu.floatParent.id)
                   				   Ext.getCmp("searchterm").setIconCls(item.iconCls);   
                   			   }
                       	      },
                       	
                       		items:[
                       	
                       	      {text: 'einer enthalten( = |)', iconCls:'xty_menu_contains'},
                       	      {text: 'alle enthalten( = &)', iconCls:'xty_menu_containsAll'},
                       	      {text: 'nicht enthalten( -)', iconCls:'xty_menu_containsNot'},
                       	      {text: 'Beginnt mit (^)', iconCls:'xty_menu_startsWith'},
                       	      {text: 'Endet mit ($)', iconCls:'xty_menu_endsWith'},
                       	      {text: 'Stimmt genau überein ("")', iconCls:'xty_menu_exact'}
                       	     ]  
                         	}
                         },
                         
                  '-',
                  {text: 'Spracheinstellung', iconCls:'xty_menu_languageUser',   
              		menu:{items:[ {
              			 xtype:'combo', itemId:'language', name:'p_sLanguage', 
              			 store: extVia.stores.initLanguageStore({}),
              			 queryMode: 'local',
              			 typeAhead: true,
              			 displayField: 'dscr',
           	  			 emptyText: 'Pick language',
           	  			 valueField: 'iso2',
           	  			 value: 'DE',
                           listConfig : {
                           	   minWidth:210,
	   	                           getInnerTpl : function() {
		                                var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
		                                return tpl;
			                       }
                              }	 	                		 
              		 }]}
                  	},
                  	
                    
                   
                   {text: extVia.locales.workVersion_P+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="xty_menu-versioning-work" style="width:16px;height:16px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>', iconCls:'xty_menu-versioning-work', id:'querySearchButtonMenuItem-versioningSettings_1',value: 'work',
                  	hidden:true, checked:true,
               	   textPrefixW:'&nbsp;&nbsp;&nbsp;&nbsp;<span class="xty_menu-versioning-work" style="width:16px;height:16px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>',
               	   textPrefixV:'&nbsp;&nbsp;&nbsp;&nbsp;<span class="xty_menu-versioning-version" style="width:16px;height:16px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>',
               	   
       			   handler:function(item){
       				   if (item.value=='work'){
       					   Ext.getBody().addCls("xty_body_search4Versions");
       					   item.setText(extVia.locales.frozVersion_P+item.textPrefixV);
       					   item.value='version';
       				   }
       				   else {
       					   Ext.getBody().removeCls("xty_body_search4Versions");  
       					   item.setText(extVia.locales.workVersion_P+item.textPrefixW);
       					   item.value='work';
       				   }
       				   item.checked=false;
       				   Ext.getCmp("querySearchButtonMenuItem-versioningSettings_1").setIconCls('xty_menu-versioning-'+item.value);   
       			   }	
               
               },
               
               
               {text: 'Versionseinstellung', iconCls:'xty_menu-versioning-work', id:'querySearchButtonMenuItem-versioningSettings', hidden:true,
                  	menu:{

 		            	   defaults:{
		            		   style:'padding-left:20px', 
		            		   height:48,
	            			   handler:function(item){
	            				   if (item.value=='version'){
	            					   Ext.getBody().addCls("xty_body_search4Versions");
	            				   }
	            				   else {
	            					   Ext.getBody().removeCls("xty_body_search4Versions");  
	            				   }
	            				   Ext.getCmp("querySearchButtonMenuItem-versioningSettings").setIconCls('xty_menu-versioning-'+item.value);   
	            			   }
		            	      },                   	      
                  	      items:[   
                  	        {value: 'version',iconCls:'xty_pgtoolbar-versioning-version', text: extVia.locales.frozVersion_P} , 
                  	        {scale:extVia.constants.raster.pagetoolbarCenterBtnScale, iconCls:'xty_pgtoolbar-versioning-work', value: 'work',text: extVia.locales.workVersion_P} 
                  	      ]
                  		}
                  },
                  
                  
                  {text: 'Ergebnisdarstellung', iconCls:'xty_menu_thumbs',

                      menu: {       
                          items: [
      					                            
      					                            
      					{ xtype:'panel',
      					    layout: {
      					        type: 'hbox',
      					        padding:'5',
      					        align:'middle'
      					    },
      					    defaults:{margins:'0 5 0 0'},
      					    width:400,
      					    items:[  
      					           {		
      					        	xtype:'form',
      					 	        frame:true,
      					 	        height:120,
      					 	        bodyStyle:'padding:5px 5px 0',
      					 	        fieldDefaults: {
      					 	            msgTarget: 'side'
      					 	            //labelWidth: 50
      					 	        },
      					 	        defaultType: 'radio',
      					 	        defaults: {
      					 	            anchor: '100%'
      					 	        },
      								items:[	{
      								    xtype: 'radiogroup', 
      									id:'resultsasRadiogroup',
      									itemId:'resultsasRadiogroup',
      								    columns: 1,
      								    width:140,
      								    defaults:{width:200, margins:'0 5 0 50'},
      								    items: [
      										{boxLabel: 'List', name: 'resultsasRadiogroup', inputValue: 'List', checked :true},
      								        {boxLabel: 'Thumbs', name: 'resultsasRadiogroup', inputValue: 'Thumbs' },
      								        {boxLabel: 'Thumbs small', name: 'resultsasRadiogroup', inputValue: 'Thumbs small'},
      								        {boxLabel: 'Tree', name: 'resultsasRadiogroup', inputValue: 'Tree'}
      						
      								    ]
      								} ]
      					 	    },           
      					
      						
      						   
      						{		xtype:'form',
      						        frame:true,
      						        height:120,
      						        bodyStyle:'padding:5px 5px 0',
      						        width: 220,
      						        fieldDefaults: {
      						            msgTarget: 'side',
      						            labelWidth: 85
      						        },
      						        
      						        defaults: {
      						            anchor: '100%'
      						        },
      					
      						        items: [	        				                 		 
      							    
      				              { fieldLabel: 'Platzierung', xtype:'checkbox' }, 
      				              
      				               {   xtype:'combo',
      				                   width:40,
      				                   fieldLabel:'Treffermenge',
      				                   store:  {  
      				                	   fields: [ {type: 'string', name: 'hits'}],
	        				                   data : [ 
	        				                         {hits: '5'}, {hits: '10'}, {hits: '15'}, {hits: '20'}, 
	        				                         {hits: '25'}, {hits: '50'}, {hits: '100'}  
	        				                     ]	
      				                   },
      				                   displayField: 'hits',
      				                   typeAhead: true,
      				                   mode: 'local',
      				                   triggerAction: 'all',
      				                   emptyText:'20',
      				                   selectOnFocus:true
      				               },
      				               { fieldLabel: 'Aufgeklappt', disabled:true, xtype:'checkbox', checked: false }
      				               ]
      						    }// eo form Panel
      					       ]// eo ergebnisdarstellungsPanel items
      						  }// eo ergebnisdarstellungsPanel 		                              
      					   ]
                      }

                 },
                  '-',
                  {text: 'Schnellsuche'},
                  {text: 'Erweiterte Suche'},
                  {text: 'Suche einschr&auml;nken', handler:cfg.restrictHandler,menu:[{text: 'Einschr&auml;nken aufheben',handler :cfg.unrestrictHandler}]},
                  '-',
                  {text: 'Suchen laden'},
                  {text: 'Suchen recherchieren', menu:[]},
                  {text: 'Suche speichern', menu:[]},
                  '-',
                  {text: 'Sucheeingabe l&ouml;schen'}

                  ]},
          
          handler: function(button, evt){

          	var formValues = Ext.encode(button.ownerCt.getForm().getValues()).replace(/,/g ,",<br>") ; 
          	
  	        extVia.showNotification({
  		  	      status : 'Inactive',
  		  	      cls: 'ux-notification-light',
  		  	      position: 'tr',
  		  	      title : extVia.regApp.name+ " search click",
  		  	      html : 'Implement the search<br>'+formValues
  		  	    });
          }
        };
		
		
	},
	
    initQueryQuickPanel : function(cfg){

            if (!cfg){cfg={};}
      
	    	extVia.ui.layout.region.West = {
	    			labelWidth: 100,
	    			DEF: 220
	    	};
	    	extVia.currentRegion = extVia.ui.layout.region.West;
	    	
	    	
	    	var restrictHandler =function (item, evt){

	 			var queryContainer = extVia.regApp.myRaster.getWestTabPanel().getComponent('recherche').getComponent('queryContainer');
	 			queryContainer.setTitle("Restricted to XY");
	 			queryContainer.getHeader().show();
	 			var  searcharea = queryContainer.getComponent('searcharea');   

	 		    Ext.form.field.VTypes.restrictedSearcharea = function (v, field){
	 		    	var val = field.getValue();
	 		    	if (val < extVia.module.epob.PRODUCT  || val  == extVia.module.epob.MYPRODUCT){return false;}
	 		    	else return true;
	 		    };
	 		    Ext.form.field.VTypes.restrictedSearchareaText = 'Eingeschr&auml;nkte Suche ist nur f&uuml;r Produkte, Varianten und Hierarchien verf&uuml;gbar';
	 		 	searcharea.vtype = 'restrictedSearcharea';
	 		    searcharea.validate();
	 	    };
	 	   var unrestrictHandler = function (item, evt){
				var queryContainer = extVia.regApp.myRaster.getWestTabPanel().getComponent('recherche').getComponent('queryContainer');             			
				queryContainer.setTitle(undefined);
				queryContainer.getHeader().hide();
				var  searcharea = queryContainer.getComponent('searcharea');   
				
				queryContainer.setTitle("Restricted toXY");
	   		 	searcharea.vtype = null; //'alphanum';
	   		    searcharea.validate();
	   	    };

	        cfg.restrictHandler= restrictHandler; 
	        cfg.unrestrictHandler=unrestrictHandler;

	        var queryQuickContainer = {
	          xtype: 'form',  // container
	          itemId: 'queryContainer',
	          cls:'xty_queryQuick-formpanel',
	          border: false,
	          padding: '0 0 5 0',
	          layout: {
	            type: 'table',
	            columns: 3
	          },
	          defaults:{
	            labelWidth: extVia.currentRegion.labelWidth,
	            width:  extVia.currentRegion.labelWidth + extVia.currentRegion.DEF -70,
	            margin: '4 0 0 0'
	          },
	          items: [
	          {
	            xtype: 'textfield',
	            itemId: 'searchterm',
	            name: 'searchterm',
	            
	            fieldLabel : extVia.locales.searchterm,
	            colspan: 2
	          }, 
	          	          
	          extVia.query.statics.getSearchButtonCfg(cfg),	   
	          
	          {
	        	  fieldLabel : cfg.searchareaDscr?cfg.searchareaDscr:extVia.locales.searcharea, 
	              itemId:'searcharea',
	              cls:'xty_searchareaCombo',
	              //emptyText:'Suchbereich',
	              store:extVia.stores.getSearchareaStore(cfg), queryMode: 'local',displayField: 'dscr',  valueField: 'value',     
	              xtype:'combo',
	              name: 'searcharea',
	              forceSelect:false,
	              allowBlank:false,
	              value: extVia.module.epob.MYPRODUCT,
	              colspan: 2,
	              
                  listConfig : {
               	   minWidth:180,
                      getInnerTpl : function(displayField) {
                        var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{[ extVia.module.epob.getEpobKeyFromTypeId(values.value)]}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div></div>';
                        return tpl;
                      }
                    } 
	          }
	          ]
	        };
	        return queryQuickContainer;
	    },  
	    
	getElastictQueryTabCfg : function(){
    	extVia.ui.layout.region.West = {
    			labelWidth: 100,
    			DEF: 220,
    			mainWestWidth:extVia.regApp.myRaster.getWest().getWidth()
    	};
    	
    	
    	extVia.currentRegion = extVia.ui.layout.region.West;
		
		var elastictQueryTabCfg = {  
	    	   title: 'Elastic',
	    	   id : 'elastictQuery',
	    	   itemId : 'elastictQuery',
	    	   border:false,
	    	   margins : '0 0 0 0',

	    	   defaults:{
		          
		          },
	           items:[
	                  extVia.query.statics.initElastictQueryQuickPanel(),
	                  extVia.query.statics.initElastictQueryExtendedPanel()
	    	          ]
	    	 } ;
		
		return elastictQueryTabCfg;
	},
	    
	    
	 initElastictQueryQuickPanel : function(){
	        var elastictQueryQuickContainer = {
	          xtype: 'form',  // container
	          itemId: 'elastictQueryQuickContainer',
	          cls:'xty_queryQuick-formpanel',
	          border: false,
	          padding: '0 0 5 0',
	          layout: {
	            type: 'table',
	            columns: 3
	          },
	          defaults:{
	            labelWidth: extVia.currentRegion.labelWidth,
	            width:  extVia.currentRegion.labelWidth + extVia.currentRegion.DEF -70,
	            margin: '4 0 0 0'
	          },
	          items: [
	          {
	            xtype: 'combo',
	            itemId: 'searchterm',
	            name: 'searchterm',
	            hideTrigger:true,
	            store:extVia.stores.getSearchareaStore(), queryMode: 'local',displayField: 'dscr',  valueField: 'value',     
	            fieldLabel : extVia.locales.searchterm,
	               listConfig : {
	            	   minWidth:180,
	                   getInnerTpl : function(displayField) {
	                     var tpl = 
	                    	 	'<div style="width:100%;height:32px;" class="">'
	                    	 		+'<img style="width:32px;height:32px;src="">' 
                    	 			+'<span style="padding-left:32px;">' + '&nbsp; {dscr}' 
                    	 			+ '</span>'
	                    	 	+'</div>'
	                    	 	+'<div style="width:100%;height:16px;padding-left:32px;" class="">'
                    	 			+'<span style="">' + '&nbsp; {dscr}' 
                    	 			+ '</span>'
                    	 		+'</div>';
	                     return tpl;
	                   }
	                 },
	            colspan: 2
	          }, 
	          	          
	          extVia.query.statics.getSearchButtonCfg({}),	          
	          
	          {
	        	  fieldLabel : 'Suche nach',
	              itemId:'searcharea',
	              cls:'xty_searchareaCombo',
	              emptyText:'Suchobjekte',
	              store:extVia.stores.getSearchareaStore(), queryMode: 'local',displayField: 'dscr',  valueField: 'value',     
	              xtype:'combo',
	              name: 'searcharea',
	              forceSelect:false,
	              allowBlank:false,
	              value: extVia.module.epob.ALL,
	              colspan: 2,
	               listConfig : {
	            	   minWidth:180,
	                   getInnerTpl : function(displayField) {
	                     var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{[ extVia.module.epob.getEpobKeyFromTypeId(values.value)]}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
	                     return tpl;
	                   }
	                 }  
	          }
	          ]
	        };
	        return elastictQueryQuickContainer;
	    },
	    
	 initElastictQueryExtendedPanel : function(){

	        var elastictQueryExtendedContainer = {
	          collapsible:true,
	          
	          title:'<span>Facettierte Suche<span>',	
	          itemId: 'elastictQueryExtendedContainer',
	          cls:'xty_queryExtended-bin',
	          bodyStyle:'border-left:0px;border-right:0px;',
	         
	          padding: '0 0 5 0',
	          width:extVia.currentRegion.mainWestWidth,

	          defaults:{
	            labelWidth: extVia.currentRegion.labelWidth,
	            width:  extVia.currentRegion.mainWestWidth-14,
	            margin: '4 0 0 4'
	          },
	          items: [
	                  
	                  
	         {xtype:'tbspacer', height:8},  
       		 { xtype:'fieldset', title:'<b>Objekttypen</b>', collapsible : true,
       			 items:[
             		 {	 
       				     xtype:'boxselect',     				     
             			 itemId:'epobTypes',
       	                 store:extVia.stores.getSearchareaStore(), displayField: 'dscr',  valueField: 'value',  
              			 width:  extVia.currentRegion.mainWestWidth-36,
      	                 listConfig : {
    	            	   minWidth:180,
    	                   getInnerTpl : function(displayField) {
    	                     var tpl = 
    	                    	 '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{[ extVia.module.epob.getEpobKeyFromTypeId(values.value)]}">'
    	                    	 	+'<span style="margin-top:-8px;">' 
    	                    	 		+ '&nbsp; {dscr}' 
    	                    	 	+ '</span>'
    	                    	 +'</div>';
    	                     return tpl;
    	                   }
    	                 },  
              			 name:'p_arrEpobTypes',
              			 queryMode: 'local',
           	  			 emptyText: 'Alle epobTypes'
              		 } 	 
              			 
       			 ]	 
       		 },	         
       		 { xtype:'fieldset', title:'<b>Hierachien</b>', collapsible : true,
       			 items:[
             		 {	 
       				     xtype:'boxselect',     				     
             			 fielsdLabel:'Hierachien',
              			 itemId:'hierarchies',
              			 store:  extVia.stores.getHierachiesStore({}),
              			 width:  extVia.currentRegion.mainWestWidth-36,
              	         listConfig : {
              				width:440,
              			    getInnerTpl: function(displayField) {
          	                    return '<div  class="x-combo-list-item">{[extVia.formatAutoCompleteText(values.name, false,"'+this.id+'","'+this.ownerCt.id+'")]}</div>' ;   
          	                }			
              			 },
              			 name:'p_arrHierachies',
              			 queryMode: 'local',

              			 displayField: 'name',
              			 values:['SCH_D13','SCH_D17'],
           	  			 emptyText: 'Alle Hierachien',
           	  			 valueField: 'path'
              		 } 	 
              			 
       			 ]	 
       		 },	
       		 { xtype:'fieldset', title:'<b>Kategorien</b>', collapsible : true,
       			 items:[
             		 {	 
       				     xtype:'boxselect',
             			 fieldsLabel:'Kategorien',
             			 width:  extVia.currentRegion.mainWestWidth-36,
              			 store:  extVia.stores.getCategoriesStore({}),
                          listConfig : {
                          	 minWidth:440
                           },
              			 name:'p_arrKategories',
              			 queryMode: 'local',
              			 itemId:'categories',
              			 displayField: 'name',
           	  			 emptyText: 'Alle Kategorien',
           	  			 valueField: 'path'
              		 } 	 
       			 ]	 
       		 },	
       		 {xtype:'tbspacer', height:8},        
	                  
       		 { xtype:'fieldset', title:'<b>Metadaten</b>', collapsible : true,   collapsed:true,
   			     defaults:{
    			    	width:  extVia.currentRegion.mainWestWidth-58
    			     },
       			 items:[
	          { fieldLabel : 'Name' , xtype: 'textfield', name: 'p_sName' }, 
	          { fieldLabel : 'Schlagwort' , xtype: 'textfield', name: 'p_sCatchword' }, 
	          { fieldLabel : 'EPIM-Id' , xtype: 'textfield', naxme: 'p_sEpimId' }, 
	          { fieldLabel : 'Artikelnummer' , xtype: 'textfield', naxme: 'p_sArticelNr' }, 
	          { fieldLabel : 'Bestellnummer' , xtype: 'textfield', naxme: 'p_sOrdernr' }, 
	          { fieldLabel : 'Schlagwort' , xtype: 'textfield', naxme: 'p_s' }, 
	          
//	          {xtype:'checkboxgroup', name:'p_cbgrpVariants', itemId:'cbgrpVariants', fieldLabel: 'Varianten', 
//	        	  items:[  {name:'p_sRootVariant', itemId:'only',boxLabel: '&nbsp;Nur'}, 
//	        	           {name:'p_sRootVariant', itemId:'none',boxLabel: '&nbsp;Keine'},
//	        	           {name:'p_sRootVariant',  checked:true, itemId:'all',boxLabel: '&nbsp;Alles'},
//	        	           ]
//	          },
//	          
	          {xtype:'radiogroup', name:'p_rdgrpVariants', itemId:'rdgrpVariants', fieldLabel: 'Varianten', 
	        	  items:[  {name:'p_sVariants', checked:true, itemId:'yes',boxLabel: '&nbsp;Ja'}, 
	        	           {name:'p_sVariants',  itemId:'none',boxLabel: '&nbsp;Nein'},
	        	           {name:'p_sVariants', itemId:'only',boxLabel: '&nbsp;Nur Varianten'}
	        	           ]
	          }
	          ]
       		 },
       		 {xtype:'tbspacer', height:8},  
       		 
	      	  { xtype:'fieldset', title:'<b>Änderungsinfo</b>', collapsible : true, collapsed:true,
	      			 items:[
	      		          {xtype:'radiogroup', name:'p_rdgrpchangeOrCreation', itemId:'changeOrCreation', fielsdLabel: 'Änderungsinfo', hideEmptyLabel:false,
	      		        	  items:[  

	      		        	           {name:'p_sChangeOrCreation',  itemId:'creation',boxLabel: '&nbsp;Erstellt'},
	      		        	           {name:'p_sChangeOrCreation', checked:true, itemId:'change',boxLabel: '&nbsp;Geändert'}
	      		        	           ]
	      		          },
	      		          { xtype:'fieldcontainer', fieldLsabel:'Änderungsinfo', collapsible : true,layout:'hbox',hideEmpstyLabel:false,
	      		      			 items:[
	      		      		          { labelWidth:60, fieldLabel : 'von' , xtype: 'datefield', naxme: 'p_s',flex:.5 }, 
	      		      		          { labelWidth:60, fieldLabel : 'bis' , xtype: 'datefield', naxme: 'p_s',flex:.5  } 	 
	      		      			 ]	 
	      		          },	
	      			      { xtype:'fieldcontainer', fieldLsabel:'Änderungsinfo', collapsible : true,layout:'hbox',hideEmpstyLabel:false,
	      		      			 items:[
	      		      		          { labelWidth:60, fieldLabel : 'Gruppe' , xtype: 'combo', naxme: 'p_s',flex:.5  }, 
	      		      		          { labelWidth:60, fieldLabel : 'Benutzer' , xtype: 'combo', naxme: 'p_s' ,flex:.5 }
	      		             			 
	      		      			 ]	 
	      		      	  }	
	             			 
	      			 ]	 
	      		 },	
	          
	          
	          
//	          {xtype:'radiogroup', name:'p_rdgrpchangeOrCreation', itemId:'changeOrCreation', fieldLabel: 'Änderungsinfo', hideEmptyLabel:false,
//	        	  items:[  
//
//	        	           {name:'p_sChangeOrCreation',  itemId:'creation',boxLabel: '&nbsp;Erstellt'},
//	        	           {name:'p_sChangeOrCreation', checked:true, itemId:'change',boxLabel: '&nbsp;Geändert'}, 
//	        	           ]
//	          },
//	          { xtype:'fieldcontainer', fieldLsabel:'Änderungsinfo', collapsible : true,layout:'hbox',hideEmptyLabel:false,
//	      			 items:[
//	      		          { labelWidth:60, fieldLabel : 'von' , xtype: 'datefield', naxme: 'p_s',flex:.5 }, 
//	      		          { labelWidth:60, fieldLabel : 'bis' , xtype: 'datefield', naxme: 'p_s',flex:.5  }, 	 
//	      			 ]	 
//	          },	
//		      { xtype:'fieldcontainer', fieldLsabel:'Änderungsinfo', collapsible : true,layout:'hbox',hideEmptyLabel:false,
//	      			 items:[
//	      		          { labelWidth:60, fieldLabel : 'Gruppe' , xtype: 'combo', naxme: 'p_s',flex:.5  }, 
//	      		          { labelWidth:60, fieldLabel : 'Benutzer' , xtype: 'combo', naxme: 'p_s' ,flex:.5 }, 
//	             			 
//	      			 ]	 
//	      	  },	

	      	  
	          
	  
      		 
      		 {xtype:'tbspacer', height:8},  
      		 
      		 { xtype:'displayfield', value:'<b>&nbsp;&nbsp;&nbsp;Attribute</b>' },	
      		 
    		 {xtype:'combo', hidden:true,
    			 store: extVia.stores.initAttributesStore({}),
    			 queryMode: 'local',
    			 displayField: 'dscr',
 	  			 emptyText: 'Pick a Facette',
 	  			 valueField: 'name',
    			 fieldLasbel: 'Attribute',
    			 
    			 listeners:{
    				 'change': function(combo) {
    					 combo.ownerCt.add({xtype:'fieldset',collapsible : true, closable : true,title:''+combo.getRawValue()});
    				 }
    			 },
    			 
                 listConfig : {
              	    minWidth:210,
                     getInnerTpl : function(displayField) {
                       var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{epobType}">{multiplicity}<span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span> ({hits})</div>';
                       return tpl;
                     }
                   }		 
    		 },
     		 
      		 
      		 
      		 { xtype:'fieldset', title:'Wohnungsfeatures', collapsible : true,tools:[{id:'close'}],
      			 items:[
                   { text:'x', xtype: 'button',tooltip:'filter löschen', itemId: 'clear' ,style:'position:absolute;right:16px;'},    
                   { text:'&laquo;', xtype: 'button', tooltip:'filter zurück', itemId: 'backy' ,style:'position:absolute;right:38px; z-index:19999;top:-10px'},    
             
      			   { boxLabel : 'Balkon' , xtype: 'checkbox', name: 'p_sName' }, 
         		   { boxLabel : 'Terasse' , xtype: 'checkbox', name: 'p_sName' }, 
      			   { boxLabel : 'Garten' , xtype: 'checkbox', name: 'p_sName' }, 
      			   { boxLabel : 'Garage' , xtype: 'checkbox', name: 'p_sName' }, 
      			   { boxLabel : 'Tiefgarage' , xtype: 'checkbox', name: 'p_sName' }, 
      			   { boxLabel : 'Altbau' , xtype: 'checkbox', name: 'p_sName' }, 
                   {xtype:'tbspacer', height:8} 
      			 ]	 
      		 },	      		 
	          
      		{xtype:'tbspacer', height:8}
	          

	          ]
	        };
	        return elastictQueryExtendedContainer;
	    }	    	
    }
});
