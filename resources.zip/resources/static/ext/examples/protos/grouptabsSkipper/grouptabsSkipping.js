Ext.Loader.setConfig({enabled: true});

Ext.Loader.setPath('Ext.ux', '../../ux/');

Ext.require([
    'Ext.Viewport',
    'Ext.tip.QuickTipManager',
    'Ext.tab.Panel',
    'Ext.ux.GroupTabPanel',
    'Ext.grid.*'
]);


Ext.onReady(function() {

	Ext.tip.QuickTipManager.init();
    
    // create some portlet tools using built in Ext tool ids
    var tools = [{
        type:'gear',
        handler: function(){
            Ext.Msg.alert('Message', 'The Settings tool was clicked.');
        }
    },{
        type:'close',
        handler: function(e, target, panel){
            panel.ownerCt.remove(panel, true);
        }
    }];




var panel = Ext.create('Ext.ux.GroupTabPanel',  {
           
	   name:"grouptabpanel",

	   
	   cls:'xty_regionCenter',	
	   id:'myGrouptabpanel',   
       activeGroup: 0,
			
    	items: [
    		
    		
		{// group6 : Collections
			   
			name:"erstes GroupTab",
			mainItem: 0,
			expanded: false,
			
			// my
		//	beforeactivate: loadHandler,
			
			
			items: [
				{
					title: 'Sammlungen', // mainItem
					name:"sammlungen",
					itemId:"sammlungen",
				    //cls:'',
				    style:'background:red;',
					//index:0,
					layout: 'fit',
					tabTip: 'collections tabtip',
					style: 'padding: 10px;',
					items: [{
						   style:'margin:10px',
							html: '<div class="xty_wizJob">Automatisches Anlegen einer Sammlung. </div>',
							border:false
						}]
				},
				{
					title: 'Pflegen', // subItem
					itemId: 'pflegen',
					name:"pflegen",
					layout: 'fit',
					tabTip: 'pflegen tabtip',
					style: 'padding: 10px;',
					items: [{
							style:'margin:10px',
							html: '<div class="xty_wizJob">Pflegen einer Sammlung. </div>',
							border:false
						}]
				}
			]// eo group6 items
		       },// eo group6	
    		
    		
    		
			// my_test
			
			
			
    		
    		
    		{
    			mainItem: 1,
    			items: [{
    				title: 'Tickets',
    				name:"tickets",
    				itemId:"dashboard",
                    iconCls: 'x-icon-tickets',
                    tabTip: 'Tickets tabtip',
                    //border: false,
                    xtype: 'gridportlet',
                    height: null
    			}, 
                {
                    xtype: 'portalpanel',
                    title: 'Dashboard',
                    name:"dashboard",
                    itemId:"dashboard",
                    tabTip: 'Dashboard tabtip',
                    border: false,
                    items: [{
                        flex: 1,
                        items: [{
                            title: 'Portlet 1',
                            
                            html: '<div class="portlet-content">'+Ext.example.bogusMarkup+'</div>'
                        },{
                            
                            title: 'Stock Portlet',
                            items: {
                                xtype: 'chartportlet'
                            }
                        },{
                            title: 'Portlet 2',
                            html: '<div class="portlet-content">'+Ext.example.bogusMarkup+'</div>'
                        }]
                    }]                  
                }, {
    				title: 'Subscriptions',
    				name:"subscriptions",
    				itemId:"subscriptions",
                    iconCls: 'x-icon-subscriptions',
                    tabTip: 'Subscriptions tabtip',
                    style: 'padding: 10px;',
                    border: false,
					layout: 'fit',
    				items: [{
						xtype: 'tabpanel',
						activeTab: 1,
						items: [{
							title: 'Nested Tabs',
							html: Ext.example.shortBogusMarkup
						}]	
					}]	
    			}, {
    				title: 'Users',
    				name:"users",
    				itemId:"users",
                    iconCls: 'x-icon-users',
                    tabTip: 'Users tabtip',
                    style: 'padding: 10px;',
    				html: Ext.example.shortBogusMarkup			
    			}]
            }, {
                expanded: true,
                items: [{
                    title: 'Configuration',
                    itemId:'configuration',
                    name:"configuration",
                    iconCls: 'x-icon-configuration',
                    tabTip: 'Configuration tabtip',
                    style: 'padding: 10px;',
                    html: 'FERTIG GO' 
                }, {
                    title: 'Email Templates',
                    itemId: 'emailtemplates',
					name: 'emailtemplates',
                    iconCls: 'x-icon-templates',
                    tabTip: 'Templates tabtip',
                    style: 'padding: 10px;',
                    border: false,
                    items:{
                            xtype: 'form', // since we are not using the default 'panel' xtype, we must specify it
                            id: 'form-panel',
                            labelWidth: 75,
                            title: 'Form Layout',
                            bodyStyle: 'padding:15px',
                            labelPad: 20,
                            defaults: {
                                width: 230,
                                labelSeparator: '',
                                msgTarget: 'side'
                            },
                            defaultType: 'textfield',
                            items: [{
                                    fieldLabel: 'First Name',
                                    name: 'first',
                                    allowBlank:false
                                },{
                                    fieldLabel: 'Last Name',
                                    name: 'last'
                                },{
                                    fieldLabel: 'Company',
                                    name: 'company'
                                },{
                                    fieldLabel: 'Email',
                                    name: 'email',
                                    vtype:'email'
                                }
                            ],
                            buttons: [{text: 'Save'},{text: 'Cancel'}]
                        }
                }]
            }]
		});

panel.region="center";

panel.margins='24 24 12 24';
		
var navi = Ext.create('Ext.ux.grouptabnavi',panel);


navi.region="south";


Viewport_ = Ext.create('Ext.Viewport', {
        layout:'border',
		
		// my _xtype_
		id: 'tree',
		xtype: 'viewport', 
		enableNoGroups:false,

        items:[
               panel,navi
               
              // {  region:'north', height:90,   buttons:[{text:'weiter'}]}
         ]
		
    });
	
// navi.show();		
	
	
	
	
//	debugger;
});
