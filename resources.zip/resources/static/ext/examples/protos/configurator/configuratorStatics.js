Ext.namespace('extVia.configurator');
Ext.define('extVia.configurator.statics', {
    statics: {

      
      
      showConfiguratorDialog : function(config) {
        try {
          var me = this,
              configuratorDialog = Ext.getCmp(me.configuratorDialogId);

          if(!configuratorDialog){      
            configuratorDialog = extVia.configurator.statics.createConfiguratorDialog(config);
          }
          configuratorDialog.show();
           
          return  configuratorDialog;
        } catch(exception) {
           window.alert('showConfiguratorDialog exception '+exception);
        }
      },
      
      getConfiguratedEpobsPanel : function(config) {
        
        var me = this;
        
        var instrPanel = extVia.dialoges.getInstructionPanel ({
          mainInstr: 'Sie haben 25 Varianten konfiguriert.',
          suppInstr:'F&uuml;llen Sie alle mit <b>Namen</b> und <b>Bestellnummern</b>.'
        });
        
        
        
        
//        var carFields = ['Model', 'BasicConfiguration', 'Paint', 'Wheels', 'Interior', 'SeatConfiguration', 'ComfortPackage', 'ImprovedAutopilotFunctionality', 'Battery', 'Range' , 'MaximumSpeed', '0to100kmh'];
//        var carFieldsHeaders = [ 'Model' , 'Basis Konfiguration' , 'Lackierung' , 'R&auml;der' , 'Innenraum' , 'Sitz Konfiguration' , 'Komfort-Paket' , 'Verbesserte Autopilot-Funktionalität' , 'Batterie' , 'Reichweite' , 'H&ouml;chstgeschwindigkeit' , '0-100km/h'];
//        var carData = [
//          [ 'Model S' , '100D' , 'Deep Blue Metallic' , '19-Zoll-Felgen' , 'silber,' , 'Beige' , '5-Sitze' , 'selektiert' , 'nicht selektiert' , '100 kWh' , '632 km' , '250 km/h' , '4,3 Sek.'  ],
//          [ 'Model S' , '100D' , 'Deep Blue Metallic', '19-Zoll-Felgen', 'silber', 'Komplett Schwarz  ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'  ],
//          [ 'Model S' , '100D' , 'Deep Blue Metallic',  '19-Zoll-Felgen', 'silber', 'Schwarz und Weiß  ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'],
//          [ 'Model S' , '100D' , 'Midnight Silver Metallic',  '19-Zoll-Felgen', 'silber', 'Beige ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'],
//          [ 'Model S' , '100D' , 'Midnight Silver Metallic',  '19-Zoll-Felgen', 'silber', 'Komplett Schwarz  ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'  ],
//          [ 'Model S' , '100D' , 'Midnight Silver Metallic',  '19-Zoll-Felgen', 'silber', 'Schwarz und Weiß  ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'  ],
//          [ 'Model S' , '100D' , 'Pearl White Multi-Coat',  '19-Zoll-Felgen', 'silber', 'Beige ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'  ],
//          [ 'Model S' , '100D' , 'Pearl White Multi-Coat',  '19-Zoll-Felgen', 'silber', 'Komplett Schwarz  ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h',  '4,3 Sek.'  ],
//          [ 'Model S' , '100D' , 'Pearl White Multi-Coat',  '19-Zoll-Felgen', 'silber', 'Schwarz und Weiß  ', '5-Sitze', 'selektiert', 'nicht selektiert', '100 kWh', '632 km',  '250 km/h']
//        ];
//        
        
       var configuratedEpobModelFields = ['assignable', 'name', 'epobType', 'orderNr', 'length',   'height',  'width', 'diameter', 'color',  'resistance' ,'overload-protection'] ;
       var  configuratedEpobModel = Ext.define('configuratedEpob', {
          extend: 'Ext.data.Model',
          fields: configuratedEpobModelFields
        });

       var dummyRenderer =  function (value, metaData, record, rowIndex, colIndex, store, view){
         var dummyData =' ABCDEFG';
         if (configuratedEpobModelFields[colIndex]){  
           var dataIndex = configuratedEpobModelFields[colIndex];
           var randy = Math.round( 100 + (rowIndex * colIndex / (rowIndex+1) + colIndex) * 100);
           switch (dataIndex) {
             case 'length':
               dummyData = randy +' mm';
               break;
             case 'height':
               dummyData = randy +' mm';
               break;           
             case 'width':
               dummyData = randy +' mm';
               break;  
             case 'diameter':
               dummyData = randy +' Ø';
               break;            
             case 'color':
               dummyData = '#'+randy;
               break;             
             case 'resistance':
               dummyData = randy + ' &#8486;';
               break; 
             case 'overload-protection':
               dummyData = rowIndex % 3 === 0 ? ' &#10003;' : '-';
               break; 
             default:
               dummyData = configuratedEpobModelFields[colIndex];
               break;
           }
         }
         return dummyData;  
       };
       
       
       var currentEpobName = me.currentEpobName ?  me.currentEpobName : ' ';
       
       var generateOrderNrCnt = 0;
       var generateOrderNr = function(){
         var date = new Date();
         var millis = date.getMilliseconds();
         var nrstr = generateOrderNrCnt.toString();
         var nrblockA = nrstr+nrstr+nrstr;
         generateOrderNrCnt++;
         var nrblockB = '000'+generateOrderNrCnt;
         var orderNr = millis+'-' +nrblockA +'-'+nrblockB;
         return orderNr;
       };
       
       
        var configuratedEpobsStore  = Ext.create('Ext.data.Store', {
          storeId: 'configuratedEpobsStore',
          model: 'configuratedEpob',
          proxy: {
            type: 'memory',
            reader: {
                type: 'json',
                root: 'items'
            }
          },
          data:{'items':[
              { 'name': currentEpobName +' Variante 1',  "epobType":"ProductVariant",  "orderNr":generateOrderNr() },
              { 'name': currentEpobName +' Variante 2',  "epobType":"ProductVariant",  "orderNr":generateOrderNr() },
              { 'name': currentEpobName +' Variante 3', "epobType":"ProductVariant",  "orderNr":generateOrderNr()  },
              { 'name': currentEpobName +' Variante 4', "epobType":"ProductVariant", "orderNr":generateOrderNr()  },
              { 'name': currentEpobName +' Variante 5',  "epobType":"ProductVariant",  "orderNr":generateOrderNr()  },
              { 'name': currentEpobName +' Variante 6',  "epobType":"ProductVariant", "orderNr":generateOrderNr() },
              { 'name': currentEpobName +' Variante 7', "epobType":"ProductVariant",  "osrderNr":generateOrderNr()  },
              { 'namxe': currentEpobName +' Variante 8', "epobType":"ProductVariant", "osrderNr":generateOrderNr()  }
          ]}
        });
        
       var requiredStar =  "<SPAN class=\"requiredfield lty_requiredStar\"> *</SPAN>";
        

//       extVia.configuratedEpobsGridInputHandler = function(inputEl){
//         var dataIndex = inputEl.getAttribute('data-index');
//         var rowindex = inputEl.getAttribute('data-rowindex');
//         var record =  configuratedEpobsStore.getAt(rowindex);
//         if (record){
//           record.set(dataIndex,inputEl.value ) ;  
//         } 
//       };
    //
//       var tabindex = 0;
    //// ,renderer : function (value, metaData, record, rowIndex, colIndex, store, view){
    //// var orderNr = value.replace(/ /g,'');
    //// return '<input type="text" value="'+value+'"   tabindex="'+(tabindex++)+'"  onchange="extVia.configuratedEpobsGridInputHandler(this);" data-index="orderNr"  data-rowindex="'+rowIndex+'"  class="x-form-field-fake" style="padding-left:2px;border:1px solid #B5B8C8; width: 100%; background-image: url(../jsp/css/GRAPE/img/ext/form/text-bg.gif); ">'; 
    ////}
       
       
       
       var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
         clicksToEdit: 1
       });

       var editableCellRenderer = function (value, metaData, record, rowIndex, colIndex, store, view, columnWidth){ 
         metaData.tdCls='xty_grid-editable-cell';
         var isemptyCls = Ext.isEmpty(value.replace(/ /g,'')) ? 'xty_form-field-fake-isempty' :'';
         var html =  '<div class="xty_form-field-fake '+isemptyCls+'" style="width: '+(columnWidth-10)+'px;">'+value+'</div>';
         return html;
       };
       
       var configuratedEpobsGrid;
       configuratedEpobsGrid =  Ext.create('Ext.grid.Panel', {
          plugins: [cellEditing],
          itemId:'configuratedEpobsGrid',
          cls:'xty_configurated-epobs-grid',
          store:configuratedEpobsStore,
          viewConfig:{
            getRowClass : function(record, rowIndex, rowParams, store) {
              var name = record.get('name').replace(/ /g,'');
              var orderNr = record.get('orderNr').replace(/ /g,'');
              var assignable = !Ext.isEmpty(name)  && !Ext.isEmpty(orderNr); 
              var rowCls= assignable ? 'xty_configurated-epob-row-assignable' :'xty_configurated-epob-row-unassignable';   
              if(record.isModified('name') || record.isModified('orderNr')){
                rowCls+=' xty_configurated-epob-row-entered';
              }
              return rowCls;
           }
          },

          listeners:{
            itemclick: function( view, record, item, index, evt, eOpts ){
              Ext.get(item).addCls('xty_configurated-epob-row-entered');
            }
          },
          
          selModel: Ext.create('Ext.selection.CheckboxModel', 
            {
            checkOnly:true, 

            listeners:{
              beforeselect: function ( selmodel, record, index ){
                var name = record.get('name').replace(/ /g,'');
                var orderNr = record.get('orderNr').replace(/ /g,'');
                var nameEmpty = Ext.isEmpty(name);
                var ordernrEmpty = Ext.isEmpty(orderNr);
                var assignable = !nameEmpty  && !ordernrEmpty; 
                if (!assignable){
                  configuratedEpobsGrid.getView().addRowCls( record, 'xty_configurated-epob-row-entered' );
                  var missingFields = nameEmpty ? 'Name' :''; 
                  missingFields+= nameEmpty && ordernrEmpty ? ' und ' :''; 
                  missingFields+= ordernrEmpty ? ' Bestellnummer' :''; 
                  top.showNotification('Bitte '+missingFields+' ausf&uuml;llen','ChangeIt','Zeile ausw&auml;hlen');
                }

                var applyBtn = configuratedEpobsGrid.ownerCt.ownerCt.getComponent('buttons').getComponent('apply');
                if(applyBtn){
                  if(!assignable){ 
                    applyBtn.disable();
                  }
                  // TODO check if all SELECTED rows are valid
                  else { applyBtn.enable();}  
                }
                return  true; 
              }
          
            }
            }),
          columns: [ 
//            { header: 'Typ', dataIndex: 'epobType', width: 36 ,
//              renderer : function (value, metaData, record, rowIndex, colIndex, store, view){
//                var ttip = value;
//                metaData.tdCls=   'xty_epob' + value + '-icon-cell' ;
//                return '<div data-qtip="' + ttip + '" class="xty_epob' + value + '" style="height:18px;"/>';
//              },
//            },
            
            { header: '<span class="xty_icon xty_iconChecked">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>', dataIndex: 'assignable', width: 42 ,
              renderer : function (value, metaData, record, rowIndex, colIndex, store, view){
                var name = record.get('name').replace(/ /g,'');
                var orderNr = record.get('orderNr').replace(/ /g,'');
                var valid = !Ext.isEmpty(name)  && !Ext.isEmpty(orderNr);
                if(!valid){
                  metaData.tdCls='xty_grid-editable-cell-unassignable';
                }
                var iconCls  = valid?'Assigned' :'Nothing'; //  Assigned should be Assignable
                var ttip = valid?'Kann &uuml;bernommen werden' :' Bestellnummer und Name d&uuml;rfen nicht leer sein';
                return '<div data-qtip="' + ttip + '" class="xty_icon xty_icon' + iconCls + '" style="height:18px;"/>';
              }
            },
            
            { header: '<b> Name </b> '+ requiredStar,  dataIndex: 'name', width: 240, 
              editor: {
                xtype: 'textfield',
                margin:'4 0 4 6',
                style:'font-size:11px;',
                width: 230,          
                maxWidth: 230,    
                selectOnTab: true,
                allowBlank: false
              },
              renderer : function (value, metaData, record, rowIndex, colIndex, store, view){ 
                return editableCellRenderer(value, metaData, record, rowIndex, colIndex, store, view, 240);
              }
            },
            
            { header: '<b>Bestellnummer</b> '+ requiredStar, dataIndex: 'orderNr', width: 140,          
              editor: {
              xtype: 'textfield',
              margin:'4 0 4 6',
              style:'font-size:11px;',
              width: 130,          
              maxWidth: 130,          
              selectOnTab: true,
              allowBlank: false
             },
              renderer : function (value, metaData, record, rowIndex, colIndex, store, view){ 
                return editableCellRenderer(value, metaData, record, rowIndex, colIndex, store, view, 140);
              }
            },
            { header: 'L&auml;nge', dataIndex: 'length', renderer: dummyRenderer },{ header: 'H&ouml;he', dataIndex: 'height', renderer: dummyRenderer },{ header: 'Breite', dataIndex: 'width', renderer: dummyRenderer  },{ header: 'Durchmesser', dataIndex: 'diameter', renderer: dummyRenderer },{ header: 'Farbe', dataIndex: 'color', renderer: dummyRenderer },
            { header: 'Widerstand', dataIndex: 'resistance', renderer: dummyRenderer },
            { header: '&Uuml;berlastschutz', dataIndex: 'overload-protection', renderer: dummyRenderer }
          ],
          margin:'0 10 10 10',
          height: config.height-62,
          width: config.width-30
      });

       
        var configuratedEpobsPanelCfg = 
        { itemId:'configuratedEpobsPanel', border:false, height: config.height,
          items:[
            instrPanel,
            configuratedEpobsGrid
          ]
        };
        return configuratedEpobsPanelCfg;
      },
      
      
      
      
      
      /**
       * @param config
       */
      createConfiguratorDialog : function(config) {
        try {
          var me = this; 
          if (!config){
            config = {};
          }
          if (!config.app){
            config.app = me;
          }     
          var configuratorDialog =  Ext.getCmp(me.configuratorDialogId);
          if(!configuratorDialog){
           // configuratorDialog = new extVia.ux.widgets.ConfiguratorDialog(config);

            
            var width=  900;
            var height = 600;
            
            configuratorDialog =  Ext.create('Ext.window.Window', {
              title: 'Konfigurator',
              itemId: 'configuratorDialog',
              componentCls:'xty_dialog xty_configurator-dialog',
              x:380,
              y:210,
              height: height,
              width: width,
              layout: 'fit',
              items: [ 
                me.getConfiguratedEpobsPanel({width:width,height:height-40})
              ] 
          });

            me.configuratorDialogId = configuratorDialog.id;
          }
          return  configuratorDialog;
        } catch(exception) {
          alert('createConfiguratorDialog exception '+exception)
        }
      }      
      
      
    }
       
    }
);