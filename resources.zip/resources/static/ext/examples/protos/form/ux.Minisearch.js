/**
 * @class BaseMinisearch
 * 
 *  A Container (Buttongroup) providing a quicksearch AND an extended Search.<br> 
 *  contains a triggerfield, an extend Button and a formPanel where all searchparams are hold.<br>
 *  
 *  <code>
 *  config:{
 *  quicksearchTypeSelector: { name:'fieldName', fieldLabel:'', storeid:null , triggerPosition: 1|2},
 *  fields (searchparam-columns): should be given as  {type: 'string|number|date|boolean', storeid:null, name:'fieldName', fieldLabel:''},
 *  searchbehaviour: [
 *    { name: 'columnoperator',  value: 'AND',  editable:false , fieldLabel:'',  values:'AND|OR' },
 *    { name: 'matching',  value: 'CONTAINS' ,  editable:false , fieldLabel:'', values:'CONTAINS|STARTSWITH|ENDSWITH|EXACT'},
 *    { name: 'sort',  value: 'ASC',  editable:false , fieldLabel:'', values:'ASC|DESC'},
 *    { name: 'orderby',  , value: 'NAME',  editable:false , fieldLabel:'', values:'name|type|changedate|id|ressourcetext|remark|comment'}
 *  ]
 *  } 
 *  <code>
 *  
 *  To be used in toolbars of a List or any other Set(list/baselist/grid/tree/thumb ...).
 * 
 * @author Simon Lederer, Viamedici Software GmbH
 * @version $Date: 2015/07/16 16:20:16 $ $Revision: 1.7 $
 */
Ext.define('Ext.ux.BaseMinisearch', { 
  extend: 'Ext.container.ButtonGroup',
  alias:'widget.baseminisearch'
  });



Ext.define('Ext.ux.PratMinisearch', { 
    extend: 'Ext.ux.BaseMinisearch',
    alias:'widget.pratminisearch',
    id:'minisearch',
    cls:'xty_minisearch-bin xty_minisearch-btngroup',
    itemId:'minisearch',
    margin : '0 10 0 10',

    submit:function(cfg){ 
        var quickmode = cfg.quickmode;
        var searchcriteriaPanel =  this.getSearchcriteriaPanel();
        var searchcriteriaForm = searchcriteriaPanel.getForm();    
        var quicksearchtextField =  this.getComponent('quicksearchtextField');
        var quicksearchtextValue = quicksearchtextField.getValue();
        var quickDataType = quicksearchtextField.getDataType();
        
        if (quickmode){
          searchcriteriaForm.reset();
          searchcriteriaPanel.getComponent('dataType').setValue(quickDataType);
        }
        searchcriteriaPanel.getComponent('quickmode').setValue(quickmode);
        searchcriteriaPanel.getComponent('quicksearchtext').setValue(quickmode?quicksearchtextValue:''); 
        searchcriteriaPanel.getComponent('columnoperator').setValue(quickmode?'OR':'AND'); 

        alert("searchcriteria   \n " +Ext.encode(searchcriteriaForm.getValues()).replace(/,/g ,",\n") ); 
    },
    
    getSearchcriteriaPanel : function(){
        var searchcriteriaWrapperMenu = this.getComponent('showExtendedSearchBtn').getMenu();
        var searchcriteriaPanel =  searchcriteriaWrapperMenu.getComponent('searchcriteriaPanel');  
        return searchcriteriaPanel;
    },

    items:[   
      {
        xtype:'triggerfield', 
        cls : 'xty_quicksearchtextField xty_has-insidetrigger ',
        itemId:'quicksearchtextField',
        tooltip:'Suche',
        dataType:'Attribute',
        getDataType: function(){
         return this.dataType;
        },
        setDataType: function(dataType){
         this.dataType = dataType;
        },
        
        getTriggerEl: function(triggerNr){
          var me = this;
          var triggersArr = Ext.DomQuery.select('#'+me.id+' .x-trigger-index-'+(triggerNr-1));
          var trgId =  triggersArr[0].id;
          return Ext.get(trgId);
        },
 
        trigger1Cls : 'xty_inside-trigger-search',
        onTrigger1Click:function(evt){
          this.ownerCt.submit({quickmode : true});
        },
        
        trigger2Cls : 'xty_form-attribute-trigger',
        trigger2Tooltip : 'Datentyp:&nbsp;Alle&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;', 
        onTrigger2Click:function(evt){   
              var menuOwner = this;
              var triggerEl =  Ext.get(evt.target.id);  
              //var triggerEl =  menuOwner.getTriggerEl(2);  
              var menu = Ext.create('Ext.menu.Menu',{
                valueField: 'epobType',     
                defaults:{
                 handler:function(item){
                   menuOwner.setDataType( item[item.ownerCt.valueField]);
                   var newEpobCls = item.triggerCls?item.triggerCls:item.iconCls;
                   triggerEl.setTriggerCls(newEpobCls);
                   if (triggerEl.setTooltip){triggerEl.setTooltip('Datentyp:&nbsp;'+item.text); }
                 }
                },
              items: [
//                  {text: 'Alle Typen', iconCls:'xty_epobAttribute', epobType:'Attribute' , epobTypeId:extVia.enums.EpimObjects.PRODUCTATTRIBUTE.id    },
//                  {text: 'Collection', iconCls:'xty_epobAttributeCollection', epobType:'AttributeCollection', epobTypeId:extVia.enums.EpimObjects.PRAT_COLLECTION.id },
//                  {text: 'Dictionary', iconCls:'xty_epobDictionary', triggerCls: 'x-form-dictionary-trigger', epobType:'Dictionary' , epobTypeId:extVia.enums.EpimObjects.PRAT_DICTIONARY.id},
//                  {text: 'String', iconCls:'xty_epobString', epobType:'String', epobTypeId:extVia.enums.EpimObjects.PRAT_STRING.id },
//                  {text: 'Dyn-String', iconCls:'xty_epobDynString', epobType:'DynString' , epobTypeId:extVia.enums.EpimObjects.PRAT_STRING.id+5},
//                  {text: 'Flag', iconCls:'xty_epobFlag', epobType:'Flag' , epobTypeId:extVia.enums.EpimObjects.PRAT_FLAG.id},
//                  {text: 'Number', iconCls:'xty_epobNumber', epobType:'Number', epobTypeId:extVia.enums.EpimObjects.PRAT_NUMBER.id },
//                  {text: 'Selection', iconCls:'xty_epobSelection', epobType:'Selection' , epobTypeId:extVia.enums.EpimObjects.PRAT_SELECTION.id}     
 
                      {text: 'Alle', iconCls:'xty_epobAttribute', epobType:'Attribute', triggerCls: 'xty_form-attribute-trigger'},
		              {text: 'Collection', iconCls:'xty_epobAttributeCollection', epobType:'AttributeCollection', triggerCls: 'xty_form-attributeCollection-trigger'},
		              {text: 'Date', iconCls:'xty_epobDate', epobType:'Date', triggerCls: 'x-form-date-trigger'},
		              {text: 'Dictionary', iconCls:'xty_epobDictionary', epobType:'Dictionary' , triggerCls: 'xty_form-dictionary-trigger' },
		              {text: 'String', iconCls:'xty_epobString', epobType:'String', triggerCls: 'xty_form-string-trigger'}, 
		              {text: 'DynString', iconCls:'xty_epobDynString', epobType:'DynString', triggerCls: 'xty_form-dynstring-trigger' },
		              {text: 'Flag', iconCls:'xty_epobFlag', epobType:'Flag', triggerCls: 'xty_form-flag-trigger' },
		              {text: 'Number', iconCls:'xty_epobNumber', epobType:'Number', triggerCls: 'xty_form-number-trigger'},
		              {text: 'Selection', iconCls:'xty_epobSelection', epobType:'Selection', triggerCls: 'xty_form-selection-trigger' }
          
              ]
              });

           var pos = Ext.get(evt.target.id).getXY();
           pos[0]-=52;
           pos[1]+=21;
           menu.showAt(pos);
        },
        enableKeyEvents : true,
        listeners:{
          keydown:function(triggerfield, evt){
            if (evt.getKey()===Ext.EventObject.ENTER){
              Ext.getCmp('minisearch').submit({quickmode:true}); 
            }
          },
          
          afterrender:function(field){
            
            // datatype trigger
            if (field.trigger2Cls){
            var trigger2El =  field.getTriggerEl(2);       
            trigger2El.setTriggerCls = function(triggerCls){ 
             var me = trigger2El;
             me.removeCls(me.triggerCls);
             me.addCls(triggerCls);
             me.triggerCls = triggerCls;
            };
            trigger2El.triggerCls = field.trigger2Cls; // so that the initial state can be removed
          
            if (field.trigger2Tooltip){
              var tip;
              tip = Ext.create('Ext.tip.ToolTip', {
              target: trigger2El.id,
              html: field.trigger2Tooltip,
              setHtml: function(html){
                var tooltipBodyEl = Ext.get(tip.id+'-body');
                if (tooltipBodyEl){
                  tooltipBodyEl.dom.innerHTML = html;
                }
              }
               });
               trigger2El.tip = tip;
               trigger2El.setTooltip = function(tooltip){ 
                trigger2El.tip.setHtml(tooltip);
               };
            } 
          }// eo init trigger2El
          }  
       } 
      }, 
  
  
      {  xtype:'button',
	     iconCls:'x-btn-split-right',
	     itemId:'showExtendedSearchBtn',
	     tooltip:'Erweiterte Suche',
	     width:20, height:22,
	     
	     handler:function(button, evt){
	      var myMenu = this.getMenu(); 
	      var pos = this.getPosition();
	      pos[0] = pos[0] -278;
	      pos[1] = pos[1] -92;
	      
	      if (!myMenu.isVisible()){
	        myMenu.showAt(pos);
	      }
	     },
	     
	     getMenu: function (){
	      if (!this.myMenu){
	       this.myMenu = Ext.create('Ext.menu.Menu', this.menuCfg);
	      }
	      return this.myMenu;
	     },
	     
	     menuCfg:{
	       shadow:false,
	       cls:'xty_formwrappermenu-flat',
	       bodyCls:'xty_formwrappermenu-body-flat',
	       id:'searchcriteriaWrapperMenu',  
	       items:[      
		   // extended Query     
		   {
		    xtype: 'form',  
		    frame:true,
		    itemId: 'searchcriteriaPanel',
		    rbar:{ cls:'xty-minirbar-xs', width:14, margin: '-7 0 0 0', 
		           items:[ 
		            { iconCls:'xty_minitool-close', overCls:'xty_minitool-over', itemId: 'close',
		              handler:function(){ 
		              var searchcriteriaWrapperMenu  =  Ext.getCmp('searchcriteriaWrapperMenu'); 
		              searchcriteriaWrapperMenu.hide();
		           } 
		            }
		            ]},
		     defaults:{
		      labelWidth: 120,
		      width:  280,
		      enableKeyEvents : true,
		      listeners:{
		          keydown:function(triggerfield, evt){
		            if (evt.getKey()===Ext.EventObject.ENTER){
		              Ext.getCmp('minisearch').submit({quickmode:false}); 
		            }
		          }
		      }   
		    },
		    items: [
		    {xtype: 'hiddenfield', name: 'quickmode',  itemId: 'quickmode', value: false},
		    {xtype: 'hiddenfield', name: 'quicksearchtext',  itemId: 'quicksearchtext'},
		    
		    {
		      xtype: 'triggerfield',
		      margin: '2 0 0 0',
		      //cls : 'xty_inside-trigger ',
		      triggerCls : 'xty_form-trigger-search',
		      itemId: 'name',
		      name: 'name',
		      fieldLabel :"&nbsp;Name",
		      
		      onTriggerClick:function(evt){   
		        var minisearch  =  Ext.getCmp('minisearch');
		        minisearch.submit({quickmode : false});
		      }
		    }, 
		
		    {
		        fieldLabel : "&nbsp;Datentyp",
		        margin: '2 0 0 0',
		        xtype:'combo',
		        name: 'dataType',
		        itemId:'dataType',
		        cls:'xty_searchareaCombo',
		        store:extVia.stores.initAttributeTypesStore({}), 
		        queryMode: 'local', 
		        displayField: 'dscr',  
		        valueField: 'epobType',     
		        forceSelection:true,
		        value: 'Attribute' ,
		        colspan: 2,
		          listConfig : {
		           minWidth:180,
		              getInnerTpl : function(displayField) {
		                var tpl = '<div class="xty_epobType-item" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{epobType}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div></div>';
		                return tpl;
		              }
		            } 
		    },
		    { xtype:'textfield',  margin: '2 0 0 0', fieldLabel : "&nbsp;Ressourcetext"  , name : "ressourcetext" , itemId : "ressourcetext" },
		    { xtype:'textfield',  margin: '2 0 0 0', fieldLabel : "&nbsp;Bemerkung"  , name : "remark" , itemId : "remark" },
		    { xtype:'textfield',  margin: '2 0 0 0', fieldLabel : "&nbsp;Kommentar"  , name : "comment" , itemId : "comment" },
		    
		    {xtype: 'hiddenfield', name: 'columnoperator',  itemId: 'columnoperator', value: 'AND', values:'AND|OR'},
		    {xtype: 'hiddenfield', name: 'matching',  itemId: 'matching', value: 'CONTAINS' , values:'CONTAINS|STARTSWITH|ENDSWITH|EXACT'},
		    {xtype: 'hiddenfield', name: 'sort',  itemId: 'sort', value: 'ASC' , values:'ASC|DESC'},
		    {xtype: 'hiddenfield', name: 'orderby',  itemId: 'orderby', value: 'NAME' , values:'name|type|changedate|id|ressourcetext|remark|comment'}
		
		    
		    ]
		    //buttons:[ {text:'Suchen',  handler:function(button){var minisearch  =  Ext.getCmp('minisearch'); minisearch.submit({quickmode : false});}}]
		  }          
	       ]      
	  },// eo menuCfg 
	
	  listeners:{
	     afterrender:function(button){
	      // Provide tooltips on button should be done by buttongroup
	      var tip = Ext.create('Ext.tip.ToolTip', {
	      target: button.id,
	      html: button.tooltip
	      });
	     }
	   } 
      }// eo showExtendedSearchBtn
   ]// eo minisearchitems
   
   });


/*
 * 
 * $Revision: 1.7 $
 * $Modtime: 20.04.15 16:49 $ 
 * $Date: 2015/07/16 16:20:16 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */

