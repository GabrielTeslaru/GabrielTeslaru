/*
* @author    Artur Taranyuk, Viamedici Software GmbH
*/

Ext.require(['*']);
Ext.onReady(function() {
recherchebereich='PRODUCTS';
// Store definition for Searchinputs.


Ext.define('searchType', {
    extend: 'Ext.data.Model',
    fields: [ 'Search']
	});

var searchStore = Ext.create('Ext.data.Store', {
    	model: 'searchType',
        proxy: new Ext.data.MemoryProxy()
});

function search(myCombo, key) {
		var url = document.URL.split('jsp');
       	 
       	extVia.ui.page.pagejob.setPagejobText(extVia.ui.page.strings.epobs[ "Epob_" + extVia.module.epob[recherchebereich]+"_P"]);   
        var marginTop= '-120';
       
        if(myCombo.getRawValue()!='') {
        	if (key==13){
        		
        		extVia.ui.page.BaseRaster.centerTabPanel.setActiveTab( 'queryCenterTab' );
        		
        		var html = '<iframe width="603" height="832" id="queryAppIFRAME" style="margin-top:'+marginTop+'px" frameborder="0" src=" '+url[0]+'jsp/QueryApp.jsp?appModeName=queryWestRun&embeddedin=productmaintenance&epobType='+recherchebereich+'&map=p_sSearchtext:'+myCombo.getRawValue()+'" ></iframe>';
        		Ext.fly('queryCenterTab-body').update(html, false);
        	}else{
        		window.open(url[0]+'jsp/QueryApp.jsp?appModeName=queryRun&epobType='+recherchebereich+'&map=p_sSearchtext:'+myCombo.getRawValue());
        	}
        var find = searchStore.find('Search', myCombo.getRawValue());
        if(find != -1){}else{ searchStore.add({Search: myCombo.getRawValue()});};
        }else{
        	if(key==13){
        		extVia.ui.page.BaseRaster.centerTabPanel.setActiveTab( 'queryCenterTab' );
        		var html = '<iframe width="603" height="832" id="queryAppIFRAME" style="margin-top:'+marginTop+'px" frameborder="0" src=" '+url[0]+'jsp/QueryApp.jsp?appModeName=queryWestRun&embeddedin=productmaintenance&epobType='+recherchebereich+'&map=p_sSearchtext:" ></iframe>';
       			
       			Ext.fly('queryCenterTab-body').update(html, false);
        	}else{
        		window.open(url[0]+'jsp/QueryApp.jsp?appModeName=queryRun&epobType='+recherchebereich+'&map=p_sSearchtext:');
        	}
        }
    };
    
function menu(myCombo, e){
	var split=document.URL.split('?');
	var searchareaAsTB='true';
		if(split[1]){
			var parameters = Ext.Object.fromQueryString(split[1]);
			searchareaAsTB = parameters.searchareaAsTB;
		};
		if(searchareaAsTB=='true'){
			myCombo.toolbar.showAt(myCombo.getPosition()[0]-350,0);
			myCombo.toolbar.focus();
		}else{
			myCombo.menu.showAt(myCombo.getPosition()[0]+18,myCombo.getPosition()[1]+20); 
	};
};

// Definition of CustomTrigger that will be used as miniquery for search
var miniqueryComp = Ext.define('Ext.ux.CustomTrigger', {
    extend: 'Ext.form.field.ComboBox',
    alias: 'widget.miniquery',
    trigger1Cls:'xty_miniquery-clear-trigger',
	trigger2Cls:'xty_miniquery-menu-trigger', 
    trigger3Cls:'xty_miniquery-search-trigger',
    hideTrigger1:false, 
    hideTrigger2:false, 
    hideTrigger3:false, 
    enableKeyEvents:true,
    autoSelect: false,

    listeners:{
    	focus: function(){
    						if(searchStore.getCount()>0){this.getPicker().show()};
    						if(this.toolbar){this.toolbar.hide();};
    						/*if(this.noAnimation == false){
	    						if(this.focused == false){
		    						this.animate({
		    							duration: '300',
		        						to: {
									            width: (this.getWidth() == 150) ? 200 : 150
									        },
									    keyframes: {
											        0: {
											            x : (this.getPosition()[0]-50)
											        }
											       },
									    dynamic: true
									});
									this.addCls('xty_miniquery-menu-trigger-ANIMATE');
									this.addCls('xty_miniquery-search-trigger-ANIMATE');
									this.focused = true;
									
								};
							};*/
    					},
    	blur: function(){
    						this.getPicker().hide(); 
    						/*if(this.noAnimation == false){
								if (this.focused == true){
									this.animate({
									duration: '300',
		        						to: {
									            width: (this.getWidth() == 200) ? 150 : 200
									        },
									    keyframes: {
											        0: {
											            x : (this.getPosition()[0]+50)
											        }
											       },
									    dynamic: true
									});
									this.removeCls('xty_miniquery-menu-trigger-ANIMATE');
									this.removeCls('xty_miniquery-search-trigger-ANIMATE');
									this.focused = false;
								};
							};*/
							
    					},
    	afterrender: function(e){
    					this.mapEnterAlt = new Ext.util.KeyMap(this.getEl(),{
    						key: Ext.EventObject.ENTER,
					       	alt: true,
					        scope: this,
					        fn: function(){search(this, 78);}
					    });
					    
					    this.mapCtrlArrow = new Ext.util.KeyMap(this.getEl(),{
    						key: Ext.EventObject.LEFT,
					       	ctrl: true,
					        scope: this,
					        fn: function(){
					        		if(!this.toolbar){
    									this.onTrigger2Click(e);
    								}else{
    									if(this.toolbar.isHidden()==false){
    										this.toolbar.hide();
    									}else{
    										this.onTrigger2Click(e);
    									}	
    								}
    							}
					    });
    					
    					this.addCls('xty_miniquery-menu-trigger-PRODUCTS'); 
    					this.addCls('xty_miniquery-clear-trigger-NONE');
    					
    					var searchareaTriggerId = Ext.query('#'+this.id+' DIV[class~="xty_miniquery-menu-trigger"]')[0].id; 
    					Ext.create('Ext.tip.ToolTip',{trackMouse: true, html: 'Suchbereich anzeigen', target: searchareaTriggerId});
    					
    					var searchTriggerId = Ext.query('#'+this.id+' DIV[class~="xty_miniquery-search-trigger"]')[0].id; 
    					Ext.create('Ext.tip.ToolTip',{trackMouse: true, html: 'Suche starten', target: searchTriggerId});
    					
    					var clearTriggerId = Ext.query('#'+this.id+' DIV[class~="xty_miniquery-clear-trigger"]')[0].id; 
    					Ext.create('Ext.tip.ToolTip',{trackMouse: true, html: 'Suchfeld leeren', target: clearTriggerId});
    					
    					
    					this.altKeyPressed = false;
    					this.focused = false;
    					this.noAnimation = false;
    					},
    					
    			
    	keyup: function(text,e){
    					
    					if (e.getKey() == e.ENTER) {search(text, 13 )};
    					if (e.getKey()==e.DOWN){if(searchStore.getCount()>0){this.getPicker().show()};};
    				
        				if (e.getKey()==e.PAGE_UP){
        					var find = searchStore.find('Search',this.getRawValue());
        					if(find != -1){searchStore.removeAt(find);};
        				};
    					},
    	change: function(text, newValue, oldValue){
    												if (newValue!=null){
    													text.removeCls('xty_miniquery-clear-trigger-NONE');
    												}else{
    													text.addCls('xty_miniquery-clear-trigger-NONE');
    												};
    												},
		select: function(){this.removeCls('xty_miniquery-clear-trigger-NONE');}
    	},
    store: searchStore, 
    queryMode: 'local',
    displayField: 'Search',
    typeAhead: true,
    paramName : 'filterText',
	fieldStyle: 'background: #ffffff; position:relative; right:-30px; border: #1876A5 solid 1px; padding:3px; border-left:0px; border-right: 0px;',
    //Triger one is for calling the menu
    onTrigger2Click: function(e) {
		 this.noAnimation = true;
         var myCombo = this;
    	 var temp;
    	 if(!this.toolbar){
    	 	this.toolbar = new Ext.Panel({
    	 	renderTo: Ext.getBody(), 
    	 	floating: true,            
    	 	width    : 406,
    	 	border: false,
			items: [{
			tbar:[{
			xtype: 'buttongroup',
			defaults: {handler: function(item){
								
    							recherchebereich  = extVia.module.epob.getEpobTypeFromTypeId(item.value);
								myCombo.removeCls('xty_miniquery-menu-trigger-'+temp);
    							myCombo.addCls('xty_miniquery-menu-trigger-'+recherchebereich);
    							
    							myCombo.recherchebereich = recherchebereich;
    							
    							temp = recherchebereich;	
								myCombo.toolbar.hide();
								myCombo.focus();
								myCombo.noAnimation = false;
					 			},
					 			scale: 'small'
					 },
			items:[
			       
			       {
    		icon: '../../protos/img/epobs/P_STANDARD_REL0_REF0.png',
    	    value: extVia.module.epob.PRODUCTS,
    	    tooltip: {
        		text: "Suche nach "+extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCT +"_P"]+"n",
        		anchor: 'top'
      		}
    	    
    		},{
    		icon: '../../protos/img/epobs/productAndVariants.png',
    	    value: extVia.module.epob.PRODUCTANDVARIANT,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTANDVARIANT +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/V_STANDARD_REL0_REF0.png',
    	    value: extVia.module.epob.PRODUCTVARIANT,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTVARIANT +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/G_STANDARD_REL0_REF0.png',
    	    value: extVia.module.epob.PRODUCTGROUP,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTGROUP +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/myProducts.png',
    	    value: extVia.module.epob.MYPRODUCT,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYPRODUCT +"_P"],
        		anchor: 'top'
      		}
    		},
    		
    		
    		//{xtype: 'tbseparator'}, // WHY does this not work?   		
    		{width:10,html:'<div class="x-toolbar-separator x-box-item x-toolbar-item x-toolbar-separator-horizontal" style="margin: 0px;margin-left: 4px;top:-2px " ></div>'}
    		
    		
    		,{
        		icon: '../../protos/img/epobs/category_16.png',
        	    value: extVia.module.epob.CATEGORY,
        	    tooltip: {
            		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.CATEGORY +"_P"],
            		anchor: 'top'
          		}
        	}
    		
    		
    		,{
    		icon: '../../protos/img/epobs/e_elements.png',
    	    value: extVia.module.epob.ELEMENTS,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"]+"n",
        		anchor: 'top'
      		}
    		}
    		
    		
    		,{
    		icon: '../../protos/img/epobs/e_myElements.png',
    	    value: extVia.module.epob.MYCATEGORIES,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYCATEGORIES +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_image_var.png',
    	    value: extVia.module.epob.IMAGE,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"]+"n",
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_graphic_var.png',
    	    value: extVia.module.epob.GRAPHIC,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_text_var.png',
    	    value: extVia.module.epob.TEXT,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"]+"n",
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_document_var.png',
    	    value: extVia.module.epob.DOCUMENT,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"+"n"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_edtable_var.png',
    	    value: extVia.module.epob.EDTABLE,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.EDTABLE +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_prodtable.png',
    	    value: extVia.module.epob.PRODUCTTABLE,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTTABLE +"_P"],
        		anchor: 'top'
      		}
    		}
    		
    		
    		
    		,{
    		icon: '../../protos/img/epobs/e_audio_var.png',
    	    value: extVia.module.epob.AUDIO,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],
        		anchor: 'top'
      		}
    		},{
    		icon: '../../protos/img/epobs/e_video_var.png',
    	    value: extVia.module.epob.VIDEO,
    	    tooltip: {
        		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],
        		anchor: 'top'
      		}
    		}/**/
    		
    		,{width:10,html:'<div class="x-toolbar-separator x-box-item x-toolbar-item x-toolbar-separator-horizontal" style="margin: 0px;margin-left: 4px;top:-2px " ></div>'}
    		
    		
    		,{
        		icon: '../../protos/img/epobs/collection_16.png',
        	    value: extVia.module.epob.COLLECTION,
        	    tooltip: {
            		text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.COLLECTION +"_P"],
            		anchor: 'top'
          		}
        	}
    		
    		
    		
    		
    		]
    		}]
    		}]
    	 	});
    	 } 
    	 if (!this.menu) {
        	this.menu = new Ext.menu.Menu({
    		floating: true,  
    		renderTo: Ext.getBody(),  
    		defaults: {handler: function(item){
    							recherchebereich  = extVia.module.epob.getEpobTypeFromTypeId(item.value);
								myCombo.removeCls('xty_miniquery-menu-trigger-'+temp);
    							myCombo.addCls('xty_miniquery-menu-trigger-'+recherchebereich);
    							temp = recherchebereich;
    							myCombo.recherchebereich = recherchebereich;
    							myCombo.focus();	
    							myCombo.noAnimation = false; 
					 }
					 },
    		items: [{
    		icon: '../../protos/img/epobs/P_STANDARD_REL0_REF0.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCT +"_P"],
    	    value: extVia.module.epob.PRODUCTS
    		},{
    		icon: '../../protos/img/epobs/productAndVariants.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTANDVARIANT +"_P"],
    	    value: extVia.module.epob.PRODUCTANDVARIANT
    		},{
    		icon: '../../protos/img/epobs/V_STANDARD_REL0_REF0.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTVARIANT +"_P"],
    	    value: extVia.module.epob.PRODUCTVARIANT
    		},{
    		icon: '../../protos/img/epobs/G_STANDARD_REL0_REF0.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTGROUP +"_P"],
    	    value: extVia.module.epob.PRODUCTGROUP
    		},{
    		icon: '../../protos/img/epobs/myProducts.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYPRODUCT +"_P"],
    	    value: extVia.module.epob.MYPRODUCT
    		},{
    		xtype: 'menuseparator'
    		},{
    		icon: '../../protos/img/epobs/e_elements.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"],
    	    value: extVia.module.epob.ELEMENTS
    		},{
    		icon: '../../protos/img/epobs/e_myElements.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYCATEGORIES +"_P"],
    	    value: extVia.module.epob.MYCATEGORIES
    		},{
    		icon: '../../protos/img/epobs/e_image_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"],
    	    value: extVia.module.epob.IMAGE
    		},{
    		icon: '../../protos/img/epobs/e_graphic_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],
    	    value: extVia.module.epob.GRAPHIC
    		},{
    		icon: '../../protos/img/epobs/e_text_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"],
    	    value: extVia.module.epob.TEXT
    		},{
    		icon: '../../protos/img/epobs/e_document_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"],
    	    value: extVia.module.epob.DOCUMENT
    		},{
    		icon: '../../protos/img/epobs/e_edtable_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.EDTABLE +"_P"],
    	    value: extVia.module.epob.EDTABLE
    		},{
    		icon: '../../protos/img/epobs/e_prodtable.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTTABLE +"_P"],
    	    value: extVia.module.epob.PRODUCTTABLE
    		},{
    		icon: '../../protos/img/epobs/e_audio_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],
    	    value: extVia.module.epob.AUDIO
    		},{
    		icon: '../../protos/img/epobs/e_video_var.png',
    	    text: "Suche nach "+ extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],
    	    value: extVia.module.epob.VIDEO
    		}]
        });
	}
	myCombo.toolbar.hide();
    menu(this, e);
    },
    //Clear button
    onTrigger1Click : function() {
    	this.reset();
    	this.addCls('xty_miniquery-clear-trigger-NONE');
    	this.focus();
    },
    //Search button
    onTrigger3Click : function(){
    	var key = 13;
    	search(this, key);
    }
});


});




/*
 * 
 * $Revision: 1.3 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2013/01/21 08:56:47 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
