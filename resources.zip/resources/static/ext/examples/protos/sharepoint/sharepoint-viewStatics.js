
Ext.define('extVia.sharepoint.view.statics', {
    statics: {

 

  getViewPanelCfg : function(cfg){

    var record = cfg.record;

    var epobTypeId = record.get('epobTypeId');

    var epob = {
      dscr:record.get('text'),
      name : record.get('text'),
      epobId:  record.get('epobId'),
      epobTypeId :  epobTypeId
    };


    var product_SuperFinish23 = {
       weburl:'https://www.wagner-group.com/en/contractor/product/superfinish-23-plus-al-emulsion/',
       breadcrumbs: ['Decorative Finishing','Architectural Coating','Diaphragm Pumps' ],
       shortDescription:'The compact solution - strong yet lightweight',     
       description: 'Compact: Smallest in its class, mobile and light. For small emulsion jobs up to 200 m². Robust: Perfectly designed for demanding construction site use. PumpRunner: perfect for clean transport. Can be used with 30 to 45 m hose length',    
       image:'csm_gross_SF23_Plus_Dispersion_446e066bd7.jpg',
       
       slides:[
         {img:'csm_Slider_Dispersion3_1d6da76e7a.jpg',  caption: 'The compact solution'},
         {img:'csm_Slider_Dispersion1_d95d934f2e.jpg',  caption: 'EASY AND LIGHTWEIGHT'},
         {img:'csm_Slider_TempSpray3_a23033b0ea.jpg',  caption: 'Strong in every Detail'}
       ],
       
       technicalData:[
         ['ArtNr.:',' Skid version (2341493), cart version (2341494)'],
         ['ELECTRIC MOTOR','1,3 kw'],
         ['MAX. PRESSURE',' 3600 PSI / 25 MPa'],
         ['WEIGHT on frame',' 26 kg'],
         ['WEIGHT on carriage',' 29 kg'],
         ['MAX. CONVEYING PERFORMANCE','2,6 l/min'],
         ['MAX. NOZZLE SIZE',' 0,023"']  
       ],
       
       bullets:[
         ['Material wetted parts'
           ],
         ['Included Items'
            ],
         ['Ordering information'
            ] 
        ], 
       
       pdf:'https://cdn.wagner-group.com/fileadmin/produkte/1_Professional_Finishing/Membranpumpen/1_PDFs/SuperFinish_2015_GB_small.pdf'

    };
    
    var product_SF_23 ={breadcrumbs: ['Decorative Finishing','Architectural Coating','Diaphragm Pumps' ]};
    

    var product_PILOT = {   
       
       weburl:'https://www.wagner-group.com/en/industry/products/liquid-coating/product/pilot-wa-700/?no_cache=1&cHash=b7a7568d31752bc98e88eb8b662d2bd1',
       breadcrumbs: ['Industry','Liquid coating','Applying','PILOT WA 700'] ,
       shortDescription:'Airspray automatic gun with internal control',
       description:'Simple, versatile and innovative!',
       image:'csm_00051113_0_9f3f0f76fa.jpg',
       pdf:'https://cdn.wagner-group.com/fileadmin/produkte/Industrie/Broschueren/Broschueren_Nass/Applizieren/BO_Airspray-Automatic_AME.pdf',
       
       technicalData:[
      ['Material pressure 8 bar',' 116 PSI'],
      ['Max. atomizer pressure  ','0,8 MPa, 8 bar, 116 PSI'],
      ['Material inlet  ','G 1/4“'],
      ['Control air connection  ','G 1/8“'],
      ['Atomizer air connection ','G 1/8“'],
      ['Operating temperature ','80 °C, 176.0 °F'],
      ['Weight ',' 729 g, 1.61 lb'],
      ['Max. sound level ',' 86 dB(A)'],
      ['Control type ',' Internal control']
       ]
       
       
    };
    
    
    
    
    
    
    
    var product_COBRA_4010AC = {
      breadcrumbs: ['Industry','Liquid coating','Feeding','Diaphragm Pumps'] ,        
      weburl:'https://www.wagner-group.com/en/contractor/product/cobra-40-10-ac/?tx_wproducts_product_detail%5Baction%5D=detail&tx_wproducts_product_detail%5Bcontroller%5D=Product&cHash=a696bb5c80b98d726619ae757437d115',                 
      slides:[
        {img:'csm_slideshow_Cobra_Holzbrett_ebb9b6562b.jpg', caption:'Quick,easy to handle - the best-seller'},
        {img:'csm_slideshow_Cobra_Schubladen_3a77cbf8be.jpg', caption:'Always a perfect finish'},
        {img:'csm_slideshow_AirCoat_Kubus_5_5f9f5da30c.jpg', caption:'Material-saving with little Overspray, small cross section and hopper.'},
        {img:'csm_slideshow_AirCoat_Fuellertuer_4_d05e025819.jpg', caption:'ENVIRONMENT-FRIENFDLY TECHNOLOGY. '}
      ],
      shortDescription:'The best-selling unit in the AirCoat range: To satisfy the most demanding coating needs',
      description: 'Flexible: Very small volumes can be handled using the hopper while other work can be performed directly from the original container<br>'+
//      'When used with the hopper: Frequent colour changes are no problem thanks to the unit\'s easy-to-clean design <br>'+
//      'Unique double diaphragm technology: Perfect for materials sensitive to shearing and moisture as well as for premixed 2K materials<br>'+
      'Suitable for use in potentially explosive atmospheres',
      
      image:'Produktbild_Cobra40-10.jpg',
      
      pdf:'https://cdn.wagner-group.com/fileadmin/produkte/1_Professional_Finishing/Doppelmembranpumpen_pneumatisch/1_PDF/ANW_Holz-_und_Metallbearbeitung_stationaer_2015_EN_small.pdf',
      
      technicalData:[
        ['ArtNr.:','0322112'],
        ['Pump ratio','40:1'],
        ['Volumetric flow per double stroke','10 cm3'],
        ['Volumetric flow (200 double strokes)','2.0 l/min'],
        ['Max. operating pressure','25 MPa'],
        ['Weight','23 kg']
      ]
 
    
    };
    
    
    var product_COBRA_4010 = {
      breadcrumbs: ['Industry','Liquid coating','Feeding','Diaphragm Pumps'] ,        
      weburl:'https://www.wagner-group.com/en/industrie/products/liquid-coating/product/?tx_wproducts_product_detail%5Bproduct%5D=944&tx_wproducts_product_detail%5Baction%5D=detail&tx_wproducts_product_detail%5Bcontroller%5D=Product&cHash=2be1302d8fbda7f35939ea9a0979a4d5',
      shortDescription:'High-pressure diaphragm pump',
      propertyicons:'material-icons-cobra_40_10.gif',
      description:'High-pressure, double diaphragm pump, Consistal. For AirCoat and Airless applications up to 2.5 l/min and 250 bar. Ideal for everything from the individual lacquer station to complex multi-paint systems.',
      
      image:'csm_00051113_0_9f3f0f76fa.jpg',
      pdf:'https://cdn.wagner-group.com/fileadmin/produkte/Industrie/Broschueren/Broschueren_Nass/Foerdern/BO_Cobra_AME_web.pdf',
        
       technicalData:[
          ['Multiplication ratio','40 :1'],
          ['Max. material pressure at pump inlet','20 bar, 290 PSI'],
          ['Material inlet ','M–M 36x2'],
          ['Material outlet','M–G 3/8‘‘'],
          ['Material temperature','10 - 80 °C, 50.0 - 176.0 °F'],
          ['Air inlet pressure','2,5 – 6,3 bar, 36 – 91 PSI'],
          ['Air inlet connection','F–G 1/2‘‘'],
          ['Operating pressure','250 bar, 3626 PSI'],
          ['Max. stroke rate ','200 DS/min'],
          ['Volumetric flow per double stroke ','25 cm³/DS, 1,53 in³/DH'],
          ['Ambient temperature ','10 – 60 °C, 50 – 140 °F'],
          ['Weight ','32,0 kg, 70.6 lb'],
          ['Max. sound level ','76 dB(A)'],
          ['Material pH','3,5 – 9,0 pH'],
          ['Min. air inlet Ø ','19 mm, 0.7 in.']   
       ], 
  
       
       bullets:[
         ['Material wetted parts',
           'Tungsten carbide','Stainless steel','Consistal','PA'],
         ['Included Items',
             'Cobra 40-10', 'Sign', 'Ground cable assy.', 'Double open-end wrench', 'CE declaration of conformity', 'User manual'],
         ['Ordering information',
           'Spraypack consisting of pump with frame, top tank, air regulator, hose set, and AirCoat gun',
           'The desired spraypack can be created using the basic pump and a selection from our comprehensive accessories range.'] 
        ]   
    };
    
    var epobData = {
      shortDescription:'',
      description: '',
      technicalData:[['Name', epob.name]], 
      breadcrumbs: ['&rang;'] ,        
      attributes:'',     
      attrib:''   
    };
    
    epobData = Ext.apply(epobData, epob);
    

    
    var dataKey ="superfinish23";
    if (epob.name.indexOf('SuperFinish')>-1){ dataKey ="superfinish23";  epobData = Ext.apply(epobData, product_SuperFinish23); }
    else if (epob.name.indexOf('Cobra 40-10 (AC)')>-1){  dataKey ="CobraAC";  epobData = Ext.apply(epobData, product_COBRA_4010AC); }
    else if (epob.name.indexOf('Cobra 40-10')>-1){  dataKey ="Cobra";  epobData = Ext.apply(epobData, product_COBRA_4010); }
    else if (epob.name.indexOf('PILOT')>-1){ dataKey ="PILOT"; epobData = Ext.apply(epobData, product_PILOT); }
    else if (epob.name.indexOf('SF-23')>-1){ dataKey ="SF-23"; epobData = Ext.apply(epobData, product_SF_23); }

    
    var breadcrumbsHTML='';
    var i;
    for (i =0; i < epobData.breadcrumbs.length ; i++){
      var crumb = epobData.breadcrumbs[i];
      breadcrumbsHTML+='<li><a href="#">'+crumb+'</a>';
      if (i!==epobData.breadcrumbs.length-1){
        breadcrumbsHTML+='/';
      }
      else if (epobData.weburl){
        breadcrumbsHTML+='<li><a href="'+epobData.weburl+'" target="_blank">&nbsp;&rang;</a>';
      }
      breadcrumbsHTML+='</li>';
    }
    
    
    var breadcrumb = {
     border:false, 
     margin:'20 0 0 40',
     html: '<section class="breadcrumbs xty_breadcrumbs-section"><ul>'+ breadcrumbsHTML + '</ul></section>'   
    };
    

    var propIcons = epobData.propertyicons ? '<img class="xty_view-panel-property-icons" src="./img/slides/'+epobData.propertyicons+'" style="width: 400px; position:absolute; margin-top:8px; left: 442px;" >' :'' ;
    
    var header = {border:false, html:  propIcons+'<h1 class="xty_view-header" >'+epobData.name+'</h1><h2 class="xty_view-subheader">'+epobData.shortDescription+'</h2>', margin:'20 0 40 40'};

    
    
  var technicalData  = Ext.create('Ext.data.ArrayStore', {
      storeId:'technicalDataStore',
      fields:['name', 'value', 'phone'],
      data: epobData.technicalData
  });
  var technicalDataGrid =  Ext.create('Ext.grid.Panel', {
      title: 'TECHNICAL DATA',
      cls:'xty_technical-data-grid',
      cellCls :'xty_view-panel-item-cell xty_technical-data-grid-bin', 
      viewConfig:{
        stripeRows: false
      },
      //preventHeader:true,
      hideHeaders : true,
      store: Ext.data.StoreManager.lookup('technicalDataStore'),
      columns: [
          { header: 'Name',  dataIndex: 'name' , flex : 0.5},
          { header: 'Value', dataIndex: 'value', flex : 0.5}
      ],
      colspan: 3, rowspan: 2,
      width: 400
  });
    

  
  
  var centerWidth =  extVia.regApp.myRaster.getCenter().getWidth();
  var slideWidth = centerWidth - 19;

  var slideshowHTML = '';
  var showSlides = false;
  if (epobData.slides){
    showSlides = true;
  var si; var slidesHTML ='';   var slideINPUTS =''; var slideCONTROLS ='';
  for (si =0; si < epobData.slides.length ; si++){
    //'<!-- die inputs um den Slider zu Steuern -->'+
    slideINPUTS+=
      '<input name="slider" id="slide0'+(si+1)+'" '+( si===0 ? ' checked="checked" ' : '' )+' type="radio">';
      slidesHTML+=
      '<li>'+
          '<figure>'+
              '<img src="./img/slides/'+epobData.slides[si].img+'" alt="" width="800" height="260">'+
              '<figcaption>'+epobData.slides[si].caption+'</figcaption>'+
          '</figure>'+
      '</li>' ;
      
      
    slideCONTROLS+=
      '<li><label for="slide0'+(si+1)+'">'+(si+1)+'</label></li>';
  }    

  slideshowHTML =
    //'<!-- zuerst das Sichtfenster -->'+
    '<section class="tabResult"><div class="cssSlider">'+
      slideINPUTS+
    //'<!-- die einzelnen Slides, hier als Liste angelegt -->'+
    '<ul class="sliderElements">';
 
  slideshowHTML+=slidesHTML;    
  
    slideshowHTML+=
  '</ul>'+
  //'<!-- Eine Steuerung -->'+
  '<div class="sliderControls-bin"><ul class="sliderControls">'+
    slideCONTROLS+
  '</ul></div>'+
'</div></section>';
  }
  
  var slideshow = {border:false, hidden: !showSlides, html:slideshowHTML,  margin:'20 0 0 0', height:340, width:slideWidth};
  
  
  
//////////////////////// --- bullets --- ///////////////////////
  var bulletsTpl = new Ext.XTemplate(
      '<ul class="xty_bullets" >',
        '<tpl for=".">',
            '<li class="xty_bullet">{.}</li>',        
        '</tpl>',
      '</ul>'
  );
  var bulletlistsHTML = '';
  if (epobData.bullets){ 
    var bi; 
    for (bi =0; bi < epobData.bullets.length ; bi++){
      bulletlistsHTML+=bulletsTpl.apply( epobData.bullets[bi] );
    }
  }
//////////////////////// --- eo bullets --- ///////////////////////

  
  
    var myContentPanelHeight =  extVia.regApp.myRaster.getWest().getHeight();
    
    var viewPanelCfg = {
      title: epob.dscr,
      itemId:epob.dscr,
      closable:true,
      
      cls:'xty_view-panel',
      bodyCls:'xty_view-panel-body',
      
      //height:myContentPanelHeight-28,
      height:myContentPanelHeight,
      autoScroll:true, 
      

      
      
      items:[
        // ✕      &#10005; &#x2715; 
        {xtype:'button', text:' ✕  ', cls:'xty_view-panel-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', style:'color: #e2e2e2; background-color:white;background:none; border:0px; position:absolute;right:0px;', handler:function(btn){btn.ownerCt.close();}},
        
        breadcrumb,
        
        slideshow,
        
        header,
        
        {
        height:1000,
//        height:myContentPanelHeight-28,
//        autoScroll:true, 
         
        border:false, 
        layout: {
            type: 'table',
            columns: 6
         },
         defaults: {
           border:false,
           cls:'xty_view-panel-item', 
           cellCls :'xty_view-panel-item-cell'
         },
         items: [
         {
            html: epobData.description,
            cls:'xty_view-panel-item xty_description',
            colspan: 3,
            width: 400
         },

         
        technicalDataGrid,
        
        
        {
          html:'<img class="xty_image" src="./img/slides/'+ ( epobData.image? epobData.image :'no-image-24.gif') +'" height="360" />',
          cls:'xty_view-panel-item xty_image-bin', 
          height:370, colspan: 3
        },
  
        
        { html:  bulletlistsHTML , margin:'40 0 0 40',  colspan: 6 },
        
        { xtype:'toolbar' , margin:'40 0 0 40', cls:'xty_view-panel-bbar', border:false, bodyBorder:false, height:36, colspan:6, items:['->',{href:epobData.pdf, overCls:'', pressedCls:'', width:24, margin:'0 6 0 0', iconCls:'xty_epobPDF', texxt:'pdf'}]}
        
        ]
         
        }
        
      ]
    };
                     
    

    
	  return viewPanelCfg;   

   },
   
   
   initProductViewsStore: function(cfg){ 

     if (!extVia.sharepoint.productViewsStore){
       //var productViewModel =  
         Ext.define('Sharepoint.model.ProductView', {
          extend: 'Ext.data.Model',
          fields: [
            {/*type: 'string',*/ name: 'id'} , 
            {/*type: 'string',*/ name: 'epobId'} ,
            
            {/*type: 'string',*/ name: 'name'} ,
            {/*type: 'array',*/  name: 'breadcrumbs'},  // ['String', 'String']        
            {/*type: 'string',*/ name: 'weburl'}, 
            {/*type: 'array',*/  name: 'slides'},  // Array with JSON-objects  [{img:'String', caption:'String'}],
            {/*type: 'string',*/ name: 'shortDescription'}, 
            {/*type: 'string',*/ name: 'propertyicons'}, 
            {/*type: 'string',*/ name: 'description'}, 
            {/*type: 'string',*/ name: 'image'}, 
            {/*type: 'string',*/ name: 'pdf'}, 
            {/*type: 'array',*/  name: 'technicalData'},  // 2-dimensional: [    ['String', 'String'] ,  ['String', 'String']    ]    
            {/*type: 'array',*/  name: 'breadcrumbs'},  // ['String', 'String']        
            {/*type: 'array',*/  name: 'bullets'}  // 2-dimensional: [    ['String', 'String'] ,  ['String', 'String']    ]   
          ]
       });
   
       
       Ext.define('Sharepoint.store.Products', {
         extend: 'Ext.data.Store',
         model:  'Sharepoint.model.ProductView',
         autoLoad: true,
         proxy: {
             type: 'ajax',
             url : './resources/productViews.json',
             reader: {
               type: 'json',
               root: ''
           }
         }
       });
       
       var productViewsStore =  Ext.create('Sharepoint.store.Products', { });
       var testStoreTask = new Ext.util.DelayedTask(function(){
         var totalCount = productViewsStore.getCount();
         //var record =   productViewsStore.getAt(0);   

         var testId = 'product_COBRA_4010';
         var record  = productViewsStore.findRecord('id', testId);
         
         //alert('productViewsStore count['+totalCount+'] \n id:['+ record.get('id')+'] \nbullets:'+   record.get('bullets') );
       });
       //testStoreTask.delay(1500);
       extVia.sharepoint.productViewsStore = productViewsStore;
     }
   },
   
   showViewPanel : function(cfg){ 

     if (!extVia.sharepoint.productViewsStore){
       extVia.sharepoint.view.statics.initProductViewsStore({});
     }
     
     var record = cfg.record;
     var epobTypeId = record.get('epobTypeId');
       if (!epobTypeId){  
         extVia.notify({action: 'Anzeigen (Click)'   , mssg:  'missing <i>'+record.get('text')+'</i> epobTypeId '}); 
       }
       if (epobTypeId !== extVia.module.epob.PRODUCTGROUP){  
         var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
         var viewPanelCfg = extVia.sharepoint.view.statics.getViewPanelCfg(cfg);
         var viewPanelTab = centerTabPan.addAndActivate(viewPanelCfg);
         
         if (centerTabPan.lastViewPanelTab && centerTabPan.lastViewPanelTab.id!==viewPanelTab.id){
           centerTabPan.lastViewPanelTab.close();
           centerTabPan.lastViewPanelTab = null;
         }
         centerTabPan.lastViewPanelTab = viewPanelTab;
       }
   }
   
   
   
   
	
 }
});
