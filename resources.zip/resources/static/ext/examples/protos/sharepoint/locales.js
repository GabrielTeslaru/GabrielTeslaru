Ext.namespace('extVia.locales' ,'extVia.sharepointProto.locales');
/**
 * @class extVia.sharepoint.locales
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/06/22 16:08:30 $
 *            $Revision: 1.1.2.2 $
 */

extVia.sharepointProto.locales = {
        appName:'sharepoint-proto',
};

Ext.apply(extVia.locales, extVia.sharepointProto.locales);



/*
 * 
 * $Revision: 1.1.2.2 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/06/22 16:08:30 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 