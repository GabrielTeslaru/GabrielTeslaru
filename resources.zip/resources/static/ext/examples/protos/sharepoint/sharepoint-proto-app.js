/*

*/
Ext.application({
    name: 'sharepoint-proto-app',
    appMode:{},

    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	extVia.regApp = this;
    	var  modulDscr = 'Sharepoint PIM Landing Page';
    	var epobDscr = 'Viamedici';
    	
    	var viewCfg = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true});
    	extVia.ui.page.raster.onReady(this);

    	var westTabPan = extVia.regApp.myRaster.initWestTabPanel({items:[extVia.hierarchy.statics.getHierarchyTabCfg({})]});    	
    	var westPan = extVia.hierarchy.statics.getHierarchyTabCfg({});
    	westPan.title = null;
    	extVia.regApp.myRaster.addToWest(westPan);

      var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel({cls:'xty_invisiblebar-tab-panel'});
      extVia.regApp.centerTabPan = centerTabPan;
      extVia.regApp.myRaster.addToCenter(centerTabPan);
    	
      var appheader = { border:false, html:'<h1 class="xty_view-header" >Sharepoint PIM Landing Page</h1><h2 class="xty_view-subheader">Viamedici</h2>', margin:'50 40 40 40'};
	    var appPanel = {
	    defaults:{
        margin:'24 24 24 24'
	    },             
	     items:[ appheader  ] 
	    };
	    centerTabPan.add(appPanel);
    }
});