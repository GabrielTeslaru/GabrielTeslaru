
Ext.define('extVia.hierarchy.statics', {
    statics: {

 
   showExplorerPanel : function(cfg, epob){
     extVia.notify({action: 'Öffnen (Doppelclick)'  , mssg:  'Explorer <i>'+epob.dscr+'</i> '}); 
   },
      
  getHierarchyTabCfg : function(cfg){
	  

	  var myContentPanelHeight =  extVia.regApp.myRaster.getWest().getHeight() ;

    
      var listenersCfg = {   
        
	        itemcontextmenu: function( view, record, item, index, evt, eOpts ){
	          evt.preventDefault();
            
	          var breadcrumb = record.getPath('text'); 
            
	          var epob = {
	            dscr:record.get('text'),
	            epobId:  record.get('epobId'),
	            epobTypeId :  record.get('epobTypeId'),
	            breadcrumb: breadcrumb
	          };
	
	          var hierachiesMenu = Ext.create('Ext.menu.Menu', {
	            //width: 100,
	            //height: 100,
	            margin: '0 0 10 0',
	            items: [{
	            text: '&Auml;ndern', iconCls:'x-tool x-tool-edit',
                handler:function(){

                } 
	            }

	            ]
	        });  
	        hierachiesMenu.showAt(evt.getXY());
	        },
	        
	       
	        itemclick: function( view, record, item, index, evt, eOpts ){
	        //itemdblclick: function( view, record, item, index, evt, eOpts ){
	          extVia.sharepoint.view.statics.showViewPanel({record:record});
	        } 
        };
    
      Ext.define('Epob', {
        extend: 'Ext.data.Model',
        fields: [{type: 'string', name: 'text'},{type: 'string', name: 'dscr'},{type: 'number', name: 'epobTypeId'},{type: 'string', name: 'epobId'}]
      });
      
      
      
//      var resultTree =  Ext.getCmp(Ext.get('oTreeQueryResult-body').dom.firstChild.id);
//      var recordsStr='';
//      resultTree.getStore().each(function(record){ recordsStr+='{ text:"'+record.data.text+'", epobTypeId:"'+record.data.id.substring(0,2)+'", epobId:"'+record.data.id+'", parentId:"'+record.data.parentId+'"},\n' });
//      Ext.getCmp('mainEastTab').add({xtype:'textarea', value:recordsStr, width:400, height:200});      
      
      
      
      
      
     var PRODUCTGROUP =  extVia.module.epob.PRODUCTGROUP;
     var PRODUCT =  extVia.module.epob.PRODUCT;
     var PRODUCTVARIANT =  extVia.module.epob.PRODUCTVARIANT;
      
      
      
      var productsStore = Ext.create('Ext.data.TreeStore', {
      storeId:'productsTreeStore',
      model: 'Epob',
      root: {
        text: 'Hierarchien',
        iconCls:'xty_epobHierarchyies',
        expanded: true,


               
children: [
  {
     text: "Product Hierarchy", 
     epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
     epobId:  "PG16117",
     children: [
      {
         text: "Decorative Finishing",
         epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
         epobId:  "PG17101",
         "children": [
           {
             "text": "Architectural Coating",
              epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
              epobId: "PG17102",
             "children": [
               {
                 "text": "Building Trade",
                  epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                  epobId: "PG17103",
                 "children": [
                   {
                     "text": "Diaphragm Pumps elec.",
                      epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                      epobId: "PG17104",
                     "children": [
                       {
                         "text": "SuperFinish 23Plus",
                          epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                          epobId: "PG17108",
                         "children": [
                           {
                             "text": "Basic Products",
                              epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup  xty_hasDummy', expanded: true,
                              epobId: "PG17109",
                             "children": [
                               {
                                 "text": "SuperFinish 23 Plus (AL) Emulsion",
                                  epobTypeId: PRODUCT, iconCls:'xty_epobProduct  xty_hasDummy ',
                                  epobId: "PP31330a", id: "PP31330a",
                                  leaf: true
                               },
                               {
                                 "text": "SF-23i 230V/50Hz Injektion EUR",
                                  epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                  epobId: "PP31330",
                                  leaf: true
                               },
                               {
                                 "text": "SF-23 Plus 110V/50Hz Gestell (GB)",
                                  epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                  epobId: "PP31328",
                                  leaf: true
                               },
                               {
                                 "text": "SF-23 Plus 110V/50Hz Wagen (GB)",
                                  epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                  epobId: "PP31329",
                                  leaf: true
                               },
                               {
                                 "text": "SF-23 Plus 230V/50Hz Grundger. Wagen",
                                  epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                  epobId: "PP31326",
                                  leaf: true
                               },
                               {
                                 "text": "SF-23 Plus 230V/50Hz Grundgerät, Gestell", 
                                  epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                  epobId: "PP31327",
                                  leaf: true
                               }
                             ]
                           },
                           {
                             "text": "Spray Packs",
                              epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup',
                              epobId: "PG17110",
                              children: []
                           }
                         ]
                       }
                     ]
                   }
                 ]
               }
             ]
           }
         ]        
      },
      {
         text: "Industrial Solution",
         epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup  xty_hasDummy', expanded: true,
         epobId:  "PG16118",
         children: [
          {
             text: "Liquid Coating", 
             epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup  xty_hasDummy', expanded: true,
             epobId:  "PG16310",
             children: [
              {
                 text: "Accessory", 
                 epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup', children:[],
                 epobId:  "PG16548"
              },
              {
                 text: "Applying",
                 epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                 epobId:  "PG16434",
                 children:[                   
                   {
                     text: "Air Spray Automatic Gun", 
                     epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup  xty_hasDummy', expanded: true,
                     children:[
                       {
                         text: "PILOT WA 7xx", leaf: false,
                         epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup  xty_hasDummy', expanded: true,
                         children:[
                           {text: "PILOT WA 700 ", epobId:  "PG_PILOT_WA_700-03", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct xty_hasDummy' },
                           {text: "PILOT WA 700 0,5mm ZWK", epobId:  "PG_PILOT_WA_700-05", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct' },
                           {text: "PILOT WA 700 0,8mm ZWK", epobId:  "PG_PILOT_WA_700-08", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct' },
                           {text: "PILOT WA 700 1,0mm ZWK", epobId:  "PG_PILOT_WA_700-10", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct' },
                           {text: "PILOT WA 700 1,2mm ZWK", epobId:  "PG_PILOT_WA_700-12", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct' },
                           {text: "PILOT WA 700 1,4mm ZWK", epobId:  "PG_PILOT_WA_700-14", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct' },                           
                           {text: "PILOT WA 700 1,5mm ZWK", epobId:  "PG_PILOT_WA_700-15", leaf: true, epobTypeId: PRODUCT, iconCls:'xty_epobProduct' }
                         ],
                         epobId:  "PG_PILOT_WA_4xx"
                      }
                     ],
                     epobId:  "PG_Air_Spray_Automatic_Gun"
                  }
                 ]
              },
              {
                text: "Control",
                epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup', children:[],
                epobId:  "PG_Control_ufo"
              },
              {
                 text: "Feeding",
                 epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                 epobId:  "PG16311",
                 children: [
                  {
                     text: "Diaphragm Pumps",
                     epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                     epobId:  "PG16366",                    
                     children: [
                      {
                         text: "Cobra 40-10", 
                         epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                         epobId:  "PG16367",                        
                         children: [
                          {
                             text: "Basic Products",
                             epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true,
                             epobId:  "PG16368",
                             children: [

                             {
                                 text: "Cobra 40-10 (AC)",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct xty_hasDummy', expanded: true,
                                 epobId:  "Cobra_40_10_AC",
                                 leaf: true
                              },  
                               
                              {
                                 text: "Cobra 40-10",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct xty_hasDummy xty_open-on-start-node', expanded: true,
                                 epobId:  "PP27674",
                                 leaf: true
                              },
                              {
                                 text: "DiaphragmP.Cobra 40-10 frame",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27675",
                                 leaf: true
                              }
                            ]
                          },
                          {
                             text: "Spray Packs",
                             epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup',
                             epobId:  "PG16369",
                             children: [
                              {
                                 text: "SP Cobra 40-10 GM4700 trolley cup",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27679",
                                 leaf: true
                              },
                              {
                                 text: "SP cobra 40-10 GM4700AC/base frame",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27676",
                                 leaf: true
                              },
                              {
                                 text: "SP Cobra 40-10 trolley cup",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27678",
                                 leaf: true
                              },
                              {
                                 text: "Spraypack cobra 40-10 GM4100/base frame",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27677",
                                 leaf: true
                              }
                            ]
                          }
                        ]
                      },
                      {
                         text: "Cobra 40-25",
                         epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup',
                         epobId:  "PG16370",                        
                         children: [
                          {
                             text: "Basic Products",
                             epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup',
                             epobId:  "PG16371",
                             children: [
                              {
                                 text: "Cobra 40-25",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27680",
                                 leaf: true
                              }
                            ]
                          },
                          {
                             text: "Spray Packs",
                             epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup',
                             epobId:  "PG16372",
                             children: [
                              {
                                 text: "DiaphragmP.Cobra 40-25 frame",
                                 epobTypeId: PRODUCT, iconCls:'xty_epobProduct',
                                 epobId:  "PP27681",
                                 leaf: true
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              {
                 text: "Service Sets",
                 epobTypeId: PRODUCTGROUP, iconCls:'xty_epobProductgroup',
                 epobId:  "PG16791",
                 children:[]
              }
            ]
          },

          
          {
            "text": "Powder Coating",
             epobTypeId: PRODUCTGROUP,
            "epobId": "PG16119",
             iconCls: "xty_epobProductgroup ",
            "children": [
              {
                "text": "Accessory",
                 epobTypeId: PRODUCTGROUP,
                "epobId": "PG16245",
                 iconCls: "xty_epobProductgroup ", 
                "children": [
                  {
                    "text": "Nozzles And Atomizers",
                     epobTypeId: PRODUCTGROUP,
                    "epobId": "PG16267",
                     iconCls: "xty_epobProductgroup ",
                    "children": [
                      {
                        "text": "Finger Nozzles",
                         epobTypeId: PRODUCTGROUP,
                        "epobId": "PG16271",
                         iconCls: "xty_epobProductgroup ", 
                        "children": [
                          {
                            "text": "Adapter finger nozzle 10-fach",
                             epobTypeId: PRODUCT,
                             leaf: true,
                            "epobId": "PP27238",
                             iconCls: "xty_epobProduct "
                          },
                          {
                            "text": "Finger nozzle 10x",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27234",
                             iconCls: "xty_epobProduct"
                          },
                          {
                            "text": "Finger nozzle 16x",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27236",
                             iconCls: "xty_epobProduct"
                          },
                          {
                            "text": "Finger Nozzle 16x crosswise",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27237",
                             iconCls: "xty_epobProduct"
                          },
                          {
                            "text": "Nozzle D10",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27235",
                             iconCls: "xty_epobProduct"
                          },
                          {
                            "text": "Nozzle D8",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27239",
                             iconCls: "xty_epobProduct"
                          },
                          {
                            "text": "Powder shower",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27241",
                             iconCls: "xty_epobProduct"
                          },
                          {
                            "text": "Round Nozzle",
                             epobTypeId: PRODUCT,leaf: true,
                            "epobId": "PP27240",
                             iconCls: "xty_epobProduct"
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }

          
        ]
      }
    ]
  }
  
  
                  
           ]
         

      
      
      
      }
      });
    
	  var productsTreePan = Ext.create('Ext.tree.Panel', {
	    	region:'center',
	    	cls:'xty_hierarchy-tree-panel',
	    	rootVisible: false,
	    	store: productsStore,
	    	border: false,
	    	height: myContentPanelHeight-28,
	    	bodyBorder:false,
	      preventHeader: true,
	        header: false,
	        hideHeader: true,
//	        viewConfig: {
//	            plugins: {
//	                ptype: 'treeviewdragdrop'
//	            }
//	        },
	        useArrows: true,
		    listeners: listenersCfg	,
		    
		    
// >>>>>>>>>>>>>>>> filter Func Start <<<<<<<<<<<<<<<<<<<<< //                  
// Copied from  extjs4-treefilter.js   https://gist.github.com/colinramsay/1789536 07.07.2015       
          filterByText: function(text) {
           this.filterBy(text, 'epobId');
          },
          /**
           * Filter the tree on a string, hiding all nodes expect those which match and their parents.
           * @param The term to filter on.
           * @param The field to filter on (i.e. 'text').
           */
          filterBy: function(text, by) {
              this.clearFilter();
              if(Ext.isEmpty(text)) {
                return;
              }
              var view = this.getView(),
                  me = this,
                  nodesAndParents = [];
              // Find the nodes which match the search term, expand them.
              // Then add them and their parents to nodesAndParents.
              this.getRootNode().cascadeBy(function(tree, view){
                  var currNode = this;
                  if(currNode && !currNode.isLeaf() && currNode.data[by] && currNode.data[by].toString().toLowerCase().indexOf(text.toLowerCase()) > -1) {
                      me.expandPath(currNode.getPath());
                      while(currNode.parentNode) {
                          nodesAndParents.push(currNode.id);
                          currNode = currNode.parentNode;
                      }
                  }
              }, null, [me, view]);
              // Hide all of the nodes which aren't in nodesAndParents
              this.getRootNode().cascadeBy(function(tree, view){
                  var uiNode = view.getNodeByRecord(this);
                  if(uiNode && !Ext.Array.contains(nodesAndParents, this.id)) {
                      Ext.get(uiNode).setDisplayed('none');
                  }
              }, null, [me, view]);
          },
          clearFilter: function() {
              var view = this.getView();
              this.getRootNode().cascadeBy(function(tree, treeView){
                var node = this,
                  nodeView;
                  nodeView = treeView.getNode(node);       
                  if(!Ext.isEmpty(nodeView)) {
                    new Ext.Element(nodeView).setDisplayed('table-row');
                  }
              }, null, [this, view]);
          }  
// >>>>>>>>>>>>>>>> filter Func Ende  <<<<<<<<<<<<<<<<<<<<< //   

	    });
	  

	  

	   var hierarchyTabCfg = 	
	     {title: 'Produkthierarchien',
	     //id : 'hierarchy',// leads to problems in ext 4.2 
	     itemId : 'hierarchy',
	     cls:'xty_hierarchy-tree',
		   ///height: myContentPanelHeight,

		   
	        //layout:'border', // leads to problems in ext 4.2 
    	    
	        tbar:{cls:'xty_hierarchy-tree-tbar', 
    	   
    	     items:['->',
    	    // {iconCls:'x-tool x-tool-left'},
    	   
    	     {xtype:'tbspacer', height:22},
        
    	     { xtype: 'triggerfield', 
    	     hidden:true,
           name: 'hierarchiesTreefilter', 
           cls:'xty_panelheader-field xty_has-insidetrigger', trigger2Cls:'xty_form-trigger-searchable',  trigger1Cls:'xty_inside-trigger-clear', 
           onTrigger1Click: function(evt){
             var targetEl = Ext.get(evt.target.id); 
             var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
             var field = Ext.getCmp(fieldId);
             if (field.isDirty()){field.setValue('');}
            },
           enableKeyEvents:true,
           listeners:{
            keydown:function(field, evt){
             if (evt.getKey()===Ext.EventObject.DELETE){
              field.setValue(''); 
             }
            }, 
            change:function( field, newValue, oldValue ){
             var delayedFilterTask = new Ext.util.DelayedTask(function(){
                //var productsTreePanel = field.ownerCt.getComponent('categoriesTreePanel');
                productsTreePan.filterBy(newValue, 'epobId');
            });
             delayedFilterTask.delay(500);
            }
           }
         }   
    	   

    	   
    	   ]
	     },
	     
	     
       listeners:{
         afterrender:function(treepanel){
           var task = new Ext.util.DelayedTask(function(){
             //var node = productsStore.getNodeById('PP31330a');
             var openOnStartNodesArr =  Ext.query('.xty_hierarchy-tree-panel .xty_open-on-start-node');
             if (openOnStartNodesArr){
               var openOnStartNode = openOnStartNodesArr[0];
               var openOnStartNodeEl = Ext.get(openOnStartNode); 
               var openOnStartNodeDomEl = document.getElementById(openOnStartNodeEl.id);
               document.getElementById(openOnStartNodeEl.id).parentNode.click();
             }
           });
           //task.delay(100);  
         }
	     },
	     
	  items:[ productsTreePan ]};
	   
	  return hierarchyTabCfg;   

   }
	
    }
});
