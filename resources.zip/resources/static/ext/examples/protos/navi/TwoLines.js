

/**
 * @author aweber@viamedici.de (Adrian Weber)
 * @docauthor aweber@viamedici.de (Adrian Weber)
 * 
 * TODO: Write documentation.
 */
Ext.define('extVia.nav.TwoLines', {
	extend: 'Ext.panel.Panel',
	cls: 'xty_navi-twolines',
	border: false,
	height : 100,
	width : '100%',
	
	/**
	 * @cfg {String} thridLevelType
	 */
	thridLevelType : 'inline',
	
	isInline : function() {
		return this.thridLevelType === 'inline';
	},
	
	isSidebar : function() {
		return this.thridLevelType === 'sidebar';
	},
	
	//@private
	initComponent: function() {
		var me = this,
			root = Ext.data.StoreManager.lookup('navigationStore').getRootNode(),
			tabPan = this.tabPan,
			i;
			
		me.callParent(arguments);
		
		if (location.href.indexOf('whereami')){
          var qStr = location.href.replace(/.[^\?]*\?/,'');
          var urlParams = Ext.Object.fromQueryString(qStr);
          me.firstLevelItem = urlParams.whereami;
          extVia.regApp.myRaster.getNorth().setHeight(36);
        }
		
		me.createFirstLine(root);
		
		me.firstLine.add('->');
		for(i = 0; i < me.menubarItems.length; ++i) {
			me.firstLine.add(me.menubarItems[i]);
		}
	
		
		me.createSecondLine();
		
		
        
        if(!Ext.isEmpty(localStorage.getItem('tl_target'))) {
        	var target = localStorage.getItem('tl_target');
        	var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Men�eintrag', epobDscr:target} );
        	tabPan.add({xtype:'panel',frame:false,border:false, tbar :appbar, items:[{
        		border : false,
        		html:'<div style="margin:0 auto;padding:20px;text-align:center;width:100%;font-size:2em;text.align:center;color:#444;">' +
        				'Sie haben <i>' + target + '</i> erreicht!' +
        			  '</div>', margin:'24 24 24 24',
        	 		  padding:20}], 
        	    title : 'Navigationsziel'
        	 });
        }
	},
	
	createFirstLine: function(root) {
		var me = this,
			items = [];
		
        //var firstLevelItem;
        
      
      
      	items.push(me.createItem(root));
		root.eachChild(function(child){
            var item = me.createItem(child);
            if (item.text === me.firstLevelItem){
              item.cls='xty_navi-iamhere';
            }
			items.push(item);
		});
		

    
		me.firstLine = Ext.create('Ext.toolbar.Toolbar', {
			componentCls : 'xty_navi-container xty_navi-twolines-firstline',
			items : items,
			defaults : {
				pressedCls : 'menu-button-pressed',
				overCls : 'menu-button-over',
				cls : 'xty_menu-button'
			}
			
		});
		me.add(me.firstLine);
	},
	
	createSecondLine: function() {
		var me = this;
		
		me.secondLine = Ext.create('Ext.toolbar.Toolbar', {
			hidden: true,
			width : '100%',
			height: 35,
			componentCls: 'xty_navi-container xty_navi-twolines-secondline',
			listeners : {
				beforeadd : function(tbar, cmp) {
					if(cmp.text && cmp.text.indexOf('-') >= 0 
						 && (cmp.text.indexOf('XML-') < 0 || cmp.text.indexOf('CSV-') <0) ) {
						cmp.text = cmp.text.replace('-', '');
					}
				}
			}
		});
		me.add(me.secondLine);
	},
	
	createItem : function(node, secondLine) {
		var me = this,
			config = {
				xtype : 'button',
				node : node,
				text : node.get('text'),
				id : node.id,
				listeners : {scope: me}
			};
	
		if(node.isRoot()) {
			config.listeners.click = me.hideSecondLine;
			config.iconCls = node.get('iconCls');
			config.cls = 'xty_navi-home';
		} else if(secondLine){
			config.overCls = 'xty_navi-twolines-item-over';
			if(node.isLeaf()) {
				config.listeners.click = function(item) {
                    var href = location.href.replace(/\&whereami.*/,'')
					location.href = href+'&whereami='+me.lastFirstLineOverItem.text;
					localStorage.setItem('tl_target', item.getText());
				};
			} else {
				config.listeners.click = me.showThirdLevel;
			}
		} else {
			config.listeners.click = me.toggleSecondLine;
			//config.listeners.mouseover = me.onMouseOver;
			config.listeners.afterrender = function(item) {
				item.getEl().on('mousemove', me.onMouseOver, me);
			}
			config.listeners.mouseover = function(item) {
				me.overItem = item;
			}
		}
		
		if(!node.isRoot() && !node.isLeaf()) {
			config.xtype = 'splitbutton';
		}
		
		return config;
	},
	
	hideSecondLine: function() {
		this.north.setHeight(35);
		this.secondLine.hide();
		this.clearSelection();
	},
	
	onMouseOver : function(e, item) {
		var me = this,
			selection;
		
		
		selection = me.getSelection();
		
		if(!Ext.isEmpty(selection) && !selection.node.isRoot()
		&& me.mustTrigger(item, e)) {
			me.toggleSecondLine(me.overItem, true);
		}
	},
	
	
	mustTrigger : function(item, e) {
		item = new Ext.Element(item);
		var me = this,
			itemX = item.getXY()[0],
			itemY = item.getXY()[1],
			eX = e.getXY()[0],
			eY = e.getXY()[1],
			length,
			height,
			offsetX = item.getWidth() * 0.22,
			offsetY = 13;
			
		length = item.getWidth() + itemX;
		height = item.getHeight(); + itemY;
		

		return ((eX > (itemX + offsetX)) && (eX < (length - offsetX)) 
			&& (eY < (itemY + offsetY)));
	},
	
	
	toggleSecondLine: function(item, noSelect) {
		var me = this,
			node = item.node,
			inline,
			subItem;
			
		if(me.lastFirstLineOverItem) {
				me.lastFirstLineOverItem.removeCls('xty_moused-over');
		}
		item.addCls('xty_moused-over');
		me.lastFirstLineOverItem = item;
			
		if(noSelect !== true) {
			if(item === me.getSelection()) {
				me.hideSecondLine();
				return;
			}
			me.selectItem(item);
		}
		
		me.resetSecondLine();
		node.eachChild(function(child){
			subItem = me.createItem(child, true);
			me.secondLine.add(subItem);
			if(me.isInline() && !child.isLeaf()) {
				inline = me.createInline(child);
				me.secondLine.add(inline);
				subItem.inline = inline;
			}
		});
		
		me.north.setHeight(75);
		me.secondLine.show();
	},
	
	widthOffset : 18,
	
	calcWidth : function(text) {
		return (Ext.util.TextMetrics.measure(Ext.getBody(), text).width + this.widthOffset);
	},
	
	createInline : function(node) {
		var me = this,
			width = 0,
			items = [],
			text = node.get('text'),
			inline;

		items.push({
			xtype : 'button',
			text : text,
			parent : true,
			overCls : 'xty_navi-twolines-item-over',
			componentCls : 'xty_navi-twolines-secondline-active',
			handler : function(item) {
				me.slideOutInline(item.up());
				if(!Ext.isEmpty(me.hidedItem)){
					me.hidedItem.show();
					me.hidedItem = null;
				}
			}
		});
		width += me.calcWidth(text);
		node.eachChild(function(child){
			text = child.get('text');
			items.push({
				xtype : 'button',
				overCls : 'xty_navi-twolines-item-over',
				text : text
			});
			width += me.calcWidth(text);
		});
		
		width += 10;
		
		inline =  Ext.create('Ext.toolbar.Toolbar', {
			height: 30,
			padding : 2,
			width : width,
			calcWidth : width,
			componentCls : 'xty_navi-twolines-thirdline',
			items : items,
			hidden : true,
			defaults : {
				listeners : {
					scope: me,
					click : function(item) {
						if(!item.parent) {
							var href = location.href.replace(/\&whereami.*/,'')
							location.href = href+'&whereami='+me.lastFirstLineOverItem.text;
							localStorage.setItem('tl_target', item.getText());
						}
					}
				}
			},
			listeners : {
				beforeadd : function(tbar, cmp) {
						if(cmp.text && cmp.text.indexOf('-') >= 0 
							 && (cmp.text.indexOf('XML-') < 0 && cmp.text.indexOf('DTD-') < 0 && cmp.text.indexOf('CSV-') <0) ) {
							cmp.text = cmp.text.replace('-', '');
						}
					}
			}
		});
		
		return inline;
	},
	
	
	secondSelection : null,
	
	showThirdLevel: function(item) {
		var me = this,
			inline;
			
		item.up().addCls('xty_navi-secondline-childs-expanded');
		
		if(me.isInline()) {
			if(me.secondSelection) {
				me.secondSelection.toggle();	
			}
			item.toggle();
			me.secondSelection = item;
			if(!Ext.isEmpty(item.initialConfig.inline)) {
				inline = item.initialConfig.inline;
				if(inline.getWidth() <= 0) {
					me.slideInInline(inline);
				}else {
					me.slideOutInline(inline);
				}
				item.hide();
				if(!Ext.isEmpty(me.hidedItem)) {
					me.hidedItem.show();
				}
				me.hidedItem = item;
			} else {
				if(!Ext.isEmpty(me.hidedItem)){
					me.hidedItem.show();
					me.hidedItem = null;
				}
				if(!Ext.isEmpty(me.visibleInline)) {
					me.slideOutInline(me.visibleInline);
				}
				
			}
		}
	},
	
	task : null,
	
	createFadeoutTask : function(inline, callback) {
		var task,
			me = this;
			
		task =  {
			interval : 10,
			run : function() {
				if(inline.getWidth() <= 0) {
					inline.setWidth(0);
					clearInterval(me.getTask(inline.getId()));
					if(Ext.isFunction(callback)) {
						callback();
					}
				}
				inline.setWidth(inline.getWidth() - 8);
			}
		};
		
		return task;
	},
	
	createFadeinTask : function(inline) {
		var task,
			me = this;
			
		task =  {
			interval : 10,
			run : function() {
				if(inline.getWidth() >= inline.calcWidth) {
					clearInterval(me.getTask(inline.getId()));
				}
				inline.setWidth(inline.getWidth() + 8);
			}
		};
		
		return task;
	},
	
	tasks : {},
	
	registerTask : function(id, task) {
		this.tasks[id] = task;
		return task;
	},
	
	getTask : function(id) {
		return this.tasks[id];
	},
	
	slideInInline : function(inline) {
		var me = this,
			task,
			visibleInline;
		
		visibleInline = me.visibleInline;
			
		if(!Ext.isEmpty(visibleInline)) {
			me.slideOutInline(visibleInline, function(){me.slideInInline(inline);});
		} else {
			me.visibleInline = inline;
			inline.setWidth(0);
			inline.show();
			me.registerTask(inline.getId(), setInterval(function(){
				if(inline.getWidth() >= inline.calcWidth) {
					clearInterval(me.getTask(inline.getId()));
				}
				inline.setWidth(inline.getWidth() + 8);
			}, 10));
		}
	},
	
	slideOutInline : function(inline, callback) {
		var me = this,
			task;
			
		if(inline !== me.visibleInline) {
			console.error('The elemnt is not the same.', inline);
		}
		me.registerTask(inline.getId(), setInterval(function(){
			if(inline.getWidth() - 10 <= 0) {
				inline.setWidth(0);
				inline.hide();
				me.visibleInline = null;
				clearInterval(me.getTask(inline.getId()));
				if(Ext.isFunction(callback)) {
					callback();
				}
			}
			inline.setWidth(inline.getWidth() - 8);
		}, 10));
	},
	
	resetSecondLine : function() {
		var me = this;
		
		me.secondLine.removeAll();
		
		Ext.Object.each(me.tasks, function(key, task){
			clearInterval(task);
		});
		me.tasks = {};
		
		me.visibleInline = null;
		me.animationActive = false;
		me.secondSelection = null;
	},
	
	animationActive : false,
	
	
	
	selectItem : function(item) {
		var me =this;
		
		if(me.selection) {
			me.selection.toggle();
		}
		item.toggle();
		me.selection = item;
	},
	
	clearSelection: function() {
		var me = this;
		
		if(me.getSelection()) {
			me.getSelection().toggle();
			me.selection = null;
		}
	},
	
	getSelection: function() {
		return this.selection;
	}
});