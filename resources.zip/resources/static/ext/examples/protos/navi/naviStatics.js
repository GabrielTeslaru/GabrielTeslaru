/**
 * @class extVia.navi.staticrs
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2016/03/14 16:05:20 $
 *            $Revision: 1.18 $
 */
Ext.define('extVia.navi.statics', {
    statics: {

 
    getMenuCfg : function(cfg){
	    var menuCfg = {};
	    return menuCfg;
    },
    
    renderText : function(text) {
    	if(text.indexOf('-') >= 0 && text.indexOf('XML-') < 0 
    		&& text.indexOf('DTD-') < 0 && text.indexOf('CSV-') < 0) {
    		return text.replace('-', '');
    	}
    	return text;
    },
      

    getHomeButtonCfg : function(cfg){
      var me = this;
      

      var subVerti =  location.href.indexOf('palettehorizontal')==-1;
      
      var tbsep = {xtype:'tbseparator' };
      var tbsep2 = {xtype:'tbseparator', width:4, hidden: subVerti};
      var tbsep3 = {xtype:'tbseparator', width:4};
      
      //var subVerti = cfg.subVerti;
      
       var buttCfg =  { xtype:'button', itemId:'home', hidden:true,
                         iconCls:'xty_viaMenubar-home', cls:'xty_viaMenubar xty_viaMenu-level-1',
                        
                         handler: function(button){
                          	parent.activePalett = button.showMenu(button,{x:30, srcButton:button});
                          
                         },
                         
                         height:470,
                         
                         showMenu:function( button, cfg){ 
                         	
                         	
                         var paletteNoBtnGrp = true;
                         	
                         if(paletteNoBtnGrp) {
                         	
                          var treeStore = Ext.data.StoreManager.lookup('navigationStore'),
                          	  items = [],
                          	  title = cfg.srcButton.text,
                          	  i = 0,
                          	  columns = 3,
                          	  position = cfg.srcButton.getPosition(),
                          	  srcButton = cfg.srcButton;
                          	
                          position[0] += 10;
                          position[1] += 40;
                          
                          if(Ext.isEmpty(treeStore)) {
                          	treeStore = Ext.create('ExtVia.data.NavigationTreeStore');
                          }	
                          
                          items.push({
                          	xtype : 'tbtext',
                          	cls : 'xty_palette-title',
                          	colspan : columns,
                          	text : title,
                          	width : '100%',
                          	height : 30
                          });
                          
                          createThirdLevel = function() {
                          		return {
                          			xtype : 'toolbar',
                          			baseCls : 'xty_palette-subitem-container',
                         			colspan : columns,
                         			listeners : {
	                         			beforeadd : function(tbar, button) {
	                         				if(button.text && button.text.indexOf("-") >= 0) {
	                         					button.text = button.text.replace('-', '-<br />');
	                         				}
	                         			}
	                         		},
	                         		moveArrow : function(index) {
	                         			var parent = this.up(),
	                         				position = index + 1;
	                         				
	                         			switch(position % 3) {
	                         				case 1:
	                         				 	parent.removeCls('arrow-center');
	                         				 	parent.removeCls('arrow-right');
	                         				 	parent.addCls('arrow-left');
	                         					break;
	                         				case 2: 
	                         					parent.removeCls('arrow-left');
	                         				 	parent.removeCls('arrow-right');
	                         				 	parent.addCls('arrow-center');
	                         					break;
	                         				case 0:
	                         					parent.removeCls('arrow-center');
	                         				 	parent.removeCls('arrow-left');
	                         				 	parent.addCls('arrow-right');
	                         					break;
	                         			}
	                         		
	                         		},
                         			width : '100%',
                         			hidden : true,
                         			defaults : {
                         				scale : 'medium',
                         				width : 80,
                         				height: 40
                         			},
                         			layout : {
                         				type : 'table',
                         				columns : columns
                         			}
                      			};
                          };
          
                          var xtype = 'button';
                          treeStore.getRootNode().eachChild(function(root){
                          	root.eachChild(function(child) {
                          		cls = 'xty_palette-item';
	                          	if(root.get('text') === title) {
	                          		var childItems = [];
	                          		var cls ="xty_palette-item";
	                          		if(!child.isLeaf()) {
	                          			child.eachChild(function(c){
	                          				childItems.push({
	                          					text: c.get('text'),
	                          					cls : 'xty_palette-subitem',
	                          					overCls : 'xty_palette-subitem-over',
	                          					iconAlign : 'left',
	                          					iconCls : c.get('iconCls'),
	                          					handler : function(item) {
//	                          						if(c.isLeaf()) {
//			                          					var centerTabs = extVia.regApp.myRaster.getCenterTabPanel();
//			                          				 	centerTabs.removeAll();
//			                          				 	centerTabs.add({
//			                          				 		title : 'Navigationsziel',
//			                          				 		border: false,
//			                          				 		frame : false,
//			                          				 		tbar : extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Men�eintrag', epobDscr: me.renderText(c.get('text'))}),
//			                          				 		items : [{
//			                          				 			border : false,
//			                          				 			padding : 20,
//			                          				 			html : '<div style="margin:0 auto;padding:20px;text-align:center;width:100%;font-size:2em;text.align:center;color:#444;">' +
//			                          				 					'Sie haben <i>' +  me.renderText(c.get('text')) + '</i> erreicht!' +
//		        			  											'</div>', margin:'24 24 24 24'
//			                          				 		}]
//			                          				 	});
//			                          				}
//			                          				item.up('menu').hide();
	                          						if(c.isLeaf()) {
	                          						var href = location.href.replace(/\&whereami.*/,'')
													location.href = href;//+'&whereami='+me.lastFirstLineOverItem.text;
													localStorage.setItem('pl_target', item.getText());
													}
	                          					}
	                          				});
	                          			});
	                          			cls += ' xty_palette-hasitems';
	                          			//xtype = 'splitbutton';
	                          		} else {
	                          			//xtype = 'button';
	                          		}
	                          		if(i !== 0 && i % columns == 0) {
	                          			items.push(createThirdLevel());
	                          		}
	                          		items.push({
	                          			text : child.get('text'),
	                          			iconCls : child.get('iconCls'),
	                          			childItems : childItems,
	                          			cls : cls,
	                          			xtype : xtype,
	                          			handler : function(item) {
	                          				if(child.isLeaf()) {
//	                          					var centerTabs = extVia.regApp.myRaster.getCenterTabPanel();
//	                          				 	centerTabs.removeAll();
//	                          				 	centerTabs.add({
//	                          				 		title : 'Navigationsziel',
//	                          				 		border: false,
//	                          				 		frame : false,
//	                          				 		tbar : extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Men�eintrag', epobDscr: me.renderText(child.get('text'))}),
//	                          				 		items : [{
//	                          				 			border : false,
//	                          				 			padding : 20,
//	                          				 			html : '<div style="margin:0 auto;padding:20px;text-align:center;width:100%;font-size:2em;text.align:center;color:#444;">' +
//	                          				 					'Sie haben <i>' +  me.renderText(child.get('text')) + '</i> erreicht!' +
//        			  											'</div>', margin:'24 24 24 24'
//	                          				 		}]
//	                          				 	});
//	                          				 	item.up('menu').hide();
	                          					var href = location.href.replace(/\&whereami.*/,'')
													location.href = href;//+'&whereami='+me.lastFirstLineOverItem.text;
													localStorage.setItem('pl_target', item.getText());
	                          				}
	                          				
	                          			},
	                          			index : i,
	                          			width : 80,
                         				height:80,
                         				margin : '8 8 8 4',
	                          			overCls : 'palette-item-over',
	                          			pressedCls : 'palette-item-pressed'
	                          		});
	                          		
	                          		++i;
	                          	}
	                          });
	                          if(i < 9) {
	                          	while(i % 3 !== 0) {
	                          		items.push({
	                          			xtype : 'hidden',
	                          			width : 95
	                          		});
	                          		++i;
	                          	}
	                          	items.push(createThirdLevel());
	                          } else if(i === 9) {
	                          	items.push(createThirdLevel());
	                          }
                          });
                          
                         
                         	
                         var palett = Ext.create('Ext.menu.Menu', {
                         	shadow: false,
                         	border: false,
                         	width: 275,
                         	layout : 'fit',
                         	cls : 'xty_palette',
                         	baseCls : 'xty_palette-arrow-top', 

                         	items : [{
                         		xtype : 'toolbar',
                         		width : 275,
                         		cls : 'xty_palette-item-container', // xty_palette
                         		border : false,
                         		listeners : {
                         			beforeadd : function(tbar, cmp) {
                         				if(cmp.text && cmp.text.indexOf("-") >= 0) {
                         					cmp.text = cmp.text.replace('-', '-<br />');
                         				}
                         			}
                         		},
                         		layout : {
                         			type : 'table',
                         			columns : columns
                         		},
                         		defaults : {
                         			scale : 'large',
                         			enableToggle : true,
                         			iconAlign : 'top',
                         			listeners : {
                         				click : function(btn) {                         					
                         					var parent = btn.up(),
                         						childContainer = btn.nextSibling('toolbar'),
                         						pressed = btn.pressed;
                         					
                                                if (pressed){parent.addCls('xty_palette-hasPressed-item');}
                                                else {parent.removeCls('xty_palette-hasPressed-item');}
                                    
                                    
                         					if(parent.activeContainer) {
                         						parent.activeContainer.hide();
                         					}
                         					if(pressed && !Ext.isEmpty(btn.childItems)) {
                         						
                         							childContainer.moveArrow(btn.index);
                         						
	                         						childContainer.removeAll();
	                         						childContainer.add(btn.childItems);
		                         					childContainer.show();
		                         					parent.activeContainer = childContainer;
                         					}
                         					if(parent.activeButton && parent.activeButton !== btn) {
	                         					parent.activeButton.toggle(false);
                         					}
                         					parent.activeButton = btn;
                         				}
                         			}
                         		},
                         		items : items
                         	}]
                         });
                         
                         function renderPalett(palett, region, src, center) {
                              var me = this,
                              	  rX = region.getPosition()[0],
                              	  rY = region.getPosition()[1],
                              	  rWidth = region.getWidth(),
                              	  pWidth = 240,
                              	  sX = src.getPosition()[0],
                              	  sY = src.getPosition()[1],
                              	  sWidth = src.getWidth(),
                              	  needWidth,
                              	  pX, pY,
                              	  pointer,
                              	  pointerX;
                              	 
                             needWidth = pWidth + (sWidth / 2) - 20;
                          
                          	 if(needWidth > rWidth && center) {
                          	 	var missingWidth = needWidth - rWidth;
                          	 	var eastPan = extVia.regApp.myRaster.getEast();
                          	 	eastPan.setWidth(eastPan.getWidth() - missingWidth);
                          	 } else if(needWidth > rWidth) {
                          	 	region.setWidth(needWidth);
                          	 }
                          	 
                          	 rX = region.getPosition()[0];
	                      	 rY = region.getPosition()[1];
	                      	 rWidth = region.getWidth();
                          	 
                          	 pY = sY + 45;
                          	 if(sX - pWidth <= rX) {
                          	 	pX = rX + 5;
                          	 } else {
                          	 	pX = sX - pWidth + (sWidth / 2 - 5);
                          	 }
                          	 
                          	 pointerX = sX - pX + (sWidth / 2) - 15;
                          	 if(pointerX < 10) {
                          	 	pointerX = 25;
                          	 } else if(pointerX >= 333) {
                          	 	pointerX = 333;
                          	 }
                          	 
                          	 palett.showAt(pX, pY);
                          	 
                          	 Ext.util.CSS.removeStyleSheet('arrow');
                          	 Ext.util.CSS.createStyleSheet('.xty_palette-arrow-top:after, .xty_palette-arrow-top:before {left:'+pointerX+'px}', 'arrow');
                          	 
//                          	 pointer = Ext.get('menubar-pointer');
//                          	 pointer.setStyle('background-position', pointerX + 'px 0px');
//                          	 palett.getComponent('menubar-level-3').hide();
                          };
                          
                          
                          
                          
                          // Finde alle Panel die �berwacht werden sollen inklusive der Palette.
                          var westPan = extVia.regApp.myRaster.getWest(),
                          	  eastPan = extVia.regApp.myRaster.getEast(),
                          	  centerPan = extVia.regApp.myRaster.getCenter();
                          	  
                          // Finde Position des aktuell gew�hlten Buttons.
                          var buttonPos = srcButton.getPosition();
                          
                          // Finde die maximale rechte X-Koordiante f�r die Palette.
                          var palettMaxRightPos = buttonPos[0] + (srcButton.getWidth()  / 2 - 50);
                          
                          // Pr�fe ob Palette in den Westen passt.
                          if(!Ext.isEmpty(westPan) && palettMaxRightPos < westPan.getWidth()) {
                          	renderPalett(palett, westPan, srcButton);
                          // Pr�fe ob Palette in den Osten passt.
                          } else if(!Ext.isEmpty(eastPan) && palettMaxRightPos > eastPan.getPosition()[0]) {
                          	renderPalett(palett, eastPan, srcButton);
                          } else { //Palette muss also in die Mitte passen.
                          	renderPalett(palett, centerPan, srcButton, true);
                          }
                         	
                         
                         	
                         return palett;
                         
                         }
                         	
                         	
                         	
                          var treeStore = Ext.data.StoreManager.lookup('navigationStore');
                          if(Ext.isEmpty(treeStore)) {
                          	treeStore = Ext.create('ExtVia.data.NavigationTreeStore');
                          }
                          
                          var srcButton = cfg.srcButton; 
                          var srcBX = srcButton.getPosition()[0];
                          var oldItems = button.menuCfg.items[0].items;
                          var buttonGroup;
                          var cnt = 0;
                          
                          for(var i = 0; i < oldItems.length; ++i) {
                          	var oldItem = oldItems[i];
                          	if(oldItem.xtype && oldItem.xtype === "buttongroup") {
                          		buttonGroup = oldItem;
                          	}
                          }
                          
                          buttonGroup.items.splice(1, buttonGroup.items.length);
                          
                          treeStore.getRootNode().eachChild(function(child){
                          	if(child.get('text') === cfg.srcButton.text) {
                          		var ref = Ext.create('Ext.container.ButtonGroup', {
                          			columns: 3,
                          			colspan: 3,
                          			width : 300,
                          			hidden : true,
                          			defaults : {
                          				scale : 'large'
                          			}
                          		}),
                          		count = 0;
                          		
                          		child.eachChild(function(c) {
                          			if(count !== 0 && count % 3 === 0) {
                          				buttonGroup.items.push(ref);
                          				ref = Ext.create('Ext.container.ButtonGroup', {
                          					columns: 3,
                          					colspan: 3,
                          					hidden : true,
		                          			width : 300,
		                          			defaults : {
		                          				scale : 'large'
		                          			}
		                          		});
                          			}
	                      			buttonGroup.items.push({
	                      				xtype : 'button',
	                      				index : cnt++,
	                      				enableToggle :true,
	                      				menu : [{
	                      					text : 'Vorlage'
	                      				}, {
	                      					text : 'Kategorien'
	                      				}],
	                      				text : c.get('text'),
	                      				iconCls : c.get('iconCls'),
	                      				scale : 'large',
	                      				node : c,
	                      				thirdLevelRef : ref
	                      			});
	                      			++count;
                          		});
                          		
                          		
                          		return;
                          	}
                          });
                          
                          
                          if (!button.myMenu){
                          	button.myMenu =    Ext.create('Ext.menu.Menu', button.menuCfg);
                          } else {
                          	button.myMenu.down('buttongroup').removeAll();
                          	button.myMenu.down('buttongroup').add(buttonGroup.items);
                          	//button.myMenu.getComponent('menubar-level-3').hide();
                          }
                          
                          
                          var level2Header = button.myMenu.getComponent('menubar-level-2').getComponent('level2-buttongroup').getComponent('level2-header');
                          level2Header.setText(srcButton.getText()); //+' '+srcBX);                   

                          
                          // Ab hier wird Controller Funktonalit�t ausgef�hrt.
                          
                          
//                          srcButton.ownerCt.items.items.forEach(function(b) {
//                          	if(b.$className.indexOf("Ext.button") >= 0) {
//                          		console.log(b.text + ": " + b.getWidth());
//                          	}
//                          });
                          
//                          function renderPalett(palett, region, src, center) {
//                              var me = this,
//                              	  rX = region.getPosition()[0],
//                              	  rY = region.getPosition()[1],
//                              	  rWidth = region.getWidth(),
//                              	  pWidth = 366,
//                              	  sX = src.getPosition()[0],
//                              	  sY = src.getPosition()[1],
//                              	  sWidth = src.getWidth(),
//                              	  needWidth,
//                              	  pX, pY,
//                              	  pointer,
//                              	  pointerX;
//                              	 
//                             needWidth = pWidth + (sWidth / 2) - 20;
//                          
//                          	 if(needWidth > rWidth && center) {
//                          	 	var missingWidth = needWidth - rWidth;
//                          	 	var eastPan = extVia.regApp.myRaster.getEast();
//                          	 	eastPan.setWidth(eastPan.getWidth() - missingWidth);
//                          	 } else if(needWidth > rWidth) {
//                          	 	region.setWidth(needWidth);
//                          	 }
//                          	 
//                          	 rX = region.getPosition()[0];
//	                      	 rY = region.getPosition()[1];
//	                      	 rWidth = region.getWidth();
//                          	 
//                          	 pY = sY + 25;
//                          	 if(sX - pWidth <= rX) {
//                          	 	pX = rX + 5;
//                          	 } else {
//                          	 	pX = sX - pWidth + (sWidth / 2 - 5);
//                          	 }
//                          	 
//                          	 pointerX = sX - pX + (sWidth / 2) - 15;
//                          	 if(pointerX < 10) {
//                          	 	pointerX = 10;
//                          	 } else if(pointerX >= 333) {
//                          	 	pointerX = 333;
//                          	 }
//                          	 
//                          	 palett.showAt(pX, pY);
//                          	 pointer = Ext.get('menubar-pointer');
//                          	 pointer.setStyle('background-position', pointerX + 'px 0px');
//                          	 palett.getComponent('menubar-level-3').hide();
//                          };
                          
                          
                          
                          
                          // Finde alle Panel die �berwacht werden sollen inklusive der Palette.
                          var westPan = extVia.regApp.myRaster.getWest(),
                          	  eastPan = extVia.regApp.myRaster.getEast(),
                          	  centerPan = extVia.regApp.myRaster.getCenter(),
                          	  palett = button.myMenu;
                          	  
                          // Finde Position des aktuell gew�hlten Buttons.
                          var buttonPos = srcButton.getPosition();
                          
                          // Finde die maximale rechte X-Koordiante f�r die Palette.
                          var palettMaxRightPos = buttonPos[0] + (srcButton.getWidth()  / 2 - 50);
                          
                          // Pr�fe ob Palette in den Westen passt.
                          if(!Ext.isEmpty(westPan) && palettMaxRightPos < westPan.getWidth()) {
                          	renderPalett(palett, westPan, srcButton);
                          // Pr�fe ob Palette in den Osten passt.
                          } else if(!Ext.isEmpty(eastPan) && palettMaxRightPos > eastPan.getPosition()[0]) {
                          	renderPalett(palett, eastPan, srcButton);
                          } else { //Palette muss also in die Mitte passen.
                          	renderPalett(palett, centerPan, srcButton, true);
                          }
                          
                          var westWidth = westPan.getWidth();
                          
                          //  showUnderButton
                          var x =  subVerti? srcBX : 370;  
                         

                          //  showInWest or showInCenter
                          
                          button.myMenu.removeCls('xty_menu-pointer-left');
                          button.myMenu.removeCls('xty_menu-pointer-midleft');
                          button.myMenu.removeCls('xty_menu-pointer-midright');
                          button.myMenu.removeCls('xty_menu-pointer-right');
                          
                          button.myMenu.addCls('xty_menu-pointer-right');
                          
                          
//                          if (x===51  || x===416){ button.myMenu.addCls('xty_menu-pointer-left');}
//                          if (x===140 || x===520){ button.myMenu.addCls('xty_menu-pointer-midleft');}
//                          if (x===230 || x===617){ button.myMenu.addCls('xty_menu-pointer-midright');}
//                          if (x===313 || x===680){ button.myMenu.addCls('xty_menu-pointer-right');}
                          
                          
//                          if (x>350){
//                            westPan.setWidth(350);
//                            x = 440;
//                          }
//                          else {
//                            westPan.setWidth(350);
//                            x = 66;
//                          }
                          

                          //  showUnderButton
                         // button.myMenu.showAt(x-50, 32);
                          
                         },
                         
                         
                         menu:null,
                         menuCfg:{
                         
                        componentCls:'xty_menu-palette xty_menu-white xty_menu-hasPointer', 
                        showSeparator:false, 
                        shadow:false, 
                         
                         listeners:{
                          
                          show: function(menu){
						      if (!menu.pointerEl){     
	                           var pointerEl =   Ext.DomHelper.insertFirst(Ext.get(menu.id),      {
		                         tag:'div', 
		                         id:'menubar-pointer',
		                         cls:'xty_menubar-pointer'
	                            });
						        menu.pointerEl  = pointerEl;   
                                Ext.get(menu.id).setHeight(menu.getHeight()+12);
                    
						       }
                           }                         
                         },
                         
                         
                         items:[
                        
                         
                        //  {text : 'viaCONTENT', width:280, height:30, overCls:'nix', cls:'xty_viaMenu-level2-header', iconCls :null, index:2,  colspan:3, margin:'0 0 0 0'}, 
                         
                         
                         
                         {
                         xtype:'toolbar', 

                         width:  subVerti? 320 : 814, 
                         height: subVerti? 340 : 90, 
                         vertical:subVerti, 

                         style:'background:white;border-color:#FFF;', 
                         itemId:'menubar-level-2',
                         margin:'10 10 10 10',
                         border:false,
                         cls:'xty_viaMenubar-sublevelbar xty_viaMenu-level-2',
                         x:320, 
                         
                         
                         defaults:{
                         	iconCls:'xty_sublevel-item',
                         	scale:'large',
                         	iconAlign :'top',
                         	height:80,
                         	width:80,

                         	listeners:{
		                          mouseover: function( butt, evt ){
		                            var menubarLevel3 = butt.ownerCt.ownerCt.getComponent('menubar-level-3');
		                            if (menubarLevel3.lastOverButt){
		                              menubarLevel3.lastOverButt.removeCls('x-btn-default-toolbar-large-over');
		                            }
		                            
		                            var x = 30 + butt.index*83;
		                            //menubarLevel3.setPosition(x,130);
		                            menubarLevel3.show();
		                            menubarLevel3.showItems();
		                            menubarLevel3.lastOverButt = butt;
		                          },
		                          mouseout: function( butt, evt ){
		                            var menubarLevel3 = butt.ownerCt.ownerCt.getComponent('menubar-level-3');
		                            butt.addCls('x-btn-default-toolbar-large-over');
		                            //menubarLevel3.setPosition(20,130);   
		                          }
                         	}
                         },
                         
                         items:[
                          {text : 'Kategorie', index:0,hidden: subVerti},tbsep2,
                          {text : 'Unicodezeichen', index:1,hidden: subVerti},tbsep2,
                          {text : 'Elementattribute', index:2, hidden: subVerti},tbsep2,
                          {text : 'Elementattributsicht', index:3,hidden: subVerti},tbsep2,
                          {text : 'DateiFormat', index:4, hidden: subVerti},tbsep2,
                          {text : 'Farbraum', index:4, hidden: subVerti},tbsep2,
                          {text : 'Bildbearbeitung', index:4, hidden: subVerti},tbsep2,
                          {text : 'W�rterbuch', index:4, hidden: subVerti},tbsep2,
                          {text : 'XSD/DTD Datei', index:4, hidden: subVerti},
                          
                          
                          { xtype:'buttongroup', 
                            columns: 3,                  
                            hidden:  !subVerti,
                            width:320, 
                            height:320,
                            frame:false,
                            itemId:'level2-buttongroup',
                            cls:'xty_viaMenu-level2-buttongroup', 
                            defaults:{
                            margin:'10 10 10 10', 
                            iconCls:'xty_sublevel-item ', scale:'large', iconAlign :'top', height:80, width:80,
                            listeners:{
                            scope : me,
                            mouseover: function( butt, evt ){                         	
                            	
								var menubarLevel3 = butt.ownerCt.ownerCt.ownerCt.getComponent('menubar-level-3'),
									node = butt.node;
									
								if(menubarLevel3.lastOverButt) {
									 menubarLevel3.lastOverButt.removeCls('x-btn-default-toolbar-large-over');
								}
								
								
								if(node && !node.isLeaf()) {
									menubarLevel3.removeAll();
									butt.thirdLevelRef.removeAll();
									node.eachChild(function(child){
										butt.thirdLevelRef.add({
											xtype : 'button',
											text : child.get('text')
										});
									});
									
									if(me.activeRef) {
										me.activeRef.hide();
									}
									butt.thirdLevelRef.show();
									me.activeRef = butt.thirdLevelRef;
									
									if(!butt.up().addHight) {
										addHight = butt.thirdLevelRef.getHeight() + 10;
										butt.up().setHeight(butt.up().getHeight() + addHight);
										butt.up('toolbar').setHeight(butt.up('toolbar').getHeight() + addHight);
										butt.up('menu').setHeight(butt.up('menu').getHeight() + addHight);
										butt.up().addHight = true;
									}
									
									
									menubarLevel3.show();
									menubarLevel3.doLayout();
									menubarLevel3.lastOverButt = butt;
								}
								
								
                              
//                              var menubarLevel3 = butt.ownerCt.ownerCt.ownerCt.getComponent('menubar-level-3');
//                              if (menubarLevel3.lastOverButt){
//                                menubarLevel3.lastOverButt.removeCls('x-btn-default-toolbar-large-over');
//                              }
//                              var x = 30 + butt.index*83;
//                              //menubarLevel3.setPosition(x,130);
//                              
//                              // adjust menuHeight because of pointer
//                              var menu = butt.ownerCt.ownerCt.ownerCt;
//                              Ext.get(menu.id).setHeight(menu.getHeight()+12);
//                           
//                              
//                              menubarLevel3.show();
//                              menubarLevel3.showItems();
//                              menubarLevel3.lastOverButt = butt;
                            },
                            mouseout: function( butt, evt ){
//                              var menubarLevel3 = butt.ownerCt.ownerCt.ownerCt.getComponent('menubar-level-3');
//                              menubarLevel3.hide();
                              
                            	if( butt.thirdLevelRef) {
                            		//butt.thirdLevelRef.hide();
                            	}
                              
                              if (butt.itemId && butt.itemId.indexOf('level2-header')==-1){
                               butt.addCls('x-btn-default-toolbar-large-over');
                              }
                             
                              //menubarLevel3.setPosition(20,130);   
                            }
                             }
                            }, 
                            
                            items:[
                            
                            {text : 'viaCONTENT', width:280, height:30, overCls:'nix', itemId:'level2-header', cls:'xty_viaMenu-level2-header', iconCls :null, index:2,  colspan:3, margin:'0 0 0 0'}, 
                            
                            {text : 'Hierarchy', index:2, iconCls:'xty_pgtoolbar-hierarchy'}, 
                            {text : 'Suche', index:3, iconCls:'xty_pgtoolbar-search'},
                            {text : 'Importordner', index:4, iconCls:'xty_pgtoolbar-dropbox'},
                            {text : 'Farbraum', index:4, iconCls:'xty_pgtoolbar-editItem'},
                            {text : 'Bildbearbeitung', index:4, iconCls:'xty_pgtoolbar-searchAndAssign'},
                            {text : 'W�rterbuch', index:4, iconCls:'xty_pgtoolbar-collectionAddTo'},
                            {text : 'XSD/DTD Datei', index:4, iconCls:'xty_pgtoolbar-editItem'},
                              {text : 'XSD/DTD Datei', index:4, iconCls:'xty_pgtoolbar-reference'},
                              {text : 'XSD/DTD Datei', index:4, iconCls:'xty_pgtoolbar-edit'}
                              
                            ]
                          },{xtype:'tbseparator', width:4, hidden: !subVerti}
                          
                          ]}
                         
                          
                         // LEVEL 3
                         ,{xtype:'toolbar', itemId:'menubar-level-3',
                         hidden:true, style:'background:white;border-color:#FFF;', 
                          margin:'0 10 10 10', border:false, cls:'xty_viaMenubar-sublevelbar xty_viaMenu-level-3', 
                          
                          x:320, width:814, height:40, 
                         
                          width:  subVerti? 200 : 814, 
            
                          
                          defaults:{hisdden:true, iconxxCls:'xty_sublevel-item-noic', scale:'large', icxxonAlign :'top', height:30, width:80},
                         
                         items:[
                          {text : 'Farbraum'},tbsep3,
                          {text : 'Bildbearbeitung'},tbsep3,
                          {text : 'W�rterbuch'},tbsep3,
                          {text : 'XSD/DTD Datei'},tbsep3,
                          {text : 'Kategorie'},tbsep3,
                          {text : 'Unicodezeichen'},tbsep3,
                          {text : 'Elementattribute'},tbsep3,
                          {text : 'Elementattributsicht'},tbsep3,
                          {text : 'DateiFormat'}
                         ],
                          
                          showItemsCnt:0,
                          showItems:function(evenOddAll){
                            var menubarLevel3 = this;
                            menubarLevel3.hideItems();
                            
                            var even= menubarLevel3.showItemsCnt%2==0;
                            var odd = !even;
                            
                            //var even=true;
                            //var odd = true;
                            
                            if (odd){
                            menubarLevel3.getComponent(0).show();  menubarLevel3.getComponent(1).show();
                            menubarLevel3.getComponent(4).show(); menubarLevel3.getComponent(5).show();
                            menubarLevel3.getComponent(8).show(); menubarLevel3.getComponent(9).show();
                            menubarLevel3.getComponent(12).show(); menubarLevel3.getComponent(13).show();
                            menubarLevel3.getComponent(16).show();
                            }
                            if (even){
                            menubarLevel3.getComponent(2).show();menubarLevel3.getComponent(3).show();
                            menubarLevel3.getComponent(6).show();menubarLevel3.getComponent(7).show();
                            menubarLevel3.getComponent(10).show(); menubarLevel3.getComponent(11).show();
                            menubarLevel3.getComponent(14).show(); menubarLevel3.getComponent(15).show();
                            }
                            menubarLevel3.showItemsCnt++;
                          }, 
                          hideItems:function(){
                            var menubarLevel3 = this;
                            menubarLevel3.getComponent(0).hide();
                            menubarLevel3.getComponent(1).hide();menubarLevel3.getComponent(2).hide();
                            menubarLevel3.getComponent(3).hide();menubarLevel3.getComponent(4).hide();
                            menubarLevel3.getComponent(5).hide();menubarLevel3.getComponent(6).hide();
                            menubarLevel3.getComponent(7).hide();menubarLevel3.getComponent(8).hide();
                            menubarLevel3.getComponent(9).hide();menubarLevel3.getComponent(10).hide();
                            menubarLevel3.getComponent(11).hide();menubarLevel3.getComponent(12).hide();
                            menubarLevel3.getComponent(13).hide();menubarLevel3.getComponent(14).hide();
                            menubarLevel3.getComponent(15).hide();menubarLevel3.getComponent(16).hide();
                          }                          
                          }
                         
                         
                         
                         ]}
                        
                        };   
    
          return buttCfg;
    
    }
    
//    ,getHomeButtonmenuCfg : function(cfg){
//    
//    }
    
    
    	
    }
});
