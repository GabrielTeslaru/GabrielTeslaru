/*


*/
Ext.application({
    name: 'collaborationsApp',
    
    /**
     * Place 
     */
    appMode:{},


    
    launch: function() {
      
      
      //var uiLangScriptEl = document.getElementById('uiLang');
      //uiLangScriptEl.src =  uiLangScriptEl.src.replace(/ext-lang-...js/,'ext-lang-en');
      
      
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	
    	extVia.regApp = this;

    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true,hidesNorth:true,hidseWest:true, modulDscr:'Collaborations'});
    	extVia.ui.page.raster.onReady(this);

    	var centerTabPan;

    	
    	centerTabPan = extVia.regApp.myRaster.initCenterTabPanel();
    	extVia.regApp.centerTabPan = centerTabPan;
    	extVia.regApp.myRaster.addToCenter(centerTabPan);
    	

    	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip
    	var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
    	

//      var viewCfg = {};
//      var setViewConfigFromUrl  = function getViewConfigFromUrl() {
//         var qStr = location.href.replace(/.[^\?]*\?/,'');
//         var urlParams = Ext.Object.fromQueryString(qStr);
//        return urlParams;
//       };
//       setViewConfigFromUrl();
       extVia.regApp.viewCfg = {}; //viewCfg;
  	

    	var westTabPan  =  extVia.regApp.myRaster.initWestTabPanel(
	    		{
	    	    	activeTab:'hierarchy',
	    	    	items:[ 
	    	    	        extVia.query.statics.getQueryTabCfg() ,
	    	    	        
	    	    	        extVia.hierarchy.statics.getHierarchyTabCfg({}),
	    	    	        extVia.hierarchy.statics.getStructureTreePanelCfg({})
	    	    	        ]
	    		}); 	    
    	extVia.regApp.myRaster.addToWest(westTabPan);


    	 extVia.editor.baseEditor.statics.epobEditor ='collaborationsDraft';
    	 
        var task = new Ext.util.DelayedTask(function(){
          var openOnStartNodesArr =  Ext.query('.xty_hierarchy-tree-panel .xty_open-on-start-node');
          if (openOnStartNodesArr){
            var openOnStartNode = openOnStartNodesArr[0];
            var openOnStartNodeEl = Ext.get(openOnStartNode); 
            var openOnStartNodeDomEl = document.getElementById(openOnStartNodeEl.id);
            var openOnStartNodeClicker = document.getElementById(openOnStartNodeEl.id).parentNode;
            openOnStartNodeClicker.openEditor = true;
            openOnStartNodeClicker.click();
          }
        });
        task.delay(100); 
         
        
    }
});


/*
 * 
 * $Revision: 1.1.2.3 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/07/10 17:42:34 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
