Ext.namespace('loc', 'extVia.locales' ,'extVia.collaboration.locales');
/**
 * @class extVia.collaboration.locales
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/09/11 17:41:58 $
 *            $Revision: 1.1.2.21 $
 */


extVia.collaboration.locale_DE_EN =   { 
  
                                       
  cancel: ['Abbrechen','Cancel'],                                    
                                       
                                       
  collaboration: ['Zusammenarbeit','Collaboration'],
  collaborationOverview: ['&Uuml;bersicht Zusammenarbeit','Collaboration overview'],  
  
  notifications: ['Benachrichtigungen','Notifications'],
  newNotifications: ['neue Benachrichtigungen','new Notifications'],
  allNotifications: ['alle Benachrichtigungen','all Notifications'],
  
  faves: ['Favoriten','Favorites', ''],
  share: ['Teilen','Share'],
  mainInstrShareIt: ['Dieses Produkt teilen.','Share this product.'],
  mainInstrShareGroup: ['Diese Gruppe teilen.','Share this group.'],
  labelIncludeMessage: ['Eine Mitteilung einbinden','Include a message'],
  labelAddPerson: ['Personen hinzuf&uuml;gen','Add a person'],

  sharedWithMsg: ['Mit {xothers} geteilt','Shared with {xothers}'],
  shared: ['Geteilt','Shared'],
  sharedThisProduct: ['hat dieses Produkt geteilt','has shared this Product'],
  sharedWithYou: ['hat etwas mit Ihnen geteilt','has shared something with you'],
  
  
  otherPersons: ['und {x} weiteren Personen','and {x} other persons'],
  oneOtherPerson: ['und einer weiteren Person','and one other person'],

  watch: ['Beobachten','watch'],
  watched: ['Beobachtet','watched'],
  isWatchingThisProduct: ['beobachtet dieses Produkt','is watching this Product'],
  situationYouAreWatching: ['Sie beobachten dieses Produkt.','You are watching this product.'],
  situationYouAreNotWatching: ['Sie beobachten dieses Produkt nicht.','You are not watching this product.'],
  
  
  recently: ['vor kurzem','recently'],
  recentlyViewed: ['vor kurzem angesehen','recently viewed'],
  viewed: ['Angeschaut','viewed'],

  
  thisProduct: ['dieses Produkt','this product'],
  thisProductgroup: ['dieses Produktgruppe','this productgroup'],
  thisProductAndGroup: ['Produkt und Gruppe','this product and group'],
  thatProduct: ['diesem Produkt','this product'],
  thatProductgroup: ['dieser Produktgruppe','this productgroup'],
  thatProductAndGroup: ['diesem Produkt und dieser Produktgruppe','this product and this productgroup'],
  
  
  situationYouAreWatchingThisEpob: ['Sie beobachten {thisEpob}.','You are watching {thisEpob}.'],
  situationYouAreNotWatchingThisEpob: ['Sie beobachten {thisEpob} nicht.','You are not watching {thisEpob}.'],
  purposeWatchingThisEpob: ['Benachrichtigung per E-Mail &uuml;ber &Auml;nderungen an <br>{thisEpob}.','Notifications per mail about changes on <br>{thisEpob}.'],
  labelWatchIt: ['Dieses Produkt beobachten.','Watch this product.'],
  labelWatchGroup: ['Die ganze Gruppe beobachten.','Watch the whole group.'],
  
  
  manageWatchers: ['Beobachter verwalten','Manage Watchers'],
  manageWatchEpobSupp: ['Diese Personen werden bei &Auml;nderungen an diesem Produkt benachrichtigt.','These people will be notified of changes to this product.'],  
  manageWatchAreaSupp: ['Diese Personen werden benachrichtigt &uuml;ber jede &Auml;nderung in dieser Gruppe ','These people will be notified of any changes in this group'],
  
  

  
  comment: ['Kommentar','Comment'],
  comments: ['Kommentare','Comments'],
  commentedThis: ['hat einen Kommentar hinzugef&uuml;gt','has added a comment'],
  commentedForYou: ['hat einen Kommentar f&uuml;r Sie','has a comment for you'],

  
  labelClose: ['Schliessen','Close'],
  labelAdd: ['Hinzuf&uuml;gen','Add'],
  labelAdded: ['Hinzugef&uuml;gt','Added'],
  
  extDateDscrFormat : [ "d.m.Y", "d/m/Y",'']

    
      // key : ['',''],
     };


 extVia.collaboration.locales = {
  appName:'collaboration'
 };

 if (!Ext.isDefined(extVia.locales.uiLangIsoIx)){
   extVia.locales.uiLangIsoIx = 1; // EN 
   if (Ext.isDefined( extVia.ui.page.strings.languageId)){
     if(extVia.ui.page.strings.languageId==="2"){ // DE
       extVia.locales.uiLangIsoIx = 0; 
     }
   }  
 }

 
 Ext.Object.each(extVia.collaboration.locale_DE_EN, function(key, value, myself) {
     extVia.collaboration.locales[key] = value[extVia.locales.uiLangIsoIx];
 });


 Ext.apply(extVia.locales, extVia.collaboration.locales);



 

/*
 * 
 * $Revision: 1.1.2.21 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/09/11 17:41:58 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 