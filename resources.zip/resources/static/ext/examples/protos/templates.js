
/**
 * Provides Templates + Template needed functions
 */
Ext.define('extVia.templates.statics', {
    statics: {

     getAspectRatioDependentSizes :  function(values) {
            var width = parseInt(values.previewWidth, 10); 
            var height = parseInt(values.previewHeight, 10); 
          /**
           * The aspect ratio of an image is its width divided by its height.
           * If aspectRatio > 1 the Image is horizontal / landscape format 
           * If aspectRatio < 1 the Image is vertical   / portrait format
          */
          var aspectRatio = 1;
          if (width > 0 && height >0){
            aspectRatio = width/height; 
          }
          //var imgSize = aspectRatio > 1 ? 'width=\'58\' style=\'vertical-align:middle; margin-top:9px;\' ' : 'height=\'58\'';
          
            var newEdge;
            var edgeOverlayMargin;
            var newEdgeFactor;
            if (aspectRatio>1){ // landscape
               newEdgeFactor  =  56 /  height; 
               newEdge =  width * newEdgeFactor;    
               edgeOverlayMargin= 'margin-left: -';
            }
            else{// portrait
               newEdgeFactor  =  56 /  width; 
               newEdge =  height * newEdgeFactor; 
               edgeOverlayMargin= 'margin-top: -';
            }

             var edgeOverlay = newEdge - 56;
             edgeOverlayMargin+= parseInt ((edgeOverlay / 2 ) -1 , 10) +'px;';
             
            var imgSize = aspectRatio > 1 ? 'height=\'60\' ' : 'width=\'60\'';
            imgSize+= ' style=\' ' +edgeOverlayMargin+ '\' ' ;
          
          
          return imgSize;    
         },
         
         isImageUrl :  function(url) { 
            var isImageUrl = false;
            if (url){
               url =  url.toLowerCase();
               if (url.length>10){
                url =  url.substring(url.length-10, url.length);
               }
               if (url.indexOf ('.jpg') === url.length-4 ){ 
                isImageUrl = true;
               }
               else if (url.indexOf ('.png') === url.length-4 ){ 
                isImageUrl = true;
               }
               else if (url.indexOf ('.gif') === url.length-4 ){ 
                isImageUrl = true;
               }
               return isImageUrl;             
            }
          },
          
          
         getTeaserThumbnailAttributes :  function(values) {
              var thumbAtts = '';
              var src='../img/icons/spacer.gif';
              var defaultthumbCls ='';
              defaultthumbCls='xty_teaser-default-thumbnail';
              var hasImageUrl = true; //extVia.templates.statics.isImageUrl(values.previewUrl);
              var imgSizes='height=\'58\' ' ;
              
              if (hasImageUrl){
                src = values.previewimage;
                imgSizes = extVia.templates.statics.getAspectRatioDependentSizes(values) ;
              }
              else{
                defaultthumbCls='xty_teaser-default-thumbnail';
              }
              thumbAtts ='  class=\'xty_teaser-thumbnail '+defaultthumbCls+'\' src=\''+src +'\' ' +  imgSizes  + '  ' ;
              return thumbAtts;
            },
      
      
      
      
     BoundListItem_userChannelTeaser : 
      '<div class="xty_teaser-thumbnail-bin">' +      
        '<img {[extVia.templates.statics.getTeaserThumbnailAttributes(values)]} />' +
       '</div>' + 
       '<div class="xty_teaser-text xty_teaser-text-twoLines <tpl if="isnew">xty_teaser-isnew</tpl>" >' +
         '<span class="xty_teaser-title" >{title} </span> ' +
         '<span class="xty_teaser-author" >{author} </span> ' +
         '<span class="xty_teaser-summary" >{summary}</span>' +
       '</div>' +
       '<div class="xty_teaser-text xty_teaser-iconAndDate-bin" >' +
         '<span class="xty_teaser-format <tpl if="formats && formats[0]">xty_teaser-format-{[values.formats[0].toLowerCase()]}" title="{formats}</tpl>"  >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>' + 
         '<span class="xty_teaser-date" >{changedate}' +
           '<tpl if="isnew">' +
            '<span class="xty_teaser-isnew-star" title="{isnew}" >&nbsp;&nbsp;</span>' +
           '</tpl>'+
         '</span>' +
         '<tpl if="categories">' +
           '<span class="xty_teaser-categories xty_teaser-{[values.categories.length>7?"many":values.categories.length]}-categories"  >' +
             '<tpl for="categories">'+    
              '<span class="xty_teaser-category" title="{.}">{.}</span>'+
             '</tpl>'+ 
           '</span>' +
         '</tpl>'+
       '</div>'  
      



    }// eo statics
});
