
Ext.namespace('extVia.uploader.data');

extVia.uploader.data.webdavTree = {
  "text": ".",
  "children": [
    {
      "task": "Project: Shopping",
      "duration": 13.25,
      "user": "Tommy Maintz",
      "iconCls": "task-folder",
      "expanded": true,
      "children": [
        {
          "task": "Housewares",
          "duration": 1.25,
          "user": "Tommy Maintz",
          "iconCls": "task-folder",
          "children": [
            {
              "task": "Kitchen supplies",
              "duration": 0.25,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            },
            {
              "task": "Groceries",
              "duration": 0.4,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            },
            {
              "task": "Cleaning supplies",
              "duration": 0.4,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            },
            {
              "task": "Office supplies",
              "duration": 0.2,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            }
          ]
        },
        {
          "task": "Remodeling",
          "duration": 12,
          "user": "Tommy Maintz",
          "iconCls": "task-folder",
          "expanded": true,
          "children": [
            {
              "task": "Retile kitchen",
              "duration": 6.5,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            },
            {
              "task": "Paint bedroom",
              "duration": 2.75,
              "user": "Tommy Maintz",
              "iconCls": "task-folder",
              "children": [
                {
                  "task": "Ceiling",
                  "duration": 1.25,
                  "user": "Tommy Maintz",
                  "iconCls": "task",
                  "leaf": true
                },
                {
                  "task": "Walls",
                  "duration": 1.5,
                  "user": "Tommy Maintz",
                  "iconCls": "task",
                  "leaf": true
                }
              ]
            },
            {
              "task": "Decorate living room",
              "duration": 2.75,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            },
            {
              "task": "Fix lights",
              "duration": 0.75,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            },
            {
              "task": "Reattach screen door",
              "duration": 2,
              "user": "Tommy Maintz",
              "leaf": true,
              "iconCls": "task"
            }
          ]
        }
      ]
    },
    {
      "task": "Project: Testing",
      "duration": 2,
      "user": "Core Team",
      "iconCls": "task-folder",
      "children": [
        {
          "task": "Mac OSX",
          "duration": 0.75,
          "user": "Tommy Maintz",
          "iconCls": "task-folder",
          "children": [
            {
              "task": "FireFox",
              "duration": 0.25,
              "user": "Tommy Maintz",
              "iconCls": "task",
              "leaf": true
            },
            {
              "task": "Safari",
              "duration": 0.25,
              "user": "Tommy Maintz",
              "iconCls": "task",
              "leaf": true
            },
            {
              "task": "Chrome",
              "duration": 0.25,
              "user": "Tommy Maintz",
              "iconCls": "task",
              "leaf": true
            }
          ]
        },
        {
          "task": "Windows",
          "duration": 3.75,
          "user": "Darrell Meyer",
          "iconCls": "task-folder",
          "children": [
            {
              "task": "FireFox",
              "duration": 0.25,
              "user": "Darrell Meyer",
              "iconCls": "task",
              "leaf": true
            },
            {
              "task": "Safari",
              "duration": 0.25,
              "user": "Darrell Meyer",
              "iconCls": "task",
              "leaf": true
            },
            {
              "task": "Chrome",
              "duration": 0.25,
              "user": "Darrell Meyer",
              "iconCls": "task",
              "leaf": true
            },
            {
              "task": "Internet Exploder",
              "duration": 3,
              "user": "Darrell Meyer",
              "iconCls": "task",
              "leaf": true
            }
          ]
        },
        {
          "task": "Linux",
          "duration": 0.5,
          "user": "Aaron Conran",
          "iconCls": "task-folder",
          "children": [
            {
              "task": "FireFox",
              "duration": 0.25,
              "user": "Aaron Conran",
              "iconCls": "task",
              "leaf": true
            },
            {
              "task": "Chrome",
              "duration": 0.25,
              "user": "Aaron Conran",
              "iconCls": "task",
              "leaf": true
            }
          ]
        }
      ]
    }
  ]
}