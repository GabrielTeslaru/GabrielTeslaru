/**
 * 
 */
Ext.application({
    name: 'uploader',
    
    version:'$Revision: 1.7.2.45 $',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerHeight = centerPan.getHeight();
      centerHeight-=25; // substract center-tabstrip 
      centerHeight-=66; // substract pagejobbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=60;  // substract pagetoolbar 
      }
      if (cfg && cfg.hasSubtabs){
        centerHeight-=30; // substract subtabstrip
      }      
      return centerHeight;
    },

    getCenterWidth : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerWidth = centerPan.getWidth()-50;    
      return centerWidth;
    },
    
    getWestListHeight : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
      return westHeight;
    },
    
    
    getWestWidth : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westWidth = westPan.getWidth(); 
      return westWidth;
    },
    
    
    generateEpobCls: function() {    
      // in the moment still @  ~lty/pg/epobCSS.jsp 
    },
    
    
    generateFlagsCls: function() {
      // in the moment @ baseProto.baseEditorStatics#generateFlagCss 
    },
    

//    // copied from http://www.html5rocks.com/en/tutorials/file/dndfiles/?redirect_from_locale=ko
//    handleFileSelect : function (evt) {
//          evt.stopPropagation();
//          evt.preventDefault();
//          var files = evt.dataTransfer.files; // FileList object.
//          // files is a FileList of File objects. List some properties.
//          var output = [];
//          var filename;
//          var i; var f;
//          for (i = 0, f; f = files[i]; i++) {     
//            filename = f.name;
//            output.push('<li class="xty_output-item"><strong>', escape(f.name), '</strong> (', f.type || 'n/a', ') - ',
//                        f.size, ' bytes, last modified: ',
//                        f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a',
//                        '</li>');
////             var fileObbby = {
////                        name: escape(f.name), 
////                  type: ''+f.type,
////                        size: f.size +' bytes', 
////                        lastmodified:  f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a',
////                        }; 
////
////             if (f.name.indexOf('_32.png')>-1){
////               imagesViewPanelPNGToolbar.add({icon:'./svg/'+f.name, tooltip:''+f.name, tooltipType:'title' });
////               imagesViewPanelPNG24Toolbar.add({icon:'./svg/'+f.name, tooltip:''+f.name, tooltipType:'title'});
////             }
////             else{
////               imagesViewPanelSVGToolbar.add({icon:'./svg/'+f.name, tooltip:''+f.name, tooltipType:'title'});
////             }
////             svgdata.push(fileObbby);           
//          }
//          document.getElementById('fileslist').innerHTML = '<ul>' + output.join('') + '</ul>';
//         //  store.loadData(svgdata);
//          var dropZoneEl = Ext.get('dropzone-importfolder');
//          dropZoneEl.removeCls('xty_dropzone-over');
//          extVia.regApp.showRequiredPreviewDialog({filename:filename});
//        },
    
    
    
    initWestTreeGrid: function(cfg) {
      var me = this;
      Ext.create('Ext.data.Store', {
         storeId:'whateverStore',
         fields:['id', 'epobType', 'name', 'status', 'responsible'],
         data:{'items':[
             {id:'1', epobType:'Product', name:'Flow 1', status:'Warnung', responsible:'Ernie'  },
             {id:'2', epobType:'Image', name:'Bilder hochladen', status:'', responsible:'Oskar'  },
             {id:'3', epobType:'Video', name:'Welt retten', status:'Start', responsible:'Grobi'  },
             {id:'4', epobType:'User', name:'Kuchen backen', status:'Danger', responsible:''  },
             {id:'5', epobType:'Attribute', name:'Datenbank zerst&ouml;ren', status:'Success', responsible:''  },
             {id:'6', epobType:'Product', name:'Produkte pflegen', status:'Wait', responsible:''  }
         ]},
         proxy: {
             type: 'memory',
             reader: {
                 type: 'json',
                 root: 'items'
             }
         }
       });
       var epobTypeRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
         };
       var statusRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon_'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
         };
        var whateverGrid = Ext.create('Ext.grid.Panel', {
          itemId:'whateverGrid',
              width: 400,
              border:false,
              store: Ext.data.StoreManager.lookup('whateverStore'),
              columns: [
                   { header: 'Typ',  dataIndex: 'epobType', width:32, renderer:epobTypeRenderer },
                   { header: 'Name',  dataIndex: 'name' ,  flex: 1},
                   { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
                   { header: 'Verantwortliche', dataIndex: 'client', 
                     renderer: function(){
                       var clientsHtml = 
                         '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
                           '<span class="xty_tag" title="Muppets">Muppets</span>' +
                           '<span class="xty_tag" title="Puppets" >Puppets</span>' +
                         '</span>';
                       return clientsHtml;
                     }
                   },
                 { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
           ],
           height: 200,
               listeners:{
                itemdblclick: function( view, record, item, index, evt, eOpts ){
                 me.showEditor(record);
                }
               }
       });
         var whateverList = {
             title:'Uploads',
             itemId:'whateverList',
             height: me.getWestListHeight(),
             tbar:[
             '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit', handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'L&ouml;schen', handler: me.deleteEpobDialog}
             ],
             items:[ whateverGrid ] ,
             bbar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
          };
         

       
       
       
       
       // Treegrid
       Ext.define('Task', {
         extend: 'Ext.data.Model',
         fields: [
             {name: 'task',     type: 'string'},
             {name: 'user',     type: 'string'},
             {name: 'duration', type: 'string'}
         ]
     });
     var webDavTreeStore = Ext.create('Ext.data.TreeStore', {
         model: 'Task',
         root: extVia.uploader.data.webdavTree,
//         proxy: {
//             type: 'ajax',
//             //the store will get the content from the .json file
//             url: '../../tree/treegrid.json'
//         },
         folderSort: true
     });

     //Ext.ux.tree.TreeGrid is no longer a Ux. You can simply use a tree.TreePanel
     var webDavTreeGrid = Ext.create('Ext.tree.Panel', {
         region:'center',
         split: true, 
         //title: 'web-dav',
         itemId:'webdav',
         width: 500,
         height: 600,
         //collapsible: true,
         border:false,
         useArrows: true,
         rootVisible: false,
         store: webDavTreeStore,
         multiSelect: true,
        /// selModel: 'Ext.selection.CheckboxModel',
         //singleExpand: true,
         //the 'columns' property is now 'headers'
         columns: [{
             xtype: 'treecolumn', //this is so we know which column will show the tree
             text: 'Name',
             flex: 2,
             sortable: true,
             dataIndex: 'task'
         },
         {text:'Typ', width:50},
         {text:'Grösse', width:50},
         {
             //we must use the templateheader component so we can use a custom tpl
             xtype: 'templatecolumn',
             text: 'Duration',
             flex: 1,
             sortable: true,
             dataIndex: 'duration',
             align: 'center',
             //add in the custom tpl for the rows
             tpl: Ext.create('Ext.XTemplate', '{duration:this.formatHours}', {
                 formatHours: function(v) {
                     if (v < 1) {
                         return Math.round(v * 60) + ' mins';
                     } else if (Math.floor(v) !== v) {
                         var min = v - Math.floor(v);
                         return Math.floor(v) + 'h ' + Math.round(min * 60) + 'm';
                     } else {
                         return v + ' hour' + (v === 1 ? '' : 's');
                     }
                 }
             })
         },{
             text: 'Assigned To',
             flex: 1,
             dataIndex: 'user',
             sortable: true
         }],
         listeners:{
           'itemdblclick':function(){extVia.notify({action: 'dblclick'  , mssg:  'dblclick'});},
           'itemcontextmenu':function(){extVia.notify({action: 'contextmenu'  , mssg:  'contextmenu'}); }  
         },
         bbar:[{text:'+'}]
     });
  
     
     return   webDavTreeGrid;


    },
    
    initWestTreeTab: function(cfg) {
      var me  = this;

      var importFolderTreeStore = Ext.create('Ext.data.TreeStore', {
        root: {
            expanded: true,
            text: "Root",
            children: [
                { text: "Audios"},
                { text: "Bilder", expanded: true, children: [
                    { text: "book report", leaf: true, iconCls:'xty_epobImage'},
                    { text: "alegrbra", leaf: true,  iconCls:'xty_epobImage'}
                ] },
                { text: "Texte"},
                { text: "Neuer Import" },
                { text: "Herbstbilder", cls:'xty_treenode-herbstbilder'}
            ]
        }
    });
    var importFolderTreePanel = Ext.create('Ext.tree.Panel', {
        title: 'Importordner',
        useArrows : true,  
        viewConfig: {
          plugins: {
              ptype: 'treeviewdragdrop'
          }
        },
        itemId:'structureTreeTab',
        border:false,
        store: importFolderTreeStore,
        tbar:[ '->',  {disabled:true, iconCls: 'xty_pgtoolbar-upload',  itemId:'upload'},    { iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor, tooltip:'Neuer Ordner' }, {itemId:'delete', iconCls: 'xty_pgtoolbar-delete'}, {  tooltip:'Inhalte downloaden', iconCls: 'xty_pgtoolbar-download',  itemId:'download'}]
    });
      
      
      webDavTreeGrid = me.initWestTreeGrid();
      
      var myContentPanelHeight =  extVia.regApp.myRaster.getWest().getHeight() -52 ;
      var webdavTreeTab = {
                           title : 'Webdav',
                           itemId:'webdavTreeTab',
                           hsidden:true,
                           layout:'border',
                           height: myContentPanelHeight,
                           items:[
                             //{region:'north',   split: true, height: 180, border:false,  html: '<img onclick="extVia.regApp.showFileChooser();" style="margin-left:10px; margisn-top:15px" height="180px"  src="../img/fakes/dropzone-panel.png"/>'},
                             { tXitle:'Upload Dropzone treeTab', 
                               region:'north',  
                               height:202, 
                               cls:'xty_dropzone-panel xty_dropzone-panel-nested-with-tree', 
                               collapsible:true,
                               split: true,
                               border:false, 
                               html: 
                                 '<div style="" id="dropzone-webdav">'+
                                   '<img o_nclick="extVia.regApp.showFileChooser();" style="margin-left:10px; margin-top: -15px" height="180px"  src="../img/fakes/dropzone-panel.png"/>'+
                                 '</div>',  
                               items:[               
                                 {
                                 xtype: 'filefield', border:false,
                                 itemId:'filechooser',
                                 //cls:'xty_dropzone-filefield xty_webdav-dropzone-filefield',
                                 style:'position:absolute; top:115px; right:110px;  opacity:0;',
                                 cls:'xty_dropzone-filefield',
                                 name: 'filefield',
                                 allowBlank: false,
                                 buttonText: 'Browse Files'
                                }
                               ] 
                               //,xtml: '<div style="" id="dropzone-webdav"></div>' ,
//                               listeners:{
//                                 //afterrender: function( panel ){} 
//                               }   
                             },
                             webDavTreeGrid, 
                             {region:'south',  height: 20, split: true,  border:false, items:[ ]  }    
                           ]               
                      };
      var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
        activeTab: 2,
        tabBar:{ 
          tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
          handler:function(button){
            var activeTab = button.ownerCt.ownerCt.getActiveTab();
              extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
            }
           }
          ]
        },
        //items:[ webDavTreeGrid, webdavTreeTab ]
        items:[ webDavTreeGrid, webdavTreeTab, importFolderTreePanel]
        });
       extVia.regApp.myRaster.addToWest(tabPanWest);
      
      
    },
    
    getImportPresetDialog : function getImportPresetDialog(cfg){ 
      
      var title =  cfg.title ? cfg.title :'Importieren';
      var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'Was möchten Sie importieren?';
      
      var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'Was möchten Sie für {name} importieren?';
      
      var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'Importiere {name}';
      
      
      
      mainInstr = mainInstr.replace(/{name}/, '<i>'+cfg.name+'</i>');
      
      //var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Welche Objekte und welches Profil möchten Sie verwenden?';
      var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Welches Profil und welche Objekte möchten Sie verwenden?';
    
      
      
      
       if (cfg.isXML){
         suppInstr =  'Welches Profil möchten Sie verwenden?';
         //suppInstr = null;
       }
      
      
     var importPresetDialog = Ext.create('widget.window', {
          width: 420,
         
          y: 120, 
          modal:true,
          title:title,
          iconCls:extVia.dialoges.getWindowIconCls('Question'),
          plain: true,
          items : [
            {
              border : false,
              itemId:'dialogIntructions',
              defaults : {
                 style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
              },
              items : [  extVia.dialoges.getInstructionPanel ({  mainInstr: mainInstr,suppInstr:suppInstr})]
            },
          
            {
              xtype : 'form',
              border : false,
              itemId:'dialogBody',
              defaults : {
                width: 340,
                xtype:'combo', 
                 style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                 labelSeparator : ':<span class="xty_requiredStar"> *</span>'
              },
              
              
              items : [ 
                
                {  
                  fieldLabel:'Importprofil',
                  itemId:'importprofile',  
                  store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                    data :  [ ['Default'],  ['Profil 1'],  ['Profil 2'], ['Profil 3']]
                   }) ,                              
                 displayField: 'dscr',
                 typeAhead: true,
                 value:'Default',
                 mode: 'local',
                 triggerAction: 'all',
                 selectOnFocus:true 
              },
              
                {  

                  fieldLabel:'Objekttypen', hidden: !cfg.isCSV,
                  itemId:'objekttypen',  
                  store:   Ext.create('Ext.data.Store', {fields: [ 'dscr','epobType', 'value'], 
                    data :  [ 
                      {dscr:'Hierarchien', epobType:'Hierarchy', value: extVia.module.epob.HIERARCHY},  
                      {dscr:'Produkte', epobType:'Product', value: extVia.module.epob.PRODUCT}, 
                      {dscr:'Neue Attribute', epobType:'Attribute', value: extVia.module.epob.PRODUCTATTRIBUTE},  
                      {dscr:'Attributszuordnung', epobType:'ProductAttributeAssignment', value: 'ATTRIBUTEASSIGNMENT'},  
                      {dscr:'Attributwerte', epobType:'Attributevalue', value: 'ATTRIBUTEVALUE'},  
                      {dscr:'Vergleichsoperatoren', epobType:'ComparisonOperator', value: extVia.module.epob.COMPARISONOPERATOR},   
                      {dscr:'Einheiten', epobType:'Unit',  value: extVia.module.epob.UNIT},  
                      {dscr:'Auswahlgruppen', epobType:'Selectiongroup', value:'SELECTIONGROUP'},  
                      {dscr:'Wörterbuch', epobType:'Dictionary', value: extVia.module.epob.PRAT_DICTIONARY},  
                      {dscr:'Metadaten', epobType:'Metadata', value: 'METADATA'},  
                      {dscr:'Lieferantendaten', epobType:'Supplier', value: extVia.module.epob.SUPPLIER},  
                      {dscr:'Lieferantenattribut', epobType:'Supplierattribute',  value: 'SUPPLIERATTRIBUTE'}

                      ]
                   }) ,      
                   
                   listConfig : {
                     minWidth:150,
                     itemTpl:'<div style="width:100%;padding-left:16px;height:18px;" title="{value}" class="xty_epob{epobType}">' + '&nbsp; {dscr}' + '<span style="color:#ccc;"> &nbsp;&nbsp;</span></div>'
                  },
                   
                   
                 displayField: 'dscr',
                 typeAhead: true,
                 mode: 'local',
                 triggerAction: 'all',
                 selectOnFocus:true 
              },

                                
              {xtype:'tbspacer', height:10}
              ]
            }
          ],

          buttons:[{xtype:'tbspacer', width:30},
            {text:'Weiter', disabled: cfg.isCSV, handler:function(button ){  
              button.ownerCt.ownerCt.hide(); 
             }
            },
            {text:'Abbrechen', handler:function(button ){button.ownerCt.ownerCt.hide();   }}
          ]      
      }) ;

      return importPresetDialog;
},

    


    
getNestedlistContainerCfg: function(cfg) {   
  var me = this;
  var myContentPanelHeight =  extVia.regApp.myRaster.getWest().getHeight() -52 ;

  
  var nestedGridData = {'items':[]};
    
    
  var isImportModule = cfg.listmodule.indexOf('import')>-1;  
  
  var isXMLImportModule = cfg.listmodule.indexOf('importxml')>-1;  
  var isCSVImportModule = cfg.listmodule.indexOf('importcsv')>-1;  
  
  var isImportFolderModule = cfg.listmodule.indexOf('importfolder')>-1;  
  
  
  var goUpFolder = { name:'&hellip;', type:'goup' }; 
  
  
if(cfg.listmodule==='webdav'){
  nestedGridData = {'items':[
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },
//  { name: 'Herbst',  type:'gif', size:'500k', time: '2018-02-12 11:58:58' },

    
    goUpFolder,
    
  { name:'Categories', type:'folder', size:'10 MB', time: '2017-05-12 07:01:07' },
  { name:'collectionWidg.psd', type:'psd', size:'500k', time: '2018-02-12 11:58:58', locked:true },
  { name:'Collections', type:'folder', size:'', time: '2018-02-12 11:58:58' },
  { name:'dashboardFullscreen.png', type:'png', size:'500k', time: '2018-01-13 21:16:16', locked:true },
  { name:'Matrix', type:'folder', size:'60 MB', time: '2018-01-13 21:16:16' },
  { name:'diff-tree_1.png', type:'png', size:'500k', time: '2018-02-11 08:08:08', locked:true },
  { name:'diff-tree_2.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
  { name:'dropzone-panel.txt', type:'txt', size:'500k', time: '2018-02-11 08:08:08' },
  { name:'embeddedQuery.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
  { name:'extendedSearchHd.gif', type:'gif', size:'500k', time: '2018-02-11 08:08:08' },
  { name:'frankLloydWright.jpeg', type:'jpeg', size:'500k', time: '2018-01-13 21:16:16' },
  { name:'Hierarchien', type:'folder', size:'0 mb', time: '2018-01-13 21:16:16' , locked:true},
  { name:'hierarchies.jpg', type:'jpg', size:'500k', time: '2018-01-13 21:16:16'},
  { name:'hierarchies_jungheinrich.png', type:'png', size:'500k', time: '2018-02-12 11:58:58', locked:true },
  { name:'historyTabCardViewEast.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
  { name:'metadatenBox_img.gif', type:'gif', size:'500k', time: '2018-02-12 11:58:58' }
//  { name:'Exportplanner', type:'folder', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'metadatenBox_prod.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'quicksearch.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'refline.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'refline-border.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'sammlungenWest.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'ScrollnaviOverviewBar', type:'folder', size:'500 MB', time: '2018-01-13 21:16:16' },
//  { name:'scrollnaviOverviewBar-both.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'scrollnaviOverviewBar-both_2.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'scrollnaviOverviewBar-both-1.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'success-strategies.jpg', type:'jpg', size:'1500k', time: '2018-02-12 11:58:58' },
//  { name:'success-strategies-portrait.jpg', type:'jpg', size:'1500k', time: '2018-02-12 11:58:58' },
//  { name:'tag_feuer.gif', type:'gif', size:'100k', time: '2018-02-12 11:58:58' },
//  { name:'tagcloud.gif', type:'gif', size:'100k', time: '2018-01-13 21:16:16' },
//  { name:'tagcloud.jpg', type:'jpg', size:'1500k', time: '2018-01-13 21:16:16' },
//  { name:'versioning-prodview-flat.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'versioning-prodview-matrix.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'versioning-prodview-preview.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'versioning-prodview-tree.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'editor-export-.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'editor-export-.psd', type:'psd', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'editor-export-settings.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'editor-export-source.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'editor-export-sourceAndSettings.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'editor-import.psd', type:'psd', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'editor-import-event-xml - Kopie.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'editor-import-event-xml.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'editor-import-once-xml - Kopie.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'editor-import-once-xml.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'Exportplanner-edit-intab.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'Exportplanner-new_01-source.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'Exportplanner', type:'folder', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'Importplanner-edit-intab.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'Importplanner-new_01-source.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'Importplanner-new_01-sourceFolder.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'Importplanner-new_02-settings.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'publicationtree.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'Unbenannt-1.png', type:'png', size:'500k', time: '2018-02-11 08:08:08' },
//  { name:'xml-editor.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'xml-editor.psd', type:'psd', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'XML-Export.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'XML-Export_01.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'XML-Export_02.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'XML-Export_03.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'XML-Export_04.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'xml-export-editor_01.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'xml-export-editor_01.psd', type:'psd', size:'500k', time: '2018-01-13 21:16:16' },
//  { name:'zz_import-once-xml-choose_00.png', type:'png', size:'500k', time: '2018-02-12 11:58:58' },
//  { name:'zz_import-once-xml-choose_01.png', type:'png', size:'500k', time: '2018-01-13 21:16:16' }

]};
}  





if(isImportModule){ 
  
  var importtype = 'xml' ;   
  if(isCSVImportModule){ importtype = 'csv'; }
  
  nestedGridData = {'items':[
    goUpFolder,
  
   { name:'Categories', type:'folder', size:'10 MB', time: '2017-05-12 07:01:07' },
   { name:'collectionWidg.'+importtype, type:importtype, size:'500k', time: '2018-02-12 11:58:58' },
   { name:'Collections', type:'folder', size:'', time: '2018-02-12 11:58:58' },
   
   { name:'resources_export_20181120.xml', type:'xml', size:'500k', time: '2018-11-20 21:16:16' },
   { name:'ReportExport_20181120_185419634.xml', type:importtype, size:'500k', time: '2018-02-12 11:58:58' },
   { name:'masterdata_eng_GBR_DICT_20180124.xml', type:importtype, size:'500k', time: '2018-02-12 11:58:58' },
   
   { name:'dashboardFullscreen.'+importtype, type:importtype, size:'500k', time: '2018-01-13 21:16:16' },
   { name:'diff-matrix_1.'+importtype, type:importtype, size:'500k', time: '2018-01-13 21:16:16' },
   { name:'Matrix', type:'folder', size:'60 MB', time: '2018-01-13 21:16:16' },
   { name:'diff-tree_1.'+importtype, type:importtype, size:'500k', time: '2018-02-11 08:08:08' },
   { name:'dropzone-panel.'+importtype, type:importtype, size:'500k', time: '2018-02-11 08:08:08' },
   { name:'embeddedQuery.'+importtype, type:importtype, size:'500k', time: '2018-02-12 11:58:58' },
   { name:'extendedSearchHd.'+importtype, type:importtype, size:'500k', time: '2018-02-11 08:08:08' },
   { name:'frankLloydWright', type:'zip', size:'50MB', time: '2018-01-13 21:16:16' },
   { name:'Hierarchien', type:'folder', size:'0 mb', time: '2018-01-13 21:16:16' },
   { name:'hierarchies.'+importtype, type:importtype, size:'500k', time: '2018-01-13 21:16:16' },
   { name:'hierarchies_jungheinrich.'+importtype, type:importtype, size:'500k', time: '2018-02-12 11:58:58' },
   { name:'historyTabCardViewEast.'+importtype, type:importtype, size:'500k', time: '2018-02-12 11:58:58' }
 ]};
}






  if(isImportFolderModule){ 
    
    nestedGridData = {'items':[

      goUpFolder,
      
    { name:'My Import', type:'folder', size:'500 MB', time: '2018-01-13 21:16:16' },
    { name:'Sonnenuntergang ', type:'jpg', size:'500k', time: '2018-01-13 21:16:16' , indentlevel: 1},
    { name:'tag_feuer.gif', type:'gif', size:'100k', time: '2018-02-12 11:58:58', indentlevel: 1 },
    { name:'Funkenfräse.png', type:'png', size:'500k', time: '2018-01-13 21:16:16', indentlevel: 1 },
    { name:'success-strategies.txt', type:'txt', size:'1500k', time: '2018-02-12 11:58:58', indentlevel: 1 },
    { name:'some.txt', type:'txt', size:'5k', time: '2018-02-12 11:58:58' , indentlevel: 1},

    { name:'', type:'', size:'', time: '' },
    
    { name:'My Import (after xml generated)', type:'folder', size:'500 MB', time: '2018-01-13 21:16:16' },
    { name:'Import_2018_10_29_17_44_06.xml', type:'xml', size:'500k', time: '2018-01-13 21:16:16', indentlevel: 1 },

    { name:'Neu', type:'folder',  foldertype:'generated', size:'500 MB', time: '2018-01-13 21:16:16', indentlevel: 1  },
    
    { name:'Bilder', type:'folder', foldertype:'generated', size:'500 MB', time: '2018-01-13 21:16:16', indentlevel: 2 },
    { name:'Sonnenuntergang ', type:'jpg', size:'500k', time: '2018-01-13 21:16:16', indentlevel: 3 },
    { name:'tag_feuer.gif', type:'gif', size:'100k', time: '2018-02-12 11:58:58', indentlevel: 3 },
    { name:'Funkenfräse.png', type:'png', size:'500k', time: '2018-01-13 21:16:16', indentlevel: 3 },

    
    { name:'Texte', type:'folder', foldertype:'generated', size:'500k', time: '2018-02-12 11:58:58', indentlevel: 2 },
    { name:'success-strategies.txt', type:'txt', size:'1500k', time: '2018-02-12 11:58:58' , indentlevel: 3},
    { name:'some.txt', type:'txt', size:'5k', time: '2018-02-12 11:58:58' , indentlevel: 3},
    
    
    { name:'', type:'', size:'', time: '' },
    { name:'My Zip Import', type:'zip', size:'500 MB', time: '2018-01-13 21:16:16' }
    
   ]};
 }

  
  
 
  
  
  
    var nestedGridStore =  Ext.create('Ext.data.Store', {
         storeId:'nestedGridStore-'+cfg.listmodule,
         fields:['name', 'type', 'size', 'time', 'locked', 'foldertype', 'indentlevel'],
         data: nestedGridData,
         proxy: {
             type: 'memory',
             reader: {
                 type: 'json',
                 root: 'items'
             }
         }
     });

  
     var nestedlistContainerItemId = Ext.id(null, 'nestedlist-container-'); 
     
     var showHideUploadZone = function(menuitem){
       var westTabPanel =  extVia.regApp.myRaster.getWestTabPanel() ;
       var nestedlistContainer = westTabPanel.getComponent(nestedlistContainerItemId);
       var uploadDropzone = nestedlistContainer.getComponent('upload-dropzone');
       if (uploadDropzone.hidden){
         uploadDropzone.show();
         if (menuitem) { 
           menuitem.setText('Upload ausblenden');
           menuitem.setIconCls('xty_menu-hide');
         }
         uploadDropzone.addCls('xty_panel-isVisible');
       }else{
         uploadDropzone.hide();
         if (menuitem) { 
          menuitem.setText('Upload');
          menuitem.setIconCls('x-tool-upload');
         }
         uploadDropzone.removeCls('xty_panel-isVisible');
       }
     };
     
     var nestedGridCfg = Ext.create('Ext.grid.Panel', {
         region:'center', 
         //title:'nestedGrid' , 
         cls:'xty_nestedGrid xty_nestedlist xty_nested-webdav-list',
         border:false,
         //height: 100,
         tbar :{ cls:'xty_nestedlist-breadcrumbbar',
           height: 30,
           defaults:{margin:'1 1 1 1'},
           hidden:true,
           items: [
           {xtype:'tbtext', text: '&nbsp;<span class="xty_crumb xty_linked-crumb ">WebDav</span>' },
           {xtype:'tbtext', text: '<span class="xty_breadcrumb-separator" >»</span>' },
           {xtype:'tbtext', text: '<span class="xty_crumb xty_linked-crumb ">Metabo</span>' },
           {xtype:'tbtext', text: '<span class="xty_breadcrumb-separator" >»</span>' },
           {xtype:'tbtext', text: '<span class="xty_crumb xty_linked-crumb ">Bilder</span>' },
           {xtype:'tbtext', text: '<span class="xty_breadcrumb-separator" >»</span>' },           
           {xtype:'tbtext', text: '<span class="xty_crumb xty_linked-crumb "><b>Bohrer</b></span>' }  
         ]
         },
         bbar:[{text:'+'}],
         store: nestedGridStore, 
         selModel: Ext.create('Ext.selection.CheckboxModel'),
         columns: [
             { header: ' ',  dataIndex: 'type',width:30,   
               renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                 metaData.tdCls='xty_icon-cell ';
                 
                 var  indentlevel = record.get('indentlevel');
                 if (indentlevel){
                   metaData.tdCls+=' xty_grid-cell-indent-'+indentlevel;
                 }
                 
                 if (record.get('type')==='goup'){
                   metaData.tdCls+=" xty_folderGoUp-cell ";
                   view.addCls('xty_nestedlist-hasfolderGoUp-row');
                 }
                  
                 
                 var  locked = record.get('locked');
                 var  readonly = record.get('readonly');
                 var modifierHtml ='';
                 if (locked){
                   metaData.tdCls='xty_icon-cell xty_locked-file';
                   modifierHtml = '<div class="xty_locked-modifier">&nbsp;</div>';
                 }
                 var cls ='xty_filetype xty_filetype-'+value;
                 if( value.indexOf('folder')>-1 ){
                   var  generatedfolder = false;
                   var  readonlyfolder = false;
                   var  foldertype = record.get('foldertype'); 
                   if (foldertype){
                     generatedfolder = foldertype.indexOf('generated')>-1; 
                     readonlyfolder = foldertype.indexOf('readonly')>-1; 
                   }

                   
                   var iconCls = ( locked || readonly) ? 'folder-readonly' :'folder'  ;    
                   cls ='xty_'+iconCls;
                   
                   if (generatedfolder){
                     cls+=' xty_generated-folder';
                   }
                   if (readonlyfolder || readonly){
                     cls+=' xty_folder-readonly';
                   }
                   
                 }
                 
                 var html =  '<div data-qtip="'+value+'" class="'+cls+'">&nbsp;'+modifierHtml+'</div>';
                 if (value===''){html=value;}
                 
                 return  html;
                 }  
             },
             
             { header: 'Name',  dataIndex: 'name',width:200  },
             { header: 'Datum', dataIndex: 'time', width:100,
               renderer: function(value){ 
                  var date = new Date(value);
                  var retDate = '';  
                  
                  try{ retDate = date.toLocaleString().replace(/:..$/,''); }
                  catch(ex){var jslintVarX = 'y';}
                  if (retDate==='Invalid Date'){
                    retDate = '';
                  }
                 
                    
                  return retDate; //date.toLocaleString().replace(/:..$/,''); 
                }
             },
             { header: 'Typ', dataIndex: 'type', width:50,
               renderer: function(value, metaData, record, rowIndex, colIndex, store, view){ 
                 
                 if (value==='goup'){
                   value='';
                   metaData.tdCls='xty_goup-folder-cell';
                   metaData.tdCls+=" xty_folderGoUp-cell ";
                 }
                 
                 return value;
               }
             
             },
             
             { header: 'Grösse', dataIndex: 'size',  width:80 }    
         ],

         listeners:{
           afterrender: function( grid){
           var gridEmptySpaceContextmenuHandler  = function ( evt, target){
             evt.preventDefault( ); // important to stop the browsers contextmenu
             // here you have to check if target.className or evt.target.className is ‘x-grid-view’
             // so you can be sure it is not an row rightclick,
             if (target.className &&  target.className.indexOf('x-grid-view')>-1  ){ 
              var emptySpaceContextmenu =   Ext.create('Ext.menu.Menu', {
                 renderTo: Ext.getBody(),
                 items: [ 
                   {iconCls:'xty_menu-goUp',  text:'Eine Ebene nach oben'} ,
                   '-',                   
                   {iconCls:'xty_pgtoolbar-add-folder',  text:'Neuen Ordner anlegen'} ,
                   {iconCls:'x-tool x-tool-paste', text:'Einfügen', disabled:true} ,
                   '-',
                   {iconCls: 'xty_menu-hide',  id:'showHideUploadMenu',  itemId:'showHideUploadMenu', text:'Upload ausblenden', handler: showHideUploadZone} 
                 ]
               });
              emptySpaceContextmenu.showAt(evt.getXY());
             }

           };
           var gridBodyEl =   Ext.get(grid.id+'-body');
           gridBodyEl.on('contextmenu', gridEmptySpaceContextmenuHandler);
           },
           'itemdblclick': function( view, record, item, index, evt, eOpts ){
               var type = record.get('type');

               var isFolder = type.indexOf('folder')>-1 ;
               var isGoupFolder =  type.indexOf('goup')>-1;

               var isFile = !isFolder && !isGoupFolder;
               
               if (isFolder){extVia.notify('open Folder');}
               if (isGoupFolder){extVia.notify('go up Folder');}
               if (isFile){
             
                 var name = record.get('name'); 
                 var is4Masterdata = name.toLowerCase().indexOf('masterdata')>-1;
                 var is4Reports = name.toLowerCase().indexOf('report')>-1;
                 var is4Resources = name.toLowerCase().indexOf('resources')>-1;
                 var module;
                 if (is4Masterdata){
                   module = 'Masterdata';
                 }
                 else if (is4Reports){
                   module = 'Reports Import';
                 }
                 else if (is4Resources){
                   module = 'Resource Import';
                 }
                 
                 if (!is4Masterdata && !is4Reports && !is4Resources ){
                   var  importPresetDialog = me.getImportPresetDialog({name:name, isXML:isXMLImportModule, isCSV: isCSVImportModule});
                   importPresetDialog.show();
                 }

                 me.showEditor({module: module, profile:extVia.nestedlistCurrentProfile}, record);
                 
               }
            },
  
           'itemcontextmenu': function( view, record, item, index, evt, eOpts ){
             evt.preventDefault();
             var type = record.get('type');
             var isFolder = record.get('type').indexOf('folder')>-1;
             if (isFolder){ 
               var  foldertype = record.get('foldertype'); 
               if (foldertype){
                 var generatedfolder = foldertype.indexOf('generated')>-1; 
                 if (generatedfolder){ // No contextmenu
                   return; 
                 }
               }
             }
             

             
             
             var isXMLFile = record.get('type').indexOf('xml')>-1;
             var isFile = ! isFolder;
            

            var  nestedlistFolderMenuItems = [
              {iconCls: 'x-tool x-tool-explore', text:'Öffnen'},
              {iconCls: '', text:'Umbenennen'},
              {text:'Neuen Ordner anlegen'},
              {text:'Löschen'},
              '-',
              {text:'Download'}
            ];
 
            var  nestedlistFileMenuItems = [
              {iconCls:'x-tool x-tool-view',  text:'Anzeigen'},
              {iconCls:'x-tool x-tool-cut', text:'Auschneiden'}, 
              {iconCls:'x-tool x-tool-paste', text:'Einfügen', disabled:true},
              {text:'Löschen'},
              '-',
              {text:'Download'}
            ];

            var openImortEditor = function (menuitem){
              
              var profile = menuitem.text;
              
              if (menuitem.uselistprofile){
                profile = extVia.nestedlistCurrentProfile;
              }
              
              
              me.showEditor({profile: profile}, record);
            };
            

            
            
            var  nestedlistItemMenuItems = [
              {iconCls: 'x-tool x-tool-view', text:'Öffnen', hidden: isFile},

              {iconCls:'x-tool x-tool-edit', text:'Umbenennen', hidden: isFile},
              {iconCls:'xty_pgtoolbar-add-folder', text:'Neuen Ordner anlegen', hidden: isFile},
              {iconCls:'x-tool x-tool-view',  text:'Anzeigen', hidden: isFolder || isXMLImportModule},

              { xtype: 'menuseparator'},
            
              
              {iconCls:'xty_menu-import',  text:'Ordnerinhalt importieren <span style="color:#888">(XML-Importdatei generieren)</span>', uselistprofile : true, hidden: !( isFolder  && isImportFolderModule) },
              
              {iconCls:'xty_menu-import',  text:'Importieren', uselistprofile : true, hidden: !(  isXMLFile && isImportFolderModule) },
              
              //{iconCls:'xty_icon xty_iconXMLFileExported',  text:'XML-Importdatei generieren', uselistprofile : true, hidden: !(isFolder && isImportFolderModule) },
              
              {iconCls:'xty_menu-translate',  text:'Übersetzungsimport', uselistprofile : true, hidden: !(isFolder && isImportFolderModule) },
              
              { xtype: 'menuseparator', hidden: !( isFolder  && isImportFolderModule) },
              
              {iconCls:'x-tool x-tool-cut', text:'Auschneiden', hidden: !( isFolder  && isImportFolderModule)}, 
              {iconCls:'x-tool x-tool-paste', text:'Einfügen', disabled:true, hidden: isFile},
              {iconCls:'x-tool x-tool-delete', text:'Löschen'}
//              '-',
//              
//              {iconCls:'xty_menu-import',  text:'Importieren', uselistprofile : true, hidden: !( (isFolder || isXMLFile) && isImportFolderModule) },
//              {iconCls:'xty_icon xty_iconXMLFileExported',  text:'XML-Importdatei generieren', uselistprofile : true, hidden: !(isFolder && isImportFolderModule) }

              
              //{iconCls:'x-tool x-tool-download', text:'Download'}
            ];
             var nestedlistItemMenu = Ext.create('Ext.menu.Menu', {
               margin: '0 0 10 0',
               items: nestedlistItemMenuItems//isFolder ? nestedlistFolderMenuItems : nestedlistFileMenuItems,
              });  
             nestedlistItemMenu.showAt(evt.getXY());
             }  
         }
         
     });
    
     
     var myContentPanelWidth =  extVia.regApp.myRaster.getWest().getWidth() ;

     extVia.nestedlistBreadcrumbClickHandler= function(el){  
      extVia.notify('nestedlistBreadcrumbClickHandler '+el.innerHTML);
     };
 
     extVia.nestedlistCurrentProfile = 'Standard';
     
     var changeCurrentProfile = function(menuitem){
       //nestedlistContainerItemId
       
       extVia.nestedlistCurrentProfile = menuitem.text;
       
     };


     var rootFolderDscr = '&#9750; &#8962; ';
     
    rootFolderDscr = '&#9750; '; // white shogi piece
    //rootFolderDscr = '&#9751; '; // black shogi piece
    
    rootFolderDscr =' &#128193  '; // open folder ;
    
    rootFolderDscr = '&#128025; '; // octopus
    
   // rootFolderDscr = ' &#10084;  '; // Heavy Black Heart
    
    //rootFolderDscr = '&#8962; '; // house,  is too small

     rootFolderDscr = '&#9050; ';  // APL Functional Symbol Diamond Underbar
    
     rootFolderDscr =' &#128193;  '; //  folder ;
    // rootFolderDscr = '&#127754; '; // water wave
     
    
     // &#127968;
     
    // rootFolderDscr = ' &nbsp; '; // diamond
     
     
     rootFolderDscr = ' Home '; 
     
     
     
     var nestedlistContainerCfg = {
              title : cfg.title,
              closable: cfg.closable,
              itemId: nestedlistContainerItemId,
              cls:'xty_nestedlist-container xty_webdav-nested-bin',
              layout:'border',
//              currentProfile:'Standard',
//              setCurrentProfile: function(profile){
//                this.currentProfile = profile;
//              },
//              getCurrentProfile; function(){return this.currentProfile; },

              tbar :{ cls:'xty_nestedlist-breadcrumbbar',
                listeners:{
                  resize: function( tbar ){        
                    var breadcrumbTbText = tbar.getComponent('breadcrumb');
                    var myContentPanelWidth =  extVia.regApp.myRaster.getWest().getWidth() ;
                    var edge =  myContentPanelWidth - 48;
                    if ( breadcrumbTbText.getWidth() >  edge ){ 
                      //alert('toolong')
                      tbar.addCls('xty_breadcrumb-toolong');
                    } 
                    else{
                      //alert('enough')
                      tbar.removeCls('xty_breadcrumb-toolong');
                    }
                   }
                  },
                defaults:{ overCls:'OFF'},
                items: [
                  {  
                    xtype:'tbtext', 
                    itemId:'breadcrumb',
                    cls:'xty_breadcrumb-tbtext',
                    text:    
                      '<span class="xty_crumb xty_linked-crumb" onclick="extVia.nestedlistBreadcrumbClickHandler(this);" >'+rootFolderDscr+'</span><span class="xty_breadcrumb-separator" > » </span>' +
                      '<span class="xty_crumb xty_linked-crumb" onclick="extVia.nestedlistBreadcrumbClickHandler(this);"  >Bohrmaschinen</span><span class="xty_breadcrumb-separator" > » </span>' +
                      '<span class="xty_crumb xty_linked-crumb" onclick="extVia.nestedlistBreadcrumbClickHandler(this);"  >Handgeführte</span><span class="xty_breadcrumb-separator" > » </span>' +
                      '<span class="xty_crumb xty_linked-crumb" onclick="extVia.nestedlistBreadcrumbClickHandler(this);"  >Produktbilder</span><span class="xty_breadcrumb-separator" > » </span>' +
                      '<span class="xty_crumb xty_linked-crumb" onclick="extVia.nestedlistBreadcrumbClickHandler(this);"  >Agentur</span>'  
                      
                  },
                //  '->',
                  
                { iconCls:' xty_icon xty_iconDownloading', cls:'xty_breadcrumb-more-btn',  text:'&nbsp;', arrsowAlign : 'top',  arrowCls : 'off',  width:24 },
                  
                  
                { iconCls:'xty_pgtoolbar-more ', cls:'xty_breadcrumb-more-btn',  text:'&nbsp;', arrsowAlign : 'top',  arrowCls : 'off',  width:24, heigsht:26,
                 
                  mEEenu:[ 
                    {xtype:'panel', width:236, id:'moremenu-progress-host2', items:[ 
                      ] },
                    ],
                  
                  menu:[ 
                    {xtype:'panel', width:236, id:'moremenu-progress-host', items:[me.getProgressDialog({dialogItemId:'progressDialogInMenu'}).items[0]  ] },
                    '-',
                    
                    {iconCls:'xty_menu-goUp',  text:'Eine Ebene nach oben'} ,
                    '-',
                    {iconCls:'xty_pgtoolbar-add-folder',  text:'Neuen Ordner anlegen'} ,
                    {iconCls:'x-tool x-tool-paste', text:'Einfügen', disabled:true} ,
                    '-',
                    {iconCls: 'xty_menu-hide',  text:'Upload ausblenden', handler: showHideUploadZone}
                    ]
                 } 
              ]
              },
              
              height: myContentPanelHeight+27,
              items:[
                { tXitle:'Upload Dropzone', 
                  itemId:'upload-dropzone', 
                  cls:'xty_dropzone-panel xty_panel-isVisible',
                  region:'north',  
                  height:122, 
                  split: true,
                  border:false, 
                  html: 
                    '<div style="" id="dropzone-webdav-nested" class="xty_dropzone-webdav-nested">'+
                      '<img o_nclick="extVia.regApp.showFileChooser();" style="margin-left: 16%; margin-top: -15px" height="140px"  src="../img/fakes/dropzone-panel.png"/>'+
                    '</div>',  
                  items:[   

                    {xtype:'button', text:' ✕  ', cls:'xty_upload-panel-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', 
                      style:'color:  background-color:white;background:none; border:0px; position:absolute; top:-4px; right: -3px;', 
                    
                      handler:function(btn){
                        showHideUploadZone();
                      }
                    },
                    
                    
                    {
                    xtype: 'filefield', border:false,
                    itemId:'filechooser',
                    style:'position:absolute; top:84px; left:22px; opacity:0;',
                    cls:'xty_dropzone-filefield',
                    name: 'filefield',
                    allowBlank: false,
                    buttonText: 'Browse Files'
                   }
                  ]  
                },
                nestedGridCfg
                ]               
              };     
       
     
     return nestedlistContainerCfg;

    },
    
    
    
  getImportsTabCfg: function(cfg){   
   var me = this; 
    
   var importsStore = Ext.create('Ext.data.Store', {
      storeId:'importsStore',
      fields:['type', 'name', 'email', 'phone'],
      data:{'items':[
          { 'name': 'Lisa',  "email":"lisa@simpsons.com",  "phone":"555-111-1224"  },
          { 'name': 'Bart',  "email":"bart@simpsons.com",  "phone":"555-222-1234" },
          { 'name': 'Homer', "email":"home@simpsons.com",  "phone":"555-222-1244"  },
          { 'name': 'Marge', "email":"marge@simpsons.com", "phone":"555-222-1254"  }
      ]},
      proxy: {
          type: 'memory',
          reader: {
              type: 'json',
              root: 'items'
          }
      }
  });

  var importslistCfg = {
      xtype:'grid',
      border:false,
      store: Ext.data.StoreManager.lookup('importsStore'),
      columns: [
          { header: 'Name',  dataIndex: 'name' }
      ]
   };
    
  
  var importsTabCfg = {
     title:'Importe',
     height: me.getWestListHeight(),
     tbar:[
     '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}
     ],
    
     closable:true,
     items:[
       importslistCfg
     ]
   };
  
  
    return importsTabCfg;
  },
    
    
  initWest: function(){  
    
    var me = this;
    var webdavNestedTab = me.getNestedlistContainerCfg({
      title:'Webdav',
      listmodule:'webdav',
      closable:true
    });
    
    
    var importXMLNestedTab = me.getNestedlistContainerCfg({
      title:'Exported Reports',
      //closable:true,
      listmodule:'importxml'
    });
    

    var importCSVNestedTab = me.getNestedlistContainerCfg({
      title:'CSV-Import',
      closable:true,
      listmodule:'importcsv'
    });
    
  
    var importFolderNestedTab = me.getNestedlistContainerCfg({
      title:'Importfolder',
      closable:true,
      listmodule:'importfolder'
    });
    
    
  //  var importsTabCfg = me.getImportsTabCfg({});
    

    
    var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
      activeTab: 2,  
      tabBar:{ 
          tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
          handler:function(button){
            var activeTab = button.ownerCt.ownerCt.getActiveTab();
              extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
            }
           }
          ]
        },
        items:[importFolderNestedTab, webdavNestedTab, importXMLNestedTab, importCSVNestedTab  ]
        });
       extVia.regApp.myRaster.addToWest(tabPanWest);
       
    //   me.initWestTreeTab();
     

},


showProgressDialog: function(){ 
  var me = this;
  
//  var progressDialogAtBtn  =  me.getProgressDialog({dialogItemId:'progressDialogAtBtn'}); 
//  progressDialogAtBtn.show();
//  var progressDialogBottom  =  me.getProgressDialog({dialogItemId:'progressDialogBottom'}); 
//  progressDialogBottom.show();
  
},
    
getProgressDialog: function(cfg){

  var me = this;
  
  //var yPos = me.getContentPanelHeight()+60;
  var yPos = me.getContentPanelHeight()+88; // preventHeader
  var xPos = me.getWestWidth()-216;
  
  if (cfg.dialogItemId==='progressDialogBottom'){

  var progressbarDownload = Ext.create('Ext.ProgressBar', { itemId:'downloadProgressBar', width:200 });
  progressbarDownload.wait({
    interval: 500, //bar will move fast!
    duration: 50000,
    increment: 10,
    text: 'Downloading... 6/66',
    scope: this,
    fn: function(){
      progressbarDownload.updateText('Done!');
    }
  });
  
  var progressbarUpload = Ext.create('Ext.ProgressBar', { itemId:'uploadProgressBar', width:200 });
  progressbarUpload.wait({
    interval: 500, //bar will move fast!
    duration: 50000,
    increment: 15,
    text: 'Uploading... 7/77',
    scope: this,
    fn: function(){
      progressbarUpload.updateText('Done!');
    }
  });
  
  var progressbarMove = Ext.create('Ext.ProgressBar', { itemId:'moveProgressBar', width:200 });
  progressbarMove.wait({
    interval: 500, //bar will move fast!
    duration: 50000,
    increment: 20,
    text: 'Moving... 3/10',
    scope: this,
    fn: function(){
      progressbarMove.updateText('Done!');
    }
});
  

  var progressDialogBottom  = Ext.create('Ext.window.Window', {
    
  itemId:'progressDialogBottom',
 
  //title: 'Upload, Download, Move',
  closable:false,
  //tools:[{id:'minimize', tooltip:'minimize'}],
  preventHeader:true,
  //y:126, // near more button,
  y: yPos,
  x: xPos,
  
  width: 248,
  layout: 'fit',
  
  items: [
    
    {  
      xtype: 'form',
      border: false,
      defaults:{
        margin:'4 4 4 4'
      },
      
      items:[
        {xtype:'fieldcontainer', layout:'hbox', items:[progressbarDownload, {xtype:'button',  margin:'0 0 0 2', height:20,  width:22, tooltip:'Cancel', style:'fosnt-size:14px;', text:'✕'}]},
        {xtype:'fieldcontainer', layout:'hbox', items:[progressbarUpload, {xtype:'button',  margin:'0 0 0 2', height:20,  width:22, tooltip:'Cancel', style:'fosnt-size:14px;', text:'✕'}]},
        {xtype:'fieldcontainer', layout:'hbox', items:[progressbarMove, {xtype:'button',  margin:'0 0 0 2', height:20,  width:22, tooltip:'Cancel', style:'fosnt-size:14px;', text:'✕'}]}
      ]  
  }]
 });
 //progressDialogBottom.show();
  return progressDialogBottom;
  
  }
 
 
  if (cfg.dialogItemId==='progressDialogAtBtn' || cfg.dialogItemId==='progressDialogInMenu' ){
 
    
  var inMenu = cfg.dialogItemId==='progressDialogInMenu';
    
 var progressbarDownload2 = Ext.create('Ext.ProgressBar', { itemId:'downloadProgressBar', width:200 });
 progressbarDownload2.wait({
   interval: 500, //bar will move fast!
   duration: 50000,
   increment: 8,
   text: 'Downloading... 6/66',
   scope: this,
   fn: function(){
     progressbarDownload2.updateText('Done!');
   }
 });
 
 var progressbarUpload2 = Ext.create('Ext.ProgressBar', { itemId:'uploadProgressBar', width:200 });
 progressbarUpload2.wait({
   interval: 500, //bar will move fast!
   duration: 50000,
   increment: 12,
   text: 'Uploading... 7/77',
   scope: this,
   fn: function(){
     progressbarUpload2.updateText('Done!');
   }
 });
 
 var progressbarMove2 = Ext.create('Ext.ProgressBar', { itemId:'moveProgressBar', width:200 });
 progressbarMove2.wait({
   interval: 500, //bar will move fast!
   duration: 50000,
   increment: 22,
   text: 'Moving... 3/10',
   scope: this,
   fn: function(){
     progressbarMove2.updateText('Done!');
   }
});
 
 var progressDialogAtBtnCfg  =  {
   title: 'Upload, Download, Move',
   itemId:'progressDialogAtBtn',
   //closable:false,
   tools:[{id:'minimize', tooltip:'minimize'}],
   //preventHeader:true,
   y: inMenu? null : 126, // near more button,
   x: inMenu? null : xPos+200,
   width: 248,
   layout: 'fit',
   items: [
     {  
       xtype: 'form',
       border: false,
       defaults:{
         margin:'4 4 4 4'
       },
       
       items:[
         {xtype:'fieldcontainer', layout:'hbox', items:[progressbarDownload2, {xtype:'button',  margin:'0 0 0 2', height:20,  width:22, tooltip:'Cancel', style:'fosnt-size:14px;', text:'✕'}]},
         {xtype:'fieldcontainer', layout:'hbox', items:[progressbarUpload2, {xtype:'button',  margin:'0 0 0 2', height:20,  width:22, tooltip:'Cancel', style:'fosnt-size:14px;', text:'✕'}]},
         {xtype:'fieldcontainer', layout:'hbox', items:[progressbarMove2, {xtype:'button',  margin:'0 0 0 2', height:20,  width:22, tooltip:'Cancel', style:'fosnt-size:14px;', text:'✕'}]}
       ]  
   }]
  };
 
 var progressDialogAtBtn  = Ext.create('Ext.window.Window', progressDialogAtBtnCfg);
 
 
 //progressDialogAtBtn.show();
    return inMenu ? progressDialogAtBtnCfg :  progressDialogAtBtn ;
  }
  
},






getImportProgressDialog: function(cfg){

  var me = this;
  
  //var yPos = me.getContentPanelHeight()+60;
  var yPos = me.getContentPanelHeight()+88; // preventHeader
  var xPos = me.getCenterWidth()-216;
 

  var progressbarImport = Ext.create('Ext.ProgressBar', { itemId:'importProgressBar', width:200 });
  progressbarImport.wait({
    interval: 500, //bar will move fast!
    duration: 50000,
    increment: 10,
    text: 'Importing... 6/66',
    scope: this,
    fn: function(){
      progressbarImport.updateText('Done!');
    }
  });


  var progressDialogImport  = Ext.create('Ext.window.Window', {
  itemId:'progressDialogImport',
  title: 'Import',
  closable:false,
  //tools:[{id:'minimize', tooltip:'minimize'}],
  //preventHeader:true,
  y: 30,
  x: 1200,
  width: 248,
  layout: 'fit',
  items: [
    {  
      xtype: 'form',
      border: false,
      defaults:{
        margin:'4 4 4 4'
      },
      items:[
        progressbarImport
      ]  
  }]
 });
  
  progressDialogImport.show();
  
  return progressDialogImport;  
  

},





  showFileChooser: function(){
    var fileChooserPanelCfg = {
    height: 500,
    width: 800,
    xtype:'panel',
    layout: 'border',
    items: [
      {region:'west',  margin:'2 0 2 2',  split:true,  width:200, collapsible:true, title:'user pc file tree',
       xitems:[{tistle:'user pc file tree', border:false}]  
      },
      { region:'center',  margin:'2 2 2 0', title:'user pc file folder',
        items:[
          //{title:'user file folder',  border:false,}
//          
//          { 
//            xtype: 'grid',
//            border: false,
//            columns: [{header: 'World'}],                 // One header just for show. There's no data,
//            store: Ext.create('Ext.data.ArrayStore', {}) // A dummy empty data store
//        }
        ]  
      }
      ]
    };

    var fileChooserDialog =   Ext.create('Ext.window.Window',         
      {
        title: 'Dateien wählen',
        cls:'xty_filechooser-dialog',
        height: 500,
        modal:true,
        //x:460,
        y:120,
        width: 800,
        layout: 'fit',
        border:false,
        items: [
          fileChooserPanelCfg 
//          
//          { 
//            xtype: 'grid',
//            border: false,
//            columns: [{header: 'World'}],                 // One header just for show. There's no data,
//            store: Ext.create('Ext.data.ArrayStore', {}) // A dummy empty data store
//        }
          ],
       buttons:[ {text:'Hochladen', disabled:true}, {text:'Abbrechen', handler:function(btn){ btn.ownerCt.ownerCt.hide();}}]
      }
      );
    fileChooserDialog.show();
    },

    
    showEditor: function(cfg, record) {
      var me = extVia.regApp;
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();  
      var epob = {epobId:'folder_1', dscr:'Herbst Bilder', epobsType:'folder'};
      
      if (record){ 
        epob = {dscr: record.get('name')}; //.replace(/.xml/,'')};
      }
      var epobDscr  = epob.dscr;  
      
      
//      if (cfg.profile){
//        //epobDscr +=' &raquo; '+cfg.profile;
//      }
      
      extVia.regApp.myRaster.getWestTabPanel().addCls('xty_herbstbilderON');
      
      var importEditorPagetoolbarButtons =  [
        {itemId:'check', tooltip:'prüfen', hiddedn:true},
        {itemId:'import', enableToggle:true, tooltip:'Importieren', 
        
        handler: function(){
          me.getImportProgressDialog();
        }
        },
        //{ itemId:'tree', handler: me.showFileChooser, tooltip:'Dateien wählen'}, 
        { itemId:'clear', tooltip:'Zurücksetzen',  hidden:true}
       ] ;
      
      //epobDscr = 
      
      var pgjobDscr = cfg.module ? cfg.module : 'XXX';
      
      
      var is4Masterdata = pgjobDscr.toLowerCase().indexOf('masterdata')>-1;
      var is4Reports = pgjobDscr.toLowerCase().indexOf('report')>-1;
      var is4Resources = pgjobDscr.toLowerCase().indexOf('resources')>-1;

      
      var importEditorAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: pgjobDscr , epobDscr: epobDscr,    
        pgjobButtons: [  ], 
        pagetoolbarButtons: importEditorPagetoolbarButtons } );
   
      var importEditorPanel  = {
        title: epobDscr, 
        itemId:'editorPanel-'+epobDscr, 
        
        closable:true, tbar: importEditorAppbar,

         defaults:{
           margin:'24 24 24 24',
           collapsible:true,
           width:580,
           xtype: 'form'
         },                       
         items:[  
           
           
           
//           {title:'Upload Dropzone', height:280,  hidden:true,
//             items:[  
//               { border:false,  html: '<img onclick="extVia.regApp.showFileChooser();" style="margin-left:80px;" height="220px"  src="../img/fakes/dropzone-panel.png"/>'},
//               { xtype: 'filefield', border:false,
//                 cls:'xty_dropzone-filefield',
//                 width:310,
//                 name: 'filefield',
//                 allowBlank: false,
//                 buttonText: 'Browse Files'
//               } ]
//           },
           
           

           
           
           
//           {title:'Importprofil',
//             defaults:{
//               margin:'4 4 4 4',
//               xtype: 'textfield',
//               labelWidth:180,
//               width:360
//            }, 
//            items:[ {  
//                xtype:'combo',
//                itemId:'importprofile',   margin:'0 0 0 16',
//              store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
//              data :  [ ['Default'],  ['Profil 1'],  ['Profil 2'], ['Profil 3']]
//              }) ,                              
//             displayField: 'dscr',
//             typeAhead: true,
//             value:'Default',
//             mode: 'local',
//             triggerAction: 'all',
//             selectOnFocus:true 
//          }
//            ]
//           },
           

           
           
          {title:'Importeinstellungen', heisght:400, //collapsed:true,
             defaults:{
               margin:'4 4 4 4',
               xtype: 'textfield',
               labelWidth:180,
               width:360
            },  
            items:[

              
              {xtype: 'checkboxgroup', fieldLabel:'Masterdata Types',
                hidden:  !is4Masterdata ,
                itemId:'masterdataTypes' ,
                layout:'vbox', height: 66,
                items:  [
                    {boxLabel:'Categories'},
                    {boxLabel:'Selection Groups'},
                    {boxLabel:'Dictionaries'}  
                 ]
               }, 
              
              
              
              {xtype: 'checkboxgroup', fieldLabel:'Reports',
               labelSeparator: extVia.dialoges.getLabelSeparator4Required(),
               allowBlank: false,
               hidden:  !is4Reports ,
               itemId:'availableReports' ,
               layout:'vbox', height:152,
               items:  [
                   {boxLabel:'Select All', margin:'0 0 4 0'},
                   {boxLabel:'Report 1'},
                   {boxLabel:'Report 2 '},
                   {boxLabel:'Report 3'},
                   {boxLabel:'Report 4'},
                   {boxLabel:'Report 5 '},
                   {boxLabel:'Report 6'}   
                ]
              }, 
              
              
             // {xtype: 'displayfield', fieldLabel:'Importdatei', value:record.get('name')}, 
              {xtype: 'displayfield', hidden: is4Reports , fieldLabel:'Source Language', value : 'German', margin:'8 4 4 4'},
             // {xtype: 'displayfield',  hiddsen: !is4Masterdata && !is4Reports , fieldLabel:'Target Language', value : 'English', margin:'4 4 12 4' },

              {  
                xtype:'combo', hidden: is4Reports,
                labelSeparator: extVia.dialoges.getLabelSeparator4Required(),
                allowBlank: false,
                fieldLabel:'Target Language', 
                itemId:'importprofile',   //margin:'0 0 0 16',
              store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
              data :  [  ['German'],  ['French'], ['English']]
              }) ,                              
             displayField: 'dscr',
             typeAhead: true,
             //value:'Default',
             mode: 'local',
             triggerAction: 'all',
             selectOnFocus:true 
          },
              
              
          {xtype: 'checkboxgroup', fieldLabel:'Changed objects', hidden: !is4Masterdata,
            itemId:'changedObjects' ,  margin:'8 4 4 4' ,
            width:420,
            items:  [
                {boxLabel:'Skip Import of changed Objects'}
             ]
           },
              
              
//              {xtype: 'displayfield', fieldLabel:'Status', value:'nicht ausgeführt' },
//              
//              
//              {xtype: 'displayfield', value:'<b>Import Einstellungen<b>',  margin:'8 4 4 4'},  
//              
//              {xtype: 'checkboxgroup',  fieldLabel:'Elemente', width:540, items:[{xtype: 'checkbox', boxLabel:'neue Elemente anlegen', checked :true}, {xtype: 'checkbox', boxLabel:'vorhandene überschreiben', checked :true}]},
//              
////              {xtype: 'checkbox', fieldLabel:'neue Elemente anlegen', checked :true},
////              
////              {xtype: 'checkbox', fieldLabel:'vorhandene überschreiben', checked :true},
//              
//              {xtype: 'combo', fieldLabel:'Sprache (Neuanlage)'},
//              
//              {xtype: 'displayfield', value:'<b>Sammlung<b>',  margin:'8 4 4 4'}, 
//              {xtype: 'combo', fieldLabel:'Hinzufügen zur Sammlung'},
//              {xtype: 'textarea', fieldLabel:'Notiz', width:420 }
          
           
           
           {xtype: 'tbspacer', height: 2}
           
           
           ]  
          } 
        ] 
      };
      tabPanCenter.addAndActivate(importEditorPanel);         
    },
    
    
    
    showRequiredPreviewDialog: function(cfg) {
      var dropzoneImportfolderPanel = Ext.get('dropzoneImportfolder');
      var diaBodyPosX = dropzoneImportfolderPanel.getX();
      var diaBodyPosY = dropzoneImportfolderPanel.getX();
      var mainInstr ='Sie müssen noch ein Preview f&uuml;r <i>'+cfg.filename+'</i> &nbsp;hochladen';   
       var win =   Ext.create('Ext.window.Window', {
           title: 'Upload',
           y: diaBodyPosY-324,// 110,
           x: diaBodyPosX-7, //395,
           height: 360,
           width: 594,
           cslosable:false,
           dragsgable:false,
           layout: 'fit',  modal:true,  
           items:[
             {
               border : false,
               itemId : 'instructionPanel',
               setMainInstruction:function(instruction){
                 var instructionPanel = this;
                 var mainInstructionPanel = instructionPanel.getComponent('mainInstruction');
                 mainInstructionPanel.getEl().dom.firstChild.innerHTML =   '<div class="xty_dialog-mainInstr">'+instruction +'</div>';
               },
               setSupplementalInstruction:function(instruction){
                 var instructionPanel = this;
                 var supplementalInstructionPanel = instructionPanel.getComponent('supplementalInstruction');
                 supplementalInstructionPanel.getEl().dom.firstChild.innerHTML =   '<div class="xty_dialog-supplementalInstr">'+instruction+'</div>';
               },
               listeners:{
                 close:function(){
                    extVia.notify('Nixda mit dingen');
                 }
               },
               width:'100%',
               items : [ {
                 itemId : 'mainInstruction',
                 border : false,
                 margin:'4 4 4 4',
                 style : 'padding: 8px 8px 16px 4px',
                 // Better use XTEMPLATE
                 html : '<div class="xty_dialog-mainInstr">'+mainInstr +'</div>'
               } ]
             }
           ],
           buttons:[{text:'Upload abbrechen', handler:function(btn){btn.ownerCt.ownerCt.hide(); extVia.notify({mssg:'Upload von <i>'+cfg.filename+'</i> abgebrochen', action: 'Upload abbrechen'});}}] 
       }).show(); 
    },
    
    
    launch: function() {
      if (window.File && window.FileReader && window.FileList && window.Blob) {
        // Great success! All the File APIs are supported.
        var jslintAlibi =1;
      } else {
        extVia.notify('The File APIs are not fully supported in this browser.');
      }

      
      
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      var me = this;

      
      var  modulDscr = '';


      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.constants.raster.mainWestWidth = 360;
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);

      me.initWest();
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
        handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
        iconCls:'x-tool x-tool-refresh'}]  } 
      });

      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 



        var importProtocolePanelCfg = {
          title:'Importe',
          closable: true,
          height:me.getCenterHeight()+80,
          // >>> PROD V4 Start (EPIM-7678) <<<
          html : '<iframe width="100%" height="'+me.getCenterHeight()+80+'px" id="importProtocolsIFRAME"  frameborder="0" src="http://192.0.2.1/viaMEDICI/ajsp/Forward.jsp?p_sFromPage=ImportsListMain&p_sPageType=List&p_sStartIndex=0&p_sIncrement=40" ></iframe>'
          // >>> PROD V4 End (EPIM-7678) <<<
          
        };
      
      
       //tabPanCenter.addAndActivate(importProtocolePanelCfg); 

       
        me.showProgressDialog();
        
        
//       var nestedListAppbar = extVia.ui.page.pagejob.getApplicationBar( { 
//         pgjobDscr:'Nested List', epobDscr: 'Nested List',  
//         breadcrumb: "WebDav/Metabo/Bilder/Wilder/Filter/Akku-Bohrschrauber", 
//         pgjobButtons: [{itemId:'tree', handler:me.showFileChooser, tooltip:'Dateien wählen'},{itemId:'upload',  tooltip:'Epim Objekte erstellen', margin:'0 4 0 0', enableToggle:true,  xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}}] } 
//       );
//       var nestedListPanel = {title:'Nested List', tbar: nestedListAppbar, closable:true,
//       defaults:{
//         margin:'24 24 24 24',
//         width:580
//       },                       
//       items:[  
//         { height:250, collapsible:false, border:false,
//           html: '<div style="" id="dropzone-nestedList"></div>' 
//         }
//       ]
//       };
//       tabPanCenter.add(nestedListPanel);
//
//       function handleDragOver(evt) {
//         evt.stopPropagation();
//         evt.preventDefault();
//         evt.dataTransfer.dropEffect = 'copy'; // Explicitly show this is a copy.
//         var dropZoneEl = Ext.get('dropzone-importfolder');
//         dropZoneEl.addCls('xty_dropzone-over');
//       }
//       
//       function handleDragLeave(evt) {
//         var dropZoneEl = Ext.get('dropzone-importfolder');
//         dropZoneEl.removeCls('xty_dropzone-over');
//       }
//       
//       // Setup the dnd listeners.
//       var dropZone = document.getElementById('dropzone-importfolder');
//       dropZone.addEventListener('dragover', handleDragOver, false);
//       dropZone.addEventListener('drop', me.handleFileSelect, false);
//       dropZone.addEventListener('dragleave', handleDragLeave, false);
//       dropZone.addEventListener('click', me.showFileChooser, false);
      
    }
});



/*
 * 
 * $Revision: 1.7.2.45 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2019/12/16 13:38:27 $
 * $Author: aross $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 
