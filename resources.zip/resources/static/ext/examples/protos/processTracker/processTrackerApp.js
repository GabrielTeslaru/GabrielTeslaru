/*


*/
Ext.application({
    name: 'processTrackerApp',
    
    /**
     * Place 
     */
    appMode:{},

    testFakeBridge : function(){
    	
        // ///////////////////// CALLBACK START //////////////////////////
        var myfirstCallback = function(result, ex) {
          if (ex) { extVia.notifyException("myfirstCallBack", ex);} 
          else {//DO WHAT YOU HAVE TO DO
        	var resultStr  = ( typeof result === 'string') ?  result : Ext.encode(result[0]);
        	var notifyHtml = resultStr;

	        extVia.showNotification({
	  	      status : 'Success',
	  	      cls: 'ux-notification-light',
	  	      position: 'tr',
	  	      title : extVia.regApp.name+ " myfirstFakeCallBack",
	  	      html : notifyHtml,
	  	      width:600,
	  	      hideDelay : 3800
	  	    });
  
          }
        };
        /////////////////////// CALLBACK ENDE //////////////////////////
        
       jjbridge.callRemote(this, 'yourHandler', 'getEpobDummyData', [], myfirstCallback);
    	
    },
    
 
	getProcessTypeStore : function(cfg){ 
		var store = Ext.data.StoreManager.lookup('ProcessTypeStore');
		if (!store){
	        var model = Ext.define('ProcessType', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}] });
	        var data = [ {value: 'process', dscr: 'Prozess',id: '1'} , {value: 'action',dscr: 'Aktion',id: '2'} , {value: 'task', dscr: 'Aufgabe',id: '3'}  ];
	        store = Ext.create('Ext.data.Store', { storeId:'ProcessTypeStore', model: model,data: data});  
		}
    	return store;	
	},
    
	getProcessStateStore : function(cfg){ 
		var store = Ext.data.StoreManager.lookup('ProcessStateStore');
		if (!store){
	        var model = Ext.define('ProcessState', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}] });
	        var data = [ 
	                     {value: 'RUNNING', dscr: 'laufend',id: '0'} , 
	                     {value: 'FINISHED',dscr: 'beendet',id: '10'} , 
	                     {value: 'Success', dscr: 'beendet mit Erfolg',id: '1'}  ,
	                     {value: 'FINISHED_ERROR', dscr: 'beendet mit Fehler',id: '2'}  ,
	                     {value: 'FINISHED_WARNING', dscr: 'beendet mit Warnung',id: '2'}  ,
	                     {value: 'ABORTED', dscr: 'Abgebrochen',id: '3'}  ,
	                     {value: 'Stopped', dscr: 'Gestoppt',id: '12'}  ,
	                     {value: 'Inactive', dscr: 'Inaktiv',id: '23'}  ,
	                     {value: 'PAUSED', dscr: 'Pausiert',id: '13'}  ,
	                     {value: 'Locked', dscr: 'Gesperrt',id: '14'}  ,
	                     {value: 'TIMEOUT', dscr: 'Zeit&uuml;berschreitung',id: '4'},  
	                     {value: 'FAILED', dscr: 'Fehlgeschlagen',id: '5'} ,
	                     {value: 'Unchecked', dscr: 'Leer',id: '52'} 
	                     ];
	        store = Ext.create('Ext.data.Store', { storeId:'ProcessStateStore', model: model,data: data});  
		}
    	return store;	
	},
    
	getInterfaceToStore : function(cfg){ 
		var store = Ext.data.StoreManager.lookup('InterfaceToStore');
		if (!store){
	        var model = Ext.define('InterfaceTo', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}] });
	        var data = [ {value: 'xml', dscr: 'XML Import',id: '1'} , {value: 'csv',dscr: 'CSV Import',id: '2'} ,{value: 'export',dscr: 'Export',id: '2'} , {value: 'jobscheduler', dscr: 'Job Scheduler',id: '3'}  ];
	        store = Ext.create('Ext.data.Store', { storeId:'InterfaceToStore', model: model,data: data});  
		}
    	return store;	
	},
    
    
	getIntervallStore : function(cfg){ 
		var store = Ext.data.StoreManager.lookup('intervallStore');
		if (!store){
	        var model = Ext.define('Intervall', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}] });
	        var data = [ {value: '5', dscr: '5 sec',id: '1'} , {value: '10',dscr: '10 sec',id: '2'} , {value: '20', dscr: '20 sec',id: '3'} , {value: '30',dscr: '30 sec',id: '4'} , {value: '60',dscr: '60 sec',id: '5'}  ];
	        store = Ext.create('Ext.data.Store', { storeId:'intervallStore', model: model,data: data});  
		}
    	return store;	
	},
    
    
    
    
    initQueryPanel : function(){

    	extVia.ui.layout.region.West = {
    			labelWidth: 118,
    			DEF: 192
    	};
    	
    	
    	extVia.currentRegion = extVia.ui.layout.region.West;
    	

        var queryContainer = {
          xtype: 'form',  // container
          itemId: 'queryContainer',
          border: false,
          padding: '0 0 5 0',
          layout: {
            type: 'table',
            columns: 3
          },
          defaults:{
            
            labelWidth: extVia.currentRegion.labelWidth,
            width:  extVia.currentRegion.labelWidth + extVia.currentRegion.DEF -70,
            margin: '4 0 0 0'
          },
          items: [
          {
            xtype: 'textfield',
            itemId: 'searchterm',
            name: 'searchterm',
            
            fieldLabel : extVia.locales.searchterm,
            colspan: 2
          }, {
            xtype: 'splitbutton', 
            itemId: 'searchButton', 
            name: 'searchButton', 
            tooltip:extVia.locales.search,
            scale: 'large',
            iconCls: 'xty_pgtoolbar-search',
            margin: '4 0 0 10',
            width: 58,
            height: 50,
            rowspan: 2,
            colspan: 1,
            handler: function(button, evt){
 
            	var formValues = Ext.encode(button.ownerCt.getForm().getValues()).replace(/,/g ,",<br>") ; 
            	
    	        extVia.showNotification({
    		  	      status : 'Inactive',
    		  	      cls: 'ux-notification-light',
    		  	      position: 'tr',
    		  	      title : extVia.regApp.name+ " search click",
    		  	      html : 'Implement the search<br>'+formValues
    		  	    });
            }
          },
          
          
          {
              xtype: 'textfield',
              itemId: 'processId',
              name: 'processId',
              
              fieldLabel : extVia.locales.processId,
              colspan: 2
            },
          
//          
//          {
//            xtype: 'checkbox',
//            itemId: 'searchtermAsRegex',
//            name: 'searchtermAsRegex',
//            boxLabelAlign: 'before',
//            fieldLabel:  extVia.locales.searchtermAsRegex,
//            checked : false,
//            colspan : 2
//          }, 
          {
            xtype: 'datefield',
            fieldLabel:  extVia.locales.startdate,
            itemId: 'startdate',
            name: 'startdate',
            disabled: false,
            format : 'd-m-Y',
            colspan: 2
           }, 
           { xtype: 'timefield',  triggerCls:'xty_form-trigger-timefield', itemId: 'starttime', name: 'starttime',  margin: '4 0 0 10', colspan: 1 , width:58, format:'H:i'},
           {
            xtype: 'datefield',
            fieldLabel:  extVia.locales.enddate,
            itemId: 'enddate',
            name: 'enddate',
            format : 'd-m-Y',
            marsgin: '7 0 5 0',
            maxValue: new Date(),
            minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -89),
            colspan: 2
//           emptyText : 'TT-MM-JJJJ',
//           anchor: '100%'
            },
           { xtype: 'timefield', itemId: 'endtime',  triggerCls:'xty_form-trigger-timefield', name: 'endtime',  margin: '4 0 0 10', colspan: 1 , width:58, format:'H:i'},
           
           
           { xtype: 'combo',  cls : 'xty_form-iconCombo xty_iconNOVAL',  trigger2Cls : 'x-form-trigger', trigger1Cls : 'xty_form-trigger-iconCombo',   itemId: 'state', name: 'state', fieldLabel: extVia.locales.state, width:  extVia.currentRegion.labelWidth + extVia.currentRegion.DEF-2 ,

        	   listeners : {
            	   
                render:function(){
               		var trigger2DIV = Ext.query('#'+this.id+' DIV[class~="'+this.trigger2Cls+'"]')[0].id; 	
               		var trigger2El = Ext.get(trigger2DIV);
               		trigger2El.setStyle({borderTop:'1px solid #b5b8c8'});
               		trigger2El.setStyle({borderRight:'1px solid #b5b8c8'});
               		trigger2El.setStyle({borderLeft:'0px solid #FFF'});
               		this.trigger2El = trigger2El;	
               	},
            	focus:function(){this.trigger2El.setStyle({borderColor:'#7eadd9'});}, 
            	blur:function( field, eOpts ){this.trigger2El.setStyle({borderColor:'#b5b8c8'});},  
            	   
               change : function(field, newValue, oldValue) {
                   this.trigger2El.addCls('xty_icon'+newValue);
                   this.trigger2El.removeCls('xty_iconNOVAL');
                   this.trigger2El.removeCls('xty_icon'+oldValue);
                 }
                 
               },
        	   
        	   
                   listConfig : {
                	   minWidth:150,
                       getInnerTpl : function(displayField) {
                         var tpl = '<div style="width:100%;padding-left:16px;" class="xty_icon xty_icon{value}">' + '&nbsp; {dscr}' + '</div>';
                         return tpl;
                       }
                     },
        		   
        		   
        	   store:this.getProcessStateStore() ,  queryMode: 'local',displayField: 'dscr',  valueField: 'value', colspan: 3},        

           { xtype: 'combo',  itemId: 'interfaceTo',name: 'interfaceTo', fieldLabel: extVia.locales.interfaceTo,
        	   store:this.getInterfaceToStore() ,  forceSelection:true, queryMode: 'local',displayField: 'dscr',  valueField: 'value', colspan: 3 },
           
           { xtype: 'combo',  itemId: 'type',name: 'type', fieldLabel: extVia.locales.type,
        	   store:this.getProcessTypeStore() ,  queryMode: 'local',displayField: 'dscr',  valueField: 'value', colspan: 3 },	   
        	   
           { xtype: 'combo',  itemId: 'refreshIntervall',name: 'refreshIntervall', fieldLabel: extVia.locales.refreshIntervall,
        	   store:this.getIntervallStore() ,  queryMode: 'local',displayField: 'dscr',  valueField: 'value', colspan: 3,  margin: '14 0 0 0' }
           ]
        };
        return queryContainer;
    },
    
    
    getProcessTreeGridPanel : function(){
    	 //we want to setup a model and store instead of using dataUrl
        Ext.define('ExternalProcessModel', {
            extend: 'Ext.data.Model',
            fields: [
                {name: 'epobDscr',     type: 'string'},
                {name: 'epobTypeDscr', type: 'string'},
                {name: 'processId', type: 'string'},
                {name: 'epobId', type: 'number'}, // Database Id
                {name: 'epobParentId', type: 'number'}, // Database Id

                {name: 'user',     type: 'string'},
                {name: 'duration', type: 'string'}
            ]
        });

        var store = Ext.create('Ext.data.TreeStore', {
            model: 'ExternalProcessModel',
            storeId:'externalProcesses',

            // >>> PROD V4 Start (EPIM-7678) <<<
            proxy: {
                type: 'ajax',
                //the store will get the content from the .json file
                //url: '../../tree/treegrid.json',
                url: 'processes.json'
            }           
            // >>> PROD V4 End (EPIM-7678) <<<
        });

        //Ext.ux.tree.TreeGrid is no longer a Ux. You can simply use a tree.TreePanel
        var tree = Ext.create('Ext.tree.Panel', {
        	id:'externalProcessesTreeGrid',
        	itemId:'externalProcessesTreeGrid',
        	//tbar: {border:false,items: [{margin:'0 0 0 2',xtype:'textfield'}]},
        	border:false,
        	preventHeader:true,
            height: 400,
            collapsible: true,
            useArrows: true,
            rootVisible: false,
            store: store,
            multiSelect: true,
            //singleExpand: true,
            //the 'columns' property is now 'headers'
            columns: [
                      
            {
                xtype: 'treecolumn', //this is so we know which column will show the tree
                text: 'Name',
                width:200,
                sortable: true,
                dataIndex: 'epobDscr'
            },
            { text:  extVia.locales.type, dataIndex: 'epobTypeDscr', width:60 },
            
            { text:  extVia.locales.processId, dataIndex: 'processId',  width:60 , align:'center', width:60},
            
            
            { text:"EPIM-Id", dataIndex: 'epobId', align:'center', width:60},// Database Id
            { text:"Eltern-Id", dataIndex: 'epobParentId' ,align:'center', width:60},// Database Id
            
            
            { text: '&Aumlnderung'  },
           
            { text: 'Zeit'  },
            { text: extVia.locales.state  },
            { text: 'Hierarchie'  },
            { text: extVia.locales.description },
           
            { text:  extVia.locales.interfaceTo },
            { text: 'Anwendung'  },
            { text: 'Start'  },
            { text: 'Ende'  },
            
            {
                //we must use the templateheader component so we can use a custom tpl
                xtype: 'templatecolumn',
                text: 'Duration',
                flex: 1,
                sortable: true,
                dataIndex: 'duration',
                align: 'center',
                //add in the custom tpl for the rows
                tpl: Ext.create('Ext.XTemplate', '{duration:this.formatHours}', {
                    formatHours: function(v) {
                        if (v < 1) {
                            return Math.round(v * 60) + ' mins';
                        } else if (Math.floor(v) !== v) {
                            var min = v - Math.floor(v);
                            return Math.floor(v) + 'h ' + Math.round(min * 60) + 'm';
                        } else {
                            return v + ' hour' + (v === 1 ? '' : 's');
                        }
                    }
                })
            },{
                text: 'Assigned To',
                flex: 1,
                dataIndex: 'user',
                sortable: true
            }],
            
            listeners:{
            	itemclick:  function ( treePanel, record, item, index, e, eOpts ){
                 var detailsPanel =  extVia.regApp.myRaster.getCenter().getComponent('detailsPanel');
                 detailsPanel.setDisabled(false);
                 var pagejobbar = detailsPanel.getComponent('pagejobbar');
                 
                 var epobdscr = pagejobbar.getComponent('epobdscr');
                 epobdscr.setText('<span  class="xty_pgjobEpobDscr">'+record.data.epobDscr+'</span>');

                 // Should be done by pagejobbar.setEpobDscr

                 
            	}
            },
        
        
        	filterByProp:function(filterProp,newValue, oldValue){

				   var tree = Ext.getCmp('externalProcessesTreeGrid');
				   
				   var filteredNodes = [];
				   
				   if(newValue !== oldValue){
					   var treeNodes = tree.getRootNode().childNodes;
					    Ext.each(treeNodes, function(n) {
					      var el = Ext.fly(tree.getView().getNodeByRecord(n));
					      if (el != null && !el.isDisplayed()) {
					        el.setDisplayed(true);
					        el.expand();
					      }
					    });

					    filteredNodes = [];
				   }
				    
				    var regExp = new RegExp(Ext.String.escapeRegex(newValue.toLowerCase()), 'i');
				    var visibleSum = 0;

				    
				    var filterTreeByProp = function(node, filterProp, value) {
				      
				    	if (!filterProp){filterProp = 'epobDscr';}
				    	
				    	if (node.hasChildNodes()) {
				        visibleSum = 0;
				        var nodeName = null;
				        node.eachChild(function(childNode) {
				          nodeName = childNode.data[filterProp].toLowerCase();
				          if (childNode.isLeaf()) {
				            if (!regExp.test(nodeName)) {
				              filteredNodes.push(childNode);
				            } else {
				              visibleSum++;
				              childNode.expand();
				            }
				          } else if (!childNode.isLeaf()) {// folder
				            childNode.expand();
				            if (regExp.test(nodeName)) {
				              visibleSum++;
				            }
				            
				            if(!childNode.hasChildNodes() && regExp.test(nodeName)) {
					            visibleSum++;
					         }
				            
				          } else {
				        	  filterTreeByProp(childNode);
				          }
				        });
				        if (visibleSum === 0 && !regExp.test(node.data[filterProp].toLowerCase())) {
				          filteredNodes.push(node);
				        }
				        else{node.expand();}
				      } else if (!regExp.test(node.data[filterProp].toLowerCase())) {
				        filteredNodes.push(node);
				      }
				      else{node.expand();}
				    	
				    	
				    };

				   tree.getRootNode().cascadeBy(filterTreeByProp);
				   Ext.each(filteredNodes, function(n) {
				        var el = Ext.fly(tree.getView().getNodeByRecord(n));
				        if (el !== null && !n.neededForPath) {
				          el.setDisplayed(false);
				        }
				    });

        	}
        

        });
    	
        return tree;
    },
    
    getProcessTreeFilterCombo : function(){

	     var filterComboCfg = {
			   triggerCls:'xty_form-trigger-filter',
			   xtype:'combo',
			   displayField: 'dscr',
			   name:'processesFilterCombo',
			   id:'processesFilterCombo',
			   validator:function(val){
			    	  try {new RegExp(val);return true;}
			    	  catch(rgxEx){return "Die Eingabe ist nicht Regex-konform<br>"+rgxEx;}
			   },
			    queryMode: 'local',
			    mode: 'local',
			    value:'',
			    autoCompleteInsert:extVia.stores.inputTextautoCompleteInsert,
			    store:   
				   Ext.create('Ext.data.Store', {   
					            model:  Ext.define('QuickSearchField', {
					    	    fields: ['value','dscr'],
					    	    extend: 'Ext.data.Model'
					    	})
				   }) ,
			   
				   listeners:{
				
					   specialkey:  extVia.stores.inputTextautoCompleteInsertonEnter,
					   
					   change:function( combo, newValue, oldValue, eOpts ){
						   var tree = Ext.getCmp('externalProcessesTreeGrid');
						   tree.filterByProp('epobDscr',newValue, oldValue);
						   }
				   }
	   };
	   return  filterComboCfg;
    	
    },
    
    
    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	
    	extVia.regApp = this;
    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside

    	var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true});
    	extVia.ui.page.raster.onReady(this);
	        	

  
    	
    	var  queryPanel = this.initQueryPanel();

    	var tabPan = extVia.regApp.myRaster.initWestTabPanel({items:[{title:'Recherche',bodyPadding: 10,items:[queryPanel]},{title:'Prozesse'}] });
    	extVia.regApp.myRaster.addToWest(tabPan);
    	

 	     
 	    
 	    var pagejobButtons = [this.getProcessTreeFilterCombo(), {itemId:'tree', tooltip:extVia.locales.asTree},{itemId:'list', tooltip:extVia.locales.asList},{itemId:'refresh', tooltip:extVia.locales.refresh}];
    	var pagetoolbarButtons = [{itemId:'new'},{itemId:'save'},{itemId:'back'}];
    	
 
    	var appbar = extVia.ui.page.pagejob.getPagejobBar( { pgjobDscr:extVia.locales.appName, epobDscr:extVia.locales.overview,  pgjobButtons: pagejobButtons } );
    	extVia.regApp.myRaster.addToCenter({tbar :appbar});

    	extVia.regApp.myRaster.addToCenter(this.getProcessTreeGridPanel());
    	
    	
    	
        var detailsPan  = Ext.create('Ext.panel.Panel', {
        	disabled:true,
        	itemId:'detailsPanel',
            tbar : extVia.ui.page.pagejob.getPagejobBar( { pgjobDscr:"Details", epobDscr:"Prozess" } )
          });
        extVia.regApp.myRaster.addToCenter(detailsPan);
    	
    	//this.testFakeBridge();
    	
    }
});



/*
 * 
 * $Revision: 1.18.6.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2019/12/10 08:32:21 $
 * $Author: lowen $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
