/**
 * @classextVia.panel.FakePanel
 * 
 * A Panel with an image (fakesketch) in the background, and some click buttons positioned over it.
 * Useful for quick lofi prototyping.
 * 
 * @author Simon Lederer, Viamedici Software GmbH
 */
Ext.define('extVia.panel.FakePanel',{
  
    extend : 'Ext.panel.Panel',
    alias : 'widget.fakepanel',
    
    cls:'xty_fake-panel',
  border:false,
  bodyStyle:'background-color:transparent;', 
  layout: 'absolute',
     
  constructor : function(config) {

    var backgroundSize= config.backgroundSize?'background-size:'+config.backgroundSize+';':'';
    var backgroundPosition= config.backgroundPosition?'background-position:'+config.backgroundPosition+';':'';  
    if (config.hasPanelHeader){
      backgroundPosition='background-position:0px 24px;';
      config.height+=24;
    }
      this.style='background-image:url('+config.fake+');background-repeat:no-repeat;background-color:transparent;'+backgroundSize+backgroundPosition;
    this.callParent(arguments);
    return this;
    
  }, 
  
  
  setFake:function(fake){
    var thisEl = Ext.get(this.id);  
      if (thisEl){
        thisEl.setStyle('backgroundImage','url("'+fake+'")');
      } 
  },
  
  
  defaults:{
     xtype:'button',
     style:'backgXXXround-color: transparent;opacity:0.5;',
     scxale:'large',
     //height:32,
     width:32,
     bordser:false,
     iconAlssign:'right',
     
     handler:function(item){

       var epobType ='';
       if (item.typeId) {
         epobType = extVia.module.epob.getEpobTypeFromTypeId(item.typeId);
       }
       
       var htmlStr = epobType+' '+ item.epobDscr+' '+'<br> clicked  at '+item.x + '-'+item.y;
       
        Ext.create('widget.uxNotification', {
        title:'clicked' ,
        position: 'tr',
        manager: 'instructions',
        cls: 'ux-notification-light',
        iconCls: 'ux-notification-icon-information',
        html :  htmlStr,  
        slideInAnimation: 'bounceOut',
        slideBackAnimation: 'easeIn'
      }).show();
     },
     cls:'xty_fake-panel-clicker',
     //html: '<div style="position:absolute; top:-14px;" class="xty_pulse"></div>',height:20,
     //html:'<div class="xty_pulse-marker"><div class="xty_pulse"></div></div></div>',height:20,
     x:280
  }
  }
);