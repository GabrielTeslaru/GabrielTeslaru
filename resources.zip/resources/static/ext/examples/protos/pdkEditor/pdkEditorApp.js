




Ext.application({

    name: 'pdkEditor',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      //var centerWidth = centerPan.getWidth()-50;
      var centerHeight = centerPan.getHeight()-92; // ohne pagetoolbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=86;
      }
      if (cfg && cfg.hasSubtabs){
        //centerHeight-=86;
      }      
      return centerHeight;
    },
    

    
    launch: function() {
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      me = this;
      var  modulDscr = 'PDK Editor';
      var epobDscr = 'Alle';
      
//      try{
//      alert(' extVia.dummies.pdkeditor.SYNC_Nodes '+ Ext.encode(extVia.dummies.pdkeditor) );
//      } catch(ex){alert(ex)}
      
      
    Array.prototype.move = function (old_index, new_index) {
	    if (new_index >= this.length) {
	        var k = new_index - this.length;
	        while ((k--) + 1) {
	            this.push(undefined);
	        }
	    }
	    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
	    return this; // for testing purposes
    };
      
      
      
      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      
      extVia.constants.raster.mainWestWidth = 360;
      
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);

      
      var pgjobStartBtn = {itemId:'start', scale:'large', xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}};
      var pgjobStopBtn = {itemId:'stop', scale:'large'};
      
      var pagejobButtons = [pgjobStartBtn,pgjobStopBtn];
      
      
      
      
      var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
      


      
      
      
      
   Ext.create('Ext.data.Store', {
    storeId:'simpsonsStore',
    fields:['name', 'changedate', 'size'],
    data:{'items':[
        { name: 'Do it s',  changedate:"26.09.2016 17:09",  size:"111 kb"  },
        { name: 'Change dies und das',  changedate:"27.09.2016 11:09",  size:"555 kb" },
        { name: 'Copy all', changedate:"28.09.2016 12:09",  size:"222 kb"  },
        { name: 'Search and Destroy', changedate:"29.09.2016 11:55", size:"666 kb"  }
    ]},
    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            root: 'items'
        }
    }
});

		var jobchainsGrid = Ext.create('Ext.grid.Panel', {
		   itemId:'jobchainsGrid',
           border:false,
		   store: Ext.data.StoreManager.lookup('simpsonsStore'),
		    columns: [
                //{ header: 'Typ',  datasIndex: 'name', width:32 },
		        { header: 'Name',  dataIndex: 'name' ,  flex: 1},
		        { header: 'Ge�ndert', dataIndex: 'changedate', width:100 },
                { header: 'Gr�sse', dataIndex: 'size', width:50 },
                { header: 'Kunden', dataIndex: 'client', wixdth:40 , 
                  renderer: function(){
                    var clientsHtml = 
                      '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
                        '<span class="xty_tag" title="Muppets">Muppets</span>' +
                        '<span class="xty_tag" title="Puppets" >Puppets</span>' +
                      '</span>';
                    return clientsHtml;
                  }
                }
		    ],
		    height: 200,
		    width: 400
		});
      
      
      
      var jobchainsList = {
          title:'Jobketten',
          itemId:'jobchainsList',
          tbar:[
          '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'L�schen', handler: me.deleteEpobDialog}
          ],
          items:[ jobchainsGrid ] 
          };

 
          
          
      var jobchainTab = { 
        title:'Jobketten-Baum', 
        //closable:true,
        itemId:'jobchainTab',
        tbar:[
          
          '->',    {iconCls: 'xty_pgtoolbar-list'}, {iconCls: 'xty_pgtoolbar-new', itemId:'new'}, {iconCls: 'xty_pgtoolbar-edit',itemId:'edit'},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete'}
          ]
         // items:me.getAssetsTypesListItems()
          }    
          
          
      var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
          tabBar:{ 
            tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
            handler:function(button){
              var activeTab = button.ownerCt.ownerCt.getActiveTab();
                extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
              }
             }
            ]
          },
          
          items:[jobchainsList, jobchainTab]
          
          ,listeners:{      

          }

          });
      extVia.regApp.myRaster.addToWest(tabPanWest);


        // Your App
        var pdkAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Standorte', epobDscr:null,   pagetoolbarButtsons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
        var pdkPanel = {title:'Distribution �bersicht',closable:true,  tbar: pdkAppbar, items:[{html:'hello Distributions App', margin:'24 24 24 24'}] }
        //extVia.regApp.myRaster.addToCenter(appPanel); //  set BaseRaster modulDscr to null
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel(  {
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
       handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
      iconCls:'x-tool x-tool-refresh'}]  } });
      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      tabPanCenter.add(distributionsPanel);

      

      pagejobButtons =  ['->' ,pgjobStartBtn, pgjobStopBtn] ;
      
      var appbarAssetOverviewTypes = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Jobketten Bausteine' , epobDscr: 'Alle ',   pagetoolbarButxxtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var assetTypesOverviewPanel  = {title:'Bausteine',  tbar: appbarAssetOverviewTypes, xiconCls: 'xty_icon xty_iconPlanned',
        items:[  ] 
        
      };
      tabPanCenter.add(assetTypesOverviewPanel);    




      
      

      
      
    }
});



/*
 * 
 * $Revision: 1.3 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2016/11/16 14:36:37 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
