/*


*/
Ext.application({
    name: 'resources App',
    
    /**
     * Place 
     */
    appMode:{},

    
    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)), //7 days from now
    	}));
    	extVia.regApp = this;
    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside
    	var  modulDscr = 'Resource Manager'
    	var epobDscr = 'my Resources';
    	
    	
    	var viewCfg = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscXXr:modulDscr});
    	extVia.ui.page.raster.onReady(this);

    	var pagejobButtons = [{itemId:'tree'},{itemId:'list'},{itemId:'back'}];
    	var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
    	var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:modulDscr, epobDscr:epobDscr,   pagetoolbarButtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
    	
	// Need some west?	
    	var tabPan = extVia.regApp.myRaster.initWestTabPanel({
    	  items:[
    	   
    	    {title:'Suche', xtype:'form',
    	      
    	     defaults:{margin:'4 4 4 4'},
    	     items:[
    	       {xtype:'textfield', fieldLabel:'resource value'},
    	       {xtype:'textfield', fieldLabel:'resource key'}
    	     ]  
    	    },
    	    {title:'Liste',tbar:[{iconCls:'plus'}]},
    	   
    	    {title:'tab 3'}
    	    ] 
    	});
    	extVia.regApp.myRaster.addToWest(tabPan);


    	
    	
//    	
//    	Ext.define('extVia.InfinityGrid',{
//    	  extend : 'Ext.grid.Panel',
//    	  alias:'widget.infinitygrid',
//    	  componentCls : 'xty_infinitygrid'
//    	});
//    	
//      Ext.define('extVia.VersionGrid',{
//        extend : 'extVia.InfinityGrid',
//        alias: 'widget.versiongrid',
//        componentCls : 'xty_infinitygrid xty_versiongrid'
//      });
    	
    	
    	
    	// Your App
	var appPanel = {tbar :appbar, items:[{html:'hello resources', margin:'24 24 24 24'}] }
        extVia.regApp.myRaster.addToCenter(appPanel); //  set BaseRaster modulDscr to null
    	

    	// Need some center Tabs?
    	//appPanel.closable=true;
    	//appPanel.title=epobDscr;
    	//var tabPan = extVia.regApp.myRaster.initCenterTabPanel();
    	//extVia.regApp.myRaster.addToCenter(tabPan);
    	//tabPan.add(appPanel);

    	
    }
});



/*
 * 
 * $Revision: 1.1.6.3 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/06/22 12:44:34 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
