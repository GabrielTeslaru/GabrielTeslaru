Ext.namespace('extVia.locales' ,'extVia.resourcesProto.locales');
/**
 * @class extVia.resourcesProto.locales
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/03/28 14:34:53 $
 *            $Revision: 1.1.6.1 $
 */

extVia.resourcesProto.locales = {
        appName:'resourcesProto',
};

Ext.apply(extVia.locales, extVia.resourcesProto.locales);



/*
 * 
 * $Revision: 1.1.6.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/03/28 14:34:53 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 