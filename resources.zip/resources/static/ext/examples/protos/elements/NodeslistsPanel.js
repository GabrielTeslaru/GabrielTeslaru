/**
 * @author S.Lederer (s.lederer@viamedici.de)
 * 
 * Creates a Panel with nodes and inside lists
 */
Ext.define('extVia.ux.widgets.NodesListsPanel', { //  NodesViewsPanel ... list is just one view
  extend : 'Ext.panel.Panel',
  componentCls : 'xty_nodeslistsPanel',
  alias:  'widget.nodeslistspanel',
  border:false,
  bodyBorder:false,
  //closable:true,
  
  
  cls:'xty_nodePanel-flyout-panel  xty_palette-arrow-top xsty_palette-arrow-top-default ',
  
  //headerPosition : 'left',
  
  //tbar:[{text:' ✕   '}],
  
  // layout: 'accordion',
  
  
  bbar:{ itemId: 'bottombar',
    cls:'xty_nodeslistspanel-bbar',
    height: 28,
    items: [ '->' , 
  
//    {itemId:'more',  text:'&#9013',
//     handler: function(button){
//       //articelStore.add( getArticels(2));
//     }
//    
//    }, 

    {itemId:'pagingFirst', text:' &nbsp;&#10094;&#10094; &nbsp;', tooltip:'first', disabled:true},
    {itemId:'pagingPrev', text:' &nbsp;&#10094; &nbsp;', tooltip:'previous', disabled:true},
    {itemId:'pagingNext', text:' &nbsp;&#10095; &nbsp;',tooltip:'next'},
    {itemId:'pagingLast', text:' &nbsp;&#10095;&#10095; &nbsp;',tooltip:'last'}
    
    ,'->'
    ]
},


//resizable:true,



defaults: {
  // applied to each contained panel
  //bodyStyle: 'padding:15px',
  
  //height: 200,
  width: 396
  
},




  
  constructor : function(config) {
    var me = this;
   

    var searchval = config.searchValue;
    if(!searchval){
      searchval = '';
    }
    
   var searchtype ='';
   var nodes = [      
     
     'Bohr<i>' +searchval.toLowerCase() +'</i>ine 666',
     
     'Mensch <i>' +searchval +'</i>ine xyz',

     'Stahl <i>' + searchval.toLowerCase() +'</i>ine 999',
     
     '<i>' + searchval +'</i>inenbau',
       
     //'Productgroup',
     'Product','Product',
     'Productvariante','Product','Product','Product','Product','Product',
     'Product','Product','Product','Product','Product','Product',
     'Productvariant','Productvariant','Productvariant'
     ];
    
   me.nodes = nodes;
    
    
    
   
   var itemsPerPage = 15;   // set the number of items you want per page
   var nodesStore = Ext.create('Ext.data.Store', {
       id:'simpsonsStore',
       autoLoad: false,
       fields:['name', 'collapsed'],
       pageSize: itemsPerPage, // items per page
       data: nodes,
       prssoxy: {
           type: 'ajax',
           url: 'pagingstore.js',  // url that will load data with respect to start and limit params
           reader: {
               type: 'json',
               root: 'items',
               totalProperty: 'total'
           }
       }
   });
   // specify segment of data you want to load using params
//   nodesStore.load({
//       params:{
//           start:0,
//           limit: itemsPerPage
//       }
//   });
   
   
   
    me.bbar = {
      height: 32, 
        xtype: 'pagingtoolbar',
        cls:'xty_nodeslistspanel-pagingbar',
        store: nodesStore,   // same store NodeslistPanel is using
        beforePageText :'',
        afterPageText :'/ {0}',
        displayMsg : '{0} - {1} / {2}',
        displayInfo: true ,
        prependButtons : true,
        defaults: {cls:'xty_nodeslistspanel-pagingbar-item'},
        buttons:[{xtype:'tbfill'},{xtype:'tbspacer', width:80}]
    };
    
    
    
    
    me.toggleAll =  function(collapse){  
      var items = me.items;
      var i;
      for (i=0; i < items.length; i++){ 
        var nodesPanel = items.getAt(i);
        nodesPanel.toggleCollapse();
      }
    };

    me.expandAll =  function(collapse){  
      var items = me.items;
      var i;
      for (i=0; i < items.length; i++){ 
        var nodesPanel = items.getAt(i);
        nodesPanel.expand();
      }
    };
    me.collapseAll =  function(collapse){  
      var items = me.items;
      var i;
      for (i=0; i < items.length; i++){ 
        var nodesPanel = items.getAt(i);
        nodesPanel.collapse();
      }
    };
    
    
    var querybehaviourItemHandler = function(item){
  //    if(!queryCfg.filters){
  //     queryCfg.filters=[];
  //    }
     };

    me.tbar ={ 
               
        cls:'xty_nodeslistspanel-tbar',       
        items: [

        {itemId:'sorting', cls:'xty_nodeslistspanel-sort-btn',  tooltip:'Sort DESC', text:'&#9013;', heisght:20 , margin:'0 0 0 6', arrowCls:'',
         menu:[

           {text:'<b>Sortierung</b>'},
           {text:'Aufsteigend',checked:true, handler :querybehaviourItemHandler, itemId:'sort-asc', group:'SORT', value:'ASC'},
           {text:'Absteigend', handler :querybehaviourItemHandler, itemId:'sort-desc', group:'SORT', value:'DESC'},
           '-',
           {text:'&Auml;nderungsdatum', checked:true,handler :querybehaviourItemHandler, itemId:'sortby-changedate', group:'SORTBY', value:'CHANGEDATE'},
           //{text:'Erstellungsdatum', handler :querybehaviourItemHandler, itemId:'sortby-creationdate', group:'SORTBY', value:'CREATIONDATE' },
           {text:'Name',handler :querybehaviourItemHandler, itemId:'sortby-name', group:'SORTBY', value:'NAME'},
           {text:'Typ',handler :querybehaviourItemHandler, itemId:'sortby-type', group:'SORTBY', value:'TYPE'}
           
         ]
        
        
        },
        
       // {itemId:'sortDown', text:'&#9013;', height:20, style:'-webkit-transform: rotate(180deg);' },
       
        '->',
//        {xtype:'button', 
//          
//          //text: '&#8634;',
//          text: '&#8635;', //'&#8634;', // '&#10690;',// '&#10227;',
//          margin:'2 2 2 2', cls:'xty_nodeslistspanel-refresh-btn', width:24, height:24 ,overCls:'', pressedCls:'refresh-pressed',   focusCls:'fokuhila', 
//          handler:function(btn){
//          
//          }
//        },


        
        {xtype:'button',  itemId:'collapseall', tooltip:'Collapse all',  masrgin:'2 2 2 2', 
          cls:'xty_nodeslistspanel-expandall-btn', iconCls:'xty_nodeslistspanel-collapseall', overCls:'', pressedCls:'', 
        
          handler:function(btn){
           var toolbar =  btn.ownerCt;
           var nodeslistPanel =  btn.ownerCt.ownerCt;
           btn.hide();
           toolbar.getComponent('expandall').show();
           nodeslistPanel.expandAll(false);
          }
        },
        
        {xtype:'button', hidden:true,  itemId:'expandall', tooltip:'Expand all',  masrgin:'2 2 2 2', 
          cls:'xty_nodeslistspanel-expandall-btn', iconCls:'xty_nodeslistspanel-expandall', overCls:'', pressedCls:'', 
        
          handler:function(btn){
            var toolbar =  btn.ownerCt;
            var nodeslistPanel =  btn.ownerCt.ownerCt;
            btn.hide();
            toolbar.getComponent('collapseall').show();
            nodeslistPanel.collapseAll(true);
           
          }
        },
        
        {xtype:'button', text:' ✕   ', itemId:'close', margin:'2 2 2 2', cls:'xty_nodeslistspanel-close-btn xty_propsearch-extended-picker-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', 
          handler:function(btn){
            btn.ownerCt.ownerCt.hide();
          }
        }
    ]};


  me.listeners={


  afterrender: function(nodelistspanel){


    
   var nodes = me.nodes;

    
    var dropHandler = function(node, data, dropRec, dropPosition) {
      //alert('NodelistsPanel dropHAndler');
      
      var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
      //Ext.example.msg("Drag from right to left", 'Dropped ' + data.records[0].get('name') + dropOn);
      extVia.notify({action:'Drag from right to left'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
   };
    
   
   
   
   
   var   BoundListItem_userChannelTeaserTpl =  new Ext.XTemplate(
     '<div class="xty_teaser-thumbnail-bin" style="position: absolute; ">' +      
     '<img class="xty_teaser-thumbnail xty_teaser-default-thumbnail" src="{imgSrc}" style="background-color:#efefef; height:40px; width: 40px; border:1px solid #d0d0d0; margin-top: 0px;"  >' +
    '</div>' + 
    '<div class="xty_teaser-text xty_teaser-text-twoLines <tpl if="isnew">xty_teaser-isnew</tpl>" style="height:24px; margin-left:44px" >' +
      '<span class="xty_teaser-title" >{title} </span> ' +
      '<span class="xty_teaser-author" >{author} </span> ' +
      '<span class="xty_teaser-summary" >{summary}</span>' +
    '</div>' +
    '<div class="xty_teaser-text xty_teaser-iconAndDate-bin" >' +
    

     '<span class="xty_pinfo-datatype xty_epob{epobType}" title="{epobType}" style="border-bottom:3px solid transparent; position:relative; left: 44px; top: -8px; msin-height:28px; hesight:18px; " >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>' + 
    
      '<span class="xty_teaser-format <tpl if="formats && formats[0]">xty_teaser-format-{[values.formats[0].toLowerCase()]}" title="{epobType}</tpl>" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>' + 
      '<span class="xty_teaser-date" >{changedate}' +
        '<tpl if="isnew">' +
         '<span class="xty_teaser-isnew-star" title="{isnew}" >&nbsp;&nbsp;</span>' +
        '</tpl>'+
      '</span>' +
      '<tpl if="categories">' +
        '<span class="xty_teaser-categories xty_teaser-{[values.categories.length>7?"many":values.categories.length]}-categories"  >' +
          '<tpl for="categories">'+    
           '<span class="xty_teaser-category" title="{.}">{.}</span>'+
          '</tpl>'+ 
        '</span>' +
      '</tpl>'+
    '</div>'
      );
   

   
   
   
//  var nodeModel =  Ext.define('Node', {
//     extend: 'Ext.data.Model',
//     fields: [
//         {name: 'id',   type: 'int'},
//         {name: 'name', type: 'string'},
//         {name: 'epobType', type: 'string'}
//     ],
//     // we can use the hasMany shortcut on the model to create a hasMany association
//     hasMany: {model: 'Child', name: 'children'}
// });
   
   
   
   
   
   var dataObjectModel =  Ext.define('DataObject', {
     extend: 'Ext.data.Model',
     //fields: ['name', 'imgSrc', 'epobType', 'childOf', 'column1', 'column2']
     fields: [{'name':'name'},{'name':'imgSrc'},{'name':'epobType'},{'name':'childOf'}, {'name':'expanded'}, {'name':'column1'},{'name':'column1'}]
   });
   
   

   var moreBtnHandler = function(btn){
     var bar = btn.ownerCt;   
     //bar.getComponent('plus').hide();
     //bar.getComponent('minus').show();
     bar.getComponent('more').hide();
     bar.getComponent('restore').show();
     bar.getComponent('restorespacer').show();
     bar.getComponent('filter').show();
     bar.getComponent('sorting').show();
     var grid = bar.ownerCt;
     grid.maximize(grid);  
   };
   var restoreBtnHandler = function(btn){
     var bar = btn.ownerCt;
     bar.getComponent('restore').hide();
     bar.getComponent('restorespacer').hide();
     //bar.getComponent('minus').hide();
     //bar.getComponent('plus').show();
     bar.getComponent('more').show();
     bar.getComponent('filter').hide();
     bar.getComponent('sorting').hide();
     var grid = bar.ownerCt;
     grid.restore(grid);
    };
   
   

    var columns = [

//    {text: "epob", width: 36, sortable: true, dataIndex: 'epobType',
//      renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {   
//        var epobType = value;
//        return '<div title="'+epobType+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+epobType+'"> &nbsp;&nbsp;&nbsp;'+'</div>';
//      }
//    },
    
      {text: "Record Name", flex:1, width:240, sortable: true, dataIndex: 'name',
       renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {

         metaData.tdCls = 'xty_nodeitem-cell xty_nodeitem-card-cell';

         var childOf = record.get('childOf');
         if (childOf){
           metaData.tdCls+= ' xty_nodeitem-child-cell';
         }
         
         var epobType = record.get('epobType');
         if (!Ext.isDefined(epobType)){epobType='';}
         var imgSrc = record.get('imgSrc');

         if (Ext.isEmpty(imgSrc)){ imgSrc='../img/epobs/previews/'+epobType.toLowerCase().replace(/root.*/,'')+'.gif';}

         var html =  BoundListItem_userChannelTeaserTpl.applyTemplate({epobType:epobType,title:value, imgSrc:imgSrc, formsat:'xty_epobProduct',  isnew:true});
         return html; 
       }
      },

      {text: "more", width: 36, sortable: true, dataIndex: 'name',

        renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
          metaData.tdCls = 'xty_nodeitem-cell xty_nodeitem-tools-cell ';
          var isExpanded =  record.get('expanded');
          if (!Ext.isDefined(isExpanded)){
            isExpanded = false;
          }  
          else{
            isExpanded = isExpanded==='expanded';
          }
          if (isExpanded){
            metaData.tdCls+= ' xty_nodeitem-cell-expanded';
          }

          var searchval = value; 
          var epobType = record.get('epobType'); 
          
          if (!Ext.isDefined(epobType)){
            epobType = '';
          }
          
          var epobTypeLower = epobType.toLowerCase();
          var searchtype = epobType; 

          var btnSearch4 = '<div  class="xty_celltool-plus"  data-qtip="maximize: <br><b>'+searchval+'</b>"  searchval="'+searchval+'" searchtype="'+searchtype+'" > &nbsp;&nbsp;&nbsp;&nbsp;</div>';

          var showSearch4 = false;
          if (epobTypeLower.indexOf('product')>-1 || epobTypeLower.indexOf('collection')>-1 ){
            showSearch4 = true;
          }
          if (epobTypeLower.indexOf('attribute')>-1){
            showSearch4 = false;
          }
          
          var btnExpand = '<div class="xty_celltool-more" data-qtip="expand childs  of <br><b>'+searchval+'</b>"  viewid="'+view.id+'"  rowindex="'+rowIndex+'"   recordid="'+record.id+'" > &nbsp;&nbsp;&nbsp;&nbsp;</div>';
          
          var showExpand = false;
          if (epobTypeLower.indexOf('root')>-1){
            showExpand = true;
          }

          var html =  (showSearch4  ? btnSearch4 : '' ) + (showExpand  ? btnExpand : '' );
         return  html;
        }
      }
  ];
    
   var  gridMaximize = function(nodeGrid){  
      nodeGrid.beforeMaximizeHeight = nodeGrid.getHeight();
      nodeGrid.setHeight(me.getHeight()-54);
      nodeGrid.setWidth( nodeGrid.getWidth()+18);
      me.addCls('xty_nodeslistsPanel-hasMaximized');
     // me.getComponent('bottombar').setHeight(2);
     // me.getComponent('bottombar').hide();
      nodeGrid.getStore().loadData( [
        {name:'wetwet gwergwe'},{name:'abc tw4tw'},{name:'abc wettwetw'},{name:'abc wtwetwet'},{name:'wetkljh9876'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},
        {name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'},{name:'abc'}
      ]);
      var nodeslistsPanelEl = Ext.get(me.id);
      var nodeGridPos = nodeGrid.getPosition();
      var scrollTop = document.getElementById(me.id+'-body').scrollTop;
      document.getElementById(me.id+'-body').scrollTop = scrollTop + (  scrollTop -nodeGridPos[1] );
      //alert (nodeGrid.getPosition() +' '+ document.getElementById(me.id+'-body').scrollTop);
    };
    
    var gridRestore = function(nodeGrid){
      nodeGrid.setHeight(nodeGrid.beforeMaximizeHeight);
      nodeGrid.setWidth( nodeGrid.getWidth()-18);
      me.removeCls('xty_nodeslistsPanel-hasMaximized');
     // me.getComponent('bottombar').show();
      nodeGrid.collapse();
    };

    
    var gridGetRowClass = function(record, rowIndex, rowParams, store){
      var rowCls= 'xty_nodeitem-row xty_nodeitem-row-'+rowIndex;  
      var isExpanded =  record.get('expanded');
      if (!Ext.isDefined(isExpanded)){
        isExpanded = false;
      }  
      else{
        isExpanded = isExpanded==='expanded';
      }
      if (isExpanded){
        rowCls+= ' xty_nodeitem-row-expanded';
      }

      var childOf = record.get('childOf');
      if (childOf){
        rowCls+= ' xty_nodeitem-child-row';
      }
      
      return rowCls;
    };
    
    
    
    var gridAfterrender =  function( panel ){
      panel.getEl().on('click',
        function(evt, targ){    
        var toggleHeaderEl = evt.getTarget('.x-panel-header', null, true);
        var fieldEl = evt.getTarget('.x-form-field', null, true);
        var isFieldClick = fieldEl!==null; 
        var buttonEl = evt.getTarget('.x-btn ', null, true);
        var isButtonClick = buttonEl!==null; 
        var isHeaderClick = toggleHeaderEl!==null && !isFieldClick && !isButtonClick;
          if (isHeaderClick){
            //extVia.notify('nodeslistsPanelHeader dblclick  panel.collapseed '+ panel.collapsed);
            if(panel.collapsed){
               //panel.margin ='0 0 24 0';
               panel.expand();
            }
            else{
              ///panel.margin ='0 0 0 0';
              panel.collapse(); 
            }
          }
       }
      );
      // todo header click
      //alert('nodePanelResultPanelPos afterrender')
      config.calleeCmp.searchResultRendered();
    };
    
    
    
    
    var toggleChilds = function(view, record, item, index, evt ){
      var myGridView = view;
      var myGridStore = myGridView.getStore();

      var recordid = record.id;

      var isExpanded =  record.get('expanded');
      if (!Ext.isDefined(isExpanded)){
        isExpanded = false;
      }  
      else{
        isExpanded = isExpanded==='expanded';
      }
      if (!isExpanded){
        record.set('expanded', 'expanded');
      }
      else{
        record.set('expanded', 'not');
      }

      var insertIndex = parseInt(index, 10) +1;
      
      if (!isExpanded){
        myGridStore.insert( insertIndex, [
          {name:'ABC', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A1_602000.jpg", childOf: recordid},
          {name:'DEF', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A1_602190.jpg", childOf: recordid},
          {name:'GHI', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A2_600500.jpg", childOf: recordid},
          {name:'JKL', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A2_602150.jpg", childOf: recordid},
          {name:'MNO', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A3_600500.jpg", childOf: recordid},
          {name:'PQR', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A4_602000.jpg", childOf: recordid},
          {name:'STU', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/A4_602400.jpg", childOf: recordid},
          {name:'VWX', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/P_602100.jpg", childOf: recordid},
          {name:'XYZ', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/P_602140.jpg", childOf: recordid},
          {name:'XYZ', epobType:'Image', imgSrc: "../img/fakes/previews/metabo/P_602400.jpg", childOf: recordid}
        ]); 
      }
      else{
       var childRecords =  myGridStore.getRange(insertIndex, insertIndex+9);
       myGridStore.remove( childRecords);
      }
    };
    
    
    var maximizeMeBtnHandler = function(view, record, item, index, evt ){
      var searchval = record.get('name'); // in real thing the id
      searchval = searchval.replace(/<i>/g,'');
      searchval = searchval.replace(/<\/i>/g,'');
      var searchtype = record.get('epobType');
      config.calleeCmp.setValueAndProp(searchval, searchtype);
      
      var maximizeMeMask = new Ext.LoadMask(Ext.get(me.id), {msg:"Searching in <b>"+searchval+'<b>'});
      maximizeMeMask.show();
 
      var maximizeMeMaskTask = new Ext.util.DelayedTask(function(){
        me.close();
        config.calleeCmp.search(config.calleeCmp);
        maximizeMeMask.hide();
      });
      maximizeMeMaskTask.delay(2000);
    };
    
    
    
    
    /* needed to differentiate between click and DoubleClick.  like done extVia.bom.event.main.eventClickState  */
    extVia.eventClickState = 0; 
    var gridItemdblclick =  function( view, record, item, index, evt ){
      extVia.eventClickState = 2;
      extVia.notify('griditemDBLCLICK extVia.eventClickState '+extVia.eventClickState);
    };

    var gridItemclick =  function( view, record, item, index, evt ){
      
      if (extVia.eventClickState === 0 ){ // do what you want to do on click

        if (evt.target.className.indexOf('xty_celltool-more')>-1){
          toggleChilds( view, record, item, index, evt );
        }
        else if (evt.target.className.indexOf('xty_celltool-plus')>-1){
          //extVia.notify('TO be done here search4meBtnHandler ');
          maximizeMeBtnHandler( view, record, item, index, evt );
        }
        else{
          var jsLintAlibiVar;
          //extVia.notify('single CLICK');
        }
      }
      extVia.eventClickState = 0;
    };
    
    
    
    var i;
    for (i=0; i < nodes.length; i++){

    var node = nodes[i];
      
    
      var myData = [
        //{ name : "Image "+i, column1 : "0", column2 : "0" }, 
        { name : "Bohrer "+(i+1),  epobType: 'ImageRoot',  column1 : "1", column2 : "1" },
        { name : "Zeichnung "+(2*(i+1)), epobType: 'GraphicRoot', column1 : "2", column2 : "2" },
        { name : "ProductVariant "+(3*(i+1)), epobType: 'ProductVariant', column1 : "3", column2 : "3" },
        { name : "Collection "+(4*(i+1)), epobType: 'Collection', column1 : "4", column2 : "4" , imgSrc:'../img/icons/spacer.gif'},
        { name : "Attribute "+(5*(i+1)), epobType: 'Attribute', column1 : "5", column2 : "5" , imgSrc:'../img/icons/spacer.gif' }
//        ,{ name : "Flag "+(6+(i+1)), column1: "6", column2 : "6" },
//        { name : "Dictionary "+(7*(i+1)), column1 : "7", column2 : "7" },
//        { name : "Rec "+(8*(i+1)), column1 : "8", column2 : "8" },
//        { name : "Rec "+(9*(i+1)), column1 : "9", column2 : "9" }
    ];

      
   var showChildsCount = 5;   // configurable
   myData = myData.slice(0, showChildsCount);
   
      
    // create the data store
    var nodeGridStore = Ext.create('Ext.data.Store', {
        model: 'DataObject',
//        id: 'nodeGridStore-'+node+'-'+i,
//        itemId: 'nodeGridStore-'+node+'-'+i,
        
        data: myData
    });



    
    var nodeName = node+' '+i ;

    var gridWidth = config.width-21;
    
    var nodeGrid;
    nodeGrid = Ext.create('Ext.grid.Panel', {
       // id: gridId,
      
        width:gridWidth,
        
        cls:'xty_nodeslist-nodegrid xty_nodegrid',
        //collapsible: true,
        border:false,
        hideHeaders:true,
        //height: 200,
        tools:[ 

          {itemId:'sorting', xtype:'button',  cls:'xty_tool-sort-btn', tooltip:'Sort DESC', text:'&#9013;', margin:'0 2 0 2', hidden:true, height:18, width:18, arrowCls:'',
            menu:[
              {text:'<b>Sortierung</b>'},
              {text:'Aufsteigend',checked:true, handler :querybehaviourItemHandler, itemId:'sort-asc', group:'SORT', value:'ASC'},
              {text:'Absteigend', handler :querybehaviourItemHandler, itemId:'sort-desc', group:'SORT', value:'DESC'},
              '-',
              {text:'&Auml;nderungsdatum', checked:true,handler :querybehaviourItemHandler, itemId:'sortby-changedate', group:'SORTBY', value:'CHANGEDATE'},
              //{text:'Erstellungsdatum', handler :querybehaviourItemHandler, itemId:'sortby-creationdate', group:'SORTBY', value:'CREATIONDATE' },
              {text:'Name',handler :querybehaviourItemHandler, itemId:'sortby-name', group:'SORTBY', value:'NAME'},
              {text:'Typ',handler :querybehaviourItemHandler, itemId:'sortby-type', group:'SORTBY', value:'TYPE'}
            ] 
           },
          
           {xtype:'textfield', itemId:'filter', hidden:true, cls:'xty_nodegrid-header-textfield', margin:'0 2 0 2', height:18, width: 120 },
           
          { itemId:'more',  xtype:'button', scale:'small', cls:'xty_tool-plus-btn', iconCls:'xty_tool xty_tool-plus',  pressedCls:'OFF', tooltip:'maximize: <br><b>'+nodeName+'<b>',
            searchval:  nodeName, handler: moreBtnHandler
          }, 
          
          { itemId:'restore', hidden:true, margin:'0 0 0 4', xtype:'button', scale:'small', cls:'xty_tool-restore-btn', iconCls:'xty_tool xty_tool-minus', tooltip:'collapse', pressedCls:'OFF', 
            searchval:  nodeName, handler: restoreBtnHandler
          }, 
          
          {xtype:'tbspacer', itemId:'restorespacer', width: 4, hidden :true}
          
//          ,{type:'plus', itemId:'plus',searchval:  nodeName, hXXandler: moreBtnHandler,
//            handler: function(event, toolEl, panel){
//             restoreBtnHandler(panel.getComponent('plus'));
//            }  
//           },
//          
//          
//          {type:'minus', itemId:'minus',hidden:true, searchval:  nodeName, hXXandler: restoreBtnHandler ,
//            handler: function(event, toolEl, panel){
//              restoreBtnHandler(panel.getComponent('minus'));
//            } 
//          }
          
//          ,{ id:'search4meBtn', hidden: true, xtype:'button', cls:'xty_search4me-btn', iconCls:'xty_search4me', overCls:'OFF',
//            searchval:  nodeName, handler:search4meBtnHandler
//          }
         
          ],
        
        multiSelect: true,

        itemId: 'nodeGrid-'+node+'-'+i,
        
        //scroll: false,
        
        viewConfig: {
            stripeRows: false,
            plugins: {
                ptype: 'gridviewdragdrop',
                dragGroup: 'firstGridDDGroup',
                dropGroup: 'collectorDDGroup'
            },
            getRowClass:  gridGetRowClass,
            
            listeners: {
              //  drop: dropHandler
            }
        },
        store            : nodeGridStore,
        columns          : columns,
        //
        title            : nodeName,
        //margins          : '0 2 0 0'

        listeners:{
          afterrender: gridAfterrender,
          //itemclick: { fn:gridItemclick, scope: nodeGrid, buffer : 100 }, // if you want to seperate itemclick from doubleclick
          itemclick: gridItemclick,
          itemdblclick: gridItemdblclick
        },
        maximize: gridMaximize,
        restore: gridRestore,          

        bsbar:{
        
          height: 2,
          itemId: 'bottombar', 
          cls:'xty_nodeslist-node-bbar',
          
//          setPagingVisible: function(visible ){
//            var bbar = this;
//            bbar.getComponent('pagingspacer').setVisible(visible);
//            bbar.getComponent('pagingFirst').setVisible(visible);
//            bbar.getComponent('pagingPrev').setVisible(visible);
//            bbar.getComponent('pagingNext').setVisible(visible);
//            bbar.getComponent('pagingLast').setVisible(visible);
//          },

          items: [ 
            '->' , 

          {itemId:'pagingspacer', xtype:'tbspacer', width:48, hidden:true},
          {itemId:'pagingFirst', text:' &nbsp;&#10094;&#10094; &nbsp;', disabled:true, tooltip:'first', hidden:true},
          {itemId:'pagingPrev', text:' &nbsp;&#10094; &nbsp;', disabled:true, tooltip:'previous', hidden:true},

          
          {itemId:'pagingNext', text:' &nbsp;&#10095; &nbsp;', tooltip:'next', hidden:true},
          {itemId:'pagingLast', text:' &nbsp;&#10095;&#10095; &nbsp;', tooltip:'last', hidden:true}
            

         ]
      }
        
    });

    nodelistspanel.add(nodeGrid);

   


    }

    }
  };

    
    me.callParent(arguments);
  }


  
});
/*
 * 
 * $Revision: 1.1.2.45 $
   $Modtime: 22.01.19 18:29 $ 
   $Date: 2019/05/24 18:43:08 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 