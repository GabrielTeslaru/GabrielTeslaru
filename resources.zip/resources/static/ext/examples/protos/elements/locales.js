Ext.namespace('extVia.locales' ,'extVia.elements.locales');
/**
 * @class plain
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2019/01/16 16:56:28 $
 *            $Revision: 1.1.2.1 $
 */





extVia.elements.locales = {
        appName:'elements',
        modul:'elements',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.elements.locales);



/*
 * 
 * $Revision: 1.1.2.1 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2019/01/16 16:56:28 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 