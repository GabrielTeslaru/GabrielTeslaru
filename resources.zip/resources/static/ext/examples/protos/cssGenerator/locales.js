Ext.namespace('extVia.locales' ,'extVia.cssGenerator.locales');
/**
 * @class cssGenerator
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2017/11/15 11:45:36 $
 *            $Revision: 1.1 $
 */





extVia.cssGenerator.locales = {
        appName:'cssGenerator',
        modul:'cssGenerator',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.cssGenerator.locales);



/*
 * 
 * $Revision: 1.1 $
   $Modtime: 15.11.17 12:40 $ 
   $Date: 2017/11/15 11:45:36 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 