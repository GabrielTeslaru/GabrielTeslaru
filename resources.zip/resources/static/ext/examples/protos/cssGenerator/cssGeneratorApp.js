/**
 * 
 */
Ext.application({
    name: 'cssGenerator',
    
    version:'$Revision: 1.11.6.37 $',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerHeight = centerPan.getHeight();
      centerHeight-=25; // substract center-tabstrip 
      centerHeight-=66; // substract pagejobbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=60;  // substract pagetoolbar 
      }
      if (cfg && cfg.hasSubtabs){
        centerHeight-=30; // substract subtabstrip
      }      
      return centerHeight;
    },

    getCenterWidth : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerWidth = centerPan.getWidth()-50;    
      return centerWidth;
    },
    
    getWestListHeight : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
      return westHeight;
    },
    

    showEditor: function() {
      extVia.notify({action: 'show Editor '  , mssg:  'Wo isser ?'}); 
    },


    
    generateEpobCls: function() {    
      // in the moment still @  ~lty/pg/epobCSS.jsp 
    },
    
    
    generateFlagsCls: function() {
      // in the moment @ baseProto.baseEditorStatics#generateFlagCss 
    },
    
    /**
     *  Action Button generation (3070) , large medium, small 
     */
    generatePageToolbarIconCls: function(cfg) {
      var me = this;
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
      
      var actionBtns = [

      { action: "addComment", icon: "addComment_32", oldGUIcls:"", newGUIcls:"comment",   oldGUI:false,  newGUI:true },    
      { action: "addGroup", icon: "addGroup_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "addSync", icon: "addSync_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true, mediumFileType:'png', largeFileLoc:'actions'}, 
      { action: "addLocationSync", icon: "addLocationSync_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true, mediumFileType:'png', largeFileLoc:'actions' }, 
      { action: "assign", icon: "assign_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      //{ action: "assignAttribute", icon: "assignAttribute_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:false },   
      { action: "assignDown", icon: "assignDown_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "assignments", icon: "assignments_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "assignTask", icon: "assignTask_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true }, 
      //{ action: "assignTaskToTheLeft", icon: "assignTaskToTheLeft_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true }, 
      { action: "transferTask", icon: "assignTask_32", oldGUIcls:"", newGUIcls:"transferTask",   oldGUI:false,  newGUI:true }, 
      { action: "backspace", icon: "backspace_32", oldGUIcls:"backsm", newGUIcls:"clear",   oldGUI:true,  newGUI:true }, 
      { action: "backspace", icon: "backspace_32", oldGUIcls:"leerensm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "check", icon: "check_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "check", icon: "check_32", oldGUIcls:"toarticsm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "checkDoubles", icon: "checkDoubles_32", oldGUIcls:"ersatzsm", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "checkDoubles", icon: "checkDoubles_32", oldGUIcls:"variantsm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "copy", icon: "copy_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      //{ action: "copyAndPaste", icon: "copyAndPaste_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "delete", icon: "delete_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true, doSmall:true }, 
      { action: "delete", icon: "delete_32", oldGUIcls:"", newGUIcls:"remove",   oldGUI:false,  newGUI:true }, 
      { action: "deleteChecked", icon: "deleteChecked_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "deleteSync", icon: "deleteSync_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true, mediumFileType:'png', largeFileLoc:'actions' }, 
      { action: "deleteLocationSync", icon: "deleteLocationSync_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true, mediumFileType:'png', largeFileLoc:'actions' },
      { action: "download", icon: "download_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "duplicate", icon: "duplicate_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "edit", icon: "edit_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true, doSmall:true }, 
      { action: "edit", icon: "edit_32", oldGUIcls:"editor", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      //{ action: "editMany", icon: "editMany_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "editTable", icon: "editTable_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "editTask", icon: "editTask_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true }, 
      { action: "exportStart", icon: "exportStart_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "exportStart", icon: "exportStart_32", oldGUIcls:"export", newGUIcls:"export",   oldGUI:true,  newGUI:true }, 
      { action: "execute", icon: "execute_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true, ticketNr:'3776'},
      
      
      { action: "folder", icon: "openFolder_32", oldGUIcls:"folder", newGUIcls:"folder",   oldGUI:true,  newGUI:true, ticketNr:'3776'},
      { action: "import", icon: "importStart_32", oldGUIcls:"import", newGUIcls:"import",   oldGUI:true,  newGUI:true , ticketNr:'3776'}, 
      { action: "importStart", icon: "importStart_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true , ticketNr:'3776'}, 
      //{ action: "openFolder", icon: "openFolder_32", oldGUIcls:"openFolder", newGUIcls:"",   oldGUI:true,  newGUI:false, ticketNr:'3776'},
      
      { action: "addItem", icon: "itemsAdd", oldGUIcls:"", newGUIcls:"addItem",   oldGUI:false,  newGUI:true }, 
      
      { action: "itemsDelete", icon: "itemsDelete_32", oldGUIcls:"", newGUIcls:"deleteItems",   oldGUI:true,  newGUI:true }, 
      { action: "itemsDelete", icon: "itemsDelete_32", oldGUIcls:"", newGUIcls:"removeItem",   oldGUI:false,  newGUI:true }, 
      

      
      { action: "mam-upload", icon: "mam-upload_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true }, 
      { action: "metadataShow", icon: "metadataShow_32", oldGUIcls:"showMetadata", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "moveInTree", icon: "moveInTree_32", oldGUIcls:"movesm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "moveInTree", icon: "moveInTree_32", oldGUIcls:"aumovesm", newGUIcls:"",   oldGUI:true,  newGUI:false }, 
      { action: "new", icon: "new_32", oldGUIcls:"", newGUIcls:"newEpob",   oldGUI:true,  newGUI:true, mediumFileType:'png', doSmall:true }, 

      { action: "openFolder", icon: "openFolder_32", oldGUIcls:"workasm", newGUIcls:"",   oldGUI:true,  newGUI:false},
      { action: "pagingFirst", icon: "pagingFirst_32", oldGUIcls:"erstersm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "pagingLast", icon: "pagingLast_32", oldGUIcls:"letztesm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "pagingNext", icon: "pagingNext_32", oldGUIcls:"naechssm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "pagingPrev", icon: "pagingPrev_32", oldGUIcls:"vorhersm", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "preview", icon: "preview_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "preview", icon: "preview_32", oldGUIcls:"preview_image", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "previewHTML", icon: "previewHTML_32", oldGUIcls:"preview_html", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      //{ action: "process", icon: "process_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "processStart", icon: "processStart_32", oldGUIcls:"", newGUIcls:"startProcess",   oldGUI:false,  newGUI:true }, 
      //{ action: "reload", icon: "reload_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "refresh", icon: "refresh_32", oldGUIcls:"reloadsm", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "sammlungAddTo", icon: "sammlungAddTo_32", oldGUIcls:"collectionAddTo", newGUIcls:"collectionAddTo",   oldGUI:true,  newGUI:true }, 
      { action: "save", icon: "save_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true, doSmall:true }, 
      { action: "saveAndAssign", icon: "saveAndAssign_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false}, 
      { action: "savechecksm", icon: "saveChecked_32", oldGUIcls:"savechecksm", newGUIcls:"",   oldGUI:true,  newGUI:false, ticketNr:'3610'}, 
      { action: "saveChecked", icon: "saveChecked_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:false, ticketNr:'3610' }, 
      { action: "saveAndNew", icon: "saveAndNew_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      //{ action: "saw-up", icon: "saw-up_32", oldGUIcls:"", newGUIcls:"inheritance-break",   oldGUI:false,  newGUI:true }, 
      { action: "search", icon: "search_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      //{ action: "searchThin", icon: "searchThin_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "share", icon: "share_32", oldGUIcls:"", newGUIcls:"",   oldGUI:false,  newGUI:true }, 
      { action: "share", icon: "share_32", oldGUIcls:"", newGUIcls:"release",   oldGUI:false,  newGUI:true }, 
      { action: "start", icon: "start_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "stop", icon: "stop_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "transfer", icon: "transfer_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "upload", icon: "upload_32", oldGUIcls:"", newGUIcls:"",   oldGUI:true,  newGUI:true }, 
      { action: "upload", icon: "upload_32", oldGUIcls:"uploadsm", newGUIcls:"",   oldGUI:true,  newGUI:false }, 
      { action: "createVersion", icon: "versioning_createVersion_32", oldGUIcls:"versioning-create", newGUIcls:"versioning-create",   oldGUI:true,  newGUI:true }
  
      ];

      
      //var generateOldGUICls = true;
      var generateOldGUICls = cfg.oldGUI ? cfg.oldGUI: (cfg.newGUI ? false: true);
      var generateNewGUICls = !generateOldGUICls; //false;

      var gui = generateNewGUICls ? 'newGUI' : 'oldGUI' ;
      
      me.version = me.version.replace(/(\$Revision)(.*)(\$)/,'$2');
      me.version = me.version.replace(/:\s/,'');
      
      var actionBtnCls= '\n';
      actionBtnCls+= '/*-------------- [  pagetoolbar-icons generated by extVia.protos.cssGenerator v.'+me.version+' #generatePageToolbarIconCls START ] ----------------*/';              
      actionBtnCls+= '\n';
      
      var i;
      for(i = 0 ; i< actionBtns.length ; i++){
        var actionBtn = actionBtns[i];
        
        var btn = actionBtn.icon.replace(/_32/, '');
        
        var actionOldGUI = btn;
        var actionNewGUI = btn;
        
        
        if (!Ext.isEmpty(actionBtn.oldGUIcls)){
          actionOldGUI = actionBtn.oldGUIcls;
        }
        
        if (!Ext.isEmpty(actionBtn.newGUIcls)){
          actionNewGUI = actionBtn.newGUIcls;
        }

        var  usedInOldGUI = actionBtn.oldGUI;
        var  usedInNewGUI = actionBtn.newGUI;
        
        //var mediumFileType = actionBtn.mediumFileType ? actionBtn.mediumFileType : 'svg';   // for ie doesn't work properly with svg # 
        var mediumFileType = 'png';   
        
        var largeFileLoc = actionBtn.largeFileLoc ? actionBtn.largeFileLoc+'/' : '';   

        
        if(generateOldGUICls && usedInOldGUI){
          if(actionBtn.ticketNr){ actionBtnCls+= ' /* >>> PROD V4 Start ('+actionBtn.ticketNr+') <<< */ \n';}
          
          if(actionBtn.doSmall){
            actionBtnCls+= 
            ' .x-btn-default-toolbar-small  .lty_fbuttons_'+actionOldGUI+' {background-image:url(../../via-img/'+btn+'_16.png); }\n';
          }
          
          actionBtnCls+= 
            ' .x-btn-default-toolbar-medium  .lty_fbuttons_'+actionOldGUI+' {background-image:url(../../via-img/actions/'+btn+'_24.'+mediumFileType+'); }\n'+
            ' .x-btn-default-toolbar-large   .lty_fbuttons_'+actionOldGUI+' {background-image:url(../../via-img/'+largeFileLoc+btn+'_32.png); }\n' ; 
          
          
          if(actionBtn.ticketNr){ actionBtnCls+= ' /* >>> PROD V4 End ('+actionBtn.ticketNr+') <<< */ \n';}
        }
        
        if(generateNewGUICls && usedInNewGUI){
          if(actionBtn.ticketNr){ actionBtnCls+= ' /* >>> PROD V4 Start ('+actionBtn.ticketNr+') <<< */ \n';}

          if(actionBtn.doSmall){
            actionBtnCls+= 
              ' .x-btn-default-toolbar-small   .xty_pgtoolbar-'+actionNewGUI+' {background-image:url(../../via-img/'+btn+'_16.png); }\n' ;  
          }

          actionBtnCls+= 
            ' .x-btn-default-toolbar-medium  .xty_pgtoolbar-'+actionNewGUI+' {background-image:url(../../via-img/actions/'+btn+'_24.'+mediumFileType+'); }\n'+
            ' .x-btn-default-toolbar-large   .xty_pgtoolbar-'+actionNewGUI+' {background-image:url(../../via-img/'+largeFileLoc+btn+'_32.png); }\n' ;
          
          if(actionBtn.ticketNr){ actionBtnCls+= ' /* >>> PROD V4 End ('+actionBtn.ticketNr+') <<< */ \n';}
        } 
  
      }
      
      actionBtnCls+= '/*-------------- [  pagetoolbar-icons generated END ] ----------------*/';
      actionBtnCls+='\n';

      var formPanel = Ext.create('Ext.form.FormPanel', {
        title      : 'actionBtnCls '+gui,
        closable: true,
        anchor    : '100%',
        items: [{
            xtype     : 'textareafield',
           // grow      : true,
            value:    actionBtnCls,
            name      : 'message',
            fieldLabel: 'actionBtnCls ',
            height: me.getContentPanelHeight(),
            anchor    : '100%'
        }]
    });
      
      
      
      tabPanCenter.addAndActivate(formPanel);       

      
    },
    
    
    
    getTicketNrCommentTpl: function(ticketNr) {
      return' /* >>> PROD V4 {startend} ({ticketNr}) <<< */ \n' ; 
    },
    
    
    showGeneratedClsInTab: function(gencls, tabTitle) {
      var me = this;
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
      
      var formPanel = Ext.create('Ext.form.FormPanel', {
        title      : tabTitle?tabTitle:'genCls',
        closable: true,
        
        anchor    : '100%',
        items: [{
            xtype     : 'textareafield',
           // grow      : true,
            value:    gencls,
            name      : 'genCls',
            //fieldLabel: 'genCls ',
            height: me.getContentPanelHeight(),
            anchor    : '100%'
        }]
     });

      tabPanCenter.addAndActivate(formPanel);  
      
    },
    
    
    
    
    generateTimeRelatedCollapseCls: function() {  
      
      var me = this;
      
      var timeRelatedKeys =[
          'Today',
          'Yesterday',
          'This_Week',
          'Last_Week',
          'This_Month',
          'Last_Month',
          'This_Year',
          'Last_Year'
        //  ,'Once_Upon_A_Time'
          
         , '2_Years_ago',   '3_Years_ago',   '4_Years_ago',   '5_Years_ago'
 
        ];

      
      
      
    var collapseRelatedTimes =[
      'Today',
      'Yesterday',
      'This_Week',
      'Last_Week',
      'This_Month',
      'Last_Month',
      'This_Year',     // -> 2019 now
      'Last_Year',     // -> 2018
      '2020',
      '2_Years_ago',   // -> 2017
      '2019',
      '3_Years_ago',   // -> 2016
      '4_Years_ago',   // -> 2015
      '5_Years_ago'    // -> 2014
    ];
      
      var timeRelatedCls ='';
      
      
      var rowwrapTDselector = '.xty_rowwrap-td'; // needs Infinitygrid adjustment
      //rowwrapTDselector = 'TD[colspan="1"]';
      
      
      var i;
      for (i=0; i< collapseRelatedTimes.length; i++){
        var timeRelatedKey = collapseRelatedTimes[i];
        
        timeRelatedKey = timeRelatedKey.toLowerCase().replace(/_/g, '');
        
        timeRelatedKey = timeRelatedKey.replace(/_/g, '-').toLowerCase();

        
        timeRelatedCls+=' .xty_cardview-grid-group-'+timeRelatedKey+'-collapsed .xty_history-row-childof-'+timeRelatedKey+':not(.xty_history-firstOfGroup-row) {display:none;} \n';
        
        
      //  timeRelatedCls+=' .xty_cardview-grid-group-'+timeRelatedKey+'-collapsed .xty_history-row-childof-'+timeRelatedKey+' .x-grid-group-title .xty_group-toggler { background-image: url(\'../via-img/ext/grid/group-expand.gif\'); } \n';
        

      

        
        //timeRelatedCls+=' .xty_cardview-grid-group-'+timeRelatedKey+'-collapsed .xty_history-row-childof-'+timeRelatedKey+'.xty_history-firstOfGroup-row {display: block !important;} \n';
        
        //timeRelatedCls+=' .xty_cardview-grid-group-'+timeRelatedKey+'-collapsed .xty_history-row-childof-'+timeRelatedKey+':not(.xty_history-firstOfGroup-row) .xty_rowwrap-td {display:none;} \n';
        //timeRelatedCls+=' .xty_cardview-grid-group-'+timeRelatedKey+'-collapsed .xty_history-row-childof-'+timeRelatedKey+'.xty_history-firstOfGroup-row .xty_rowwrap-td {display: block !important;} \n';
        
        timeRelatedCls+=' .xty_cardview-grid-group-'+timeRelatedKey+'-collapsed .xty_history-row-childof-'+timeRelatedKey+'.xty_history-firstOfGroup-row .xty_grid-card-bin {display: none;} \n';
   
        
        
      }

      me.showGeneratedClsInTab(timeRelatedCls, 'timeRelated');
      
      
    },  
     
     
    
    generateColsVSSizes: function() {
      // needs
      // >>> PROD V4 Start (EPIM-7678) <<<
      // >>> PROD V4 End (EPIM-7678) <<<
      var me = this;
      var colsVSSizesHTML = '<textarea id="display-textarea" style="width:'+600+'px !important; max-width:'+600+'px !important;  min-width:'+600+'px !important; "  class="lty_pratTextarea" rows="5" ></textarea><br>';
      var start = 0;
      var howmany = 80;
      var i;
      for (i=start; i< howmany; i++){
       var txaW = i*6 +23; //FF like
      //  var txaW =  Math.round(this.size * 6.5) + 20; //extjs getBodyNaturalWidth
        colsVSSizesHTML+='<textarea id="prat-textarea-'+i+'" style="width:'+txaW+'px !important; max-width:'+txaW+'px !important;  min-width:'+txaW+'px !important; "  class="lty_pratTextarea" rows="1" cols="'+i+'">'+i+'</textarea><br>';
        colsVSSizesHTML+= '<input id="prat-input-'+i+'" class="forminputtext lty_pratInp lty_pratInp_dtyVC"  value="'+i+'"  size="'+i+'" type="text"><span id="prat-display-'+i+'"></span><br><br>' ; 
           
      }
      var checkHandler = function(btn){
        var j;
        var alStr ='';
        for (j=start; j< howmany; j++){
          var inpEl = Ext.get( ('prat-input-'+j));   
          var txaEl = Ext.get( ('prat-textarea-'+j));   
          var inpW = inpEl.getWidth();
          var txW = txaEl.getWidth();
          var newval  =  inpEl.dom.getAttribute('size')+' : '+inpW+'px  -- '+txW+'px -- '+  ( inpW - (j * 6) ) ;
          var displayEl = Ext.get( ('prat-display-'+j));   
          displayEl.dom.innerHTML = newval;
          alStr+= inpW+',';
        }
        Ext.get('display-textarea').dom.value = alStr;
      };
      var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'cols VS sizes' ,    pgjobButtons: [ { iconCls:'xty_pgtoolbar-check', handler: checkHandler} ,{xtype:'tbspacer', width:20} ]});
      var colsVSSizesPanel  = {title: 'cols vs  sizes', itemId:'editorPanel', closable:true, 
                              tbar: applibar,
                              autoScroll:true, 
                              height: me.getContentPanelHeight()+64,
                              items:[ { html:colsVSSizesHTML } ] 
                            };
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
      tabPanCenter.addAndActivate(colsVSSizesPanel);  
    },
    
    
    generateEpobIconsForNetworkGraph: function() {
      // >>> PROD V4 Start (EPIM-7678) <<<
      // >>> PROD V4 End (EPIM-7678) <<<
      var me = this;
      
      /* NEU
        - TextVar
      */
      var epobs = [
        'Product', 'Productgroup',  'ProductVariant', 'Hierarchy',
        
        'Reference', 'ProductRef', 'ProductgroupRef',  'ProductVariantRef',
        
        // Folder
        'Productref', 'Productvariantsfolder' ,
        

        //'Element', 
        'Image', 'Graphic', 'Document', 'Text', 'TextVar', 'Audio', 'Video' , 'EdTable', 'ProdTable' 
 
        
      ];

      var gencls='\n';
      
      var genClsJSON ={};

      gencls+= ' .xty_graph-node-leaf .xty_graph-node-icon {width:24px; height:24px; background-image: url(../../../../../../../../jsp/via-img/epobs/networkgraph/element_32.png); background-repeat:no-repeat; } \n';
      gencls+= ' .xty_graph-node-folder .xty_graph-node-icon {width:24px; height:24px; background-image: url(../../../../../../../../jsp/via-img/epobs/networkgraph/folder_32.png); background-repeat:no-repeat; } \n';
      
      var i;
      for ( i=0; i<epobs.length; i++ ){
        
        var epobFolder = i< 10 ? 'products' : 'content';        
        epobFolder = 'networkgraph';
        
        var epob= epobs[i];
        gencls+= ' .xty_graph-node-epob-'+epob+' .xty_graph-node-icon {width:24px; height:24px; background-image: url(../../../../../../../../jsp/via-img/epobs/'+epobFolder+'/'+epob.toLowerCase()+'_32.png); background-repeat:no-repeat; } \n';
        //gencls+= ' .xty_graph-node-structure-elements-'+epob.toLowerCase()+' .xty_graph-node-icon {width:24px; height:24px; background-image: url(../../../../../../../../jsp/via-img/epobs/'+epobFolder+'/'+epob.toLowerCase()+'folder_32.png); background-repeat:no-repeat; } \n';
        
        

        
        //genClsJSON['xty_graph-node-epob-'+epob]=  { width: '24px', height: '24px', 'backgroundImage': 'url(../via-img/epobs/'+epobFolder+'/'+epob+'_32.png)', 'backgroundRepeat': 'no-repeat'};
        
      }

      me.showGeneratedClsInTab(gencls, 'graphnode');

    },

    
    
    attributeSelectors:{
      
     rowSelectors : '.lty_pratTR .lty_pratrow-{dty} .lty_pratrow__{KEY} .lty_pratbox_{PARENTKEY}_Child ', 
      
     cellSelectors : '.lty_pratCellDscr  .lty_pratCellValue ',

     labelCellSelectors : '.lty_prat-label-td__{KEY}  .lty_{COMMENT}-pratT??D  .lty_pratCellDscr',
     labelSelectors : '.lty_pratDscrSPAN  ',
      
     
     
     fieldCellSelectors : '.lty_prat-field-td__{KEY} .lty_{COMMENT}-pratT??D   .lty_pratCellValue',
     
     fieldSelectors : '.lty_pratInp .lty_pratInp_dty{dty} ', 

     
     typedSelectors : { 
       all : '.lty_pratrow .lty_pratboxDscr .lty_pratCellValue .lty_pratInp', 
       String : '.lty_pratrow-VC  .lty_pratboxDscr.dtyVC .lty_pratCellValue_dtyVC  .lty_pratInp_dtyVC',  
       Number : '.lty_pratrow-N .lty_pratboxDscr.dtyN .lty_pratCellValue_dtyN .lty_pratInp_dtyN', 
       Date : '.lty_pratrow-D .lty_pratboxDscr.dtyD .lty_pratCellValue_dtyD .lty_pratInp_dtyD', 
       Flag : '.lty_pratrow-F .lty_pratboxDscr.dtyF .lty_pratCellValue_dtyF .lty_pratInp_dtyF', 
       Dictionary : '.lty_pratrow-DI .lty_pratboxDscr.dtyDI .lty_pratCellValue_dtyDI .lty_pratInp_dtyDI', 
       Collection : '.lty_pratrow-C .lty_pratboxDscr.dtyC .lty_pratCellValue_dtyC .lty_pratInp_dtyC', 
       HeaderCollection : '.lty_pratrow-C .lty_pratboxDscr.dtyC .lty_pratCellValue_dtyC .lty_pratInp_dtyC', 
       Selection : '.lty_pratrow-S .lty_pratboxDscr.dtyS .lty_pratCellValue_dtyS .lty_pratInp_dtyS' 
       
     },

         
     keySelectors : '.lty_pratrow__{KEY} .lty_prat-label-td__{KEY} .lty_prat-field-td__{KEY} ', 
     
     
     idSelectors : '.lty_prat{ID}-row  .lty_prat{ID}-label-td  .lty_prat{ID}-field-td ', 
     
     
     // begins 
     keypartSelectors : '  .lty_pratTR[class^=lty_pratrow__{KEYPART}]  .lty_pratCellDscr[class^=lty_prat-label-td__{KEYPART}] .lty_pratCellValue[class^=lty_prat-field-td__{KEYPART}]', 
     // ends 
     //keypartSelectors : '  [class$=lty_pratrow__{KEYPART}]  [class$=lty_prat-label-td__{KEYPART}] [class$=lty_prat-field-td__{KEYPART}]', 
     // contains 
     //keypartSelectors : '  [class*=lty_pratrow__{KEYPART}]  [class*=lty_prat-label-td__{KEYPART}] [class*=lty_prat-field-td__{KEYPART}]', 
     
     
     
  
     
     
     childOfAttributeKeySelectors : '.lty_pratTR.lty_pratbox_{PARENTKEY}_Child  .lty_pratCellDscr  .lty_pratCellValue ',

     commentSelectors : '.lty_{COMMENT}_dscrTD .lty_{COMMENT}-pratTD'

    },
    

    
    
    showAttributeSpecificDialog: function() {
      var me = this;     
      
//      var attributeSpecificDialog = Ext.create('widget.window', {
//        width: 520,
//        x: 620,
//        y: 120,
//        title:'Attributspezifisches CSS generieren',
//        plain: true,
//        items : [ {
//            xtype: 'form',
//            border : false,
//            minHeight : 200,
//            defaults : {
//               //style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
//               masrgin:'4 4 4 4', 
//               width:420
//            },
//            items : [ 
//                     extVia.dialoges.getInstructionPanel ({
//                       mainInstr: 'Geben Sie das gewünschte CSS und die Attribute ein.'
//                     }),        
//               {fieldLabel:'Attribute',xtype: 'textarea',  margin:'4 4 4 12',  minHeight:100} ,      
//               {fieldLabel:'css',xtype: 'textarea',  margin:'4 4 4 12',  minHeight: 200, height: 200}      
//                     ]
//          }
//        ]
//        ,buttons:[ 
//          {xtype:'tbspacer', width:30},
//          {text:'Generieren'},
//          {text:'Abbrechen', handler:function(button){ button.ownerCt.ownerCt.hide(); }}
//        ]         
//    }) ;
//    //attributeSpecificDialog.show();
    
    
    

    var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
    var updateGenClsTextarea = function(btn) {

      var attributeGenForm = btn.ownerCt.ownerCt;
      var genClsTextarea = attributeGenForm.getComponent('genClsTextarea');

      var customer = attributeGenForm.getComponent('customer').value;
      
      var attributetypes = attributeGenForm.getComponent('selectorsCt').getComponent('attributetypes').value;

      var attributeselectors = attributeGenForm.getComponent('selectorsCt').getComponent('attributeselectors').value;
      
      var attributes = attributeGenForm.getComponent('attributes').value;
      

      var cellsCt = attributeGenForm.getComponent('cellsCt');
      var labelCellsCls = cellsCt.getComponent('labelCellsCls').value;
      var fieldCellsCls = cellsCt.getComponent('fieldCellsCls').value;

      var cellcontentsCt = attributeGenForm.getComponent('cellcontentsCt');
      var labelsCls = cellcontentsCt.getComponent('labelsCls').value;
      var fieldsCls = cellcontentsCt.getComponent('fieldsCls').value;
      
      
      var genCfg ={
         customer: customer,   
         attributetypes: attributetypes,
         attributes: attributes,
         labelCellsCls: labelCellsCls,
         fieldCellsCls: fieldCellsCls,
         labelsCls: labelsCls,
         fieldsCls: fieldsCls
      };
      
      
      
      var generatedCls = me.generateAttributeSpecificCls(genCfg);

      genClsTextarea.setValue(generatedCls);
      
    };
    
    
    var gencls = '';
    // if you ned an extra App Panel:  cssGenerator-Module
    var attributeAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Attributspezifisches CSS generieren', epobDscr:null,  
      pgjobButtons: [
        {itemId:'attribute', tooltip:'Attributspezifisches CSS generieren', iconCls:'xty_pgtoolbar-attribute', handler:me.showAttributeSpecificDialog},
        {itemId:'start'}
      ] } );

    
    
    var cssTexareaHeight = 66;
    
    var attributeCSSGeneratorPanel = {
      itemId:'attributeCSSGeneratorPanel', 
      tbar: attributeAppbar, 
      height:864,
      title: 'Attribute CSS',
      closable: true,   
      autoScroll:true,
      anchor    : '100%',
      items: [
        
        {
        xtype: 'form',  
        border:false,
        itemId:'attributeGenForm', 
        tistle: 'Attributspezifisches CSS',
        margin:'20 20 20 10',
        defaults:{
          labelWidth:200,
          margin:'4 8 4 12'
        },
        items: [
        
       // extVia.dialoges.getInstructionPanel ({          style:'padding:10px 0px 15px 0px',  mainInstr: 'Geben Sie das gewünschte CSS und die Attribute ein'   }),
        
        
         // >>> PROD V4 Start (EPIM-7678) <<<        
         {fieldLabel:'Kunde',  itemId:'customer', value:'ACME',  xtype: 'textfield', width:360 ,  margin:'4 8 8 12'} ,
         // >>> PROD V4 End (EPIM-7678) <<<


         {fieldLabel:'Attribute',  itemId:'attributes',  xtype: 'textarea',  anchor : '98%', height: 40,
           value:'Verpackung_Laenge Verpackung_Breite Verpackung_Hoehe Palette_Laenge Palette_Breite Palette_Hoehe'
             
           // AAA BBB CCC DDD EEE FFF GGGG HHHH IIII JJJJ KKKK LLLL MMM NNN OOO PPP QQQ RRR SSS TTT UUU VVV WWW XXX YYY ZZZ  
         } , 
         
         
         
         
       {  xtype: 'fieldcontainer',  fieldLabel:'Selektoren', itemId:'selectorsCt',  laqyout:'hbox', items:[

         { xtype:'combo',
           itemId:'attributeselectors',
           fieldLabel:'Attributselector',
           value:'Key',
           store:  {  
             fields: [ {type: 'string', name: 'name'},  {type: 'string',  name: 'value'}],
               data : [ 
                     {name: 'Id', value:'id'}, 
                     {name: 'Key', value:'key'}, 
                     {name: 'Keypart namespace', value:'keypart'}, 
                     {name: 'Childs of Attribute Key ', value:'childofkey'}, 
                     {name: 'Notiz', value:'comment'} 
                 ]  
           },
           displayField: 'name',
           valueField: 'value',
           typeAhead: true,
           mode: 'local',
           triggerAction: 'all',
           widsth : 360,
           listeners:{
             change: function (field, value){

               var selectors = me.attributeSelectors.keySelectors;
               if (value==='keypart'){selectors = me.attributeSelectors.keypartSelectors;}
               else if (value==='id'){selectors = me.attributeSelectors.idSelectors;}
               else if (value==='childofkey'){selectors = me.attributeSelectors.childOfAttributeKeySelectors;}
               else if (value==='comment'){selectors = me.attributeSelectors.commentSelectors;}
               field.ownerCt.getComponent('attributeselectorsVal').setValue(selectors);
             }
              
           }
          },
         
         {xtype:'displayfield', cls:'xty_css-code xty_css-selector', itemId:'attributeselectorsVal',  width : 800, value:me.attributeSelectors.keySelectors},    
          
         {xtype:'tbspacer', height:20},
         { xtype:'combo',
           itemId:'attributetypes',
           fieldLabel:'Attributetypen',
           wisdth : 360,
           value:'String',
           store:  {  
             fields: [ {type: 'string', name: 'name'},  {type: 'string',  name: 'epobType'},  {type: 'string',  name: 'shorty'}],
               data : [ 
                     {name: 'Alle', epobType:'all',shorty:''}, 
                     {name: 'String', epobType:'String',shorty:'VC'}, 
                     {name: 'Number', epobType:'Number',shorty:'N'}, 
                     {name: 'Date', epobType:'Date',shorty:'D'}, 
                     {name: 'Flag', epobType:'Flag',shorty:'F'}, 
                     {name: 'Dictionary', epobType:'Dictionary',shorty:'DI'}, 
                     {name: 'Collection', epobType:'Collection',shorty:'C'}, 
                     {name: 'HeaderCollection', epobType:'HeaderCollection',shorty:'C'}, 
                     {name: 'Selection', epobType:'Selection',shorty:'S'}
                 ]  
           },
           
           
           listeners:{
             change: function (field, value){
              var valuesArr = value; 
              var selectors = '';
              var i;
              for(i=0 ; i < valuesArr.length; i++){
                var val = valuesArr[i];
                selectors+=me.attributeSelectors.typedSelectors[val]+'<br> '; 
              }
              field.ownerCt.getComponent('attributetypeselectorsVal').setValue(selectors);
             } 
             },
           
           
           multiSelect : true,
           
           listConfig : {
             minWidth:280,
             maxWidth:280,
             getInnerTpl : function(displayField) {
               var tpl = '<div class="xty_epobBin" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epob{epobType}"><span style="margin-top:-8px;">' + '&nbsp; {name}  <span style="color:#888;">({shorty})</span>' + '</span></div></div>';
               return tpl;
             } 
           },
            
           displayField: 'name',
           valueField: 'epobType',
           typeAhead: true,
           mode: 'local',
           triggerAction: 'all'
         },
         
         {xtype:'displayfield', cls:'xty_css-code xty_css-selector', itemId:'attributetypeselectorsVal', value:me.attributeSelectors.typedSelectors.String}   
         
         ]     
       }, // eo selectorsCt
         
  
         
         
  
         {xtype:'tbspacer', height:20},


         
         {  xtype: 'fieldcontainer', fieldLabel:'<br>CSS Zelle', itemId:'cellsCt',  layout:'hbox', items:[
           {fieldLabel:'<b>Zelle Label', labelAlign: 'top', xtype: 'textarea', cls:'xty_css-code xty_css-props', itemId:'labelCellsCls', width : 400,  margin:'0 0 4 0', minHeight: cssTexareaHeight, height: cssTexareaHeight,    value:'color:red; border-color: red !important; '}  ,                    
           {fieldLabel:'<b>Zelle Feld', labelAlign: 'top',  xtype: 'textarea', cls:'xty_css-code xty_css-props',  itemId:'fieldCellsCls', width : 400,  margin:'0 0 0 4',  minHeight: cssTexareaHeight, height: cssTexareaHeight,    value:'background-color: gold !important;  background-image: none !important; border-color: gold !important; '}                    
          
           ]     
         },
         
         
         {  xtype: 'fieldcontainer', fieldLabel:'<br>CSS Zellinhalt', itemId:'cellcontentsCt', layout:'hbox',  items:[
           {fieldLabel:'<b>Label', labelAlign: 'top',xtype: 'textarea', cls:'xty_css-code xty_css-props', itemId:'labelsCls', width : 400, margin:'0 0 4 0',  minHeight: cssTexareaHeight, height: cssTexareaHeight,    value:'color:pink; border-color: pink !important; '}  ,                    
           {fieldLabel:'<b>Feld', labelAlign: 'top', xtype: 'textarea', cls:'xty_css-code xty_css-props', itemId:'fieldsCls',width : 400, margin:'0 0 0 4',   minHeight: cssTexareaHeight, height: cssTexareaHeight,    value:'background-color: tomato !important;  background-image: none !important; border-color: tomato !important; '}                      
          
           ]     
         },
         
         
         
         { hideEmptyLabel: false , xtype: 'fieldcontainer', itemId:'genBtnCt',   items:[
           {xtype:'button', text:'Generieren', handler: updateGenClsTextarea}
           ]     
         },

         {xtype:'tbspacer', height:20},
         
        {
          xtype  : 'textareafield', 
          itemId:'genClsTextarea',
          cls:'xty_css-code xty_css-props',
          fiesldLabel:'generiertes Attributspezifisches CSS',  

          grow      : true,
          value:    gencls,
          name      : 'genClsTextarea',
          growMax: 520,
          //height:2000,
          //fieldLabel: 'genCls ',
          anchor    : '98%'
      }]
         
      }  
         
      ]
   };

    tabPanCenter.addAndActivate(attributeCSSGeneratorPanel); 
    
    
    },
    
    
    generateAttributeSpecificCls: function(cfg) {

      var me = this;
      
      

      var customer = cfg.customer ? cfg.customer.toUpperCase(): '';   
      var attributetypes = cfg.attributetypes;
     

      var attributes = cfg.attributes ? cfg.attributes : '';   
      
      attributes = attributes.trim();
      attributes = attributes.replace(/\s/g, ',');
      //attributes = attributes.replace(/\s\s/g, ' ');
      
      //attributes = attributes.replace(/,/g, ' ');
      attributes = attributes.split(',');
      
      
      var attributeKeys = attributes;
      
      
      var cls = cfg.cls;
      
      var labelCellsCls = cfg.labelCellsCls;
      var labelsCls = cfg.labelsCls;
      var fieldCellsCls = cfg.fieldCellsCls;
      var fieldsCls = cfg.fieldsCls;
      

      
      var attributeCls = '\n';
      
      attributeCls+= '/*-------------- [  AttributeSpecific-CSS for '+customer+', generated by extVia.protos.cssGenerator v.'+me.version+' #generateAttributeSpecificCls START ] ----------------*/\n\n';     
      
      // Verpackung_Laenge Verpackung_Breite Verpackung_Hoehe Palette_Laenge Palette_Breite Palette_Hoehe
      
      var attributeLabelCls = '';
      var attributeLabelCellsCls = '';
      var attributeFieldCls = '';
      var attributeFieldCellsCls = '';

      
      var i ;
      for (i =0; i < attributeKeys.length ; i++){ 
       var  attributeKey = attributeKeys[i].trim();
       var isLast = i === attributeKeys.length-1;
       if(!Ext.isEmpty(attributeKey)){
        //var rowSelector = '.lty_prat-'+attributeKey+'-row'; 
        var labelCellSelector = '.lty_prat-label-td__'+attributeKey; 
        var fieldCellSelector = '.lty_prat-field-td__'+attributeKey; 

        
         var parentEl = '.lty_form-productsupdate'; 
         parentEl='';
        
         if (!Ext.isEmpty(labelCellsCls)){
           if (i===0){ attributeLabelCellsCls+= '/* label-cells */\n'; }
           var selectorLabelCell = parentEl+' '+labelCellSelector;
           attributeLabelCellsCls+= selectorLabelCell + (isLast ?'':',')  +  (isLast || (i+1)%2===0 ?'\n':'') ;
           if (isLast){ attributeLabelCellsCls+='\t{ '+ labelCellsCls +' }\n'; }
         }
         
         if (!Ext.isEmpty(labelsCls)){
           if (i===0){ attributeLabelCls+= '/* labels */\n'; }
           var selectorLabel = parentEl+' '+labelCellSelector+' .lty_pratDscrSPAN';
           attributeLabelCls+= selectorLabel + (isLast ?'':',') +  (isLast || (i+1)%2===0 ?'\n':'') ;
           if (isLast){ attributeLabelCls+='\t{ '+ labelsCls +' }\n'; }
         }

         
         if (!Ext.isEmpty(fieldCellsCls)){
           if (i===0){attributeFieldCellsCls+= '/* field-cells */\n'; }
           var selectorFieldCell = parentEl+' '+fieldCellSelector;
           attributeFieldCellsCls+= selectorFieldCell + (isLast ?'':',') +  (isLast || (i+1)%2===0 ?'\n':'') ;
           if (isLast){ attributeFieldCellsCls+='\t{ '+ fieldCellsCls +' }\n'; }           
         }

         
         
         if (!Ext.isEmpty(fieldsCls)){
           if (i===0){attributeFieldCls+= '/* fields */\n'; }
           var selectorField = parentEl+' '+fieldCellSelector+' .lty_pratInp';
           attributeFieldCls+= selectorField + (isLast ?'':',')  +  (isLast || (i+1)%2===0 ?'\n':'') ;
           if (isLast){ attributeFieldCls+='\t{ '+ fieldsCls +' }\n'; }           
         }
         
         
       }
      }
      
      
      attributeCls+=attributeLabelCellsCls;
      attributeCls+=attributeLabelCls;
      attributeCls+=attributeFieldCellsCls;
      attributeCls+=attributeFieldCls;
      
      
//      for (i =0; i < attributeKeys.length ; i++){ 
//        var  attributeKey = attributeKeys[i].trim();
//        var isLast = i === attributeKeys.length-1;
//        if(!Ext.isEmpty(attributeKey)){ 
//         //var rowSelector = '.lty_prat-'+attributeKey+'-row'; 
//         //var labelCellSelector = '.lty_prat-'+attributeKey+'-label-td'; 
//         var fieldCellSelector = '.lty_prat-'+attributeKey+'-field-td'; 
//          var selectorCell ='FORM[action*="ProductsUpdate"]   '+fieldCellSelector+' .lty_pratCellValue ';
//          attributeCls+= selectorCell + (isLast ?'':',') +  '\n';
//          if (isLast){ attributeCls+='\t{ '+ cls +' }\n'; }
//        }
//       }
//      
      
      
      
      
      attributeCls+= '\n/*-------------- [  AttributeSpecific-CSS generated END ] ----------------*/\n'; 
      
      attributeCls+='\n';
      
     // me.showGeneratedClsInTab(attributeCls, 'attributeCls');
    
      return attributeCls;
       
   },
    
    
    
  generateCustomHityIconsCls: function(hityIds) {

    var me = this;
    
    var hityCls = '\n';
    
    
    
    hityCls+= '/*-------------- [  CustomHityIconsCls generated by extVia.protos.cssGenerator v.'+me.version+' #generateCustomHityIconsCls START ] ----------------*/\n';     
    
    
    
    var i ;
    for (i =0; i < hityIds.length ; i++){ 
    
     var  hityId = hityIds[i];
    
      
      hityCls+='.xty_epobProductgroupHity'+hityId+' .x-tree-icon, .xty_epobProductgroupHity'+hityId+'{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL0_REF0.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'Ref .x-tree-icon, .xty_epobProductgroupHity'+hityId+'Ref{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL0_REF1.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'Rel .x-tree-icon, .xty_epobProductgroupHity'+hityId+'Rel{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL1_REF0.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'RelRef .x-tree-icon, .xty_epobProductgroupHity'+hityId+'RelRef{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL1_REF1.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'Mass .x-tree-icon, .xty_epobProductgroupHity'+hityId+'Mass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL0_REF0.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'RefMass .x-tree-icon, .xty_epobProductgroupHity'+hityId+'RefMass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL0_REF1.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'RelMass .x-tree-icon, .xty_epobProductgroupHity'+hityId+'RelMass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL1_REF0.gif") !important; background-repeat:no-repeat;}\n'; 
      hityCls+='.xty_epobProductgroupHity'+hityId+'RelRefMass .x-tree-icon, .xty_epobProductgroupHity'+hityId+'RelRefMass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL1_REF1.gif") !important; background-repeat:no-repeat;}\n'; 
  
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL0_REF0.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'Ref{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL0_REF1.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'Rel{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL1_REF0.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'RelRef{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_STANDARD_REL1_REF1.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'Mass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL0_REF0.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'RefMass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL0_REF1.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'RelMass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL1_REF0.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 
      hityCls+='.xty_thumbsdvBigBoxwrap .xty_epobProductgroupHity'+hityId+'RelRefMass{background-image:url("../jsp/via-img/epobs/products/conditions/HT'+hityId+'_MASS_REL1_REF1.gif");margin-left:0px;margin-top:1px;position:absolute;height:16px;width:16px}\n'; 

    }
    
    
    hityCls+= '/*-------------- [  CustomHityIconsCls generated END ] ----------------*/\n'; 
    
    hityCls+='\n';
    
    me.showGeneratedClsInTab(hityCls, 'hity');
    
    
    },
    
    generateCssHityCustomSpecificIcons: function() {
      // generated by ~lty/pg/epobProductsCSS.jsp?p_sShowCss=1] 
      //  LookTools.initCssHityCustomSpecificIcons 
      // LookTools.getCSSStringHityCustomSpecificIcons(iClientsId

      
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
      
      
//      var icons=[
//        'HT{x}_STANDARD_REL0_REF0.gif',
//        'HT{x}_MASS_REL0_REF0.gif'
//      ];
      
      
      //https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/fillRect
      var canvasArr=[];
      var generateCanvasItems= function(){

        var i ;
        for (i =0; i < 4; i++){ 
          var standard = i<2;
          var mass = !standard;
          var canvLeftId = standard ? '_STANDARD' :'_MASS';
          
          var j;
          for (j =0; j < 2; j++){
            var canvId = canvLeftId;  
            var rel = i%2;
            var ref = j;
            
            canvId+='_REL'+rel;
            canvId+='_REF'+ref;

            canvasArr.push(
                {itemId:canvId, standard:standard, mass:mass, rel:rel, ref:ref,  html:canvId+' <canvas id="canv'+canvId+'" style=""  width="15" height="15"></canvas>'}
            );
          }
 
        }
        return canvasArr;
      };
      generateCanvasItems();
      
      
     var exportCanvasItems; 
     var hityId='1';
     var downloadHityIcons= function(btn){
       hityId = btn.ownerCt.getComponent('hityId').getValue(); 
       exportCanvasItems();
     };
      
     
     var drawCanvasItems;
     var spaceInvaderImgSrc = './hityIcons/spaceInvader-orange_15.gif';
     var hityIconCombo =  Ext.create('Ext.form.ComboBox', {
         emptyText:'hity iconUrl', 
         store:  Ext.create('Ext.data.Store', {
           fields: ['iconUrl', 'name'],
           data : [
               {"iconUrl": "./hityIcons/spaceInvader-pink_15.gif", "name":"spaceInvader pink"},
               {"iconUrl": "./hityIcons/spaceInvader-red_15.gif", "name":"spaceInvader red"},
               {"iconUrl": "./hityIcons/spaceInvader-blue_15.gif", "name":"spaceInvader blue"},
               {"iconUrl": "./hityIcons/spaceInvader-green_15.gif", "name":"spaceInvader green"},
               {"iconUrl": "./hityIcons/spaceInvader-orange_15.gif", "name":"spaceInvader orange"}
           ]
         }),
         listeners:{
           change: function(combo){
             //alert('hityIconCombo change '); //+combo.getValue());
             spaceInvaderImgSrc = combo.getValue();
             drawCanvasItems();
           }
         },
         listConfig : {
          minWidth:180,
          getInnerTpl : function(displayField) {
            var tpl = '<div class="xty_hityIcons-item" style="" ><span style="background-image: url({iconUrl}); padding-left:18px; background-repeat:no-repeat;" >' + '&nbsp; {name}' + '</span></div>';
            return tpl;
            }
          },
         queryMode: 'local',
         displayField: 'name',
         valueField: 'iconUrl'
     });
     
     
      var canvasEditorPagetoolbarButtons =  [hityIconCombo,
        {itemId:'hityId', xtype:'textfield', emptyText:'hity Id'},{itemId:'download', handler: downloadHityIcons}] ;
      var canvasEditorAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'generator' , epobDscr: 'Hierarchytype Icons',    
       xpgjobButtons: [    ], pagetoolbarButtons: canvasEditorPagetoolbarButtons } );
      
      
      
      var canvasEditorPanel  = {
          title: 'canvas', itemId:'canvasPanel', closable:true, 
          tbar: canvasEditorAppbar,
          cls:'xty_canvasPanel',
          
          layout: {
            type: 'table',
            padding:4,
            columns: 4
          },

          
          defaults:{
           // margin:'4 4 4 4',
          },
          items:canvasArr 
      
      };
     tabPanCenter.addAndActivate(canvasEditorPanel);

     
     function exportCanvasAsGIF(id, fileName) {
       var canvasElement = document.getElementById(id);
       var MIME_TYPE = "image/gif";
       var imgURL = canvasElement.toDataURL(MIME_TYPE);

       var dlLink = document.createElement('a');
       dlLink.download = fileName;
       dlLink.href = imgURL;
       dlLink.dataset.downloadurl = [MIME_TYPE, dlLink.download, dlLink.href].join(':');

       document.body.appendChild(dlLink);
       dlLink.click();
       document.body.removeChild(dlLink);
    }
     
     
     drawCanvasItems= function(){
       var i;
       for (i =0; i < canvasArr.length; i++){ 
         var canvasItem = canvasArr[i];
         var canvasId = 'canv'+canvasItem.itemId;
         var canvas = document.getElementById(canvasId);

         var context;
         try{
           context = canvas.getContext("2d"); 

           context.fillStyle = "white";
           context.fillRect(0, 0, 15, 15);       
           
         if(canvasItem.rel===1){ // dependant from WorkflowStatus
//           context.lineWidth = 1;
//           context.strokeStyle = "#1eb829";
//           context.strokeRect(0, 0, 15, 15);    
           context.fillStyle = "#1eb829";
           context.fillRect(0, 0, 15, 15);
           context.fillStyle = "white";
           context.fillRect(1, 1, 13, 13);
         }

           var spaceInvaderImg = new Image();   // Create new img element
           spaceInvaderImg.src = spaceInvaderImgSrc;
           context.drawImage(spaceInvaderImg, 0, 0);

           

// Genarate Text does look ugly because of missing anti-aliasing           
//           context.font = 'bold 13pt Helvetica neue'; // context.font="italic small-caps bold 12px arial";
//           context.fontWeight = 'bold';
//           //context.strokeStyle = "#545454";
//           //context.strokeText('G', 2, 12);
//           context.fillStyle = "#545454";
//           context.fillText('G', 1, 14);
           
           
           if(canvasItem.ref===1){ // means is Reference
             var refImg = new Image();   // Create new img element
             refImg.src = './hityIcons/modifier-ref_6.gif';
             context.drawImage(refImg, 9, 9);
             
           }
           
           if(canvasItem.mass){ // dependant from TreeLoadMaxNodes-Parameter
             var massImg = new Image();   // Create new img element
             massImg.src = './hityIcons/modifier-mass_7x4.gif';
             context.drawImage(massImg, 7, 0);
           }
         }
         catch(canvasEx){
           extVia.notify('canvasEx '+canvasEx);
         }         
         
       }

     };
     
     drawCanvasItems();
     
     exportCanvasItems= function(){
       var i;
       for (i =0; i < canvasArr.length; i++){ 
         var canvasItem = canvasArr[i];
         var canvasId = 'canv'+canvasItem.itemId;
         exportCanvasAsGIF(canvasId,'HT'+hityId+canvasItem.itemId+'.gif');
//         var exportCanvasAsGIFTask = new Ext.util.DelayedTask(function(){
//            exportCanvasAsGIF(canvasId,'acdc.gif');
//         });
//         exportCanvasAsGIFTask.delay(2500);
         
       }
     };
 
    },
    
    
   
    
    
    initWest: function() {

      var me = this;
      
      Ext.create('Ext.data.Store', {
         storeId:'whateverStore',
         fields:['id', 'epobType', 'name', 'status', 'responsible'],
         data:{'items':[
             {id:'1', epobType:'Product', name:'Flow 1', status:'Warnung', responsible:'Ernie'  },
             {id:'2', epobType:'Image', name:'Bilder hochladen', status:'', responsible:'Oskar'  },
             {id:'3', epobType:'Video', name:'Welt retten', status:'Start', responsible:'Grobi'  },
             {id:'4', epobType:'User', name:'Kuchen backen', status:'Danger', responsible:''  },
             {id:'5', epobType:'Attribute', name:'Datenbank zerst&ouml;ren', status:'Success', responsible:''  },
             {id:'6', epobType:'Product', name:'Produkte pflegen', status:'Wait', responsible:''  }
         ]},
         proxy: {
             type: 'memory',
             reader: {
                 type: 'json',
                 root: 'items'
             }
         }
       });

       var epobTypeRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
         };
       var statusRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon_'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
         };

        var whateverGrid = Ext.create('Ext.grid.Panel', {
          itemId:'whateverGrid',
              width: 400,
              border:false,
              store: Ext.data.StoreManager.lookup('whateverStore'),
              columns: [
                   { header: 'Typ',  dataIndex: 'epobType', width:32, renderer:epobTypeRenderer },
                   { header: 'Name',  dataIndex: 'name' ,  flex: 1},
                   { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
                   { header: 'Verantwortliche', dataIndex: 'client', 
                     renderer: function(){
                       var clientsHtml = 
                         '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
                           '<span class="xty_tag" title="Muppets">Muppets</span>' +
                           '<span class="xty_tag" title="Puppets" >Puppets</span>' +
                         '</span>';
                       return clientsHtml;
                     }
                   },
                 { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
           ],
           height: 200,
               listeners:{
                itemdblclick: function( view, record, item, index, evt, eOpts ){
                 me.showEditor(record);
                }
               
               }
          
       });

         var whateverList = {
             title:'Whatever',
             itemId:'whateverList',
             height: me.getWestListHeight(),
             tbar:[
             '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'L&ouml;schen', handler: me.deleteEpobDialog}
             ],
             items:[ whateverGrid ] ,
             bbar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
          };
  
         
         
         
         var structureTreeStore = Ext.create('Ext.data.TreeStore', {
           root: {
               expanded: true,

               text: "Bohrmaschine",
               iconCls:'xty_epobProduct',
               children: [
                   { text: "Audios"},
                   { text: "Bilder", expanded: true, children: [
                       { text: "book report", leaf: true, iconCls:'xty_epobImage'},
                       { text: "alegrbra", leaf: true,  iconCls:'xty_epobImage'}
                   ] },
                   { text: "Texte"}
               ]
           }
       });

       var structureTreePanel = Ext.create('Ext.tree.Panel', {
           title: 'Produktstruktur',
           useArrows : true,  
           viewConfig: {
             plugins: {
                 ptype: 'treeviewdragdrop'
             }
           },
           itemId:'structureTreeTab',
           border:false,
           store: structureTreeStore,
           tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign'}]
       });
         
         
         
         var structureTreeTab = { 
                title:'Produktstruktur', 
                itemId:'structureTreeTab',
                tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign'}],
                items:[structureTreePanel]
          }; 
 
         var hierarchyTab = extVia.hierarchy.statics.getHierarchyTabCfg({});
         
         var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
             tabBar:{ 
               tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
               handler:function(button){
                 var activeTab = button.ownerCt.ownerCt.getActiveTab();
                   extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                 }
                }
               ]
             },
             items:[structureTreePanel, hierarchyTab, whateverList]
             });
            extVia.regApp.myRaster.addToWest(tabPanWest);

    },
    
    
    
  getDnDGridsPanel: function(cfg) {
    
    Ext.define('DataObject', {
      extend: 'Ext.data.Model',
      fields: ['name', 'column1', 'column2']
    });
    
      var myData = [
        { name : "Rec 0", column1 : "0", column2 : "0" },
        { name : "Rec 1", column1 : "1", column2 : "1" },
        { name : "Rec 2", column1 : "2", column2 : "2" },
        { name : "Rec 3", column1 : "3", column2 : "3" },
        { name : "Rec 4", column1 : "4", column2 : "4" },
        { name : "Rec 5", column1 : "5", column2 : "5" },
        { name : "Rec 6", column1 : "6", column2 : "6" },
        { name : "Rec 7", column1 : "7", column2 : "7" },
        { name : "Rec 8", column1 : "8", column2 : "8" },
        { name : "Rec 9", column1 : "9", column2 : "9" }
    ];

    // create the data store
    var firstGridStore = Ext.create('Ext.data.Store', {
        model: 'DataObject',
        data: myData
    });


    // Column Model shortcut array
    var columns = [
        {text: "Record Name", flex: 1, sortable: true, dataIndex: 'name'},
        {text: "column1", width: 70, sortable: true, dataIndex: 'column1'},
        {text: "column2", width: 70, sortable: true, dataIndex: 'column2'}
    ];

    // declare the source Grid
    var firstGrid = Ext.create('Ext.grid.Panel', {
        multiSelect: true,
        viewConfig: {
            plugins: {
                ptype: 'gridviewdragdrop',
                dragGroup: 'firstGridDDGroup',
                dropGroup: 'secondGridDDGroup'
            },
            listeners: {
                drop: function(node, data, dropRec, dropPosition) {
                    var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
                    //Ext.example.msg("Drag from right to left", 'Dropped ' + data.records[0].get('name') + dropOn);
                    extVia.notify({action:'Drag from right to left'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
                    
                }
            }
        },
        store            : firstGridStore,
        columns          : columns,
        stripeRows       : true,
        title            : 'First Grid',
        margins          : '0 2 0 0'
    });

    var secondGridStore = Ext.create('Ext.data.Store', {
        model: 'DataObject'
    });

    // create the destination Grid
    var secondGrid = Ext.create('Ext.grid.Panel', {
        viewConfig: {
            plugins: {
                ptype: 'gridviewdragdrop',
                dragGroup: 'secondGridDDGroup',
                dropGroup: 'firstGridDDGroup'
            },
            listeners: {
                drop: function(node, data, dropRec, dropPosition) {
                    var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
                    //Ext.example.msg("Drag from left to right", 'Dropped ' + data.records[0].get('name') + dropOn);
                    extVia.notify({action:'Drag from left to right'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
                }
            }
        },
        store            : secondGridStore,
        columns          : columns,
        stripeRows       : true,
        title            : 'Second Grid',
        margins          : '0 0 0 3'
    });

    //Simple 'border layout' panel to house both grids
    var displayPanel = Ext.create('Ext.Panel', {
        width        : 650,
        height       : 300,
        layout       : {
            type: 'hbox',
            align: 'stretch',
            padding: 5
        },

        defaults     : { flex : 1 }, //auto stretch
        items        : [
            firstGrid,
            secondGrid
        ],
        dockedItems: {
            xtype: 'toolbar',
            dock: 'bottom',
            items: ['->', // Fill
            {
                text: 'Reset both grids',
                handler: function(){
                    //refresh source grid
                    firstGridStore.loadData(myData);

                    //purge destination grid
                    secondGridStore.removeAll();
                }
            }]
        }
    });

      var dndGridsDisplayPanel = displayPanel; //{title:'acdc'};
      return dndGridsDisplayPanel;
      
    },
    

    
    launch: function() {
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      var me = this;
      var  modulDscr = 'css Generator';


      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.constants.raster.mainWestWidth = 360;
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);


       me.initWest();
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
        handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
        iconCls:'x-tool x-tool-refresh'}]  } 
      });

      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      
      
      // if you ned an extra App Panel:  cssGenerator-Module
       var generatorModuleAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'cssGenerator modul', epobDscr:null,  
         pgjobButtons: [
           {itemId:'attribute', tooltip:'Generate Attribute specific css', iconCls:'xty_pgtoolbar-attribute', handler:me.showAttributeSpecificDialog},
           {itemId:'start'},
           {itemId:'execute'},
           {itemId:'search',  xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}}
         ] } );

       var generatorModulePanel = {title:'cssGenerator modul', itemId:'genmodulePanel', tbar: generatorModuleAppbar, 
       //height:864,
       autoScroll:true,
       defaults:{margin:'24 24 24 24'},                            
       items:[
           {xtype:'form', title:'parse', itemId:'parseform', collapsed: true, collapsible: true, width:580, height:732, tools:[
             { id:'gear', 
               handler:function(event, toolEl, panel){
                 var textarea  = panel.ownerCt.getComponent('parsearea');
                 var value = textarea.getValue();
                 
                 
                 var valArr = value.split('\n');
                 var retStr ='';
                 
                 
                 var coll = new Ext.util.MixedCollection();
                 var i;
                 for(i =0; i < valArr.length; i++){
                   var line = valArr[i].trim();
                   if(!Ext.isEmpty(line) ){
                     
                     
                     // extract treestore from
                     var jsonStr = line.replace(/},$/,'/}');
                     jsonStr = jsonStr.replace(/<code class="xty_queryMatch">/,'');
                     jsonStr = jsonStr.replace(/<\/code>/,'');
                     jsonStr = jsonStr.replace(/(:[.^:]*"[.^"]*)".*"/,'');
                     var epob =Ext.decode(jsonStr);
                     epob.epobId = epob.id;
                     delete epob.id;
                     
                     if (epob.epobTypeId==='PG'){
                       epob.epobTypeId = 'PRODUCTGROUP';
                       epob.iconCls = 'xty_epobProductgroup';
                     }
                     if (epob.epobTypeId==='PP'){
                       epob.epobTypeId = 'PRODUCT';
                       epob.iconCls = 'xty_epobProduct';
                     }                    

                     if (epob && Ext.isEmpty( coll.get(epob.epobId))){
                       coll.add(epob.epobId.toString(), epob);
                     }

                     if (epob && epob.parentId){
                       var parent = coll.get(epob.parentId);
                       if (parent){
                         if (! parent.children){
                           parent.children =[];
                         } 
                         parent.children.push(epob);
                       } 
                       delete epob.parentId;
                     }
                     else{
                       epob.leaf = true;
                     }
                   }
                }
                                  
                 extVia.notify('coll '+Ext.encode(coll.get('-99')));

                 
                }
             },
             { id:'maximize', tooltip:'csslint', 
               handler:function(){window.open("http://csslint.net","newwindow");}
             }
              ],
             items:[{xtype:'textarea', itemId:'parsearea', width:572, growMax:700,  growMin:300, height:700, grow:true, margin:'4 5 4 3'}]
           }
         ] 
       };
       
       tabPanCenter.addAndActivate(generatorModulePanel);

      // ProductEditor - prodEditor

     var prodEdiBoxDefaults = { labelWidth : 180, width : 460,  msgTarget:'side',  xtype:'textfield',   margin:'4 0 4 4' };

     var editorSubTabHeight = me.getEditorSubTabHeight();
     
     var striptoolHandler = function(button){
       var editorPan = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
       var editorSubTabsActiveTab = editorPan.getComponent('editorSubTabsPanel').getActiveTab().title;
       extVia.notify({action: button.itemId+' Center SubTab'  , mssg:  '<b>'+editorSubTabsActiveTab+'</b>'}); 
     };
     
     var appIsInsideWebserver = location.href.indexOf('http://')>-1;
     
     var prodEditorSubTabsPanelCfg =     { 
        xtype:'tabpanel',
        itemId:'editorSubTabsPanel',
        border:false, 
        margin : '0 0 0 0', 
        cls:'xty_prodEditorTabPanel', 
        activeTab:  3, 
        tabBar:{cls:'xty_subtabpanel-tabbar',   
          tools:[
            {xtype:'tbfill'},
            {xtype:'button', itemId:'maximize', handler:striptoolHandler, cls:'xty_striptool-button xty_striptool-button-maximize', iconCls:'x-tool x-tool-maximize',style:'margin-top:2px;'},
            {xtype:'button', itemId:'refresh',  handler:striptoolHandler, cls:'xty_striptool-button xty_striptool-button-refresh',  iconCls:'x-tool x-tool-refresh',style:'margin-top:2px;'}
           ]
          }, 

        defaults:{ // defaults for tab-panels
                   border:false,
                   XautoScroll:true, height: editorSubTabHeight, 
                   defaults:{ // defaults for boxes
                    xtype:'form', width:580, margin:'24 24 24 24',
                    defaults:{ // defaults for box-items
                    labelWidth : 180,
                    width : 380,
                    msgTarget:'side',
                    xtype:'textfield', 
                    margin:'4 0 4 4'
                     }
                   }
                },
        items:[
          {title:'Produkt', items:[
            { xtype:'form', title:'Metadaten', itemId:'metadata',  collapsible:true,
              defaults:prodEdiBoxDefaults, items:[{fieldLabel:'Name', allowBlank:false, value:'Bohrmaschine'}]
            },
            { xtype:'form', title:'&Auml;nderungsinfo', itemId:'changeInfo', defaults:prodEdiBoxDefaults,
             items:[  { itemId:'changeDate', xtype:'displayfield', fieldLabel:'Anlage', value:'heute' }, { itemId:'creationDate', xtype:'displayfield', fieldLabel:'letzt �nderung', value:'' }]
            }
           ]
          },
          {title:'Attribute', itemId:'attributes',  items:[  ]},
          {title:'Elemente',  itemId:'elements', items:[  ]},


          
          
          {title:'css Generator', itemId:'cssGenerator-1', items:[       
            { xtype:'form', title:'Search', itemId:'search',  collapsible:true,collapsed:true,
              defaults:prodEdiBoxDefaults, items:[
                  {fieldLabel:'Name'},
                  {fieldLabel:'Id'},
                  Ext.create('Ext.form.ComboBox', {
                    fieldLabel:'Attribute', labelWidth:180,
                      store:  Ext.create('Ext.data.Store', {
                        fields: ['abbr', 'name'],
                        data : [
                            {"abbr":"AL", "name":"Easy"},
                            {"abbr":"AK", "name":"Medium"},
                            {"abbr":"AZ", "name":"Advanced"}
                        ]
                      }),
                      queryMode: 'local',
                      displayField: 'name',
                      valueField: 'abbr'
                  }),
                  {fieldLabel:'Date', xtype:'datefield'}  
                  ]
            },
            
            Ext.create('Ext.grid.Panel', {
              title: 'Users', collapsible:true,collasdpsed:true,
              height:400,
              maxHeight:400,
              store: Ext.create('Ext.data.Store', {
              model: Ext.define('User', {
                  extend: 'Ext.data.Model',
                  fields: [
                      {name: 'name', type: 'string'},
                      {name: 'id',   type: 'string'},
                      {name: 'born', type: 'string'},
                      {name: 'who',  type: 'string'}                            
                  ]
              }),

              xdata:[
                {"name": "Oscar Wilde", "id": "12327","born": "1854", "who": "Writer" },     
                {"name": "Werner T.Kuestenmacher", "id": "12312", "born": "1953 ","who": "simplify founder"},
                {"name": "Kira Kr&auml;mer","id": "1239", "born": "1972", "who": " Design Thinking Teacher"}
              ],
              // >>> PROD V4 Start (EPIM-7678) <<<
              proxy: {
                  type: 'ajax',
                  url : '../data/users.json',
                  reader: {
                      type: 'json',
                      root: 'users'
                  }
              },
              // >>> PROD V4 End (EPIM-7678) <<<
              autoLoad: true
              }),
            
              columns: [
                  { header: 'Name', width:184, dataIndex: 'name' },
                  { header: 'Born', dataIndex: 'born'  },
                  { header: 'Profession', dataIndex: 'who', flex: 1 },
                  { header: 'id', dataIndex: 'id', hidden: true }
              ]  
          }),

            {title:'some css links',xtype:'form', xtsype:'toolbar', collapsible:true,collapsed:true,  
              defaults:{xtype:'button'}  , 
              items:[ 
                {text:'sass',  href:'http://sass-lang.com/'}

              ]
            }
            ]
          }        
        ]
      };  


      
      var epob = {epobId:'drill_1', dscr:'Bohrmaschine', epobType:'Product'};

      
      var uiLangIso = extVia.locales.uiLangIso;
      
      var prodEditorPagetoolbarButtons =  [{itemId:'save'},{itemId:'export'},{itemId:'collectionAddTo'},{xtype:'splitbutton', itemId:'versioning-create'}] ;
      // >>> PROD V4 Start (EPIM-7678) <<<
      var prodEditorAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Produktpflege' , epobDscr: epob.dscr,    
        pgjobButtons: [  
          {
            xtype: 'buttongroup',
            itemId:'contentSwitcherBtnGrp',
            items:[
              {iconCls : 'xty_icon_'+uiLangIso, cls:'xty_language-chooser', itemId:'language',tooltip:'Sprache',height:22, width:22, scale: 'small',
                menu:{
                  items:[{
                    xtype:'boundlist', 
                    queryMode: 'local',
                    multiSelect : true,
                    displayField: 'dscr',
                    store: extVia.stores.initLanguageStore(),
                    listeners:{
                      itemclick: function( view, record, item, index, e, eOpts ){
                        var iso2 = record.get('iso2');         
                        this.ownerCt.floatParent.setIconCls('xty_icon_'+iso2);
                        this.ownerCt.floatParent.setTooltip(record.get('dscr'));
                        this.ownerCt.hide();
                        if (iso2==='de' || iso2==='en'|| iso2==='us' || iso2==='ro' ){
                         extVia.ui.page.raster.reloadPage('uiLangIso='+iso2);
                        }    
                      }
                    },
                    itemTpl : '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>',
                    heidght:150}]
                }  
              }
            ]
           }
          ], pagetoolbarButtons: prodEditorPagetoolbarButtons, breadcrumb:'ACME/Elektrowerkzeuge/Akkuger&aumlte/Akku-Bohrschrauber' } );
      // >>> PROD V4 End (EPIM-7678) <<<
      var prodEditorPanel  = {title: epob.dscr, itemId:'editorPanel', closable:true, tbar: prodEditorAppbar,
        items:[prodEditorSubTabsPanelCfg  ] 
      };
     // tabPanCenter.addAndActivate(prodEditorPanel);    

      
    //  me.generatePageToolbarIconCls({oldGUI:true});
      
    //  me.generatePageToolbarIconCls({newGUI:true});
      
    //  me.generateEpobIconsForNetworkGraph();
      
   //   me.generateTimeRelatedCollapseCls();
      
      
    //  me.generateCustomHityIconsCls([7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]);
      
      
      me.showAttributeSpecificDialog();
      
       
       var anchor ;
       var url = location.href;
       var hashIndex = url.indexOf('#');
       if (hashIndex>-1){
         anchor = url.substring(hashIndex+1);  
         if (anchor){
          
           if (anchor.indexOf('pgtoolbaricons')>-1){
             me.generatePageToolbarIconCls({oldGUI:true});
             me.generatePageToolbarIconCls({newGUI:true});
           }
           
           
           if (anchor.indexOf('hityicons')>-1){
             me.generateCssHityCustomSpecificIcons({hityId:123});
           }  
         } 
       }
       
       
    }
});



/*
 * 
 * $Revision: 1.11.6.37 $
   $Modtime: 15.11.17 12:40 $ 
   $Date: 2019/12/11 07:59:44 $
 * $Author: lowen $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 
