Ext.Loader.setConfig({
  enabled : true,
  disableCaching : true
});

Ext.require([ '*' ]);

Ext.application({
      name : 'baseProtoApp',
      // controllers: ['Users'],
      appMode : {},
      launch : function() {

        // this.appMode = extVia.app.setup.appMode; // preconfigured oby Url on javaside
        extVia.ui.page.raster = new extVia.ui.page.BaseRaster({
          hideWest : false
        });
        extVia.ui.page.raster.onReady(this);
        
        Ext.tip.QuickTipManager.init();

        
        // ///////////////////////////////////////////// WEST ///////////////////////////////////////////////
        
        var dummyGridData = [{
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:29 [ ALL ] - MissingResourceException: >>>>>>>> GlobalVariables.doUpdateSync called for GlobalVariables_HityCustomSpecificIcons <<<<<<<<<<<",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "34953",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:32 [ ALL ] - MissingResourceException: >>>>>>>> GlobalVariables.doUpdateSync called for GlobalVariables_UsersClientId <<<<<<<<<<<",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "34991",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:36 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_3 ",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "35064",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:37 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_5 ",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "35077",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_4 ",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "35090",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:38 [ ALL ] - MissingResourceException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "35093",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:40 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_6 ",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "35138",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
          filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
          hit: "31 Jan 2013 14:04:41 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S ",
          filename: "VIACONTENTPUBLISH_1.log",
          rowNumber: "35152",
          date: "31 Jan 2013",
          searcharea: "EPIM"
      }, {
        filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
        hit: "31 Jan 2013 14:04:40 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_6 ",
        filename: "VIACONTENTPUBLISH_1.log",
        rowNumber: "35165",
        date: "31 Jan 2013",
        searcharea: "EPIM"
    }, {
        filePath: "d:\\viaLOG\\VIACONTENTPUBLISH_1.log",
        hit: "31 Jan 2013 14:04:41 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S ",
        filename: "VIACONTENTPUBLISH_1.log",
        rowNumber: "35178",
        date: "31 Jan 2013",
        searcharea: "EPIM"
    }];
        
        
        var panelMw = Ext.getCmp('panel_mw');
        var panelMwWidth = panelMw.getWidth() - 2;
        var panelMwHeight = panelMw.getHeight() - 2;
        var txt2Search = "exception";
		
        // this fieldContainer contains search textfield, regex, 
        // search button and 2 datefields
        var fieldContainer = {
          xtype: 'form',  // container
          itemId: 'logBrowFieldContainerId',
          border: false,
          padding: '0 0 5 0',
          layout: {
            type: 'table',
            columns: 3
          },
          defaults:{
            margin: '0 10 0 0'
          },
          items: [
          {
            xtype: 'textfield',
            itemId: 'searchfieldId',
            fieldLabel : 'Search term',
            allowBlank : false,
            labelWidth: 70,
            width: 245,
            value: 'exception',
            colspan: 2
          }, {
            xtype: 'button',  //search button
            scale: 'large',
            iconCls: 'xty_pgtoolbar-search',
            width: 50,
            height: 45,
            rowspan: 2,
            colspan: 1,
            handler: function(){
//                searchBtnHandlerFct(this);
              var proxy = Ext.getStore('LogBrowserStoreId').getProxy();
              proxy.data = [];
              
              for(var i=0; i<dummyGridData.length; i++){
                proxy.data.push(dummyGridData[i]);
            }     
          
              Ext.getCmp('pagingToolbarId').doRefresh();
//              Ext.getStore('dummyStoreId').loadData(dummyGridData);
              
            }
          },
          {
            xtype: 'checkbox',
            itemId: 'checkboxId',
            boxLabelAlign: 'before',
            boxLabel: 'RegEx:<span style="margin:32px;"/>',
//            labelWidth: 120,
            checked : false,
//            disabled : true,
            colspan : 2
          }, 
          {
            xtype: 'datefield',
            fieldLabel: 'Start date',
            allowBlank: false,
            itemId: 'startdatefieldId',
            disabled: false,
            labelWidth: 70,
            width: 245,
            format : 'd-m-Y',
            margin: '4 0 0 0',
            value: Ext.Date.add(new Date(), Ext.Date.DAY, -5), // -90
            maxValue: Ext.Date.add(new Date(), Ext.Date.DAY, -1),
//            minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -90),
            colspan: 3
           }, 
           {
            xtype: 'datefield',
            fieldLabel: 'End date',
            allowBlank : false,
            itemId: 'enddatefieldId',
            labelWidth: 70,
            width: 245,
            format : 'd-m-Y',
            margin: '7 0 5 0',
            value: new Date(),
            maxValue: new Date(),
            minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -89),
            colspan: 3
//           emptyText : 'TT-MM-JJJJ',
//           anchor: '100%'
            }]
        };

        var accordionPanel = ('Ext.panel.Panel', {
//          id: "logBrowAccordionPanelId",
          border: false,
          height: 700,
          bodyPadding: 10,
          items: [
                  
           fieldContainer,

            {
             xtype:'fieldset',
             itemId: 'checkboxfieldsetId',
             title: 'LOG files',
             collapsible: true,
             defaultType: 'checkboxfield',
             defaults: {checked : false}, 
//             bodyStyle: 'padding:2px', anchor: '90%'
             items :[{
               boxLabel  : '<i>Select all</i>',
               name      : 'select',
               inputValue: '8',
               margin    : '0 0 5 0',
               listeners : {
                   change: function( that, newValue, oldValue, eOpts ){
                     var fieldSet = this.ownerCt;
                     if (newValue === true) {
                       this.boxLabel = 'Deselect All';
//                       that.setText('Deselect All');                      
                       fieldSet.getComponent('viacontentpublishId').setValue(true);
                       fieldSet.getComponent('viadbconnectionId').setValue(true);
                       fieldSet.getComponent('viatasksId').setValue(true);
                       fieldSet.getComponent('viatableapiId').setValue(true);
                       fieldSet.getComponent('viadataId').setValue(true);
                       fieldSet.getComponent('dbconnectionpoolId').setValue(true);
                       fieldSet.getComponent('mainepimId').setValue(true);
                     } else if (newValue === false) {
//                       that.setText('Select All');
                       this.boxLabel = 'Select All';
                       fieldSet.getComponent('viacontentpublishId').setValue(false);
                       fieldSet.getComponent('viadbconnectionId').setValue(false);
                       fieldSet.getComponent('viatasksId').setValue(false);
                       fieldSet.getComponent('viatableapiId').setValue(false);
                       fieldSet.getComponent('viadataId').setValue(false);
                       fieldSet.getComponent('dbconnectionpoolId').setValue(false);
                       fieldSet.getComponent('mainepimId').setValue(false);
                     }
                   }
               }
             }, {
                boxLabel  : 'viaCONTENTPUBLISH',
                name      : 'logfiles',
                inputValue: '1',
                itemId    : 'viacontentpublishId',
                checked   : true
              }, {
                boxLabel  : 'viaDBCONNECTION',
                name      : 'logfiles',
                inputValue: '2',
                itemId    : 'viadbconnectionId'
              }, {
                boxLabel  : 'viaTASKS',
                name      : 'logfiles',
                inputValue: '3',
                itemId    : 'viatasksId'
              }, {
                boxLabel  : 'viaTABLEAPI',
                name      : 'logfiles',
                inputValue: '4',
                itemId    : 'viatableapiId'
              }, {
                boxLabel  : 'viaDATA',
                name      : 'logfiles',
                inputValue: '5',
                itemId    : 'viadataId'
              }, {
                boxLabel  : 'DBConnectionPool',
                name      : 'logfiles',
                inputValue: '6',
                itemId    : 'dbconnectionpoolId'
              }, {
                boxLabel  : 'Main EPIM',
                name      : 'logfiles',
                inputValue: '7',
                itemId    : 'mainepimId'
              }
              ]
            
          }, {
            xtype:'fieldset',
            itemId: 'searchareaFieldsetId',
            title: 'Search areas',
            collapsible: true,
            margin: '15 10 0 0',
            defaults:{ 
              xtype: 'button',
              pressed : false,
              enableToggle : true,
              scale: 'large',
              textAlign: 'center',
              margin: '0 10 10 0'
            },      
            items :[ {
                      text   : 'EPIM', 
                      itemId : 'epimId',
                      width  : 60,
                      pressed : true
                    }, {
                      xtype   : 'displayfield',
                      width   : panelMwWidth - 45,
                      margin  : '0 0 0 0'
//                      itemId : 'epimId'
                    }, {
                      text   : 'DAEMON', 
                      itemId : 'daemonId',
                      width  : 60,
                      toggleHandler : function(btn, pressed) {
                        var buttons = this.ownerCt;
                        if (pressed === true) {
                          buttons.getComponent('plannerId').toggle(true);
                          buttons.getComponent('xmlImportId').toggle(true);
                          buttons.getComponent('csvImportId').toggle(true);
                          buttons.getComponent('xmlExportDispId').toggle(true);
                          buttons.getComponent('xmlExportPrevId').toggle(true);
                          buttons.getComponent('xmlExportId').toggle(true);
                          buttons.getComponent('jdaemonId').toggle(true);
                          buttons.getComponent('webServiceId').toggle(true);
                        } else if (pressed === false) {
                          buttons.getComponent('plannerId').toggle(false);
                          buttons.getComponent('xmlImportId').toggle(false);
                          buttons.getComponent('csvImportId').toggle(false);
                          buttons.getComponent('xmlExportDispId').toggle(false);
                          buttons.getComponent('xmlExportPrevId').toggle(false);
                          buttons.getComponent('xmlExportId').toggle(false);
                          buttons.getComponent('jdaemonId').toggle(false);
                          buttons.getComponent('webServiceId').toggle(false);
                        }
                      }
                    }, {
                      xtype   : 'displayfield',
                      width   : panelMwWidth - 45,
                      margin  : '0 0 0 0'
                    }, {
                      text   : 'Planner', 
                      itemId : 'plannerId',
                      margin : '0 10 10 60'
                    }, {
                      text   : 'XMLImport', 
                      itemId : 'xmlImportId'
                    }, {
                      text   : 'CSVImport', 
                      itemId : 'csvImportId'
                    }, {
                      text   : 'XMLExportDispatcher', 
                      itemId : 'xmlExportDispId',
                      margin : '0 10 10 60'
                    }, {
                      text   : 'XMLExport', 
                      itemId : 'xmlExportId',
                      width  : 73
                    }, {
                      text   : 'XMLExportPreview', 
                      itemId : 'xmlExportPrevId',
                      margin : '0 10 10 60'
                    }, {
                      text   : 'JDAEMON', 
                      itemId : 'jdaemonId',
                      width  : 87
                    }, {
                      text   : 'WebService', 
                      itemId : 'webServiceId',
                      margin : '0 10 0 60'
                    }
//                    {
//                      xtype: 'displayfield',
//                      width: 50,
////                      disabled: true,
////                      visible: false
//                      margin: '0 0 0 0'
//                    }
            ]
          }]
        });
           

        
     // test store for viaLOG-Browser
        var storeX = Ext.create('Ext.data.TreeStore', {
          id: "storeXId",
          root : {
            expanded : true,
            children : [{
            text: "EPIM",
            expanded : true,
            children : [ 
                 {
                  text : "VIACONTENTPUBLISH_1.log",
                  leaf : true
                }, {
                  text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                  leaf : true
                }, {
                  text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                  leaf : true
                }, {
                  text : "VIADBCONNECTION_1.log",
                  leaf : true
                }, {
                  text : "VIATABLEAPI_1.log",
                  leaf : true
                }, {
                  text : "VIATABLEAPI_1.log.2012-02-14_13_52_53",
                  leaf : true
                }, {
                  text : "VIATASKS_1.log",
                  leaf : true
                } 
                ]
            }, {
              text: "DAEMON",
              expanded : true,
              children : [
                   {
                    text : "Planner",
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  }, {
                    text   : 'XMLImport', 
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  },  
                  {
                    text   : 'CSVImport',
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  },
                  {
                    text   : 'XMLExportDispatcher', 
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  },
                  {
                    text   : 'XMLExport', 
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  },
                  {
                    text   : 'XMLExportPreview', 
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  },
                  {
                    text   : 'JDAEMON', 
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  },
                  {
                    text   : 'WebService', 
                    expanded : false,
                    children : [{
                      text : "VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55",
                      leaf : true
                    }, {
                      text : "VIACONTENTPUBLISH_1.log.2012-01-27_12_29_17",
                      leaf : true
                    }]
                  }                   
                  ]
              }]
          }
        });
        


        // accordion panel in west panel
        var logBrowserWest = Ext.create('Ext.panel.Panel', {
            width: panelMwWidth,
            height: panelMwHeight,
            defaults: {
                bodyStyle: 'padding:0px',
            },
            layout: {
                type: 'accordion',
//                titleCollapse: false,
//                animate: true,
//                activeOnTop: true
            },
            items: [
                    
              { // viaLOG Query Accordion
                title: 'viaLOG Query',
                items: [accordionPanel],
                listeners: {
                  expand: function() {
                    Ext.getCmp('panel_mC').items.items[1].hide();
                    Ext.getCmp('panel_mC').items.items[0].show();
                  }
                }
              },  
              
              { // viaLOG Browser Accordion
                title: 'viaLOG Browser',
                
//                html : 'Tree mit "search areas" als Elternknoten <br> und "log files" als Kinderknoten',
                bodyStyle: 'padding: 0px',
                border: false,
                listeners: {
                  expand: function() {
                    if(Ext.getCmp('panel_mC').items.length > 1){
                      Ext.getCmp('panel_mC').items.items[1].show();
                      Ext.getCmp('panel_mC').items.items[0].hide();
                    }
                    else initViaQueryTabPanel();
                  }

                },
                items: [   
                  Ext.create('Ext.tree.Panel', {
       //           title: 'Simple Tree',
       //           width: 200,
                    height: 600,
       //           renderTo:
                    border: false,
                    store: storeX,
                    rootVisible: false,
                    listeners: {
//                      afterrender: function(){},
                      itemdblclick: function( that, record, item, index, e, eOpts ){
                        
                        var htmlResult1 = "<span style='background-color:#E5E3E3'>1&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>2&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>3&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>4&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>5&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>6&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>7&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>8&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>9&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>10&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:11 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>11&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:19 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>12&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:42:19 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>13&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>14&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>15&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>16&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>17&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>18&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>19&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>20&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>21&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>22&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>23&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>24&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>25&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>26&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>27&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>28&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>29&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>30&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>31&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>32&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>33&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>34&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>35&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>36&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>37&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>38&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>39&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>40&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>41&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>42&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>43&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>44&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>45&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>46&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>47&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>48&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>49&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>50&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>51&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>52&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>53&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>54&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>55&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>56&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>57&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>58&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:36 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>59&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:50:36 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>60&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>61&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>62&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>63&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>64&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>65&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>66&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>67&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>68&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>69&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>70&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>71&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>72&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>73&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>74&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>75&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>76&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>77&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>78&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>79&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>80&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>81&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>82&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>83&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>84&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>85&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>86&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>87&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>88&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>89&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>90&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>91&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>92&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>93&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>94&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>95&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>96&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>97&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 "+
                                          "[ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>98&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>99&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>100&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>101&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>102&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>103&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>104&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:10 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>105&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:19 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>106&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 16:57:19 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>107&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:12 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>108&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:12 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>109&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>110&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>111&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>112&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>113&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>114&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>115&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>116&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>117&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>118&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>119&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>120&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>121&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>122&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>123&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>124&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>125&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>126&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>127&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>128&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>129&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>130&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>131&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>132&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>133&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>134&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>135&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>136&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>137&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>138&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>139&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>140&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>141&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>142&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>143&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>144&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>145&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>146&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>147&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>148&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>149&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>150&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>151&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:13 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>152&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:21 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>153&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:00:21 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>154&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>155&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>156&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>157&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>158&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>159&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>160&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>161&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>162&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>163&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>164&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>165&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>166&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+
                                          " at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>167&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>168&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>169&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>170&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>171&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>172&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>173&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>174&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>175&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>176&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>177&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>178&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>179&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>180&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>181&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>182&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>183&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>184&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>185&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>186&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>187&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>188&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>189&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>190&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>191&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>192&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>193&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>194&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>195&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>196&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>197&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>198&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:27 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>199&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:36 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>200&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:05:36 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>201&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>202&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>203&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>204&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>205&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>206&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>207&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>208&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>209&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>210&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>211&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>212&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>213&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>214&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>215&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>216&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>217&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>218&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>219&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>220&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>221&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>222&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>223&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>224&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>225&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>226&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>227&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>228&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>229&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>230&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>231&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>232&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>233&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>234&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>235&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>236&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>237&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>238&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>239&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>240&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>241&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>242&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>243&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>244&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>245&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:02 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>246&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:11 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>247&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:08:11 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>248&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>249&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>250&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>251&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>252&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>253&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>254&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>255&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>256&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>257&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>258&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>259&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>260&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>261&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>262&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>263&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "+
                                          "at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>264&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>265&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>266&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>267&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>268&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>269&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>270&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>271&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>272&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>273&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>274&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>275&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>276&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>277&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>278&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>279&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>280&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>281&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>282&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>283&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>284&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>285&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>286&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>287&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>288&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>289&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>290&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>291&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>292&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>293&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:47 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() beforeLaunch <p><span style='background-color:#E5E3E3'>294&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:11:47 [ ALL ] - [JS LOG][_pty_ExtDefaultApp.jsp] [USERID: 2] extVia.app.router.startApp() launched <p><span style='background-color:#E5E3E3'>295&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:38 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>296&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:38 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>297&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>298&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>299&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>300&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>301&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>302&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>303&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>304&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>305&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>306&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>307&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>308&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>309&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>310&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>311&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>312&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>313&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>314&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>315&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>316&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>317&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>318&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>319&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>320&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>321&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>322&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>323&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>324&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>325&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>326&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>327&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>328&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>329&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>330&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>331&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>332&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_S <p><span style='background-color:#E5E3E3'>333&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_TEMPLATE_P <p><span style='background-color:#E5E3E3'>334&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_S <p><span style='background-color:#E5E3E3'>335&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGET_P <p><span style='background-color:#E5E3E3'>336&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_S <p><span style='background-color:#E5E3E3'>337&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_WIDGETTYPE_P <p><span style='background-color:#E5E3E3'>338&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_S <p><span style='background-color:#E5E3E3'>339&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobLOGBROWSER_P <p><span style='background-color:#E5E3E3'>340&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>341&nbsp;&nbsp;&nbsp;</span>28 Dez 2012 17:15:39 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>342&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>343&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>344&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>345&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>346&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>347&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>348&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p>"
                        
                        var tbarTxt = Ext.getCmp("viaLogQueryCenterTabTitleBarId").getComponent('logQueryText1').text;
                        var newTbarTxt = tbarTxt + ": ";
                        Ext.getCmp("viaLogQueryCenterTabTitleBarId").getComponent('logQueryText1').setText(newTbarTxt);
                        Ext.getCmp("viaLogQueryCenterTabTitleBarId").getComponent('logQueryText2').setText(record.data.text);
                        
                        
                        var title = record.data.text;
                        if (title.length > 10) {
                          title = title.substring(0, 10) + "...";
                        }
                        
                        Ext.getCmp('viaQueryTabPanelId').add({
                          title : title,
//                          rowIndex : rowNr,
                          autoScroll : true,
                          closable : true,
                          tabConfig : {
                            tooltip : record.data.text,
                            width : 100
                          },
                          html: htmlResult1,
                          bodyStyle: 'padding:10px'
                        });
                        
                      }
                    }
                 })
                ]
            }]
        });
        // ///////////////////////////////////////// WEST END //////////////////////////////////////////////
        
        // ///////////////////////////////////////// CENTER ///////////////////////////////////////////////
        
        var panelMc = Ext.getCmp('panel_mC');
        panelMc.removeAll(); //
        var panelMcWidth = panelMc.getWidth();
        var panelMcHeight = panelMc.getHeight()- 3; //- extVia.constants.raster.pgToolbarEditHeight + 40;

        var titleBar = Ext.create('Ext.toolbar.Toolbar', {
          frame : false,
          id : 'logBrowserCenterTabTitleBarId',
          height : 50,
          padding : '0 0 0 10',
          border : false,
          width : panelMcWidth,
          items : [ {
            xtype : 'tbtext',
            itemId : 'logBrowserText1',
            text : 'viaLOG Query ',
            style : {
              'font-weight' : 'bold',
              'font-size' : '22px',
              'font-family' : 'tahoma',
              'color' : '#415968'
            }
          }, {
            xtype : 'tbtext',
            itemId : 'logBrowserText2',
            text : '',
            hidden : false,
            style : {
              // 'font-weight': 'bold',
              'font-size' : '19px',
              'font-family' : 'tahoma',
              'color' : '#415968'
            }
          }

          , '->',

          {
            xtype : 'triggerfield',
            margin : '0 10 0 0',
            triggerCls : 'x-form-search-trigger',
       emptyText : 'Text search',
       disabled: true
          }

          ]
        });
        
        var dummyTab = {
            title : '...',
            itemId : '...Id',
            tabConfig : {
              tooltip : '...',
              width : 85
            }
          };

        var logBrowserTabPanel = Ext.create('Ext.tab.Panel', {
          id: 'logBrowserTabPanelId',
          border : 0,
          width : panelMcWidth - 2,
          height : (panelMcHeight * 0.7) - 50,
          tabBar : {
          // height: 25
          },
          items : [ ]
        });

        // logBrowserTabPanel.setActiveTab(0);

        var logBrowserCenterTab = Ext.create('Ext.panel.Panel', {
          width : panelMcWidth,
          border : false,
          frame : false,
          tbar : titleBar,
          items : logBrowserTabPanel
        });
        
        var titleBarGrid = Ext.create('Ext.toolbar.Toolbar', {
//          frame : false,
          height : 50,
          padding : '0 0 0 10',
          width : panelMcWidth - 2,
          items : [ {
            xtype : 'tbtext',
            itemId : 'Text1',
            text : 'Trefferliste',
            style : {
              'font-weight' : 'bold',
              'font-size' : '22px',
              'font-family' : 'tahoma',
              'color' : '#415968'
            }
          }

          , '->',

          {
            xtype : 'button',
            margin : '0 10 0 0',
            iconCls : 'list',
            scale : 'large'
          }, {
            xtype : 'button',
            margin : '0 10 0 0',
            iconCls : 'tree',
            scale : 'large'
          }]
        });
        
        
        // LogBrowser Model
        Ext.define('LogBrowser', {
          extend: 'Ext.data.Model',
          fields: [
              'filename', 'searcharea', 'beforeHit', 'hit', 'rowNumber',
              {name: 'date', type: 'date', dateFormat: 'd M Y'}, 'filePath'
          ]
//          ,idProperty: 'threadid'
        });
  
        var dummyData = [
          {
             filename: 'VIACONTENTPUBLISH_1.log.2012-07-17_13_52_55',
             searcharea: 'CSV', 
             matches: 'LOREM', 
             cellnr: '1240', 
             date: '01.01.2012'
           }, {
             filename: 'VIADBCONNECTION_1.log',
             searcharea: 'CSV', 
             matches: 'LOREM', 
             cellnr: '150', 
             date: '21.03.2012'
            }, {
             filename: 'VIATABLEAPI_1.log.2012-02-14_13_52_53',
             searcharea: 'CSV', 
             matches: 'LOREM', 
             cellnr: '57240', 
             date: '15.10.2012'
           }
            
        ];
        
    
        
        var dummyStore_ = Ext.create('Ext.data.Store', {
          id: "dummyStoreId",
          pageSize: 10,
          model: 'LogBrowser',
          data : []
        });
        
        var dummyStore = Ext.create('Ext.data.Store', {
          id: 'LogBrowserStoreId',
          model: 'LogBrowser',
          remoteSort: true,
          pageSize: 10,
          proxy: {
              type: 'pagingmemory',
              data: []
          }
        });
        
        
        var findTab = function(tabs, rowIdx){
          var res = {
             isLoaded : false,
             tabNr : 0
          };     
          
          for(var i = 0; i < tabs.length; i++){
            if(tabs.items[i].rowIndex === rowIdx){
              res.isLoaded = true;
              res.tabNr = i;
              break;
            }
          }
          
          return res;
        };

        
        var html = '<span style="color:red;font-weight:bold">Lorem </span><span style="">ipsum dolor sit amet, consectetuer adipiscing elit. Sed metus nibh, sodales a, porta at, vulputate eget, dui. Pellentesque ut nisl. Maecenas tortor turpis, interdum non, sodales non, iaculis ac, lacus. Vestibulum auctor, tortor quis iaculis malesuada, libero lectus bibendum purus, sit amet tincidunt quam turpis vel lacus. In pellentesque nisl non sem. Suspendisse nunc sem, pretium eget, cursus a, fringilla vel, urna.<br /><br />Aliquam commodo ullamcorper erat. Nullam vel justo in neque porttitor laoreet. Aenean lacus dui, consequat eu, adipiscing eget, nonummy non, nisi. Morbi nunc est, dignissim non, ornare sed, luctus eu, massa. Vivamus eget quam. Vivamus tincidunt diam nec urna. Curabitur velit.</span>';
        
        var htmlResult1 = "<span style='background-color:#E5E3E3'>34964&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>34965&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>34966&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>34967&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>34968&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>34969&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>34970&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>34971&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>34972&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>34973&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>34974&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>34975&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>34976&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>34977&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>34978&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>34979&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>34980&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>34981&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:29 [ ALL ] - load mappings <p><span style='background-color:#E5E3E3'>34982&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:29 [ ALL ] - Auth.countUsers: select distinct usrs.id  from users usrs, usergroups usgr, roles_usergroups ro_gr, role_userrights ro_ri, userrights usri  where lower(usrs.shortcut) != 'system' and lower(usrs.shortcut) != 'demo' and usrs.clie_id = 1 and (usri.shortcut = 'vCONT' or usri.shortcut = 'vPROD')  and usrs.deleted = 0 and usgr.id = usrs.usgr_id and usgr.deleted = 0 and ro_gr.usgr_id = usgr.id  and ro_ri.role_id=ro_gr.role_id and ro_ri.usri_id = usri.id and usri.deleted = 0 and usri.clie_id = 1 <p><span style='background-color:#E5E3E3'>34983&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:29 [ ALL ] - Auth.countUsers: select distinct usrs.id from users usrs, usergroups usgr, usergroup_userrights grri,  userrights usri  where usrs.usgr_id = usgr.id  and usgr.deleted=0  and grri.usgr_id=usgr.id  and grri.usri_id= usri.id  and lower(usrs.shortcut) != 'system'  and lower(usrs.shortcut) != 'demo'  and usrs.clie_id = 1 and (usri.shortcut = 'vCONT' or usri.shortcut = 'vPROD')  and usri.clie_id = 1 and usrs.deleted = 0 <p><span style='background-color:#E5E3E3'>34984&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:29 [ ALL ] - Auth.countUsers: select distinct usrs.id  from users usrs, usergroups usgr, roles_usergroups ro_gr, role_userrights ro_ri, userrights usri  where lower(usrs.shortcut) != 'system' and lower(usrs.shortcut) != 'demo' and usrs.clie_id = 1 and usri.shortcut = 'vPUB'  and usrs.deleted = 0 and usgr.id = usrs.usgr_id and usgr.deleted = 0 and ro_gr.usgr_id = usgr.id  and ro_ri.role_id=ro_gr.role_id and ro_ri.usri_id = usri.id and usri.deleted = 0 and usri.clie_id = 1 <p><span style='background-color:#E5E3E3'>34985&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:29 [ ALL ] - Auth.countUsers: select distinct usrs.id from users usrs, usergroups usgr, usergroup_userrights grri,  userrights usri  where usrs.usgr_id = usgr.id  and usgr.deleted=0  and grri.usgr_id=usgr.id  and grri.usri_id= usri.id  and lower(usrs.shortcut) != 'system'  and lower(usrs.shortcut) != 'demo'  and usrs.clie_id = 1 and usri.shortcut = 'vPUB'  and usri.clie_id = 1 and usrs.deleted = 0 <p><span style='background-color:#E5E3E3'>34986&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:29 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key LoginErrorCheckLicensedUsrsWarning <p><span style='background-color:#E5E3E3'>34987&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:31 [ ALL ] - null <p><span style='background-color:#E5E3E3'>34988&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:31 [ ALL ] - ajsp/LoginAction.jsp <p><span style='background-color:#E5E3E3'>34989&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:31 [ ALL ] - null <p><span style='background-color:#E5E3E3'>34990&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:31 [ ALL ] - ajsp/Forward.jsp <p><span style='background-color:#E5E3E3'>34991&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - java.lang.Exception: >>>>>>>> GlobalVariables.doUpdateSync called for GlobalVariables_UsersClientId <<<<<<<<<<<<p><span style='background-color:#E5E3E3'>34992&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.utilities.GlobalVariables.doUpdateSync(GlobalVariables.java:3909)<p><span style='background-color:#E5E3E3'>34993&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.utilities.GlobalVariables.setUsersClientId(GlobalVariables.java:1544)<p><span style='background-color:#E5E3E3'>34994&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.utilities.DBTableCols.getUsersClientIdWithSet(DBTableCols.java:3347)<p><span style='background-color:#E5E3E3'>34995&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.utilities.DBTableCols.getUsersClientIdWithSet(DBTableCols.java:3303)<p><span style='background-color:#E5E3E3'>34996&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.ajsp.LoginAction_jsp._jspService(LoginAction_jsp.java:163)<p><span style='background-color:#E5E3E3'>34997&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>34998&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>34999&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>35000&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>35001&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>35002&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>35003&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>35004&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>35005&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationDispatcher.invoke(ApplicationDispatcher.java:691)<p><span style='background-color:#E5E3E3'>35006&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationDispatcher.processRequest(ApplicationDispatcher.java:469)<p><span style='background-color:#E5E3E3'>35007&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationDispatcher.doForward(ApplicationDispatcher.java:403)<p><span style='background-color:#E5E3E3'>35008&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationDispatcher.forward(ApplicationDispatcher.java:301)<p><span style='background-color:#E5E3E3'>35009&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.PageContextImpl.doForward(PageContextImpl.java:691)<p><span style='background-color:#E5E3E3'>35010&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.runtime.PageContextImpl.forward(PageContextImpl.java:661)<p><span style='background-color:#E5E3E3'>35011&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jsp.ajsp.Forward_jsp._jspService(Forward_jsp.java:85)<p><span style='background-color:#E5E3E3'>35012&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>35013&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>35014&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>35015&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>35016&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>35017&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>35018&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>35019&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>35020&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>35021&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>35022&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>35023&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>35024&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>35025&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>35026&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>35027&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>35028&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>35029&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>35030&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>35031&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>35032&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>35033&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>35034&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>35035&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>35036&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - Auth.countUsers: select distinct usrs.id  from users usrs, usergroups usgr, roles_usergroups ro_gr, role_userrights ro_ri, userrights usri  where lower(usrs.shortcut) != 'system' and lower(usrs.shortcut) != 'demo' and usrs.clie_id = 1 and (usri.shortcut = 'vCONT' or usri.shortcut = 'vPROD')  and usrs.deleted = 0 and usgr.id = usrs.usgr_id and usgr.deleted = 0 and ro_gr.usgr_id = usgr.id  and ro_ri.role_id=ro_gr.role_id and ro_ri.usri_id = usri.id and usri.deleted = 0 and usri.clie_id = 1 <p><span style='background-color:#E5E3E3'>35037&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - Auth.countUsers: select distinct usrs.id from users usrs, usergroups usgr, usergroup_userrights grri,  userrights usri  where usrs.usgr_id = usgr.id  and usgr.deleted=0  and grri.usgr_id=usgr.id  and grri.usri_id= usri.id  and lower(usrs.shortcut) != 'system'  and lower(usrs.shortcut) != 'demo'  and usrs.clie_id = 1 and (usri.shortcut = 'vCONT' or usri.shortcut = 'vPROD')  and usri.clie_id = 1 and usrs.deleted = 0 <p><span style='background-color:#E5E3E3'>35038&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - Auth.countUsers: select distinct usrs.id  from users usrs, usergroups usgr, roles_usergroups ro_gr, role_userrights ro_ri, userrights usri  where lower(usrs.shortcut) != 'system' and lower(usrs.shortcut) != 'demo' and usrs.clie_id = 1 and usri.shortcut = 'vPUB'  and usrs.deleted = 0 and usgr.id = usrs.usgr_id and usgr.deleted = 0 and ro_gr.usgr_id = usgr.id  and ro_ri.role_id=ro_gr.role_id and ro_ri.usri_id = usri.id and usri.deleted = 0 and usri.clie_id = 1 <p><span style='background-color:#E5E3E3'>35039&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - Auth.countUsers: select distinct usrs.id from users usrs, usergroups usgr, usergroup_userrights grri,  userrights usri  where usrs.usgr_id = usgr.id  and usgr.deleted=0  and grri.usgr_id=usgr.id  and grri.usri_id= usri.id  and lower(usrs.shortcut) != 'system'  and lower(usrs.shortcut) != 'demo'  and usrs.clie_id = 1 and usri.shortcut = 'vPUB'  and usri.clie_id = 1 and usrs.deleted = 0 <p><span style='background-color:#E5E3E3'>35040&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - null <p><span style='background-color:#E5E3E3'>35041&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - jsp/Menu0.jsp <p><span style='background-color:#E5E3E3'>35042&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key OnlinehelpTooltip <p><span style='background-color:#E5E3E3'>35043&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - null <p><span style='background-color:#E5E3E3'>35044&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:32 [ ALL ] - jsp/MenuMain.jsp <p><span style='background-color:#E5E3E3'>35045&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:33 [ ALL ] - null <p><span style='background-color:#E5E3E3'>35046&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:33 [ ALL ] - null <p><span style='background-color:#E5E3E3'>35047&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:33 [ ALL ] - jsp/MenuTopLeiste.jsp <p><span style='background-color:#E5E3E3'>35048&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:33 [ ALL ] - jsp/MenuButtonLeiste.jsp <p><span style='background-color:#E5E3E3'>35049&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:33 [ ALL ] - null <p><span style='background-color:#E5E3E3'>35050&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:33 [ ALL ] - jsp/MenuEmpty.jsp <p><span style='background-color:#E5E3E3'>35051&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:34 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key System.Requirements.Java.Client.Version.Required <p><span style='background-color:#E5E3E3'>35052&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:35 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35053&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:35 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35054&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:35 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35055&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:35 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35056&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:35 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35057&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:35 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35058&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35059&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35060&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35061&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35062&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35063&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB_SCHURTER.properties while searching for key BM_3 <p><span style='background-color:#E5E3E3'>35064&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale.getStringLocale(): <span style='background-color:red'>MissingResourceException</span> -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_3 <p><span style='background-color:#E5E3E3'>35065&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35066&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35067&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35068&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35069&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35070&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:36 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35071&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35072&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35073&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35074&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35075&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35076&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB_SCHURTER.properties while searching for key BM_5 <p><span style='background-color:#E5E3E3'>35077&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_5 <p><span style='background-color:#E5E3E3'>35078&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35079&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35080&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:37 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35081&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35082&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35083&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35084&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35085&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35086&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35087&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35088&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35089&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB_SCHURTER.properties while searching for key BM_4 <p><span style='background-color:#E5E3E3'>35090&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_4 <p><span style='background-color:#E5E3E3'>35091&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StackTrace: <p><span style='background-color:#E5E3E3'>35092&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35093&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - java.lang.ClassNotFoundException: com.viaMEDICI.custom.jjbridge.QueryProductsHandler<p><span style='background-color:#E5E3E3'>35094&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1359)<p><span style='background-color:#E5E3E3'>35095&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1205)<p><span style='background-color:#E5E3E3'>35096&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.ClassLoader.loadClassInternal(ClassLoader.java:319)<p><span style='background-color:#E5E3E3'>35097&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName0(Native Method)<p><span style='background-color:#E5E3E3'>35098&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at java.lang.Class.forName(Class.java:164)<p><span style='background-color:#E5E3E3'>35099&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:102)<p><span style='background-color:#E5E3E3'>35100&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:64)<p><span style='background-color:#E5E3E3'>35101&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at com.viaMEDICI.jjbridge.Tools.registerJJBridge(Tools.java:46)<p><span style='background-color:#E5E3E3'>35102&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jsp.jsp._005fpty_005fExtDefaultApp_jsp._jspService(_005fpty_005fExtDefaultApp_jsp.java:249)<p><span style='background-color:#E5E3E3'>35103&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:98)<p><span style='background-color:#E5E3E3'>35104&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>35105&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:328)<p><span style='background-color:#E5E3E3'>35106&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:315)<p><span style='background-color:#E5E3E3'>35107&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.jasper.servlet.JspServlet.service(JspServlet.java:265)<p><span style='background-color:#E5E3E3'>35108&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at javax.servlet.http.HttpServlet.service(HttpServlet.java:803)<p><span style='background-color:#E5E3E3'>35109&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:269)<p><span style='background-color:#E5E3E3'>35110&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>35111&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at php.java.servlet.PhpCGIFilter.doFilter(PhpCGIFilter.java:126)<p><span style='background-color:#E5E3E3'>35112&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:215)<p><span style='background-color:#E5E3E3'>35113&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:188)<p><span style='background-color:#E5E3E3'>35114&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:210)<p><span style='background-color:#E5E3E3'>35115&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:174)<p><span style='background-color:#E5E3E3'>35116&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:127)<p><span style='background-color:#E5E3E3'>35117&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:117)<p><span style='background-color:#E5E3E3'>35118&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:108)<p><span style='background-color:#E5E3E3'>35119&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:151)<p><span style='background-color:#E5E3E3'>35120&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.coyote.http11.Http11Processor.process(Http11Processor.java:870)<p><span style='background-color:#E5E3E3'>35121&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.coyote.http11.Http11BaseProtocol$Http11ConnectionHandler.processConnection(Http11BaseProtocol.java:665)<p><span style='background-color:#E5E3E3'>35122&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.PoolTcpEndpoint.processSocket(PoolTcpEndpoint.java:528)<p><span style='background-color:#E5E3E3'>35123&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at org.apache.tomcat.util.net.LeaderFollowerWorkerThread.runIt(LeaderFollowerWorkerThread.java:81)<p><span style='background-color:#E5E3E3'>35124&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  at org.apache.tomcat.util.threads.ThreadPool$ControlRunnable.run(ThreadPool.java:685)<p><span style='background-color:#E5E3E3'>35125&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; at java.lang.Thread.run(Thread.java:595)<p><span style='background-color:#E5E3E3'>35126&nbsp;&nbsp;&nbsp;</span> <p><span style='background-color:#E5E3E3'>35127&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:38 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35128&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35129&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35130&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35131&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35132&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35133&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35134&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35135&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:39 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35136&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35137&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB_SCHURTER.properties while searching for key BM_6 <p><span style='background-color:#E5E3E3'>35138&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key BM_6 <p><span style='background-color:#E5E3E3'>35139&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - OnlineHelpTools.getMenuTopHelpLink: sLanguageISO: de,  sCountryISO: DE <p><span style='background-color:#E5E3E3'>35140&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35141&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35142&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:40 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35143&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35144&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35145&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35146&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35147&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35148&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35149&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35150&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35151&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB_SCHURTER.properties while searching for key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35152&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale.getStringLocale(): MissingResourceException -->Can't find resource for bundle com.viaMEDICI.utilities.StringLocale$UpdatableResourceBundle, key EpobDASHBOARD_S <p><span style='background-color:#E5E3E3'>35153&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35154&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:41 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35155&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35156&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35157&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35158&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35159&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35160&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_de_DE_SCHURTER.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35161&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35162&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35163&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB.properties while searching for key EpobDASHBOARD_P <p><span style='background-color:#E5E3E3'>35164&nbsp;&nbsp;&nbsp;</span>31 Jan 2013 14:04:42 [ ALL ] - StringLocale: Normal reload of resource bundle for Locale /resources/viaResources_en_GB_SCHURTER.properties while searching for key EpobDASHBOARD_P <p>";
        
        
//        Ext.get("testDiv").highlight();
        var logBrowserGrid = Ext.create('Ext.grid.Panel', {
          id: 'logBrowserGridId',
          border: false,
          loadMask : false,
          width : panelMcWidth - 2,
          height : (panelMcHeight * 0.3) - 49,
          store: dummyStore,
          stripeRows: true,
          listeners : {
            celldblclick: function( view, td, cellIndex, record, tr, rowIndex, e, eOpts ){

              // add filename to the logBrowserCenterTab
              var tbarTxt = Ext.getCmp("logBrowserCenterTabTitleBarId").getComponent('logBrowserText1').text;
              var newTbarTxt = tbarTxt + ": ";
              Ext.getCmp("logBrowserCenterTabTitleBarId").getComponent('logBrowserText1').setText(newTbarTxt);
              Ext.getCmp("logBrowserCenterTabTitleBarId").getComponent('logBrowserText2').setText(record.data.filename);
              
              
              var title = record.data.filename;
              if (title.length > 10) {
                title = title.substring(0, 10) + "...";
              }
              
              var rowNr = record.get("rowNumber");
              var tab = findTab(logBrowserTabPanel.items, rowNr);
              
              if(!tab.isLoaded){
                logBrowserTabPanel.add({
                  title : title,
                  rowIndex : rowNr,
                  autoScroll : true,
                  closable : true,
                  tabConfig : {
                    tooltip : record.data.filename,
                    width : 100
                  },
                  html: htmlResult1,
                  bodyStyle: 'padding:10px'
                });
                
                logBrowserTabPanel.setActiveTab(logBrowserTabPanel.items.length - 1);
              }
              else if(tab.isLoaded){
                logBrowserTabPanel.setActiveTab(tab.tabNr);
              }
              
              // hier zuerst die Position der markierten Zeile ermitteln
              logBrowserTabPanel.getActiveTab().body.scrollTo('top', 1400); 

            }
          },
          columns:[{
              text: "Filename",
              dataIndex: 'filename',
              width : 290,
//              renderer: '',
              sortable: false
          },{
              text: "Search area",
              dataIndex: 'searcharea',
              width: 120,
              titleAlign : 'center',
//              align: 'center',
              sortable: true
          },{
              text: "Treffer",
              dataIndex: 'hit',
              width: 265,
              align: 'center',
              sortable: true,
              renderer: function( value, metaData, record, rowIndex, colIndex, store, view ) {
                var result = "";
                var regExp = new RegExp(txt2Search.toLowerCase(), 'g');
                
                var splittedValue = value.split(' ');
                for(var i = 0; i < splittedValue.length; i++){
                  if(splittedValue[i].toLowerCase().match(regExp)){
                    result = splittedValue[i];
                    if(result.charAt(result.length-1).match(/:/)){
                      result = result.substring(0, result.length-1);
                    }
                  }
                }

                return result;
              }
          },{
              text: "Zeile",
              dataIndex: 'rowNumber',
              width: 50,
              align: 'center',
              sortable: true
          },{
              text: "Datum",
              dataIndex: 'date',
              width: 100,
              align: 'center',
              sortable: false,
              renderer: Ext.util.Format.dateRenderer('d-m-Y')

          }],
          // paging bar
          bbar: Ext.create('Ext.PagingToolbar', {
              id: 'pagingToolbarId', 
              pageSize: 10,
              store: dummyStore,
              displayInfo: true,
              displayMsg: 'Treffer {0} - {1} of {2}',
              emptyMsg: "Keine Treffer",
              listeners: {
                afterrender: function() {
//                    this.down('#refresh').hide();
                }
            }
          })
        });

        
        var logBrowserCenterGrid = Ext.create('Ext.panel.Panel', {
          tbar : titleBarGrid,
          items : logBrowserGrid
        });
        
        var logBrowserCenter = Ext.create('Ext.panel.Panel', {
          border : false,
//          frame : false,
          width : panelMcWidth - 2,
          height : panelMcHeight + 20,
          items : [logBrowserCenterTab, logBrowserCenterGrid]
        });
        
        var collapsed = false;
        
        // click listener for splitter between west and center
        var panelMWSplitter = Ext.getCmp('panel_mw-splitter');
        
        if (panelMWSplitter)
        	panelMWSplitter.addListener({
          click: {
            element: 'el',
            fn: function(){ 
//                  var splitterPos = Ext.getCmp('panel_mw-splitter').getPosition(); // [x,y]
                  var newWidth = panelMc.getWidth();
                  
                  if(collapsed){ //-> westpanel is collapsed
                    if(!Ext.getCmp('panel_mC').items.items[0].isHidden()){
                      Ext.getCmp("logBrowserTabPanelId").setWidth(newWidth - 340);
                      Ext.getCmp("logBrowserTabPanelId").ownerCt.setWidth(newWidth - 340);
                      Ext.getCmp("logBrowserTabPanelId").ownerCt.ownerCt.setWidth(newWidth - 340);
                      
                      Ext.getCmp("logBrowserGridId").setWidth(newWidth - 340);
                      Ext.getCmp("logBrowserGridId").ownerCt.setWidth(newWidth - 340);
                    }
                    else if(Ext.getCmp('panel_mC').items.items[0].isHidden()){
                      Ext.getCmp("viaQueryTabPanelId").setWidth(newWidth - 340);
                      Ext.getCmp("viaQueryTabPanelId").ownerCt.setWidth(newWidth - 340);
//                      Ext.getCmp("viaQueryTabPanelId").ownerCt.ownerCt.setWidth(newWidth - 340);
                    }
                    collapsed = false;
                  }
                  
                  else if(!collapsed){ //-> westpanel is expanded
                    if(!Ext.getCmp('panel_mC').items.items[0].isHidden()){
                      Ext.getCmp("logBrowserTabPanelId").setWidth(newWidth);
                      Ext.getCmp("logBrowserTabPanelId").ownerCt.setWidth(newWidth);
                      Ext.getCmp("logBrowserTabPanelId").ownerCt.ownerCt.setWidth(newWidth);
                      
                      Ext.getCmp("logBrowserGridId").setWidth(newWidth);
                      Ext.getCmp("logBrowserGridId").ownerCt.setWidth(newWidth);
                    }
                    else if(Ext.getCmp('panel_mC').items.items[0].isHidden()){
                      Ext.getCmp("viaQueryTabPanelId").setWidth(newWidth);
                      Ext.getCmp("viaQueryTabPanelId").ownerCt.setWidth(newWidth);
//                      Ext.getCmp("viaQueryTabPanelId").ownerCt.ownerCt.setWidth(newWidth);
                    }
                    collapsed = true;
                  }
            }
          }
        });

        
        //////////////////////////////////////// viaLOG Query  END/////////////////////////////////////////
        
        //////////////////////////////////////// viaLOG Browser //////////////////////////////////////////////
        
        // Tree mit Knoten ...
        
        var initViaQueryTabPanel = function(){
          
          var panMc = Ext.getCmp('panel_mC');
          panMc.items.items[0].hide();
//          panMc.removeAll();
          
          var panelMcWidth = panMc.getWidth();
          var panelMcHeight = panMc.getHeight()- 3; 
          
          var titleBar = Ext.create('Ext.toolbar.Toolbar', {
            frame : false,
            id : 'viaLogQueryCenterTabTitleBarId',
            height : 50,
            padding : '0 0 0 10',
            border : false,
            width : panelMcWidth,
            items : [ {
              xtype : 'tbtext',
              itemId : 'logQueryText1',
              text : 'viaLOG Browser',
              style : {
                'font-weight' : 'bold',
                'font-size' : '22px',
                'font-family' : 'tahoma',
                'color' : '#415968'
              }
            }, {
              xtype : 'tbtext',
              itemId : 'logQueryText2',
              text : '',
              hidden : false,
              style : {
                // 'font-weight': 'bold',
                'font-size' : '19px',
                'font-family' : 'tahoma',
                'color' : '#415968'
              }
            }

            , '->',

            {
              xtype : 'triggerfield',
              margin : '0 10 0 0',
              triggerCls : 'x-form-search-trigger',
              emptyText : 'Text search',
              disabled: true
            }

            ]
          });
          
          var dummyTab = {
              title : '...',
              itemId : '...Id',
              tabConfig : {
                tooltip : '...',
                width : 85
              }
            };

          var logQueryTabPanel = Ext.create('Ext.tab.Panel', {
            id: 'viaQueryTabPanelId',
            border : 0,
            width : panelMcWidth,
            height : panelMcHeight,
            tabBar : {
            // height: 25
            },
            items : [ ]
          });

          // logQueryTabPanel.setActiveTab(0);

          var logQueryCenterTab = Ext.create('Ext.panel.Panel', {
            width : panelMcWidth,
            height : panelMcHeight,
            border : false,
            frame : false,
            tbar : titleBar,
            items : logQueryTabPanel
          });
          
          panMc.add(logQueryCenterTab);
          
        };
        
        
        ////////////////////////////////////////viaLOG Browser END//////////////////////////////////////////////
        
           
        
     // ///////////////////////////////////////// CENTER END ///////////////////////////////////////////////

        extVia.regApp.myRaster.addToCenter(logBrowserCenter);
        extVia.regApp.myRaster.addToWest(logBrowserWest);
      }

    });

//var logFilefieldSet = fields2.getComponent('checkboxfieldsetId');
//var viaContPub = logFilefieldSet.getComponent('viacontentpublishId').getValue();
//var viaDbCon = logFilefieldSet.getComponent('viadbconnectionId').getValue();
//var viaTasks = logFilefieldSet.getComponent('viatasksId').getValue();
//var viaTableApi = logFilefieldSet.getComponent('viatableapiId').getValue();
//var viaData = logFilefieldSet.getComponent('viadataId').getValue();
//var viaDbConPool = logFilefieldSet.getComponent('dbconnectionpoolId').getValue();
//var viaMainEpim = logFilefieldSet.getComponent('mainepimId').getValue();
//
//// search areas
//var searchAreafieldSet = fields2.getComponent('searchareaFieldsetId');
//var plannerBtn = searchAreafieldSet.getComponent('plannerId').getValue();
//var xmlBtn = searchAreafieldSet.getComponent('xmlId').getValue();
//var csvBtn = searchAreafieldSet.getComponent('csvId').getValue();
//var daemonBtn = searchAreafieldSet.getComponent('daemonId').getValue();
//var xmlExportBtn = searchAreafieldSet.getComponent('xmlExportId').getValue();
//var xmlExportPrevBtn = searchAreafieldSet.getComponent('xmlExportPrevId').getValue();
//var epimBtn = searchAreafieldSet.getComponent('epimId').getValue();

/*
 * 
 * $Revision: 1.7 $ $Modtime: 17.12.12 12:39 $ $Date: 2013/06/03 12:32:48 $ $Author: slederer $ $viaMEDICI Release: 3.9 $
 * 
 */