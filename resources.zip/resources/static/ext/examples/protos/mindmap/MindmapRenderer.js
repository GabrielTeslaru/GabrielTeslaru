Ext.define('extVia.renderer.Mindmap', {

	/**
	 * @private
	 * @cfg {Object} particleSystem The particle system will be given fom the arbor.js framework.
	 */
	particleSystem : null,

	/**
	 * @private
	 * @cfg {HTMLElement} canvas The canvas element where the mindmap should be rendered in.
	 */
	canvas : null,

	/**
	 * @private
	 * @cfg {Object} context The 2d context of the canvas.
	 */
	context : null,

	/**
	 * @cfg {Number} screenPadding Extra whitespace per side.
	 */
	screenPadding : 80,

	/**
	 * @private
	 * @param {Object} config User config for initializaion.
	 */
	constructor : function(config) {
		try {
			this.canvas = Ext.get(config.viewId).dom;
			this.context = this.canvas.getContext("2d");
			this.screenPadding = (config.screenPadding || 80);
		} catch (ex) {
			console.error('[ERROR] The viewId is invalid or not given in the config.');
		}
	},

	/**
	 * @private
	 * @param {Object} particleSystem The particle System from arbor.js
	 * 
	 * Used by arbor.js to initialize the renderer with a particle system.
	 */
	init : function(particleSystem) {
		this.particleSystem = particleSystem;
		this.particleSystem.screenSize(this.canvas.width, this.canvas.height);
		this.particleSystem.screenPadding(this.screenPadding);
		this.initMouseHandling();
	},

	/**
	 * @private
	 */
	redraw : function() {
		var me = this;
		if (!this.particleSystem) {
			return;
		}

		me.context.save();
		me.context.fillStyle = "white";
		me.context.fillRect(0, 0, me.canvas.width, me.canvas.height);
		me.context.restore();

		me.particleSystem.eachEdge(function(edge, pt1, pt2) {
			me.context.strokeStyle = "rgba(0,0,0, 0.333)";
			me.context.lineWidth = 1
			me.context.beginPath();
			me.context.moveTo(pt1.x, pt1.y);
			me.context.lineTo(pt2.x, pt2.y);
			me.context.stroke();
		});

		me.particleSystem.eachNode(function(node, pt) {
			me.context.fillStyle = "black";
			me.context.fillRect(pt.x - 10 / 2, pt.y - 10 / 2, 10, 10);
		});

	},

	/**
	 * @private
	 */
	initMouseHandling : function() {

	}
});