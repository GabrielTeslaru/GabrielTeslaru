Ext.namespace('extVia.locales' ,'extVia.mindmap.locales');
/**
 * @class extVia.resourcesProto.locales
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2014/09/18 14:50:48 $
 *            $Revision: 1.1 $
 */

extVia.mindmap.locales = {
        appName:'mindmapProto'
};

Ext.apply(extVia.locales, extVia.mindmap.locales);



/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2014/09/18 14:50:48 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 