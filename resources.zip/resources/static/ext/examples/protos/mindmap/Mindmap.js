Ext.define('extVia.component.Mindmap', {
	extend : 'Ext.panel.Panel',
	layout: 'absolute',

	canvasId : null,
	
	canvas : null,

	context : null,

	constructor : function(cfg) {
		var id = Ext.id();
		this.html = '<canvas id="'+id+'">Your Browser doesn\'t support the canvas Element</canvas>';
		this.canvasId = id;
		
		this.callParent(arguments);
	},
	
	lineTo : function(p1, p2) {
		var me = this;
		me.context.beginPath();
		me.context.lineWidth = "1";
		me.context.fillStyle = "#ccc";
		me.context.moveTo(p1.x, p1.y);
		me.context.lineTo(p2.x, p2.y);
		me.context.stroke();
	},
	
	bezierCurveTo: function(p1, cp1, cp2, p2) {
		var me = this;
		me.context.beginPath();
		me.context.fillStyle = "#00FFFF";
		me.context.moveTo(p1.x, p1.y);
		me.context.bezierCurveTo(cp1.x,cp1.y,cp2.x,cp2.y,p2.x,p2.y);
		me.context.stroke();
	},
	

	addPointInterface : function(node, x, y) {
		node.p = {
			x : x,
			y : y
		};
		node.mmExpanded = true;
		node.isMMExpanded = function() {
			return this.mmExpanded;
		};
		node.mmExpand = function() {
			this.mmExpanded = true;
		};
		node.mmCollapse = function() {
			this.mmExpanded = false;
		};
		node.setXY = function(p) {
			this.p = p;
		};
		node.setX = function(x) {
			this.p.x = x;
		};
		node.setY = function(y) {
			this.p.y = y;
		};
		node.getXY = function() {
			return this.p;
		};
		node.getX = function() {
			return this.p.x;
		};
		node.getY = function() {
			return this.p.y;
		};
	},
	
	initRootNode : function(root) {
		var me = this,
		    x, y;
		
		x = (me.getWidth() / 2);
		y = (me.getHeight() / 2);
		me.addPointInterface(root, x, y);
		root.data.leftHeight = 0;
		root.data.rightHeight = 0;
	},
	
	drawRootNode : function(root) {
		var rootHeight = 0,
			me = this;
		
		if(root.data.leftHeight > root.data.rightHeight) {
			height = root.data.leftHeight / 2;
		} else {
			height = root.data.rightHeight / 2;
		}
		
		root.setY(height);
		me.drawNode(root);
	},
	
	copyNode: function(node) {
		var me = this,
			copy = node.copy(),
			i = 0;
		
		for(i; i < node.childNodes.length; i++) {
			if(!copy.childNodes) {
				copy.childNodes = [];
			}
			copy.appendChild(me.copyNode(node.childNodes[i]));
		}
		
		return copy;
	},
	
	setRoot : function(root) {
		var me = this;
		var copy = me.copyNode(root);
		
		
		if(!me.store) {
			me.store = new Ext.data.TreeStore({
				root: copy
			});
		} else {
			me.store.setRootNode(copy);
		}
		
		me.initialized = false;
	},
	
	initialized : false,
	
	draw : function() {
		var me = this,
		    root = this.store.getRootNode(),
		    i = 0,
		    child;
		
		me.context.clearRect(0,0,me.getWidth(),me.getHeight());
		me.removeAll();
		
		if(!me.initialized) {
			me.initialize();
		}
		
		me.canvas.height = root.data.leftHeight > root.data.rightHeight ? root.data.leftHeight : root.data.rightHeight;
		me.canvas.width = ((me.leftDepth + me.rightDepth) * (me.nodeDistance * 2)) + me.nodeDistance;
		me.drawRootNode(root);
		root.eachChild(function(child) {
			me.printChilds(child);
		});
		

	},
	
	lineBetweenNodes : function(node, parent) {
		var me = this,
//		    parentView = Ext.getCmp(parent.data.viewId),
//		    view = Ext.getCmp(node.data.viewId),
		    nodeXY = node.getXY(),
		    parentXY = parent.getXY(),
		    p1 , p2 , p3;
		
			p1 = {
				x : parentXY.x + (parent.data.text.length * 5),
				y : parentXY.y + 17
			};			
			
		
			if(node.isLeaf() && node.data.isLeft) {
				p3 = {
						x : nodeXY.x + (node.data.text.length * 6.3),
						y : nodeXY.y + 6
					};
				p2 = {
						x : parentXY.x + (parent.data.text.length * 5),
						y : nodeXY.y + 6
					};
			} else if(node.isLeaf() && node.data.isRight){
				p3 = {
						x : nodeXY.x - (node.data.text.length - 3),
						y : nodeXY.y + 6
					};
				p2 = {
						x : parentXY.x + (parent.data.text.length * 5),
						y : nodeXY.y + 6
					};
			} else {
				p3 = {
						x : nodeXY.x + (node.data.text.length * 5),
						y : nodeXY.y + 17
					};
				p2 = {
						x : parentXY.x + (parent.data.text.length * 5),
						y : nodeXY.y + 17
					};
			}

		
			me.bezierCurveTo(p1, p2, p2, p3);
//			me.lineTo(p1, p2);
//			me.lineTo(p2, p3);
	},
	
	
	printChilds : function(node) {
		
		var me = this,
			previousNode = node.previousSibling,
			parentHeight, firstChildPosition,
			nodeCenterPosition, previousNodeHeight,
			parent = node.parentNode;
		
		if(parent.isMMExpanded()) {
		if(previousNode && ((node.data.left && previousNode.previousSibling) || (node.data.right && previousNode.previousSibling))) {
			previousNode = previousNode.previousSibling;
			nodeCenterPosition = node.data.height / 2;
			previousNodeHeight = (previousNode.data.height / 2);
			node.setY((previousNode.getY() + previousNodeHeight + nodeCenterPosition));
		} else if(previousNode && !node.data.left && !node.data.right) {
			nodeCenterPosition = node.data.height / 2;
			previousNodeHeight = (previousNode.data.height / 2);
			node.setY((previousNode.getY() + previousNodeHeight + nodeCenterPosition));
		} else {
			if(node.data.left) {
				parentHeight = parent.data.leftHeight;
			} else if(node.data.right) {
				parentHeight = parent.data.rightHeight;
			} else {
				parentHeight = parent.data.height;
			}
			parentHeight = parentHeight / 2;
			firstChildPosition = parent.getY() - parentHeight;
			nodeCenterPosition = node.data.height / 2;
			node.setY(firstChildPosition + nodeCenterPosition);
		}
		
		me.drawNode(node);
		me.lineBetweenNodes(node, parent);
		node.eachChild(function(child) {
			me.printChilds(child);
		});
		}
	},
	
	rootCls : 'xty-mindmap-root',
	nodeCls : 'xty-mindmap-node',
	leafCls : 'xty-mindmap-leaf',
	
	
	drawNode : function(node) {
		var me = this, baseCls;
		
		if(node.isRoot()) {
			baseCls = me.rootCls;
		} else if(node.isLeaf()) {
			baseCls = me.leafCls;
		} else {
			baseCls = me.nodeCls;
		}
		
		
		var view =  me.add({
			xtype : 'splitbutton',
			text : node.data.text,
			//basxeCls : baseCls,
			cls : 'button-draggable',
			//iconCls : 'xty_iconLoading',
			scale : 'small',
			height: 32,
			iconAlign : 'left',
			x : node.getX(),
			y : node.getY(),
			node : node,
			parent: node.parentNode,
			listeners : {
				render : function(btn) {
					btn.dragZone  = new Ext.dd.DragZone(Ext.getBody(),{
						getDragData : function(e) {
							if(sourceEl = e.getTarget('.button-draggable')) {					
								d = sourceEl.cloneNode(true);
								d.id = Ext.id();
								return btn.dragData = {
									sourceEl: sourceEl,
									node : btn.node,
									repairXY: Ext.fly(sourceEl).getXY(),
									ddel: d
								}
							}
						},
						onDrag: function(e) {
							var proxy = Ext.DomQuery.select('*', this.getDragEl());				
							proxy[2].style.position = '';
						},
						getRepairXY: function() {
							return this.dragData.repairXY;
						}
					});
				},
				afterrender : function(btn, eOtps) {
					if(btn.node.isMMExpanded() && !btn.node.isLeaf()) {
						btn.getEl().down("em").setStyle("background-image", "url(s-collapse.gif)");
					} else if(!btn.node.isLeaf()){
						btn.getEl().down("em").setStyle("background-image", "url(s-expand.gif)");
					}
				},
				arrowclick : function(btn,  e, eOpts) {
					Ext.getCmp('panel_mC').setLoading(true);
					if(btn.node.isMMExpanded()) {
						btn.node.mmCollapse();
						
					} else {
						btn.node.mmExpand();
						
					}
					me.draw();
					Ext.getCmp('panel_mC').setLoading(false);
				}
			}
		});
		
		node.data.viewId = view.getId();
	},
	
	nodeDistance : 180,
	previousDistance : 40,
	rightDepth : 0,
	leftDepth : 0,
	
	addChildNode : function(node, right) {
		var parent = node.parentNode,
	 	x, y, offset,
	 	me = this;
		
		var depth = node.getDepth();
		if(right && depth > me.rightDepth) {
			me.rightDepth = depth;
		} else if(depth > me.leftDepth) {
			me.leftDepth = depth;
		}
		
		offset = right ? 1 : -1;
	
		x = parent.getX() + (offset * me.nodeDistance);
		y = parent.getY();
		node.data.subnodes = node.childNodes.length;
		node.data.height = 0;
		node.data.isLeft = !right;
		node.data.isRight = right;
		if(node.isLeaf()) {
			node.data.height = 40;
		}

		me.addPointInterface(node, x, y);
		
		node.eachChild(function(child){
			node.data.height += me.addChildNode(child, right);
		});
		
		return node.data.height;
	},
	
	addToLeft : function(node) {
		return this.addChildNode(node, false);
	},
	
	addToRight : function(node, pos) {
		return this.addChildNode(node, true);
	},	
	
	itemId : '#test',
	
	listeners : {
		afterrender : function(me)  {
			me.canvas = Ext.get(me.canvasId).dom;
			me.context = me.canvas.getContext("2d");
			var canvasEl = Ext.get(me.canvasId);
			me.dropZone = new Ext.dd.DropZone(me.body, {
				getTargetFromEvent : function(e) {
					return e.getTarget('#'+ me.canvasId);
				},
				onNodeOver : function(target, dd, e, data) {
					return Ext.dd.DropZone.prototype.dropAllowed;
				},
				onNodeDrop : function(target, dd, e , data) {
					if(dragEl = Ext.get(data.sourceEl)) {					
						dragEl.setXY([e.getPageX(),e.getPageY()]);					
					}
					return true;
				}
			});	
			
		}
	},
	
	initialize : function() {
		var me = this;
		var root = me.store.getRootNode();
		me.initRootNode(root);
		var i = 0;
		
		me.initialized = true;
		
		for(i; i < root.childNodes.length; i++) {
			child = root.childNodes[i];
			if(i%2 === 0) {
				child.data.left = true;
				root.data.leftHeight += me.addToLeft(child);
			} else {
				child.data.right = true;
				root.data.rightHeight += me.addToRight(child);
			}
		}
	}

});