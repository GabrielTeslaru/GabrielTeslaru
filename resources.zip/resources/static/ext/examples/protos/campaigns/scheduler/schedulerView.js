Ext.namespace('extVia.campaigns.scheduler.view');

/**
 * @class extVia.campaigns.scheduler.view
 */
extVia.campaigns.scheduler.view = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.scheduler.view",
    name : "extVia.campaigns.scheduler.view"
  });
};

extVia.campaigns.scheduler.view.prototype = {

  getStoreType : function getStoreType() {

    var storeType = Ext.create('Ext.data.Store', {
      fields : [ 'type', 'name', 'icon' ],
      data : [ {
        'type' : 'K',
        'name' : 'Kataloge',
        'icon' : 'sammlung'
      }, {
        'type' : 'M',
        'name' : 'Messe',
        'icon' : 'handshake'
      }, {
        'type' : 'E',
        'name' : 'Epim',
        'icon' : 'epim'
      } ]
    });
    return storeType;
  },
  
  /**
   * 
   * @param ownerId
   * @returns window
   */
  createMilestoneDialog : function createMilestoneDialog(ownerId, recordId) {
    var startDate = extVia.campaigns.scheduler.control.generateStartDate();

    if (!Ext.getCmp('createMilestoneDialogId')) {

      var window = null;
      window = Ext.create('Ext.window.Window', {
        bodyPadding : 10,
        id : 'createMilestoneDialogId',
        width : 310,
        height : 190,
        frame : false,
        maximizable : false,
        // resizable : false,
        title : 'Neuer Meilenstein',
        // defaults : {},
        items : [ {
          xtype : 'radiogroup',
          fieldLabel : 'Milestones',
          defaultType : 'radiofield',
          columns : 3,
          vertical : true,
          items : [ {
            // checked : true,
            boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_green_one.png"/>&nbsp;&nbsp;&nbsp;',
            name : 'pType',
            inputValue : '1',
            milestone : 'green',
            id : 'radio1'
          }, {
            boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_one.png"/>&nbsp;&nbsp;&nbsp;',
            name : 'pType',
            inputValue : '2',
            milestone : 'blue',
            id : 'radio2'
          }, {
            boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_gold_one.png"/>&nbsp;&nbsp;&nbsp;',
            name : 'pType',
            inputValue : '3',
            milestone : 'gold',
            id : 'radio3'
          }, {
            boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_red_one.png"/>&nbsp;&nbsp;&nbsp;',
            name : 'pType',
            inputValue : '4',
            milestone : 'red',
            id : 'radio4'
          }, {
            boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_orange_one.png"/>&nbsp;&nbsp;&nbsp;',
            name : 'pType',
            inputValue : '5',
            milestone : 'orange',
            id : 'radio5'
          }, {
            boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_purple_one.png"/>&nbsp;&nbsp;&nbsp;',
            name : 'pType',
            inputValue : '6',
            milestone : 'purple',
            id : 'radio6'
          } ]
        }, {
          xtype : 'datefield',
          padding : '15 0 0 0',
          // anchor : '100%',
          fieldLabel : 'Date',
          name : 'from_date',
          emptyText : Ext.Date.format(startDate, 'Y-m-d'),
          format : 'Y m d',
          minValue : startDate,
          value : startDate,
          width : 280
        } ],

        buttons : [ {
          xtype : 'button',
          text : 'Add',
          width : 50,
          handler : function() {

            var checked, fields, mStone, msDate;
            fields = this.ownerCt.ownerCt.items.items;

            checked = fields[0].getChecked();
            mStone = checked[0].milestone; // oder mStone = checked[0].inputValue;
            msDate = fields[1].getValue();

            extVia.campaigns.scheduler.control.addMilestoneFn(ownerId, recordId, mStone, msDate);
          }
        } ]

      });

      return window.show();
    }

  },

  /**
   * 
   * @param scheduler
   * @param date
   * @param rowIndex
   * @returns window
   */
  createMilestoneDialogOnSchClick : function createMilestoneDialogOnSchClick(scheduler, date, rowIndex) {
    var record = null;
    eventConfigTemp = {
      milestone : record ? true : false,
      mlstName : record ? record.get('Name') : 'TestMilenstone',
      mlstColor : record ? record.get('Style') : '',
      mlstDscr : record ? record.get('Dscr') : ''
    };

    if (!Ext.getCmp('createMilestoneDialogOnSchClickId')) {

      var window = null;
      window = Ext.create('Ext.window.Window', {
        bodyPadding : 10,
        id : 'createMilestoneDialogOnSchClickId',
        width : 280,
        height : 220,
        frame : false,
        maximizable : false,
        // resizable : false,
        title : 'Neuer Meilenstein',
        // defaults : {},
        items : [
        // {
        // xtype : 'radiogroup',
        // itemId : 'mlstGroupId',
        // fieldLabel : 'Milestones',
        // defaultType : 'radiofield',
        // columns : 3,
        // vertical : true,
        // items : [ {
        // // checked : true,
        // boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_green_one.png"/>&nbsp;&nbsp;&nbsp;',
        // name : 'pType',
        // inputValue : '1',
        // milestone : 'green',
        // id : 'radio1'
        // }, {
        // boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_one.png"/>&nbsp;&nbsp;&nbsp;',
        // name : 'pType',
        // inputValue : '2',
        // milestone : 'blue',
        // id : 'radio2'
        // }, {
        // boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_gold_one.png"/>&nbsp;&nbsp;&nbsp;',
        // name : 'pType',
        // inputValue : '3',
        // milestone : 'gold',
        // id : 'radio3'
        // }, {
        // boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_red_one.png"/>&nbsp;&nbsp;&nbsp;',
        // name : 'pType',
        // inputValue : '4',
        // milestone : 'red',
        // id : 'radio4'
        // }, {
        // boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_orange_one.png"/>&nbsp;&nbsp;&nbsp;',
        // name : 'pType',
        // inputValue : '5',
        // milestone : 'orange',
        // id : 'radio5'
        // }, {
        // boxLabel : '<img style="margin-bottom:-3px;" src="images/milestone_purple_one.png"/>&nbsp;&nbsp;&nbsp;',
        // name : 'pType',
        // inputValue : '6',
        // milestone : 'purple',
        // id : 'radio6'
        // } ]
        // }
        extVia.campaigns.scheduler.control.getColorfieldMlst(eventConfigTemp, 128), {
          xtype : 'textfield',
          itemId : 'mlstNameId',
          name : 'name',
          fieldLabel : 'Name',
          maxLength : 100,
          width : 230,
          labelWidth : 110
        // ,allowBlank : false
        }, {
          xtype : 'textareafield',
          itemId : 'mlstDscrId',
          grow : false,
          name : 'dscr',
          width : 230,
          height : 50,
          fieldLabel : 'Description',
          labelWidth : 110
        // anchor : '100%'
        } ],

        buttons : [ {
          xtype : 'button',
          text : 'Add',
          width : 50,
          handler : function() {

            var fields, mStone, name, dscr;
            fields = this.ownerCt.ownerCt;

            mStone = eventConfigTemp.mlstColor ? eventConfigTemp.mlstColor : 'blue';
            name = fields.getComponent('mlstNameId').getValue();
            dscr = fields.getComponent('mlstDscrId').getValue();

            var evStore = scheduler.getEventStore();
            var treeStore = scheduler.getStore();

            var resourceId = treeStore.data.getByKey(rowIndex + 1).data.Id;

            evStore.add({
              ResourceId : resourceId,
              Name : name,
              StartDate : date,
              EndDate : date,
              Resizable : false,
              Style : mStone,
              Dscr : dscr,
              Type : 'Milestone'
            });

            Ext.getCmp('createMilestoneDialogOnSchClickId').close();
            evStore.sync();
          }
        } ]

      });

      return window.show();
    }
  },

  /**
   * Returns dialogue for creating new Campaigne
   * 
   * @param view
   * @param record
   * @returns
   */
  addTreeNodeRightClick : function addTreeNodeRightClick(view, record) {

    if (!Ext.getCmp('createTreeNodeOnRightClickId')) {

      var storePrio = Ext.create('Ext.data.Store', {
        fields : [ 'prio' ],
        data : [ {
          'prio' : 'A'
        }, {
          'prio' : 'B'
        }, {
          'prio' : 'C'
        }, {
          'prio' : 'D'
        }, {
          'prio' : 'E'
        } ]
      });

//      var prioCombo = Ext.create('Ext.form.field.ComboBox', {
//        fieldLabel : 'Prio',
//        displayField : 'prio',
//        itemId : 'prioComboId',
//        name : 'prio',
//        width : 210,
//        labelWidth : 110,
//        store : storePrio,
//        queryMode : 'local'
//      });

      var addEpobDialog = Ext.create(
              'widget.window',
              {
                // width: dialogDefaultWidth,
                // x: pos_col_3,
                // y: pos_row_1-40,
                width : 420,
                height : 470,
                id : 'createTreeNodeOnRightClickId',
                title : 'Neue Kampagne',

                plain : true,

                items : [ {
                  border : false,
                  minHeight : 200,

                  itemId : 'myFormPanel',
                  xtype : 'form',

                  dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
                    var dialogButtons = this.ownerCt.getComponent('myButtons');

                    var activate = dirty;
                    if (!valid)
                      activate = false;

                    if (activate)
                      dialogButtons.getComponent('apply').enable();
                    else
                      dialogButtons.getComponent('apply').disable();
                    if (activate)
                      dialogButtons.getComponent('create').enable();
                    else
                      dialogButtons.getComponent('create').disable();

                  },

                  listeners : {

                    validitychange : function(basic, valid, eOpts) {
                      this.dirtyAndValiditychange(basic, this.getForm().isDirty(), valid, eOpts);
                    },
                    dirtychange : function(basic, dirty, eOpts) {
                      this.dirtyAndValiditychange(basic, dirty, this.getForm().isValid(), eOpts);
                    },

                    dirtychangeOLD : function(basic, dirty, eOpts) {
                      var dialogButtons = this.ownerCt.getComponent('myButtons');

                      var activate = dirty;

                      if (!this.getForm().isValid())
                        activate = false;

                      if (activate)
                        dialogButtons.getComponent('apply').enable();
                      else
                        dialogButtons.getComponent('apply').disable();
                      if (activate)
                        dialogButtons.getComponent('create').enable();
                      else
                        dialogButtons.getComponent('create').disable();

                    }
                  },

                  fieldDefaults : {
                  // msgTarget : 'side',
                  },
                  defaults : {
                    style : 'margin:0px 10px 4px 14px;',
                    anchor : '100%',
                    labelWidth : 130,
                    width : 350
                  },
                  items : [
                           {
                             border : false,
                             itemId : 'instructionPanel',
                             width : null,
                             style : 'padding:10px 0px 15px 10px',
                             items : [
                                      {
                                        itemId : 'mainInstruction',
                                        border : false,
                                        style : 'padding:0px 0px 4px 0px',
                                        html : '<div class="xty_dialog-mainInstr">Erstellen Sie eine <i>Kampagne in: </i><i style="font-weight:normal">'
                                               + record.data.Name + '</i></div>'
                                      },
                                      {
                                        itemId : 'supplementalInstruction',
                                        border : false,
                                        hidden : true,
                                        html : '<div class="xty_dialog-supplementalInstr">Legen Sie <i>{das gew�nschte Objekt}</i>, das Anzeigeverhalten und das Erscheinungsbild fest.</div>'
                                      } ]
                           },
                           {
                             xtype : 'displayfield',
                             value : '<b>Allgemeine Metadaten</b>'
                           },
                           {
                             xtype : 'textfield',
                             itemId : 'cmpNameId',
                             name : 'name',
                             labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                             fieldLabel : '&nbsp;Name',
                             // maxLength : 100,
                             // width : 210,
                             // labelWidth : 110,
                             allowBlank : false,
                           // value : 'Test',
                           /*
                             * listeners : { validitychange : function(text, isValid, eOpts ){ var dialogButton =
                             * this.ownerCt.getComponent('myButtons').getComponent('add'); if(isValid){
                             * dialogButton.enable(); }else{ dialogButton.disable(); } } }
                             */
                           },
                           {
                             xtype : 'textarea',
                             itemId : 'description',
                             fieldLabel : '&nbsp;Beschreibung'
                           },
                           {
                             xtype : 'tbspacer',
                             height : 16
                           },
                           {
                             xtype : 'displayfield',
                             value : '<b>Typspezifische Metadaten</b>'
                           },
                           {

                             xtype : 'combobox',
                             fieldLabel : '&nbsp;Prio',
                             displayField : 'prio',
                             itemId : 'prioComboId',
                             name : 'prio',
                             // width : 210,
                             // labelWidth : 110,
                             store : storePrio,
                             queryMode : 'local'

                           },
                           {
                             xtype : 'combobox',
                             fieldLabel : '&nbsp;Type',
                             displayField : 'type',
                             pickerOffset : [ -17, 0 ],
                             itemId : 'typeComboId',
                             name : 'type',
                             editable : false,
                             trigger1Cls : 'xty_menu-trigger',
                             trigger2Cls : 'x-form-menu-trigger',
                             // width : 210,
                             // labelWidth : 110,
                             store : extVia.campaigns.scheduler.view.getStoreType(),
                             fieldStyle : 'position:relative; left:+17px; border-left:0px;',
                             displayTpl : Ext.create('Ext.XTemplate', [ '<tpl for=".">', '{name}', '</tpl>',

                             ]),
                             listConfig : {
                               getInnerTpl : function(displayField) {
                                 var tpl = '<div>' + '<img src="../img/icons/{icon}_16.png" align="left">&nbsp;'
                                           + '{name}' + '</div>';
                                 return tpl;
                               }
                             },
                             listeners : {
                               change : function(field, newValue, oldValue) {
                                 if (newValue == 'K') {
                                   if (oldValue) {
                                     if (oldValue == 'M') {
                                       this.removeCls('xty_menu-trigger-messe');
                                     } else if (oldValue == 'E') {
                                       this.removeCls('xty_menu-trigger-epim');
                                     }
                                   }
                                   this.addCls('xty_menu-trigger-kataloge');
                                 } else if (newValue == 'E') {
                                   if (oldValue) {
                                     if (oldValue == 'M') {
                                       this.removeCls('xty_menu-trigger-messe');
                                     } else if (oldValue == 'K') {
                                       this.removeCls('xty_menu-trigger-kataloge');
                                     }
                                   }
                                   this.addCls('xty_menu-trigger-epim');
                                 } else if (newValue == 'M') {
                                   if (oldValue) {
                                     if (oldValue == 'E') {
                                       this.removeCls('xty_menu-trigger-epim');
                                     } else if (oldValue == 'K') {
                                       this.removeCls('xty_menu-trigger-kataloge');
                                     }
                                   }
                                   this.addCls('xty_menu-trigger-messe');
                                 } else {
                                   if (oldValue) {
                                     if (oldValue == 'M') {
                                       this.removeCls('xty_menu-trigger-messe');
                                     } else if (oldValue == 'K') {
                                       this.removeCls('xty_menu-trigger-kataloge');
                                     } else if (oldValue == 'E') {
                                       this.removeCls('xty_menu-trigger-epim');
                                     }
                                   }
                                 }
                               },
                               focus : function() {
                                 this.addCls('xty_menu-trigger-focus');
                               },

                               blur : function() {
                                 this.removeCls('xty_menu-trigger-focus');
                               },
                               afterrender : function(combo) {
                                 this.addCls('xty_menu-trigger-position');
                               }
                             },
                             queryMode : 'local',
                             onTrigger1Click : function(e) {
                             }

                           }, {
                             xtype : 'numberfield',
                             itemId : 'bgtiId',
                             name : 'bgti',
                             fieldLabel : '&nbsp;Budget Ist (TEUR)',
                             minValue : 0
                           }, {
                             xtype : 'numberfield',
                             itemId : 'bgtsId',
                             name : 'bgts',
                             fieldLabel : '&nbsp;Budget Soll (TEUR)',
                             minValue : 0
                           }, {
                             xtype : 'numberfield',
                             itemId : 'bgtpId',
                             name : 'bgtp',
                             fieldLabel : '&nbsp;Budget Prognosse (TEUR)',
                             minValue : 0
                           }, {
                             xtype : 'numberfield',
                             itemId : 'fgradId',
                             name : 'fgrad',
                             fieldLabel : '&nbsp;Fertigungsgrad (%)',
                             minValue : 0,
                             maxValue : 100
                           }, {
                             xtype : 'tbspacer',
                             height : 16
                           } ]
                } ],

                buttons : {
                  itemId : 'myButtons',
                  items : [ {
                    xtype : 'tbspacer',
                    width : 30
                  }, {
                    itemId : 'create',
                    text : 'Erstellen',
                    disabled : true,
                    handler : function() {

                      var name, prio, type, bgti, bgts, bgtp, fgrad, description;
                      var fields = this.ownerCt.ownerCt.getComponent('myFormPanel');
                      var leaf = true;
                      var iconCls = 'sch-gate';
                      var depth = record.get('depth');

                      name = fields.getComponent('cmpNameId').getValue();
                      type = fields.getComponent('typeComboId').getValue();
                      prio = fields.getComponent('prioComboId').getValue();
                      bgti = fields.getComponent('bgtiId').getValue();
                      bgts = fields.getComponent('bgtsId').getValue();
                      bgtp = fields.getComponent('bgtpId').getValue();
                      fgrad = fields.getComponent('fgradId').getValue();
                      description = fields.getComponent('description').getValue();
                      if (depth < 3) { // children === null || children[0].leaf
                        leaf = false;
                        iconCls = 'sch-terminal';
                      }

                      if (name && name !== '') {
                        var root = JSON.parse(localStorage.StoreJSBlob);
                        var indexes = new Array();
                        function allIndexes(parent) {
                          if (parent.children != null) {
                            if (parent.children.length > 0) {
                              for ( var i = 0; i < parent.children.length; i++) {
                                if (parent.children[i].leaf == true) {
                                  indexes.push(parent.children[i].Id);
                                } else {
                                  indexes.push(parent.children[i].Id);
                                  allIndexes(parent.children[i]);
                                }
                              }
                            } else {
                              return false;
                            }
                          } else {
                            indexes.push(parent.Id);
                          }
                        }
                        ;
                        allIndexes(root);
                        indexes.sort(function(a, b) {
                          return a - b;
                        });
                        var index = indexes.pop() + 1;
                        var child = {
                          Id : index,
                          BudgetI : bgti ? bgti : 0,
                          BudgetS : bgts ? bgts : 0,
                          BudgetP : bgtp ? bgtp : 0,
                          FGrad : fgrad ? fgrad : 0,
                          Name : name,
                          Prio : prio ? prio : 'A',
                          Type : type ? type : 'E',
                          leaf : leaf,
                          iconCls : iconCls,
                          Description : description,
                          // sch-terminal or sch-gate
                          // Id: null,
                          // allowDrag:true,
                          // allowDrop:true,
                          // checked:null,
                          children : leaf ? null : new Array()
                        // cls:"",
                        // depth:12,
                        // expandable:true,
                        // expanded:false,
                        // href:"",
                        // hrefTarget:"",
                        // icon:"",
                        // iconCls:"sch-gate",
                        // index:0,
                        // isFirst:true,
                        // isLast:false,
                        // leaf:true,
                        // loaded:false,
                        // loading:false,
                        // parentId:3,
                        // qtip:"",
                        // qtitle:"",
                        // root:false
                        };

                        record.appendChild(child);
                        // localStorage.setItem("LoadetRoot", root);

                        function search(parent) {
                          if (parent.children != null) {
                            if (record.data.Id == parent.Id) {
                              parent.children.push(child);
                            } else {
                              if (parent.children.length > 0) {
                                for ( var i = 0; i < parent.children.length; i++) {
                                  if (record.data.Id == parent.children[i].Id) {
                                    parent.children[i].children.push(child);
                                    break;
                                  } else if (parent.children[i].leaf == true) {
                                    continue;
                                  } else {
                                    search(parent.children[i]);
                                  }
                                }
                              } else {
                                return false;
                              }
                            }
                          } else {
                            if (record.data.Id == parent.Id) {
                              parent.push(child);
                            }
                          }
                        }
                        ;
//                        var node = search(root);
                        localStorage.StoreJSBlob = JSON.stringify(root);
                        view.refresh();

                        Ext.getCmp('createTreeNodeOnRightClickId').close();
                      }
                    }
                  }, {
                    text : 'Abbrechen',
                    handler : function() {
                      Ext.getCmp('createTreeNodeOnRightClickId').close();
                    }
                  }, {
                    itemId : 'apply',
                    text : '&Uumlbernehmen',
                    disabled : true,
                    handler : function() {

                      var name, prio, type, bgti, bgts, bgtp, fgrad, description;
                      var fields = this.ownerCt.ownerCt.getComponent('myFormPanel');
                      var leaf = true;
                      var iconCls = 'sch-gate';
                      var depth = record.get('depth');

                      name = fields.getComponent('cmpNameId').getValue();
                      type = fields.getComponent('typeComboId').getValue();
                      prio = fields.getComponent('prioComboId').getValue();
                      bgti = fields.getComponent('bgtiId').getValue();
                      bgts = fields.getComponent('bgtsId').getValue();
                      bgtp = fields.getComponent('bgtpId').getValue();
                      fgrad = fields.getComponent('fgradId').getValue();
                      description = fields.getComponent('description').getValue();
                      if (depth < 3) { // children === null || children[0].leaf
                        leaf = false;
                        iconCls = 'sch-terminal';
                      }

                      if (name && name !== '') {
                        var root = JSON.parse(localStorage.StoreJSBlob);
                        var indexes = new Array();
                        function allIndexes(parent) {
                          if (parent.children != null) {
                            if (parent.children.length > 0) {
                              for ( var i = 0; i < parent.children.length; i++) {
                                if (parent.children[i].leaf == true) {
                                  indexes.push(parent.children[i].Id);
                                } else {
                                  indexes.push(parent.children[i].Id);
                                  allIndexes(parent.children[i]);
                                }
                              }
                            } else {
                              return false;
                            }
                          } else {
                            indexes.push(parent.Id);
                          }
                        }
                        ;
                        allIndexes(root);
                        indexes.sort(function(a, b) {
                          return a - b;
                        });
                        var index = indexes.pop() + 1;
                        var child = {
                          Id : index,
                          BudgetI : bgti ? bgti : 0,
                          BudgetS : bgts ? bgts : 0,
                          BudgetP : bgtp ? bgtp : 0,
                          FGrad : fgrad ? fgrad : 0,
                          Name : name,
                          Prio : prio ? prio : 'A',
                          Type : type ? type : 'E',
                          leaf : leaf,
                          iconCls : iconCls,
                          Description : description,
                          // sch-terminal or sch-gate
                          // Id: null,
                          // allowDrag:true,
                          // allowDrop:true,
                          // checked:null,
                          children : leaf ? null : new Array()
                        // cls:"",
                        // depth:12,
                        // expandable:true,
                        // expanded:false,
                        // href:"",
                        // hrefTarget:"",
                        // icon:"",
                        // iconCls:"sch-gate",
                        // index:0,
                        // isFirst:true,
                        // isLast:false,
                        // leaf:true,
                        // loaded:false,
                        // loading:false,
                        // parentId:3,
                        // qtip:"",
                        // qtitle:"",
                        // root:false
                        };

                        record.appendChild(child);
                        // localStorage.setItem("LoadetRoot", root);

                        function search(parent) {
                          if (parent.children != null) {
                            if (record.data.Id == parent.Id) {
                              parent.children.push(child);
                            } else {
                              if (parent.children.length > 0) {
                                for ( var i = 0; i < parent.children.length; i++) {
                                  if (record.data.Id == parent.children[i].Id) {
                                    parent.children[i].children.push(child);
                                    break;
                                  } else if (parent.children[i].leaf == true) {
                                    continue;
                                  } else {
                                    search(parent.children[i]);
                                  }
                                }
                              } else {
                                return false;
                              }
                            }
                          } else {
                            if (record.data.Id == parent.Id) {
                              parent.push(child);
                            }
                          }
                        }
                        ;
//                        var node = search(root);
                        localStorage.StoreJSBlob = JSON.stringify(root);
                        view.refresh();

                      }
                    }
                  } ]
                }
              });
      return addEpobDialog.show();
    }
  },

  /**
   * Returns dialogue for editing a Campaigne
   * 
   * @param view
   * @param record
   * @returns
   */
  editTreeNode : function editTreeNode(view, record) {

    if (!Ext.getCmp('createTreeNodeOnRightClickId')) {

      var storePrio = Ext.create('Ext.data.Store', {
        fields : [ 'prio' ],
        data : [ {
          'prio' : 'A'
        }, {
          'prio' : 'B'
        }, {
          'prio' : 'C'
        }, {
          'prio' : 'D'
        }, {
          'prio' : 'E'
        } ]
      });


//      extVia.stores.initPublicationStore();
      var galleryElements  =  extVia.dialoges.getGalleryView({epobType:'ELEMENTS',pageStart:0,pageSize:7});
      var galleryProd  =  extVia.dialoges.getGalleryView({epobType:'PRODUCTS',pageStart:7,pageSize:3});
      var publicationStore = extVia.campaigns.scheduler.store.getPublicationStore();
      
      var defaultLabelWidth = 150;
      var defaultItmWidth = 410;
//      var windowHeight = extVia.regApp.myRaster.getCenter().getHeight();
      var editEpobDialog = Ext.create('widget.window', {
                width : 480,
                maxWidth : 480,
                height: 730,
                autoScroll: true,
                id : 'editTreeNodeId',
                title : 'Kampagne bearbeiten',
                plain : true,
                items : [ 
                 {
                  border : false,
                  minHeight : 760,
                  itemId : 'myFormPanel',
                  xtype : 'form',
                  
                  dirtyAndValiditychange: function( basic, dirty, valid, eOpts){ 
                    var dialogButtons = this.ownerCt.getComponent('myButtons');

                    var activate = dirty ;
                    if (!valid) activate = false;

                    if (activate) dialogButtons.getComponent('create').enable();//or ok or save
                    else dialogButtons.getComponent('create').disable();
                    
                    if (activate) dialogButtons.getComponent('apply').enable();
                    else dialogButtons.getComponent('apply').disable();
          
                  },
          
                  listeners:{
                    validitychange:function( basic, valid, eOpts ){
                      extVia.dialoges.notifyFormEvent('validitychange','valid',valid,this.ownerCt.title);
                      this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts ); 
                    },  
                    dirtychange:function( basic, dirty, eOpts){
                      extVia.dialoges.notifyFormEvent('dirtychange','dirty',dirty,this.ownerCt.title);
                      this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts ); 
                    }
                  },

                  fieldDefaults : {
                  // msgTarget : 'side',
                  },
                  
                  defaults : {
                   style : 'margin:0px 10px 0px 10px;',
                   anchor : '100%'
                  },
                  
                  items : [{
                             border : false,
                             itemId : 'instructionPanel',
                             width : null,
                             style : 'padding:10px 0px 15px 10px',
                             items : [
                                {
                                  itemId : 'mainInstruction',
                                  border : false,
                                  style : 'padding:0px 0px 4px 0px',
                                  html : '<div class="xty_dialog-mainInstr">Bearbeiten Sie die <i>Kampagne: </i><i style="font-weight:normal">'
                                         + record.data.Name + '</i></div>'

                                },
                                {
                                  itemId : 'supplementalInstruction',
                                  border : false,
                                  hidden : true,
                                  html : '<div class="xty_dialog-supplementalInstr">Legen Sie <i>{das gew�nschte Objekt}</i>, das Anzeigeverhalten und das Erscheinungsbild fest.</div>'
                                } ]
                           },
                           {
                             xtype : 'tbspacer',
                             height : 5
                           },
                           {
                             xtype : 'fieldset',
                             itemId : 'fieldsetId1',
                             title : '<b>Allgemeine Metadaten</b>',
                             collapsible : true,
                             collapsed : false,
                             defaults : {
                               width : defaultItmWidth,
                               labelWidth : defaultLabelWidth
                             },
                             items : [
                                      {
                                        xtype : 'textfield',
                                        itemId : 'cmpNameId',
                                        name : 'name',
                                        labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                                        fieldLabel : 'Name',
                                        value : record.data.Name
                                      },
                                      {
                                        xtype:'combo',
                                        itemId:'tags',
                                        triggerCls : 'x-form-publication-trigger',
                                        store: publicationStore,
                                        queryMode: 'local',
                                        displayField: 'dscr',
                                        multiSelect: true,
                                        emptyText: 'Pick tags',
                                        valueField: 'epobId',
                                        value: '1',
                                        fieldLabel: 'Publikation'
                                      },
                                      {
                                        xtype : 'combobox',
                                        fieldLabel : 'Priorit\u00E4t',
                                        displayField : 'prio',
                                        itemId : 'prioComboId',
                                        name : 'prio',
                                        store : storePrio,
                                        queryMode : 'local',
                                        value : record.data.Prio
                                      },
                                      {
                                        xtype : 'combobox',
                                        fieldLabel : 'Typ',
                                        displayField : 'type',
                                        pickerOffset : [ -17, 0 ],
                                        itemId : 'typeComboId',
                                        trigger1Cls : 'xty_menu-trigger',
                                        trigger2Cls : 'x-form-menu-trigger',
                                        fieldStyle : 'position:relative; left:+17px; border-left:0px;',
                                        editable : false,
                                        name : 'type',
                                        store : extVia.campaigns.scheduler.view.getStoreType(),
                                        queryMode : 'local',
                                        displayTpl : Ext.create('Ext.XTemplate',
                                            [ '<tpl for=".">', '{name}', '</tpl>' ]),
                                        value : record.data.Type,
                                        // ,onTrigger1Click: function(e) {}
                                        listConfig : {
                                          getInnerTpl : function(displayField) {
                                            return '<div>' + '<img src="../img/icons/{icon}_16.png" align="left">'
                                                   + '&nbsp;{name}' + '</div>';
                                          }
                                        },
                                        listeners : {
                                          change : function(field, newValue, oldValue) {
                                            if (newValue == 'K') {
                                              if (oldValue) {
                                                if (oldValue == 'M') {
                                                  this.removeCls('xty_menu-trigger-messe');
                                                } else if (oldValue == 'E') {
                                                  this.removeCls('xty_menu-trigger-epim');
                                                }
                                              }
                                              this.addCls('xty_menu-trigger-kataloge');
                                            } else if (newValue == 'E') {
                                              if (oldValue) {
                                                if (oldValue == 'M') {
                                                  this.removeCls('xty_menu-trigger-messe');
                                                } else if (oldValue == 'K') {
                                                  this.removeCls('xty_menu-trigger-kataloge');
                                                }
                                              }
                                              this.addCls('xty_menu-trigger-epim');
                                            } else if (newValue == 'M') {
                                              if (oldValue) {
                                                if (oldValue == 'E') {
                                                  this.removeCls('xty_menu-trigger-epim');
                                                } else if (oldValue == 'K') {
                                                  this.removeCls('xty_menu-trigger-kataloge');
                                                }
                                              }
                                              this.addCls('xty_menu-trigger-messe');
                                            } else {
                                              if (oldValue) {
                                                if (oldValue == 'M') {
                                                  this.removeCls('xty_menu-trigger-messe');
                                                } else if (oldValue == 'K') {
                                                  this.removeCls('xty_menu-trigger-kataloge');
                                                } else if (oldValue == 'E') {
                                                  this.removeCls('xty_menu-trigger-epim');
                                                }
                                              }
                                            }
                                          },
                                          focus : function() {
                                            this.addCls('xty_menu-trigger-focus');
                                          },

                                          blur : function() {
                                            this.removeCls('xty_menu-trigger-focus');
                                          },
                                          afterrender : function(combo) {
                                            this.addCls('xty_menu-trigger-position');
                                            if (combo.value == 'K') {
                                              this.addCls('xty_menu-trigger-kataloge');
                                            } else if (combo.value == 'E') {
                                              this.addCls('xty_menu-trigger-epim');
                                            } else if (combo.value == 'M') {
                                              this.addCls('xty_menu-trigger-messe');
                                            } else {
                                            }
                                          }
                                        }
                                        
                                      }, {
                                        xtype : 'textarea',
                                        itemId : 'description',
                                        fieldLabel : 'Beschreibung',
                                        value : record.data.Description
//                                        ,height: 30
                                      } ]
                           },

                           {
                             xtype : 'tbspacer',
                             height : 10
                           },
                           {
                             xtype : 'fieldset',
                             itemId : 'fieldsetId2',
                             title : '<b>Budget</b>', // Typspezifische Metadaten
                             collapsible : true,
                             collapsed : false,
                             defaults : {
                               width : defaultItmWidth,
                               labelWidth : defaultLabelWidth
                             },
                             items : [ {
                               xtype : 'numberfield',
                               itemId : 'bgtiId',
                               name : 'bgti',
                               fieldLabel : 'Budget Ist (TEUR)',
                               minValue : 0,
                               value : record.data.BudgetI
                             }, {
                               xtype : 'numberfield',
                               itemId : 'bgtsId',
                               name : 'bgts',
                               fieldLabel : 'Budget Soll (TEUR)',
                               minValue : 0,
                               value : record.data.BudgetS
                             }, {
                               xtype : 'numberfield',
                               itemId : 'bgtpId',
                               name : 'bgtp',
                               fieldLabel : 'Prognosse (TEUR)',
                               minValue : 0,
                               value : record.data.BudgetP
                             }, {
                               xtype : 'numberfield',
                               itemId : 'fgradId',
                               name : 'fgrad',
                               fieldLabel : 'Fertigstellung (%)', // Fertigungsgrad
                               minValue : 0,
                               maxValue : 100,
                               value : record.data.FGrad
                             } ]
                           },

                           {
                             xtype : 'tbspacer',
                             height : 10
                           },
                           {
                             xtype : 'fieldset',
                             title : '<b>Contentelemente</b>',
                             bodyStyle : 'margin:-5px 0px 0px -5px;',
                             collapsible : true,
                             collapsed : false,
                             defaults : {
                               width : defaultItmWidth
                             },
                             items : [galleryElements]
                           },

                           {
                             xtype : 'tbspacer',
                             height : 10
                           },
                           {
                             xtype : 'fieldset',
                             title : '<b>Produkte</b>',
                             collapsible : true,
                             collapsed : false,
                             defaults : {
                               width : defaultItmWidth,
                               style : 'margin:-5px 0px 0px -5px;'
                             },
                             items : [galleryProd]
                           }]
                } ],

                buttons : {
                  itemId : 'myButtons',
                  items : [ {
                    xtype : 'tbspacer',
                    width : 30
                  }, {
                    itemId : 'ok',
                    text : 'OK',
                    disabled : true,
                    handler : function() {

                      var name, prio, type, bgti, bgts, bgtp, fgrad, description, leaf;
                      var fields = this.ownerCt.ownerCt.getComponent('myFormPanel');
                      var iconCls = 'sch-gate';
                      // var depth = record.get('depth');

                      name = fields.getComponent('fieldsetId1').getComponent('cmpNameId').getValue();
                      prio = fields.getComponent('fieldsetId1').getComponent('prioComboId').getValue();
                      type = fields.getComponent('fieldsetId1').getComponent('typeComboId').getValue();
                      description = fields.getComponent('fieldsetId1').getComponent('description').getValue();

                      bgti = fields.getComponent('fieldsetId2').getComponent('bgtiId').getValue();
                      bgts = fields.getComponent('fieldsetId2').getComponent('bgtsId').getValue();
                      bgtp = fields.getComponent('fieldsetId2').getComponent('bgtpId').getValue();
                      fgrad = fields.getComponent('fieldsetId2').getComponent('fgradId').getValue();

                      leaf = record.data.leaf;
                      if (name && name !== '') {
                        var root = JSON.parse(localStorage.StoreJSBlob);
                        var child = {
                          Id : record.data.Id,
                          BudgetI : bgti ? bgti : 0,
                          BudgetS : bgts ? bgts : 0,
                          BudgetP : bgtp ? bgtp : 0,
                          FGrad : fgrad ? fgrad : 0,
                          Name : name,
                          Prio : prio ? prio : 'A',
                          Type : type ? type : 'E',
                          leaf : leaf,
                          iconCls : iconCls,
                          Description : description,
                          // sch-terminal or sch-gate
                          // Id: null,
                          // allowDrag:true,
                          // allowDrop:true,
                          // checked:null,
                          children : leaf ? null : new Array()
                        // cls:"",
                        // depth:12,
                        // expandable:true,
                        // expanded:false,
                        // href:"",
                        // hrefTarget:"",
                        // icon:"",
                        // iconCls:"sch-gate",
                        // index:0,
                        // isFirst:true,
                        // isLast:false,
                        // leaf:true,
                        // loaded:false,
                        // loading:false,
                        // parentId:3,
                        // qtip:"",
                        // qtitle:"",
                        // root:false
                        };

                        function putData(record) {
                          record.Name = child.Name;
                          record.BudgetI = child.BudgetI;
                          record.BudgetS = child.BudgetS;
                          record.BudgetP = child.BudgetP;
                          record.FGrad = child.FGrad;
                          record.Prio = child.Prio;
                          record.Type = child.Type;
                          record.Description = child.Description;
                        }
                        ;

                        putData(record.data);

                        function search(parent) {
                          if (parent.children != null) {
                            if (record.data.Id == parent.Id) {
                              putData(parent);
                            } else {
                              if (parent.children.length > 0) {
                                for ( var i = 0; i < parent.children.length; i++) {
                                  if (record.data.Id == parent.children[i].Id) {
                                    putData(parent.children[i]);
                                    break;
                                  } else if (parent.children[i].leaf == true) {
                                    continue;
                                  } else {
                                    search(parent.children[i]);
                                  }
                                }
                              } else {
                                return false;
                              }
                            }
                          } else {
                            if (record.data.Id == parent.Id) {
                              putData(parent);
                            }
                          }
                        }
                        ;
//                        var node = search(root);
                        localStorage.StoreJSBlob = JSON.stringify(root);
                        view.refresh();

                        Ext.getCmp('editTreeNodeId').close();
                      }
                    }
                  }, {
                    text : 'Abbrechen',
                    handler : function() {
                      Ext.getCmp('editTreeNodeId').close();
                    }
                  },

                  {
                    itemId : 'apply',
                    text : '&Uumlbernehmen',
                    disabled : true,

                    handler : function() {

                      var name, prio, type, bgti, bgts, bgtp, fgrad, description, leaf;
                      var fields = this.ownerCt.ownerCt.getComponent('myFormPanel');
                      var iconCls = 'sch-gate';
                      // var depth = record.get('depth');

                      name = fields.getComponent('fieldsetId1').getComponent('cmpNameId').getValue();
                      prio = fields.getComponent('fieldsetId1').getComponent('prioComboId').getValue();
                      type = fields.getComponent('fieldsetId1').getComponent('typeComboId').getValue();
                      description = fields.getComponent('fieldsetId1').getComponent('description').getValue();

                      bgti = fields.getComponent('fieldsetId2').getComponent('bgtiId').getValue();
                      bgts = fields.getComponent('fieldsetId2').getComponent('bgtsId').getValue();
                      bgtp = fields.getComponent('fieldsetId2').getComponent('bgtpId').getValue();
                      fgrad = fields.getComponent('fieldsetId2').getComponent('fgradId').getValue();
                      leaf = record.data.leaf;
                      if (name && name !== '') {
                        var root = JSON.parse(localStorage.StoreJSBlob);
                        var child = {
                          Id : record.data.Id,
                          BudgetI : bgti ? bgti : 0,
                          BudgetS : bgts ? bgts : 0,
                          BudgetP : bgtp ? bgtp : 0,
                          FGrad : fgrad ? fgrad : 0,
                          Name : name,
                          Prio : prio ? prio : 'A',
                          Type : type ? type : 'E',
                          leaf : leaf,
                          iconCls : iconCls,
                          Description : description,
                          // sch-terminal or sch-gate
                          // Id: null,
                          // allowDrag:true,
                          // allowDrop:true,
                          // checked:null,
                          children : leaf ? null : new Array()
                        // cls:"",
                        // depth:12,
                        // expandable:true,
                        // expanded:false,
                        // href:"",
                        // hrefTarget:"",
                        // icon:"",
                        // iconCls:"sch-gate",
                        // index:0,
                        // isFirst:true,
                        // isLast:false,
                        // leaf:true,
                        // loaded:false,
                        // loading:false,
                        // parentId:3,
                        // qtip:"",
                        // qtitle:"",
                        // root:false
                        };

                        function putData(record) {
                          record.Name = child.Name;
                          record.BudgetI = child.BudgetI;
                          record.BudgetS = child.BudgetS;
                          record.BudgetP = child.BudgetP;
                          record.FGrad = child.FGrad;
                          record.Prio = child.Prio;
                          record.Type = child.Type;
                          record.Description = child.Description;
                        }
                        ;

                        putData(record.data);

                        function search(parent) {
                          if (parent.children != null) {
                            if (record.data.Id == parent.Id) {
                              putData(parent);
                            } else {
                              if (parent.children.length > 0) {
                                for ( var i = 0; i < parent.children.length; i++) {
                                  if (record.data.Id == parent.children[i].Id) {
                                    putData(parent.children[i]);
                                    break;
                                  } else if (parent.children[i].leaf == true) {
                                    continue;
                                  } else {
                                    search(parent.children[i]);
                                  }
                                }
                              } else {
                                return false;
                              }
                            }
                          } else {
                            if (record.data.Id == parent.Id) {
                              putData(parent);
                            }
                          }
                        }
                        ;
//                        var node = search(root);
                        localStorage.StoreJSBlob = JSON.stringify(root);
                        view.refresh();
                      }
                    }
                  } ]
                }
              });
      
      
      return editEpobDialog.show();
    }
  },


  /**
   * 
   * @returns cellEditing
   */
  getCellEditingCfg : function getCellEditingCfg() {

    var cellEditing = Ext.create('Sch.plugin.TreeCellEditing', {
      clicksToEdit : 1,
      listeners : {
        beforeedit : function() {
          // alert('cellEditing-beforeedit'); //return !Ext.getCmp('demo-readonlybutton').pressed;
        },
        edit : function(e, record) {
          var root = JSON.parse(localStorage.StoreJSBlob);
          function search(parent) {
            if (parent.children != null) {
              if (parent.children.length > 0) {
                for ( var i = 0; i < parent.children.length; i++) {
                  if (record.record.data.Id == parent.children[i].Id) {
                    parent.children[i][record.field] = record.value;
                    break;
                  } else if (parent.children[i].leaf == true) {
                    continue;
                  } else {
                    search(parent.children[i]);
                  }
                }
              } else {
                return false;
              }
            } else {
              if (record.data.Id == parent.Id) {
                parent.push(child);
              }
            }
          }
          ;
//          var node = search(root);
          localStorage.StoreJSBlob = JSON.stringify(root);
        }
      }
    });

    return cellEditing;
  },

  searchFilter : function searchFilter(fValue, store) {

    // var store = store; //grid.getStore();
    var trimStr = fValue.trim();

    if (trimStr.search(/\*/) !== -1 && trimStr.length > 1) {
      trimStr = trimStr.replace(/\*/g, "");
    }
    if (trimStr.search(/\:/) !== -1) {
      var spValue = trimStr.split(':');
      if (spValue[0].toUpperCase() === 'GROUP') {
        store.filterBy(function(record, id) {
          var str = record.get('group').toUpperCase();
          if (str.search(spValue[1].toUpperCase()) !== -1) { // str.search(/trimStr.+/)
            return true;
          }
          return false;
        });
      }
    }
    if (trimStr.search(/\:/) === -1) {
      if (trimStr.length === 1 && trimStr === '*') {
        store.filterBy(function(record, id) {
          return true;
        });
      } else {
        store.filterBy(function(record, id) {
          var str = record.get('Name').toUpperCase();
          if (str.search(trimStr.toUpperCase()) !== -1) { // str.search(/trimStr.+/)
            return true;
          }
          return false;
        });
      }
    }
  },

  /**
   * Filter names
   * 
   * @param modelFieldname
   * @param resourceStore
   * @param width
   * @returns {filterTemplCfg}
   */
  getFilterCfg : function getFilterCfg(modelFieldname, resourceStore, width) {

    var filterTemplCfg = {

      xtype : 'textfield',
      width : width,
      tooltip : 'Filter',
      emptyText : 'Filter ' + modelFieldname,
      // triggerCls : 'x-form-clear-trigger',
      // onTriggerClick : function() {
      // this.setValue('');
      // },
      listeners : {
        change : function(field, newValue, oldValue) {
          if (newValue) {
            if (resourceStore.nodeStore.data.items[8]) {
              resourceStore.nodeStore.data.items[8].expand();
              resourceStore.nodeStore.data.items[8].expandChildren();
            }
            resourceStore.nodeStore.filterBy(function(record, id) {
              var str = record.get(modelFieldname).toUpperCase();
              if (str.search(newValue.toUpperCase()) !== -1) {
                return true;
              }
              return false;
            });

            this.ownerCt.ownerCt.lockedGrid.getView().refresh();
            this.ownerCt.ownerCt.normalGrid.getView().refresh();
            // var res = extVia.campaigns.scheduler.view.searchFilter(newValue, resourceStore.nodeStore.data);

          } else {
            resourceStore.nodeStore.clearFilter();
            this.ownerCt.ownerCt.lockedGrid.getView().refresh();
            this.ownerCt.ownerCt.normalGrid.getView().refresh();
          }
        },

        specialkey : function(field, e, t) {
          if (e.keyCode === e.ESC)
            field.reset();
        }
      }
    };

    return filterTemplCfg;
  },

  /**
   * Filter types
   * 
   * @param modelFieldname
   * @param resourceStore
   * @param width
   * @returns {filterTemplCfg}
   */
  getComboFilterCfg : function getComboFilterCfg(modelFieldname, resourceStore, width) {

    var storeType = Ext.create('Ext.data.Store', {
      fields : [ 'type', 'name', 'icon' ],
      data : [ {
        'type' : '',
        'name' : 'Alle Anzeigen',
      }, {
        'type' : 'K',
        'name' : 'Kataloge',
        'icon' : 'sammlung'
      }, {
        'type' : 'M',
        'name' : 'Messe',
        'icon' : 'handshake'
      }, {
        'type' : 'E',
        'name' : 'Epim',
        'icon' : 'epim'
      } ]
    });

    var filterTemplCfg = {

      xtype : 'combobox',
      width : width,
      tooltip : 'Filter',
      store : storeType,
      displayField : 'type',
      trigger1Cls : 'xty_menu-trigger',
      trigger2Cls : 'x-form-menu-trigger',
      // editable: false,
      emptyText : '',
      fieldStyle : 'border-right: 0px; visibility:hidden;',

      // displayTpl: Ext.create('Ext.XTemplate', [
      // '<tpl for=".">',
      // '<img src="../img/icons/{icon}_16.png" align="left" />',
      // '</tpl>',
      //		    
      // ]),
      // onTrigger2Click: function() {
      // this.getPicker().show();
      // //this.showList();
      // },

      listConfig : {
        minWidth : 100,
        getInnerTpl : function(displayField) {
          var tpl = '<div>' + '<img src="../img/icons/{icon}_16.png" align="left">&nbsp;' + '{name}' + '</div>';
          return tpl;
          // return '<img src="../img/icons/{icon}_16.png" style="position: relative; top: 3px"/> {' + displayField +
          // '}';
        }
      },
      // fieldSubTpl: [
      // '<div class="{hiddenDataCls}" role="presentation"></div>',
      // '<div id="{id}" type="{type}" ',
      // '<tpl if="size">size="{size}" </tpl>',
      // '<tpl if="tabIdx">tabIndex="{tabIdx}" </tpl>',
      // 'class="{fieldCls} {typeCls}" autocomplete="off"></div>',
      // '<div id="{cmpId}-triggerWrap" class="{triggerWrapCls}" role="presentation">',
      // '{triggerEl}',
      // '<div class="{clearCls}" role="presentation"></div>',
      // '</div>',
      // {
      // compiled: true,
      // disableFormats: true
      // }
      // ],

      // triggerCls : 'x-form-clear-trigger',
      // onTriggerClick : function() {
      // this.setValue('');
      // },
      listeners : {
        /*
         * render : function(c) { Ext.QuickTips.getQuickTip().register({ target: c, title: 'test', text: 'test text' });
         * c },
         */
        focus : function() {
          this.addCls('xty_menu-trigger-focus');
        },

        blur : function() {
          this.removeCls('xty_menu-trigger-focus');
        },

        change : function(field, newValue, oldValue) {
          if (newValue == 'K') {
            if (oldValue) {
              if (oldValue == 'M') {
                this.removeCls('xty_menu-trigger-messe');
              } else if (oldValue == 'E') {
                this.removeCls('xty_menu-trigger-epim');
              }
            }
            this.addCls('xty_menu-trigger-kataloge');
          } else if (newValue == 'E') {
            if (oldValue) {
              if (oldValue == 'M') {
                this.removeCls('xty_menu-trigger-messe');
              } else if (oldValue == 'K') {
                this.removeCls('xty_menu-trigger-kataloge');
              }
            }
            this.addCls('xty_menu-trigger-epim');
          } else if (newValue == 'M') {
            if (oldValue) {
              if (oldValue == 'E') {
                this.removeCls('xty_menu-trigger-epim');
              } else if (oldValue == 'K') {
                this.removeCls('xty_menu-trigger-kataloge');
              }
            }
            this.addCls('xty_menu-trigger-messe');
          } else {
            if (oldValue) {
              if (oldValue == 'M') {
                this.removeCls('xty_menu-trigger-messe');
              } else if (oldValue == 'K') {
                this.removeCls('xty_menu-trigger-kataloge');
              } else if (oldValue == 'E') {
                this.removeCls('xty_menu-trigger-epim');
              }
            }
          }
          if (newValue) {
            if (resourceStore.nodeStore.data.items[8]) {
              resourceStore.nodeStore.data.items[8].expand();
              resourceStore.nodeStore.data.items[8].expandChildren();
            }
            resourceStore.nodeStore.filterBy(function(record, id) {
              var str = record.get(modelFieldname).toUpperCase();
              if (str.search(newValue.toUpperCase()) !== -1) {
                return true;
              }
              return false;
            });

            this.ownerCt.ownerCt.lockedGrid.getView().refresh();
            this.ownerCt.ownerCt.normalGrid.getView().refresh();
            // var res = extVia.campaigns.scheduler.view.searchFilter(newValue, resourceStore.nodeStore.data);

          } else {
            resourceStore.nodeStore.clearFilter();
            this.ownerCt.ownerCt.lockedGrid.getView().refresh();
            this.ownerCt.ownerCt.normalGrid.getView().refresh();
          }
        },

        specialkey : function(field, e, t) {
          if (e.keyCode === e.ESC)
            field.reset();
        }
      }
    };

    return filterTemplCfg;
  },

  /**
   * 
   * @returns schedulerTree
   */
  getSchedulerTree : function getSchedulerTree() {

    Sch.preset.Manager.registerPreset("yearMonthWeek", extVia.campaigns.scheduler.control.getYearMonthWeek());

    var eventStore = extVia.campaigns.scheduler.store.getEventStore();
    var resourceStore = extVia.campaigns.scheduler.store.getResourceStore();
    var startDate = extVia.campaigns.scheduler.control.generateStartDate(); // new Date(2012, 8, 1) zero-based month, number!!
    var endDate = extVia.campaigns.scheduler.control.generateEndDate(6);

    var newWidth = Ext.getCmp('panel_mC').getWidth();
    var newHeight = extVia.regApp.myRaster.getCenter().getHeight();
//    var newWidth = panelmC.getWidth();
//    var newHeight = panelmC.getHeight() - extVia.constants.raster.pgToolbarEditHeight + 45;
    var schedulerTree = null;
    
    schedulerTree = Ext.create('Sch.panel.SchedulerTree',
        {
          // id : 'schedulerTreeID',
          // loadMask : true,
          width : newWidth - 4,
          height : newHeight - 133,
          border : false,
          rowHeight : 40,
          eventStore : eventStore,
          resourceStore : resourceStore,
          // viewPreset : 'yearMonthWeek', // dayAndWeek yearMonthWeek weekAndDayLetter
          viewPreset : 'weekAndMonth',
          startDate : startDate,
          endDate : endDate,
          // selType : 'cellmodel',
          columnLines : true,
          rowLines : true,
          multiSelect : true,

          // tooltipTpl : new Ext.XTemplate('{[Ext.Date.format(values.StartDate, "D:M")]} - {Name}').compile(),
          // allowOverlap: false,
          // dynamicRowHeight : false,
          // enableEventDragDrop : false,
          // constrainDragToResource : false,
          // enableDragCreation: false,

          eventRenderer : function(campaign, resource, meta, row) {
            return extVia.campaigns.scheduler.control.getEventRenderer(campaign, resource, meta, row);
          },

          dndValidatorFn : function(dragEventRecords, targetRowRecord, newStartDate, duration, e) {
            return extVia.campaigns.scheduler.control.getDndValidatorFn(dragEventRecords, targetRowRecord,
                newStartDate, duration, e);
          },

          resizeValidatorFn : function(resourceRecord, eventRecord, startDate, endDate) {
            return extVia.campaigns.scheduler.control.getResizeValidatorFn(resourceRecord, eventRecord, startDate,
                endDate);
          },

          listeners : extVia.campaigns.scheduler.control.getSchedulerListeners(),

          onEventCreated : function(newEvent) {
            // newEvent.set('Cls', 'normalEvent');
            var eStore = this.getEventStore();

            // Sortieren des Stores; ist notwendig
            // f�r dndValidatorFn & resizeValidatorFn!
            eStore.sort('StartDate', 'ASC');

          },

          createValidatorFn : function(newEvent, startDate, endDate) {
            return extVia.campaigns.scheduler.control.getCreateValidatorFn(newEvent, startDate, endDate);
          },

          tbar : [
                  
            this.getFilterCfg('Name', resourceStore, 162),
            
            this.getComboFilterCfg('Type', resourceStore, 34), {
            id : 'invisibleTab4SchTree',
            disabled : true,
            width : 410
          }, {
            iconCls : 'icon-previous',
            scale : 'small',
            handler : function() {
              schedulerTree.shiftPrevious();
            }
          }, '->', {
            iconCls : 'icon-next',
            scale : 'small',
            margin : '0 10 0 0',
            handler : function() {
              schedulerTree.shiftNext();
            }
          } ],

          // Experimental
          layout : {
            type : 'hbox',
            align : 'stretch'
          },

          plugins : [ this.getCellEditingCfg(),

          Ext.create("Sch.plugin.Lines", {
            innerTpl : '<span class="line-text">{Text}</span>',
            store : extVia.campaigns.scheduler.store.getLineStore()
          }) ],

          // viewConfig : {
          // dynamicRowHeight : false,
          // // managedEventSizing : true,
          // getRowClass : function(r) {
          // // if (r.get('Id') === 3 || r.parentNode.get('Id') === 3) {
          // // return 'some-grouping-class';
          // // }
          // // if (r.get('Id') === 9 || r.parentNode.get('Id') === 9) {
          // // return 'some-other-grouping-class';
          // // }
          // }
          // },

          // Experimental
          lockedGridConfig : {
            width : 605,
            resizeHandles : 'e',
            resizable : {
              pinned : true
            }
          },

          lockedViewConfig : {
            plugins : {
              ptype : 'treeviewdragdrop',
              containerScroll : true
            }
          },

          // Experimental
          schedulerConfig : {
            bodyStyle : 'border:0px;',
            scroll : true
          // ,collapsible : true
          // ,flex : 1
          },

          columns : [{
                       xtype : 'treecolumn',
                       text : 'Name',
                       width : 170,
                       sortable : true,
                       dataIndex : 'Name'
                     },
                     {
                       text : 'Typ',
                       width : 35,
                       sortable : false,
                       dataIndex : 'Type',
                       align : 'center',
                       editor : 'textfield',
                       renderer : function(value, meta, record) {
                         if (value == 'M') {
                           meta.tdCls = 'xty_messe';
                         } else if (value == 'K') {
                           meta.tdCls = 'xty_kataloge';
                         } else if (value == 'E') {
                           meta.tdCls = 'xty_epim';
                         } else {
                           return value;
                         }
                       }
                     },
                     {
                       text : 'Prio',
                       width : 35,
                       sortable : false,
                       dataIndex : 'Prio',
                       align : 'center',
                       editor : 'textfield'
                     },
                     {
                       text : 'Fertigstellung',
                       width : 75,
                       sortable : true,
                       dataIndex : 'FGrad',
                       align : 'center',
                       editor : 'textfield',
                       renderer : function(value, meta, record) {

                         var event = extVia.campaigns.statistics.control.getEvent(record, record.data.Id);
                         var efficiency = 0;
                         if (event) {
                           efficiency = extVia.campaigns.statistics.control.getEfficiency(event, record.data.FGrad);
                           if (efficiency > 3) {
                             efficiency = 3;
                           }
                         }

                         var rightMargin = '&nbsp;&nbsp;&nbsp;&nbsp;'; //&nbsp;&nbsp;
                         if (efficiency >= 0 && value != '') {
                           if (efficiency >= 1 && efficiency < 2) {
                             meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-effic_L';
                             meta.tdAttr = 'data-qtip="' + 'Effizienz ist <b>' + efficiency
                                           + '</b><br /> Effizienz = verstrichene Zeit / fert. Grad' + '"';
                             return value + '%' + rightMargin;
                           } else if (efficiency >= 2) {
                             meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-effic_L';
                             meta.tdAttr = 'data-qtip="' + 'Effizienz ist <b>' + efficiency
                                           + '</b><br /> Effizienz = verstrichene Zeit / fert. Grad' + '"';
                             return value + '%' + rightMargin;
                           } else if (efficiency >= 0.8 & efficiency < 1) {
                             meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-effic_S';
                             meta.tdAttr = 'data-qtip="' + 'Effizienz ist <b>' + efficiency
                                           + '</b><br /> Effizienz = verstrichene Zeit / fert. Grad' + '"';
                             return value + '%' + rightMargin;
                           } else {
                             meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-effic_XS';
                             meta.tdAttr = 'data-qtip="' + 'Effizienz ist <b>' + efficiency
                                           + '</b><br /> Effizienz = verstrichene Zeit / fert. Grad' + '"';
                             return value + '%' + rightMargin;
                           }
                         } else if (value != '') {
                           return value + '%';
                           
                         } else if (value === '') {
                           return '';
                         }
                       }
                     },
                     {
                       text : 'Laufzeit',
                       width : 80,
                       hidden : true,
                       sortable : true,
                       dataIndex : 'FGrad',
                       align : 'center',
                       // editor : 'textfield',
                       renderer : function(value, meta, record) {
                         var event = extVia.campaigns.statistics.control.getEvent(record, record.data.Id);
                         if (event) {
                           return extVia.campaigns.scheduler.control.getElapsedTime(event);
                         } else {
                           return '';
                         }

                       }
                     },
                     {
                       text : 'Dauer',
                       width : 60,
                       sortable : true,
                       dataIndex : 'FGrad',
                       align : 'center',
                       editor : 'textfield',
                       renderer : function(value, meta, record) {
                         var event = extVia.campaigns.statistics.control.getEvent(record, record.data.Id);
                         if (event) {
                           return extVia.campaigns.statistics.control.getDuration(event);
                         } else {
                           return '';
                         }

                       }
                     },
                     {
                       text : 'Budget: Ist',
                       width : 75,
                       sortable : true,
                       dataIndex : 'BudgetI',
                       align : 'center',
                       editor : 'textfield',
                       // tdCls: 'xty_iconSuccess',
                       renderer : function(value, meta, record) {
                         if (value != '') {
                           var sum;
                           if (record.data.children) {
                             sum = 0;
                             for ( var i = 0; i < record.data.children.length; i++) {
                               sum = sum + parseInt(record.data.children[i].BudgetI);
                             }

                             var rightMargin = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';

                             if (sum < parseInt(record.data.BudgetI)) {
                               var differenz = parseInt(record.data.BudgetI) - sum;
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-Success';
                               meta.tdAttr = 'data-qtip="'
                                             + 'aus &Sigma; Subkampagnen<br /> bleibt ein Restbudget von: <b>'
                                             + differenz + ' T. &euro;</b>' + '"';
                               return value + ' T.' + rightMargin;
                             } else if (sum > parseInt(record.data.BudgetI)) {
                               var differenz = sum - parseInt(record.data.BudgetI);
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-ErrorValidate';
                               meta.tdAttr = 'data-qtip="'
                                             + '&Sigma; Subkampagnen<br /> &uuml;berschreitet Budget um : <b>'
                                             + differenz + ' T. &euro;</b>' + '"';
                               return value + ' T.' + rightMargin;
                             } else {
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-ChangeIt';
                               meta.tdAttr = 'data-qtip="'
                                             + 'aus &Sigma; Subkampagnen<br /> bleibt <b>kein</b> Restbudget' + '"';
                               return value + ' T.' + rightMargin;
                             }
                           } else {
                             return value + ' T. &euro;';
                           }
                         }

                       }
                     },
                     {
                       text : 'Budget: Soll',
                       width : 75,
                       sortable : true,
                       dataIndex : 'BudgetS',
                       align : 'center',
                       editor : 'textfield',
                       // tdCls: 'xty_icon_cell',
                       renderer : function(value, meta, record) {
                         if (value != '') {
                           var sum;
                           if (record.data.children) {
                             sum = 0;
                             for ( var i = 0; i < record.data.children.length; i++) {
                               sum = sum + parseInt(record.data.children[i].BudgetS);
                             }
                             var rightMargin = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';

                             if (sum < parseInt(record.data.BudgetS)) {
                               var differenz = parseInt(record.data.BudgetS) - sum;
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-Success';
                               meta.tdAttr = 'data-qtip="'
                                             + 'aus &Sigma; Subkampagnen<br /> bleibt ein Restbudget von: <b>'
                                             + differenz + ' T. &euro;</b>' + '"';
                               return value + ' T.' + rightMargin;
                             } else if (sum > parseInt(record.data.BudgetS)) {
                               var differenz = sum - parseInt(record.data.BudgetS);
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-ErrorValidate';
                               meta.tdAttr = 'data-qtip="'
                                             + '&Sigma; Subkampagnen<br /> &uuml;berschreitet Budget um : <b>'
                                             + differenz + ' T. &euro;</b>' + '"';
                               return value + ' T.' + rightMargin;
                             } else {
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-ChangeIt';
                               meta.tdAttr = 'data-qtip="'
                                             + 'aus &Sigma; Subkampagnen<br /> bleibt <b>kein</b> Restbudget' + '"';
                               return value + ' T.' + rightMargin;
                             }
                           } else {
                             return value + ' T. &euro;';
                           }
                         }

                         // if(value!=''){
                         // if(record.data.children){
                         // return value + ' T.'
                         // }else{
                         // return value + ' T. Euro';
                         // }
                         // }
                       }
                     },
                     {
                       text : 'Prognose',
                       width : 75,
                       sortable : true,
                       dataIndex : 'BudgetP',
                       align : 'center',
                       editor : 'textfield',
                       // tdCls: 'xty_icon_cell_P',
                       renderer : function(value, meta, record) {
                         if (value != '') {
                           var sum;
                           if (record.data.children) {
                             sum = 0;
                             for ( var i = 0; i < record.data.children.length; i++) {
                               sum = sum + parseInt(record.data.children[i].BudgetP);
                             }
                             var rightMargin = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';

                             if (sum < parseInt(record.data.BudgetP)) {
                               var differenz = parseInt(record.data.BudgetP) - sum;
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-Success';
                               meta.tdAttr = 'data-qtip="'
                                             + 'aus &Sigma; Subkampagnen<br /> bleibt ein Restbudget von: <b>'
                                             + differenz + ' T. &euro;</b>' + '"';
                               return value + ' T.' + rightMargin;
                             } else if (sum > parseInt(record.data.BudgetP)) {
                               var differenz = sum - parseInt(record.data.BudgetP);
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-ErrorValidate';
                               meta.tdAttr = 'data-qtip="'
                                             + '&Sigma; Subkampagnen<br /> &uuml;berschreitet Budget um : <b>'
                                             + differenz + ' T. &euro;</b>' + '"';
                               return value + ' T.' + rightMargin;
                             } else {
                               meta.tdCls = 'xty_icon-gridcell-withEditor xty_icon-gridcell-withEditor-ChangeIt';
                               meta.tdAttr = 'data-qtip="'
                                             + 'aus &Sigma; Subkampagnen<br /> bleibt <b>kein</b> Restbudget' + '"';
                               return value + ' T.' + rightMargin;
                             }
                           } else {
                             return value + ' T. &euro;';
                           }
                         }
                       }
                     } ],
                     
          viewConfig : {
            dynamicRowHeight : false
          // getRowClass: function(record, index) {
          // var event = extVia.campaigns.statistics.control.getEvent(record, record.data.Id);
          // var efficiency;
          // if (event){
          // efficiency = extVia.campaigns.statistics.control.getEfficiency(event, record.data.FGrad);
          // if (efficiency>3){
          // efficiency = 3;
          // }
          // };
          // if(efficiency>=0){
          // if (efficiency >= 1 & efficiency < 2) {
          // return 'xty_effic_m';
          // } else if (efficiency >= 2) {
          // return 'xty_effic_l';
          // }else if (efficiency >= 0.8 & efficiency < 1) {
          // return 'xty_effic_s';
          // }else {
          // return 'xty_effic_xs';
          // }
          // };
          // }
          // getRowClass: function(record, index) {
          // var sum;
          // if(record.data.BudgetI!=''){
          // if(record.data.children){
          // sum = 0;
          // for(var i=0; i<record.data.children.length; i++){
          // sum = sum + parseInt(record.data.children[i].BudgetI);
          // }
          // if(sum < record.data.BudgetI){
          // return "xty_iconSuccess";
          //	
          // }else if(sum > record.data.BudgetI){
          // return "xty_iconErrorValidate";
          // }else{
          // return "xty_iconChangeIt";
          // }
          // }
          // }
          // }
          }
        });

    return schedulerTree;
  }

};

// init Object as singleton
extVia.campaigns.scheduler.view = new extVia.campaigns.scheduler.view();

/*
 * 
 * $Revision: 1.38 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/07 10:23:33 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */