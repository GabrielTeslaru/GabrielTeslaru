Ext.namespace('extVia.campaigns.scheduler.main');
/**
 * @class extVia.campaigns.scheduler.main Provides ui + data + models + stores + views<br>
 *        May run as subApp
 * 
 * @author Simon Lederer, Viamedici Software GmbH
 * @version $Date: 2012/10/29 13:25:59 $ $Revision: 1.2 $
 */
extVia.campaigns.scheduler.main = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.scheduler.main",
    name : "extVia.campaigns.scheduler.main"
  });
};

extVia.campaigns.scheduler.main.prototype = {

  /**
   * 
   * @param some
   * @returns thing
   */
  getSomeThing : function getSomeThing(some) {
    var thing = {};
    return thing;
  }

};

// init Object as singleton
extVia.campaigns.scheduler.main = new extVia.campaigns.scheduler.main();

/*
 * 
 * $Revision: 1.2 $ $Modtime: 10.10.12 12:39 $ $Date: 2012/10/29 13:25:59 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */