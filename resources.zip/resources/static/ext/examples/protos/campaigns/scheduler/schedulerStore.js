Ext.namespace('extVia.campaigns.scheduler.store');

extVia.campaigns.scheduler.store = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.scheduler.store",
    name : "extVia.campaigns.scheduler.store"
  });
};

extVia.campaigns.scheduler.store.prototype = {

  getPublicationStore : function getPublicationStore() {

    var model = Ext.define('Publication', {
      extend : 'Ext.data.Model',
      fields : [ {
        type : 'string',
        name : 'shortcut'
      }, {
        type : 'string',
        name : 'name'
      }, {
        type : 'string',
        name : 'dscr'
      }, {
        type : 'string',
        name : 'year'
      }, {
        type : 'string',
        name : 'epobId'
      } ],
    });
    var data = [ {
      name : 'fallcatlogue',
      shortcut : 'fall',
      dscr : 'Herbstkatalog',
      epobId : '1',
      year : '2012'
    }, {
      name : 'mess',
      shortcut : 'mess',
      dscr : 'Messe',
      epobId : '2',
      year : '2013'
    }, {
      name : 'chapter 5',
      shortcut : 'chp5',
      dscr : 'Kapitel 5',
      epobId : '3',
      year : '2013'
    }, {
      name : 'Taschen',
      shortcut : 'tsch',
      dscr : 'Taschenkatalog',
      epobId : '4',
      year : '2013'
    }, {
      name : 'overviewNews',
      shortcut : 'news',
      dscr : '\u00dcbersicht Neuheiten',
      epobId : '5',
      year : '2012'
    } ];

    var store = Ext.create('Ext.data.Store', {
      model : model,
      storeId : 'publicationStoreId',
      data : data
    });

    return store;
  },


  testStore : function testStore() {

    Ext.define('User', {
      extend : 'Ext.data.Model',
      fields : [ {
        name : 'title',
        type : 'string'
      }, {
        name : 'postid',
        type : 'int'
      }, {
        name : 'username',
        type : 'string'
      }, {
        name : 'lastpost',
        type : 'int'
      }, {
        name : 'excerpt',
        type : 'string'
      }, {
        name : 'userid',
        type : 'int'
      }, {
        name : 'dateline',
        type : 'int'
      }, {
        name : 'forumtitle',
        type : 'string'
      }, {
        name : 'forumid',
        type : 'int'
      }, {
        name : 'replycount',
        type : 'int'
      }, {
        name : 'lastposter',
        type : 'string'
      } ]
    });

    var store = Ext.create('Ext.data.Store', {
      model : 'User',
      proxy : {
        type : 'ajax',
        url : 'scheduler/data.jsp',
        reader : {
          type : 'json',
          root : 'topics',
          totalProperty : 'totalCount',
          idProperty : 'threadid'
        }
      }
    });

    store.load();

    return store;
  },

  /**
   * 
   */
  getDummyData : function getDummyData() {

    var dummyData = {
      "Id" : 0,
      "children" : [ {
        "Id" : 1,
        "Name" : "Metabo",
        "iconCls" : "metabo",
        "expanded" : true,
        "children" : [ {
          "Id" : 2,
          "Name" : "2013",
          "iconCls" : "sch-terminal",
          "expanded" : true,
          "FGrad" : "80",
          "BudgetS" : "500",
          "BudgetI" : "300",
          "BudgetP" : "540",
          "children" : [ {
            "Id" : 3,
            "Name" : "Printkataloge",
            "iconCls" : "sch-gates-bundle",
            "expanded" : true,
            "FGrad" : "60",
            "Type" : "K",
            "BudgetS" : "250",
            "BudgetI" : "150",
            "BudgetP" : "240",
            "children" : [ {
              "Id" : 4,
              "Name" : "Hauptkatalog",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "A",
              "Type" : "K",
              "FGrad" : "15",
              "BudgetS" : "100",
              "BudgetI" : "50",
              "BudgetP" : "90"
            }, {
              "Id" : 5,
              "Name" : "HMI Katalog",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "B",
              "Type" : "K",
              "FGrad" : "40",
              "BudgetS" : "150",
              "BudgetI" : "90",
              "BudgetP" : "150"
            } ]
          }, {
            "Id" : 6,
            "Name" : "Messen",
            "iconCls" : "sch-gates-bundle",
            "expanded" : true,
            "FGrad" : "55",
            "BudgetS" : "250",
            "BudgetI" : "150",
            "BudgetP" : "300",
            "Type" : "M",
            "children" : [ {
              "Id" : 7,
              "Name" : "HMI",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "A",
              "Type" : "M",
              "FGrad" : "30",
              "BudgetS" : "110",
              "BudgetI" : "60",
              "BudgetP" : "130"
            }, {
              "Id" : 8,
              "Name" : "bauma",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "B",
              "Type" : "M",
              "FGrad" : "65",
              "BudgetS" : "200",
              "BudgetI" : "100",
              "BudgetP" : "170"
            } ]
          }, {
            "Id" : 16,
            "Name" : "EPIM",
            "expanded" : true,
            "BudgetS" : "50",
            "BudgetI" : "40",
            "BudgetP" : "50",
            "Type" : "E",
            "children" : [ {
              "Id" : 17,
              "Name" : "Asiat. Sprachen int.",
              "iconCls" : "sch-gate",
              "leaf" : true,
              "FGrad" : "4",
              "BudgetS" : "15",
              "BudgetI" : "10",
              "BudgetP" : "12",
              "Type" : "E"
            }, {
              "Id" : 18,
              "Name" : "SAP-Integration",
              "iconCls" : "sch-gate",
              "leaf" : true,
              "FGrad" : "0",
              "BudgetS" : "10",
              "BudgetI" : "8",
              "BudgetP" : "9",
              "Type" : "E"
            }, {
              "Id" : 19,
              "Name" : "MAM-Anbindung",
              "iconCls" : "sch-gate",
              "leaf" : true,
              "FGrad" : "10",
              "BudgetS" : "15",
              "BudgetI" : "10",
              "BudgetP" : "15",
              "Type" : "E"
            }, {
              "Id" : 20,
              "Name" : "Rollout Nordic",
              "iconCls" : "sch-gate",
              "leaf" : true,
              "FGrad" : "0",
              "BudgetS" : "10",
              "BudgetI" : "12",
              "BudgetP" : "14",
              "Type" : "E"
            } ]
          } ]
        }, {
          "Id" : 9,
          "Name" : "2012",
          "iconCls" : "sch-terminal",
          "FGrad" : "90",
          "BudgetS" : "700",
          "BudgetI" : "800",
          "BudgetP" : "850",
          "children" : [ {
            "Id" : 10,
            "Name" : "Printkataloge",
            "iconCls" : "sch-gates-bundle",
            "FGrad" : "40",
            "BudgetS" : "250",
            "BudgetI" : "150",
            "Type" : "M",
            "children" : [ {
              "Id" : 11,
              "Name" : "Hauptkatalog",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "A",
              "Type" : "K",
              "FGrad" : "20",
              "BudgetS" : "100",
              "BudgetI" : "50"
            }, {
              "Id" : 12,
              "Name" : "HMI Katalog",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "B",
              "Type" : "K",
              "FGrad" : "40",
              "BudgetS" : "150",
              "BudgetI" : "90"
            } ]
          }, {
            "Id" : 13,
            "Name" : "Messen",
            "iconCls" : "sch-gates-bundle",
            "FGrad" : "40",
            "BudgetS" : "150",
            "BudgetI" : "90",
            "Type" : "K",
            "children" : [ {
              "Id" : 14,
              "Name" : "HMI",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "A",
              "Type" : "M",
              "FGrad" : "30",
              "BudgetS" : "110",
              "BudgetI" : "60"
            }, {
              "Id" : 15,
              "Name" : "Baumesse",
              "leaf" : true,
              "iconCls" : "sch-gate",
              "Prio" : "B",
              "Type" : "M",
              "FGrad" : "65",
              "BudgetS" : "200",
              "BudgetI" : "100"
            } ]
          } ]
        } ]
      }, ]
    };

    return dummyData;

  },

  /*
   * Store for Campaigns
   */
  getResourceStore : function getResourceStore() {

    if (localStorage.getItem("LoadetResource") == null) {
      localStorage.StoreJSBlob = JSON.stringify(extVia.campaigns.scheduler.store.getDummyData());
      localStorage.setItem("LoadetResource", "1");
    }
    ;

    // store-model
    Ext.define('Campaign', {
      extend : 'Sch.model.Resource',
      fields : [ 'Type', 'Prio', 'FGrad', 'BudgetS', 'BudgetI', 'BudgetP', 'Description' ],
    /*
     * proxy : { type: 'localstorage', id : 'StoreJSBlob' }
     */
    });

    // store
    var resourceStore = Ext.create('Sch.data.ResourceTreeStore', {
      model : 'Campaign',
      root : JSON.parse(localStorage.StoreJSBlob),
      autoLoad : true

    });
    var resourceStore_ = Ext.create('Sch.data.ResourceTreeStore', {
      model : 'Campaign',
      proxy : {
        type : 'ajax',
        url : 'scheduler/dummy-data.json'
      },
      folderSort : true,
      listeners : {
        load : function(thisStore, rootnode, records, successful, eOpts) {
        }
      }
    });

    return resourceStore;
  },

  getLineStore : function getLineStore() {

    Ext.define('Line', {
      extend : 'Ext.data.Model',
      fields : [ 'Date', 'Text', 'Cls' ]
    });

    var lineStore = Ext.create('Ext.data.JsonStore', {
      model : 'Line',
      data : [ {
        Date : new Date(),
        Text : 'Heute',
        Cls : 'line'
      } ]
    });

    return lineStore;

  },

  getData : function getData(startDate) {

    var data = [ {
      ResourceId : 17,
      Name : "Asiat. Sprachen int.",
      StartDate : startDate,
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 20),
      Style : "00CCFF",
      Draggable : true,
      Type : 'Event',
      Dscr : '',
      EventId : 0,
      Deleted : 0
    }, {
      ResourceId : 18,
      Name : 'SAP-Integration',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 2),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 30),
      Style : "808080",
      Type : 'Event',
      Dscr : '',
      EventId : 2,
      Deleted : 0
    }, {
      ResourceId : 18,
      Name : 'MS2',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 10),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 10),
      Resizable : false,
      Style : "blue",
      Type : 'Milestone',
      Dscr : 'Text',
      EventId : 3,
      Deleted : 0
    }, {
      ResourceId : 20,
      Name : 'Rollout Nordic',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 7),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 18),
      Style : 'CCCC00',
      Type : 'Event',
      Dscr : '',
      EventId : 4,
      Deleted : 0
    }, {
      ResourceId : 20,
      Name : 'MS3',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 18),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 18),
      Resizable : false,
      Style : "purple",
      Type : 'Milestone',
      Dscr : 'Text',
      EventId : 5,
      Deleted : 0
    }, {
      ResourceId : 4,
      Name : 'Hauptkatalog',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, -5),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 30),
      Style : "669900",
      Type : 'Event',
      Dscr : '',
      EventId : 6,
      Deleted : 0
    }, {
      ResourceId : 4,
      Name : 'MS1',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 15),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 15),
      Resizable : false,
      Style : "red",
      Type : 'Milestone',
      Dscr : 'Text',
      EventId : 1,
      Deleted : 0
    }, {
      ResourceId : 5,
      Name : 'HMI Katalog',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 2),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 17),
      Type : 'Event',
      Dscr : '',
      EventId : 7,
      Deleted : 0
    }, {
      ResourceId : 19,
      Name : 'MAM-Anbindung',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 0),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 25),
      Type : 'Event',
      Dscr : '',
      EventId : 8,
      Deleted : 0
    }, {
      ResourceId : 7,
      Name : 'HMI',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, -5), // "2013-04-08 10:00",
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 20), // "2013-04-12 10:00",
      Style : 'E60000',
      Type : 'Event',
      Dscr : '',
      EventId : 9,
      Deleted : 0
    }, {
      ResourceId : 8,
      Name : 'bauma',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, -2), // "2013-04-15 10:00",
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 10), // "2013-04-21 10:00",
      Style : '006BB2',
      Type : 'Event',
      Dscr : '',
      EventId : 10,
      Deleted : 0
    },
    // {
    // ResourceId : 9,
    // Name : '2011',
    // StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 15),
    // EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 30),
    // Type : 'Event',
    // Dscr : '',
    // EventId : 11,
    // Deleted : 0
    // }, {
    // ResourceId : 10,
    // Name : 'Printkataloge',
    // StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 3),
    // EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 21),
    // Type : 'Event',
    // Dscr : '',
    // EventId : 12,
    // Deleted : 0
    // },
    {
      ResourceId : 11,
      Name : 'Hauptkatalog',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 0),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 30),
      Style : "669900",
      Type : 'Event',
      Dscr : '',
      EventId : 13,
      Deleted : 0
    }, {
      ResourceId : 12,
      Name : 'HMI Katalog',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 1),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 16),
      Type : 'Event',
      Dscr : '',
      EventId : 14,
      Deleted : 0
    },
    // {
    // ResourceId : 13,
    // Name : 'Messen',
    // StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 0),
    // EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 17),
    // Type : 'Event',
    // Dscr : '',
    // EventId : 15,
    // Deleted : 0
    // },
    {
      ResourceId : 14,
      Name : 'HMI',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 20),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 35),
      Type : 'Event',
      Dscr : '',
      EventId : 16,
      Deleted : 0
    }, {
      ResourceId : 15,
      Name : 'Baumesse',
      StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 9),
      EndDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 22),
      Deletable : false,
      Type : 'Event',
      Dscr : '',
      EventId : 17,
      Deleted : 0
    } ];

    return data;

  },

  /**
   * Store for Projects
   */
  getEventStore : function getEventStore() {

    // store-model
    var customizableFields = [ {
      name : 'Type',
      type : 'string'
    }, {
      name : 'Style',
      type : 'string'
    }, {
      name : 'Dscr',
      type : 'string'
    }, {
      name : 'EventId',
      type : 'number'
    }, {
      name : 'Deleted',
      type : 'number'
    } ];

    // store-model
    Ext.define('BaseModel', {
      extend : 'Sch.model.Event',
      customizableFields : customizableFields,
      proxy : {
        type : 'localstorage',
        id : 'storageId'
      }
    // ,fields : []
    });

    var startDate = extVia.campaigns.scheduler.control.generateStartDate();
    // var endDate = Sch.util.Date.add(startDate, Sch.util.Date.DAY, 10);

    var data = extVia.campaigns.scheduler.store.getData(startDate);

    // store-model
    var eventStore = Ext.create('Sch.data.EventStore', {
      // id : 'eventStoreId',
      model : 'BaseModel',
      autoLoad : true
    });
    eventStore.load();
    if (localStorage.getItem("Loadet") == null) {
      for ( var i = 0; i < data.length; i++) {
        var contains = false;
        // alert(eventStore.getCount());
        for ( var j = 0; j < eventStore.getCount(); j++) {
          if (data[i].EventId == eventStore.getAt(j).get('EventId')) {
            // alert('gefunden '+data[i].Name+'store '+eventStore.getAt(j).get('Name'));
            contains = true;
            break;
          }
        }
        if (contains == false & data[i].Deleted == 0) {
          // alert('Nicht gefunden '+data[i].Name)
          eventStore.add(data[i]);
          localStorage.setItem("Loadet", "1");
          eventStore.sync();
        }
      }
    }
    ;

    // eventStore.sync();
    return eventStore;
  }

};

// init Object as singleton
extVia.campaigns.scheduler.store = new extVia.campaigns.scheduler.store();

/*
 * 
 * $Revision: 1.21 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/07 10:23:33 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */