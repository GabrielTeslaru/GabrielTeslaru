Ext.namespace('extVia.campaigns.statistics.control');
/**
 * @class extVia.campaigns.statistics.main Provides ui + data + models + stores + views<br>
 *        May run as subApp
 * 
 * @author Artur Taranyuk, Viamedici Software GmbH
 * @version $Date: 2013/05/06 17:07:49 $ $Revision: 1.27 $
 */
extVia.campaigns.statistics.control = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.statistics.control",
    name : "extVia.campaigns.statistics.control"
  });
};

extVia.campaigns.statistics.control.prototype = {

	showEvents : function showEvents(){//Details wieder einblenden
	  	
	  	var schTreeId = Ext.get('panel_mC').down('a').parent().id;
	   	var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
	   	var normalTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().normal;
	   	normalTree.items.items[0].show();
	   	normalTree.headerCt.show();
	  	for (var j=0; j<normalTree.items.items.length; j++){
		    	if(j!=0 && normalTree.items.items[j].getXType()=='panel'){
		    		normalTree.items.removeAt(j);
		    	}
		}
	  },
	  
	getEvent : function getEvent(record, id){
  
	  	var events = record.store.eventStore.getRange();
	  	for (var i = 0; i<events.length; i++){
	  		if(events[i].data.ResourceId == id & events[i].data.Type == "Event"){
	  			return events[i];
	  		}
	  	}
  
  	},
  
  getCountMilestone : function getCountMilestone(record, id){
  	var count=0;
  	var result='';
  	var events = record.store.eventStore.getRange();
  	for (var i = 0; i<events.length; i++){
  		if(events[i].data.ResourceId == id & events[i].data.Type == "Milestone"){
  			count++;
  		}
  	}
   if (count==1){
     result = count+" Meilenstein";
   }else{
     result = count+" Meilensteine";
   };
  	return result;
  
  },
  
   getCountEvents : function getCountEvents(record, id){
  	var count=0;
  	var result='';
  	var events = record.store.eventStore.getRange();
  	for (var i = 0; i<events.length; i++){
  		if(events[i].data.ResourceId == id & events[i].data.Type == "Event"){
  			count++;
  		}
  	}
   if (count==1){
     result = count+" Projekt";
   }else{
     result = count+" Projekte";
   };
  	return result;
  
  },
  
  getDuration : function getDuration(event){
  	var delta = Date.parse(event.data.EndDate) - Date.parse(event.data.StartDate);
  	var days = parseInt(delta / 86400000);
	  if(days==1){
   		days = days+" Tag";
   	}else{
   		days = days+" Tage";
   	};
   	
	  return days;
  },

 
// Rechnet Effizienz aus  
  getEfficiency : function getEfficiency(event , fgrad){
  	var date = new Date();	
  	var delta = Date.parse(event.data.EndDate) - Date.parse(event.data.StartDate);
	var days = parseInt(delta / 86400000);
	var deltaFGrad = Date.parse(date) - Date.parse(event.data.StartDate);
	var daysFgrad = parseInt(deltaFGrad / 86400000);
	if(daysFgrad==0){
		daysFgrad=1;
	}
	efficiency = parseInt(fgrad) / ((daysFgrad/days)*100);
	//alert(efficiency);
  	return efficiency;
  	
  },

  addListenerToTabs : function addListenerToTabs(schedulerTabPanel) {
  
/*listener Statistik tab mit einen Klick verhindert das der Tab gewechselt wird,
* sondern erweckt nur den Anschein
*/
    Ext.get(schedulerTabPanel.getTabBar().items.getAt(4).id).addListener("click", function(e, htmlButtEl) {
      e.stopEvent();
      schedulerTabPanel.getTabBar().items.get(3).deactivate();
      schedulerTabPanel.items.getAt(3).setDisabled(false);

      schedulerTabPanel.getTabBar().items.get(4).activate();
      var schTreeId = Ext.get('panel_mC').down('a').parent().id;
      var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
      var lockedTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().locked;
      var record = lockedTree.getSelectionModel().selected.items[0];
      var schedulerTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView();
      schedulerTree.panel.dockedItems.items[0].hide();
      extVia.campaigns.statistics.main.addChartsToPanel(record, schedulerTabPanel);
      //var schedulerTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView();
      //schedulerTree.panel.dockedItems.items[0].hide();
    }

    );

//listener Details tab verhindert das der Tab gewechselt wird, sondern erweckt nur den Anschein
    Ext.get(schedulerTabPanel.getTabBar().items.getAt(3).id)
        .addListener(
            "click",
            function(e, htmlButtEl) {
              e.stopEvent();
              schedulerTabPanel.getTabBar().items.get(4).deactivate();
              schedulerTabPanel.getTabBar().items.get(3).activate();
              extVia.campaigns.statistics.control.showEvents();
              var schedulerTree = Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt.getView();
              schedulerTree.panel.dockedItems.items[0].show();
              if (schedulerTree.locked.getWidth() == schedulerTree.locked.columns[0].getWidth()) {
                schedulerTree.locked.resizer.resizeTo(610);
              }
            });

//listener Statistik tab mit einen double Klick, ver�ndert die Breite des Baumes
    Ext.get(schedulerTabPanel.getTabBar().items.getAt(4).id)
        .addListener(
            "dblclick",
            function(e, htmlButtEl) {
              // alert('Static dbclick');
              var schedulerTree = Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt
                  .getView();
              if (schedulerTree.locked.getWidth() != schedulerTree.locked.columns[0].getWidth()) {    
              	schedulerTree.locked.resizer.resizeTo(schedulerTree.locked.columns[0].getWidth());
              	var tool = Ext.getCmp('mainToolbarId');
      			tool.getComponent('newProjektButton').setPosition(210);
      			tool.getComponent('editProjektButton').setPosition(260);
      			tool.getComponent('deleteProjektButton').setPosition(310);
              }
              else if (schedulerTree.locked.getWidth() == schedulerTree.locked.columns[0].getWidth()) {
                schedulerTree.locked.resizer.resizeTo(610);
                var tool = Ext.getCmp('mainToolbarId');
                tool.getComponent('newProjektButton').setPosition(610);
                tool.getComponent('editProjektButton').setPosition(660);
                tool.getComponent('deleteProjektButton').setPosition(710);
              }
            });

//listener �bersicht tab
    Ext.get(schedulerTabPanel.getTabBar().items.getAt(0).id).addListener("click", function(e, htmlButtEl) {
      schedulerTabPanel.getComponent('ProjektplanTabId').setDisabled(true);
      schedulerTabPanel.getComponent('DetailsTabId').setDisabled(false);
      var lockedTree = Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt.getView().locked;
      var record = lockedTree.getSelectionModel().selected.items[0];
      var width = lockedTree.width- 175;
     // alert(width)
      schedulerTabPanel.getTabBar().items.get(2).setWidth(width);
     // alert(schedulerTabPanel.getTabBar().items.get(2).getWidth())
      if(record){
      	schedulerTabPanel.getComponent('StatistikTabId').setDisabled(false);
      }
      
      var tool = Ext.getCmp('mainToolbarId');
	  tool.getComponent('mainSplitButton').hide();
	  tool.getComponent('editProjektButton').show();
	  tool.getComponent('newProjektButton').show();
	  tool.getComponent('deleteProjektButton').show();
    });
    

  var oldWidth = Ext.getCmp('panel_mC').getWidth();
  var oldHeight = Ext.getCmp('panel_mC').getHeight();
  
  Ext.EventManager.onWindowResize(
  function(width, height) {
//    var panelmC = Ext.getCmp('panel_mC');
	var ubersicht = Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt.getView();
  
    var newWidth = width - 50;
    var newHeight = height; // - extVia.constants.raster.pgToolbarEditHeight - 153;
    
    var tabPanId = Ext.getCmp('panel_mC').items.items[0].id;
    var schTreeId = Ext.getCmp(tabPanId).items.items[0].getActiveTab().items.items[0].id;
    var center = Ext.getCmp(schTreeId).getView();
    var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
   	var normalTree = Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt.getView().normal;
    //var statisticsId = Ext.getCmp(tabPanId).items.items[0].getActiveTab().items.items[0].items.items[1].items.items[1].id;
    //var statistics = Ext.getCmp(statisticsId);
    if(width > oldWidth || height > oldHeight){
      
      Ext.getCmp(tabPanId).setWidth(newWidth);
      Ext.getCmp(tabPanId).setHeight(newHeight-81);
      
      // 2 Toolbars von PageJobBar
      Ext.getCmp(tabPanId).dockedItems.items[0].items.items[0].setWidth(newWidth);
      Ext.getCmp(tabPanId).dockedItems.items[0].items.items[1].setWidth(newWidth);
      
      // TabPanel
      Ext.getCmp(tabPanId).items.items[0].setWidth(newWidth);
      Ext.getCmp(tabPanId).items.items[0].setHeight(newHeight-80);
      
      // SchedulerGrid
      Ext.getCmp(schTreeId).setWidth(newWidth);
      Ext.getCmp(schTreeId).setHeight(newHeight-80);
      
      newWidth = width - 48;
      newHeight = height - extVia.constants.raster.pgToolbarEditHeight - 153;
      ubersicht.panel.setHeight(newHeight);
      ubersicht.panel.setWidth(newWidth);
      center.panel.setHeight(newHeight);
      center.panel.setWidth(newWidth);
      center.panel.doComponentLayout();
//      var record = center.locked.getSelectionModel().selected.items[0];
//     if(schedulerTabPanel.getTabBar().items.getAt(4).active){
//      var statisticsId = Ext.getCmp(tabPanId).items.items[0].getActiveTab().items.items[0].items.items[1].items.items[1].id;
//    	var statistics = Ext.getCmp(statisticsId);
//    	statistics.items.items[0].setHeight(normalTree.getHeight()-20);
//    	statistics.items.items[1].setHeight(normalTree.getHeight()-20);
//        //extVia.campaigns.statistics.main.addChartsToPanel(record, schedulerTabPanel);
//      }
    }
   
    else if(width < oldWidth || height < oldHeight){
      newWidth = width - 48;
      newHeight = height - extVia.constants.raster.pgToolbarEditHeight - 153;
      center.panel.setHeight(newHeight);
      center.panel.setWidth(newWidth);
      center.panel.doComponentLayout();
    }
//      var record = center.locked.getSelectionModel().selected.items[0];
//     if(schedulerTabPanel.getTabBar().items.getAt(4).active){
//      var statisticsId = Ext.getCmp(tabPanId).items.items[0].getActiveTab().items.items[0].items.items[1].items.items[1].id;
//    	var statistics = Ext.getCmp(statisticsId);
//    	statistics.items.items[0].setHeight(normalTree.getHeight()-20);
//    	statistics.items.items[1].setHeight(normalTree.getHeight()-20);
//       // extVia.campaigns.statistics.main.addChartsToPanel(record, schedulerTabPanel);
//      }
      
      
    // var test = oldWidth;
    // var panelmC = Ext.getCmp('panel_mC');
    // var center =
    // Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt.getView();
    // var newWidth = width-48;
    // var newHeight = height - extVia.constants.raster.pgToolbarEditHeight - 153;
    // //panelmC.doLayout();
    // center.panel.setHeight(newHeight);
    // center.panel.setWidth(newWidth);
    // center.panel.doComponentLayout();
    // var record = center.locked.getSelectionModel().selected.items[0];
    // if(schedulerTabPanel.getTabBar().items.getAt(4).active){
    // extVia.campaigns.statistics.main.addChartsToPanel(record, schedulerTabPanel);
    // }

  });

  },

// passt die position von Tabs an
  addListenerToResizer : function addListenerToResizer(schedulerTabPanel) {

    var lockedTree = Ext.getCmp(Ext.get(Ext.get('panel_mC').down('a').parent().id).dom.children[0].id).ownerCt.ownerCt
        .getView().locked;
    lockedTree.resizer.addListener("resize", function() {
      var width = lockedTree.getWidth() - 175;
      schedulerTabPanel.getTabBar().items.get(2).setWidth(width);
      
      var width4Tbar = lockedTree.getWidth() - 200;
      Ext.getCmp('invisibleTab4SchTree').setWidth(width4Tbar);
      var tool = Ext.getCmp('mainToolbarId');
      tool.getComponent('newProjektButton').setPosition(width4Tbar+200);
      tool.getComponent('editProjektButton').setPosition(width4Tbar+250);
      tool.getComponent('deleteProjektButton').setPosition(width4Tbar+300);
    });

  }
  

};

// init Object as singleton
extVia.campaigns.statistics.control = new extVia.campaigns.statistics.control();

/*
 * 
 * $Revision: 1.27 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/06 17:07:49 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */