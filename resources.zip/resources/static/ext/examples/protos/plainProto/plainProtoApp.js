/*


*/
Ext.application({
    name: 'plainProtoApp',
    
    /**
     * Place 
     */
    appMode:{},

    testFakeBridge : function(){
        // ///////////////////// CALLBACK START //////////////////////////
        var myfirstCallback = function(result, ex) {
          if (ex) { extVia.notifyException("myfirstCallBack", ex);} 
          else {//DO WHAT YOU HAVE TO DO
        	var resultStr  = ( typeof result === 'string') ?  result : Ext.encode(result[0]);
        	var notifyHtml = resultStr;
	        extVia.showNotification({ status: 'Success',title : extVia.regApp.name+" myfirstFakeCallBack",cls: 'ux-notification-light',position: 'tr',html : notifyHtml,width:600,hideDelay : 3800});
          }
        };
        /////////////////////// CALLBACK ENDE //////////////////////////
        jjbridge.callRemote(this, 'yourHandler', 'getEpobDummyData', [], myfirstCallback);
    },
    
    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	extVia.regApp = this;
    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside
    	var  modulDscr = 'plain App';
    	var epobDscr = 'Objektname';
    	
    	
    	var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
    	extVia.ui.page.raster.onReady(this);

    	var pagejobButtons = [{itemId:'tree'},{itemId:'list'},{itemId:'back'}];
    	var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
    	var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:modulDscr, epobDscr:epobDscr,   pagetoolbarButtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
    	
        // Need some west?	
    	var tabPan = extVia.regApp.myRaster.initWestTabPanel({items:[{title:'Liste',tbar:[{iconCls:'plus'}]},{title:'Suche'},{title:'tab 3'}] });
    	extVia.regApp.myRaster.addToWest(tabPan);


    	
        // Your App
        var appPanel = {tbar :appbar,
        
           defaults:{margin:'24 24 24 24'},
           
        
           items:[
            {html:'hello plain App', margin:'24 24 24 24'},
            
            
             {xtype:'slider', width:400, 
              
              margin:'0 0 24 24',
              
              fieldLabel:'Wann',
              
   
              legendTpl: '<span class="xty_slider-min-dscr">{0}</span><span class="xty_slider-val-dscr">{1}</span><span class="xty_slider-max-dscr">{2}</span>',
              
              minDscr:'heute',
              maxDscr: 'vor einem Jahr',
              valDscr:' vor x bis y Tagen',
    
              minValue:100,
              maxValue:400,
              
              values:[250, 350],
              
              
              listeners:{
               afterrender: function(slider){
                var sliderEl = Ext.get(slider.id+'-bodyEl');
                sliderEl.createChild( {
                tag:'div', cls:'xty_slider-legend',  style: 'width:'+ (slider.getWidth() - slider.labelWidth)  +'px;', 
                children: [     
			        {tag: 'span', cls:'xty_slider-min-dscr', id: 'item0', html: slider.minDscr},
			        {tag: 'span', cls:'xty_slider-val-dscr', id: 'item1', html: slider.valDscr},
			        {tag: 'span', cls:'xty_slider-max-dscr', id: 'item2', html: slider.maxDscr}
			    ]});
               }
              }
              
              
             
             },
            
             
             //{xtype:'fieldset', title:'fieldset', checkboxToggle : true, width:520, items:[{xtype:'textfield', fieldLabel:'acdc'}]}, 
             
             {xtype:'checkbox', fieldLabel:'fieldLabel', boxLabel:'boxLabel'}, 
             
            
            {xtype:'dateslider', width:400,  fieldLabel:'dateslider', margin:'0 0 0 24',

				minDate: '10/1/2016', //valid Ext.Date format
				maxDate: '12/30/2016', //valid Ext.Date format
				//dateFields: [], //array of Ext.form.field.Date items
				//OR
				values: ['10/15/2016','12/19/2016' ], //array of date string matching dateFormat
				
				//Optional
				//dateIncrement: '', //Ext.Date interval constant (default Ext.Date.DAY)
				dateFormat: 'n/j/Y' //valid Ext.Date format (default 'n/j/Y')
            
            }
            
            
            ] 
        };
        //extVia.regApp.myRaster.addToCenter(appPanel); //  set BaseRaster modulDscr to null
    	

    	// Need some center Tabs?
    	appPanel.closable=true;
    	appPanel.title=epobDscr;
    	var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel();
    	extVia.regApp.myRaster.addToCenter(centerTabPan);	
    	centerTabPan.add(appPanel);


      
    }
});



/*
 * 
 * $Revision: 1.8 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2016/12/22 14:43:05 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
