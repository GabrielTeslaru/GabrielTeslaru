Ext.namespace('extVia.ui.page.BaseRaster');
/**
 * @class extVia.ui.page.BaseRaster 
 * A lightweight BaseRaster  for all borderLayout-combinations.
 * It should be not more or less be a layoutManager.
 * @version   $Date: 2019/12/11 09:43:39 $
 *            $Revision: 1.134.2.27 $
 */

if (extVia.ui.cmp && extVia.ui.cmp.factory && extVia.ui.cmp.factory.component){
    extVia.ui.cmp.factory.component.extViaLayoutRegion = extVia.ui.layout.region.Center;
}



extVia.ui.page.BaseRaster = function(config){
    if (config && config.viewCfgFromUrl){
        var viewCfgFromUrl = this.getViewConfigFromUrl();
        Ext.apply(config, viewCfgFromUrl);
    }
  Ext.apply(this,config,{    
    id          : "extVia.ui.page.BaseRaster",
    name        : "extVia.ui.page.BaseRaster",
    viewport    : null,
    mainNorth   : null,
    mainEast    : null,
    mainCenter  : null,
    //menu
    showMenubar : true,
    mainMenu    : null
  });
};
    
extVia.ui.page.BaseRaster.prototype = {
        
  /**
   * Raster + Region specific<br>
   * REFAC: init your regions here, call from extVia.regApp.myRaster.onReady
   */
  initRegions : function initRegions() {
  },

  /**
   * Raster + Region specific<br>
   * init your Margins here
   */
  initMargins : function initMargins() {
    var northMargins = '0 12 12 12';
    var westMargins = '0 5 12 12';
    var centerMargins = '0 5 12 5';
    var eastMargins = '0 12 12 5';
    var southMargins = '5 12 12 12';

    extVia.ui.page.raster.hideEast = false;

    try {
      var pgMrgH = parseInt(extVia.constants.raster.pgPanelMargin / 2, 10);
      var pgMrgQ = parseInt(extVia.constants.raster.pgPanelMargin / 4, 10) - 1;// -1 ist for region resizer;

      var westTopMargin = this.hideNorth?12:0;
      
      // 4 is for roundCornersOverlayWidth
      // northMargins= '0 '+ (pgMrgH+4) +' '+pgMrgH+' '+(pgMrgH+4) +'';
      if (extVia.regApp.appMode.standalone) {
        westMargins = '0 0 0 0'; // queryWest is standalone, e.g. modal dialog.
      } else {
        westMargins = westTopMargin+' ' + pgMrgQ + ' ' + pgMrgH + ' ' + pgMrgH ;
      }

      // center Margins

      var centerMrgTop = 0; // default hasNorth
      var centerMrgRig = pgMrgH; // default noEast
      var centerMrgBot = pgMrgH; // default noSouth
      var centerMrgLef = pgMrgQ; // default hasWest

      if (extVia.ui.page.raster.buildEast && !extVia.ui.page.raster.hideEast) {
        centerMrgRig = pgMrgQ;
      }

      if (this.hideWest) {
        centerMrgLef = pgMrgH;
      }

      if (this.hideNorth) {
        centerMrgTop = pgMrgH;
      }

      if (this.buildEast && !this.hideEast) {
        centerMrgRig = '5';  
      }
      
      centerMargins =  centerMrgTop + ' ' + centerMrgRig + ' ' + centerMrgBot + ' ' + centerMrgLef ;
      
      

      eastMargins = westTopMargin+' ' + pgMrgH + ' ' + pgMrgH + ' ' + pgMrgQ ;
      southMargins =  pgMrgQ + ' ' + pgMrgH + ' ' + pgMrgH + ' ' + pgMrgH ; // if south is used, center
                                                                                    // bottom-Margin is pgMrgQ NOT
                                                                                    // pgMrgH
    } catch (pgMrgEx) {
      extVia.notify("pgMrgEx " + pgMrgEx);
    }

    if (Ext.getVersion().version !== "4.0.7") {
      centerMargins = '0 24 24 24';
      northMargins = '0 24 20 24';
      westMargins = '0 12 24 24';
    }

    // breadcrumbfat
    //northMargins = '0 12 22 12'
    

    
    extVia.regApp.myRaster.northMargins = northMargins;
    extVia.regApp.myRaster.westMargins = westMargins;
    
    extVia.regApp.myRaster.centerMargins = centerMargins;
    
    
    extVia.regApp.myRaster.eastMargins = eastMargins;
    extVia.regApp.myRaster.southMargins = southMargins;
    
    extVia.regApp.myRaster.pgBoxMargins = extVia.constants.raster.pgBoxMargin+' ' +extVia.constants.raster.pgBoxMargin+' ' +extVia.constants.raster.pgBoxMargin+' ' +extVia.constants.raster.pgBoxMargin;
     

  },
        
  /**
   * Called from every Applications . Builds the pageraster. The events are send to the default handlers of the given
   * Application (regApp).
   * 
   * @param {extVia.xyApp} regApp the given Application Object
   * @param {JSON - Object} params whatever needed
   */
  onReady : function onReady(regApp, params) {
    // Set as global Applicatian
    extVia.regApp = regApp;
    extVia.regApp.myRaster = this;
    if (!extVia.regApp.appMode){
        extVia.regApp.appMode = extVia.app.setup.appMode;
    }


    Ext.getBody().addCls('xty_proto-app');
    
    extVia.ui.page.raster.initBodyClsFromTheme(extVia.ui.page.raster.getCurrentThemeCfg());

    
    extVia.regApp.myRaster.initMargins();

    // watchout for the structure they need in : menu!
    // there's no clear rule how to name/id the panels, the divs
//    this.mnPan = new Ext.panel.Panel({
//      id : 'panel_menubar',
//      itemId : 'menubarXXX',
//      // region: 'center',
//      cls : 'xty_DarkBottomBorderNavi',
//      // style:'border-bottom: 2px solid #15428B !important;',
//      autoScroll : false,
//      bodyBorder : false,
//      border : false
//    });
    
    this.mainNorth = new Ext.panel.Panel({
      // layout : 'border',
      layout : 'hbox', // proto-specific
      pack : 'start',// proto-specific
      id : 'panel_mNorth',
      cls : 'xty_region xty_regionNorth xty_navigationbar-region ',
      bodyCls : 'xty_region-body xty_regionNorth-body',
      itemId : 'suitebar',
      region : 'north',
      myApp : 'extVia.app.area.navi.main',
      preventHeader : true,
      border : false,
      frame : false,
      bodyBorder : false,
      split : true,
      collapsible : false,
      titleCollapse : false,
      autoScroll : false,

      height: extVia.constants.raster.northHeight ? extVia.constants.raster.northHeight : 36, 
      margin : extVia.regApp.myRaster.northMargins
      //,items : [ this.mnPan ]
    });

    // -- west --
    if (!this.hideWest) {
      this.mainWest = new Ext.panel.Panel({
        id : 'panel_mw',
        // title : 'west',
        region : 'west',
        width : extVia.constants.raster.mainWestWidth,
        cls : 'xty_region xty_regionWest',
        bodyCls:'xty_region-body',
        collapseFirst : false,
        margin : extVia.regApp.myRaster.westMargins,
        bodyBorder : false,
        border : false,
        split : true,
        header : false,
        collapsible : true,
        listeners:{
          expand:function(){
           this.doLayout();
          }
        }
      });

    }

    
    // -- east --
    if (this.buildEast) {
      this.mainEast = new Ext.panel.Panel({
        id : 'panel_me',
        hidden: this.hideEast,
        // title : 'east',
        region : 'east',
        width : extVia.constants.raster.eastWidth,
        cls : 'xty_region xty_regionEast',
        bodyCls:'xty_region-body',
        collapseFirst : false,
        margin : extVia.regApp.myRaster.eastMargins,
        bodyBorder : false,
        border : false,
        split : true,
        header : false,
        collapsible : true,
        listeners:{
           show:function(panel ){
              var centerPanel =  extVia.regApp.myRaster.getCenter();
              centerPanel.margins.right=12;
           },
           hide:function(panel ){
              var centerPanel =  extVia.regApp.myRaster.getCenter();
              centerPanel.margins.right=24;
           }                      
           
        }
      });
    }

    
    // -- south --
    if (this.buildSouth) {
      this.mainSouth = new Ext.panel.Panel({
        id : 'panel_ms',
        region : 'south',
        hidden: this.hideSouth,
        cls : 'xty_region xty_regionSouth',
        bodyCls:'xty_region-body',
        height: extVia.constants.raster.southHeight,
        collapseFirst : false,
        margin : extVia.regApp.myRaster.southMargins,
        bodyBorder : false,
        border : false,
        split : true,
        header : false,
        collapsible : true
      });
    }
    
    
    // -- center --
    this.mainCenter = new Ext.panel.Panel({
      id : 'panel_mC',
      region : 'center',
      cls : 'xty_region xty_regionCenter',
      bodyCls:'xty_region-body',
      collapseFirst : false,
      margin : extVia.regApp.myRaster.centerMargins,
      bodyBorder : false,
      border : false
    });

    
    if (this.modulDscr){
        var modulPagejob =  extVia.ui.page.pagejob.getPagejobBar({pgjobDscr:this.modulDscr }) ;
        this.mainCenter.add(modulPagejob);
        this.mainCenter.modulPagejob = modulPagejob;
    }
    
    var vpItems = [ this.mainCenter ];
    if (!this.hideNorth) {
      vpItems.push(this.mainNorth);
    }
    if (!this.hideWest) {
      vpItems.push(this.mainWest);
    }
    if (this.buildEast) {
        vpItems.push(this.mainEast);
    }
    if (this.buildSouth) {
        vpItems.push(this.mainSouth);
    }
    
    
    // -- viewport --
    this.viewport = new Ext.container.Viewport({
      id : 'viewport',
      layout : 'border',
      items : vpItems
    });
    
    
//////// Click Highlighting test ///////////////    
    
//    this.viewport.getEl().on('click',  function( e, t, eOpts ){
////
////        extVia.showNotification({
////          title : 'highlight',
////          cls: 'ux-notification-light',
////          html:'e'+e+' t'+t
////        });
//      
//      try{
////            var highEl ;
////            if (t){
////                highEl = Ext.get(Ext.get(t.id).dom.parentNode );
////                if (!highEl) highEl = Ext.get(t.id); 
////                if (!highEl) highEl = Ext.get(e.getTarget().id); 
////
////            }
////            else{
////                highEl = e.getTarget();
////            }
////            
//           highEl = Ext.get(t.id); 
//          highEl.highlight("#D4E59C",{duration:1000});
//          //highEl.frame("ff0000", 3, { duration: 3 });
//          //highEl.frame("ff0000"); //, 3, { duration: 3 });
//          //highEl.frame();
//      }
//      catch(ex){alert("highlight"+ex);}
//      
//    });
    
//////// eo Click Highlighting test ///////////////       

    // Needed on every center
    Ext.panel.Panel.prototype.setTabTip = function(msg) {
      var tabPanel = this.findParentByType(Ext.tab.Panel);
      if (tabPanel) {
        var tabEl = Ext.fly(tabPanel.getTabEl(this).id);
        if (tabEl) {
          var tsTxt = tabEl.child('span.x-tab-strip-text', true);
          if (tsTxt) {
            tsTxt.qtip = msg.toString();
          }
        }
      }
    };
    
    
    
    Ext.panel.Panel.prototype.addHeaderCls =  function(headerCls,cfg) {
           if(Ext.isDefined(this.header)){
             var a, hasCls = false;
             for(a = this.header.additionalCls.length-1; a >= 0; a--){
               if(this.header.additionalCls[a] === headerCls){
                 hasCls = true;
                 break;
               }
             }
             if(!hasCls){
               this.header.addCls('xty_accordionHd');
             }
           }
         };
    
    
    Ext.panel.Panel.prototype.setPagejobText = function(pgjobText, pgjobEpobDscr) {
    Ext.getCmp( this.getTopToolbar().id).setPagejobText(pgjobText, pgjobEpobDscr);
    };
    Ext.panel.Panel.prototype.setMeasuredTabTitle = function(title) {
      // var shortTitle = extVia.ui.layout.factory.getMeasuredTabTitle(epobDscr);
      // this.setTitle(shortTitle);
      // this.setTabTip(title);
    };
    Ext.panel.Panel.prototype.setTip = function(msg) {
       var span = Ext.getCmp(this.id).header.child('span');
       span.dom.setAttribute('ext:qtip',msg );
    };
    /**
     * Shows and Hides Tools and sets invisible Property.<br>
     * to provides persitance of visibility-State
     * <code>this.tools[toolId].invisible = !visible; </code>
     *  So the Tool can be asked about its visibility state
     * @param {String } toolId 
     * @param {boolean} visible
     */
    Ext.panel.Panel.prototype.setToolVisibility = function(toolId, visible) {
      if (this.tools && this.tools[toolId]) {
        if (visible) {
          this.tools[toolId].show();
        } else {
          this.tools[toolId].hide();
        }
        this.tools[toolId].invisible = !visible;
      }
    };
    /**
     * Triggers our Ext.panel.Panel.prototype.setToolVisibility
     */
    Ext.panel.Panel.prototype.hideTool = function(toolId) {
      this.setToolVisibility(toolId, false);
    };    
    /**
     * Triggers our Ext.panel.Panel.prototype.setToolVisibility
     */
    Ext.panel.Panel.prototype.showTool = function(toolId) {
      this.setToolVisibility(toolId, true);
    };
    
    // ------ Start navigationbar ------ //
    
   
    var loc = extVia.locales;

    
    if (extVia.regApp.myRaster.showMenubar) {
      // prime menubar
      //extVia.app.area.navi.main.initMenubar();
        
        
        
//      var listenersCfg = {
//            render: function(itm){
//                var dd = new Ext.dd.DragSource(itm.el,{
//                    ddGroup: 'dragitems',
//                    scroll: true
//                });
//            }
//        };
        
        
        var rechercheCfg_P = 
        {  text:'Suche',
           epobType:extVia.module.epob.PRODUCTS,
           handler: function(item){ 
            var baseUrl = location.href.replace(/jsp.*/,"");
            //alert("baseUrl"+baseUrl+item.ownerCt.id);
            // >>> PROD V4 Start (EPIM-7678) <<<
            // >>> PROD V4 End (EPIM-7678) <<<
            window.open(baseUrl+"jsp/QueryApp.jsp?appModeName=query&epobTypeId="+item.epobType,"newwindow");
            }  
        };
        
        var hierarchiesMenuItemCfg = Ext.apply({}, rechercheCfg_P); 
        hierarchiesMenuItemCfg.text = "Hierarchien"; 
        
        
        var rechercheCfg_E  = Ext.apply({}, rechercheCfg_P); 
        rechercheCfg_E.epobType=extVia.module.epob.ELEMENTS;    
        
        
        var collectionCfg = Ext.apply({}, rechercheCfg_P); 
        collectionCfg.text = "Sammlungen"; 
        collectionCfg.epobType=extVia.module.epob.PRODUCTS +"&map=startColl:true"; 
        

        
        var sizesWindowCall  = function(item){ //http://resizemybrowser.com/
            window.open(window.location.href+"?showScreenSizes=true","newwindow","width=1440,height=900,x=200,y=0,resizable=yes,scrollable=yes,scrollbars=yes,toolbar=yes,location=yes");
        };
        
        
        var sizesResize = function(item){
            
            var width = item.widthN;
            var height = item.heightN; 

            window.resizeTo(width,height);
            window.moveTo(200,50);
            extVia.ui.page.raster.viewport.doLayout();  
            };
        
        
        var sizesPanel = Ext.create('widget.window', {
            
            width: 480,
            height: 280,
            x: 390,
            y: 110,

            title:'Screen sizes',
            iconCls:'xty_icon xty_iconMatrix',
           
            defaults:{
                xtype:'button',
                scale:'large',
                enableToggle:true,
                handler:function(button){
                    
                    if (button.ownerCt.lastButton){
                        button.ownerCt.lastButton.toggle();
                    }
                    
                    sizesResize(button);
                    button.ownerCt.lastButton = button;
                    
                    }
            },
            

            items : [                                                       
               {text:"1024x600  Most Netbooks", widthN:1024, heightN:600},
               {text:"1366x768  Some Laptops", widthN:1366, heightN:768},

               {text:"1280x800  <b>MacBook</b> Air 08/Nexus / Galaxy Tab", widthN:1280, heightN:800},
               {text:"1440x900  <b>MacBook</b> Pro 15 inches", widthN:1440, heightN:900},
            
               {text:"1024x768 <b>ipad</b>",  widthN:1024, heightN:768},
               {text:"1400x768",  widthN:1400, heightN:768},
               
               
               { xtype: 'tbspacer' ,height:12},
         
               {text:"phones",  scale:'small',  height:20,   width:40},
               {text:"tablets + laptop", scale:'small',height:20,   width:120},
               //{text:"laptop",  scale:'small',height:20,   width:60},
               {text:"desktop", scale:'small',height:20,   width:200},

               { xtype: 'tbspacer' ,width:80},
         
               {text:"768x640",   widthN:768, heightN:640,   height:54},
               {text:"1024x720<br><b>tablet<br></b>",  widthN:1024, heightN:720,   height:54},
               {text:"1280x768<br><b>lapdesk<br></b>",  widthN:1280, heightN:768,   height:54},
               {text:"1440x840<br><b>desktop<br></b>",  widthN:1440, heightN:840,   height:54},
               {text:"1600x900<br><b>desktop<br>wide</b>",  widthN:1600, heightN:900,   height:54},   
               {text:"1920x1024<br><b>desktop<br>ultrawide</b>", widthN:1920, heightN:1024,   height:54},
               
               { xtype: 'tbspacer' ,height:12},
               {text:"1280x1024", widthN:1280, heightN:1024},
               {text:"1600x1200", widthN:1600, heightN:1200},
               {text:"1920x1200", widthN:1920, heightN:1200}
               
            ]
        }); 
        
        
        var getUrlParam = function(paramName){
            var paramValue = null;
            var urlArr =  document.URL.split("?");
            if (urlArr.length>1){   
                var paramsObj  = Ext.Object.fromQueryString(urlArr[1]);
                paramValue = paramsObj[paramName];
            }
            return paramValue;
        };
        
        
        var showScreenSizes = getUrlParam("showScreenSizes");
        if (showScreenSizes){sizesPanel.show();}
        
        
        var isfileUrl = /^file:/.test(location.href);
        
      
      
        var subVerti =  location.href.indexOf('palettehorizontal')===-1;
      
        var tbsep = {xtype:'tbseparator' };
        var tbsep2 = {xtype:'tbseparator', width:4, hidden: subVerti};
        var tbsep3 = {xtype:'tbseparator', width:4};

      
        var homieButt = {xtype:'tbspacer'};
        if (extVia.navi &&  extVia.navi.statics){
          homieButt = extVia.navi.statics.getHomeButtonCfg();
        }
        
        
        
        
        extVia.ui.page.raster.addToNorth( { 
            //hidden:true,
            itemId : 'navigationbar-bin', 
            cls : 'xty_navigationbar-bin', 
            //itemId:'menubar-modules-wrapper',
            style:'paddsing-top:2px; borsder:2px solid red;',
            xtype:'panel', 
            width:692, 
            
            height: extVia.constants.raster.northHeight ? extVia.constants.raster.northHeight : 36, 
            
            flex:3,
            border:false, 
            text:'resp' ,
            tbar:{
                
              height: extVia.constants.raster.northHeight ? extVia.constants.raster.northHeight : 36, 
                
                
                
                
                border: false,
                cls:'xty_navigationbar xty_navigationbar-'+extVia.constants.raster.northHeight,
                itemId: 'navigationbar',

                defaults:{
                    enableToggle:true, 
                    cls : 'xty_navi-btn',
                    pressedCls : 'navi-btn-pressed',
                    overCls : 'navi-btn-over',
                    
                    
                    listeners: {
                        click: function(button){                   
                            if (button.ownerCt.lastToggledButton){
                                button.ownerCt.lastToggledButton.toggle();
                            }
                            button.ownerCt.lastToggledButton = button;
                            
                            button.showMenu();
                        },
                        
                        mouseover: function(button){
//                           var homieButt = button.ownerCt.getComponent('home');
//                           if (homieButt.myMenu && homieButt.myMenu.isVisible()){
//                            homieButt.showMenu(homieButt, {x:button.getPosition()[0]});
//                           }
                
                           button.ownerCt.lastButtonId = button.id;
                           var task = new Ext.util.DelayedTask(function(){
                           var homieButt = button.ownerCt.getComponent('home');
                           if ( button.ownerCt.lastButtonId === button.id &&  homieButt && homieButt.myMenu && homieButt.myMenu.isVisible()){
                            //homieButt.showMenu(homieButt, { srcButton:button});
                             var lintalibi;
                           }
                           });
                           task.delay(80);    
                           
                        },
                        
                        menushow : function(button) {
                        	 var homieButt = button.ownerCt.getComponent('home');
                        	 homieButt.showMenu(homieButt, { srcButton:button});
                        }
                        
                        
                    },
                    
                    handler: function(button){                   
                      var homieButt = button.ownerCt.getComponent('home');
                      //homieButt.showMenu(homieButt, { srcButton:button});
                    },

                    menu:{
                        listeners: {
                            render: function(itm){
                                var dd = new Ext.dd.DragSource(itm.el,{
                                    ddGroup: 'dragitems',
                                    scroll: true
                                });
                            }
                        }
                        
                    }

                },
                
                items: [
                       
//                        {xtype:'button', tesxt:'home', iconCls:'xty_viaMenubar-home', cls:'xty_viaMenubar-level1',
//                         menu:{items:[{text:'sublevel 1: entry 1', menu:{items:[{text:'sublevel 1: entry 2', menu:{items:[{text:'sublevel 1: entry 3', menu:{items:[{text:'sublevel 1: entry 4', menu:{items:[{text:'sublevel 1: entry 5',menu:{items:[{text:'sublevel 1: entry 7', menu:{items:[{text:'sublevel 1: entry 8', menu:{items:[{text:'sublevel 1: entry 9',menu:{items:[{text:'sublevel 1: entry 10' }]} }]}}]}}]} }]}}]}}]} }]}}]}
//                        }, 
          
                        {xtype:'button', tesxt:'home', iconCls:'xty_viaMenubar-home', cls:'xty_viaMenubar-level1', hidden:true,
                          handler: function(butt){
                            
                          if (!butt.myMenu){
                            butt.myMenu =    Ext.create('Ext.menu.Menu',butt.menuCfg);
                          } 
                          
                          if (!butt.myMenu.isVisible()){
                            extVia.regApp.myRaster.getNorth().setHeight(90); 
                            butt.myMenu.showAt(40, 34); // sub by home
                            //butt.myMenu.showAt(150, 4); // after viaCONTENT
                          } else{
                           butt.myMenu.hide();
                           extVia.regApp.myRaster.getNorth().setHeight(30);
                          }
                         },

                         menu:null,
                         menuCfg:{componentCls:'xty_menu-white',  showSeparator:false, 
                         
                         items:[
                         {xtype:'toolbar', style:'background:white;border-color:#FFF;',  width:900, margin:'2 2 2 2',
                          items:[{text : 'Kategorie', handler:function(item){item.ownerCt.ownerCt.hide();} },tbsep, {text : 'Unicodezeichen'},tbsep,{text : 'Elementattribute'},tbsep,{text : 'Elementattributsicht'},tbsep,
                          {text : 'DateiFormat'},tbsep,{text : 'Farbraum'},tbsep,{text : 'Bildbearbeitung'},tbsep,{text : 'Wörterbuch'},tbsep,{text : 'XSD/DTD Datei'}]}
                         ],
                         
                         listeners:{
                          hide:function(){
                           extVia.regApp.myRaster.getNorth().setHeight(30);
                          }
                         }
                         }
                        },           

                        
                        //{xtype:'tbspacer', width:300},
                        
                        homieButt,
                        

                        {xtype:'splitbutton', text:'viaCONTENT',
                            menu:{
                            items:[
                              {text:'Element', tooltip:'Erstellung', cls:'xty_IA-error',
                                menu:{
                                items:[ {text:'Text'}, {text:'Bild'}, {text:'Grafik'}, {text:'Redaktionelle Tabelle'}, {text:'Produkttabelle'}, {text:'Dokument'}, {text:'Video'}, {text:'Audio'}  ] }
                                
                              }, {text:'Suche'}, {text:'Kategorien'}, {text:'Importordner'}, {text:'XML-Import'}, {text:'CSV-Import'}, {text:'Importplanung'}
   
                            ]
                           }
                        },
                                                                                                
                        {xtype:'splitbutton', text:'viaPRODUCT', menu:{items:[ 
                          {text:'Suche'}, hierarchiesMenuItemCfg,{text:'Massendatenpflege'}
                         ]}
                        },
                        {xtype:'splitbutton', text:'viaPUBLISH',menu:{items:[ {text:'Publikationspflege'}, 
                          {text:'Produktion',menu:{items:[{text:'XML-Export'},{text:'XML-Exportplanung'},{text:'DTD-Export'},{text:'Exportarchiv'}]}}
                          ]}
                        },
                        {xtype:'splitbutton', text:'adminCONTENT',
                            menu:{
                              items:[ 
                                {text:'Kategorie'}, {text:'Unicodezeichen'}, {text:'Elementattribute'},{text:'Elementattributssicht'},{text:'Dateiformat'},{text:'Farbraum'},{text:'Bildverarbeitung'},
                                {text:'W&ouml;rterbuch',menu:{items:[{text:'W&ouml;rterbucheintrag'},{text:'W&ouml;rterbuchkategorie'}]}},{text:'XSD/DTD Datei'}
                              ]
                            }
                         },
                        {xtype:'splitbutton', text:'adminPRODUCT',
                          menu:{
                              items:[
                                {text:'Hierarchiestufe'}, 
                                {text:'Vergleichsoperator',  menu:{ items:[{text:'Operator'}, {text:'Operatorengruppe'}, {text:'Operatorenzuordung'}]}}, 
                                {text:'Einheit',  menu:{ items:[{text:'Einheit'}, {text:'Gruppe'}, {text:'Zuordung'}]}},
                                {text:'Auswahlgruppe',  menu:{ items:[{text:'Auswahlgruppenformat',cls:'xty_IA-error'}] } }, 
                                {text:'Produktattribut'}, 
                                {text:'Produktattributsicht',  menu:{ items:[{text:'Sicht'},  {text:'Zuordung'}]}},
                                
                                {text:'Beziehungstypen',  menu:{ items:[{text:'Typ'}, {text:'Sichtbarkeit'}]}},
                                  
                                {text:'Hierarchietyp'}, 
                                {text:'Lieferant',  menu:{ items:[{text:'Attribut'}, {text:'Stamm'}, {text:'Export'}]}}
                                
                                ]} 
                        },
                        {xtype:'splitbutton', text:'adminPUBLISH', hidden:true,
                          menu:{
                            items:[ 
   
                              {text:'Editor',  menu:{ items:[{text:'Element'}, {text:'Gruppe'}, {text:'Zuordung'}]}},
                              {text:'Feld',  menu:{ items:[{text:'Element'}, {text:'Gruppe'}, {text:'Zuordung'}]}},
                              {text:'Format',  menu:{ items:[{text:'Element'}, {text:'Gruppe'}, {text:'Zuordung'}]}},
                              {text:'Exportformat',  menu:{ items:[{text:'Element'}, {text:'Gruppe'}, {text:'Zuordung'}]}},                              
                              {text:'Masterpublikation',  menu:{ items:[{text:'Hierarchiestufe'}, {text:'Masterpublikation', cls:'xty_IA-error'}, {text:'Zuordung'}]}},
                              {text:'Produktplanungsvorlage',  menu:{ items:[{text:'Vorlage'}, {text:'Kategorie'}]}},                              
                              {text:'Strukturplanungsvorlage',  menu:{ items:[{text:'Vorlage'}, {text:'Kategorie'}]}},
                              {text:'XML-Exportvorlage',  menu:{ items:[{text:'Element'}, {text:'Gruppe'}, {text:'Zuordung'}]}},                              
                              {text:'ecatDesigner',  menu:{ items:[{text:'Element'}, {text:'Gruppe'}, {text:'Zuordung'}]}}
                              
                            ]
                          }
                        },    
                  
                  
                  
                        {xtype:'splitbutton', 
                            text:'System',
                            menu:{
                                items:[                                            
   
                                        {text:'Benutzerpflege'}, {text:'Deamon'}, {text:'Parameter'},{text:'Workflow'},{text:'&Uuml;bersetzung'},
                              
                                     {text:'NLS', cls:'xty_IA-error',
                                      menu:{items:[{text:'Sprachen', handler: function(){
                                        extVia.accessArea.modules.access.openLanguageModule();
                                      }} ]} 
                                     }
                              
                              
                                  ]}},  // eo system 
                                        {xtype:'splitbutton', text: loc.user,
                                            menu:{ 
                                                items:[
                                                       collectionCfg, {text:'Jobliste'}, {text:'Benutzerprofil'}, {text:'Protokoll'}, {text:'Statistiken'}, {text:'Report'}, 
                                                       {text:'Lesezeichen',
                                                        menu:{
                                                            items:[
                                                                   {text:'Lesezeichen A'},
                                                                   {text:'Lesezeichen B'},
                                                                   {text:'Lesezeichen C'},
                                                                   {text:'Lesezeichen Verwaltung'},
                                                                   {text:'gespeicherte Suchen',
                                                                        menu:{
                                                                            items:[
                                                                                   {text:'Suche A'},
                                                                                   {text:'Suche B'},
                                                                                   {text:'Suche C'}
                                                                                   ]}
                                                                       }
                                                                   ]}
                                                       }
                                                       
                                                       
                                                       ]}}   

                    ]
             }
        });
        
        
        
        var removeBarrelRollCls = new Ext.util.DelayedTask(function(){
          Ext.getBody().removeCls('xty_do-a-barell-roll');
        });
        extVia.doABarrelRoll = function(field){     
          if (field.value==='Do A Barrel Roll'){
            Ext.getBody().addCls('xty_do-a-barell-roll');
            removeBarrelRollCls.delay(4500);
          }
        };
        
        

       var bellsCaller ={};
       var insightsCaller ={};

      var bellsoverviewIFRAME; 
      var bellsFlyoutClose = function() {   
        bellsoverviewIFRAME.close();
      };
       
      top.bellsFlyoutClose = bellsFlyoutClose;
      
       
      var bellsHandler= function(cfg) {   
         var title = loc.notifications;
         var callerCls ='bells';
         var caller = bellsCaller;
         bellsoverviewIFRAME = Ext.create('Ext.panel.Panel', {
           itemId: 'collabs-palette-panel',
           border:false,
           bodyBorder:false,
           cls:'xty_'+callerCls+'-flyout-panel xty_feed-iframe-bin  xty_palette-arrow-top xty_palette-arrow-top-default ',
           listeners:{  
             destroy: function(panel){
               caller.bellsoverviewIFRAME = null;
             }
           },
           renderTo: Ext.getBody(),
           width:420,
           height:620,
           items : [
           {
            style : 'margin:0;padding:0px; border:1px solid #d0d0d0; bodrder-right:1px solid #99BCE8;bodrder-bottom:1px solid #99BCE8;',
            width:570,
            itemId : 'iframe',
            //cls : 'xty_dialog-item-panel  xty_dialog-content-item-panel  xty_dialog-iframe-panel ',
            xtype : "component",
            autoEl : {
              border : true,
              layout : 'fit',
              tag : "iframe",
              height:620,
              name: 'collabsOverviewFrame',
              frameborder : 0,
              src : '../collaboration/collaborationsOverview.html?uiLangIso='+extVia.locales.uiLangIso  //srcUrl
            }
           }
          ]  
         });     
     };
       
     var chatbotCaller ={};
     var chatbotHandler= function(cfg) {   
       var chatbotEnabled = false;
       if (extVia.assistance && extVia.assistance.chatbot && extVia.assistance.chatbot.Chatbot){
         chatbotEnabled = true;
         extVia.assistance.chatbot.Chatbot.statics.startChat({});
       }            
     };
    
     var chatboAfterrender= function(cfg) {   
       var chatbotEnabled = false;
       if (extVia.assistance && extVia.assistance.chatbot && extVia.assistance.chatbot.View){
         chatbotEnabled = true;
         extVia.assistance.chatbot.View.statics.createChatbotButton({});
        }            
      };
     
     
       var insightsHandler = function(btn){ 
        var title = btn.itemId.replace(/counter/,'');
        var callerCls ='insights';
        var caller = insightsCaller;
        
        if (btn.itemId==='logo' || btn.itemId==='newsbadge' ){
          title = 'Insights';
          callerCls ='insights';
          caller = insightsCaller;
        }
        
        
        if (btn.itemId.indexOf('bell')>-1){
          title = loc.notifications;
          callerCls ='bells';
          caller = bellsCaller;
        }
        
        if (btn.itemId.indexOf('badge')>-1){
          btn.hide();
        }
       
        //extVia.notify({action: 'badgeclick'  , mssg:  'zeige '+btn.tooltip}); 
        
        var iframeId =  btn.itemId +'feedIFRAME'; 
        

        var articelStore = extVia.stores.initArticelStore({});
                
        
        var articelStartIndex = 0;
        var articelRound = '';
        var articelsPageSize = 5;
        var getArticels = function(articlesCount){          
           var articels = [];
           if (!articlesCount){ articlesCount = articelsPageSize; }
           var i ;
           for ( i =0 ; i<articlesCount; i++ ){ 
            var newIx = articelStartIndex;
            if (articelStore.myData[newIx]){
              articelStore.myData[newIx].author+=articelRound;
              
              articels.push( articelStore.myData[newIx]);
              articelStartIndex++;
            }
            else{
             articelStartIndex=0;
             articelRound+='&middot;';
            }
           }
           return articels;
        };
         

        articelStore.add(getArticels(8));

        
        if (!caller.insightsfeedIFRAME){
        // >>> PROD V4 Start (EPIM-7678) <<<
        var insightsfeedIFRAME = Ext.create('Ext.panel.Panel', {
                itemId: 'feed-palette-panel',
                bodyBorder:false,
                cls:'xty_'+callerCls+'-flyout-panel xty_feed-iframe-bin  xty_palette-arrow-top xty_palette-arrow-top-default ',

                title: title,
                closable:true,
                listeners:{  
                  destroy: function(panel){
                    caller.insightsfeedIFRAME = null;
                  }
                },
                
                tools:[{id:'right', hidden:true}],
                renderTo: Ext.getBody(),
                width:420,
                height:520,
                
                bbar:{ itemId: 'bottombar', items: [ '->' , 
                    {itemId:'more',  text:'more...',
                     handler: function(button){
                       articelStore.add( getArticels(2));
                     }
                    
                    
                    }, 
                    {itemId:'back', text:'&#10094; &nbsp;back', hidden:true,
                    handler:function(btn){
                          var bbar = btn.ownerCt;
                          var panel = bbar.ownerCt;
                          panel.setTitle(' Insights');
                          panel.getComponent('feed-boundlist').show();
                          bbar.getComponent('more').show();
                          bbar.getComponent('back').hide();
                    }},
                    '->']},
                
                resizable:true,

                items:[
                  {
                      xtype : 'boundlist',
                      itemId: 'feed-boundlist',
                      cls:'xty_teaserlist',
                      style:'border:0px; ',
                      queryMode : 'local',
                      displayField : 'author',
                      loadingText : 'Boundlist is loading',
                      //width:320,
                      height:467,
                      store: articelStore,
                      itemTpl : extVia.templates.statics.BoundListItem_userChannelTeaser
          
        
                      ,listeners:{
                        
                        afterrender: function(boundlist){
                          var boundlistListEl = Ext.get(boundlist.id+'-listEl'); 
                          boundlistListEl.on('scroll', function(){
                            
                           var scrollTop =  boundlistListEl.dom.scrollTop;
                           var listHeight =  boundlistListEl.getHeight();
                           var scrollBottom = listHeight+scrollTop-10;
                           //insightsfeedIFRAME.setTitle("scrollTop "+ scrollTop + " scrollBottom "+ scrollBottom + " articelStore.count() "+articelStore.count() );                      
                           if (scrollBottom > (articelStore.count())*63 ){ 
                            articelStore.add(getArticels(1)); 
                           }
                          });
                        }, 
                        
                        itemcontextmenu:function( boundlist, record, item, index, evt ){
                          evt.preventDefault();
                          boundlist.hide();
                          var bbar = boundlist.ownerCt.getComponent('bottombar');
                          bbar.getComponent('more').hide();
                          boundlist.ownerCt.setTitle(record.get('author'));
                          
                          bbar.getComponent('back').show();
                          
                          var link =record.get('link');
                          
                          //alert('iframeId '+iframeId +' '+record.get('author') +' '+record.get('link')) 
                          //Ext.get(iframeId).dom.src = 'http://www.staggeringbeauty.com/';
                          
                          //Ext.get(iframeId).dom.src = 'https://www.bing.com/images/search?q='+record.get('author')+'&qpvt=kermit&qpvt=kermit&qpvt=kermit&FORM=IGRE'
                          var ifrSrc =  link ? link :'https://duckduckgo.com/?q='+record.get('author')+'&iax=1&ia=images'; 
                          
                          Ext.get(iframeId).dom.src = ifrSrc;
                          
                        },
                        
                        itemdblclick:function( boundlist, record, item, index, evt ){
                            window.open('https://www.google.de/search?q='+record.get('author')+'&source=lnms&tbm=isch&sa=X&biw=1321&bih=881');
                        }                      
                      }
                   } 
                ]
                ,html:'<iframe id="'+ iframeId + '" src="" style="border: 0px inset #ddd" width="100%" height="100%"></iframe>' // http://www.staggeringbeauty.com/
                
                
                
         }); 
          // >>> PROD V4 End (EPIM-7678) <<<
          caller.insightsfeedIFRAME = insightsfeedIFRAME; 
        }
        
        };
        

      var uiLangHandler = function(item){extVia.ui.page.raster.reloadPage('uiLangIso='+item.itemId);};

      
      var hideDevyItem = location.href.indexOf('file:///D:/Projekte/CVS/')===-1;
      var devyIp = '';
      if (!hideDevyItem){
        devyIp = '194';
      }

      
        
       var avatarMenuCfg = {
         itemId:'menu',
         defaults:{
           handler: function(item){                                                              
             extVia.notify(item.text+" clicked");
           }  
         },
         items:[
           {
             text:'Themes',
             iconCls:"x-tool-themes",
             menu:{
             items:[
               
               
               { xtype: 'buttongroup', columns:3,
                 itemId:'themes-btngrp', 
                 defaults:{
                   scale:'large',
                   handler: extVia.ui.page.raster.initTheme 
                 },
                 items: extVia.ui.page.raster.themes
                }
             ]
            }
         },

         // >>> PROD V4 Start (EPIM-7678) <<<
         // >>> PROD V4 End (EPIM-7678) <<<
                 
              // Navi protos
              {
               text:"Navis",
               itemId:'navis', 
               expanded:true,
               url:'navi/naviProto.html',
               menu:{ 
               
                items:[
                 { xtype: 'buttongroup', columns:2,
                 itemId:'navis-btngrp', 
               
                 defaults:{scale:'large'},
                
                 items:[
                     {
                       text: 'Breadcrumb',
                       href: location.href.replace(/protos.*/,"protos/") + 'navi/naviProto.html?navtype=breadcrumb&breadcrumbtipp=false',
                       hrefTarget: '_blanc'
                     },
                       {
                       text: 'Breadcrumb with Tips',
                       href: location.href.replace(/protos.*/,"protos/") + 'navi/naviProto.html?navtype=breadcrumb', 
                       hrefTarget: '_blanc'
                      },
                      
                      
                      {
                        text:'Menu',
                        href: location.href.replace(/protos.*/,"protos/") + 'navi/naviProto.html?navtype=menu', 
                        hrefTarget: '_blanc'
                        },
                        {xtype:'tbspacer'},
                      
                      {
                      text:'Two Lines',
                      href: location.href.replace(/protos.*/,"protos/") + 'navi/naviProto.html?navtype=twolines', 
                      hrefTarget: '_blanc'
                      },
                      {xtype:'tbspacer'},
                       
                      {text:'Palette',
                      href: location.href.replace(/protos.*/,"protos/") + 'baseProto/baseProto.html?navtype=palette', // overlay-panel , flyout
                      hrefTarget: '_blanc'
                      },
                      {text:'Palette resize',
                      href: location.href.replace(/protos.*/,"protos/") + 'baseProto/baseProto.html?navtype=palette&resize=true', // overlay-panel , flyout
                      hrefTarget: '_blanc'
                      },
                      {text:'Palette horizontal',
                      href: location.href.replace(/protos.*/,"protos/") + 'baseProto/baseProto.html?navtype=palettehorizontal', // overlay-panel 
                      hrefTarget: '_blanc'
                      }
                 ]
                 
                }]
                 
                 
               }
  }, // eo navi-protos
                 
                 
    {
        text:'Protos',
         menu:{
         defaults:{
         handler: function(item){                                                              
           var appUrl = location.href.replace(/protos.*/,"");
           appUrl+="protos/"+item.url;
           window.open(appUrl,"newwindow"); 
         }  
       },
     items:[
      ///////////////// lightweight ////////////////////  
     {text:"Collaboration", url:'collaboration/collaborations.html'},
       
     {text:"Asset Browser", url:'assets/assetsProto.html?regions=NWCE'},
     {text:"baseProto", url:'baseProto/baseProto.html'},

     {text:"dialoge", url:'dialoge/dialoge.html'},
     {text:"distributed EPIM", url:'distributions/distributionsProto.html'},
     
     {text:"dqi", url:'dqi/dqiProto.html'},
     
     {text:"elements", url:'elements/elementsProto.html'},
     
     {text:"Formula", url:'formulaEditor/formulaProto.html'},
     
     {text:"versionierung", url:'versionsProto/versionsProto.html'},
     
     {text:"Planners", url:'planner/planner.html?regions=NC'},

     {text:"Uploader", url:'uploader/uploader.html'},
     
     {text:"Workflows", url:'workflows/workflows.html'},
     
     {text:"Custom Tabs", url:'customTab/customTab.html'},
       
     {text:"Camunda Forms", url:'camundaForms/camundaForms.html'},
     
     {text:"resources Proto", url:'resourcesProto/resourcesProto.html?regions=C'},
     {text:"Publikationen", url:'publications/publicationsProto.html'},
     {text:"plain Proto", url:'plainProto/plainProto.html'},
     {text:"resources Proto", url:'resourcesProto/resourcesProto.html?regions=C'},
     {text:"processTracker", url:'processTracker/processTracker.html'},
     {text:"logbrowser", url:'logbrowser/logbrowser.html'},
     {text:"miniquery", url:'miniquery/miniquery.html?searchareaAsTB=true'},
     {text:"campaigns", url:'campaigns/campaignsProto.html'},
     {text:"group Tabs Skipping", url:'grouptabsSkipper/grouptabsSkipper.html'},
     {xtype:'menuseparator'},
     
     ///////////////// heavyweight ////////////////////  
     {text: 'plainApp',  url:'../../../../../_pty_plainApp.jsp?appModeName=plain', disabled:isfileUrl},
     {text: 'dialogesApp',  url:'../../../../../_pty_plainApp.jsp?appModeName=dialoges', disabled:isfileUrl},
     {text: 'mam',  url:'../../../../../QueryApp.jsp?epobType=PRODUCT&appModeName=queryLoadModule&map=loadModule:mam,loadModuleMain:mamMain', disabled:isfileUrl},
     {text: 'versions Data',  url:'../../../../../QueryApp.jsp?epobType=PRODUCT&appModeName=queryLoadModule&map=loadModule:versioning,loadModuleMain:versionsMain,epobLoadType:VERSION,epobLoadId:327342', disabled:isfileUrl},
     {text: 'elastic Search',  url:'../../../../../QueryApp.jsp?appModeName=queryElastic&epobType=PRODUCTS&map=queryElastic:true', disabled:isfileUrl},
     {xtype: 'menuseparator' },
     
     ///////////////// oldGUI ////////////////////        
     { text: 'drapeMain',  url:'../../../../../_pty_plainDRAPEMain.jsp' , disabled:isfileUrl},
     { text: 'drape',  url:'../../../../../_pty_plainDRAPE.jsp', disabled:isfileUrl },    
     { text: 'pty', url:'../../../../../_pty_Pagetyp.jsp' , disabled:isfileUrl }
   ]
 }
},//eo protos
 
     {
      text:'Layout',
             iconCls:"x-tool-layout",
             menu:{
               defaults:{handler: sizesWindowCall},
                 items:[
                                {
       text:"regions",
       iconCls:"x-tool-regions",
       menu:{
         defaults:{
               handler:function(item){
                   var newHref = location.href.replace(/.html.*/,"");
                   location.href= newHref+".html?regions="+item.regions;
               }
             },
         items:[
              {text:"north west center", regions:'NWC' ,iconCls:"x-tool-regions-NWC"},
              {text:"north west center east", regions:'NWCE',iconCls:"x-tool-regions-NWCE"},
              {text:"north west center east south", regions:'NWCES',iconCls:"x-tool-regions-NWCES"},
              {text:"north west center south", regions:'NWCS',iconCls:"x-tool-regions-NWCS"},
              {text:"north center", regions:'NC',iconCls:"x-tool-regions-NC"},
              {text:"center", regions:'C',iconCls:"x-tool-regions-C"},
              {text:"north center south", regions:'NCS',iconCls:"x-tool-regions-NCS"},
              {text:"north center east south", regions:'NCES',iconCls:"x-tool-regions-NCES"}
         ]
        }
     }, {
       text:"hide Menu",
       handler: function(item){
         extVia.ui.page.raster.mainNorth.setHeight(5);
       }
    }, {
     text:"sizes"
   }// eo sizes
     ]
   }
 },// eo Layout    
                     
           {xtype: 'menuseparator' },
           //<<< EO: Copied Prototype menus into Dashboard menu. <<< (aweber)
           {text:"Sprachen ", iconCls:'xty_icon_'+loc.uiLangIso,
             menu:[
               {iconCls:'xty_icon_de xty_icon_deu xty_icon_deu_DEU' , handler: uiLangHandler, itemId:'de', text: 'Deutsch' + ( loc.uiLangIsoIx===0? '&nbsp;&nbsp;&nbsp;<span class="xty_icon xty_iconChecked">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>':'')},
               {iconCls:'xty_icon_en xty_icon_eng xty_icon_eng_GBR' , handler: uiLangHandler, itemId:'en', text: 'Englisch' + ( loc.uiLangIsoIx===1? '&nbsp;&nbsp;&nbsp;<span class="xty_icon xty_iconChecked">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>':'')},
               {iconCls:'xty_icon_ro xty_icon_ron xty_icon_ron_ROU' , handler: uiLangHandler, itemId:'ro', text: 'Rum&auml;nisch' + ( loc.uiLangIsoIx===2? '&nbsp;&nbsp;&nbsp;<span class="xty_icon xty_iconChecked">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>':'')}
             ]
          },
          
        {text:"Unicodezeichen"},
        {text:"Dashboard Einblenden"   },
        {text:"Abmelden"}
       ]}; // eo dasbbtnMenu avatarMenu
                 

       
       var newInsightscount = 6;

       var voiceEnabled = true;   
       
       var  chatbotBtnWidth = -10; 
       
       
       var  miniQueryWidth = 180; 

       var  propsearchWidth =  380; 

       
       var propsearchEnabled = false;
       
       
       
       if (this.propsearchEnabled){
          propsearchEnabled = this.propsearchEnabled;
        }
       
       
       var naviSearchWidth = propsearchEnabled ?  propsearchWidth : miniQueryWidth;
       
       
       var  voiceBtnWidth = 17; 
       var  logoWidth = 106; 


       var  helpBtnWidth = 24; 
       var  bellBtnWidth = 24; 
       var  avatarBtnWidth = 24; 
       
       
       var allNaviToolsWidths = chatbotBtnWidth +  naviSearchWidth + (voiceEnabled ? voiceBtnWidth: 0 ) + logoWidth + helpBtnWidth + bellBtnWidth + avatarBtnWidth ; 
       var navigationToolsPanelWidth = allNaviToolsWidths+ 56;
        
       
       
       var navigationToolsPanel =  extVia.ui.page.raster.addToNorth( {  
         xtype:'toolbar', 
         width:navigationToolsPanelWidth, 
         cls:'xty_navigationTools-panel', 
         itemId:'navigationTools-wrapper',
         style:'border:0px;',
         border: false, 
         bodyBorder: false, 
         
         
         defaults:{ 
           componentCls:'xty_navi-tool'
//           overCls:'navitool-over',
//           pressedCls:'navitool-pressed'
         },
         
         
             items: [

               {
                 
                 hidden: ! propsearchEnabled,

   
                 xtype: propsearchEnabled ? 'propsearchcombo' : 'combo',
                 
                 itemId:'propsearchCombo',
                 //componentCls: '',
                 cls:'xty_propsearch-combo xty_formfield-XL xty_has-insidetrigger', 
                 width:propsearchWidth, 
                 
                 emptyText:'Want to search for something?', 
                 
                 store:   Ext.create('Ext.data.Store', {fields: [ 'dscr','epobType', 'labeledType','value'], 
                 data :  [ 
                   {dscr:'Hierarchien', epobType:'Hierarchy', labeledType:'type:Hierarchy', value: extVia.module.epob.HIERARCHY},  
                   {dscr:'Produkte', epobType:'Product', labeledType:'type:Product', value: extVia.module.epob.PRODUCT}, 
                   {dscr:'Attribute', epobType:'Attribute',  labeledType:'type:Attribute', value: extVia.module.epob.PRODUCTATTRIBUTE},  
                   {dscr:'Sammlungen', epobType:'Collection',labeledType:'type:Collection', value: extVia.module.epob.COLLECTION},  
                   {dscr:'Bilder', epobType:'Image',labeledType:'type:Image', value:extVia.module.epob.IMAGE},  
                   {dscr:'Wörterbuch', epobType:'Dictionary', labeledType:'type:Dictionary', value: extVia.module.epob.PRAT_DICTIONARY}
                   ]
                 })   
                 //,searchResultHandler:searchResultHandler
                 
               },
               
               
//               { 
//                 xtype:'button', hidden:true,
//                 itemId:'chatbot',  
//                 iconCls:'xty_navi-chatbot', 
//                 scale:'medium',
//                 cls:'xty_navi-chatbot-btn',
//                 handler:chatbotHandler
//                 ,listeners:{
//                   afterrender: chatboAfterrender
//                 }
//               },
//               
               


 
               
               
               { xtype:'panel', hidden: propsearchEnabled,
                 border:false, height: 36, 
                 width:miniQueryWidth, 
                 cls:'xty_miniquery-bin',
                 itemId:'miniquery-wrapper', 
                 html:'<input id="viamenu-miniquery-input" onkeyup="extVia.doABarrelRoll(this);" type="text" style="border-radius:10px; height:20px; margin-top:5px;padding-left:4px; border-color:#7EADD9" class="x-form-field x-form-text "/>'
               }, 


             
             { 
               xtype:'button', hidden: !voiceEnabled,
               itemId:'voice', 
               enableToggle:true,
               iconCls:'xty_navi-voice-icon', 
               scale:'medium',
               height:26, 
               width: voiceBtnWidth,
               cls:'xty_navi-voice-btn'
             },
               
               
               
               
               {
                 itemId:'viaMenu-logo-panel',
                 xtype:'panel',
                 cls:'xty_viaMenu-logo-panel', 
                 border:false,
                 newInsightscount:newInsightscount,
                 height:36,
                 width:logoWidth,
                 listeners:{
                   afterrender:function(panel){
                     panel.getEl().on('click', function(panelEl){
                       insightsHandler(panel);
                     });
                   }
                 }
                 
             },
             

             
             { 
               xtype:'button', 
               itemId:'help',
               iconCls:'xty_navi-help', 
               scale:'medium',
               cls:'xty_navi-help-btn'     
             },
 
               { 
                 xtype:'button', 
                 itemId:'bell',  
                 iconCls:'xty_navi-bell', 
                 scale:'medium',
                 cls:'xty_navi-bell-btn',
                 handler:bellsHandler
               },


               { 
                 xtype:'button', 
                 itemId:'avatar',  
                 iconCls:'xty_navi-avatar', 
                 scale:'medium',
                 cls:'xty_navi-help-avatar', 
                 menu:avatarMenuCfg
               },              

               
               
               // badges
               
             {
               itemId:'newsbadge',
               scale:'small',
               style:'position:absolute; ',
               cls:'xty_badge-btn xty_insights-badge-btn  xty_insights-badge-btn-' +  (newInsightscount.toString().length) ,
               height:16,
               
               x:100,
               
               xtype:'button',
               text: newInsightscount,
               tooltip:' '+newInsightscount+' neue Viamedici Insights',
               newInsightscount:newInsightscount,
               handler:insightsHandler
               },
             
             
               {
                 id:'bellsbadge',
                 hidden:true,
                 itemId:'bellsbadge',
                 scale:'small',
                 style:'position:absolute; ',
                 cls:'xty_badge-btn xty_bells-badge-btn xty_bells-badge-btn-5',
                 height:16,
                 xtype:'button',
                 text:'',
                 handler:insightsHandler,
                 tooltip:'neue Nachrichten'
               },     

               
              {
                itemId:'tasksbadge',
                scale:'small',
                stylse:'position:absolute; ',
                cls:'xty_badge-btn xty_tasks-badge-btn  xty_tasks-badge-btn-7',
                height:16,
                xtype:'button',
                text:'7',
                tooltip:'7 neue Aufgaben'
              },
              

              
              {
                xtype:'tbspacer', itemId:'spacer', 
                height: extVia.constants.raster.northHeight ? extVia.constants.raster.northHeight : 36
              }
                
              
          ]
     });
       
 
  
    }
    // ------ End navigationbar ------ //
  },
  
  
  
    themes:[
      

      {text:'classic', itemId:'classic', name: 'ext-all', bodyCls:'xty_body', iconCls:'xty_btn-classic-theme'},      
      {text:'gray', itemId:'gray', name: 'ext-all-gray', bodyCls:'xty_body-light', iconCls:'xty_btn-gray-theme'},      
      {text:'access', itemId:'access', name: 'ext-all-access', bodyCls:'xty_body-dark' , iconCls:'xty_btn-access-theme'},      
      {text:'azzurra', itemId:'azzurra', name: 'azzurra', bodyCls:'xty_body-light', iconCls:'xty_btn-azzurra-theme'},      
      {text:'carbon', itemId:'carbon', name: 'carbon', bodyCls:'xty_body-dark', iconCls:'xty_btn-carbon-theme'}   
 
    ],
  
    getCurrentThemeCfg: function(){
      var themeCfg;
      var themeSheet  = extVia.ui.page.raster.getCurrentThemeSheet();
      var themeId = themeSheet.getAttribute('themeId');
      
      var i;
      for (i = 0; i < extVia.ui.page.raster.themes.length; i++){
        themeCfg = extVia.ui.page.raster.themes[i];
        if (themeSheet.href.indexOf(themeCfg.name+'.css')>-1){
          return themeCfg;
        } 
      }
      return themeCfg;
    },
    
    initTheme: function(themeCfg){
      
      extVia.ui.page.raster.initBodyClsFromTheme(themeCfg);
      
      var themeSheetFolder ='resources/css/';
      var themeSheet  = extVia.ui.page.raster.getCurrentThemeSheet();
      
      themeSheet.setAttribute('themeId',themeCfg.itemId);
      
      
      if (themeCfg.name === 'azzurra'){
        themeSheet.href= '../../../' + themeSheetFolder +themeCfg.name +'.css';
        
        
//     <link rel="stylesheet" type="text/css" href="../../../resources/css/azzurra-core.css" />
//     <link rel="stylesheet" type="text/css" href="../../../resources/css/azzurra-ui-all.css" />    
//     <script type="text/javascript" src="../../../resources/themes/azzurra.js"></script> -->
//            <script type="text/javascript" src="../../../resources/themes/azzurra.js"></script> -->

        
        
        
        
        
        
        
      }
      else{
       themeSheet.href= '../../../' + themeSheetFolder +themeCfg.name +'.css';
       
      }
      
      
      
    },
    
    
    initBodyClsFromTheme: function(themeCfg){
      var body = Ext.getBody();
      body.removeCls('xty_body-light xty_body-dark xty_body');
      body.addCls(themeCfg.bodyCls);
      body.removeCls('xty_classic-theme xty_gray-theme xty_access-theme xty_carbon-theme xty_azzurra-theme');
      body.addCls('xty_'+themeCfg.itemId+'-theme');
    },    
    
    getCurrentThemeSheet: function(){
      var themeSheetFolder ='resources/css/';
      var themeSheet = document.getElementById('theme');
      if (!themeSheet){
        var linkArr = document.getElementsByTagName("head")[0].getElementsByTagName("link");
        var i;
        for ( i = 0; i < linkArr.length; i++){
          var link = linkArr[i];
          if (link.href.indexOf(themeSheetFolder)>-1){
            themeSheet = link; 
          } 
        }
      }
      return themeSheet;
    },
  
    
    getAzzurraScript: function(){
      var themeSheetFolder ='resources/css/';
      var azzurraScript = document.getElementById('azzurraLink');
      if (!azzurraScript){
        var scriptArr = document.getElementsByTagName("head")[0].getElementsByTagName("script");
        var i;
        for (i = 0; i < scriptArr.length; i++){
          var script = scriptArr[i];
          if (script.href.indexOf(themeSheetFolder)>-1){
            azzurraScript = script; 
          } 
        }
      }
      return azzurraScript;
    },
    
    
  
    reloadPage :  function(param){
      var newHref = location.href;
      var sepa = '';

      if (param){
	      if (location.href.indexOf('?')===-1){
            sepa ='?';
	      }
          else if (location.href.indexOf('&')===-1){
            sepa ='&';
          }
	      
          var paramName = param.split('=')[0];
          if (location.href.indexOf(paramName+'=')===-1){
	        newHref+= sepa+param; 
	      }
	      else{
          var paramX = new RegExp(paramName+'=.[^&]*');
	        newHref = newHref.replace(paramX, param);
	      }
     }
     location.href = newHref;
   },
  

  
  /**
   * Inits main Region TabPanel with id panel_m{r}Tabs. {r} is the first Char of the region.
   * @param region {String}
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initMainRegionTabPanel : function initMainRegionTabPanel(region, tabCfg){
       
      var regionChar = region.substring(0,1).toLowerCase();
      var id = "panel_m"+regionChar+"Tabs";
      
      var cfg =  {
              activeTab: 0,
              id:id,
              itemId:id,
              border:false,
              addAndActivate:function(tabCfg){    
                 var tab = this.getComponent(tabCfg.itemId);
                 
                 if (! tab){
                     tab =  this.add(tabCfg);
                 }
                 this.setActiveTab(tab);
                 if (this.ownerCt.collapsed){
                     this.ownerCt.expand();
                     this.ownerCt.doLayout();
                 } 
                return tab;  
              },
              addUnique:function(tabCfg){     
                     var tab = this.getComponent(tabCfg.itemId);
                     if (! tab){
                         tab =  this.add(tabCfg);
                     } 
                    return tab;  
                  },
              defaults :{
                  border:false,
                  bodysPadding: 10
              }
      };
         
      Ext.apply(cfg, tabCfg);
      cfg.tabBar ={cls:'xty_regiontabpanel-tabbar xty_tabbar-noborder-rl'};

      if (tabCfg && tabCfg.tabBar  && tabCfg.tabBar.tools){
        cfg.tabBar.tools = tabCfg.tabBar.tools;
      }
      
      
      var regionTabPan = Ext.createWidget('tabpanel', cfg  ); 
      extVia.ui.page.BaseRaster[region+"TabPanel"] =  regionTabPan;
      return regionTabPan;
  },
  
  
  createModulePanel : function createModulePanel(cfg){  
    
     var title = cfg.title; //(cfg && cfg.title) ? cfg.title : 'Module';  
     var pgjobDscr = (cfg && cfg.pgjobDscr) ? cfg.pgjobDscr : title ;
  
     var  pgjobButtons = (cfg&& cfg.tbar && cfg.tbar.items)?cfg.tbar.items:null;
     
     var modulePanel = Ext.create('Ext.panel.Panel', {
      layout : 'fit',
      title: title,
      cls:'xty_modulePanel-bin',
      tabConfig: {
            iconCls:'xty_module-home',
            cls:'xty_ modulePanel-tabitem',
            style:(cfg && cfg.showTabItem)?'':'display:none;'
        },
      tbar :   extVia.ui.page.pagejob.getPagejobBar({pgjobDscr: pgjobDscr ,pgjobButtons: pgjobButtons}),
      id : 'mcModulePanel',
      border:cfg.border,
      style:cfg.style,
      html:cfg.html,
      listeners:cfg.listeners,
      items:cfg.items,
      itemId : 'modulePanel',
      myApp : extVia.regApp.id,
      toolscope : '-'
    });
    return modulePanel;    
    },
  
  /**
   * Inits centerTabPanel with id panel_mcTabs
   * 
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initCenterTabPanel : function initCenterTabPanel(tabCfg){ 
      
    if (!tabCfg){tabCfg={};}
    tabCfg.tabBar = Ext.apply(this.getTabBarCfg(),tabCfg.tabBar );   
    
    var centerTabPanel = this.initMainRegionTabPanel("center", tabCfg);
    
  
    var onTabPanelCenterChange = function(tab, newcard, oldcard, obj) {
      if (tab.tabBar && tab.tabBar.handleTabChange)  {
        tab.tabBar.handleTabChange(newcard,tab.tabBar ); 
      }
    };  
    centerTabPanel.mon(centerTabPanel, 'tabchange', onTabPanelCenterChange);  
  
    if (tabCfg.modulePanelCfg){
     extVia.regApp.modulePanel = this.createModulePanel(tabCfg.modulePanelCfg);
     centerTabPanel.add(extVia.regApp.modulePanel);
    }
    

  
    centerTabPanel.on('add', function(tabPanel, component, index, eOpts){
        if(extVia.regApp.myRaster.mainCenter.modulPagejob){
            extVia.regApp.myRaster.mainCenter.modulPagejob.hide();  
        }
    });

    centerTabPanel.on('remove', function(tabPanel, component, eOpts){
        if(tabPanel.items.length===0 && extVia.regApp.myRaster.mainCenter.modulPagejob){
            extVia.regApp.myRaster.mainCenter.modulPagejob.show();  
        }   
     });

     return centerTabPanel;
  },
 
  /**
   * Inits westTabPan with id panel_mwTabs
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initWestTabPanel : function initWestTabPanel(tabCfg){
   
    
    var striptools;
    if (tabCfg && tabCfg.tabBar && tabCfg.tabBar.tools){
      striptools = tabCfg.tabBar.tools;
    }
    
    
    if (!tabCfg){tabCfg={};}  
    tabCfg.tabBar = Ext.apply(this.getTabBarCfg(),tabCfg.tabBar );   
    
    if (striptools){
        tabCfg.tabBar.tools = striptools;
    }


    var onTabPanelWestChange = function(tab, newcard, oldcard, obj) {
      
    if (tab.tabBar && tab.tabBar.handleTabChange)  {
      tab.tabBar.handleTabChange(newcard,tab.tabBar ); 
    }
    var modulePanel =  extVia.regApp.modulePanel;
    if (modulePanel){
      var pgjobDscr = extVia.regApp.getModulePagejobDscr ? extVia.regApp.getModulePagejobDscr(newcard) : newcard.title; 
      modulePanel.getComponent('pagejobbar').setPagejobDscr(pgjobDscr);
     }
    };    
    var tabPanelWest = this.initMainRegionTabPanel("west", tabCfg);
    tabPanelWest.mon(tabPanelWest, 'tabchange', onTabPanelWestChange);  
    return tabPanelWest;
  },
  
  /**
   * Inits eastTabPan with id panel_mwTabs
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initEastTabPanel : function initEastTabPanel(tabCfg){
      return this.initMainRegionTabPanel("east", tabCfg);
  },  
  
  
  /**
   * Gets main Region TabPanel with id panel_m{r}Tabs. {r} is the first Char of the region.
   * @param region {String}
   * @returns TabPanel {Component}
   */
  getMainRegionTabPanel : function getMainRegionTabPanel(region, regionPan){
      var regionTabPan  = extVia.ui.page.BaseRaster[region+"TabPanel"];
      return regionTabPan;
  },
  
  /**
   * Gets centerTabPanel with id panel_mcTabs.
   * @returns TabPanel {Component}
   */
  getCenterTabPanel : function getCenterTabPanel(){ return this.getMainRegionTabPanel("center");},
  /**
   * Gets westTabPanel with id panel_mwTabs.
   * @returns TabPanel {Component}
   */
  getWestTabPanel : function getWestTabPanel(){ return this.getMainRegionTabPanel("west");},
  /**
   * Gets eastTabPanel with id panel_meTabs.
   * @returns TabPanel {Component}
   */
  getEastTabPanel : function getEastTabPanel(){ return this.getMainRegionTabPanel("east");},
  /**
   * Gets southTabPanel with id panel_msTabs.
   * @returns TabPanel {Component}
   */
  getSouthTabPanel : function getSouthTabPanel(){  return this.getMainRegionTabPanel("south");},
  
  showMainCenterMessageMask : function showMainCenterMessageMask(bShow, sMessage) {
    return this.showMainRegionMessageMask("Center", bShow, sMessage);
  },
  
  
  /**
   * 
   * @param region
   * @param bShow
   * @param sMessage
   */
  showMainRegionMessageMask : function showMainRegionMessageMask(region, bShow, sMessage, cfg) {

    if (!region ) {region = "Center";}
    var regionCmp = this["main"+region]; 
    if (region==="viewport") { regionCmp = Ext.getBody();}
      
      if (bShow) {  
          
        var defCfg ={msg : sMessage,removeMask : true};  
        if (cfg){
            Ext.apply(defCfg, cfg);
        } 

        regionCmp.loadingMask = regionCmp.loadingMask || new Ext.LoadMask(regionCmp.id, defCfg);
        regionCmp.loadingMask.show();
        } else {
          // delay the loading mask switch off to prevent flash the loading mask if a function is lightning fast.
          var func = Ext.bind(function() {
             regionCmp.loadingMask.hide();
          }, this);
          Ext.defer(func, 1000);
        }
      return regionCmp.loadingMask;
      },
  

  
  /**
   * Adds Component to viewports border-Layout center Panel
   * @param oObject
   */
  addToCenter : function addToCenter(oObject) {
    return this.mainCenter.add(oObject);
  }
  ,
  /**
   * Adds Component to viewports border-Layout north Panel
   * @param oObject
   */
  addToNorth : function addToNorth(oObject) {
      if (this.mainNorth){
         return  this.mainNorth.add(oObject);
      }  
  },
  /**
   * Adds Component to viewports border-Layout west Panel
   * @param oObject
   */
  addToWest : function addToWest(oObject) {
    if (this.mainWest){
      return this.mainWest.add(oObject);    
    }
  },
  /**
   * Adds Component to viewports border-Layout east Panel
   * @param oObject
   */ 
  addToEast : function addToEast(oObject) {
    if (this.mainEast) {
        return  this.mainEast.add(oObject);
    }
  },
  /**
   * Adds Component to viewports border-Layout south Panel
   * @param oObject
   */
  addToSouth : function addToSouth(oObject) {
      if (this.mainSouth){
          return  this.mainSouth.add(oObject);  
      } 
  },
  
  
   getCenterRight : function getCenterRight() {
    return this.mainCenter.getEl().getRight(); 
   },
  
  
  /**
   * Returns viewports border-Layout center Panel
   * @returns Panel
   */
  getCenter : function getCenter() {return this.mainCenter; },
  /**
   * Returns viewports border-Layout west Panel
   * @returns Panel
   */
  getWest : function getWest() {return this.mainWest; }, 
  /**
   * Returns viewports border-Layout north Panel
   * @returns Panel
   */
  getNorth : function getNorth() {return this.mainNorth; }, 
  /**
   * Returns viewports border-Layout east Panel
   * @returns Panel
   */
  getEast : function getEast() {return this.mainEast; }, 
  /**
   * Returns viewports border-Layout south Panel
   * @returns Panel
   */
  getSouth : function getSouth() {return this.mainSouth; },
  
  
   getUrlParams : function getUrlParams() {
      var qStr = location.href.replace(/.[^\?]*\?/,'');
      var urlParams = Ext.Object.fromQueryString(qStr);
      return urlParams;
  },
  /*
   * Looks for regions Param in Url. Sets border-region-flags for upperCase chars (hideNorth:false for N, hideWest:false for W, buildEast:true for E, buildSouth:true for S)
   * @returns Object
   */
  getViewConfigFromUrl : function getViewConfigFromUrl() {
        var qStr = location.href.replace(/.[^\?]*\?/,'');
        var viewCfg = {hideNorth:false,hideWest:false, buildEast:false, buildSouth:false};
        var urlParams = Ext.Object.fromQueryString(qStr);
        if (urlParams.regions){
            if (urlParams.regions.indexOf("N")===-1){viewCfg.hideNorth=true;}
            if (urlParams.regions.indexOf("W")===-1){viewCfg.hideWest=true;}
            if (urlParams.regions.indexOf("E")>-1){viewCfg.buildEast=true;}
            if (urlParams.regions.indexOf("S")>-1){viewCfg.buildSouth=true;}
        }
      return viewCfg;
  },
  
  getRoutingConfigFromUrl : function getRoutingConfigFromUrl() {

     function capitalizeFirstLetter(string) {
       return string.charAt(0).toUpperCase() + string.slice(1);
     }
     function evenSeperator(routeStr) {
       //routeStr = routeStr.replace(/=/,'/'); // jslint does not like this 
       var equalX = new RegExp("=");
       routeStr = routeStr.replace(equalX,'/');
       routeStr = routeStr.replace(/:/,'/');
       return routeStr;
     }
     
      var routingCfg = null;
      var url = location.href;
      if (url.indexOf('#')>-1){
          var routeStr = url.replace(/.[^\#]*\#/,'');
          if  (!Ext.isEmpty(routeStr) ){
            routingCfg = {};
            var routes = routeStr.split('#');
            routingCfg.routes = routes;
            if  (!Ext.isEmpty(routes[0])){
               routes[0] = evenSeperator(routes[0]); 
               var loadArr = routes[0].split('/'); 
               if (loadArr.length===1){
                routingCfg.loadType = 'Product';
                routingCfg.loadId = loadArr[0];
               }else{
                 routingCfg.loadType = (!Ext.isEmpty(loadArr[0]) ) ? capitalizeFirstLetter(loadArr[0]) : 'Product';
                 routingCfg.loadId = (!Ext.isEmpty(loadArr[1]) ) ? loadArr[1] : '*';
               }    
               
            }
            if  (!Ext.isEmpty(routes[1])){
               routes[1] = evenSeperator(routes[1]); 
               var subloadArr = routes[1].split('/');
               if (subloadArr.length===1){
                routingCfg.subloadType = 'tab';
                routingCfg.subloadId = subloadArr[0];
               }
               else{
                routingCfg.subloadType = subloadArr[0];
                routingCfg.subloadId = subloadArr[1];
               } 
            } 
          } 
      }
    return routingCfg;
  },
  
  

  getTabBarCfg : function getTabBarCfg(cfg) {  
   return {
      handleTabChange: function(newcard, tabBar){
       var tabBarItemsLen =0;
       if (tabBar.items){tabBarItemsLen = tabBar.items.length;}
       var i;
       for(i =0; i<tabBarItemsLen; i++){
        var tabBarItem = tabBar.items.get(i);
        if (tabBarItem && tabBarItem.isStriptoolButton){
          if(newcard && newcard[tabBarItem.itemId]){tabBarItem.show();}
          else{tabBarItem.hide();}
        }
       }
      },
      items:[
        {xtype: 'tbfill'},
        this.getStriptoolButton({itemId:'moveHoriz',hidden:true}),
        this.getStriptoolButton({itemId:'refresh'}),
        this.getStriptoolButton({itemId:'preferences',hidden:true})
      ]
   };
  },
  
  getStriptoolButton : function getStriptoolButton(cfg) {           
    var striptoolButtonHandler = function(btn,e){ 
      var acttab =  btn.up('tabpanel').getActiveTab();
        if (acttab[btn.itemId]){
          try {
           acttab[btn.itemId]();
          } catch (oEx) {extVia.notify('BaseRaster.activeTab['+acttab.title+']#'+btn.itemId+"\n"+oEx);}
        }
        else{
          extVia.notify(btn.itemId + " not avilable on "+acttab.title) ;
        }
     };

    var btnCfg =  {
      xtype:'button', 
      cls:'xty_striptool-button', 
      isStriptoolButton:true,
      handler:striptoolButtonHandler,
      tooltip:'resKey: '+cfg.itemId,
      iconCls:'xty_button-tool xty_button-tool-'+cfg.itemId,
      height:22   
    };
    Ext.apply(btnCfg, cfg);
    return btnCfg;
  },    
    
  
  // >>> START copied from V3.8 extVia.ui.layout.factory. 18.01.2013 <<<  
  /**
   * Returns measuredTitles for Tabs which are not wider than 160px, if so they have an ellipsis(...)<br>
   * to add a tab tooltip with the original long text, use the following in the tab panel item config:<br>
   * 
   *       tabConfig: {<br>
   *         tooltip: longTitle<br>
   *       },<br>
   * 
   * @param title
   * @param region
   */
  getMeasuredTabTitle: function(title, region) {
    var center_tabItemMaxWidth = 150;// todo: get  from currentLayoutConfig
    //return extVia.ui.layout.factory.getMeasuredText(title, center_tabItemMaxWidth, "x-tab") ; 
    return extVia.regApp.myRaster.getMeasuredText(title, center_tabItemMaxWidth, "x-tab") ; 
  },
  
  /**
   * Returns measuredText with is cutted and added an ellipsis(...), if wider thean given maxWidth
   * @param text
   * @param maxWidth
   * @param targetCls
   */  
  getMeasuredText: function(text, maxWidth, targetCls) {
        var measuredText = text;
        var fullWidth = extVia.regApp.myRaster.getTextMetricsWidth(text, targetCls);
        if (fullWidth>maxWidth){
          var diff = fullWidth - maxWidth;
          var diffProz = diff/fullWidth;
          var textLen = text.length;
          var strLenRounded = Math.round(textLen - (textLen * diffProz));
          //measuredText = text.substring(0, strLen_n)+'...';    
          measuredText = Ext.String.ellipsis(text, strLenRounded);
        }
        return measuredText;
      },
    /**
   * Will be used by  {@link extVia.regApp.myRaster.getTextMetricsWidth} or {@link extVia.regApp.myRaster.getTextMetricsHeight},
   */  
  textMetricsInstances: [],
   /**
   * Will be used by  {@link extVia.regApp.myRaster.getTextMetricsWidth} or {@link extVia.regApp.myRaster.getTextMetricsHeight},
   * Represents the div-classes these UI-Element are to be measured in.
   */  
  textMetricsEtys: null,
  /**
   * maps ety to cssclasses, for text measuring
   */
  textMetricsEtysInit: function ()  { 
      extVia.regApp.myRaster.textMetricsEtys=[];
      extVia.regApp.myRaster.textMetricsEtys["_"+extVia.ui.dto.ety.NOTIFICATION] ="x-window-mc";
      extVia.regApp.myRaster.textMetricsEtys["_"+extVia.ui.dto.ety.BUTTON] ="x-btn-text";
      extVia.regApp.myRaster.textMetricsEtys["_"+extVia.ui.dto.ety.MENU] ="x-menu-item-text";
  },
  
   /**      
   * Returns the measured width of the specified text.
   * Uses Ext.util.TextMetrics.createInstance({@link extVia.regApp.myRaster.textMetricsDefaultInst})
   * @param {String} text The text to measure
   * @param {Number| String} etyCls The target-UI-Element to be measured in
   * @return {Number} width The width in pixels
   */     
    getTextMetricsWidth: function (text, etyCls)  { 

      //extVia.regApp.myRaster.getTextMetricsWidth("Eins zwei drei VIEEEERRRRRRR fuenf",extVia.ui.dto.ety.NOTIFICATION)

      if (!extVia.regApp.myRaster.textMetricsEtys){
        //Ext.Msg.alert("Message", "textMetricsEtysInit");
        extVia.regApp.myRaster.textMetricsEtysInit();
      }  
        
      if (Ext.isEmpty(extVia.regApp.myRaster.textMetricsInstances["_"+etyCls])){
        var div  = document.createElement("div");
        var cls ;
        
        if (extVia.regApp.myRaster.textMetricsEtys["_"+etyCls]){
         cls = extVia.regApp.myRaster.textMetricsEtys["_"+etyCls];
        }else{
          cls = etyCls; 
        }
        
        div.setAttribute("class",cls);
        extVia.regApp.myRaster.textMetricsInstances["_"+etyCls] =  new Ext.util.TextMetrics( div  );
      }
     
      var currInst =  extVia.regApp.myRaster.textMetricsInstances["_"+etyCls];
        
      if (currInst){
       return currInst.getWidth(text);
      }else{
        return -1; 
      }
    }
  // >>> END copied from V3.8 extVia.ui.layout.factory. 18.01.2013 <<<  
  
  
  
};

