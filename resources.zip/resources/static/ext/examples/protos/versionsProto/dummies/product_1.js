extVia.versionsProto.product_1 = 
[
// Metadata areaorder: 1              
{"name":"Hierarchie","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Akkuger\u00E4te  \u00bb Dummies","userWork":"Douglas Crockford","changedateWork":"06.02.2014","changetimeWork":"11:03:14","valueVersion":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Stichs&auml;ge","userVersion":"Paul Coelho","changedateVersion":"06.02.2014","changetimeVersion":"11:03:23","epimIdWork":"ms_h-2","epimIdVersion":"ms_h-2"},                    
{"name":"Name","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Product 1","userWork":"Lars Hinrichs","changedateWork":"05.02.2014","changetimeWork":"16:32:23","valueVersion":"Product 1","userVersion":"Doug Engelbart","changedateVersion":"05.02.2014","changetimeVersion":"16:32:27","epimIdWork":"ms_n-1","epimIdVersion":"ms_n-1"},
{"name":"Id","area":"Metadata","areaorder":"?","dataType":"Number","valueWork":"1","userWork":"Douglas Crockford","changedateWork":"05.02.2014","changetimeWork":"16:30:26","valueVersion":"1","userVersion":"Douglas Crockford","changedateVersion":"05.02.2014","changetimeVersion":"16:30:26","epimIdWork":"mn_i-1","epimIdVersion":"mn_i-1"},

];

