extVia.versionsProto.Metabo_Power_Maxx_Li_Pro = 
[
// Metadata areaorder: 1              
{"name":"Hierarchie","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Akkuger\u00E4te  \u00bb Akku-Bohrschrauber","userWork":"Douglas Crockford","changedateWork":"06.02.2014","changetimeWork":"11:03:14","valueVersion":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Stichs&auml;ge","userVersion":"Paul Coelho","changedateVersion":"06.02.2014","changetimeVersion":"11:03:23","epimIdWork":"ms_h-2","epimIdVersion":"ms_h-2"},                    
{"name":"Name","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"product_2","userWork":"Lars Hinrichs","changedateWork":"05.02.2014","changetimeWork":"16:32:23","valueVersion":"Metabo STEb","userVersion":"Doug Engelbart","changedateVersion":"05.02.2014","changetimeVersion":"16:32:27","epimIdWork":"ms_n-1","epimIdVersion":"ms_n-1"},
{"name":"Id","area":"Metadata","areaorder":"1","dataType":"Number","valueWork":"2837","userWork":"Douglas Crockford","changedateWork":"05.02.2014","changetimeWork":"16:30:26","valueVersion":"2","userVersion":"Douglas Crockford","changedateVersion":"05.02.2014","changetimeVersion":"16:30:26","epimIdWork":"mn_i-1","epimIdVersion":"mn_i-1"},
{"name":"Mastersprache","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Deutsch","userWork":"Steve Krug","changedateWork":"06.02.2014","changetimeWork":"11:01:06","valueVersion":"Deutsch","userVersion":"Steve Krug","changedateVersion":"06.02.2014","changetimeVersion":"11:01:06","epimIdWork":"ms_m-1","epimIdVersion":"ms_m-1"},
{"name":"Letzte \u00c4nderung","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"John Bonham - 06.02.2014","userWork":"John Bonham","changedateWork":"06.02.2014","changetimeWork":"11:13:07","valueVersion":"Klausbernd Vollmar - 02.02.2014","userVersion":"Klausbernd Vollmar","changedateVersion":"02.02.2014","changetimeVersion":"11:13:43","epimIdWork":"ms_l-2","epimIdVersion":"ms_l-2"},

//Workflows areaorder: 2 
{"name":"Katalog","area":"Workflows","areaorder":"2","dataType":"WorkflowState","valueWork":"Freigegeben","userWork":"Oscar Wilde","changedateWork":"06.02.2014","changetimeWork":"10:46:46","valueVersion":"In Bearbeitung","userVersion":"Ringo Starr","changedateVersion":"06.02.2014","changetimeVersion":"10:47:19","epimIdWork":"ww_k-5","epimIdVersion":"ww_k-5"},

//ChangeInfo areaorder: 3 
{"name":"Letzte \u00c4nderung","area":"ChangeInfo","areaorder":"3","dataType":"Changeinfo","valueWork":"John Bonham - 06.02.2014","userWork":"John Bonham","changedateWork":"06.02.2014","changetimeWork":"11:13:07","valueVersion":"Klausbernd Vollmar - 02.02.2014","userVersion":"Klausbernd Vollmar","changedateVersion":"02.02.2014","changetimeVersion":"11:13:43","epimIdWork":"cc_l-3","epimIdVersion":"cc_l-3"},
{"name":"Anlage","area":"ChangeInfo","areaorder":"3","dataType":"Changeinfo","valueWork":"John Bonham - 05.01.2014","userWork":"Susanne Fischer-Rizzi","changedateWork":"05.01.2014","changetimeWork":"11:16:12","valueVersion":"John Bonham - 05.01.2014","userVersion":"Susanne Fischer-Rizzi","changedateVersion":"05.01.2014","changetimeVersion":"11:16:12","epimIdWork":"cc_a-4","epimIdVersion":"cc_a-4"},

//Languages
{"name":"Sprachen","area":"Sprachen","childOrParent":"parent",  "areaorder":"1","dataType":"Language","valueWork":"de,en,us,es,it,fr","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"de,en,us,es","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5","epimIdVersion":"ml_s-5"},
{"name":"Sprach&auml;nderung","area":"Sprachen","childOrParent":"child",  "specprop-parentId":"ml_s-5", "areaorder":"1","dataType":"Language","valueWork":"es,fr","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"de,es","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5c","epimIdVersion":"ml_s-5c"},
{"name":"&Uuml;bersetzungen","area":"Sprachen","childOrParent":"lastchild",  "specprop-parentId":"ml_s-5", "areaorder":"1","dataType":"Language","valueWork":"en,us","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"en,us","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5c","epimIdVersion":"ml_s-5c"},


];

