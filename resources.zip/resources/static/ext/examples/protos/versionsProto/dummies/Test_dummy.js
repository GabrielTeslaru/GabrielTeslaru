extVia.versionsProto.Test_dummy = 
[
// Metadata areaorder: 1              
{"name":"Hierarchie","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Akkuger\u00E4te  \u00bb Akku-Bohrschrauber","userWork":"Douglas Crockford","changedateWork":"06.02.2014","changetimeWork":"11:03:14","valueVersion":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Stichs&auml;ge","userVersion":"Paul Coelho","changedateVersion":"06.02.2014","changetimeVersion":"11:03:23","epimIdWork":"ms_h-2","epimIdVersion":"ms_h-2"},                    
{"name":"Name","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Test Dummy","userWork":"Lars Hinrichs","changedateWork":"05.02.2014","changetimeWork":"16:32:23","valueVersion":"Test Dummie","userVersion":"Doug Engelbart","changedateVersion":"05.02.2014","changetimeVersion":"16:32:27","epimIdWork":"ms_n-1","epimIdVersion":"ms_n-1"},
{"name":"Id","area":"Metadata","areaorder":"1","dataType":"Number","valueWork":"1","userWork":"Douglas Crockford","changedateWork":"05.02.2014","changetimeWork":"16:30:26","valueVersion":"1","userVersion":"Douglas Crockford","changedateVersion":"05.02.2014","changetimeVersion":"16:30:26","epimIdWork":"mn_i-1","epimIdVersion":"mn_i-1"},
{"name":"Mastersprache","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Deutsch","userWork":"Steve Krug","changedateWork":"06.02.2014","changetimeWork":"11:01:06","valueVersion":"Deutsch","userVersion":"Steve Krug","changedateVersion":"06.02.2014","changetimeVersion":"11:01:06","epimIdWork":"ms_m-1","epimIdVersion":"ms_m-1"},
{"name":"Letzte \u00c4nderung","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"John Bonham - 06.02.2014","userWork":"John Bonham","changedateWork":"06.02.2014","changetimeWork":"11:13:07","valueVersion":"Klausbernd Vollmar - 02.02.2014","userVersion":"Klausbernd Vollmar","changedateVersion":"02.02.2014","changetimeVersion":"11:13:43","epimIdWork":"ms_l-2","epimIdVersion":"ms_l-2"},

//Workflows areaorder: 2 
{"name":"Katalog","area":"Workflows","areaorder":"2","dataType":"WorkflowState","valueWork":"Freigegeben","userWork":"Oscar Wilde","changedateWork":"06.02.2014","changetimeWork":"10:46:46","valueVersion":"In Bearbeitung","userVersion":"Ringo Starr","changedateVersion":"06.02.2014","changetimeVersion":"10:47:19","epimIdWork":"ww_k-5","epimIdVersion":"ww_k-5"},

//ChangeInfo areaorder: 3 
{"name":"Letzte \u00c4nderung","area":"ChangeInfo","areaorder":"3","dataType":"Changeinfo","valueWork":"John Bonham - 06.02.2014","userWork":"John Bonham","changedateWork":"06.02.2014","changetimeWork":"11:13:07","valueVersion":"Klausbernd Vollmar - 02.02.2014","userVersion":"Klausbernd Vollmar","changedateVersion":"02.02.2014","changetimeVersion":"11:13:43","epimIdWork":"cc_l-3","epimIdVersion":"cc_l-3"},
{"name":"Anlage","area":"ChangeInfo","areaorder":"3","dataType":"Changeinfo","valueWork":"John Bonham - 05.01.2014","userWork":"Susanne Fischer-Rizzi","changedateWork":"05.01.2014","changetimeWork":"11:16:12","valueVersion":"John Bonham - 05.01.2014","userVersion":"Susanne Fischer-Rizzi","changedateVersion":"05.01.2014","changetimeVersion":"11:16:12","epimIdWork":"cc_a-4","epimIdVersion":"cc_a-4"},

//Languages
{"name":"Sprachen","area":"Sprachen","childOrParent":"parent",  "areaorder":"1","dataType":"Language","valueWork":"de,en,us,es,it,fr","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"de,en,us,es","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5","epimIdVersion":"ml_s-5"},
{"name":"Sprach&auml;nderung","area":"Sprachen","childOrParent":"child",  "specprop-parentId":"ml_s-5", "areaorder":"1","dataType":"Language","valueWork":"es,fr","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"de,es","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5c","epimIdVersion":"ml_s-5c"},
{"name":"&Uuml;bersetzungen","area":"Sprachen","childOrParent":"lastchild",  "specprop-parentId":"ml_s-5", "areaorder":"1","dataType":"Language","valueWork":"en,us","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"en,us","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5c","epimIdVersion":"ml_s-5c"},


//Attribute areaorder: 4 
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"String","multiplicity":"3","valueWork":"DSL","userWork":"Lisa Kekaula","changedateWork":"05.02.2014","changetimeWork":"16:33:06","valueVersion":"DSL","userVersion":"Lisa Kekaula","changedateVersion":"05.02.2014","changetimeVersion":"16:33:06","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"String","multiplicity":"3","valueWork":"WLAN","userWork":"Lisa Kekaula","changedateWork":"05.02.2014","changetimeWork":"16:33:06","valueVersion":"WLAN","userVersion":"Lisa Kekaula","changedateVersion":"05.02.2014","changetimeVersion":"16:33:06","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"String","multiplicity":"3","valueWork":"VoIP","userWork":"Lisa Kekaula","changedateWork":"05.02.2014","changetimeWork":"16:33:06","valueVersion":"VoIP","userVersion":"Lisa Kekaula","changedateVersion":"05.02.2014","changetimeVersion":"16:33:06","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"Selection","multiplicity":"3","valueWork":"DSL","userWork":"Ringo Starr","changedateWork":"05.02.2014","changetimeWork":"16:33:39","valueVersion":"ISDN","userVersion":"Clemens Lutsch","changedateVersion":"05.02.2014","changetimeVersion":"16:34:00","epimIdWork":"as_z-3","epimIdVersion":"as_z-3"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"Selection","multiplicity":"3","valueWork":"WLAN","userWork":"Ringo Starr","changedateWork":"05.02.2014","changetimeWork":"16:33:39","valueVersion":"LAN","userVersion":"Clemens Lutsch","changedateVersion":"05.02.2014","changetimeVersion":"16:34:00","epimIdWork":"as_z-3","epimIdVersion":"as_z-3"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"Selection","multiplicity":"3","valueWork":"VoIP","userWork":"Ringo Starr","changedateWork":"05.02.2014","changetimeWork":"16:33:39","epimIdWork":"as_z-3"},


// prat coll id ac_z-1
{"name":"Rezept","area":"Attribute","areaorder":" 4","childOrParent":"parent",  "dataType":"Collection","multiplicity":"1","valueWork":"Rezept","userWork":"Keith Moon","changedateWork":"07.10.2013","changetimeWork":"17:47:14","valueVersion":"Rezept","userVersion":"Keith Moon","changedateVersion":"07.10.2013","changetimeVersion":"17:47:14","epimIdWork":"ac_z-1","epimIdVersion":"ac_z-1"},
//entries:
	{"name":"Zutat","area":"Attribute","areaorder":" 4","dataType":"String","multiplicity":"1",
	 "childOrParent":"child", "specprop-parentId":"ac_z-1",
	"valueWork":"Zucker","userWork":"Douglas Crockford","changedateWork":"06.02.2014","changetimeWork":"17:49:53","valueVersion":"Zucker","userVersion":"Douglas Crockford","changedateVersion":"06.02.2014","changetimeVersion":"17:49:53","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},

	
	{"name":"Menge","area":"Attribute","areaorder":" 4","dataType":"Number","multiplicity":"1",
		"childOrParent":"lastchild", 
		"specprop-parentId":"ac_z-1",
		"valueWork":"100g","userWork":"Bernard Purdie","changedateWork":"07.02.2014","changetimeWork":"10:49:53","valueVersion":"150g","userVersion":"Bernard Purdie","changedateVersion":"06.02.2014","changetimeVersion":"19:49:53","epimIdWork":"as_z-3a","epimIdVersion":"as_z-3a"},
	
		{"name":"Einheit Mengenangaben","area":"Attribute","areaorder":" 4","dataType":"String","childOrParent":"child","specprop-parentId":"ac_z-1","specprop-multiplicity":"2","specprop-link":"","valueWork":"Gramm","userWork":"John Bonham","changedateWork":"12.02.2014","changetimeWork":"11:27:58","valueVersion":"Kilogramm","userVersion":"John Bonham","changedateVersion":"12.02.2014","changetimeVersion":"02:00:00","epimIdWork":"an_m-2","epimIdVersion":"an_m-2"},	
		{"name":"Einheit Mengenangaben","area":"Attribute","areaorder":" 4","dataType":"String","childOrParent":"child","specprop-parentId":"ac_z-1","specprop-multiplicity":"2","specprop-link":"","valueWork":"Liter","userWork":"John Bonham","changedateWork":"12.02.2014","changetimeWork":"11:27:58","valueVersion":"Liter","userVersion":"John Bonham","changedateVersion":"12.02.2014","changetimeVersion":"11:27:58","epimIdWork":"an_m-2a","epimIdVersion":"an_m-2a"},
		{"name":"Einheit Mengenangaben","area":"Attribute","areaorder":" 4","dataType":"String","childOrParent":"child","specprop-parentId":"ac_z-1","specprop-multiplicity":"2","specprop-link":"","valueWork":"St&uuml;ck","userWork":"John Bonham","changedateWork":"12.02.2014","changetimeWork":"11:27:58","valueVersion":"St&uuml;ck","userVersion":"John Bonham","changedateVersion":"12.02.2014","changetimeVersion":"11:27:58","epimIdWork":"an_m-2b","epimIdVersion":"an_m-2b"},
	
	{"name":"Zutat","area":"Attribute","areaorder":" 4","dataType":"String","multiplicity":"1",
		"childOrParent":"lastchild", 
		"specprop-parentId":"ac_z-1",
		"valueWork":"Milch","userWork":"Douglas Crockford","changedateWork":"07.02.2014","changetimeWork":"12:49:53","valueVersion":"Wasser","userVersion":"Douglas Crockford","changedateVersion":"06.02.2014","changetimeVersion":"17:49:53","epimIdWork":"as_z-3","epimIdVersion":"as_z-3"},
	
	

//Elemente areaorder: 6 
    
{"name":"Cover","area":"Elemente","areaorder":"6","dataType":"Image","specprop-link":"","valueWork":"London Calling|./dummies/infoImages/elemente/clash-london-calling.jpg","userWork":"John Bonham","changedateWork":"06.05.2014","changetimeWork":"09:52:38","valueVersion":"Kitty Calling|./dummies/infoImages/elemente/clash-london-calling_faky.jpg","userVersion":"Peter Criss","changedateVersion":"06.05.2014","changetimeVersion":"09:53:35","infoId":"elIMco2_362816"},
    
{"name":"Bild","area":"Elemente","areaorder":"6","dataType":"Image","valueWork":"","changedateWork":"","valueVersion":"Bohrer XD123","userVersion":"Jason Dorsey","changedateVersion":"05.02.2014","changetimeVersion":"18:36:08","epimIdWork":"ei_b-1","epimIdVersion":"ei_b-1"},


{"name":"Dokument","area":"Elemente","areaorder":"6","dataType":"Document","childOrParent":"parent","valueWork":"Fritzbox Handbuch","userWork":"Dieter Rams","changedateWork":"07.02.2014","changetimeWork":"13:21:34","valueVersion":"Fritzbox Handbuch","userVersion":"Dieter Rams","changedateVersion":"07.02.2014","changetimeVersion":"13:21:34","epimIdWork":"ed_d-1","epimIdVersion":"ed_d-1"},
{"name":"Changeinfo Medienobjekt","area":"Elemente","areaorder":"6","dataType":"ChangeinfoMediaObject", "childOrParent":"lastchild", "specprop-parentId":"ed_d-1","specprop-link":"","valueWork":"Bernard Purdie - 07.02.2014","userWork":"Bernard Purdie","changedateWork":"16.12.2013","changetimeWork":"13:26:45","valueVersion":"Bernard Purdie - 07.02.2014","userVersion":"Bernard Purdie","changedateVersion":"16.12.2013","changetimeVersion":"13:26:45","epimIdWork":"ec_c-2","epimIdVersion":"ec_c-2"},


{"name":"Bild","area":"Elemente","areaorder":"6","dataType":"Image",
	"specprops":"{specprop-link:'http://www.elektrowerkzeug-vergleich.de/wp-content/uploads/2012/03/Metabo-SBE-900-Impuls-im-Einsatz.jpg'}",
	"specprop-link":"http://www.elektrowerkzeug-vergleich.de/wp-content/uploads/2012/03/Metabo-SBE-900-Impuls-im-Einsatz.jpg",
	"valueWork":"SBE 900 Impuls Schlagbohrmaschine","userWork":"Clemens Lutsch","changedateWork":"07.01.2014","changetimeWork":"10:15:00","valueVersion":"SBE 900 Impuls Schlagbohrmaschine","userVersion":"Lars Hinrichs","changedateVersion":"06.02.2014","changetimeVersion":"14:43:46","epimIdWork":"ei_b-1","epimIdVersion":"ei_b-1"},

{"name":"Bild","area":"Elemente","areaorder":"6","dataType":"Image",

		"valueWork":"SBE 900 Impuls Schlagbohrmaschine|http://www.elektrowerkzeug-vergleich.de/wp-content/uploads/2012/03/Metabo-SBE-900-Impuls-im-Einsatz.jpg","userWork":"Arkadi Strugatzki","changedateWork":"06.02.2014","changetimeWork":"14:56:38",
		"valueVersion":"SBE 900 Impuls Schlagbohrmaschine|http://images.testbericht.de/produkt-images/elektrowerkzeug/XL_/metabo/schlagbohrmaschine-sbe-900-impuls-2.jpg","userVersion":"Bill Ward","changedateVersion":"06.02.2014","changetimeVersion":"14:55:31","epimIdWork":"ei_b-2","epimIdVersion":"ei_b-2"},

{"name":"Bild","area":"Elemente","areaorder":"6","dataType":"Image","valueWork":"Groovebox 505|../../img/customerImages/roland/roland%20mc505-DSC01303.png","userWork":"Doug Engelbart","changedateWork":"06.02.2014","changetimeWork":"15:15:54","valueVersion":"Groovebox 505|../../img/customerImages/roland/roland%20mc505-DSC01303.png","userVersion":"Doug Engelbart","changedateVersion":"06.02.2014","changetimeVersion":"15:15:54","epimIdWork":"ei_b-1","epimIdVersion":"ei_b-1"},		
	

{"name":"Text","area":"Elemente","areaorder":"6","dataType":"Text","specprop-link":"","valueWork":"verdamp lang her|../../img/fakes/bap_koelsch.png","userWork":"Arkadi Strugatzki","changedateWork":"07.02.2014","changetimeWork":"15:13:53","valueVersion":"verdammt lang her|../../img/fakes/bap_hochdeutsch.png","userVersion":"Esther Derby","changedateVersion":"07.02.2014","changetimeVersion":"15:13:49","epimIdWork":"et_t-4","epimIdVersion":"et_t-4"},


{"name":"Produkttabelle","area":"Elemente","areaorder":"6","dataType":"ProdTable","specprop-link":"",
	"valueWork":"Verfuegbare Groessen|../../img/fakes/versioning/prodtable_a.png","userWork":"Boris Strugatzki","changedateWork":"10.02.2014","changetimeWork":"14:57:03",
	"valueVersion":"Verf\u00fcgbare Gr\u00f6ssen|../../img/fakes/versioning/prodtable_b.png","userVersion":"Haruki Murakami","changedateVersion":"02.02.2014","changetimeVersion":"07:00:00","epimIdWork":"ep_p-1","epimIdVersion":"ep_p-1"},

	{"name":"Redaktionelle Tabelle","area":"Elemente","areaorder":"6","dataType":"EdTable","specprop-link":"",
		"valueWork":"Flyer Messe|../../img/fakes/versioning/edtable_a.png","userWork":"Boris Strugatzki","changedateWork":"10.02.2014","changetimeWork":"14:57:03",
		"valueVersion":"Flyer Messe|../../img/fakes/versioning/edtable_b.png","userVersion":"Haruki Murakami","changedateVersion":"02.02.2014","changetimeVersion":"07:00:00","epimIdWork":"ep_p-1","epimIdVersion":"ep_p-1"},


	
	

//Produktbeziehungen areaorder: 7 
{"name":"Ersatzteil","area":"Produktbeziehungen","areaorder":"7","dataType":"ProductAssignment","specprop-prodrel":"Products","valueWork":"Kugellager","userWork":"Phil Rudd","changedateWork":"07.02.2014","changetimeWork":"16:49:53","valueVersion":"Kugellager","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"16:49:53","epimIdWork":"pp_e-5","epimIdVersion":"pp_e-5"},

{"name":"Zubeh\u00f6r","area":"Produktbeziehungen","areaorder":"7","dataType":"ProductVariant","childOrParent":"parent", "valueWork":"Koffer","userWork":"Carlos Ruiz Zafon","changedateWork":"07.02.2014","changetimeWork":"17:32:47","valueVersion":"Koffer","userVersion":"Carlos Ruiz Zafon","changedateVersion":"11.12.2013","changetimeVersion":"17:32:47","epimIdWork":"pp_z-1","epimIdVersion":"pp_z-1"},
{"name":"Inhalt","area":"Attribute","areaorder":"4","dataType":"String","childOrParent":"child", "specprop-parentId":"pp_z-1","specprop-multiplicity":"3","collectionEntryType":"String","collectionEntryName":"","valueWork":"Schraubschl\u00fcssel","userWork":"Phil Rudd","changedateWork":"17.01.2014","changetimeWork":"10:05:07","valueVersion":"Steckschl\u00fcssel","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"17:35:07","epimIdWork":"as_i-2","epimIdVersion":"as_i-2"},
{"name":"Inhalt","area":"Attribute","areaorder":"4","dataType":"String","childOrParent":"child", "specprop-parentId":"pp_z-1","specprop-multiplicity":"3","collectionEntryType":"String","collectionEntryName":"","valueWork":"Nuss","userWork":"Phil Rudd","changedateWork":"07.01.2014","changetimeWork":"16:35:07","valueVersion":"Steckschl\u00fcssel","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"17:35:07","epimIdWork":"as_i-2","epimIdVersion":"as_i-33"},
{"name":"Inhalt","area":"Attribute","areaorder":"4","dataType":"String","childOrParent":"lastchild", "specprop-parentId":"pp_z-1","specprop-multiplicity":"3","collectionEntryType":"String","collectionEntryName":"","valueWork":"Steckschl\u00fcssel","userWork":"Phil Rudd","changedateWork":"07.02.2014","changetimeWork":"17:35:07","valueVersion":"Steckschl\u00fcssel","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"17:35:07","epimIdWork":"as_i-2","epimIdVersion":"as_i-44"},


//Beziehungen areaorder: 8 
{"name":"Audio","area":"Beziehungen","areaorder":"8","dataType":"Audio","valueWork":"Hurra Hurra die Schule brennt","userWork":"Dieter Rams","changedateWork":"05.02.2014","changetimeWork":"16:34:56","valueVersion":"Hurra Hurra die Schule brennt","userVersion":"Dieter Rams","changedateVersion":"05.02.2014","changetimeVersion":"16:34:56","epimIdWork":"ba_h-4","epimIdVersion":"ba_h-4"},




{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"30.04.2014","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-23","epimIdVersion":"mc_a-23"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"29.04.2014","userWork":"Bernard Purdie","changedateWork":"29.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-24","epimIdVersion":"mc_a-24"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"28.04.2014","userWork":"Bernard Purdie","changedateWork":"28.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-25","epimIdVersion":"mc_a-25"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"27.04.2014","userWork":"Bernard Purdie","changedateWork":"27.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-26","epimIdVersion":"mc_a-26"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"26.04.2014","userWork":"Bernard Purdie","changedateWork":"26.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-27","epimIdVersion":"mc_a-27"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.04.2014","userWork":"Bernard Purdie","changedateWork":"25.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-28","epimIdVersion":"mc_a-28"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"24.04.2014","userWork":"Bernard Purdie","changedateWork":"24.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-29","epimIdVersion":"mc_a-29"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"23.04.2014","userWork":"Bernard Purdie","changedateWork":"23.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"22.04.2014","userWork":"Bernard Purdie","changedateWork":"22.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"21.04.2014","userWork":"Bernard Purdie","changedateWork":"21.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-211","epimIdVersion":"mc_a-211"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"20.04.2014","userWork":"Bernard Purdie","changedateWork":"20.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-212","epimIdVersion":"mc_a-212"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"19.04.2014","userWork":"Bernard Purdie","changedateWork":"19.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-213","epimIdVersion":"mc_a-213"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"18.04.2014","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-214","epimIdVersion":"mc_a-214"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"17.04.2014","userWork":"Bernard Purdie","changedateWork":"17.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-24","epimIdVersion":"mc_a-24"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"16.04.2014","userWork":"Bernard Purdie","changedateWork":"16.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-25","epimIdVersion":"mc_a-25"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"15.04.2014","userWork":"Bernard Purdie","changedateWork":"15.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-26","epimIdVersion":"mc_a-26"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"14.04.2014","userWork":"Bernard Purdie","changedateWork":"14.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-27","epimIdVersion":"mc_a-27"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"13.04.2014","userWork":"Bernard Purdie","changedateWork":"13.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-28","epimIdVersion":"mc_a-28"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"12.04.2014","userWork":"Bernard Purdie","changedateWork":"12.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-29","epimIdVersion":"mc_a-29"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"11.04.2014","userWork":"Bernard Purdie","changedateWork":"11.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"10.04.2014","userWork":"Bernard Purdie","changedateWork":"10.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-211","epimIdVersion":"mc_a-211"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"09.04.2014","userWork":"Bernard Purdie","changedateWork":"09.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-212","epimIdVersion":"mc_a-212"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"08.04.2014","userWork":"Bernard Purdie","changedateWork":"08.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-213","epimIdVersion":"mc_a-213"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"07.04.2014","userWork":"Bernard Purdie","changedateWork":"07.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-213","epimIdVersion":"mc_a-213"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"06.04.2014","userWork":"Bernard Purdie","changedateWork":"06.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-24","epimIdVersion":"mc_a-24"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"05.04.2014","userWork":"Bernard Purdie","changedateWork":"05.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-25","epimIdVersion":"mc_a-25"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"04.04.2014","userWork":"Bernard Purdie","changedateWork":"04.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-26","epimIdVersion":"mc_a-26"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"03.04.2014","userWork":"Bernard Purdie","changedateWork":"03.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-27","epimIdVersion":"mc_a-27"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"02.04.2014","userWork":"Bernard Purdie","changedateWork":"02.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-28","epimIdVersion":"mc_a-28"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"01.04.2014","userWork":"Bernard Purdie","changedateWork":"01.04.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-29","epimIdVersion":"mc_a-29"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"31.03.2014","userWork":"Bernard Purdie","changedateWork":"31.03.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"21.03.2014","userWork":"Bernard Purdie","changedateWork":"21.03.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-211","epimIdVersion":"mc_a-211"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"20.03.2014","userWork":"Bernard Purdie","changedateWork":"20.03.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-212","epimIdVersion":"mc_a-212"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"19.03.2014","userWork":"Bernard Purdie","changedateWork":"19.03.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-213","epimIdVersion":"mc_a-213"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"18.03.2014","userWork":"Bernard Purdie","changedateWork":"18.03.2014"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.03.2014","userWork":"Bernard Purdie","changedateWork":"25.03.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.02.2014","userWork":"Bernard Purdie","changedateWork":"25.02.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.01.2014","userWork":"Bernard Purdie","changedateWork":"25.01.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.12.2013","userWork":"Bernard Purdie","changedateWork":"25.12.2013","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.11.2013","userWork":"Bernard Purdie","changedateWork":"25.11.2013","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"25.10.2013","userWork":"Bernard Purdie","changedateWork":"25.10.2013","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"05.04.2013","userWork":"Bernard Purdie","changedateWork":"05.04.2013","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-25","epimIdVersion":"mc_a-25"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"04.04.2012","userWork":"Bernard Purdie","changedateWork":"04.04.2012","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-26","epimIdVersion":"mc_a-26"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"03.04.2011","userWork":"Bernard Purdie","changedateWork":"03.04.2011","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-27","epimIdVersion":"mc_a-27"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"02.04.2010","userWork":"Bernard Purdie","changedateWork":"02.04.2010","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-28","epimIdVersion":"mc_a-28"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"01.04.2009","userWork":"Bernard Purdie","changedateWork":"01.04.2009","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-29","epimIdVersion":"mc_a-29"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"31.03.2008","userWork":"Bernard Purdie","changedateWork":"31.03.2008","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-210","epimIdVersion":"mc_a-210"},
{"name":"Anlagedatum","area":"Metadata","areaorder":"1","dataType":"ChangeInfo","valueWork":"21.03.2000","userWork":"Bernard Purdie","changedateWork":"21.03.2000","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-211","epimIdVersion":"mc_a-211"}





];

extVia.versionsProto.textsTextDB  = '<font id="part_1" style="font-size:12px;"><font style="text-decoration:underline;"><u>The Boys Are Back in Town </u></font></font>' +
                '<font style="font-size:12px;"></font>' +
                '<br><font style="font-size:12px;">Guess who just got<font style="font-weight:bold;"><b> back t</b></font>oday' +
                  '</font><br><font style="font-size:12px;" id="ext-gen1042">Them wild-eyed boys that had been away</font><br>' +
                  '<font style="font-size:12px;" id="ext-gen1041">Havent changed, hadnt much to say</font><br>' +
                  '<font style="font-size:12px;" id="ext-gen1038">But, man, I still think them cats are crazy</font><br>' +
                  '<font style="font-size:12px;"></font><br><font style="font-size:12px;" id="ext-gen1039">They were asking if you were around</font><br>' +
                  '<font style="font-size:12px;" id="ext-gen1040">How you was, where you could be found</font><br><font style="font-size:12px;">Told them you were living downtown</font><br>' +
                  '<font id="part_2"  style="font-size:12px;">Driving all the old men crazy</font><br>' +
                  '<font style="font-size:12px;"></font><br><font style="font-size:12px;"><font style="font-weight:bold;"><b>The</b>' +
                  '</font><font style="font-weight:bold;"><b> boys</b></font><font style="font-weight:bold;"><b> are back in town (the boys are back in town)</b></font></font><br>' +
                  '<font style="font-size:12px;"><font style="font-weight:bold;"><b>(I said) The boys are back in town (the boys are back in town)</b></font></font><br>' +
                  '<font style="font-size:12px;"><font style="font-weight:bold;"><b>The boys are back in town (the boys are back in town)</b></font></font><br><font style="font-size:12px;">' +
                  '<font style="font-weight:bold;"><b>The boys are back in town (the boys are back in town)</b></font></font><br>' +
                  '<font style="font-size:12px;"></font><br><font style="font-size:12px;">You know that chick that used to dance a lot?</font><br>' +
                  '<font style="font-size:12px;">Every night shed be on the floor shaking what shed got</font><br><font style="font-size:12px;">Man, when I tell you she was cool, she was red hot</font><br>' +
                  '<font style="font-size:12px;">I mean, she was steaming</font><br><font style="font-size:12px;"></font><br><font style="font-size:12px;">And that time over at Johnnys place</font><br>' +
                  '<font style="font-size:12px;">Well, this chick got up and she slapped Johnnys face</font><br><font style="font-size:12px;">Man, we just fell about the place</font><br>' +
                  '<font id="part_3"  style="font-size:12px;">If that chick dont want to know, forget her</font><br>' +
                  '<font style="font-size:12px;"></font><br><font style="font-size:12px;">The boys are back in town (the boys are back in town)</font><br>' +
                  '<font style="font-size:12px;">(I said) The boys are back in town (the boys are back in town)</font><br>' +
                  '<font style="font-size:12px;">The boys are back in town (the boys are back in town)</font><br><font style="font-size:12px;">The boys are back in town (the boys are back in town)</font><br>' +
                  '<font style="font-size:12px;"></font><br><font style="font-size:12px;">Spread the word around</font><br><font style="font-size:12px;">Guess whos back in town</font><br>' +
                  '<font style="font-size:12px;"></font><br><font style="font-size:12px;">Just spread the word around</font><br><font style="font-size:12px;"></font><br>' +
                  '<font style="font-size:12px;">Friday night theyll be dressed to kill</font><br><font style="font-size:12px;">Down at Dinos Bar and Grill</font><br>' +
                  '<font style="font-size:12px;">The drink will flow and blood will spill</font><br>' +
                  '<font style="font-size:12px;">And if the boys want to fight you better let them</font><br><font style="font-size:12px;"></font><br' +
                  '<font style="font-size:12px;">That jukebox in the corner blasting out my favourite song</font><br>' +
                  '<font style="font-size:12px;">The nights are getting warmer, it wont be long</font><br><font style="font-size:12px;">Wont be long till summer comes</font><br>' +
                  '<font style="font-size:12px;">Now that the boys are here again</font><br><font style="font-size:12px;"></font>' +
                  '<br><font style="font-size:12px;">The boys are back in town (the boys are back in town)</font><br><font style="font-size:12px;">The boys are back in town (the boys are back in town)</font>' +
                  '<br><font style="font-size:12px;">The boys are back in town (the boys are back in town)</font><br><font style="font-size:12px;">Spread the word around</font><br>' +
                   '<font style="font-size:12px;" id="ext-gen1037">The boys are back in town (the boys are back in town)</font><br>' +
                   '<font style="font-size:12px;">The boys are back (the boys are back)</font><br><font style="font-size:12px;"></font><br>' +
                   '<font style="font-size:12px;">The boys are back in town again</font><br>' +
                   '<font style="font-size:12px;">Been hanging down at Dinos</font><br><font style="font-size:12px;" id="ext-gen1035">The boys are back in town again</font><br><font style="font-size:12px;"></font><br>' +
                   '<font style="font-size:12px;"></font><br><font style="font-size:12px;"></font><br><font style="font-size:12px;" id="ext-gen1022">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam ' +
                   '<font style="text-decoration:underline;"><u id="ext-gen1021">nonumy eirmod tempor invidunt ut labore et dolore ma</u></font><font style="font-weight:bold;"><b><font style="text-decoration:underline;">' +
                   '<u id="ext-gen1036">gna aliquyam erat, se</u></font></b></font>' +
                   '<font style="text-decoration:underline;"><u>d diam voluptua. At vero eos et acc</u></font>usam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est ' +
                   'Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elit<font style="font-style:italic;"><i>r, sed diam non</i></font>umy eirmod tempor invidunt ut labore et dolore magna ' +
                   'aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gu<font style="font-weight:bold;"><b>bergren, no sea takimata sanctus est Lorem ipsum dol</b></font>' +
                   'or sit amet.</font><br>' +
                   '<font style="font-size:12px;"></font><br><font style="font-size:12px;"></font><br><font style="font-size:12px;" id="ext-gen1023">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, ' +
                   'sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus ' +
                   'est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. ' +
                   'At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</font>' 

            extVia.versionsProto.textsText  = extVia.versionsProto.textsTextDB.replace(/style="font-size:12px;"/g, "class=\"xty_epob-details-htmltext-font xty_epob-details-htmltext-fontSize\"")     ;


extVia.versionsProto.getTextsTextPart = function (){


}

