Ext.namespace('extVia.locales' ,'extVia.versionsProto.locales');
/**
 * @class extVia.versionsProto.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/12/06 15:33:51 $
 *            $Revision: 1.13.6.3 $
 */



extVia.versionsProto.locale_DE_EN =   { 

                                       

                                       
                                       
                                       
     activity: ['Aktivit&auml;t','Activity', 'Activitate'],
     activities: ['Aktivit&auml;ten','Activities', 'Activit&#259;&#539;i'],
     noActivities: ['Keine Aktivit&auml;ten','No Activities',  'Nu exista activit&#259;&#539;i'],
  
     //actions
     updated : ['ge&auml;ndert','changed', 'schimbat'],
     inserted : ['angelegt','inserted', 'inserat'],
     assigned : ['zugewiesen','assigned', 'alocate'],
     deleted : ['gel&ouml;scht','deleted', 'eliminat'],

     // user selections 
     someone : ['Jemand','Someone', 'Cineva'],
     all : ['Alle','all', 'toate'],
     //ellip: ['…', '…', '…' ],
     allMine : ['Alle von mir','all mine','Toate de mine'],
     allButMine : ['Alle ausser meine','all but mine', 'Toate, cu excep&#538;ia mea '],
     
     //  timeRelated 
     newest: ['neue', 'new ones', 'nou'  ],
     now: ['jetzt', 'now' ,'acum' ],
     
     // with real grouping <asort is needed
//     today: ['<a sort=0>heute', '<a sort=0>today' , '<a sort=0>astazi'],
//     yesterday: ['<a sort=1>gestern', '<a sort=1>yesterday' , '<a sort=1>ieri' ],
//     thisweek: ['<a sort=2>diese Woche', '<a sort=2>this week' , '<a sort=2>aceast&#259; s&#259;pt&#259;m&#226;n&#259;' ],
//     lastweek: ['<a sort=3>letzte Woche', '<a sort=3>last week' , '<a sort=3> s&#259;pt&#259;m&#226;n&#259; trecutn&#259; ' ],
//     thismonth: ['<a sort=4>diesen Monat', '<a sort=4>this month' , '<a sort=4>luna aceasta' ],
//     lastmonth: ['<a sort=5>letzten Monat', '<a sort=5>last month' , '<a sort=5>luna trecuta' ],         
//     thisyear: ['<a sort=6>dieses Jahr', '<a sort=6>this year' , '<a sort=6>în acest an' ],
//     lastyear: ['<a sort=7>letztes Jahr', '<a sort=7>last year' , '<a sort=7>anul trecut' ],
//     oneyearago: ['<a sort=8>vor einem Jahr', '<a sort=8>one year ago' , '<a sort=8>acum un an' ],
//     longtimeago: ['<a sort=9>vor langer Zeit', '<a sort=9>a long time ago' , '<a sort=9>cu mult timp înainte'  ],

     
     
     
     today: ['heute', 'today' , 'astazi'],
     yesterday: ['gestern', 'yesterday' , 'ieri' ],
     thisweek: ['diese Woche', 'this week' , 'aceast&#259; s&#259;pt&#259;m&#226;n&#259;' ],
     lastweek: ['letzte Woche', 'last week' , ' s&#259;pt&#259;m&#226;n&#259; trecutn&#259; ' ],
     thismonth: ['diesen Monat', 'this month' , 'luna aceasta' ],
     lastmonth: ['letzten Monat', 'last month' , 'luna trecuta' ],         
     thisyear: ['dieses Jahr', 'this year' , 'în acest an' ],
     lastyear: ['letztes Jahr', 'last year' , 'anul trecut' ],
     oneyearago: ['vor einem Jahr', 'one year ago' , 'acum un an' ],
     longtimeago: ['vor langer Zeit', 'a long time ago' , 'cu mult timp înainte'  ],
     
     
     
     daysAgo:['vor {0} Tagen' , '{0} days ago' , '{0} zile în urm&#259;' ],
     daysToDaysAgo:['vor {0} bis {1} Tagen' , '{0} to {1} days ago' , '{0} pân&#259; la {1} zile în urm&#259;' ],

     userActionTimeRelated:[ 
            '{user} hat {timeRelated} {epobTypeDscr} {epobDscr} {action}.' , // Ringo Starr has gestern das Bild "Mein Drumset" verändert.
            '{user} {action} {epobTypeDscr} {epobDscr} {timeRelated}.',    // Ringo Starr changed the Image "MyDrumset" yesterday.
            '{user} a {action} {epobTypeDscr} {epobDscr} {timeRelated}.'   // Ringo Starr a schimbat imaginea "MyDrumset" ieri.
     ],
     
     
     dateFormat:['n/j/Y' , 'n/j/Y', 'n/j/Y'],
     
     
     // epobPronom
     epobPronomNeutral : ['das','the', '' ],
     epobPronomMale : ['der','the', '' ],
     epobPronomAkkMale : ['den','the', '' ],
     epobPronomFemale : ['die','the', '' ],

     newValue : ['neuer Wert','new value', 'Valoarea nou&#259;' ],
     oldValue : ['alter Wert','old value' , 'Valoarea veche' ]
     
     // key : ['',''],
    };


extVia.versionsProto.locales = {
        appName:'versionsProto'
};


Ext.Object.each(extVia.versionsProto.locale_DE_EN, function(key, value, myself) {
    extVia.versionsProto.locales[key] = value[extVia.locales.uiLangIsoIx];
});


Ext.apply(extVia.locales, extVia.versionsProto.locales);






/*
 * 
 * $Revision: 1.13.6.3 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/12/06 15:33:51 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 