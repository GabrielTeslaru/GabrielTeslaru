/*


*/
Ext.application({
    name: 'versionsProtoApp',
    
    /**
     * Place 
     */
    appMode:{},


    
    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	
    	extVia.regApp = this;

    	
    	extVia.editor.baseEditor.statics.epobEditor = 'versioningDraft';
    	
    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside

    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true,hidesNorth:true,hidseWest:true, modulDscr:'versions Diff scroller'});
    	extVia.ui.page.raster.onReady(this);

    	var centerTabPan;
    	
    	var contentareaArr =[];
    	var contentareaHeight=280;
    	var contentareaScrollHeight = contentareaHeight;
    	var contentareaCount=28;
    	
    	var scrollnaviBarWidth = 140;
    	var scrollnaviOverviewBarWidth = 36;
    	
    	
    	var contentareaPanels = [
    	    {dscr:'Metadata'},
    	    {dscr:'ChangeInfo'},
    	    {dscr:'Workflows'},
    	    {dscr:'Verwendung'},
    	    {dscr:'&raquo; Referenzen'},
    	    {dscr:'&raquo; Publikationen'},
    	    {dscr:'Attributes'},
    	    {dscr:'Elements'},
    	    {dscr:'&raquo; Bilder'},
    	    {dscr:'&raquo; Documente'},
    	    {dscr:'&raquo; Tabellen'},
    	    {dscr:'Beziehungen'},
    	    {dscr:'Lieferanten'},
    	    {dscr:'Vorschauen'}  	    
    
    	];
    	contentareaCount = contentareaPanels.length;
    	
    	
    	
    	extVia.regApp.scrollToTop = function(value){
    		Ext.get("deltaPanel-body").scrollTo('top',value ,{duration:500});  
    	};
    	
    	
    	
    	var deltaPanelScrollToThis = function(evt, target, panel, eOpts){		
    		panel.addCls("scrolledto");
    		//Ext.get("deltaPanel-body").scrollTo('top',panel.areaIx*contentareaScrollHeight ,true);    	
    		
    		extVia.regApp.scrollToTop(panel.areaIx*contentareaScrollHeight);
    		
    	}; 
    	
    	
    	var deltaPanelScrollFirst = function(){		
    		//Ext.get("deltaPanel-body").scrollTo('top',0 ,true);
    		extVia.regApp.scrollToTop(0);
    	};
    	
    	var deltaPanelScrollNext = function(){
    		var scrollNow = Ext.get("deltaPanel-body").getScroll().top;
    		scrollNow = scrollNow - (scrollNow%contentareaScrollHeight);
    		var scrollNext = scrollNow + contentareaScrollHeight;   		
    		//Ext.get("deltaPanel-body").scrollTo('top',scrollNext ,true);
    		extVia.regApp.scrollToTop(scrollNext);
    	};   	
    	var deltaPanelScrollPrev = function(){
    		var scrollNow = Ext.get("deltaPanel-body").getScroll().top;
    		var rest = scrollNow % contentareaScrollHeight;
    		scrollNow = scrollNow - rest;

    		var scrollPrev = scrollNow;
    		if (rest === 0 ){
    			scrollPrev = scrollNow - contentareaScrollHeight ; 		
    		}	
    		//Ext.get("deltaPanel-body").scrollTo('top',scrollPrev ,true);
    		extVia.regApp.scrollToTop(scrollPrev);
    	};  	
    	var deltaPanelScrollLast = function(){		
    		//Ext.get("deltaPanel-body").scrollTo('top',(contentareaCount*contentareaScrollHeight) ,true);
    		extVia.regApp.scrollToTop((contentareaCount*contentareaScrollHeight));
    	}; 
    	
    	extVia.regApp.deltaPanelScrollToThis = deltaPanelScrollToThis;
    	extVia.regApp.deltaPanelScrollFirst = deltaPanelScrollFirst;
    	extVia.regApp.deltaPanelScrollPrev = deltaPanelScrollPrev;
    	extVia.regApp.deltaPanelScrollNext = deltaPanelScrollNext;
    	
    	
 	   var filterComboCfg = {
			   triggerCls:'xty_form-trigger-filter',
			   xtype:'combo',
			   displayField: 'dscr',
			   name:'mengenFilterCombo',
			   id:'mengenFilterCombo',
			   validator:function(val){
			    	  try {new RegExp(val); return true;}
			    	  catch(rgxEx){return "Die Eingabe ist nicht Regex-konform<br>"+rgxEx;}
			   },
			    queryMode: 'local',
			    mode: 'local',
			    value:'',
			    defaultListConfig :{draggasble:true, floating:true, maxHeight:48, cls:'xty_mini-bound-list'},
			    autoCompleteInsert:extVia.stores.inputTextautoCompleteInsert,
			    store:   
				   Ext.create('Ext.data.Store', {   
					            model:  Ext.define('QuickSearchField', {
					    	    fields: ['value','dscr'],
					    	    extend: 'Ext.data.Model'
					    	})
				   }) ,
			   
				   listeners:{
				
					   specialkey:  extVia.stores.inputTextautoCompleteInsertonEnter,
					   
					   change:function( combo, newValue, oldValue, eOpts ){
				        	var grid =Ext.getCmp("mengenGrid");
				        	grid.store.clearFilter();
				        	var sortX = new RegExp(newValue,'gi');
				        	if (newValue.length>0){ grid.store.filter("name", sortX);}

						   }
				   }
	   };
    	
    	
    	var pagejobButtons = [
    	                      
    	                      filterComboCfg , 
    	                      {xtype:'tbspacer' , width:10},
    	                      
    	                      extVia.versionsProto.statics.getDiffFilterButtonGroupCfg ({},{epobId:'Abc',epobDscr:"Abc"}),
               

    	                    {xtype:'tbspacer' , width:30},               
                            {itemId:'listingFirst', iconCls:'xty_pgtoolbar-listingFirst' , scale:'small', handler:deltaPanelScrollFirst},
                            {itemId:'listingNext', iconCls:'xty_pgtoolbar-listingNext' ,scale:'small', handler:deltaPanelScrollNext},
                            {itemId:'listingPrev', iconCls:'xty_pgtoolbar-listingPrev' ,scale:'small', handler:deltaPanelScrollPrev},
                            {itemId:'listingLast', iconCls:'xty_pgtoolbar-listingLast' ,scale:'small', handler:deltaPanelScrollLast}

    	                    ];

    	var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:"Produktansicht &Delta;", epobDscr:"Abc",  pgjobButtons: pagejobButtons } );
    	//var westTabPan = extVia.regApp.myRaster.initWestTabPanel({items:[{title:'Liste',tbar:[{iconCls:'plus'}]},{title:'Suche'},{title:'tab 3'}] });
    	//extVia.regApp.myRaster.addToWest(westTabPan);
    	
    	
    	centerTabPan = extVia.regApp.myRaster.initCenterTabPanel();
    	//var tabPan = centerTabPan;
    	extVia.regApp.centerTabPan = centerTabPan;
    	extVia.regApp.myRaster.addToCenter(centerTabPan);
    	
    	
    	
    	
    	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip
    	
    	var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
    	
    	
   // DeltaPanel   very-first-draft
    	var doDeltaPanel = false ;
    	var deltaPanelScroll = function(){
    		var scrollNow = Ext.get("deltaPanel-body").getScroll().top;
    		var scrollNext = scrollNow + contentareaScrollHeight;   		
    		//Ext.get("deltaPanel-body").scrollTo('top',scrollNext ,true);
    		extVia.regApp.scrollToTop(scrollNext);
    	};
    	
    	
    	
    	
    	var centerScrollTocontentareaArea = function(button){
    		if (button.ownerCt.lastButton){
    			button.ownerCt.lastButton.toggle();
    		}
    		//Ext.get("deltaPanel-body").scrollTo('top',button.areaIx*contentareaScrollHeight ,true);
    		extVia.regApp.scrollToTop(button.areaIx*contentareaScrollHeight);
    		button.ownerCt.lastButton = button;
    		
    	};
    	
    	

       var viewCfg = {scrollnaviButtonsLeft :false, treeView:false,matrixView:false};

	   var setViewConfigFromUrl  = function getViewConfigFromUrl() {
	    	var qStr = location.href.replace(/.[^\?]*\?/,'');

	    	var urlParams = Ext.Object.fromQueryString(qStr);
	    	if (urlParams.scrollnaviButtonsLeft==="true"){viewCfg.scrollnaviButtonsLeft=true;}
	    	if (urlParams.treeView==="true"){viewCfg.treeView=true;}
	    	if (urlParams.matrixView==="true"){viewCfg.matrixView=true;}
            if (urlParams.subpanelListsinPage==="true"){viewCfg.subpanelListsinPage=true;}  
            if (urlParams.subpanelboxesFullWidth==="true"){viewCfg.subpanelboxesFullWidth=true;}
		  return urlParams;
	    };
	    setViewConfigFromUrl();
	    extVia.regApp.viewCfg = viewCfg;

    	
    	var scrollnaviButtonsLeft = viewCfg.scrollnaviButtonsLeft;
    	var buttonArr =[];
    	var i ;
        for ( i =0; i <contentareaCount; i++){
    		buttonArr.push({
    			//text:'scroll to '+ i,
    			
    			text: contentareaPanels[i].dscr,
    			tooltip:'scroll to '+ i,
    			textAlign : scrollnaviButtonsLeft?'right':'left',
    			icosnAlign : scrollnaviButtonsLeft?'right':'left',
    			itemId:'scrollnavi-button_'+ i,
    			xtype:'button',
    			scale:'medium',
    			width:100,
    			enableToggle:true,
    			handler: centerScrollTocontentareaArea,
    			areaIx : i,

	    	    listeners: {

	    	        afterrender: function(button) {
	    	        	button.getEl().on('keydown',function (evt, target, eOpts){

	    	        		if (evt.getKey()===Ext.EventObject.UP  || ( evt.getKey()===9 &&  evt.shiftKey )   ){
	    	        			extVia.regApp.deltaPanelScrollPrev();
	    	        		}
	    	        		else if (evt.getKey()=== Ext.EventObject.DOWN  || evt.getKey()===9){
	    	        			extVia.regApp.deltaPanelScrollNext();
	    	        		}


	    				});
	    	        }
	    	    }
    			
    			
    			
    		});
    	}
    	
    	var contentareaPanelWidth = (mainContentPanelWidth-(scrollnaviBarWidth+20+scrollnaviOverviewBarWidth-1) )/2;
    	
    	var loremIpsum1 ='<br>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.';
    	var loremIpsum2 =   '<ul>'
            	  +'<li>&bull;<a>@composedof</a> extVia.classXY{@link extVia.classXY} if</li>'
            	  +'<li><a>@responsible</a> meaningful only</li>'
            	  +'<li><a>@sideeffects</a>: See {@link #abz} and {@link extVia.classXY#xyz}</li>'
            	  +'<li>example usage:<code> var xy = 1;</code></li>'
            	  +'<li><a>@protected</a>, <a>@priviledged</a>, <a>@private</a> if , semi-private, real privates are not shown </li>'
            	  +'<li><a>@usedby</a> {@link extVia.classXY} possible??</li>'
            	  +'<li><a>@version</a></li>'
            	  +'<li><a>@history</a> ??</li>'
            +'</ul>';
    	
    	var comparedStatesArr = [ 
    	                   'unknown' ,  'diff-bydateonly',
    	                   'diff' , 'equals' ,
    	                   'diff-single' , 'diff-empty' ,
    	                   'equals-newly', 'eqequalselder'
    	                   ];
    	

    	
        var model = Ext.define('ComparableRow', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'dscr'}, {type: 'string', name:'name'},
                     {type: 'string', name: 'workValue'},{type: 'string', name: 'frozValue'},
                     {type: 'float', name: 'workDate'}, {type: 'float', name: 'frozDate'}
                     ]  
        });
    	
    	
    	
    	
    	var compareData = 									// dateForamt YYYYMMDD.mmss
    		[
    		 { name:'umdr', dscr:'Umdrehung', workValue:'sieben' , frozValue:'sieben', workDate:20010101, frozDate:20090303},    
    		 { name:'lang', dscr:'L&auml;nge', workValue:'hundert' , frozValue:'hundert', workDate:20020101, frozDate:20020202},  
    		 { name:'hoch', dscr:'H&ouml;he', workValue:'hundert' , frozValue:'hundert', workDate:20041213, frozDate:20041213},      
    		 { name:'breit', dscr:'Breite', workValue:'vier' , frozValue:'f&uuml;nf', workDate:20070101, frozDate:20070101},      
    		 { name:'opt', dscr:'Zusatzoptionen', workValue:'pi mal schraub' , frozValue:null, workDate:20080101, frozDate:20080101},    
    		 { name:'count', dscr:'Z&auml;hler', frozValue:'1234567' , workValue:null, workDate:20080101, frozDate:20080101}, 
    		 { name:'schnell', dscr:'Schnellspanner', workValue:'sieben' , frozValue:'sieben', workDate:20010101, frozDate:20090303},    
    		 { name:'durch', dscr:'Durchblick', workValue:'sieben' , frozValue:'sieben', workDate:20010101, frozDate:20090303} 
    		 
    		 
    	];
    	
    	
    	var compareRowByDateOnly = function(diffy){
    		diffy.workState = 'unknown';
    		diffy.frozState = 'unknown';
    		diffy.rowState = 'unknown';
    		
    		if (diffy.workDate !== diffy.frozDate){	  
    			diffy.rowState = 'diff-bydateonly';
    			diffy.workState = 'diff-'  + ((diffy.workDate>diffy.frozDate)?"newly":"elder");
    			diffy.frozState = 'diff-' + ((diffy.workDate<diffy.frozDate)?"newly":"elder");
    		}
    		else{
    			diffy.workState = 'equals'; 
    			diffy.frozState = 'equals';
    			diffy.rowState = 'equals-bydateonly';
    		}
    		
			if (!diffy.workValue){
				diffy.rowState = 'diff-empty-work';
    			diffy.workState = 'diff-empty'; 
    			diffy.frozState = 'diff-single';	
			}
			if (!diffy.frozValue){
				diffy.rowState = 'diff-empty-froz';
    			diffy.workState = 'diff-single'; 
    			diffy.frozState = 'diff-empty';	
			}
    		
    	};
    	
    	
    	var compareRow = function(diffy){
    		diffy.workState = 'unknown';
    		diffy.frozState = 'unknown';
    		diffy.rowState = 'unknown';
    		
    		if (diffy.workValue === diffy.frozValue){
    			diffy.workState = 'equals';
    			diffy.frozState = 'equals';
    			diffy.rowState = 'equals';
        		if (diffy.workDate !== diffy.frozDate){	
        			diffy.workState = 'equals-'  + ((diffy.workDate>diffy.frozDate)?"newly":"elder");
        			diffy.frozState = 'equal-' + ((diffy.workDate<diffy.frozDate)?"newly":"elder");
        		}
    		}
    		else{
    			diffy.workState = 'diff'; 
    			diffy.frozState = 'diff';
    			diffy.rowState = 'diff';
    			
    			if (!diffy.workValue){
    				diffy.rowState = 'diff-empty-work';
        			diffy.workState = 'diff-empty'; 
        			diffy.frozState = 'diff-single';	
    			}
    			if (!diffy.frozValue){
    				diffy.rowState = 'diff-empty-froz';
        			diffy.workState = 'diff-single'; 
        			diffy.frozState = 'diff-empty';	
    			}  
    			
    			//if (diffy.workValue && diffy.workValue){var forJSLINT;}
    			
    			
    		}
    		
    		//alert(Ext.encode(diffy) ); //+" (diffy.workDate>diffy.frozDate) "+(diffy.workDate>diffy.frozDate)+" (diffy.workDate<diffy.frozDate) " +(diffy.workDate<diffy.frozDate));

    	};
    	
    	var formatDate = function(dateNumber){	// dateForamt YYYYMMDD.mmss

    	  var emptyStr = '';
    		var dateStr = emptyStr+dateNumber;
    		
    		var year = dateStr.substring(0,4);
    		var month = dateStr.substring(4,6);
    		var day = dateStr.substring(6,8);	
    		
    		//alert(dateStr+' year['+year+'] month['+month+'] day['+day+']');
    		
    		var date = new Date(parseInt(year, 10 ), parseInt( month, 10) , parseInt(day, 10));
    		
    		return Ext.Date.format(date, "d. M.y H:m");
    		
    	};
    	
    	

    	var showHtml = '<br><br><table class="xty_compared-block">';
    	var buildHtmlFromData = function(comparableData, doCompare){
        	var i;
            for (i =0; i <comparableData.length; i++){
        		var record = comparableData[i];
        		if (doCompare) {
        			compareRow(record);
        			}
        		else {
        			compareRowByDateOnly(record);
        	    }

        		var comparedHtml = 

        			'<tr name="compared_row-'+record.name+'" class="xty_comparedRow-'+record.rowState+'" state="'+record.rowState+'">'
        				+'<td name="compared_dscr_row-'+record.name+'" class="xty_compared-dscr xty_compared-dscr-work xty_compared-dscr-'+record.workState+'" state="">'+record.dscr+':</td>'
        				+'<td  class="xty_compared-val xty_compared-val-work xty_compared-'+record.workState+'" state="'+record.workState+'"> '+record.workValue+'</td>'
        				+'<td  class="xty_compared-val xty_compared-val-work xty_compared-'+record.workState+'" state="'+record.workState+'"> '+formatDate(record.workDate)+'</td>'
        				
        				+'<td name="compared_dscr_row-'+record.name+'" class="xty_compared-dscr xty_compared-dscr-froz xty_compared-dscr-'+record.frozState+'" state="">'+record.dscr+':</td>'
        				+'<td  class="xty_compared-val xty_compared-val-froz xty_compared-'+record.frozState+'" state="'+record.frozState+'"> '+record.frozValue+'</td>'
        				+'<td  class="xty_compared-val xty_compared-val-froz xty_compared-'+record.frozState+'" state="'+record.frozState+'"> '+formatDate(record.frozDate)+'</td>'
        				
        				
        				+'<td name="compared_icon_row-'+record.name+'" class="xty_compared-icon-bin xty_compared-icon-bin-work" >'
        				+'<div  class="xty_compared-icon xty_compared-icon-work xty_compared-icon-'+record.rowState+'"  >'+'</div>'
        				+'</td>'
        				
        				
        			+'</tr>';
        		
        		
        	     showHtml+= comparedHtml;
        	}	
    	};
    	
    	buildHtmlFromData(compareData);
    	loremIpsum2 = 		showHtml+"</table>";
    			
    	showHtml = '<br><br><table class="xty_compared-block">';
    	buildHtmlFromData(compareData, true);
    	loremIpsum1 = 		showHtml+"</table>";
    	
    	
    	var buildContentareaPanelsFromData = function(){
        	var i;
            for (i =0; i <contentareaCount; i++){
        		contentareaArr.push({
        			id:'contentareaPanels_'+i+'-bin',
        			itemId:'contentareaPanels_'+i+'-bin',
        			border:false,
        			cls:'xty_contentareaPanels-bin' +  ((i%2===0)?' xty_compared-bydateonly':'') ,
        			html:
        				'<div id="contentareaPanel_'+i+'-work" class="xty_contentareaPanel-work"  '
        						+'style="width:'+contentareaPanelWidth+'px;float:left;height:'+contentareaHeight+'px; border-right:0px;">'
        					+'<a  id="a_contentareaPanel_'+i+'-work" class="xty_compared-block-header"  style="font-size:14pt" > &nbsp;&nbsp;&nbsp;'+contentareaPanels[i].dscr+'</a> '
        					+'<span class="xty_version-type-dscr">work' +((i%2===1)?loremIpsum1:loremIpsum2)+'</span>'
        			   +'</div>'
        			   +'<div id="contentareaPanel_'+i+'-froz" class="xty_contentareaPanel-froz"'  
        			   		 	+'style="width:'+contentareaPanelWidth+'px;float:right;height:'+contentareaHeight+'px; border-left:0px;">'
        			   		+'<a  id="a_contentareaPanel_'+i+'-froz"  class="xty_compared-block-header" style="font-size:14pt" > &nbsp;&nbsp;&nbsp;'+contentareaPanels[i].dscr+'</a> '
        			   		+'<span class="xty_version-type-dscr">froz'  +((i%2===1)?loremIpsum1:loremIpsum2)+'</span>'
        			   +'</div>',
        			areaIx : i,  
       	    	    listeners: {
    	    	        afterrender: function(panel) {
    	    	        	panel.getEl().on('click',function (evt, target, eOpts){extVia.regApp.deltaPanelScrollToThis(evt, target, panel, eOpts);});
    	    	        }
    	    	    }      
        		});
        	}
    	};

    	if (!viewCfg.treeView && !viewCfg.matrixView){ 	
    		buildContentareaPanelsFromData();
    	}
    	
    	
    	


		contentareaArr.push({
			id:'tothetopButton',
			itemId:'tothetop',
			hidden:true,
			//handler:function(){alert("tothetop-A");},
			border:false,
			cls:'xty_tothetop-bin',
			html:'<a id="tothetop-A" onclick="extVia.regApp.deltaPanelScrollFirst()" class="xty_tothetop"><i  class="xty_tothetop-icon"></i></a>'
		});

		var scrollnaviBarCfg = {
        	itemId:'scrollnaviBar', 
        	cls:'xty_scrollnaviBar', 
        	style:'padding-left:12px ;padding-top:12px ;',
        	width:scrollnaviBarWidth,
        	items:buttonArr
        };
		var scrollnaviOverviewBarCfg ={
	        	itemId:'scrollnaviOverviewBar', 
	        	cls:'xty_scrollnaviOverviewBar', 
	        	//style:'padding-left:12px ;padding-top:12px ;',
	        	width:scrollnaviOverviewBarWidth,
	        	html: "<img  src='../img/fakes/scrollnaviOverviewBar-both.png'/>"
	        	
	        };
    	var deltaPanelCfg = {
    				title:'&Delta; Abc', 
    			    tbar :appbar,
    				closable:true,
    				id:'deltaPanel',
    				itemId:'deltaPanel',
    				autoScroll : true,
    				height:mainContentPanelHeight,
    				width:mainContentPanelWidth,
    		        rbar:scrollnaviButtonsLeft?scrollnaviOverviewBarCfg:scrollnaviBarCfg,
    		        lbar:scrollnaviButtonsLeft?scrollnaviBarCfg:scrollnaviOverviewBarCfg,
    				border:false,
    				html: "<img  src='../img/fakes/versio-timeline.png'/>",
    				items:[
    				       {
    				    	   id:'deltaContentareaPanels',
    				    	   itemId:'deltaContentareaPanels',
    				    	   border:false,
    				    	   items: contentareaArr
    				       }
    				      ]
    				};

    	

    	extVia.regApp.showDiffPanel = function (epob){
            try{
             if (!centerTabPan) {
               centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
             }
    		 var diffGridTab = centerTabPan.addAndActivate(extVia.versionsProto.statics.getDiffGridPanelCfg(epob));
    		 diffGridTab.skip({versionNr:'4', versionDate:'7. Mai 2014'}, epob);
            }
            catch(diffex){
              extVia.notify("showDiffPanel Exception "+diffex);
            }
    	};
    	

    	var welcTab = centerTabPan.add({title:'...'
    		//htXXml:'<div style="height:100%;text-align: center ; padding:60px;width:100%;vertical-align:center;"><img style="opacity:0.5;" height="512px" src="../img/icons/flow_chart.png"/><div>'
    		});
    	centerTabPan.setActiveTab(welcTab);
    	

  
// DeltaPanel   very-first-draft
 if (doDeltaPanel){   
   var deltaPanel  =  centerTabPan.add(deltaPanelCfg);      
   extVia.regApp.showDeltaPanel = function (){centerTabPan.setActiveTab(deltaPanel);};

    	var delayedScrollTask = new Ext.util.DelayedTask(function(){
    		var scrollNow = Ext.get("deltaPanel-body").getScroll().top;
    		var rest = scrollNow%contentareaScrollHeight;
    		var skipIx = true; // Wenn scroll von buttons kommt ist rest 0
    		if (rest===0 ){
    			skipIx = false;
    		}
    		scrollNow = scrollNow - rest;
    		var scrollNowIx = scrollNow  / contentareaScrollHeight;
    		if (skipIx){
    			scrollNowIx+=1;
    		}
    		
    		var tothetopButton = Ext.getCmp("tothetopButton");
    		if (scrollNowIx>1) {tothetopButton.show();}
    		else {tothetopButton.hide();}
    		
    		var correspondingButton  = deltaPanel.getComponent("scrollnaviBar").getComponent('scrollnavi-button_'+ scrollNowIx);
    		if (correspondingButton.ownerCt.lastButton){
    			correspondingButton.ownerCt.lastButton.toggle();
    			correspondingButton.ownerCt.lastButton.setIconCls("");
    		}
    		correspondingButton.toggle();
    		correspondingButton.setIconCls("xty_scrollnavi-button-selected");
    		correspondingButton.ownerCt.lastButton = correspondingButton;

            var deltaContentareaPanels = deltaPanel.getComponent("deltaContentareaPanels");
    		var correspondingPanelsBin = deltaContentareaPanels.getComponent('contentareaPanels_'+scrollNowIx+'-bin');
    		if (deltaContentareaPanels.lastScrolledtoPanel){
    			deltaContentareaPanels.lastScrolledtoPanel.removeCls("scrolledto");
    		}
    		correspondingPanelsBin.addCls("scrolledto");
    		deltaContentareaPanels.lastScrolledtoPanel = correspondingPanelsBin;
    	});
        Ext.get("deltaPanel-body").on('scroll', function(e, t) {
          delayedScrollTask.delay(10);
        });
   }
// eo if doDeltaPanel    	

    	
    	
    	
    	var goodLinksArr =[ 	
    	                   
        {dscr:'bootstrap',url:'http://getbootstrap.com/javascript/#scrollspy'},
		{dscr:'csshat', url:'http://csshat.com/story/'},
		{dscr:'hr cloud',url:'http://hrcloud.com/why-hr-cloud/'},
		{dscr:'google diff',url:'https://neil.fraser.name/software/diff_match_patch/svn/trunk/demos/demo_diff.html'},
		
		
		
		{dscr:'diskussiontree',url:'http://chronicle.com/blogs/linguafranca/2013/04/24/slash-not-just-a-punctuation-mark-anymore/'},
		{dscr:'codio',url:'https://codio.com/'},
		
		{dscr:'scrollspy bourbon',url:'http://bourbon.io/docs/#linear-gradient-function'},
		{dscr:'ramones vs misfits',url:'http://grayhood.com/wp-content/uploads/2011/01/misfits-pie-carts.jpg'}
		];
    	
    	
    	if (viewCfg.goodLinks || viewCfg.matrixView ){
         var il;	 
           for (il =0; il <goodLinksArr.length; il++){
        		centerTabPan.add({
        			title:goodLinksArr[il].dscr,
    				height:mainContentPanelHeight,
    				width:mainContentPanelWidth,
        		    html : '<iframe width="100%" height="100%" id="goodExampleIFRAME_'+il+'"  frameborder="0" src="'+goodLinksArr[il].url+'" ></iframe>'
        			
        			
        		});
        	}
    	}

    	
    	var hierachiesItemsHeight =  (mainContentPanelHeight)/2;
    	var westTabPan  =  extVia.regApp.myRaster.initWestTabPanel(
	    		{
	    	    	activeTab:'hierarchy',
	    	    	items:[ 
	    	    	        extVia.query.statics.getQueryTabCfg() ,
	    	    	        extVia.hierarchy.statics.getHierarchyTabCfg({}),
	    	    	        extVia.hierarchy.statics.getStructureTreePanelCfg({})
	    	    	        ]
	    		}); 	    
    	extVia.regApp.myRaster.addToWest(westTabPan);

    	
       var editorSubTabsPanel;
        var routingCfg  = extVia.ui.page.raster.getRoutingConfigFromUrl();
        //alert("getRoutingConfigFromUrl "+Ext.encode(routingCfg));
        if (routingCfg){
            centerTabPan = null;
           var prodEdiTab  =null;

	        if (routingCfg.loadType){
                if (routingCfg.loadType.indexOf("Product")>-1){
                  centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
                  
                  var dscr = routingCfg.loadId.replace(/_/g, ' ');

                  prodEdiTab = centerTabPan.add(extVia.editor.baseEditor.statics.getEpobEditorPanelCfg({versioning:true},{epobId:routingCfg.loadId, dscr: dscr}));
                  centerTabPan.setActiveTab(prodEdiTab);
                }
                else if (routingCfg.loadType.indexOf("Diff")>-1){
                  extVia.regApp.showDiffPanel( {dscr:'Metabo Power Maxx BS Quick', epobTypeId:extVia.module.epob.PRODUCTVARIANT , epobId:'Metabo_Power_Maxx_BS_Quick'});
                }
                else{
                 extVia.showNotification({
                    status : 'Inactive',
                    iconCls:'xty_icon xty_iconInactive',
                    cls: 'ux-notification-light',
                    position: 'tr',
                    title : "Routing "+routingCfg.loadType,
                    html : "not available"
                  });
  
                }
	        }
	        if (routingCfg.subloadType){
               //if (routingCfg.subloadType==='tab' ){
                editorSubTabsPanel = prodEdiTab.getComponent("editorSubTabsPanel"); 
                var activeTabId = routingCfg.subloadType==='tab' ? routingCfg.subloadId : routingCfg.subloadType;
                editorSubTabsPanel.setActiveTab(activeTabId+'Tab');
               //}
	        }
        }       
    	


        
        // metadataTab, attributeTab, elementsTab, versionTab, history, tasks
        
        var ediTabs ={
          metadata: 'metadataTab', attributes: 'attributeTab', elements: 'elementsTab', versions: 'versionTab', history: 'history', tasks: 'tasks'          
        };
        var ediActiveTab = 'versionTab';        
        var subanchor ;
        var url = location.href;
        var subHashIndex = url.indexOf('#sub');
        if (subHashIndex>-1){
          subanchor = url.substring(subHashIndex+4);  
          if (subanchor){
            ediActiveTab = subanchor.replace(/-/ , '');
            if (ediTabs[ediActiveTab]){
              ediActiveTab = ediTabs[ediActiveTab];
            }
          } 
        } 
        
        centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
        
        var editorTab = centerTabPan.addAndActivate(extVia.editor.baseEditor.statics.getEpobEditorPanelCfg({versioning:true, activeTab:ediActiveTab},{historyviewCfg: {cards:true, smallcards:false}, "dscr":"Metabo Power Maxx","epobId":"Metabo_Power_Maxx","epobTypeId":2020, breadcrumb:'Metabo/Elektrowerkzeuge/Akkuger&auml;te/Akku-Bohrschrauber' }));
        centerTabPan.setActiveTab(editorTab);

     
    	
		//var addPinfoDialog  = extVia.dialoges.getPinfoRowDialog({x: 400,y: 60});
		//addPinfoDialog.show();
   //extVia.regApp.showDiffPanel({dscr:'Metabo Power Maxx BS Quick', epobTypeId:extVia.module.epob.PRODUCTVARIANT , epobId:'Metabo_Power_Maxx_BS_Quick'});
        
              
              
       // opens specific Objects from the tree       
         if (routingCfg ){// && routingCfg.subloadId=="attributes"){
          //alert(Ext.encode(routingCfg)) 
	        var routToPratDscrs = Ext.DomQuery.select('.xty_fake_prat-dscr:contains('+routingCfg.subloadId+')');
	        if (routToPratDscrs){
  	         var routToPratDscr = Ext.get(routToPratDscrs[0]);
  	         if (routToPratDscr) { 
  	          var routToPratDscrTop = routToPratDscr.getTop() - 240 ;
  	          var routToPratDscrBottom = routToPratDscr.getBottom()  ;
  	           var prodEditorTab = centerTabPan.getActiveTab();
  	           editorSubTabsPanel = prodEditorTab.getComponent("editorSubTabsPanel"); 
  	           var activePanel = editorSubTabsPanel.getActiveTab(); 
  	         
  	          var scrollPanel = Ext.get(activePanel.id+'-body');         
  	           var offsets=  routToPratDscr.getOffsetsTo( scrollPanel );
  	           // var scrollPosition = scrollPanel.getHeight() - scrollPanel.getTop();
  	           var scrollTo =    offsets[1] - 10  ;
  	             //alert('routToPratDscrTop['+routToPratDscrTop+'] routToPratDscrBottom['+routToPratDscrBottom+'] offsets['+offsets+'] scrollPosition['+scrollPosition+'] scrollTo '+scrollTo);
  	             //scrollPanel.scrollTo('top',0 ,{duration:500});  
  	             scrollPanel.scrollTo('top',scrollTo ,{duration:500});  
      	         routToPratDscr.highlight("FF44B7", {  //
      			    attr: "backgroundColor", 
      			    endColor: ('FFFFFF') ,
      			    easing: 'easeIn',
      			    duration: 5000
      			  });
	          } // eo if routToPratDscr     
	        } // eo if routToPratDscrs 
        }
        
         
         
         
         
         var historyRowDialog  = Ext.create('Ext.window.Window', extVia.historyProto.statics.getHistoryRowDialogCfg({},
              {"dscr":"Metabo Power Maxx","epobId":"Metabo_Power_Maxx","epobTypeId":2020,"breadcrumb":"Metabo/Elektrowerkzeuge/Akkuger\u00e4te/Akku-Bohrschrauber"})); 
              
              //historyRowDialog.showAt(extVia.regApp.myRaster.getCenter().getEl().getRight()-historyRowDialog.width-20, 40);
         
         
         if(ediActiveTab==='versionTab'){
           extVia.versionsProto.statics.showVersioningProgress({"epobDscr":"Metabo Power Maxx",}); 
         }
         
         
         
        
    }
});




/*
 * 
 * $Revision: 1.66.6.11 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2020/11/10 08:40:16 $
 * $Author: pehm $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
