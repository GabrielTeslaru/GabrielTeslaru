Ext.namespace('extVia.locales' ,'extVia.publications.locales');
/**
 * @class extVia.publications.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2014/02/27 17:01:15 $
 *            $Revision: 1.1 $
 */

extVia.publications.locales = {
        appName:'publications',
};

Ext.apply(extVia.locales, extVia.publications.locales);



/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2014/02/27 17:01:15 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 