




Ext.define('extVia.publications.statics', {
    statics: {
    	getPublicationsAccessCfg : function(cfg){
        	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip
        	var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
        	var publicationsItemsHeight =  mainContentPanelHeight;

        	var epobDscr ='Katalog Frühjahr';
        	
    		var publicationsAccessCfg = 	    		
    	       {  
    	    	   title: 'Publikationen',
    	    	   id : 'publicationsAccess',
    	    	   itemId : 'publicationsAccess',
    	    	   border:false,
    	    	   height:800,
    	    	   margins : '0 0 0 0',
    	    	   laysout:'fit',
    	           items:[
	        	       {   
	        	    	   itemId:'publications',     
	        	    	   xtype:'fakepanel',
	        	    	   height:800,
	        	    	   fake:'../img/fakes/sketches/01a_publicationsListSketch.gif',	        	    	   
	        	    	   items:[
        	    	          {x:296,y:8, itemId:'close',handler:function(item){item.ownerCt.ownerCt.close();}},
	        	    	          
	        	    	      { text:'   ', xtype:'splitbutton', itemId:'Publikation XY-clicker', 
	        	    	    	  x:290, y:212, 
	        	    	    	  epobDscr:epobDscr,
	        	    	    	  menu:[
	        	    	    	        {text:'abc'},
	        	    	    	        {text:'efg'},
	        	    	    	        {text:'hij'},
	        	    	    	        
	        	    	    	        {text:'Struktur',
	        	    	    	        	menu:[
	        	    	    	        	  {text:'Strukturplanung'},
	        	    	    	        	  {text:'Produktplanung',typeId : extVia.module.epob.PUBLICATION, epobDscr:'Katalog Frühjahr',
	        	    	  	    	        	  menu:{ 
	        	    	  	    	        		  defaults:{
	        	    	  	    	        			  handler:function(item, evt){	 
	        	    	  		  	    	        		extVia.publications.statics.openProductPlanningEditor({epobDscr:epobDscr, planningType: item.planningType },evt); 
	        	    	  		  	    	        	  }   
	        	    	  	    	        		  },
	        	    	  	    	        		  items:[
	        	    	  	    	        	        {text: 'Standard', planningType:'standard'},
	        	    	  	    	        	        {text: 'Regelbasiert', planningType:'rulebased'},
	        	    	  	    	        	        {text: 'Regelbasierter ProductExport', planningType:'rulebasedProductExport'}
	        	    	  	    	        	        ]
	        	    	  	    	              },
	        	    	    	        		  handler:function(item, evt){
	        	    	    	        			  extVia.publications.statics.openProductPlanningEditor({epobDscr:item.epobDscr},evt);
	        	    	    	        			  }
	        	    	    	        	  },
	        	    	    	        	  {text:'Knotenplanung'}
	        	    	    	        	 ]
	        	    	    	        },
	        	    	    	        {text:'klm'},
	        	    	    	        {text:'nop'},
	        	    	    	        {text:'query', handler:function(item, evt){ extVia.publications.statics.openQuery({}, evt);}
	        	    	    	        }
	        	    	    	       ],
	    	        			typeId : extVia.module.epob.PUBLICATION, 
	    	        			handler:function(item){
	    	        				extVia.regApp.centerTabPan.addAndActivate( extVia.publications.statics.getPublicationsEditorCfg({epobDscr:item.epobDscr}));
	    	        				}
	        	    	      }

        	                ] 
	        	       }

    	              ],
    				listeners:cfg.listeners
    	    	 } ;
    		
    		return publicationsAccessCfg;
    	},

    getPublicationsEditorCfg : function(cfg){
	
 	      return  {  
 	    	   title:cfg.epobDscr,
 	    	   xtype:'fakepanel',
	    	   height:800,
	    	   fake:cfg.fakestep?'../img/fakes/sketches/'+cfg.fakestep+'_publicationsMaintenanceSketch.gif':'../img/fakes/sketches/02_publicationsMaintenanceSketch.gif',
	    	   //itemId : 'publicationEditor',
	    	   onDropHandler:function(){
	    		 this.setFake('../img/fakes/sketches/04a_publicationsMaintenanceAddedSketch.gif');  
	    	   },
	    	   assignHandler:function(){
		    	 this.setFake('../img/fakes/sketches/04a_publicationsMaintenanceAddedSketch.gif');  
		       },
	    	   items:[
	    	          {x:266,y:150, itemId:'planningTab',
	    	        	hidden:cfg.fakestep,
	   	    		   handler:function(item){
	   	    			      var editorPan = item.ownerCt;
	   	    			      item.hide(); 
	   	    			      editorPan.setFake('../img/fakes/sketches/03_publicationsMaintenanceSketch.gif');
	   	    			      editorPan.getComponent('openPlanning').show();  

		    	          }
	    	          	},
		    	    {x:320,y:240, itemId:'openPlanning',
	    	          	   hidden:true,	
	 	   	    		   handler:function(item, evt){
	 	   	    			   
	 	   	    			   if (evt && evt.hasModifier( )){
	 	   	    				  extVia.publications.statics.openProductPlanningEditor({epobDscr:cfg.epobDscr},evt);
	    	    	        	  //extVia.regApp.centerTabPan.addAndActivate( extVia.publications.statics.getProductPlanningCfg({epobDscr:cfg.epobDscr}));   
	 	   	    			   }
	 	   	    			   else{	 	   	    			   		 	   	    			   
		   	    			      Ext.get('dnd_drop_zone').show();
	 	   	    			      var editorPan = item.ownerCt;
	 	   	    			      item.hide();
	 	   	    			      editorPan.setFake('../img/fakes/sketches/04a_publicationsMaintenanceSketch.gif');
	 	   	    			      editorPan.getComponent('query').show();
	 	   	    			      editorPan.getComponent('csv').show();
	 	   	    			      editorPan.getComponent('ruleBased').show();
	 	   	    			      editorPan.getComponent('showRuleResult').show();  			      	 	   	    			  
	 	   	    			      editorPan.getComponent('copyTemplate').show();    
	 	   	    			   }

	 		    	          }
	 	    	          	},	    	          
	    	          {x:100,y:86, itemId:'query',
	    	             hidden:!cfg.fakestep,
		   	    		 handler:function(item, evt){  extVia.publications.statics.openQuery({}, evt);}
		    	      },
	    	          {x:150,y:86,itemId:'csv',
		    	    	hidden:!cfg.fakestep,
			   	    	handler:function(item){extVia.regApp.westTabPan.addAndActivate(extVia.publications.statics.getQueryCSVCfg({}));}
		    	      },	    	          
	    	          {x:200,y:86,itemId:'ruleBased',
		    	    	  hidden:!cfg.fakestep,
		   	    		  handler:function(item){extVia.dialoges.getRuleBasedDialog().show();}
		    	      },
	    	          {x:250,y:86,itemId:'copyTemplate',
		    	    	  hidden:!cfg.fakestep,
		    	    	  handler:function(item){extVia.dialoges.getSelectTemplateDialog().show();}
		    	      },
	    	          {x:370,y:266,itemId:'showRuleResult',
		    	    	  hidden:!cfg.fakestep, 
		    	    	  listeners:{
		    	      		'afterrender':function(item){
		    	      			var buttonEl = Ext.get(item.id);
		    	      			buttonEl.on ('mousedown',function(){item.ownerCt.setFake('../img/fakes/sketches/04a_publicationsMaintenanceAddedSketch.gif');});
		    	      			buttonEl.on ('mouseup',function(){item.ownerCt.setFake('../img/fakes/sketches/04a_publicationsMaintenanceSketch.gif');});	
		    	      		}
		    	    	  },
		    	    	  handler:null
		    	      }
	    	          ]
	    	};
    		
    	},
    	
    	
    	openProductPlanningEditor : function(cfg, evt){
    		var productPlanningEditorCfg;
    		Ext.get('dnd_drop_zone').show();
    		
			if ( ( evt &&  evt.hasModifier( )) || cfg.planningType ){

				Ext.get('drop-zone-text').show();

				
		    	Ext.getBody().removeCls('xty_fake-bin');
		    	extVia.regApp.westTabPan.addAndActivate(extVia.publications.statics.getQueryCfg({newQuery:true})); 
		    	// extVia.publications.statics.openQuery({}, evt);
		    	//extVia.regApp.westTabPan.add(extVia.query.statics.getQueryTabCfg());
		    	extVia.regApp.westTabPan.addUnique(extVia.hierarchy.statics.getHierarchyTabCfg({}));
		    	extVia.regApp.westTabPan.getComponent('publicationsAccess').close();

				productPlanningEditorCfg =     extVia.publications.statics.getProductPlanningEditorCfg(cfg, evt);	
		    }
			else{
				productPlanningEditorCfg =    extVia.publications.statics.getProductPlanningCfg(cfg, evt);			
			}
			var ProductPlanningEdiTab =  extVia.regApp.centerTabPan.addAndActivate(productPlanningEditorCfg );
    		
    	},
    	getProductPlanningEditorCfg : function(cfg){

    		var rulebased = cfg.planningType=='rulebased'  || cfg.planningType=='rulebasedProductExport' ;
    		var rulebasedProductExport = cfg.planningType=='rulebasedProductExport';
    		
        	var editorMainTabItemId = 'productPlanningEditorPanel'+cfg.epobDscr ;	
        	
        	
  	      
  	      
  		  
 		   var filterComboCfg = {
 				   triggerCls:'xty_form-trigger-filter',
 				   hidden:rulebased,  
 				   xtype:'combo',
 				   displayField: 'dscr',
 				   emptyText:'filter Planning',
 				   itemIid:'productPlanningFilterCombo',
 				   validator:function(val){
 				    	  try {new RegExp(val);return true;}
 				    	  catch(rgxEx){return "Die Eingabe ist nicht Regex-konform<br>"+rgxEx;}
 				   },
 				    queryMode: 'local',
 				    mode: 'local',
 				    //value:'(sup)(.*)(ero)',
 				    defaultListConfig :{draggasble:true, floating:true, maxHeight:48, cls:'xty_mini-bound-list'},
 				    autoCompleteInsert:extVia.stores.inputTextautoCompleteInsert,
 				    store:   
 					   Ext.create('Ext.data.Store', {   
 						            model:  Ext.define('QuickSearchField', {
 						    	    fields: ['value','dscr'],
 						    	    extend: 'Ext.data.Model'
 						    	})
 					   }) ,
 				   
 					   listeners:{
 					
 						   specialkey:  extVia.stores.inputTextautoCompleteInsertonEnter,
 						   
 						   change:function( combo, newValue, oldValue, eOpts ){
 					        	var grid =Ext.getCmp("mengenGrid");
 					        	grid.store.clearFilter();
 					        	var sortX = new RegExp(newValue,'gi');
 					        	if (newValue.length>0){ grid.store.filter("name", sortX);}

 							   }
 					   }
 		   };
        	
        	
        	var	editorPgjobButtons =[                   
        	   	                     
        	   	filterComboCfg,
        	   	{xtype:'tbspacer', width:10},     
        	   	                     {
                xtype: 'buttongroup',
                columns: 3,
                defaults: {
                    scale: 'small'
                },
                items: [
     		  {iconCls : 'xty_pgtoolbar-list'},
     		  //{iconCls : 'xty_pgtoolbar-thumbsBig'},
     		  //{iconCls : 'xty_pgtoolbar-thumbsSmall'},
     		  {iconCls : 'xty_pgtoolbar-tree'},
     		  {iconCls : 'xty_pgtoolbar-assignments', tooltip:'Anzeigetiefe',
	    	        menu:{
	    	        	items:[{
	    	        		xtype:'fakepanel', hasPanelHeader:true, title:'Anzeigetiefe',height:170, width:296, fake:'../img/fakes/sketches/05c_queryFieldset_productrelations.gif'
	    	        	}] 
	    	        	}
     		 		}
               ]           
     	   }];
        	
        	var	editorPagetoolbarButtons =[
        	  
        	  //{ name : 'save',hidden:rulebased,     itemId:'save', tooltip : 'Save'},
                
             // {xtype:'tbspacer', width:10},     
	          {itemId:'query',  tooltip:'Suchen und hinzufügen',  iconCls : 'xty_pgtoolbar-searchAndAssign',	hidden:rulebased,            
	   	    		 handler:function(item, evt){extVia.publications.statics.openQuery({}, evt);}
	    	      },
		      {itemId:'querySave',  tooltip:'Suche speichern',  iconCls : 'xty_pgtoolbar-searchSave',	hidden: !rulebased,            
		   	    		 handler:function(item, evt){}
		      },   
	          {itemId:'queryShow',  tooltip:'Suche zeigen',  iconCls : 'xty_pgtoolbar-searchShow',	hidden:!rulebased,            
		   	    		 handler:function(item, evt){extVia.publications.statics.openQuery({}, evt);}
		    	      },
	          {itemId:'queryDelete',  tooltip:'Suche löschen',  iconCls : 'xty_pgtoolbar-searchDelete',	hidden:!rulebased,            
	   	    		 handler:function(item, evt){}
	    	      },		    	      
   	          {itemId:'csv',  tooltip:' CSV basiert hinzufügen', iconCls : 'xty_pgtoolbar-searchCSV',	hidden:rulebased,         	  
	    	    	 handler:function(item){extVia.regApp.westTabPan.addAndActivate(extVia.publications.statics.getQueryCSVCfg({}));}
	    	  },	    	          
   	          {itemId:'ruleBased', tooltip:'regelbasiert hinzufügen', iconCls : 'xty_pgtoolbar-assignRulebased', hidden:rulebased,    	     
	    		  handler:function(item){extVia.dialoges.getRuleBasedDialog().show();}	    	    	 
	    	  },

   	          {itemId:'copyTemplate', tooltip:'aus bestehenden Planungen hinzufügen', iconCls : 'xty_pgtoolbar-copy',	hidden:rulebased,         	
	    	    	  handler:function(item){extVia.dialoges.getSelectTemplateDialog().show();}
	    	  }	, 
        	
	    	  {xtype:'tbspacer', width:10},    	 	    
	    	  
	    	  {itemId:'removeItem', tooltip:'Kindobjekt l&ouml;schen',iconCls : 'xty_pgtoolbar-removeItem',hidden:rulebased     }  ,	
	          {itemId:'delete',  tooltip:'Produktplannung löschen',  iconCls : 'xty_pgtoolbar-remove',            
	   	    		 handler:function(item, evt){}
	    	      }
        	];	
	



        	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28 -136 ;// tabstrip appbar tabstrip
        	//var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
        	
        	var pgjobEpobDscr='Publikation  » '+cfg.epobDscr;
        	var pgjobDscr =  (rulebased?'regelbasierte ':'') +'Produktplanung';

        	var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:pgjobDscr, epobDscr:pgjobEpobDscr,  pagetoolbarButtons: editorPagetoolbarButtons, pgjobButtons: editorPgjobButtons} );


        	var productPlanningEditorCfg = {
        				title:pgjobEpobDscr, 
        				applibarId:applibar.id,
        				tbar : applibar,
        				getApplicationBar:function(){},
        				closable:true,
        				active:true,
        				itemId:editorMainTabItemId,
        				stateId:editorMainTabItemId,
        				
        				items:[ 
        				       {  
							   xtype:'fakepanel',
							   height:mainContentPanelHeight,
							   fake: rulebased ?'../img/fakes/sketches/09_prodPlanningTreeGraySketch.gif':'../img/fakes/sketches/09_prodPlanningSelectedTemplatesSketch.gif'},
        				       { height:mainContentPanelHeight }
                          ]};
        	
        	return productPlanningEditorCfg;
    	},
    	
    	getProductPlanningCfg : function(cfg){
          Ext.get('dnd_drop_zone').show();
    		
   	      return  {  
	    	   xtype:'fakepanel',
	    	   title:cfg.epobDscr,
	    	   height:800,
	    	   fake:'../img/fakes/sketches/04c_productPlanningSketch.gif',
	    	   //itemId : 'productPlanning',
	    	   onDropHandler:function(){
		    	this.setFake('../img/fakes/sketches/04c_productPlanningAddedSketch.gif');  
		       },
	    	   assignHandler:function(){
		    	this.setFake('../img/fakes/sketches/04c_productPlanningAddedSketch.gif');  
		       },
	    	   items:[
	    	          {x:100,y:86, itemId:'query',  tooltip:'Suchen und hinzufügen', 	            
			   	    		 handler:function(item, evt){ extVia.publications.statics.openQuery({}, evt);}
			    	      },
		    	          {x:150,y:86,itemId:'csv',  tooltip:' CSV basiert hinzufügen', 	  
			    	    	 handler:function(item){extVia.regApp.westTabPan.addAndActivate(extVia.publications.statics.getQueryCSVCfg({}));}
			    	      },	    	          
		    	          {x:200,y:86,itemId:'ruleBased', tooltip:'regelbasiert hinzufügen',  handler:function(item){extVia.dialoges.getRuleBasedDialog().show();}	    	    	 
			    	      },
		    	          {x:660,y:86,itemId:'showRuleResult',
			    	    	  listeners:{
			    	      		'afterrender':function(item){
			    	      			var buttonEl = Ext.get(item.id);
			    	      			buttonEl.on ('mousedown',function(){item.ownerCt.setFake('../img/fakes/sketches/04c_productPlanningRuleAddedSketch.gif');});
			    	      			buttonEl.on ('mouseup',function(){item.ownerCt.setFake('../img/fakes/sketches/04c_productPlanningSketch.gif');});	
			    	      		}
			    	    	  },
			    	    	  handler:null
			    	      },
		    	          {x:250,y:86,itemId:'copyTemplate', tooltip:'aus bestehenden Planungen hinzufügen', 	
			    	    	  handler:function(item){extVia.dialoges.getSelectTemplateDialog().show();}
			    	      }	 
	    	          
	    	          
	    	          ]
	    	};
    	},

    	
    	openQuery : function(cfg, evt){	
    		
			if (evt && evt.hasModifier( )){
				extVia.regApp.westTabPan.add(extVia.query.statics.getQueryTabCfg(cfg));
			}
			else{
				extVia.regApp.westTabPan.addAndActivate(extVia.publications.statics.getQueryCfg(cfg));
			}	
    	},
    	
    	getQueryCfg : function(cfg){	
    	  extVia.publications.statics.hideDragger();
    	  
    	  var fake = cfg.result?'../img/fakes/sketches/06_prodPlanningQueryResultXSketch.gif':'../img/fakes/sketches/05_prodPlanningQueryXSketch.gif';
    	  if (cfg.newQuery){
    		  fake = cfg.result?'../img/fakes/sketches/06_prodPlanningQueryResultXSketch.gif':'../img/fakes/sketches/05_prodPlanningQuerySketch.gif';  
    	  }
    	  
    	  
   	      return  {  
	    	   xtype:'fakepanel',
	    	   title:'query',
	    	   height:800,
	    	   fake:fake,//cfg.result?'../img/fakes/sketches/06_prodPlanningQueryResultXSketch.gif':'../img/fakes/sketches/05_prodPlanningQueryXSketch.gif',
	    	   items:[
	    	          {x:288,y:8, itemId:'close', hidden:cfg.newQuery, handler:function(item){
	    	        	  item.ownerCt.close();
	    	        	  extVia.publications.statics.hideDragger();
	    	          }
	    	          },
	    	          {x:266,  y:cfg.newQuery?28:48, itemId:'search', xtype:'splitbutton',
    	    	    	  menu:[
    	    	    	        {text:'Suchbegriff'},
    	    	    	        '-',
    	    	    	        {text:'Spracheinstellung'},
    	    	    	        {text:'Ergebnisdarstellung'},
    	    	    	        {text:'Anzeigetiefe',
    	    	    	        menu:{
    	    	    	        	items:[{
    	    	    	        		xtype:'fakepanel', height:170,width:296, fake:'../img/fakes/sketches/05c_queryFieldset_productrelations.gif'
    	    	    	        	}]
    	    	    	        }	
    	    	    	        },
    	    	    	        '-',
    	    	    	        {text:'Schnellrecherche'},
    	    	    	        {text:'Erweiterte'}
    	    	    	       ],
	    	        	  
	    	        	  handler:function(item){
	    	        	  item.ownerCt.setFake('../img/fakes/sketches/06_prodPlanningQueryResultXSketch.gif');
	    	        	  
	    	        	  Ext.get(item.ownerCt.id).on('click',function(){
	    	        		  if (!item.ownerCt.clickCount){
	    	        			  item.ownerCt.clickCount=0;
	    	        		  }
	    	        		  item.ownerCt.clickCount++;
	    	        			 
	    	        		  //alert("query click")
	    	        		  if (item.ownerCt.clickCount==2){
	    	        			  item.ownerCt.getComponent('applyToCenter').show();  
	    	        		  }
	    	        			  
	    	        	  }); 
	    	        	  extVia.publications.statics.initDragger(item.ownerCt.id);
	    	          	}
	    	          },
	    	          {x:274,y:628, hidden:true,iconCls:'xty_pgtoolbar-assignToRight' ,width:40, scale : extVia.constants.raster.pagetoolbarCenterBtnScale, itemId:'applyToCenter',
	    	        	  handler:function(){
	    	          		if (extVia.regApp.centerTabPan.getActiveTab().assignHandler){
	    	        			extVia.regApp.centerTabPan.getActiveTab().assignHandler();
	    	        		} 
	    	        	  }
	    	          }
	    	          ],
	    	   itemId : 'queryFake'
	    	   
	    	};
    	},

  
    	getQueryCSVCfg : function(cfg){
    	  extVia.publications.statics.hideDragger();
    		
   	      return  {  
	    	   xtype:'fakepanel',
	    	   title:'csv',
	    	   height:800,
	    	   items:[
	    	          {x:288,y:8, handler:function(item){
	    	        	  item.ownerCt.close();
	    	        	  extVia.publications.statics.hideDragger();
	    	          }
	    	          },
	    	          {x:266,y:48, itemId:'search', hidden:true,handler:function(item){
	    	        	  item.ownerCt.setFake('../img/fakes/sketches/07_prodPlanningQueryCSVResultXSketch.gif');
	    	        	  extVia.publications.statics.initDragger(item.ownerCt.id);
	    	          	}
	    	          },
	    	          {x:260,y:140, itemId:'csvFile',handler:function(item){
	    	        	  item.ownerCt.getComponent('search').show();
	    	        	  item.hide();
	    	        	  item.ownerCt.setFake('../img/fakes/sketches/07b_prodPlanningQueryCSVXSketch.gif');
	    	          	}
	    	          }
	    	          ],
	    	   fake:'../img/fakes/sketches/07a_prodPlanningQueryCSVXSketch.gif',
	    	   itemId : 'queryCSVFake'
	    	};
    	},
      	
    	getSelectedPlanungenCfg : function(cfg){
    		return  { 
    			 xtype:'fakepanel',
				   //title:'Planungen',
    			 height:240,
    			 fake:'../img/fakes/sketches/09_prodPlanningSelectedTemplatesSketch.gif'
    		}
    	},
    	
    	getFLOWChart : function(cfg){
        	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-4;// tabstrip
        	var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip

     	     return  { 
     	    	 title:'flowchart',
	  	    	 listeners:{
	  	    		   'activate':function(){
	  	    		    	Ext.get('drop-zone-text').hide();
	  	    		    	Ext.get('dnd_drop_zone').hide();
	  	    		   }
	  	    	   },
     	    	 autoScroll:true,
	  	    	   height:mainContentPanelHeight,
	  	    	   width:mainContentPanelWidth,
     	    	 items:
	     	      {  
	  	    	   xtype:'fakepanel',
	  	    	  // title:'flowchart',
	  	    	   items:[
	  	    	          {x:340,y:166, itemId:'publicationEditor',
	  	    	        	  handler:function(item, evt){	 
		 	  	    	        	 extVia.regApp.centerTabPan.addAndActivate( extVia.publications.statics.getPublicationsEditorCfg({fakestep:'04a',epobDscr:cfg.epobDscr}));
		  	    	          }    
	  	    	          },
	  	    	          {x:510,y:166, itemId:'productPlanner', 
//	  	    	        	  xtype:'splitbutton',
//	  	    	        	  menu:{ 
//	  	    	        		  defaults:{
//	  	    	        			  handler:function(item, evt){	 
//	  		  	    	        		extVia.publications.statics.openProductPlanningEditor({epobDscr:cfg.epobDscr, planningType: item.planningType },evt); 
//	  		  	    	        	  }   
//	  	    	        		  },
//	  	    	        		  items:[
//	  	    	        	        {text: 'Standard', planningType:'standard'},
//	  	    	        	        {text: 'Regelbasiert', planningType:'rulebased'},
//	  	    	        	        {text: 'Regelbasierter ProductExport', planningType:'rulebasedProductExport'}
//	  	    	        	        ]
//	  	    	              },
//	  	    	        	  
	  	    	        	  handler:function(item, evt){	
	  	    	        		
	  	    	        		 //WHY does here come NO event when its a splitbutton?????
	  	    	        		 //alert("evt "+evt) 
	  	    	        		extVia.publications.statics.openProductPlanningEditor({epobDscr:cfg.epobDscr},evt); 
	 	  	    	        	// extVia.regApp.centerTabPan.addAndActivate( extVia.publications.statics.getProductPlanningCfg({epobDscr:cfg.epobDscr}))
	  	    	        	  }  
	  	    	          },
	  	    	         
	  	    	          {x:284,y:300, itemId:'query' , handler:function(item, evt){extVia.publications.statics.openQuery({}, evt);}},
	  	    	          {x:380,y:300, itemId:'csv', handler:function(item){extVia.regApp.westTabPan.addAndActivate(extVia.publications.statics.getQueryCSVCfg({}));}},
	  	    	          {x:500,y:300, itemId:'rulebased',handler:function(item){extVia.dialoges.getRuleBasedDialog().show();}},
	  	    	          {x:590,y:300, itemId:'template', handler:function(item){extVia.dialoges.getSelectTemplateDialog().show();}},
	  	    	          
	  	    	          {x:280,y:506, itemId:'queryResult',  handler:function(item, evt){
	  	    	        	 extVia.publications.statics.openQuery({result:true}, evt);
	  	    	          }},
	  	    	          {x:462,y:506, itemId:'rulebasedResult'},
	  	    	          {x:590,y:506, itemId:'templateResult'}
	  	    	          ],
	  	    	   height:mainContentPanelHeight-28,
	  	    	   width:900,
	  	    	   backgroundSize:'auto 700px',
	  	    	   fake:'productplannerFLOW.svg'
	  	    	   //html:'<img  height="700px"   src="productplannerFLOW.svg" alt="">'
	  	    	}
     	    };
      	}, 	
    	
    	
    	
   initClickDetector : function(cfg){

	   var xyDetector =function(evt){
		   var centerXY =Ext.get(extVia.regApp.centerTabPan.getActiveTab().id).getXY();
		   var centerX =centerXY[0]; var centerY = centerXY[1];
		   
		   var clickXY =evt.getXY();
		   var clickX =clickXY[0]; var clickY =clickXY[1]; 

		   var westXY =Ext.get(extVia.regApp.westTabPan.getActiveTab().id).getXY();
		   var westX = westXY[0]; var westY = westXY[1];
		   var inWestX =clickX-westX; var inWestY = (clickY-westY);
		   
		   var inCenterX =clickX-centerX; var inCenterY = (clickY-centerY);
		   
		   alert ("absoluteXY:"+clickXY+" \n\tinWestXY:"+" "+inWestX+","+inWestY+"  \n\tinCenterXY"+" "+inCenterX+","+inCenterY);
		   };
	   
	   Ext.getBody().on('click',xyDetector);
   },
    	
      	
   
   hideDragger : function(){
	   var dragger = Ext.get('dragger');
	   if (dragger){
		   dragger.hide();
	   }
   },
   initDragger : function(ownerPanelId){

	   if (!extVia.publications.statics.draggerInited){
	   
            Ext.DomHelper.append(Ext.getBody(), {tag: 'div', style:'left:242px;top:566px;' , cls: 'xty_dragger', id: 'dragger' });

        	new Ext.dd.DragSource("dragger", {dragData:{epobDscr: "Produkt 123"}});
        	var droptargetCenter = new Ext.dd.DropTarget(extVia.regApp.centerTabPan.id);
        	
        	droptargetCenter.notifyDrop=function(dd, evt, data){

        		
        		if (extVia.regApp.centerTabPan.getActiveTab().onDropHandler){
        			extVia.regApp.centerTabPan.getActiveTab().onDropHandler();
        		}
        		
        		
        		if (evt.target.id=='dnd_drop_zone'){
             		Ext.create('widget.uxNotification', {
        				title:'dropped' ,
        				position: 'tr',
        				manager: 'instructions',
        				cls: 'ux-notification-light',
        				iconCls: 'ux-notification-icon-information',
        				html :  evt.target.id+' '+data.epobDscr+'' + dd.id + ' on Planung',  
        				slideInAnimation: 'bounceOut',
        				slideBackAnimation: 'easeIn'
        			}).show();
        		}
        		

        	 return true;
        	};
        	
        	var droptargetZone = new Ext.dd.DropTarget('dnd_drop_zone');
        	droptargetZone.notifyDrop = droptargetCenter.notifyDrop;

        	
        	extVia.publications.statics.draggerInited=true;
      	}

	   else{
		   Ext.get('dragger').show();
	   }
   }// eo initDragger	
  
  }// eo statics
});
