Ext.namespace('extVia.locales' ,'extVia.dqi.locales');
/**
 * @class plain
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2019/07/03 16:55:23 $
 *            $Revision: 1.1.2.4 $
 */


extVia.dqi.locales = {
      appName:['dqi','dqi'],
      modul:['dqi','dqi']
   
     };

     if (!Ext.isDefined(extVia.locales.uiLangIsoIx)){
       extVia.locales.uiLangIsoIx = 1; // EN 
       if (Ext.isDefined( extVia.ui.page.strings.languageId)){
         if(extVia.ui.page.strings.languageId==="2"){ // DE
           extVia.locales.uiLangIsoIx = 0; 
         }
       }  
     }

     
     Ext.Object.each(extVia.dqi.locale_DE_EN, function(key, value, myself) {
         extVia.dqi.locales[key] = value[extVia.locales.uiLangIsoIx];
     });


     Ext.apply(extVia.locales, extVia.dqi.locales);




/*
 * 
 * $Revision: 1.1.2.4 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2019/07/03 16:55:23 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 