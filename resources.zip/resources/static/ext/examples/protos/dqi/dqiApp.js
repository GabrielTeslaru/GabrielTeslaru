/**
 * 
 */
Ext.application({
    name: 'dqi',
    version: '$Revision: 1.1.2.22 $',

    /**
     * Place 
     */
    appMode: {},

    getContentPanelHeight: function() {
        var me = this;
        return me.getCenterHeight();
    },

    getEditorContentPanelHeight: function() {
        var me = this;
        return me.getCenterHeight({ hasPagetoolbar: true });
    },

    getEditorSubTabHeight: function() {
        var me = this;
        return me.getCenterHeight({ hasPagetoolbar: true, hasSubtabs: true });
    },

    getCenterHeight: function(cfg) {
        var centerPan = extVia.regApp.myRaster.getCenter();
        var centerHeight = centerPan.getHeight();
        centerHeight -= 25; // substract center-tabstrip 
        centerHeight -= 66; // substract pagejobbar 
        if (cfg && cfg.hasPagetoolbar) {
            centerHeight -= 60; // substract pagetoolbar 
        }
        if (cfg && cfg.hasSubtabs) {
            centerHeight -= 30; // substract subtabstrip
        }
        return centerHeight;
    },

    getCenterWidth: function(cfg) {
        var centerPan = extVia.regApp.myRaster.getCenter();
        var centerWidth = centerPan.getWidth() - 50;
        return centerWidth;
    },

    getWestListHeight: function(cfg) {
        var westPan = extVia.regApp.myRaster.getWest();
        var westHeight = westPan.getHeight() - 28; // ohne tabs toolbar + bottombar   
        return westHeight;
    },
    deleteEpobDialog: function(panel) {
        var me = this;
        var record = panel.getSelectionModel().getSelection();
        try {
            var itemName = record[0].get('name');
            var dialogWindow = Ext.create('widget.window', {
                width: 520, // extVia.dialoges.dialogDefaultWidth,
                y: 180,
                title: 'Delete',
                plain: true,
                items: [{
                    border: false,
                    minHeight: 200,
                    itemId: 'myFormPanel',
                    xtype: 'form',
                    fieldDefaults: {
                        msgTarget: 'side'
                    },
                    defaults: {
                        style: 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                        anchor: '100%',
                        labelWidth: 150,
                        width: 350,
                        msgTarget: 'side'
                    },
                    items: [
                        extVia.dialoges.getInstructionPanel({
                            mainInstr: 'Are you sure you want to delete ' + itemName + '?'
                        })
                    ]
                }],
                buttons: {
                    itemId: 'myButtons',
                    items: [{
                        xtype: 'tbspacer',
                        width: 70
                    }, {
                        itemId: 'btnSave',
                        text: 'Yes',
                        disabled: false,
                        handler: function(button, evt) {
                            panel.store.remove(record);
                            panel.getView().refresh();
                            button.up("window").close();
                        }
                    }, {
                        itemId: 'btnClose',
                        text: 'No',
                        disabled: false,
                        handler: function(button, evt) {
                            button.up("window").close();
                        }
                    }]
                }
            }).show();
        } catch (err) {
            extVia.notify({
                action: 'Delete',
                mssg: 'No record selected'
            });
        }
    },
    onSave : function(item) {
        var me = this;
        var centerPanel = extVia.regApp.myRaster.getCenterTabPanel();
        var westPanel = extVia.regApp.myRaster.getWestTabPanel();
        var editorPanel = null;
        var rawExist = null;
        
        if (item) {
            rawExist = item.raw.id;
        } else {
            rawExist = null;
        }

        
        var masterDataTab;
        var metadataPanel;
        var ruleSetPanel;
        var storeDQG;
        var rootNode;
        
        var Name ;
        var QualityGate;
        var Gestartet;
        var Version;
        var chilToAppend;
        
        
        if(rawExist){
            if (centerPanel.getComponent('elementsEditorGate'+item.raw.id)){
                editorPanel = centerPanel.getComponent('elementsEditorGate'+item.raw.id);

            } else if(centerPanel.getComponent('elementsEditorRuleSet'+item.raw.id)){
                editorPanel = centerPanel.getComponent('elementsEditorRuleSet'+item.raw.id);
            }
        } else {
            if(centerPanel.getComponent('elementsEditorNewRuleSet')){
                editorPanel = centerPanel.getComponent('elementsEditorNewRuleSet');
                 masterDataTab = editorPanel.getComponent('editorSubTabsPanel');
                 metadataPanel = masterDataTab.getComponent('MasterDataTab').getComponent('metadata');
                 ruleSetPanel = masterDataTab.getComponent('transitionNotificationTab').getComponent('DQCPanel');
                 storeDQG = extVia.stores.getDQGStore();
                 rootNode = storeDQG.getRootNode();
                
                if (metadataPanel.getForm().isValid()) {
                     Name = metadataPanel.items.items[0].rawValue;
                     QualityGate = metadataPanel.items.items[1].rawValue; // verifica numele selectat cu numele din tree si ia id din tree
                     Gestartet = metadataPanel.items.items[2].rawValue;
                     Version = metadataPanel.items.items[3].rawValue;
                     storeDQG = extVia.stores.getDQGStore();
                    var storeChilds = storeDQG.tree.root.childNodes;
                    var addToNode = null;
                    var i ;
                    for (i=0;i<storeChilds.length;i++){
                        if(storeDQG.tree.root.childNodes[i].raw.name === QualityGate){
                           addToNode = storeDQG.getNodeById(storeDQG.tree.root.childNodes[i].raw.id);
                           }
                    }
                    chilToAppend = {
                        id: Ext.id(),
                        text: Name,
                        name: Name,
                        cls: 'xty_node-modifier',
                        iconCls: 'xty_epobRuleset',
                        expanded: false,
                        epobType: 'Ruleset'
                    };

                    //westPanel.getView().refresh();
                    //store.add(store,);
                    //         store.data.items.forEach(function(ArrayElement) {
                    //            if (ArrayElement.data.id ==== epimId) {
                    //              record = ArrayElement;
                    //            }
                    //          });
                    addToNode.appendChild(chilToAppend);
                    editorPanel.close();
                    extVia.notify({
                        action : 'Save',
                        mssg : 'Saved'
                    }); 
                } else {
                    extVia.notify({
                        status : "Warning",
                        action : '',
                        mssg : "The mandatory fields weren't all filled out"
                    });
                }
            } else if (centerPanel.getComponent('elementsEditorNewGate')){
                editorPanel = centerPanel.getComponent('elementsEditorNewGate');
                 masterDataTab = editorPanel.getComponent('editorSubTabsPanel');
                 metadataPanel = masterDataTab.getComponent('MasterDataTab').getComponent('metadata');
                 ruleSetPanel = masterDataTab.getComponent('transitionNotificationTab').getComponent('DQCPanel');
                 storeDQG = extVia.stores.getDQGStore();
                 rootNode = storeDQG.getRootNode();

                if (metadataPanel.getForm().isValid()) {
                     Name = metadataPanel.items.items[0].rawValue;
                     Gestartet = metadataPanel.items.items[1].rawValue;
                     Version = metadataPanel.items.items[2].rawValue;
                    var newIdToAppend = storeDQG.tree.nodeHash;
                    var keysTree = Object.keys(newIdToAppend).length + 1;

                    var chilToAppendTree = {
                        id: keysTree,
                        text: Name,
                        name: Name,
                        expanded: true,
                        cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                        iconCls: 'xty_epobQualityIndex',
                        epobType: 'QualityIndex'
                    };
                    
                    var getQalityGatesStore = extVia.stores.getQualityGatesStore();
                    var newQalityGatesStoreId = getQalityGatesStore.data.items.length +1;
                    
                    chilToAppend = {
                        id: newQalityGatesStoreId,
                        text: Name,
                        name: Name
                    };
                    
                    rootNode.appendChild(chilToAppendTree);
                    extVia.stores.addQualityGatesStore(chilToAppend);
                    
                    editorPanel.close();
                    extVia.notify({
                        action : 'Save',
                        mssg : 'Saved'
                    }); 
                } else {
                    extVia.notify({
                        status : "Warning",
                        action : '',
                        mssg : "The mandatory fields weren't all filled out"
                    });
                }
            }
        }
    },
    showAddDialog: function(panel, item, editor) {
        var me = this;
        var dialogWindow;
        if (item === 'Rule') {
            var selectedRuleSet = null;
            var currentEditor = null;
            if (panel.getSelection) {
                selectedRuleSet = panel.getSelection();
            }
            if (editor === 'RulesetEditor') {
                currentEditor = editor;
            }
            
            
            
            dialogWindow = Ext.create('widget.window', {
                width: 520,
                y: 180,
                title: 'Add ' + item,
                plain: true,
                items: [{
                    border: false,
                    minHeight: 200,
                    itemId: 'myFormPanel',
                    xtype: 'form',
                    fieldDefaults: {
                        msgTarget: 'side'
                    },
                    defaults: {
                        style: 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                        anchor: '100%',
                        labelWidth: 150,
                        width: 350,
                        msgTarget: 'side'
                    },
                    items: [
                        extVia.dialoges.getInstructionPanel({
                            mainInstr: 'Add new ' + item
                        }),{fieldLabel: 'Name',xtype: 'textfield',itemId: "transition",name: 'transition',allowBlank: false,value: '',
                            labelSeparator: ':<span class="xty_requiredStar"> *</span>',
                            listeners: {
                                validitychange: function(view, isValid, eOpts) {
                                    if (!Ext.isEmpty(view.ownerCt)) {
                                        view.ownerCt.doLayout();
                                    }
                                }
                            }
                           },
                        {xtype: 'combo',fieldLabel: "Ruleset",itemId: 'epobType',name: 'epobType',allowBlank: true,labelSeparator: ':<span class="xty_requiredStar"> *</span>',emptyText: 'Select ruleset',queryMode: 'local',displayField: 'dscr',valueField: 'value',hidden: selectedRuleSet || currentEditor, store: extVia.stores.getCurentStore(),
                         listConfig: {
                             minWidth: 180,
                             getInnerTpl: function(displayField) {
                                 var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' +
                                     '&nbsp; {dscr}' + '</span></div></div>';
                                 return tpl;
                             }
                         }
                        },{xtype: 'combo',fieldLabel: "Quality Dimensions",itemId: 'qualityDimensions',name: 'qualityDimensions',allowBlank: true,labelSeparator: ':<span class="xty_requiredStar"> *</span>',emptyText: 'Select dimension',queryMode: 'local',displayField: 'dscr',valueField: 'value', store: extVia.stores.getQDCurentStore(),
                           listConfig: {
                               minWidth: 180,
                               getInnerTpl: function(displayField) {
                                   var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' +
                                       '&nbsp; {dscr}' + '</span></div></div>';
                                   return tpl;
                               }
                           }
                          },{fieldLabel: 'Command',xtype: 'textfield',itemId: "command",name: 'command',allowBlank: true,value: '',
                             listeners: {
                                 validitychange: function(view, isValid, eOpts) {
                                     if (!Ext.isEmpty(view.ownerCt)) {
                                         view.ownerCt.doLayout();
                                     }}}
                            }, {fieldLabel: 'Summary',xtype: 'textfield',itemId: "summary",name: 'summary',allowBlank: true,value: '',
                                listeners: {
                                    validitychange: function(view, isValid, eOpts) {
                                        if (!Ext.isEmpty(view.ownerCt)) {
                                            view.ownerCt.doLayout();
                                        }}}
                               },{fieldLabel: 'Definition',xtype: 'textarea',itemId: "definition",name: 'definition',allowBlank: true,value: '',
                                  listeners: {
                                      validitychange: function(view, isValid, eOpts) {
                                          if (!Ext.isEmpty(view.ownerCt)) {
                                              view.ownerCt.doLayout();
                                          }}}
                                 },{ fieldLabel: 'Formula',xtype: 'textarea',itemId: "formula",name: 'formula',allowBlank: true,value: '',
                                    listeners: {
                                        validitychange: function(view, isValid, eOpts) {
                                            if (!Ext.isEmpty(view.ownerCt)) {
                                                view.ownerCt.doLayout();
                                            }}}
                                   },
                        {xtype:'tbspacer', height: 10}
                    ]
                }],

                buttons: {
                    itemId: 'myButtons',
                    items: [{
                        xtype: 'tbspacer',
                        width: 70
                    }, {
                        itemId: 'btnSave',
                        text: 'Add',
                        disabled: false,
                        handler: function(button, evt) {
                            var formPan = button.up("window").getComponent("myFormPanel");
                            if (formPan) {
                                var form = formPan.getForm();
                                var formIsValid = form.isValid();
                                if (!formIsValid) {
                                    extVia.notify({
                                        action: 'Save',
                                        mssg: 'Form not valid'
                                    });
                                    return;
                                }
                                var selectedRuleSet = null;
                                var currentEditor = null;
                                if (panel.getSelection) {
                                    selectedRuleSet = panel.getSelection();
                                }
                                if (editor === 'RulesetEditor') {
                                    currentEditor = editor;
                                }
                                
                                var values = form.getValues();
                                if (!selectedRuleSet) {
                                    
                                    panel.store.add({
                                        id: Ext.id(),
                                        epobType: values.epobType,
                                        name: values.transition,
                                        Typ: 'Rule',
                                        status: 'Started',
                                        qualityDimensions: values.qualityDimensions,
                                        command: values.command,
                                        summary: values.summary,
                                        definition: values.definition,
                                        formula: values.formula
                                    });
                                } else {
                                    
                                    panel.store.add({
                                        id: Ext.id(),
                                        epobType: selectedRuleSet.group || currentEditor,
                                        name: values.transition,
                                        Typ: 'Rule',
                                        status: 'Started',
                                        qualityDimensions: values.qualityDimensions,
                                        command: values.command,
                                        summary: values.summary,
                                        definition: values.definition,
                                        formula: values.formula
                                    });
                                }
                                panel.getView().refresh();
                                button.up("window").close();
                            }
                        }
                    }]
                }
            }).show();
        } else {
            dialogWindow = Ext.create('widget.window', {
                width: 520,
                y: 180,

                title: 'Add ' + item,
                plain: true,
                items: [{
                    border: false,
                    minHeight: 200,
                    itemId: 'myFormPanel',
                    xtype: 'form',
                    fieldDefaults: {
                        msgTarget: 'side'
                    },
                    defaults: {
                        style: 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                        anchor: '100%',
                        labelWidth: 150,
                        width: 350,
                        msgTarget: 'side'
                    },
                    items: [
                        extVia.dialoges.getInstructionPanel({
                            mainInstr: 'Add new ' + item
                        }), {
                            fieldLabel: 'Name',
                            xtype: 'textfield',
                            itemId: "transition",
                            name: 'transition',
                            allowBlank: false,
                            value: '',
                            labelSeparator: ':<span class="xty_requiredStar"> *</span>',
                            listeners: {
                                validitychange: function(view, isValid, eOpts) {
                                    if (!Ext.isEmpty(view.ownerCt)) {
                                        view.ownerCt.doLayout();
                                    }
                                }
                            }
                        }
                    ]
                }],

                buttons: {
                    itemId: 'myButtons',
                    items: [{
                        xtype: 'tbspacer',
                        width: 70
                    }, {
                        itemId: 'btnSave',
                        text: 'Add',
                        disabled: false,
                        handler: function(button, evt) {
                            var formPan = button.up("window").getComponent("myFormPanel");
                            if (formPan) {
                                var form = formPan.getForm();
                                var formIsValid = form.isValid();
                                if (!formIsValid) {
                                    extVia.notify({
                                        action: 'Save',
                                        mssg: 'Form not valid'
                                    });
                                    return;
                                }
                                var values = form.getValues();
                                var record = {
                                    id: Ext.id(),
                                    dscr: values.transition,
                                    value: values.transition
                                };
                                extVia.stores.addRecordIntoStore(record);
                                panel.getView().refresh();
                                button.up("window").close();
                            }
                        }
                    }]
                }
            }).show();
        }
    },

    showEditDialog: function(transitionNotificationPanel, cfg) {
        var me = this;
        var dialogWindow = Ext.create('widget.window', {
            width: 520,
            y: 180,
            title: 'Edit Rule',
            plain: true,
            items: [{
                border: false,
                minHeight: 200,
                itemId: 'myFormPanel',
                xtype: 'form',
                fieldDefaults: {
                    msgTarget: 'side'
                },
                defaults: {
                    style: 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                    anchor: '100%',
                    labelWidth: 150,
                    width: 350,
                    msgTarget: 'side'
                },
                items: [
                    extVia.dialoges.getInstructionPanel({
                        mainInstr: 'Edit ' + cfg.name + ' rule'
                    }), {fieldLabel: 'Name',xtype: 'textfield',itemId: "transition",name: 'transition',allowBlank: false,value: cfg.name,
                         labelSeparator: ':<span class="xty_requiredStar"> *</span>',
                         listeners: {
                             validitychange: function(view, isValid, eOpts) {
                                 if (!Ext.isEmpty(view.ownerCt)) {
                                     view.ownerCt.doLayout();
                                 }}}
                        },{xtype: 'combo',fieldLabel: "Quality Dimensions",itemId: 'qualityDimensions',name: 'qualityDimensions',allowBlank: true,labelSeparator: ':<span class="xty_requiredStar"> *</span>',emptyText: 'Select dimension',queryMode: 'local',displayField: 'dscr',valueField: 'value',value:cfg.qualityDimensions,store: extVia.stores.getQDCurentStore(),
                           listConfig: {
                               minWidth: 180,
                               getInnerTpl: function(displayField) {
                                   var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' +
                                       '&nbsp; {dscr}' + '</span></div></div>';
                                   return tpl;
                               }}
                          },{fieldLabel: 'Command',xtype: 'textfield',itemId: "command",name: 'command',allowBlank: true,value: cfg.command,
                             listeners: {
                                 validitychange: function(view, isValid, eOpts) {
                                     if (!Ext.isEmpty(view.ownerCt)) {
                                         view.ownerCt.doLayout();
                                     }}}
                            },{fieldLabel: 'Summary',xtype: 'textfield',itemId: "summary",name: 'summary',allowBlank: true,value: cfg.summary,
                               listeners: {
                                   validitychange: function(view, isValid, eOpts) {
                                       if (!Ext.isEmpty(view.ownerCt)) {
                                           view.ownerCt.doLayout();
                                       }}}
                              },{fieldLabel: 'Definition',xtype: 'textarea',itemId: "definition",name: 'definition',allowBlank: true,value: cfg.definition,
                                 listeners: {
                                     validitychange: function(view, isValid, eOpts) {
                                         if (!Ext.isEmpty(view.ownerCt)) {
                                             view.ownerCt.doLayout();
                                         }}}
                                },{fieldLabel: 'Formula',xtype: 'textarea',itemId: "formula",name: 'formula',allowBlank: true,value: cfg.formula,
                                   listeners: {
                                       validitychange: function(view, isValid, eOpts) {
                                           if (!Ext.isEmpty(view.ownerCt)) {
                                               view.ownerCt.doLayout();
                                           }}}
                                  },{xtype:'tbspacer', height: 10}
                ]
            }],

            buttons: {
                itemId: 'myButtons',
                items: [{
                    xtype: 'tbspacer',
                    width: 70
                }, {
                    itemId: 'btnSave',
                    text: 'Save',
                    disabled: false,
                    handler: function(button, evt) {
                        var formPan = button.up("window").getComponent("myFormPanel");
                        if (formPan) {
                            var form = formPan.getForm();
                            var formIsValid = form.isValid();
                            if (!formIsValid) {
                                extVia.notify({
                                    action: '',
                                    mssg: 'Form not valid'
                                });
                                return;
                            }
                            var values = form.getValues();
                            var record = transitionNotificationPanel.getSelectionModel().getSelection();
                            record[0].set("name", values.transition);
                            record[0].set("text", values.transition);
                            record[0].set("qualityDimensions", values.qualityDimensions);
                            record[0].set("command", values.command);
                            record[0].set("summary", values.summary);
                            record[0].set("definition", values.definition);
                            record[0].set("formula", values.formula);
                            transitionNotificationPanel.getView().refresh();
                            button.up("window").close();
                        }
                    }
                }]
            }
        }).show();
    },

    showRulesetEditor: function(view, record, item, index, evt) {
        var me = extVia.regApp;
        var loc = extVia.locales;

        //General things
        var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
        };

        var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
        };
        var boxDefaults = { labelWidth: 180, width: 460, msgTarget: 'side', xtype: 'textfield', margin: '4 0 4 4' };
        var editorMainTabItemId = 'elementsEditorRuleSet' + record.get('id');

        //Breadcrumb things

        var epobType = record.raw.epobType;
        var recordText = record.raw.text;
        var recordName = record.raw.name;
        var pgjobDscr = loc.editType.replace(/\{type\}/, epobType);
        var pgjobEpobDscr = record.raw.name;
        var breadcrumb = 'Quality Index/' + pgjobEpobDscr;
        var parentName = record.parentNode.raw.name;
        //First tab things
        var MetadataPanel = {
            title: 'Metadaten',
            itemId: 'metadata',
            xtype: 'form',
            collapsible: true,
            width: 580,
            //defaults : boxDefaults,
            margin: '20 20 20 20',
            items: [{itemId: 'Name', xtype: 'textfield', fieldLabel: 'Name', value: recordName, margin: '4 4 4 4', labelSeparator: ':<span class="xty_requiredStar"> *</span>', width: 380 },
                    {xtype: 'combo',fieldLabel: "Quality Gate",itemId: 'groupEpobTypes',name: 'groupEpobTypes',allowBlank: false,labelSeparator: ':<span class="xty_requiredStar"> *</span>',emptyText: 'Select a quality gate',queryMode: 'local',displayField: 'dscr',valueField: 'value',value: parentName,width: 380,margin: '4 4 4 4',
                     store: extVia.stores.getQualityGatesStore(),
                     listConfig: {
                         minWidth: 180,
                         getInnerTpl: function(displayField) {
                             var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{text}"><span style="margin-top:-8px;">' +
                                 '&nbsp; {name}' + '</span></div></div>';
                             return tpl;
                         }
                     }
                    },
                    { itemId: 'started', xtype: 'displayfield', fieldLabel: 'Gestartet', value: 'Nein', margin: '4 4 4 4' },
                    { itemId: 'version', xtype: 'displayfield', fieldLabel: 'Version', value: '1', margin: '4 4 4 4' },
                    { xtype: 'tbspacer', height: 10 }
                   ]
        };
        //console.log(extVia.stores.getDQCStore());
        extVia.stores.getDQCStore().filter({property: 'ruleSet',value: recordName, exactMatch: true, caseSensitive: true});

        var DQCPanel;
        DQCPanel = Ext.create('Ext.grid.Panel', {
            store: extVia.stores.getDQCStore(),
            selectedGroup: null,
            itemId: 'DQCPanel',
            forceFit: true,
            rowSelect: true,
            cls: 'xty_transition-grid xty_grid-group-paranthesis xty_selectable-group-grid',
            border: false,
            margin: '0 0 0 0',
            width: "100%",
            height: 500,
            columns: [Ext.create('Ext.grid.RowNumberer'), {
                header: 'Typ',
                dataIndex: 'Typ',
                renderer: epobTypeRenderer,
                width: 5
            }, {
                header: 'Name',
                dataIndex: 'name'
            }, {
                header: 'status',
                dataIndex: 'status',
                renderer: statusRenderer
            }],
            listeners: {
                itemdblclick: function(view, record, item, index, evt, eOpts) {
                    var Typ = record.get('Typ');
                    if (Typ === 'Ruleset') {
                        me.showRulesetEditor(view, record, item, index, evt, eOpts);
                    } else if (Typ === 'Rule') {
                        var cfg = {
                            name: record.data.name,
                            id: record.data.id,
                            qualityDimensions: record.data.qualityDimensions,
                            command: record.data.command,
                            summary: record.data.summary,
                            definition: record.data.definition,
                            formula: record.data.formula
                        };
                        me.showEditDialog(DQCPanel, cfg);
                        //me.showRuleDialog(view, record, item, index, evt, eOpts);
                    } else {
                        me.showEditor(view, record, item, index, evt, eOpts);
                    }
                },
                itemcontextmenu: function(view, record, item, index, evt, eOpts) {
                    view.select(index);
                    evt.stopEvent();
                    var isActive = record.data.status === "Yes";
                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            hidden: isActive,
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                }
            }
        });
        var editorPagetoolbarButtons = [
            { iconCls: 'xty_pgtoolbar-save', itemId: 'btnSave', tooltip: 'Save', handler: function(button, evt) { me.onSave(record); } },
            { iconCls: 'xty_pgtoolbar-new', itemId: 'new', tooltip: 'New Object', handler: function(button, evt) { me.showAddGate(DQCPanel, 'Gate'); } },
            { text: '|' },
            { iconCls: 'xty_epobRule', itemId: 'newRule', tooltip: 'New Rule', handler: function(button, evt) { me.showAddDialog(DQCPanel, 'Rule', 'RulesetEditor'); } },
            { iconCls: 'xty_pgtoolbar-delete', itemId: 'delete', tooltip: 'Delete', handler: function(button, evt) { me.deleteEpobDialog(DQCPanel); } }
        ];
        var applibar = extVia.ui.page.pagejob.getApplicationBar({ pgjobDscr: pgjobDscr, epobDscr: pgjobEpobDscr, pagetoolbarButtons: editorPagetoolbarButtons, breadcrumb: breadcrumb });

        var centerEditorPanel = {
            title: pgjobEpobDscr,
            applibarId: applibar.id,
            tbar: applibar,
            getApplicationBar: function() {
                return applibar;
            },
            setPagejobDscr: function setPagejobDscr(pgjobDscr) { applibar.setPagejobDscr(pgjobDscr); },
            setEpobDscr: function setEpobDscr(epobDscr) { applibar.setEpobDscr(epobDscr); },
            getPagejobDscr: function getPagejobDscr() { applibar.getPagejobDscr(); },
            getEpobDscr: function getEpobDscr() { return applibar.getEpobDscr(); },
            closable: true,
            active: true,
            itemId: editorMainTabItemId,
            border: false,
            activeTab: 'Metadata',
            items: [{
                xtype: 'tabpanel',
                itemId : 'editorSubTabsPanel',
                border: false,
                refresh: function() { extVia.notify({ action: 'refresh on', mssg: this.title }); },
                tabBar: {
                    cls: 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
                    tools: [{
                        xtype: 'button',
                        cls: 'xty_striptool-button xty_striptool-button-refresh',
                        handler: function(button) {
                            var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                            extVia.notify({ action: 'Refresh Subtab', mssg: '<b>' + activeTab + '</b>' });
                        },
                        iconCls: 'x-tool x-tool-refresh'
                    }]
                },
                items: [{
                    title: 'Metadata',
                    itemId: 'MasterDataTab',
                    hidden: false,
                    border: false,
                    items: [MetadataPanel]
                }, {
                    title: 'Rules',
                    itemId: 'transitionNotificationTab',
                    hidden: false,
                    border: false,
                    items: [DQCPanel]
                }]
            }]
        };
        var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
        tabPanCenter.addAndActivate(centerEditorPanel);
    },
    showAddRuleset: function(panel, editor) {
        var me = extVia.regApp;
        var loc = extVia.locales;

        //General things
        var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
        };

        var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
        };
        var boxDefaults = { labelWidth: 180, width: 460, msgTarget: 'side', xtype: 'textfield', margin: '4 0 4 4' };
        var editorMainTabItemId = 'elementsEditorNewRuleSet';

        var MetadataPanel = {
            title: 'Metadaten',
            itemId: 'metadata',
            xtype: 'form',
            collapsible: true,
            width: 580,
            //defaults : boxDefaults,
            margin: '20 20 20 20',
            items: [{
                itemId: 'Name',
                xtype: 'textfield',
                fieldLabel: 'Name',
                value: '',
                emptyText: 'Add name',
                margin: '4 4 4 4',
                width: 380,
                labelSeparator: ':<span class="xty_requiredStar"> *</span>'
            }, {
                xtype: 'combo',
                fieldLabel: "Quality Gate",
                itemId: 'groupEpobTypes',
                name: 'groupEpobTypes',
                allowBlank: false,
                labelSeparator: ':<span class="xty_requiredStar"> *</span>',
                emptyText: 'Select a quality gate',
                queryMode: 'local',
                displayField: 'text',
                valueField: 'name',
                value: '',
                width: 380,
                margin: '4 4 4 4',
                store: extVia.stores.getQualityGatesStore(),
                listConfig: {
                    minWidth: 180,
                    getInnerTpl: function(displayField) {
                        var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{text}"><span style="margin-top:-8px;">' +
                            '&nbsp; {name}' + '</span></div></div>';
                        return tpl;
                    }
                }
            },
                    { itemId: 'started', xtype: 'displayfield', fieldLabel: 'Gestartet', value: 'Nein', margin: '4 4 4 4' },
                    { itemId: 'version', xtype: 'displayfield', fieldLabel: 'Version', value: '1', margin: '4 4 4 4' },
                    { xtype: 'tbspacer', height: 10 }
                   ]
        };

        extVia.stores.getDQCStore().filter({property: 'qualityIndex',value: '', exactMatch: true,caseSensitive: true});

        var DQCPanel;
        DQCPanel = Ext.create('Ext.grid.Panel', {
            store: extVia.stores.getDQCStore(),
            features: [Ext.create('Ext.grid.feature.Grouping', {
                groupHeaderTpl: '{name}',
                id: '{name}'
            })],
            selectedGroup: null,
            itemId: 'DQCPanel',
            forceFit: true,
            rowSelect: true,
            cls: 'xty_transition-grid xty_grid-group-paranthesis xty_selectable-group-grid',
            border: false,
            margin: '0 0 0 0',
            width: "100%",
            height: 500,
            columns: [Ext.create('Ext.grid.RowNumberer'), {
                header: 'Typ',
                dataIndex: 'Typ',
                renderer: epobTypeRenderer,
                width: 5
            }, {
                header: 'Name',
                dataIndex: 'name'
            }, {
                header: 'status',
                dataIndex: 'status',
                renderer: statusRenderer
            }],
            listeners: {
                itemdblclick: function(view, record, item, index, evt, eOpts) {
                    var Typ = record.get('Typ');
                    if (Typ === 'Ruleset') {
                        me.showRulesetEditor(view, record, item, index, evt, eOpts);
                    } else if (Typ === 'Rule') {
                        var cfg = {
                            name: record.data.name,
                            id: record.data.id,
                            qualityDimensions: record.data.qualityDimensions,
                            command: record.data.command,
                            summary: record.data.summary,
                            definition: record.data.definition,
                            formula: record.data.formula
                        };
                        me.showEditDialog(DQCPanel, cfg);
                    } else {
                        me.showEditor(view, record, item, index, evt, eOpts);
                    }
                },
                itemcontextmenu: function(view, record, item, index, evt, eOpts) {
                    view.select(index);
                    evt.stopEvent();
                    var isActive = record.data.status === "Yes";
                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            hidden: isActive,
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                }
            }
        });
        var record = null;
        var editorPagetoolbarButtons = [
            { iconCls: 'xty_pgtoolbar-save', itemId: 'btnSave', tooltip: 'Save', handler: function(button, evt) { me.onSave(record); } },
            { iconCls: 'xty_pgtoolbar-new', itemId: 'new', tooltip: 'New Gate', handler: function(button, evt) { me.showAddGate(DQCPanel, 'Gate'); } },
            { text: '|' },
            { iconCls: 'xty_epobRule', itemId: 'newRule', tooltip: 'New Rule', handler: function(button, evt) { me.showAddDialog(DQCPanel, 'Rule', 'RulesetEditor'); } },
            { iconCls: 'xty_pgtoolbar-delete', itemId: 'delete', tooltip: 'Delete', handler: function(button, evt) { me.deleteEpobDialog(DQCPanel); } }
        ];
        var applibar = extVia.ui.page.pagejob.getApplicationBar({ pgjobDscr: 'New Ruleset', pagetoolbarButtons: editorPagetoolbarButtons });

        var centerEditorPanel = {
            title: 'New Ruleset',
            applibarId: applibar.id,
            tbar: applibar,
            getApplicationBar: function() {
                return applibar;
            },
            setPagejobDscr: function setPagejobDscr(pgjobDscr) { applibar.setPagejobDscr(pgjobDscr); },
            setEpobDscr: function setEpobDscr(epobDscr) { applibar.setEpobDscr(epobDscr); },
            getPagejobDscr: function getPagejobDscr() { applibar.getPagejobDscr(); },
            getEpobDscr: function getEpobDscr() { return applibar.getEpobDscr(); },
            closable: true,
            active: true,
            itemId: editorMainTabItemId,
            border: false,
            activeTab: 'Metadata',
            items: [{
                xtype: 'tabpanel',
                itemId : 'editorSubTabsPanel',
                border: false,
                refresh: function() { extVia.notify({ action: 'refresh on', mssg: this.title }); },
                tabBar: {
                    cls: 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
                    tools: [{
                        xtype: 'button',
                        cls: 'xty_striptool-button xty_striptool-button-refresh',
                        handler: function(button) {
                            var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                            extVia.notify({ action: 'Refresh Subtab', mssg: '<b>' + activeTab + '</b>' });
                        },
                        iconCls: 'x-tool x-tool-refresh'
                    }]
                },
                items: [{
                    title: 'Metadata',
                    itemId: 'MasterDataTab',
                    hidden: false,
                    border: false,
                    items: [MetadataPanel]
                }, {
                    title: 'Rules',
                    itemId: 'transitionNotificationTab',
                    hidden: false,
                    border: false,
                    items: [DQCPanel]
                }]
            }]
        };
        var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
        tabPanCenter.addAndActivate(centerEditorPanel);
    },
    showAddGate: function(view, record, item, index, evt) {
        var me = extVia.regApp;
        var loc = extVia.locales;

        //General things
        var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
        };

        var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
        };
        var boxDefaults = { labelWidth: 180, width: 460, msgTarget: 'side', xtype: 'textfield', margin: '4 0 4 4' };
        var editorMainTabItemId = 'elementsEditorNewGate';

        //First tab things
        var MetadataPanel = {
            title: 'Metadaten',
            itemId: 'metadata',
            xtype: 'form',
            collapsible: true,
            width: 580,
            margin: '20 20 20 20',
            items: [{ itemId: 'Name', xtype: 'textfield', fieldLabel: 'Name', value: '', margin: '4 4 4 4', labelSeparator: ':<span class="xty_requiredStar"> *</span>' },
                    { itemId: 'started', xtype: 'displayfield', fieldLabel: 'Gestartet', value: 'Nein', margin: '4 4 4 4' },
                    { itemId: 'version', xtype: 'displayfield', fieldLabel: 'Version', value: '1', margin: '4 4 4 4' },
                    { xtype: 'tbspacer', height: 10 }
                   ]
        };

        extVia.stores.getDQCStore().filter({property: 'qualityIndex',value: '', exactMatch: true,caseSensitive: true});

        var DQCPanel;
        DQCPanel = Ext.create('Ext.grid.Panel', {
            store: extVia.stores.getDQCStore(),
            features: [Ext.create('Ext.grid.feature.Grouping', {
                groupHeaderTpl: '{name}',
                id: '{name}'
            })],
            selectedGroup: null,
            itemId: 'DQCPanel',
            forceFit: true,
            rowSelect: true,
            cls: 'xty_transition-grid xty_grid-group-paranthesis xty_selectable-group-grid',
            border: false,
            margin: '0 0 0 0',
            width: "100%",
            height: 500,
            columns: [Ext.create('Ext.grid.RowNumberer'), {
                header: 'Typ',
                dataIndex: 'Typ',
                renderer: epobTypeRenderer,
                width: 5
            }, {
                header: 'Name',
                dataIndex: 'name'
            }, {
                header: 'status',
                dataIndex: 'status',
                renderer: statusRenderer
            }],
            listeners: {
                itemdblclick: function(view, record, item, index, evt, eOpts) {
                    var Typ = record.get('Typ');
                    if (Typ === 'Ruleset') {
                        me.showRulesetEditor(view, record, item, index, evt, eOpts);
                    } else if (Typ === 'Rule') {
                        var cfg = {
                            name: record.data.name,
                            id: record.data.id,
                            qualityDimensions: record.data.qualityDimensions,
                            command: record.data.command,
                            summary: record.data.summary,
                            definition: record.data.definition,
                            formula: record.data.formula
                        };
                        me.showEditDialog(DQCPanel, cfg);
                    } else {
                        me.showEditor(view, record, item, index, evt, eOpts);
                    }
                },
                itemcontextmenu: function(view, record, item, index, evt, eOpts) {
                    view.select(index);
                    evt.stopEvent();
                    var isActive = record.data.status === "Yes";
                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            hidden: isActive,
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                },
                groupclick: function(view, node, group, evt, eOpts) {
                    var me = this;

                    var centerPan = extVia.regApp.myRaster.getCenter();
                    var groupHdRow = Ext.get(node);
                    var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                    var groupBodyId = groupBodytSibling.id;
                    var groupBody = Ext.get(groupBodyId);

                    if (evt.getX() - view.getEl().getLeft() < 15) {
                        groupBody.removeCls('xty_grid-group-body-no-collapse');
                        return;
                    }

                    groupBody.addCls('xty_grid-group-body-no-collapse');

                    if (!Ext.isEmpty(me.selectedGroup) && group !== me.selectedGroup.group) {
                        me.removeGroupSelection();
                    }
                    view.getSelectionModel().deselectAll(true);

                    var isSelected = groupHdRow.hasCls('xty_groupHdRow-selected');
                    if (isSelected) {
                        groupHdRow.removeCls('x-grid-group-hd-collapsed');
                        groupHdRow.removeCls('xty_groupHdRow-selected');
                        groupBody.removeCls('xty_grid-group-body-selected');

                        me.selectedGroup = null;
                    } else {

                        groupHdRow.addCls('xty_groupHdRow-selected');
                        groupBody.addCls('xty_grid-group-body-selected');

                        me.selectedGroup = { view: view, node: node, group: group, evt: evt, eOpts: eOpts };
                    }
                },
                groupcontextmenu: function(view, node, group, evt, eOpts) {

                    // var recordsInGroup = view.getStore().getGroups(group).children;
                    // view.select(index);
                    var me = this.app;

                    evt.preventDefault();

                    this.removeGroupSelection();
                    this.getSelectionModel().deselectAll(true);

                    var groupHdRow = Ext.get(node);
                    var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                    var groupBodyId = groupBodytSibling.id;
                    var groupBody = Ext.get(groupBodyId);
                    groupHdRow.addCls('xty_groupHdRow-selected');
                    groupBody.addCls('xty_grid-group-body-selected');
                    this.selectedGroup = { view: view, node: node, group: group, evt: evt, eOpts: eOpts };

                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: extVia.locales.modul + ' hinzufügen',
                            handler: me.onAddbWorkflow,
                            iconCls: 'x-btn-default-toolbar-small',
                            gridview: view,
                            transition: group,
                            app: me
                        }, {
                            text: 'Verantwortliche Person hinzufügen',
                            handler: me.onAddbWorkflowResponsiblePerson,
                            iconCls: 'xty_pgtoolbar-newWorkflowResponsiblePerson',
                            gridview: view,
                            transition: group,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                },
                selectionchange: function(view, selected, eOpts) {
                    var me = this;
                    me.removeGroupSelection();
                }
            },
            getSelection: function() {
                var me = this;

                var selection = this.getSelectionModel().getSelection()[0];

                if (Ext.isEmpty(selection)) {
                    selection = me.selectedGroup;
                    if (!Ext.isEmpty(selection)) {
                        selection.selectionTyp = 'Group';
                    }
                } else {
                    selection.selectionTyp = 'Row';
                }

                return selection;
            },
            removeGroupSelection: function() {
                var me = this;

                //Deselektiere die alte Selektion
                if (!Ext.isEmpty(me.selectedGroup)) {
                    var delgroupHdRow = Ext.get(me.selectedGroup.node);
                    var delgroupBodytSibling = Ext.get(delgroupHdRow).dom.nextSibling;
                    var delgroupBodyId = delgroupBodytSibling.id;
                    var delgroupBody = Ext.get(delgroupBodyId);

                    if (!Ext.isEmpty(delgroupBody)) {
                        delgroupHdRow.removeCls('x-grid-group-hd-collapsed');
                        delgroupHdRow.removeCls('xty_groupHdRow-selected');
                        delgroupBody.removeCls('xty_grid-group-body-selected');
                    }
                    me.selectedGroup = null;
                }
            }
        });

        var editorPagetoolbarButtons = [
            { iconCls: 'xty_pgtoolbar-save', itemId: 'btnSave', tooltip: 'Save', handler: function(button, evt) { me.onSave(record); } },
            { iconCls: 'xty_pgtoolbar-new', itemId: 'new', tooltip: 'New Object', handler: function(button, evt) { me.showAddGate(DQCPanel, 'Gate'); } },
            { text: '|' },
            { iconCls: 'xty_epobRuleset', itemId: 'newRuleset', tooltip: 'New Ruleset', handler: function(button, evt) { me.showAddRuleset(DQCPanel, 'GateEditor'); } },
            { iconCls: 'xty_epobRule', itemId: 'newRule', tooltip: 'New Rule', handler: function(button, evt) { me.showAddDialog(DQCPanel, 'Rule', 'GateEditor'); } },
            { iconCls: 'xty_pgtoolbar-delete', itemId: 'delete', tooltip: 'Delete', handler: function(button, evt) { me.deleteEpobDialog(DQCPanel); } }
        ];
        var applibar = extVia.ui.page.pagejob.getApplicationBar({ pgjobDscr: 'New Gate', pagetoolbarButtons: editorPagetoolbarButtons });

        var centerEditorPanel = {
            title: 'Add new gate',
            applibarId: applibar.id,
            tbar: applibar,
            getApplicationBar: function() {
                return applibar;
            },
            setPagejobDscr: function setPagejobDscr(pgjobDscr) { applibar.setPagejobDscr(pgjobDscr); },
            setEpobDscr: function setEpobDscr(epobDscr) { applibar.setEpobDscr(epobDscr); },
            getPagejobDscr: function getPagejobDscr() { applibar.getPagejobDscr(); },
            getEpobDscr: function getEpobDscr() { return applibar.getEpobDscr(); },
            closable: true,
            active: true,
            itemId: editorMainTabItemId,
            activeTab: 'Metadata',
            border: false,
            items: [{
                xtype: 'tabpanel',
                itemId : 'editorSubTabsPanel',
                border: false,
                refresh: function() { extVia.notify({ action: 'refresh on', mssg: this.title }); },
                tabBar: {
                    cls: 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
                    tools: [{
                        xtype: 'button',
                        cls: 'xty_striptool-button xty_striptool-button-refresh',
                        handler: function(button) {
                            var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                            extVia.notify({ action: 'Refresh Subtab', mssg: '<b>' + activeTab + '</b>' });
                        },
                        iconCls: 'x-tool x-tool-refresh'
                    }]
                },
                items: [{
                    title: 'Metadata',
                    itemId: 'MasterDataTab',
                    hidden: false,
                    border: false,
                    items: [MetadataPanel]
                }, {
                    title: 'Rulesets',
                    itemId: 'transitionNotificationTab',
                    hidden: false,
                    border: false,
                    items: [DQCPanel]
                }]
            }]
        };
        var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
        tabPanCenter.addAndActivate(centerEditorPanel);
    },

    
    showPublicationEditor: function(view, record, item, index, evt) {
      var me = extVia.regApp;
      var loc = extVia.locales;
      
      var pgjobDscr = 'Publication';
      var pgjobEpobDscr = record.get('name');
      
      
      var editorPagetoolbarButtons = [
        { iconCls: 'xty_pgtoolbar-save', itemId: 'btnSave', tooltip: 'Save' },
        { iconCls: 'xty_pgtoolbar-new', itemId: 'new', tooltip: 'New Object' }
      ];
      var applibar = extVia.ui.page.pagejob.getApplicationBar({ pgjobDscr: pgjobDscr, epobDscr: pgjobEpobDscr, pagetoolbarButtons: editorPagetoolbarButtons });

      
      var editorMainTabItemId = 'publicationEditor' + record.get('id');

      var structureplanningStore = Ext.create('Ext.data.Store', {
        storeId:'structureplanningStore',
        fields:['id', 'epobType', 'name', 'sorting', 'format'],
        data:{'items':[
            {id:'1', epobType:'Audio', name:'Flow 1', sorting:'10', format:'Ernie'  },
            {id:'2', epobType:'Video', name:'The UX of a banana', sorting:'10', format:'Oskar'  },
            {id:'3', epobType:'Image', name:'Welt retten', sorting:'10', format:'Grobi'  },
            {id:'4', epobType:'Graphic', name:'Kuchen backen', sorting:'10', format:'123'  },
            {id:'5', epobType:'Document', name:'Datenbank zerstören', sorting:'10', format:'abc'  },
            {id:'6', epobType:'EdTable', name:'Produkte pflegen', sorting:'10', format:'uandme'  },
            {id:'7', epobType:'ProductAttribute', name:'Cola trinken', sorting:'10', format:'xyz'  }
        ]},
        proxy: {
            type: 'memory',
            reader: {
                type: 'json',
                root: 'items'
            }
        }
      });

      var actionRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
        var html =  
          '<span  class="xty_actions-bin"><span title="view" style="height:18px;vertical-align:bottom;" class="xty_action-view">&nbsp;V&nbsp;</span>' +
          '<span title="edit" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_action-edit">&nbsp;E&nbsp;</span>' +
          '<span title="delete" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_action-delete">&nbsp;&#10005;&nbsp;</span></span>'
        ;
        
        
        return html;
        
    };
    
      var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
        return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
    };

    var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
        return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
    };
    
    
    var checkboxRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
      return '<input type="checkbox"/>';
  };  
      
  
  var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
    clicksToEdit: 1
  });
  
  

  
 var triggerHtml = 
   '<div class="x-form-trigger-wrap"  style="width: 17px;">'+
   '<div class="x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-last x-unselectable"  style="-moz-user-select: none;"></div>'+
   '<div class="x-clear" role="presentation"></div></div>';
  
  
  
  var fieldTpl = new Ext.XTemplate(
      '<div class="x-field x-form-item x-field-default" style="margin: 0px 10px 0px 14px; padding-bottom: 4px; width: {fieldWidth}px;">',
      '<label class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:{fieldLabelWidth}px;">&nbsp;{dscr} <tpl if="required"><span class="xty_requiredStar"> *</span></tpl></label>',
      '<div class="x-form-item-body "  style="width: {fieldItemBodyWidth}px;">',
      '<input  type="text" name="shortcut" size="20" class="x-form-field x-form-text" style="-moz-user-select: text; width: {fieldInputWidth}px;">',
      '<tpl if="combo">'+triggerHtml+'</tpl>',
      '</div>',
      '<div class="x-form-error-msg x-form-invalid-icon" style="display:none" data-errorqtip=""></div><div class="x-clear" role="presentation"><!-- --></div></div>'
  );
  var fieldLabelWidth =110;
  var fieldInputWidth =200;
  var fieldItemBodyWidth = fieldInputWidth;
  var fieldWidth = fieldLabelWidth + fieldItemBodyWidth +50;
  
  
  
  var categories = fieldTpl.apply({dscr:'Kategorien', combo:true, fieldLabelWidth: fieldLabelWidth, fieldItemBodyWidth: fieldItemBodyWidth , fieldInputWidth: fieldInputWidth - 17, fieldWidth: fieldWidth });
  
  
  var fieldHtml1 = fieldTpl.apply({dscr:'Elementauswahl', required:true, fieldLabelWidth: fieldLabelWidth, fieldItemBodyWidth: fieldItemBodyWidth, fieldInputWidth: fieldInputWidth, fieldWidth: fieldWidth });
  var fieldHtml2 = fieldTpl.apply({dscr:'Schlagwort', fieldLabelWidth: fieldLabelWidth, fieldItemBodyWidth: fieldItemBodyWidth, fieldInputWidth: fieldInputWidth, fieldWidth: fieldWidth });
  var fieldHtml3 =fieldTpl.apply({ dscr:'Sprache', fieldLabelWidth: fieldLabelWidth,  fieldItemBodyWidth: fieldItemBodyWidth, fieldInputWidth: fieldInputWidth, fieldWidth: fieldWidth });
  

  
      var structureplanningGrid = Ext.create('Ext.grid.Panel', {
        itemId:'structureplanningGrid',
         margin:'10 10 10 10',
         //border:false,
         
         
         plugins: [
           cellEditing,
           {
           ptype: 'rowexpander',
           rowBodyTpl : [
               '<div class="xty_structureplanning-expanded-row-body" style="padding-left:20px;">',
               categories,
               fieldHtml1,
               fieldHtml2,
               fieldHtml3,
               '</div>'
           ]
          }
           ],
         
         store: Ext.data.StoreManager.lookup('structureplanningStore'),
        // selModel: Ext.create('Ext.selection.CheckboxModel',{ injectCheckbox : 2}), 
        
         columns: [
              
              { header: 'Typ',  dataIndex: 'epobType', width:32, editor : {xtype : 'combo'}, renderer: epobTypeRenderer},
              { header: 'Ausgabe',  dataIndex: 'output' ,   width:52,   renderer: checkboxRenderer},
              { header: 'Sortierung',  dataIndex: 'sorting' ,  width:58, editor : {xtype : 'textfield'}
                
              },
              { header: 'Name',  dataIndex: 'name' , editor : {xtype : 'textfield'},   width:400},
              { header: 'Objecttype',  dataIndex: 'epobType' , editor : {xtype : 'combo'}},
              { header: 'Format',  dataIndex: 'format' , editor : {xtype : 'combo'}},
              
              
              { header: 'Actions',  dataIndex: 'action' , renderer: actionRenderer},

            //  { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
            { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
      ],

          listeners:{
           itemdblclick: function( view, record, item, index, evt, eOpts ){
            extVia.notify('edit '+record.get('name') );
           }
          
          }
     
     });

      
      
      
      
      var centerEditorPanel = {
               title: pgjobEpobDscr,
               applibarId: applibar.id,
               tbar: applibar,
               getApplicationBar: function() {
                   return applibar;
               },
               setPagejobDscr: function setPagejobDscr(pgjobDscr) { applibar.setPagejobDscr(pgjobDscr); },
               setEpobDscr: function setEpobDscr(epobDscr) { applibar.setEpobDscr(epobDscr); },
               getPagejobDscr: function getPagejobDscr() { applibar.getPagejobDscr(); },
               getEpobDscr: function getEpobDscr() { return applibar.getEpobDscr(); },
               closable: true,
               active: true,
               itemId: editorMainTabItemId,
              
               border: false,
               items: [{
                 xtype: 'tabpanel',
                 itemId : 'editorSubTabsPanel',
                 border: false,
                 activeTab: 'structureplanning',
                 refresh: function() { extVia.notify({ action: 'refresh on', mssg: this.title }); },
                 tabBar: {
                     cls: 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
                     tools: [{
                         xtype: 'button',
                         cls: 'xty_striptool-button xty_striptool-button-refresh',
                         handler: function(button) {
                             var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                             extVia.notify({ action: 'Refresh Subtab', mssg: '<b>' + activeTab + '</b>' });
                         },
                         iconCls: 'x-tool x-tool-refresh'
                     }]
                 },
                 items: [
                   { title: 'Publication', itemId: 'publication', border: false},
                   { title: 'Planung',itemId: 'planning', border: false},
                   { title: 'Struktur',itemId: 'structureplanning', border: false, items:[structureplanningGrid]},
                   { title: 'Vorschau',itemId: 'preview', border: false},
                   { title: 'Export',itemId: 'export', border: false},
                   { title: 'Exportarchiv',itemId: 'exportarchive', border: false}
                 ]
             }]
      };
      
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
      tabPanCenter.addAndActivate(centerEditorPanel);
    },  
    
    
    

    
    showDQIEditor: function(view, record, item, index, evt) {

        var me = extVia.regApp;
        var loc = extVia.locales;

        //General things
        var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
        };

        var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
        };
        var boxDefaults = { labelWidth: 180, width: 460, msgTarget: 'side', xtype: 'textfield', margin: '4 0 4 4' };
        var editorMainTabItemId = 'elementsEditorGate' + record.get('id');

        //Breadcrumb things
        var epobType = record.raw.epobType;
        var recordName = recordName ? record.raw.text : record.raw.name;
        var pgjobDscr = loc.editType.replace(/\{type\}/, epobType);
        var pgjobEpobDscr = record.raw.name;

        //First tab things
        var MetadataPanel = {
            title: 'Metadaten',
            itemId: 'metadata',
            xtype: 'form',
            collapsible: true,
            width: 580,
            margin: '20 20 20 20',
            items: [{ itemId: 'Name', xtype: 'textfield', fieldLabel: 'Name', value: recordName, margin: '4 4 4 4', labelSeparator: ':<span class="xty_requiredStar"> *</span>' },
                    { itemId: 'started', xtype: 'displayfield', fieldLabel: 'Gestartet', value: 'Nein', margin: '4 4 4 4' },
                    { itemId: 'version', xtype: 'displayfield', fieldLabel: 'Version', value: '1', margin: '4 4 4 4' },
                    { xtype: 'tbspacer', height: 10 }
                   ]
        };

        extVia.stores.getDQCStore().filter({property: 'qualityIndex',value: recordName, exactMatch: true, caseSensitive: true});

        
        var DQCPanel;
        DQCPanel = Ext.create('Ext.grid.Panel', {
            store: extVia.stores.getDQCStore(),
            features: [Ext.create('Ext.grid.feature.Grouping', {
                groupHeaderTpl: '{name}',
                id: '{name}'
            })],
            selectedGroup: null,
            itemId: 'DQCPanel',
            forceFit: true,
            rowSelect: true,
            cls: 'xty_transition-grid xty_grid-group-paranthesis xty_selectable-group-grid',
            border: false,
            margin: '0 0 0 0',
            width: "100%",
            height: 500,
            columns: [Ext.create('Ext.grid.RowNumberer'), {
                header: 'Typ',
                dataIndex: 'Typ',
                renderer: epobTypeRenderer,
                width: 5
            }, {
                header: 'Name',
                dataIndex: 'name'
            }, {
                header: 'status',
                dataIndex: 'status',
                renderer: statusRenderer
            }],
            listeners: {
                itemdblclick: function(view, record, item, index, evt, eOpts) {
                    var Typ = record.data.Typ;
                    if (Typ === 'Ruleset') {
                        me.showRulesetEditor(view, record, item, index, evt, eOpts);
                    } else if (Typ === 'Rule') {
                        var cfg = {
                            name: record.data.name,
                            id: record.data.id,
                            qualityDimensions: record.data.qualityDimensions,
                            command: record.data.command,
                            summary: record.data.summary,
                            definition: record.data.definition,
                            formula: record.data.formula
                        };
                        me.showEditDialog(DQCPanel, cfg);
                    } else {
                        me.showEditor(view, record, item, index, evt, eOpts);
                    }
                },
                itemcontextmenu: function(view, record, item, index, evt, eOpts) {
                    view.select(index);
                    evt.stopEvent();
                    var isActive = record.data.status === "Yes";
                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            hidden: isActive,
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                },
                groupclick: function(view, node, group, evt, eOpts) {
                    var me = this;

                    var centerPan = extVia.regApp.myRaster.getCenter();
                    var groupHdRow = Ext.get(node);
                    var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                    var groupBodyId = groupBodytSibling.id;
                    var groupBody = Ext.get(groupBodyId);

                    if (evt.getX() - view.getEl().getLeft() < 15) {
                        groupBody.removeCls('xty_grid-group-body-no-collapse');
                        return;
                    }

                    groupBody.addCls('xty_grid-group-body-no-collapse');

                    if (!Ext.isEmpty(me.selectedGroup) && group !== me.selectedGroup.group) {
                        me.removeGroupSelection();
                    }
                    view.getSelectionModel().deselectAll(true);

                    var isSelected = groupHdRow.hasCls('xty_groupHdRow-selected');
                    if (isSelected) {
                        groupHdRow.removeCls('x-grid-group-hd-collapsed');
                        groupHdRow.removeCls('xty_groupHdRow-selected');
                        groupBody.removeCls('xty_grid-group-body-selected');

                        me.selectedGroup = null;
                    } else {

                        groupHdRow.addCls('xty_groupHdRow-selected');
                        groupBody.addCls('xty_grid-group-body-selected');

                        me.selectedGroup = { view: view, node: node, group: group, evt: evt, eOpts: eOpts };
                    }
                },
                groupcontextmenu: function(view, node, group, evt, eOpts) {

                    // var recordsInGroup = view.getStore().getGroups(group).children;
                    // view.select(index);
                    var me = this.app;

                    evt.preventDefault();

                    this.removeGroupSelection();
                    this.getSelectionModel().deselectAll(true);

                    var groupHdRow = Ext.get(node);
                    var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                    var groupBodyId = groupBodytSibling.id;
                    var groupBody = Ext.get(groupBodyId);
                    groupHdRow.addCls('xty_groupHdRow-selected');
                    groupBody.addCls('xty_grid-group-body-selected');
                    this.selectedGroup = { view: view, node: node, group: group, evt: evt, eOpts: eOpts };

                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: extVia.locales.modul + ' hinzufügen',
                            handler: me.onAddbWorkflow,
                            iconCls: 'x-btn-default-toolbar-small',
                            gridview: view,
                            transition: group,
                            app: me
                        }, {
                            text: 'Verantwortliche Person hinzufügen',
                            handler: me.onAddbWorkflowResponsiblePerson,
                            iconCls: 'xty_pgtoolbar-newWorkflowResponsiblePerson',
                            gridview: view,
                            transition: group,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                },
                selectionchange: function(view, selected, eOpts) {
                    var me = this;
                    me.removeGroupSelection();
                }
            },
            getSelection: function() {
                var me = this;

                var selection = this.getSelectionModel().getSelection()[0];

                if (Ext.isEmpty(selection)) {
                    selection = me.selectedGroup;
                    if (!Ext.isEmpty(selection)) {
                        selection.selectionTyp = 'Group';
                    }
                } else {
                    selection.selectionTyp = 'Row';
                }

                return selection;
            },
            removeGroupSelection: function() {
                var me = this;

                //Deselektiere die alte Selektion
                if (!Ext.isEmpty(me.selectedGroup)) {
                    var delgroupHdRow = Ext.get(me.selectedGroup.node);
                    var delgroupBodytSibling = Ext.get(delgroupHdRow).dom.nextSibling;
                    var delgroupBodyId = delgroupBodytSibling.id;
                    var delgroupBody = Ext.get(delgroupBodyId);

                    if (!Ext.isEmpty(delgroupBody)) {
                        delgroupHdRow.removeCls('x-grid-group-hd-collapsed');
                        delgroupHdRow.removeCls('xty_groupHdRow-selected');
                        delgroupBody.removeCls('xty_grid-group-body-selected');
                    }
                    me.selectedGroup = null;
                }
            }
        });
        var editorPagetoolbarButtons = [
            { iconCls: 'xty_pgtoolbar-save', itemId: 'btnSave', tooltip: 'Save', handler: function(button, evt) { me.onSave(record); } },
            { iconCls: 'xty_pgtoolbar-new', itemId: 'new', tooltip: 'New Object', handler: function(button, evt) { me.showAddGate(DQCPanel, 'Gate'); } },
            { text: '|' },
            { iconCls: 'xty_epobRuleset', itemId: 'newRuleset', tooltip: 'New Ruleset', handler: function(button, evt) { me.showAddRuleset(DQCPanel, 'GateEditor'); } },
            { iconCls: 'xty_epobRule', itemId: 'newRule', tooltip: 'New Rule', handler: function(button, evt) { me.showAddDialog(DQCPanel, 'Rule', 'GateEditor'); } },
            { iconCls: 'xty_pgtoolbar-delete', itemId: 'delete', tooltip: 'Delete', handler: function(button, evt) { me.deleteEpobDialog(DQCPanel); } }
        ];
        var applibar = extVia.ui.page.pagejob.getApplicationBar({ pgjobDscr: pgjobDscr, epobDscr: pgjobEpobDscr, pagetoolbarButtons: editorPagetoolbarButtons });

        var centerEditorPanel = {
            title: pgjobEpobDscr,
            applibarId: applibar.id,
            tbar: applibar,
            getApplicationBar: function() {
                return applibar;
            },
            setPagejobDscr: function setPagejobDscr(pgjobDscr) { applibar.setPagejobDscr(pgjobDscr); },
            setEpobDscr: function setEpobDscr(epobDscr) { applibar.setEpobDscr(epobDscr); },
            getPagejobDscr: function getPagejobDscr() { applibar.getPagejobDscr(); },
            getEpobDscr: function getEpobDscr() { return applibar.getEpobDscr(); },
            closable: true,
            active: true,
            itemId: editorMainTabItemId,
            activeTab: 'Metadata',
            border: false,
            items: [{
                xtype: 'tabpanel',
                itemId : 'editorSubTabsPanel',
                border: false,
                refresh: function() { extVia.notify({ action: 'refresh on', mssg: this.title }); },
                tabBar: {
                    cls: 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
                    tools: [{
                        xtype: 'button',
                        cls: 'xty_striptool-button xty_striptool-button-refresh',
                        handler: function(button) {
                            var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                            extVia.notify({ action: 'Refresh Subtab', mssg: '<b>' + activeTab + '</b>' });
                        },
                        iconCls: 'x-tool x-tool-refresh'
                    }]
                },
                items: [{
                    title: 'Metadata',
                    itemId: 'MasterDataTab',
                    hidden: false,
                    border: false,
                    items: [MetadataPanel]
                }, {
                    title: 'Rulesets',
                    itemId: 'transitionNotificationTab',
                    hidden: false,
                    border: false,
                    items: [DQCPanel]
                }]
            }]
        };
        var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
        tabPanCenter.addAndActivate(centerEditorPanel);
    },

    initWest: function() {
        var me = this;

        var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
        };

        var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
        };

        var DQIStore = Ext.create('Ext.data.Store', {
            storeId: 'DQIStore',
            groupField: 'qualityIndex',
            fields: ['id', 'epobType', 'qualityIndex', 'name', 'status', 'responsible'],
            data: {
                'items': [
                    { id: Ext.id(), epobType: 'Ruleset', qualityIndex: 'Web', name: 'Handheld PowerTools', status: 'Warning' },
                    { id: Ext.id(), epobType: 'Ruleset', qualityIndex: 'Web', name: 'Semi Stationary Tools', status: 'Error' },
                    { id: Ext.id(), epobType: 'Ruleset', qualityIndex: 'Web', name: 'Other tools', status: 'Started' },
                    { id: Ext.id(), epobType: 'Ruleset', qualityIndex: 'Print', name: 'Handheld PowerTools', status: 'Danger' }
                ]
            },
            proxy: {
                type: 'memory',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            }
        });

        var DQIGrid;
        DQIGrid = Ext.create('Ext.grid.Panel', {
            itemId: 'DQIGrid',
            width: '100%',
            border: false,
            store: Ext.data.StoreManager.lookup('DQIStore'),
            features: [Ext.create('Ext.grid.feature.Grouping', {
                groupHeaderTpl: '{name}'
            })],
            columns: [
                { header: 'Typ', dataIndex: 'epobType', width: 32, renderer: epobTypeRenderer },
                { header: 'Name', dataIndex: 'name', flex: 1 },
                { header: 'status', dataIndex: 'status', width: 40, renderer: statusRenderer }
            ],
            height: 500,
            listeners: {
                itemdblclick: function(view, record, item, index, evt, eOpts) {
                    var epobType = record.get('epobType');
                    if (epobType === 'Ruleset') {
                        me.showRulesetEditor(view, record, item, index, evt, eOpts);
                    } else if (epobType === 'Rule') {
                        var cfg = {
                            name: record.raw.name,
                            id: record.raw.id,
                            qualityDimensions: record.raw.qualityDimensions,
                            command: record.raw.command,
                            summary: record.raw.summary,
                            definition: record.raw.definition,
                            formula: record.raw.formula
                        };
                        me.showEditDialog(DQIGrid, cfg);
                    } else {
                        me.showDQIEditor(view, record, item, index, evt, eOpts);
                    }
                },
                groupclick: function(view, node, group, evt, eOpts) {
                    var me = this;
                    var centerPan = extVia.regApp.myRaster.getCenter();
                    var groupHdRow = Ext.get(node);
                    var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                    var groupBodyId = groupBodytSibling.id;
                    var groupBody = Ext.get(groupBodyId);
                    groupBody.addCls('xty_grid-group-body-no-collapse');
                    groupHdRow.removeCls('x-grid-group-hd-collapsed');
                },
                groupdblclick: function(view, node, item, record, index, group, evt, eOpts) {
                    var GroupStore = Ext.create('Ext.data.Store', {
                        storeId: 'GroupStore',
                        groupField: 'qualityIndex',
                        fields: ['id', 'epobType', 'qualityIndex', 'name', 'status', 'responsible'],
                        data: {
                            'items': [
                                { id: '1', epobType: 'QualityIndex', qualityIndex: 'Print', name: 'Print', status: 'Warning' },
                                { id: '2', epobType: 'QualityIndex', qualityIndex: 'Web', name: 'Web', status: 'Error' },
                                { id: '3', epobType: 'QualityIndex', qualityIndex: 'Shop', name: 'Shop', status: 'Error' }
                            ]
                        },
                        proxy: {
                            type: 'memory',
                            reader: {
                                type: 'json',
                                root: 'items'
                            }
                        }
                    });
                    var selectionName = item;
                    if (selectionName === 'Web') {
                        record = DQIStore.data.items[2];
                    } else if (selectionName === 'Print') {
                        record = DQIStore.data.items[0];
                    } else {
                        record = DQIStore.data.items[1];
                    }
                    me.showEditor(view, record, item, index, evt, eOpts);
                },
                itemcontextmenu: function(view, record, item, index, evt, eOpts) {
                    view.select(index);
                    evt.stopEvent();
                    var isActive = record.data.status === "Yes";
                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            hidden: isActive,
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                },
                groupcontextmenu: function(view, node, group, evt, eOpts) {
                    evt.preventDefault();

                    this.removeGroupSelection();
                    this.getSelectionModel().deselectAll(true);

                    var groupHdRow = Ext.get(node);
                    var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                    var groupBodyId = groupBodytSibling.id;
                    var groupBody = Ext.get(groupBodyId);
                    groupHdRow.addCls('xty_groupHdRow-selected');
                    groupBody.addCls('xty_grid-group-body-selected');
                    this.selectedGroup = { view: view, node: node, group: group, evt: evt, eOpts: eOpts };

                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                }
            },
            getSelection: function() {
                var me = this;

                var selection = this.getSelectionModel().getSelection()[0];

                if (Ext.isEmpty(selection)) {
                    selection = me.selectedGroup;
                    if (!Ext.isEmpty(selection)) {
                        selection.selectionTyp = 'Group';
                    }
                } else {
                    selection.selectionTyp = 'Row';
                }

                return selection;
            },
            removeGroupSelection: function() {
                var me = this;

                //Deselektiere die alte Selektion
                if (!Ext.isEmpty(me.selectedGroup)) {
                    var delgroupHdRow = Ext.get(me.selectedGroup.node);
                    var delgroupBodytSibling = Ext.get(delgroupHdRow).dom.nextSibling;
                    var delgroupBodyId = delgroupBodytSibling.id;
                    var delgroupBody = Ext.get(delgroupBodyId);

                    if (!Ext.isEmpty(delgroupBody)) {
                        delgroupHdRow.removeCls('x-grid-group-hd-collapsed');
                        delgroupHdRow.removeCls('xty_groupHdRow-selected');
                        delgroupBody.removeCls('xty_grid-group-body-selected');
                    }
                    me.selectedGroup = null;
                }
            }
        });
        
        var DQIGridTab = {
            title: 'Data Quality Indices',
            itemId: 'westPanel',
            height: me.getWestListHeight(),
            tbar: [
                '->',
                { iconCls: 'xty_pgtoolbar-new', itemId: 'new', handler: function(button, evt) { me.showAddGate(); } },
                { iconCls: 'xty_epobRuleset', itemId: 'newRuleset', handler: function(button, evt) { me.showAddRuleset(DQIGrid, 'GateEditor'); } },
                //{ text: '|' },
                //{ iconCls: 'xty_epobRule', itemId: 'newRule', handler: function(button, evt) { me.showAddDialog(DQIGrid, 'Rule'); } },
                { iconCls: 'xty_pgtoolbar-delete', itemId: 'delete', handler: function(button, evt) { me.deleteEpobDialog(DQIGrid); } }
            ],
            items: [DQIGrid],
            bbxxar: ['->', { iconCls: ' xty_pgtoolbar-pagingFirst' }, { iconCls: ' xty_pgtoolbar-pagingPrev' }, { iconCls: ' xty_pgtoolbar-pagingNext' }, { iconCls: ' xty_pgtoolbar-pagingLast' }]
        };


        
        




        var westPan = extVia.regApp.myRaster.getWest();
        var westHeight = westPan.getHeight() - 28;

        var DQGTree;
        DQGTree = Ext.create('Ext.tree.Panel', {
            store: extVia.stores.getDQGStore(),
            id: 'DQGTree',
            width: 400,
            border: false,
            height: westHeight,
            useArrows: true,
            rootVisible: false,
            listeners: {
                itemdblclick: function(view, record, item, index, evt, eOpts) {
                    var epobType = record.raw.epobType;
                    if (epobType === 'Ruleset') {
                        me.showRulesetEditor(view, record, item, index, evt, eOpts);
                    } else if (epobType === 'Rule') {
                        var cfg = {
                            name: record.raw.name,
                            id: record.raw.id,
                            qualityDimensions: record.raw.qualityDimensions,
                            command: record.raw.command,
                            summary: record.raw.summary,
                            definition: record.raw.definition,
                            formula: record.raw.formula
                        };
                        me.showEditDialog(DQGTree, cfg);
                    } else {
                        me.showDQIEditor(view, record, item, index, evt, eOpts);
                    }
                },
                itemcontextmenu: function(view, record, item, index, evt, eOpts) {
                    view.select(index);
                    evt.stopEvent();
                    var isActive = record.data.status === "Yes";
                    Ext.create('Ext.menu.Menu', {
                        items: [{
                            text: 'Edit',
                            handler: me.onEditbWorkflow,
                            iconCls: 'xty_menu-versioning-work',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Copy',
                            handler: me.onCopyWorkflow,
                            iconCls: 'xty_pgtoolbar-copy-small',
                            gridview: view,
                            app: me
                        }, {
                            text: 'Delete',
                            handler: me.onDeleteWorkflow,
                            iconCls: 'xty_pgtoolbar-delete-small',
                            hidden: isActive,
                            gridview: view,
                            app: me
                        }]
                    }).showAt(evt.getXY());
                }
            }
        });

        var dqiTreeTab = {
            title: 'DQIs',
            itemId: 'DQG',
            tbar: [
                '->',
                { iconCls: 'xty_pgtoolbar-new', itemId: 'new', handler: function(button, evt) { me.showAddGate(); } },
                { iconCls: 'xty_epobRuleset', itemId: 'newRuleset', handler: function(button, evt) { me.showAddRuleset(DQGTree, 'GateEditor'); } },
                { text: '|' },
                { iconCls: 'xty_epobRule', itemId: 'newRule', handler: function(button, evt) { me.showAddDialog(DQGTree, 'Rule'); } },
                { iconCls: 'xty_pgtoolbar-delete', itemId: 'delete', handler: function(button, evt) { me.deleteEpobDialog(DQGTree); } }
            ],
            items: [DQGTree]
        };

        //var westTabPan = extVia.regApp.myRaster.getWestTabPanel();
        //westTabPan.add(dqiTreeTab);
        
        
        
        
        Ext.create('Ext.data.Store', {
          storeId:'publicationsStore',
          fields:['id', 'epobType', 'name', 'status', 'responsible'],
          data:{'items':[
              {id:'1', epobType:'Publication', name:'Flow 1', status:'Warning', responsible:'Ernie'  },
              {id:'2', epobType:'Publication', name:'The UX of a banana', status:'Success', responsible:'Oskar'  },
              {id:'3', epobType:'Publication', name:'Welt retten', status:'Started', responsible:'Grobi'  },
              {id:'4', epobType:'Publication', name:'Kuchen backen', status:'Danger', responsible:''  },
              {id:'5', epobType:'Publication', name:'Datenbank zerstören', status:'Success', responsible:''  },
              {id:'6', epobType:'Publication', name:'Produkte pflegen', status:'Waiting', responsible:''  },
              {id:'7', epobType:'Publication', name:'Cola trinken', status:'Expired', responsible:''  }
          ]},
          proxy: {
              type: 'memory',
              reader: {
                  type: 'json',
                  root: 'items'
              }
          }
        });
        
        var publicationsGrid = Ext.create('Ext.grid.Panel', {
          itemId:'publicationsGrid',
           width: 400,
           border:false,
           store: Ext.data.StoreManager.lookup('publicationsStore'),
           columns: [
                { header: 'Typ',  dataIndex: 'epobType', width:32, renderer:epobTypeRenderer },
                { header: 'Name',  dataIndex: 'name' ,  flex: 1},
                { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
              { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
        ],
        height: 200,
            listeners:{
             itemdblclick: function( view, record, item, index, evt, eOpts ){
              me.showPublicationEditor(view, record, item, index, evt, eOpts);
             }
            
            }
       
       });
        var publicationsList = {
            title:'Publications',
            itemId:'publicationsList',
            height: me.getWestListHeight(),
            tbar:[
            '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'Löschen', handler: me.deleteEpobDialog}
            ],
            items:[ publicationsGrid ] ,
            bbxxar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
         };
       // westTabPan.add(publicationsList);
        
        
        
        
        
        var westTabPanel = extVia.regApp.myRaster.initWestTabPanel({
          tabBar: {
              tools: [{
                  xtype: 'button',
                  cls: 'xty_striptool-button xty_striptool-button-refresh',
                  iconCls: 'x-tool x-tool-refresh',
                  masrgin: '0 0 0 50',
                  handler: function(button) {
                      var activeTab = button.ownerCt.ownerCt.getActiveTab();
                      extVia.notify({ action: 'Refresh West ', mssg: '<b>' + activeTab.title + '</b>' });
                  }
              }]
          },
          items: [
            
            extVia.hierarchy.statics.getHierarchyTabCfg({}),
            extVia.hierarchy.statics.getStructureTreePanelCfg({}),
            
            publicationsList, dqiTreeTab ]
      });

        
      extVia.regApp.myRaster.addToWest(westTabPanel);
        
     // extVia.editor.baseEditor.statics.epobEditor = 'dqiDraft'; 
      extVia.editor.baseEditor.statics.activeTab ='dqi';
        
    },

    launch: function() {
        Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
            expires: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 7)) //7 days from now
        }));
        extVia.regApp = this;
        extVia.stores.initRuleSetStore();
        extVia.stores.initQualityDimensionsStore();
        extVia.stores.initQualityGatesStore();
        extVia.stores.initDQGStore();
        extVia.stores.initDQCStore();
        var me = this;
        var modulDscr = 'dqi';
        var viewCfg; // = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
        extVia.constants.raster.mainWestWidth = 360;
        extVia.ui.page.raster = new extVia.ui.page.BaseRaster({ viewCfgFromUrl: true, modulDscr: modulDscr });
        extVia.ui.page.raster.onReady(this);
        me.initWest();

        // Need some center Tabs?
        var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
            tabBar: {
                tools: [{
                    xtype: 'button',
                    cls: 'xty_striptool-button xty_striptool-button-refresh',
                    handler: function(button) {
                        var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                        extVia.notify({ action: 'Refresh Center', mssg: '<b>' + activeTab.title + '</b>' });
                    },
                    iconCls: 'x-tool x-tool-refresh'
                }]
            }
        });
        me.tabPanCenter = tabPanCenter;
        extVia.regApp.myRaster.addToCenter(tabPanCenter);

        // if you ned an extra App Panel:  dqi-Module
        var dqiModalMask;
        var dqiModuleAppbar = extVia.ui.page.pagejob.getApplicationBar({
            pgjobDscr: 'Data Quality Index',
            epobDscr: 'Module',
            pgjobButtons: [{
                itemId: 'upload',
                tooltip: 'Epim Objekte erstellen',
                margin: '0 4 0 0',
                enableToggle: true,
                xtype: 'splitbutton',
                menu: {
                    items: [
                        { text: 'DQI' },
                        {
                            text: 'DQI Preview',
                            handler: function() {
                                me.showRequiredPreviewDialog({ filename: 'Test' });
                            }
                        }
                    ]
                }
            }]
        });

        var dqiModulePanel = {
            title: 'dqi',
            tbar: dqiModuleAppbar,
            closable: true,
            defaults: {
                margin: '24 24 24 24',
                collapsible: true,
                width: 580
            },
            items: []
        };
        tabPanCenter.addAndActivate(dqiModulePanel);
        
        
        var task = new Ext.util.DelayedTask(function(){
          var openOnStartNodesArr =  Ext.query('.xty_hierarchy-tree-panel .xty_open-on-start-node');
          if (openOnStartNodesArr){
            var openOnStartNode = openOnStartNodesArr[0];
            var openOnStartNodeEl = Ext.get(openOnStartNode); 
            var openOnStartNodeDomEl = document.getElementById(openOnStartNodeEl.id);
            var openOnStartNodeClicker = document.getElementById(openOnStartNodeEl.id).parentNode;
            openOnStartNodeClicker.openEditor = true;
            openOnStartNodeClicker.click();
          }
        });
        task.delay(100); 
        
        
    }
});

/*
 * 
 * $Revision: 1.1.2.22 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2019/07/03 16:50:49 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */