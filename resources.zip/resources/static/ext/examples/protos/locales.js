Ext.namespace('extVia.locales', 'locales', 'loc');
/**
 * @class extVia.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2019/07/03 16:29:07 $
 *            $Revision: 1.9.6.14 $
 */



var uiLangIso = 'DE';

if (location.href.indexOf('uiLangIso=')>-1){
  var urlArr =  document.URL.split("?");
  if (urlArr.length>1){   
      var paramsObj  = Ext.Object.fromQueryString(urlArr[1]);
      uiLangIso = paramsObj['uiLangIso'];
  }
}
var uiLangIsoIx =  uiLangIso.toUpperCase()==='DE'? 0 : 1;

if (uiLangIsoIx  && uiLangIso.toUpperCase()==='DEU'){
  uiLangIsoIx = 0
}


var uiLang =  uiLangIso.toUpperCase()==='DE' ? 'Deutsch' : 'English';

extVia.locales.uiLangIso = uiLangIso;


if (uiLangIso.toUpperCase()==='RO' ){
  
  // LATIN SMALL LETTER A WITH BREVE: &#259
  
  // LATIN SMALL LETTER T WITH COMMA BELOW: &#539;
  //LATIN SMALL LETTER T WITH CEDILLA:  &#355;
  
 uiLangIsoIx =  2;
 uiLang = 'românesc';
}


extVia.locale_DE_EN =   { 

  
     // navigationbar
     user: ['Benutzer','User', 'User'],
                         
     search : ['Suche','Search', 'C&#259utare' ],
     searchterm : ['Suchbegriff','Search text', 'Cuvinte cheie' ],
     searcharea : ['Suchbereich','Search area', 'Zona de c&#259utare' ],
     hierarchies : ['Hierarchien','Hierarchies', 'Ierarhii' ],
     categories : ['Kategorien','Categories', 'Categorii' ],
     notifications: ['Benachrichtigungen','Notifications'],
     // Actions
     save : ['Speichern','Save', 'save' ],
     createVersion : ['Version erstellen','create Version', 'createVersion' ],
     addToCollection : ['Zur Standardsammlung hinzuf&uuml;gen','add to Collection', 'addToCollection' ],
     
     
     // Tabs  
     metadata : ['Metadaten','Metadata', 'Metadata' ],
       // Boxes + fields
       general : ['Allgemein','General', 'general' ],
       productnr: ['Artikelnummer', 'Item number', 'productnr' ],
       ordernr: ['Bestellnummer', 'Order number', 'ordernr' ],
       masterlang: ['Mastersprache', 'Master language', 'masterlang' ],
       seqOrdernr:  ['Reihenfolge', 'Display Order', 'seqOrdernr' ],
      
       
       
     product : ['Produkt','Product', 'Produs' ],
     attributes : ['Attribute','Attributes', 'Atribute' ],
     variants : ['Varianten','Variants', 'Variants' ],
     elements : ['Elemente','Elements', 'Element' ],
     relations : ['Beziehungen','Relations', 'Rela&#355;ii' ], 
     
     previews : ['Vorschauen','Previews', 'previews' ], 
     versions : ['Versionen','Versions', 'Versiune' ], 
     
     
     preview : ['Vorschau','Preview', 'Avanpremier&#259' ],
     version : ['Versionen','Version', 'Versiune' ],
     dataQuality:['Daten Qualität','Data Quality'],
     
     history : ['Historie','History', 'Istorie' ],    
     tasks : ['Aufgaben','Tasks', 'Sarcini' ],    
     collaboration: ['Zusammenarbeit','Collaboration'],
     edit: ['bearbeiten','edit', '' ],
     editType: ['{type} bearbeiten','Edit {type}', '' ],
     editProduct: ['Produkt bearbeiten','Edit Product', '' ],
     productstructure:['Produktstruktur','Productstructure', 'productstructure' ],
     pflege: ['pflege','maintenance', ' Ingrijire' ],
     
   language:['Sprache','Language', 'lang' ],
   uiLanguage:['Deutsch','Englisch', 'Rom�nesc' ],
   
	speechneutral: ['Sprachneutral','speech neutral', 'limbaj neutru' ],
	german:['Deutsch','German', 'German&#259;' ],
	english:['Englisch','English', 'Englez&#259' ],
	american:['Amerikanisch','American', 'American' ],
	french:['Franz&ouml;sisch' ,'French', 'Francez&#259' ],
	spanish:['Spanisch','Spanish', 'Spaniol&#259' ],
	italian:['Italienisch','Italian', 'Italian&#259' ],
	romanian:['Rum&auml;nisch','Romanian', 'Rom�nesc'],
	czech:['Tschechisch','Czech', 'Ceh&#259' ],
	turkian:['T&uuml;rkisch','Turkian', 'Turc&#259' ],
	danish:['D&auml;nisch','Danish', 'Danez&#259' ],
	svedish:['Schwedisch','Svedish', 'Suedez&#259' ],
  
  
    // Dialog Buttons
     reset:['Zur&uuml;cksetzen','Reset', 'Întoarcere' ]
  
    // key : ['','', '' ],
    };


extVia.locales = {
  uiLang: uiLang,
  uiLangIso: uiLangIso,
  uiLangIsoIx : uiLangIsoIx,
  searchterm:'Suchbegriff',
  searcharea:'Suchbereich',
  search:'Suchen',	
  startdate:'Startdatum',
  
  name:'Name',
  type:'Typ',
  state :'Status',
  
  refresh:'Neu Laden',
  asList:'als Liste anzeigen',
  asTree:'als Baum anzeigen',
  
  overview:'&Uuml;bersicht',
  details:'Details',
  workVersion:'Arbeitsversion',
  latestVersion:'letzte Version',
  frozVersion:'Version',
  workVersion_P:'Arbeitsversionen',
  frozVersion_P:'Versionen',
  
  
  ellip: '…'
  
};


Ext.Object.each(extVia.locale_DE_EN, function(key, value, myself) {
    extVia.locales[key] = value[extVia.locales.uiLangIsoIx];
});

//shortcuts
locales = extVia.locales;
loc = extVia.locales;

/*
 * 
 * $Revision: 1.9.6.14 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2019/07/03 16:29:07 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 