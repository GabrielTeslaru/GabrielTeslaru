/**
 * 
 */
Ext.application({
    name: 'plain',
    
    version:'$Revision: 1.1.2.1 $',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerHeight = centerPan.getHeight();
      centerHeight-=25; // substract center-tabstrip 
      centerHeight-=66; // substract pagejobbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=60;  // substract pagetoolbar 
      }
      if (cfg && cfg.hasSubtabs){
        centerHeight-=30; // substract subtabstrip
      }      
      return centerHeight;
    },

    getCenterWidth : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerWidth = centerPan.getWidth()-50;    
      return centerWidth;
    },
    
    getWestListHeight : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
      return westHeight;
    },
    

    showEditor: function(cfg) {
      var me = extVia.regApp;
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();  
      tabPanCenter.addAndActivate({});         
    },


    

    
    initWest: function() {

      var me = this;

         var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
             tabBar:{ 
               tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
               handler:function(button){
                 var activeTab = button.ownerCt.ownerCt.getActiveTab();
                   extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                 }
                }
               ]
             },
             items:[ {title:'some'}]

             });
            extVia.regApp.myRaster.addToWest(tabPanWest);
    },
    

    launch: function() {
      
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      var me = this;

      
      var  modulDscr = 'plain';


      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.constants.raster.mainWestWidth = 360;
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);


      me.initWest();
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
        handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
        iconCls:'x-tool x-tool-refresh'}]  } 
      });

      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      
      
      // if you ned an extra App Panel:  plain-Module
      var plainModalMask ;
      
       var plainModuleAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'plain', epobDscr: 'Neues Objekt',  
         pgjobButtons: [{itemId:'tree', handler:me.showFileChooser, tooltip:'Dateien wählen'}, 
           {itemId:'upload',  tooltip:'Epim Objekte erstellen', margin:'0 4 0 0', enableToggle:true,  xtype:'splitbutton',

            menu:{
              items:[
                {text:'Upload'},
                {text:'Upload Preview',
                  handler: function(){
                    me.showRequiredPreviewDialog({filename:'Test'});
                  }
                }
               ]
              }
           }
         ]
         } 
       );
       var plainModulePanel = {title:'plain', tbar: plainModuleAppbar, closable:true,
       defaults:{
         margin:'24 24 24 24',
         collapsible:true,
         width:580
       },                       
       items:[  

       ]
       };
       
       tabPanCenter.addAndActivate(plainModulePanel);


    }
});



/*
 * 
 * $Revision: 1.1.2.1 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2018/10/15 12:39:54 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 
