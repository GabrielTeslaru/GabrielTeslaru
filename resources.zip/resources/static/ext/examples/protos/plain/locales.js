Ext.namespace('extVia.locales' ,'extVia.plain.locales');
/**
 * @class plain
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/10/15 12:39:54 $
 *            $Revision: 1.1.2.1 $
 */





extVia.plain.locales = {
        appName:'plain',
        modul:'plain',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.plain.locales);



/*
 * 
 * $Revision: 1.1.2.1 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2018/10/15 12:39:54 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 