Ext.namespace('extVia.stores', 'extVia.locales', 'locales' );
/**
 * @class extVia.stores
 * Delivers models stores and dummy-data
 * 
 * @version   $Date: 2019/12/11 15:00:45 $
 *            $Revision: 1.158.2.19 $
 */


//shortcuts
locales = extVia.locales; 
//extVia.loc = extVia.locales;
//loc = extVia.loc; 


extVia.stores = function(config){
    Ext.apply(this,config,{    
        id          : "extVia.stores",
        name        : "extVia.stores"
    });
};

extVia.stores.prototype = {

    getColumnHeaderTexWithIcon : function(text, iconCls) {	
        return	'<div class="xty_column-header-icon '+iconCls+'"><span style="margin-left:20px;">'+text+'</span></div>';
    },	


    mengengridPageSize : 50,
    initLocalStorage : function(){

        Ext.define('Search', {
            fields: ['id','name', 'query'],
            extend: 'Ext.data.Model',
            proxy: {
                type: 'localstorage',
                id  : 'twitter-Searches'
            }
        });

        // Our Search model contains just two fields - id and query - plus a Proxy definition. 
        // The only configuration we need to pass to the LocalStorage proxy is an id. 
        // This is important as it separates the Model data in this Proxy from all others. 
        // The localStorage API puts all data into a single shared namespace, so by setting an id we enable LocalStorageProxy to manage the saved Search data
        // Saving our data into localStorage is easy and would usually be done with a Store:

        //our Store automatically picks up the LocalStorageProxy defined on the Search model
        var store = Ext.create('Ext.data.Store', {
            model: "Search",
            storeId:'localStorageStore'
        });

        //loads any existing Search data from localStorage
        store.load();
    },

    getLanguageFromISO2 : function(iso2){	
        var i;
        for (i =0; i <extVia.stores.languages.length; i++){
            if (extVia.stores.languages[i].iso2 === iso2){
                return extVia.stores.languages[i];
            }
        }
    },
    languages :  [
        // {id:'', shortcut:'_u',iso2:'_u', name: 'user',dscr: 'Benutzer'} ,
        {id:'0', shortcut:'nix',iso2:'nx',name: 'neutral', dscr: extVia.locales.speechneutral, 'countryLangId': 'nix_nx'} ,
        {id:'1', shortcut:'DE',iso2:'de',name: 'german', dscr: extVia.locales.german, 'countryLangId': 'DEU_deu'} ,

        {id:'3', shortcut:'EN',iso2:'en',name: 'english', dscr: extVia.locales.english,'countryLangId': 'GBR_eng'} ,
        {id:'5', shortcut:'US',iso2:'us',name: 'american', dscr: extVia.locales.american,'countryLangId': 'USA_eng'} ,
        {id:'4', shortcut:'FR',iso2:'fr',name: 'french', dscr: extVia.locales.french , 'countryLangId': ''},
        {id:'6', shortcut:'SP',iso2:'es',name: 'spanish',dscr: extVia.locales.spanish, 'countryLangId': ''} ,

        {id:'8', shortcut:'IT',iso2:'it',name: 'italian',dscr: extVia.locales.italian, 'countryLangId': ''} ,
        //{id:'9', shortcut:'CH',iso2:'ch',name: 'swiss',dscr: 'Schweiz', 'countryLangId': ''} ,
        {id:'10', shortcut:'RO',iso2:'ro',name: 'romania',dscr: extVia.locales.romanian, 'countryLangId': ''} ,
        {id:'11', shortcut:'CS',iso2:'cs',name: 'czech',dscr: extVia.locales.czech, 'countryLangId': ''} ,
        {id:'12', shortcut:'TR',iso2:'tr',name: 'turkian',dscr: extVia.locales.turkian, 'countryLangId': ''} ,
        {id:'13', shortcut:'DA',iso2:'da',name: 'danish',dscr: extVia.locales.danish, 'countryLangId': ''} ,
        {id:'14', shortcut:'SV',iso2:'sv',name: 'svedish',dscr: extVia.locales.svedish, 'countryLangId': ''} 
        /*  {id:'15', shortcut:'GR',iso2:'gr',name: 'greek',dscr: 'Griechisch', 'countryLangId': ''} ,
	                    {id:'16', shortcut:'FI',iso2:'fi',name: 'finn',dscr: 'Finnisch', 'countryLangId': ''} ,
	                    {id:'17', shortcut:'NL',iso2:'nl',name: 'nederlands',dscr: 'Niederl&auml;ndisch', 'countryLangId': ''} ,
	                    {id:'18', shortcut:'NO',iso2:'no',name: 'norwegian',dscr: 'Norwegisch', 'countryLangId': ''} ,
	                    {id:'19', shortcut:'PL',iso2:'pl',name: 'polsk',dscr: 'Polnisch', 'countryLangId': ''} ,
	                    {id:'20', shortcut:'RU',iso2:'ru',name: 'russion',dscr: 'Russisch', 'countryLangId': ''} ,
	                    {id:'21', shortcut:'HU',iso2:'hu',name: 'hungarian',dscr: 'Ungarisch', 'countryLangId': ''} ,
	                    {id:'22', shortcut:'CN',iso2:'cn',name: 'chinese',dscr: 'Chinesisch', 'countryLangId': ''} ,
	                    {id:'23', shortcut:'JP',iso2:'jp',name: 'japanese',dscr: 'Japanisch', 'countryLangId': ''} 
                      */

        //{id:'', shortcut:'',iso2:'',name: '',dscr: ''} ,

    ],
    initLanguageStore : function(cfg){ 
        var model = Ext.define('Language', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'id'},{type: 'string', name:'shortcut'},{type: 'string', name:'iso2'},{type: 'string', name: 'name'},{type: 'string', name: 'dscr'},{type: 'number', name: 'hits'}]
        });
        var data =  extVia.stores.languages;

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'languageStore',
            data: data
        });  

        return store;	
    },




    initDbViewsStore : function(cfg){ 
        var model = Ext.define('DbViews', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'id'},{type: 'string', name: 'name'},{type: 'string', name: 'dscr'},{type: 'number', name: 'hits'}]
        });
        // >>> PROD V4 Start (EPIM-7678) <<<
        var data = [{dscr:'Alle', hits:1000}, {dscr:'Readonly', hits:222} , {dscr:'Attribute', hits:333}, {dscr:'Preisliste', hits:123}, {dscr:'Datenbl&auml;tter', hits:300}];
        // >>> PROD V4 End (EPIM-7678) <<<
        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'DbViewsStore',
            data: data
        });  

        return store; 
    },


    randomHits : function(min, max){      // extVia.stores.randomHits(),     
        min = min?min:1; 
        max = max?max:100; 
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },



    getTimeRelatedStore : function(cfg){  
        var store =   Ext.data.StoreManager.lookup('timeRelated');

        // Todo: Do it calendar like
        var today = 1000*60*60*24;
        var anHour = 1000*60*60;
        var aDay = 1000*60*60*24;
        var aWeek = 1000*60*60*24*7;
        var aMonth = 1000*60*60*24*30.5;
        var aYear = 1000*60*60*24*365;



        if (!store){
            var model = Ext.define('timeRelated', { extend: 'Ext.data.Model',
                                                   fields: ['dscr', 'value', 'timespan', 'hits'] 
                                                  });
            var data = [ 

                //{dscr:'diese Stunde'}, {dscr:'vor einer Stunde'}, 
                {dscr: extVia.locales.all,  value:'', hits: extVia.stores.randomHits()}, 
                {dscr: extVia.locales.newest, value:'newest', hits: extVia.stores.randomHits()},  
                {dscr: extVia.locales.now, value:'now', hits: extVia.stores.randomHits(),  timespan: 0},

                {dscr: extVia.locales.today, value:'today',  timespan: anHour, hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.yesterday, value:'yesterday', timespan: aDay   , hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.thisweek ,value:'thisweek',  timespan: aWeek, hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.lastweek ,value:'lastweek', timespan: 2*aWeek, hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.thismonth ,value:'thismonth', timespan: aMonth, hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.lastmonth,value:'lastmonth', timespan: 2*aMonth, hits: extVia.stores.randomHits()}, 
                {dscr: extVia.locales.thisyear,value:'thisyear', timespan: aYear, hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.lastyear,value:'lastyear', timespan: 2*aYear, hits: extVia.stores.randomHits()},
                {dscr: extVia.locales.longtimeago,value:'longtimeago', timespan: 3*aYear, hits: extVia.stores.randomHits(1, 1000)}
            ];
            store = Ext.create('Ext.data.Store', {
                storeId:'timeRelatedStore',
                model: model,
                data: data
            });
        }
        return store; 
    },


    getActionTypesStore : function(cfg){  

        var isoen = true ; 

        var dscrALL = isoen? 'All':  'Alle';
        var dscrUPD = isoen? 'changed':  'ge&auml;ndert';
        var dscrINS = isoen? 'inserted':  "angelegt";
        var dscrASS = isoen? 'assigned':  "zugewiesen";
        var dscrDEL = isoen? 'deleted':  "gel&ouml;scht";

        var data = [ 
            {dscr: extVia.locales.all,  value:'', hits: 999}, 
            {dscr: extVia.locales.updated, value:'upd', hits: extVia.stores.randomHits()}, 
            {dscr: extVia.locales.inserted, value:'ins', hits: extVia.stores.randomHits()},
            {dscr: extVia.locales.assigned, value:'ass',hits: extVia.stores.randomHits()},
            {dscr: extVia.locales.deleted, value:'del',hits: extVia.stores.randomHits()} 
        ];

        if (cfg && cfg.forbidBlank){
            data.splice(0, 1);
        }

        var store =  Ext.create('Ext.data.Store', {
            model: Ext.define('actionTypes', {fields: ['dscr', 'value', 'hits'], extend: 'Ext.data.Model'}),
            data:data
        });
        return store;  
    },


    getHistoryEpobTypesStore : function(cfg){  
        var store =   Ext.data.StoreManager.lookup('historyEpobTypes');

        if (!store){
            store = Ext.create('Ext.data.Store', {
                storeId:'historyEpobTypes',
                model: Ext.define('historyEpobTypes', {fields: ['dscr', 'value', 'isarea', 'epobTypeId'], extend: 'Ext.data.Model'}),
                data:[
                    {dscr:'…',value:'Any', hits:'10000'},
                    {dscr:'Produktbereich',value:'Productsarea', isarea:true,  hits:'100', epobTypeId: 2000},
                    {dscr:'Hierarchien',value:'Hierarchy', hits:'50', epobTypeId: 2610},
                    //{dscr:'Produktgruppen', value:'Productgroup',  hits:'5', epobTypeId: 2030},
                    {dscr:'Produkte',value:'Product', hits:'25', epobTypeId: 2020},
                    {dscr:'Produktvarianten',value:'Productvariant', hits:'25', epobTypeId: 2040},
                    {dscr:'Produkte + Varianten',value:'ProductAndVariant', hits:'50', epobTypeId: 2050},


                    //{dscr:'',value:''},
                    //{dscr:'Beziehungen',value:'ProductsareaRelated', isarea:true},
                    {dscr:'Beziehungen',value:'ProductAssignment', isarea:true,hits:'25', epobTypeId: 2400},
                    //{dscr:'Produktbeziehung',value:'ProductAssignment'},
                    {dscr:'in Beziehung stehende Hierarchien',value:'Hierarchy',hits:'15',  epobTypeId: '2400 &#8596; 2610' },



                    {dscr:'in Beziehung stehende Produktgruppen',value:'ProductgroupRelated',hits:'5', epobTypeId: '2400 &#8596; 2030' },
                    {dscr:'in Beziehung stehende Produkte',value:'ProductRelated',hits:'5', epobTypeId: '2400 &#8596; 2020'},
                    //{dscr:'in Beziehung stehende Varianten',value:'ProductVariantRelated', epobTypeId: '2400 &#8596; 2020'},
                    //{dscr:'Referenzen',value:'ProductsareaReferences', isarea:true},
                    {dscr:'Referenzen',value:'Reference', isarea:true,hits:'50', epobTypeId: 4450},
                    {dscr:'Referenzen von Hierarchien',value:'Hierarchy',hits:'25', epobTypeId: '4450 &#8599; 2610'},
                    {dscr:'Referenzen von Produktgruppen',value:'ProductgroupReference',hits:'15', epobTypeId: '4450 &#8599; 2030'},
                    {dscr:'Referenzen von Produkten',value:'ProductReference',hits:'5',epobTypeId: '4450 &#8599; 2020'},
                    //{dscr:'Varianten Referenzen',value:'ProductVariantReference',hits:'5'},
                    {dscr:'Produktattribute',value:'ProductAttribute', hits:'5', epobTypeId: 2100},

                    {dscr:'Metadaten',value:'Metadata', isarea:true,  hits:'77', epobTypeId: 7001},


                    {dscr:'',value:'Any'},

                    {dscr:'Content',value:'Content', isarea:true, hits:'100', epobTypeId: 1000},
                    {dscr:'Elemente',value:'Elements', isarea:true, hits:'100', epobTypeId: 1111},
                    {dscr:'Bilder',value:'Image',hits:'25', epobTypeId: 1010},
                    {dscr:'Grafiken',value:'Graphic',hits:'5', epobTypeId: 1020}, 
                    {dscr:'Dokumente',value:'Document',hits:'5', epobTypeId: 1060},
                    {dscr:'Audios',value:'Audio',hits:'5', epobTypeId: 1040},
                    {dscr:'Videos',value:'Video',hits:'5', epobTypeId: 1050}, 
                    {dscr:'Produkttabellen',value:'ProdTable',hits:'5', epobTypeId: 1080}, 
                    {dscr:'Redaktionelle&nbsp;Tabellen',value:'EdTable',hits:'5', epobTypeId: 1070},
                    {dscr:'Elementattribute',value:'ContentAttribute',hits:'5', epobTypeId: 1250},

                    {dscr:'',value:'Any'},
                    {dscr:'Attribute',value:'Attribute', isarea:true,hits:'50', epobTypeId: 2101},
                    {dscr:"Dictionaries","value":"Dictionary",hits:'8', epobTypeId: 2180},
                    {dscr:"Strings","value":"String",hits:'10', epobTypeId: 2110},
                    {dscr:"Numbers","value":"Number",hits:'7', epobTypeId: 2130},
                    {dscr:"Flags","value":"Flag",hits:'5', epobTypeId: 2140},
                    {dscr:"Datum","value":"Date",hits:'5', epobTypeId: 2150},
                    {dscr:"Datumsangaben","value":"Date",hits:'5', epobTypeId: 2150},
                    {dscr:"Selections","value":"Selection",hits:'5', epobTypeId: 2160},
                    {dscr:"Attribute Collections","value":"AttributeCollection",hits:'5', epobTypeId: 2170}


                ]
            });

        }
        return store; 
    },




    countryLanguageModel : Ext.define('CountryLanguages', {
        extend: 'Ext.data.Model',
        fields: [
            {type: 'string', name:'name'},

            {type: 'boolean', name:'isMainCountry4Lang'},
            {type: 'boolean', name:'isNOTMainCountry4Lang'}, 
            {type: 'boolean', name:'isGlobalLang'},

            {type: 'string', name:'countryDscr'},{type: 'string', name:'countryDscrDE'}, {type: 'string', name:'countryISO2'}, {type: 'string', name:'countryISO3'}, 
            {type: 'string', name:'countryKey'}, {type: 'string', name:'countryLangId'}, {type: 'string', name:'flag'},

            {type: 'string', name:'langCountryId'}, {type: 'string', name:'language'}, {type: 'string', name:'languageDscr'}, {type: 'string', name:'languageDscrDE'}, 
            {type: 'string', name:'languageISO2'}, {type: 'string', name:'languageISO3'},{type: 'string', name:'languageKey'}
        ]
    }),

    initCountryLanguageStore : function(cfg){ 
        var  data =  extVia.stores.countryLang.statics.getCountryLanguages();
        var store = Ext.create('Ext.data.Store', {
            model: 'CountryLanguages',
            storeId:'countryLanguageStore',
            data: data
        });  
        return store; 
    },

    initMainLanguagesStore : function(cfg){ 
        var withDialects = false;
        var  data =  extVia.stores.countryLang.statics.getMainCountryLanguages(withDialects);
        var store = Ext.create('Ext.data.Store', {
            model: 'CountryLanguages',
            storeId:'mainLanguagesStore',
            data: data
        });  
        return store; 
    },

    initCountryLangCountriesStore : function(cfg){ 
        var  data =  extVia.stores.countryLang.statics.getCountryLanguages();
        var store = Ext.create('Ext.data.Store', {
            model: 'CountryLanguages',
            storeId:'countryLangCountriesStore',
            data: data
        });  
        return store; 
    },


    initAttributesStore : function(cfg){ 
        var model = Ext.define('Attributes', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'name'},{type: 'string', name:'dscr'},{type: 'string', name: 'epobType'}, {type: 'number', name: 'hits'},{type: 'String', name: 'multiplicity'}]
        });
        var data =  [
            {name:'productfeature', dscr: 'Product_features',    multiplicity:'*' ,epobType: 'String'} ,
            {name:'price', dscr: 'Attribute 1',  epobType: 'String' , multiplicity:'*'} ,
            {name:'price', dscr: 'Preis',  epobType: 'Number'} ,
            {name:'edurance', dscr: 'Haltbarkeit', epobType: 'Date'} ,
            {name:'american', dscr: 'american', epobType: 'Flag'} 
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'Attributes',
            data: data
        });  

        return store;	
    },

    initAttributeTypesStore : function(cfg){ 
        var model = Ext.define('AttributeTypes', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'name'},{type: 'string', name:'dscr'},{type: 'string', name: 'epobType'},{type: 'number', name: 'epobTypeId'}]
        });
        var data =  [
            //				{dscr: 'Alle', iconCls:'xty_epobAttribute', epobType:'Attribute' , epobTypeId:extVia.enums.EpimObjects.PRODUCTATTRIBUTE.id    },
            //				{dscr: 'Collection', iconCls:'xty_epobAttributeCollection', epobType:'AttributeCollection', epobTypeId:extVia.enums.EpimObjects.PRAT_COLLECTION.id },
            //				{dscr: 'Date', iconCls:'xty_epobDate', epobType:'Date', epobTypeId:extVia.enums.EpimObjects.PRAT_DATE.id },
            //				{dscr: 'Dictionary', iconCls:'xty_epobDictionary', triggerCls: 'x-form-dictionary-trigger', epobType:'Dictionary' , epobTypeId:extVia.enums.EpimObjects.PRAT_DICTIONARY.id},
            //				{dscr: 'String', iconCls:'xty_epobString', epobType:'String', epobTypeId:extVia.enums.EpimObjects.PRAT_STRING.id },
            //				{dscr: 'Dyn-String', iconCls:'xty_epobDynString', epobType:'DynString' , epobTypeId:extVia.enums.EpimObjects.PRAT_STRING.id+5},
            //				{dscr: 'Flag', iconCls:'xty_epobFlag', epobType:'Flag' , epobTypeId:extVia.enums.EpimObjects.PRAT_FLAG.id},
            //				{dscr: 'Number', iconCls:'xty_epobNumber', epobType:'Number', epobTypeId:extVia.enums.EpimObjects.PRAT_NUMBER.id },
            //				{dscr: 'Selection', iconCls:'xty_epobSelection', epobType:'Selection' , epobTypeId:extVia.enums.EpimObjects.PRAT_SELECTION.id}   

            {dscr: 'Alle', iconCls:'xty_epobAttribute', epobType:'Attribute'  },
            {dscr: 'Collection', iconCls:'xty_epobAttributeCollection', epobType:'AttributeCollection'},
            {dscr: 'Date', iconCls:'xty_epobAttributeDate', epobType:'Date'},
            {dscr: 'Dictionary', iconCls:'xty_epobDictionary', epobType:'Dictionary' , triggerCls: 'x-form-dictionary-trigger'},
            {dscr: 'String', iconCls:'xty_epobString', epobType:'String' },
            {dscr: 'Dyn-String', iconCls:'xty_epobDynString', epobType:'DynString'},
            {dscr: 'Flag', iconCls:'xty_epobFlag', epobType:'Flag'},
            {dscr: 'Number', iconCls:'xty_epobNumber', epobType:'Number'},
            {dscr: 'Selection', iconCls:'xty_epobSelection', epobType:'Selection'}   
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'AttributeTypes',
            data: data
        });  

        return store; 
    },
    initPratTableTypesStore : function(cfg){ 
        var model = Ext.define('PratTableTypes', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'dscr'},{type: 'string', name: 'cls'}, {type: 'string', name: 'image'}]
        });
        var data =  [
            { dscr: 'Checkboxes', cls:'' , img:''},
            { dscr: 'Checkboxes and ', cls:'' , img:''},
            { dscr: 'Checkboxes', cls:'' , img:''},
            { dscr: 'Checkboxes', cls:'' , img:''}

        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'PratTableTypes',
            data: data
        });  

        return store; 
    },


    initUserStore : function(cfg){ 

        var model = Ext.define('User', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'name'},{type: 'string', name: 'who'}]
        });
        var data = [


            {name: extVia.locales.all,  who:'all', hits: 9999},              
            {name: extVia.locales.allMine, who:'mine', hits: extVia.stores.randomHits()},              

            {name: extVia.locales.allButMine, who:'allbutmine', hits: extVia.stores.randomHits()},              

            {name: '…',who:'*', hits: 9999},               
            {name: 'Janis Joplin',who:'vm ', hits: extVia.stores.randomHits()},               
            {name: 'Joe Miller',who:'vm', hits: extVia.stores.randomHits()},
            {name: 'Simone Biles',who:'vm proj', hits: extVia.stores.randomHits() },     
            {name: 'Michael Rooker',who:'vm r&d', hits: extVia.stores.randomHits() },               
            {name: 'Tony Danza',who:'vm proj', hits: extVia.stores.randomHits() },               
            {name: 'Bo Derek',who:'vm', hits: extVia.stores.randomHits() },               
            {name: 'Karl Lagerfeld',who:'vm', hits: extVia.stores.randomHits() },    
            {name: 'Bruce Willis',who:'vm', hits: extVia.stores.randomHits() },
            {name: 'Frank Castle',who:'vm scrum', hits: extVia.stores.randomHits()},
            {name: 'Simon Garfunkel',who:'vm ux', hits: extVia.stores.randomHits() },               


            {name:'Doug Engelbart',who:'Mother of all demos', hits: extVia.stores.randomHits() },
            {name:'Dieter Rams',who:'braun design guru', hits: extVia.stores.randomHits() },
            {name:'Bernard Purdie',who:'Soul Drummer', hits: extVia.stores.randomHits() },
            {name:'Nina Simone',who:'Singer', hits: extVia.stores.randomHits() },
            {name:'Douglas Crockford',who:'javascript guru', hits: extVia.stores.randomHits() },
            {name:'Jesse James Garret',who:'ajax name giver', hits: extVia.stores.randomHits() },
            {name:'Clemens Lutsch',who:'UX Evangelist', hits: extVia.stores.randomHits() },
            {name:'Steve Krug',who:'Usability pro', hits: extVia.stores.randomHits() },
            {name:'Werner T.Kuestenmacher',who:'simplify founder', hits: extVia.stores.randomHits() },
            {name:'Lothar J. Seiwert',who:'simplify founder', hits: extVia.stores.randomHits() },
            {name:'Esther Derby',who:'Thinker', hits: extVia.stores.randomHits() },
            {name:'Marissa Mayer',who:'Genius', hits: extVia.stores.randomHits() },
            {name:'Gunther Dueck',who:'Writer and Thinker', hits: extVia.stores.randomHits() },
            {name:'Lars Hinrichs',who:'Xing Founder', hits: extVia.stores.randomHits() },
            {name:'Jason Dorsey',who:'Twitter founder and genY', hits: extVia.stores.randomHits() },	
            {name:'Georges I. Gurdjieff',who:'Teacher Musician', hits: extVia.stores.randomHits() },
            {name:'Haruki Murakami',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Arkadi Strugatzki',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Boris Strugatzki',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Stanislaw Lem',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Paul Coelho',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Michael Ende',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Carlos Ruiz Zafon',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Oscar Wilde',who:'Writer', hits: extVia.stores.randomHits() },
            {name:'Luisa Francia',who:'Author Thinker Writer Painter', hits: extVia.stores.randomHits() },
            {name:'Susanne Fischer-Rizzi',who:'Author', hits: extVia.stores.randomHits() },
            {name:'Klausbernd Vollmar',who:'Psychologe Dreamanalyzer', hits: extVia.stores.randomHits() },
            {name:'Lisa Kekaula',who:'BellRays', hits: extVia.stores.randomHits() },
            {name:'Ringo Starr',who:'Beatles Drummer', hits: extVia.stores.randomHits() },
            {name:'Gene Krupa',who:'Jazz Drummer', hits: extVia.stores.randomHits() },
            {name:'Phil Rudd',who:'AC/DC Drummer', hits: extVia.stores.randomHits() },
            {name:'Peter Criss',who:'Kiss Drummer', hits: extVia.stores.randomHits() },
            {name:'John Bonham',who:'Led Zeppelin Drummer', hits: extVia.stores.randomHits() },
            {name:'Keith Moon',who:'Who Drummer', hits: extVia.stores.randomHits() },
            {name:'Bill Ward',who:'Black Sabbath Drummer', hits: extVia.stores.randomHits()}
        ];

        if (cfg && cfg.forbidBlank){
            data.splice(0, 4);
        }

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'UserStore',
            data: data
        });  

        return store;	
    },

    initReceiverStore : function(cfg){ 
        var model = Ext.define('Receiver', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'epob'},
                     {type: 'string', name: 'name'}]
        });
        var data = [

            {name: 'Administrator', epob:extVia.enums.EpimObjects.ROLE.key},  
            {name: 'Entwikler', epob:extVia.enums.EpimObjects.ROLE.key},  
            {name: 'Support', epob:extVia.enums.EpimObjects.ROLE.key},  
            {name: 'Vertrieb', epob:extVia.enums.EpimObjects.ROLE.key},  
            {name: 'Student', epob:extVia.enums.EpimObjects.ROLE.key},  
            {name: 'Gesch&auml;ftsf&uuml;hrer', epob:extVia.enums.EpimObjects.ROLE.key},  
            {name: 'Hausmeister', epob:extVia.enums.EpimObjects.ROLE.key},  

            {name: 'Administrator', epob:extVia.enums.EpimObjects.USERGROUP.key},  
            {name: 'Entwikler', epob:extVia.enums.EpimObjects.USERGROUP.key},  
            {name: 'Support', epob:extVia.enums.EpimObjects.USERGROUP.key},  
            {name: 'Vertrieb', epob:extVia.enums.EpimObjects.USERGROUP.key},  
            {name: 'Student', epob:extVia.enums.EpimObjects.USERGROUP.key},  

            {name:'Doug Engelbart',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Dieter Rams',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Bernard Purdie',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Nina Simone',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Douglas Crockford',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Jesse James Garret',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Clemens Lutsch',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Steve Krug',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Werner T.Kuestenmacher',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Lothar J. Seiwert',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Esther Derby',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Marissa Mayer',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Gunther Dueck',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Lars Hinrichs',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Jason Dorsey',epob:extVia.enums.EpimObjects.USER.key}, 
            {name:'Stanislaw Lem',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Oscar Wilde',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Luisa Francia',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Susanne Fischer-Rizzi',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Klausbernd Vollmar',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Lisa Kekaula',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Ringo Starr',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Gene Krupa',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Phil Rudd',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Peter Criss',epob:extVia.enums.EpimObjects.USER.key},
            {name:'John Bonham',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Keith Moon',epob:extVia.enums.EpimObjects.USER.key},
            {name:'Bill Ward',epob:extVia.enums.EpimObjects.USER.key}
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'ReceiverStore',
            data: data,
            groupField : 'epob',
            sorters : [ 'epob', 'name', 'name_DE']
        });  

        return store; 
    },


    initArticelStore : function(cfg){ 
        var model = Ext.define('Article', {
            extend: 'Ext.data.Model',
            fields: [
                {type: 'string', name: 'name'},
                {type: 'string', name: 'author'},
                {type: 'string', name: 'id'},
                {type: 'string', name: 'format'},
                {type: 'string', name: 'title'},
                {type: 'string', name: 'categorie'},
                {type: 'string', name: 'previewimage'}, 
                {type: 'string', name: 'summary'},
                {type: 'string', name: 'link'},
                {type: 'string', name: 'creationdate'}, 
                {type: 'string', name: 'changedate'}, 
                {type: 'boolean', name: 'isnew'}
            ]
        });





        var data = [
            { name: 'name', author: 'author', id: 'id', categories:['Muppets', 'Drummer'],  formats:['PDF'], title: 'title', categorie: 'categorie', 
             previewimage: 'http://t3.gstatic.com/images?q=tbn:ANd9GcQ_2G0iZQ3eV2YGPSBWoL1kO1Y12SisYRzP3b-ZYG0hl-hZY4iu4KxX', summary: 'summary', link: 'link', creationdate: 'creationdate', isnew: true    },
     
            {author:'Kermit',summary:'speaker', categories:['Entertainer', 'Muppets'], formats:['Video'],  previewimage: 'http://gfw.condign.org/wiki/images/thumb/a/a0/84px-Kaleb.G_Kermit_ava.jpg'},
            {author:'Doug Engelbart',summary:'Mother of all demos' ,formats:['Video'], previewimage: 'http://t0.gstatic.com/images?q=tbn:ANd9GcQZdTc8Goq6-Dvhsxg26UqfMhXdr9lxjIH1Ydf0otN71xS39yWf82hv'},
            {author:'Dieter Rams', summary:'braun design guru' ,formats:['PDF'], previewimage: 'http://t1.gstatic.com/images?q=tbn:ANd9GcQ_rhcU-XhJkIaCxRHpnPp2zkNo83vOOxX01kgVG5OgfoP2dxmBmz22', link:'https://readymag.com/shuffle/dieter-rams/ten-commandments/'},


            {author:'Douglas Crockford',summary:'javascript guru', formats:['Audio'], previewimage: 'http://t2.gstatic.com/images?q=tbn:ANd9GcRCyIgts2-R9mUqzedidUD7ZdKF42P2fgLJk6gSCrRhCOC0Uml3lHpp'},

            {author:'Marc Hassenzahl',summary:'UX Professor', formats:['Document'],  previewimage: 'http://design-center.de/de/img/large/Hassenzahl+Marc_Portrait_Zuschnitt.jpg_477.jpg', ldink: 'https://youtu.be/pAfee75FQeE?t=1423'},
            {author:'Holger Eggert',summary:'UX Evangelist', formats:['Document'], previewimage: 'http://t2.gstatic.com/images?q=tbn:ANd9GcTj2mIukmh2euESXOQxTzrBZ2E4eMZ0dJvamh0eiMcZHV2zUSvD6H-3'},
            {author:'Clemens Lutsch',summary:'UX Evangelist', formats:['Audio'], previewimage: 'http://t3.gstatic.com/images?q=tbn:ANd9GcStILvo5Z-53xABDwMxjFic5I3NxmZnv3lgwEehyxK4mPAY8wU3HrUA'},

            {author:'Guy Kavasaki',summary:'Speaker' ,formats:['PDF'], previewimage:'http://t3.gstatic.com/images?q=tbn:ANd9GcTNmkO5OG1tzHmvU4XCCOEZHA0LWEs0PheRzmLJ-xvXShAJmbDBxcZc'},

            {author:'Martin Wezowski',summary:'SAP Chief Designer User Experience', formats:['Document'], previewimage: 'http://3ltddlexn3z1jo9ym15ce9rc.wpengine.netdna-cdn.com/germany/files/2015/01/IMG_7048.jpg', link:'http://www.staggeringbeauty.com/', linXk:'https://www.youtube.com/watch?v=Jx_Sq-z-pY8'},

            {author:'Niels Pfl&auml;ging',summary:'Komplexithoden and Thinker', formats:['Document'], previewimage: 'http://t0.gstatic.com/images?q=tbn:ANd9GcTkM0skJgZhLIfmu429Itsq_0JIwqH9ouQ7E_lEBPXLmHtIqN5_baCq'},
            {author:'Gunther Dueck',summary:'Writer and Thinker', formats:['Audio'], previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcQuljkR0b-1dqVFgvq_MAx-B3U1qkXoNLTSJ9TUpC99zDbjSqobF6Fw'},


            {author:'Jesse James Garret',summary:'ajax author giver', formats:['Document'], previewimage: 'http://t0.gstatic.com/images?q=tbn:ANd9GcSGYhE7wf_fnmJR7min9qihGt6KkUbZ7rAuYGAgLxU__PsTTnvb4dfy'},
            {author:'Steve Krug',summary:'Usability pro', formats:['Audio'], previewimage: 'http://t3.gstatic.com/images?q=tbn:ANd9GcTBfV8mk5tnvQAKaliCUT0z726_0xKN2Jo01J8WpunFM6vP-a2c9c6v'},
            {author:'Werner T.Kuestenmacher + Lothar J. Seiwert',summary:'simplify founder',formats:['Video'], previewimage: 'http://t2.gstatic.com/images?q=tbn:ANd9GcQGNM1raWrE4kEGn5PpqAHf-WlwAVhcwPmJG_hNouUHb9CpSGythhqyWA'},


            {author:'Lars Hinrichs',summary:'Xing Founder' ,formats:['PDF'], previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcTJKvgUDbeYb3h6IhdGbOenHYrnAB8AQGn9rrtH0CGcK81KDvd_G6CS'},
            {author:'Jason Dorsey',summary:'Twitter founder and genY',formats:['PDF'], previewimage:'http://t3.gstatic.com/images?q=tbn:ANd9GcTu_NE8iII0Owwcpp-MkjIZ58lE2pu_3C-pQdm8V6USo5lgAGEG5voTfA'}, 


            {author:'Georges I. Gurdjieff',summary:'Teacher Musician',formats:['Video'], previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcSLGp4MbTA6JP0nzYOm14hmsRAu2VHjh_YZtsyjM5EDuKQS26cXr7ct'},


            {author:'Haruki Murakami',summary:'Writer' ,formats:['PDF'], previewimage:'http://t3.gstatic.com/images?q=tbn:ANd9GcRHLn8jLc5Nxzooc6JrOjruFsJ7lqBj40UG4IrClOvIEhzogJeKAbGk'},
            {author:'Arkadi +Boris Strugatzki',summary:'Writer', formats:['Audio'],previewimage: 'http://t1.gstatic.com/images?q=tbn:ANd9GcSvXG4pv5ICCzdZWQTwCdyEm_6VE5cNrEnZGQcISsVvzdLLF9weKi6x'},
            {author:'Stanislaw Lem',summary:'Writer', formats:['PDF'], previewimage:'http://t2.gstatic.com/images?q=tbn:ANd9GcQhXFZljy7_yuW23XX55zkBRxjxJmtsvG7SlFA3gr0vybv8d-BoycaG'},
            {author:'Paul Coelho',summary:'Writer' ,formats:['PDF'], previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcTMfle8dLQ2Ah2zekdyLeqvnJAgLV_e06J1xuP4_HNTPHI_K4GfpD2y'},
            {author:'Michael Ende',summary:'Writer', formats:['Audio'], previewimage:'http://t0.gstatic.com/images?q=tbn:ANd9GcTnKBCfa9_b5q-fB-T6Xskov8hE0dYF9Ac87YQA-7df7hJ9ARDumgfp'},
            //{author:'Carlos Ruiz Zafon',summary:'Writer' ,formats:['PDF'], previewimage:''},
            {author:'Oscar Wilde',summary:'Writer' ,formats:['PDF'], previewimage:'http://t3.gstatic.com/images?q=tbn:ANd9GcTe_csoxCZlDMe36_G8vGDIWL0d6S_i5YreXA9aeaCe_N94zwBWdsRI' },
            {author:'Luisa Francia',summary:'Author Thinker Writer Painter', formats:['Audio'], previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcQu9i3gz_DW2yypijiS_ms4swj22meoafvbwpF-CZICkSClPZ-t0Lld'},
            //{author:'Susanne Fischer-Rizzi',summary:'Author', formats:['Document'], previewimage:''},
            {author:'Klausbernd Vollmar',summary:'Psychologe Dreamanalyzer',  previewimage:'http://t2.gstatic.com/images?q=tbn:ANd9GcRjmOPtopI_ENZNQGwDHQQJpWeU3jcGHbade0cEdsNXtXR41kPL271v'},
            {author:'Animal',summary:'legendary monster', formats:['Audio'], previewimage: 'http://t3.gstatic.com/images?q=tbn:ANd9GcQ_2G0iZQ3eV2YGPSBWoL1kO1Y12SisYRzP3b-ZYG0hl-hZY4iu4KxX'},
            {author:'Nina Simone',summary:'Singer', formats:['Document'], previewimage: 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRE8CaP6BjTVrhyFOfQIi-aDRjZMTTWNDFJ6t-zMCbd67vhITbx'},

            {author:'Lisa Kekaula',summary:'BellRays',  previewimage:'http://t3.gstatic.com/images?q=tbn:ANd9GcSZr0TzHcnogmUYBUShfjLz0ctFnNvfnmLvFRko8waXK8Ngs7PZ6xTD'},
            {author:'Ringo Starr',summary:'Beatles Drummer', formats:['Document'],  previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcT9brWCN0QOHMCztNnpQZAPVDnFUh6F3EnzFpkcTXRNwJL1uMRRBUb1'},
            {author:'Gene Krupa',summary:'Jazz Drummer', formats:['Document'],  previewimage:'http://t3.gstatic.com/images?q=tbn:ANd9GcTpSuHoRwaj_8UI71RLHCAG5ZQYNougtzMrKwN9bZrljf2QDyh2N3cz'},
            {author:'Bernard Purdie',summary:'Soul Drummer', formats:['Document'], previewimage: 'http://t2.gstatic.com/images?q=tbn:ANd9GcQa9reGe4wG5gwf944XeEHHeX7YlrOPqTx26uRZc5STCQ3hQEcFtVBo'},
            //  {author:'Phil Rudd',summary:'AC/DC Drummer',  previewimage:''},
            //  {author:'Peter Criss',summary:'Kiss Drummer',  previewimage:''},
            {author:'John Bonham',summary:'Led Zeppelin Drummer', categories:['Drummer'],  formats:['Document'],  previewimage:'http://th02.deviantart.net/fs45/PRE/f/2009/148/7/7/John_Bonham_vector_by_nxy21189.jpg'},
            {author:'Bill Ward',summary:'Black Sabbath Drummer', formats:['Document'],  previewimage:'http://t1.gstatic.com/images?q=tbn:ANd9GcQGfVgj3hSWxqswF5-znxGN00Ip6CdIQ8CWKkurA08v-Ne8AFPzEs2f'}
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            //bufferd:true,
            autoLoad: false,
            storeId:'ArticelStore',
            myData: data
        });  


        return store; 
    },

    statusData:[ 
        //{value: 'All' , dscr : 'Alle'} ,
        {value: 'Unknown' , dscr : 'Unbekannt'},   
        {value: 'Loading' , dscr : 'Daten werden geladen'},   
        {value: 'Crossref' , dscr : 'Verwendungsnachweis'} ,
        {value: 'Assignments' , dscr : 'Zuweisungen'} ,
        {value: 'Inherited' , dscr : 'Ererbt'} ,
        {value: 'NotInherited' , dscr : 'Nicht Ererbt'} ,
        {value: 'InheritanceActive' , dscr : 'Vererbung aktiv'} ,
        {value: 'InheritanceBroken' , dscr : 'Vererbung unterbrochen'} ,
        {value: 'FurtherInheritanceBroken' , dscr : 'Weitervererbung unterbrochen'} ,
        // {value: 'ChildsNotInherit' , dscr : 'Kinder erben nicht'} ,
        {value: 'NoFurtherInheritance' , dscr : 'Keine Weitervererbung'} ,
        //{value: 'NoLegacy' , dscr : 'Nicht weitervererbt'} ,
        {value: 'Template' , dscr : 'Vorlage'} ,
        {value: 'OK' , dscr : 'OK'} ,
        {value: 'Success' , dscr : 'Erfolgreich'} ,
        {value: 'Active' , dscr : 'Aktiv'} ,
        {value: 'Allowed' , dscr : 'Erlaubt'} ,
        {value: 'Error' , dscr : 'Fehlerhaft'} ,
        {value: 'ErrorValidate' , dscr : 'Fehler bei der Validierung'} ,
        {value: 'Failed' , dscr : 'Fehlgeschlagen'} ,

        {value: 'Finished' , dscr : 'Beendet'} ,
        {value: 'FinishedSuccess' , dscr : 'beendet mit Erfolg'} ,
        {value: 'FinishedWarning' , dscr : 'beendet mit Warnung'} ,
        {value: 'FinishedError' , dscr : 'beendet mit Fehler'} ,

        {value: 'Deprecated' , dscr : 'Veraltet'} ,
        {value: 'Expired' , dscr : 'Abgelaufen'} ,
        {value: 'Warning' , dscr : 'Warnung'} ,
        // {value: 'WarningExpired' , dscr : 'Warnung Abgelaufen'} ,
        // {value: 'WarningDeleted' , dscr : 'Warnung Gel&ouml;scht'} ,
        // {value: 'WarningDeprecated' , dscr : 'Warnung Veraltet'} ,
        // {value: 'WarningLocked' , dscr : 'Warnung Gesperrt'} ,
        {value: 'Information' , dscr : 'Information'} ,
        {value: 'Unchecked' , dscr : 'Ungecheckt'} ,
        {value: 'Checked' , dscr : 'Gecheckt'} ,
        {value: 'Yes' , dscr : 'Ja ich bin'} ,
        {value: 'No' , dscr : 'Nein ich bin nicht'} ,
        {value: 'Initialized' , dscr : 'Initialisiert'} ,
        {value: 'Started' , dscr : 'Gestartet'} ,
        {value: 'Running' , dscr : 'L&auml;uft'} ,
        {value: 'Executed' , dscr : 'Ausgef&uuml;hrt'} ,
        {value: 'Planned' , dscr : 'Geplant'} ,
        {value: 'Locked' , dscr : 'Gesperrt'} ,
        {value: 'Unlocked' , dscr : 'Entsperrt'} ,
        {value: 'ListChecked' , dscr : 'Liste Gecheckt'} ,
        {value: 'ListUnchecked' , dscr : 'Liste Ungecheckt'} ,
        {value: 'Help' , dscr : 'Hilfe'} ,
        {value: 'Question' , dscr : 'Frage'} ,
        {value: 'Inactive' , dscr : 'Inaktiv'} ,

        {value: 'Downloading' , dscr : 'Downloading'} ,
        {value: 'Uploading' , dscr : 'Uploading'} ,
        {value: 'Synchronizing' , dscr : 'Synchronizierend'} ,

        {value: 'Stopped' , dscr : 'Gestoppt'} ,
        {value: 'Stopping' , dscr : 'Wird Gestoppt'} ,
        {value: 'StoppedByUser' , dscr : 'Gestoppt durch Benutzer'} ,
        {value: 'StoppedByReboot' , dscr : 'Gestoppt durch Neustart'} ,
        {value: 'Paused' , dscr : 'Pausiert'} ,
        {value: 'Deleted' , dscr : 'Gel&ouml;scht'} ,
        {value: 'Jump' , dscr : 'Gehe zu'} ,
        {value: 'ChangeIt' , dscr : 'Bitte &auml;ndern'} ,
        {value: 'Matrix' , dscr : 'Matrix'} ,
        {value: 'Attribute' , dscr : 'Attribut'} ,
        {value: 'Selected' , dscr : 'Ausgew&auml;hlt'} ,
        {value: 'DropNo' , dscr : 'Drop nicht erlaubt'} ,
        {value: 'NotAllowed' , dscr : 'Nicht erlaubt'} ,
        {value: 'Structure' , dscr : 'Struktur'} ,
        {value: 'Assigned' , dscr : 'Zugewiesen'} ,
        {value: 'AssignedAlready' , dscr : 'Bereits zugewiesen'} ,
        {value: 'Config' , dscr : 'Konfiguration'} ,
        {value: 'Danger' , dscr : 'Gefahr'} ,
        {value: 'Empty' , dscr : 'Leer'} ,
        {value: 'Editable' , dscr : 'Bearbeitbar'} ,
        {value: 'Readonly' , dscr : 'Nur Lesbar'} ,
        {value: 'Show' , dscr : 'Zeigen'} ,
        {value: 'Hide' , dscr : 'Ausblenden'} ,
        {value: 'Searchable' , dscr : 'Suchbar'} ,
        {value: 'NotSearchable' , dscr : 'Nicht Suchbar'} ,
        {value: 'SearchableExtended' , dscr : 'Suchbar in erweiterter Suche'} ,
        {value: 'SearchableRestricted' , dscr : 'Suchbar in eingeschr&auml;nkter Suche'} ,
        {value: 'Timeout' , dscr : 'Zeit&uuml;berschreitung'} ,
        {value: 'Cancelled' , dscr : 'Abgebrochen / Cancelled'} ,
        {value: 'Aborted' , dscr : 'Abgebrochen / Aborted'} ,
        {value: 'AbortedByUser' , dscr : 'Abgebrochen durch Benutzer'} ,
        {value: 'AbortedByReboot' , dscr : 'Abgebrochen durch Neustart'} ,
        {value: 'Queued' , dscr : 'Eingereiht'} ,
        {value: 'Waiting' , dscr : 'Wartend'} ,
        {value: 'XMLFileExported' , dscr : 'XML-Datei exportiert'}, 

        {value: 'AssignedCollection' , dscr : 'Sammlung ist zugewiesen'}, 
        {value: 'SyncLocked' , dscr : 'synchronisiere gesperrte  Objekte'}, 
        {value: 'GeneratingSequence' , dscr : 'Generiere Sequenz'}, 
        {value: 'Able' , dscr : 'Bereit'} ,
        {value: 'Unable' , dscr : 'nicht Bereit'} ,
        {value: 'Above' , dscr : 'Von oben'} ,
        {value: 'AssignedAbove' , dscr : 'Ererbt'} ,
        {value: 'Here' , dscr : 'Hier'} ,
        {value: 'Nothing' , dscr : 'Nichts'},
        {value: 'Overwritten' , dscr : 'Überschrieben'} 


    ],


    initStatusStore : function(cfg){ 
        var model = Ext.define('Status', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'}] });
        var data = extVia.stores.statusData;
        var  store = Ext.create('Ext.data.Store', { storeId:'Status', model: model,data: data});  
        return store; 
    },

    initWhatDoISeeStore : function(cfg){ 
        var model = Ext.define('whatdoisee', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'name'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}]
        });
        var data = [
            {name: 'work',dscr: 'Arbeitsversion',id: '1'} ,
            {name: 'froz',dscr: 'Eingefroren',id: '2'} ,
            {name: 'diff',dscr: 'Delta',id: '3'} 
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'whatdoisee',
            data: data
        });  

        return store;	
    },


    getPinfoareaTypes : function(area){

        var productinfoareas = {
            metadata:{types:[
                {"dscr":"String","value":"String"},
                {"dscr":"Number","value":"Number"},
                {"dscr":"Flag","value":"Flag"},
                {"dscr":"&Auml;nderungsinfo","value":"ChangeInfo"},   
                {"dscr":"&Auml;nderungsinfo Medienobjekt","value":"ChangeInfoMediaobject"},
                {"dscr":"Sprache","value":"Language"},
                {"dscr":"Pfad","value":"Path"}
            ]},

            workflow:{types:[

                {"dscr":"Workflowgroup","value":"Workflowgroup"},
                {"dscr":"Workflow","value":"Workflow"},
                {"dscr":"WorkflowState","value":"WorkflowState"},
                {"dscr":"String","value":"String"},
                {"dscr":"WorkflowRole","value":"WorkflowRole"},
                {"dscr":"WorkflowResponsiblePerson","value":"WorkflowResponsiblePerson"},
                {"dscr":"WorkflowProcess","value":"WorkflowProcess"},
                {"dscr":"WorkflowProcessStep","value":"WorkflowProcessStep"},
                {"dscr":"WorkflowProcessStep","value":"WorkflowProcessStep"}
            ]},
            languages:{types:[
                {"dscr":"&Auml;nderungsinfo","value":"ChangeInfo"},
                {"dscr":"&Auml;nderungsinfo  Medienobjekt","value":"ChangeInfoMediaobject"},
                {"dscr":"Sprach&auml;nderung","value":"languagechange"}, 
                {"dscr":"Sprache","value":"Language"},
                {"dscr":"Datum","value":"Date"},
                {"dscr":"User","value":"User"}            
            ]
                      },
            changeinfo:{types:[
                {"dscr":"&Auml;nderungsinfo","value":"ChangeInfo"},
                {"dscr":"&Auml;nderungsinfo  Medienobjekt","value":"ChangeInfoMediaobject"},
                //{"dscr":"String","value":"String"},
                {"dscr":"Datum","value":"Date"},
                {"dscr":"User","value":"User"}

            ]
                       },  
            attributes:{types:[
                {"dscr":"Dictionary","value":"Dictionary"},
                {"dscr":"String","value":"String"},
                {"dscr":"Number","value":"Number"},
                {"dscr":"Flag","value":"Flag"},
                {"dscr":"Date","value":"Date"},
                {"dscr":"Selection","value":"Selection"},
                {"dscr":"Collection","value":"Collection"},
                {"dscr":"Attribute Collection","value":"AttributeCollection"},

                {"dscr":"Attribute","value":"Attribute"},
                {"dscr":"Productattribute","value":"Productattribute"},
                {"dscr":"CollectionEntry","value":"CollectionEntry"},
                {"dscr":"AttributeCollectionEntry","value":"AttributeCollectionEntry"}
            ]},
            reference:{types:[
                //{"dscr":"String","value":"String"},
                {"dscr":"ProductReference","value":"ProductReference"},
                {"dscr":"Reference","value":"Reference"}
            ]},

            variants:{types:[
                {"dscr":"String","value":"String"}
            ]},

            publication:{types:[{"dscr":"String","value":"String"}]},

            relations:{types:[
                {"dscr":"Image","value":"Image"},
                {"dscr":"Graphic","value":"Graphic"},
                {"dscr":"Text","value":"Text"},
                {"dscr":"Audio","value":"Audio"},
                {"dscr":"Video","value":"Video"},
                {"dscr":"Document","value":"Document"},
                {"dscr":"EdTable","value":"EdTable"},
                {"dscr":"ProdTable","value":"ProdTable"},    
                {"dscr":"Publikation","value":"Publication"},

                {"dscr":"Hierarchy","value":"Hierarchy"},
                {"dscr":"Productgroup","value":"Productgroup"},
                {"dscr":"Product","value":"Product"},
                {"dscr":"Productvariant","value":"Productvariant"},


                {"dscr":"Zuweisung","value":"Assignment"},
                {"dscr":"ProductAssignment","value":"ProductAssignment"},
                {"dscr":"ProductElementAssignment","value":"ProductElementAssignment"},
                {"dscr":"ElementAssignment","value":"ElementAssignment"}


            ]},


            elements:{types:[
                //{"dscr":"String","value":"String"},
                {"dscr":"Image","value":"Image"},
                {"dscr":"Graphic","value":"Graphic"},
                {"dscr":"Text","value":"Text"},
                {"dscr":"Audio","value":"Audio"},
                {"dscr":"Video","value":"Video"},
                {"dscr":"Document","value":"Document"},
                {"dscr":"EdTable","value":"EdTable"},
                {"dscr":"ProdTable","value":"ProdTable"},    
                {"dscr":"SimpleText","value":"SimpleText"},

                {"dscr":"&Auml;nderungsinfo Medienobjekt","value":"ChangeInfoMediaobject"}, 

                {"dscr":"Zuweisung","value":"Assignment"},
                {"dscr":"ProductElementAssignment","value":"ProductElementAssignment"},
                {"dscr":"ElementAssignment","value":"ElementAssignment"},
                {"dscr":"ImageAssignment","value":"ImageAssignment"},
                //{"dscr":"ImageAssignmentType","value":"ImageAssignmentType"},
                {"dscr":"GraphicAssignment","value":"GraphicAssignment"},
                //{"dscr":"GraphicAssignmentType","value":"GraphicAssignmentType"},
                {"dscr":"TextAssignment","value":"TextAssignment"},
                //{"dscr":"TextAssignmentType","value":"TextAssignmentType"},
                {"dscr":"AudioAssignment","value":"AudioAssignment"},
                //{"dscr":"AudioAssignmentType","value":"AudioAssignmentType"},
                {"dscr":"VideoAssignment","value":"VideoAssignment"},
                //{"dscr":"VideoAssignmentType","value":"VideoAssignmentType"},
                {"dscr":"DocumentAssignment","value":"DocumentAssignment"},
                //{"dscr":"DocumentAssignmentType","value":"DocumentAssignmentType"},
                {"dscr":"EdtableAssignment","value":"EdtableAssignment"},
                //{"dscr":"EdtableAssignmentType","value":"EdtableAssignmentType"},
                {"dscr":"ProducttableAssignment","value":"ProducttableAssignment"}
                //{"dscr":"ProducttableAssignmentType","value":"ProducttableAssignmentType"}
            ]},

            productrelations:{types:[



                //{"dscr":"String","value":"String"},          
                {"dscr":"Products","value":"Products"},
                {"dscr":"Product","value":"Product"},
                {"dscr":"Productgroup","value":"Productgroup"},
                {"dscr":"ProductVariant","value":"ProductVariant"},
                {"dscr":"ProductAndVariant","value":"ProductAndVariant"},
                {"dscr":"ProductgroupHity","value":"ProductgroupHity"},
                {"dscr":"ProductAssignment","value":"ProductAssignment"},
                {"dscr":"ProductAssignmentType","value":"ProductAssignmentType"}

            ]},

            suppliers:{types:[
                //{"dscr":"String","value":"String"},
                {"dscr":"Supplier","value":"Supplier"},
                {"dscr":"SupplierAttribute","value":"SupplierAttribute"},
                {"dscr":"SupplierBranch","value":"SupplierBranch"},
                {"dscr":"SupplierBranchAttribute","value":"SupplierBranchAttribute"}
            ]},

            previews:{types:[
                //{"dscr":"String","value":"String"},
                {"dscr":"Productpreview","value":"Productpreview"},
                {"dscr":"Productpreviewdefinition","value":"Productpreviewdefinition"}
            ]
                     }
        };




        var dataX =	    [

            {"dscr":"SimpleText","value":"SimpleText"},
            {"dscr":"Category","value":"Category"},
            {"dscr":"MyCategories","value":"MyCategories"},
            {"dscr":"Contentattribute","value":"Contentattribute"},
            {"dscr":"BatchJob","value":"BatchJob"},

            {"dscr":"Products","value":"Products"},
            {"dscr":"Product","value":"Product"},
            {"dscr":"Productgroup","value":"Productgroup"},
            {"dscr":"ProductVariant","value":"ProductVariant"},
            {"dscr":"ProductAndVariant","value":"ProductAndVariant"},
            {"dscr":"ProductgroupHity","value":"ProductgroupHity"},



            {"dscr":"ImageAssignmentType","value":"ImageAssignmentType"},
            {"dscr":"GraphicAssignmentType","value":"GraphicAssignmentType"},
            {"dscr":"TextAssignmentType","value":"TextAssignmentType"},
            {"dscr":"AudioAssignmentType","value":"AudioAssignmentType"},
            {"dscr":"VideoAssignmentType","value":"VideoAssignmentType"},
            {"dscr":"DocumentAssignmentType","value":"DocumentAssignmentType"},
            {"dscr":"EdtableAssignmentType","value":"EdtableAssignmentType"},
            {"dscr":"ProducttableAssignmentType","value":"ProducttableAssignmentType"},


            {"dscr":"ProductReference","value":"ProductReference"},

            {"dscr":"Hierarchytype","value":"Hierarchytype"},
            {"dscr":"Hierarchy","value":"Hierarchy"},
            {"dscr":"HierarchyNode","value":"HierarchyNode"},



            {"dscr":"Publish","value":"Publish"},
            {"dscr":"Publication","value":"Publication"},


            {"dscr":"Reference","value":"Reference"},
            {"dscr":"CrossReference","value":"CrossReference"},
            {"dscr":"Userarea","value":"Userarea"},
            {"dscr":"User","value":"User"},
            {"dscr":"Usergroup","value":"Usergroup"}


        ];

        return productinfoareas[area].types;

    },



    initPinfoareaTypesStore : function(cfg){ 

        var model = Ext.define('dataType', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'}]
        });

        //	        var data = [];
        //		    var prop;    
        //		    for (prop in extVia.enums.EpimObjects) {     
        //		      if (extVia.enums.EpimObjects.hasOwnProperty(prop) ){
        //		         data.push({dscr:extVia.enums.EpimObjects[prop].key, value:extVia.enums.EpimObjects[prop].key });
        //		      }    
        //		    }

        var data = extVia.stores.getPinfoareaTypes(cfg.area);


        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'dataType',
            data: data
        });  

        return store;	
    },

    initProductinfoareaStore : function(cfg){ 

        var model = Ext.define('productinfoarea', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'},{type: 'int', name: 'areaorder'}]
        });

        var data = [
            {dscr:'Metadata', value:'metadata', areaorder:1},
            {dscr:'Workflows', value:'workflow', areaorder:2},
            {dscr:'ChangeInfo', value:'changeinfo', areaorder:3},
            {dscr:'Sprachen', value:'languages', areaorder:3},
            {dscr:'Stammdaten', value:'masterdata', areaorder:4},
            {dscr:'Attribute', value:'attributes', areaorder:4},
            //{dscr:'Varianten', value:'variants', areaorder:5},
            {dscr:'Elemente',  value:'elements', areaorder:6},
            {dscr:'Produktbeziehungen', value:'productrelations', areaorder:7},

            {dscr:'Beziehungen',  value:'relations', areaorder:8},
            {dscr:'Zuordnungen',  value:'relations', areaorder:8},
            {dscr:'Referenzen', value:'reference', areaorder:9},
            {dscr:'Publikationen', value:'publication', areaorder:10},

            {dscr:'Lieferanten', value:'suppliers', areaorder:11},
            {dscr:'Vorschauen', value:'previews', areaorder:12}  
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'productinfoarea',
            data: data
        });  

        return store;	
    },






    initProductRelationsStore : function(cfg){ 
        var model = Ext.define('Productrelation', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'name'},{type: 'string', name: 'value'}]
        });
        var data = [
            {"dscr":"Zubeh&ouml;r","value":"zubehoer"},    
            {"dscr":"Ersatzteil","value":"ersatzteil"},    
            {"dscr":"Empfohlene Produkte","value":"assozprods"}   

        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'Productrelation',
            data: data
        });  
        return store;	
    },


    initVersionsStore : function(cfg,epob){ 

        var model = Ext.define('Version', {
            extend: 'Ext.data.Model',
            fields: [
                {type: 'string', name: 'versionNr'},
                {type: 'string', name: 'dscr'},
                {type: 'string', name: 'id'},
                {type: 'string', name: 'date'},
                {type: 'string', name: 'user'},
                {type: 'string', name: 'comment'},
                {type: 'string', name: 'blockedLanguages'},                     
                {type: 'string', name: 'versionsdepht'},
                {type: 'boolean', name: 'crossref'}

            ]
        });
        // >>> PROD V4 Start (EPIM-7678) <<<
        var data = [
            {dscr: 'ACME STE',versionNr: '',date:'20. Jan 2014',user:'Izzy', comment:'Webkatalog', versionsdepht:'*', blockedLanguages:'de,en,it,es'} ,
            {dscr: 'STE',versionNr: '4',date:'10. Jan 2013',user:'Admin', comment:'',crossref: true, versionsdepht:'P'} ,
            {dscr: 'Stichs&auml;ge STE',versionNr: '3',date:'15. Okt 2010',user:'Elvis', comment:'',crossref: true, versionsdepht:'E'} ,
            {dscr: 'Stichs&auml;ge ST',versionNr: '2',date:'14. Mai 2009',user:'Izzy', comment:'', versionsdepht:'E'} ,
            {dscr: 'Stichsaege',versionNr: '1',date:'13. Mai 2009',user:'Izzy', comment:'',crossref: true, versionsdepht:'-'} 
        ];
        if ( epob.epobId === "ACME_Power_Maxx_BS_Quick"){  
            data = [
                {dscr: 'ACME Power Maxx BS Quick',versionNr: '',date:'13. Mai 2014',user:'', comment:'', versionsdepht:'*'} ,
                {dscr: 'Power Maxx BS Quick',versionNr: '4',date:'07. Mai 2014',user:'Michael Rooker', comment:'added Zubeh&ouml;r',crossref: true, versionsdepht:'P'} ,
                {dscr: 'Power Maxx Quick ',versionNr: '3',date:'25. April 2014',user:'Dieter Rams', comment:'corrected Features, added Elemente',crossref: true, versionsdepht:'E'} ,
                {dscr: 'Power Maxx Quick',versionNr: '2',date:'20. M&auml;rz 2014',user:'Simon Garfunkel', comment:'added Features', versionsdepht:'E'} ,
                {dscr: 'Power Maxx',versionNr: '1',date:'10. Februar 2014',user:'Bernard Purdie', comment:'',crossref: true, versionsdepht:'-'} 
            ];
        }
        // >>> PROD V4 End (EPIM-7678) <<<


        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'Version',
            data: data
        });  

        return store;	
    },

    initVersionsDephtStore : function(cfg){ 
        var model = Ext.define('versionsDepht', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'dscr'},{type: 'string', name: 'value'}]
        });



        var data = [


            {value: 'P',dscr: 'Produkt', additional:'Nur Produkt versionieren'},
            {value: 'PV',dscr: 'Produkt und Varianten', additional:'Produkt und zugehörige Varianten versionieren'},
            {value: 'PE',dscr: 'Produkt und Elemente', additional:'Produkt, Variante und alle Elemente'},
            {value: 'PVE',dscr: 'Produkt, Varianten und alle Elemente', additional:'Produkt und zugehörige Varianten und zugeordnete Elemente versionieren'},


            {value: '...',dscr: '...'},


            {value: '-',dscr: 'Nur Produkt'},
            {value: '--',dscr: 'Nur Bild'} ,
            {value: 'V',dscr: 'incl. Varianten '},
            {value: 'G',dscr: 'incl. Produktgruppe'},
            {value: 'P',dscr: 'incl. zugewiesenen Produkten'},
            {value: 'E',dscr: 'incl. zugewiesenen Elementen'},
            {value: 'I',dscr: 'incl. zugewiesenen Bildern'},
            {value: '*',dscr: 'Alles'},
            {name: '*-...',dscr: 'Alles ausser ...'}
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'versionsDepht',
            data: data
        });  

        return store;	
    },

    initReferenceLineStore : function(cfg){ 
        var model = Ext.define('referenceline', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'name'},{type: 'string', name: 'dscr'},{type: 'number', name: 'id'},{type: 'string', name: 'epobTypeKey'}]
        });
        var data = [
            {name: 'orig', dscr: 'Original',id: '0', epobTypeKey: 'Product'} ,
            {name: 'wegwegwe', 		path: 'Smartphones &raquo; Apple  &raquo; H&uuml;llen &raquo;',	dscr: 'Muppets-Kermit',id: '1', epobTypeKey: 'ProductReference'} ,
            {name: 'svvsvs', 		path: 'Smartphones &raquo; Samsung  &raquo; H&uuml;llen &raquo;',	dscr: 'Muppets-Frog',id: '2', epobTypeKey: 'ProductReference'} ,
            {name: 'svvsvs', 		path: 'Smartphones &raquo; Samsung  &raquo;',	dscr: 'Muppets-Kermit',id: '2', epobTypeKey: 'ProductVariant'} ,
            {name: 'svsvsvswweg',	path: 'Smartphones &raquo; Nokia &raquo; H&uuml;llen &raquo;',	dscr: 'Muppets',id: '3', epobTypeKey: 'ProductReference'} 
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'referenceline',
            data: data
        });  

        return store;	
    },




    initPublicationStore : function(cfg){ 
        var model = Ext.define('Publication', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'shortcut'},{type: 'string', name: 'name'},{type: 'string', name: 'dscr'},{type: 'string', name: 'year'},{type: 'string', name: 'epobId'}]
        });
        var data = [
            {name: 'fallcatlogue',  shortcut:'fall', dscr: 'Herbstkatalog',epobId: '1', year:'2012'} ,
            {name: 'mess', shortcut:'mess', dscr: 'Messe', epobId: '2', year:'2013'} ,
            {name: 'chapter 5',  shortcut:'chp5', dscr: 'Kapitel 5',epobId: '3', year:'2013'} ,
            {name: 'Taschen',  shortcut:'tsch', dscr: 'Taschenkatalog',epobId: '4', year:'2013'} ,
            {name: 'overviewNews', shortcut:'news', dscr: 'Übersicht Neuheiten',epobId: '5', year:'2012'} 
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'publicationStore',
            data: data
        });  

        return store;	
    },		

    initImageStore : function(cfg){ 


        var model = Ext.define('ImageModel', {
            extend: 'Ext.data.Model',
            fields: [
                {name: 'name', type: 'string'},
                {name: 'epobId', type: 'string'},
                {name: 'epobTypeId', type: 'string'},
                {name: 'url', type: 'string'},
                {name: 'size', type: 'float'},
                {name:'lastmod', type:'date', dateFormat:'timestamp'}
            ]
        });

        // >>> PROD V4 Start (EPIM-7678) <<<
        var data = [ 		 			
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A1_602000.jpg", epobId:'1', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A1_602190.jpg", epobId:'2', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A2_600500.jpg", epobId:'3', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A2_602150.jpg", epobId:'4', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A3_600500.jpg", epobId:'5', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A4_602000.jpg", epobId:'6', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/A4_602400.jpg", epobId:'7', epobTypeId:extVia.module.epob.ELEMENTS},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/P_602100.jpg", epobId:'8', epobTypeId:extVia.module.epob.PRODUCT},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/P_602140.jpg", epobId:'9', epobTypeId:extVia.module.epob.PRODUCT},
            {"name":"ACME","size":2901,"lastmod":1366360398000,"url":"fakes/previews/metabo/P_602400.jpg", epobId:'10', epobTypeId:extVia.module.epob.PRODUCT}
        ];
        // >>> PROD V4 End (EPIM-7678) <<<


        if (cfg && cfg.pageSize ){
            data = data.splice (cfg.pageStart, cfg.pageSize);
        }


        var storeId = "imageStore" + (cfg?cfg.epobType:'');


        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:storeId,
            data: data
        });  

        return store;	
    },	



    initAvailableEpobsStore : function(cfg){ return extVia.stores.initTagsStore(cfg); },


    initSortbyStore : function(cfg){

        var model = Ext.define('Sortby', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name:'shortcut'},{type: 'string', name: 'name'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}]
        });
        var data = [
            {shortcut:'MOST',name: 'name',dscr: 'Name',id: '1'} ,
            {shortcut:'DSCR',name: 'dscr',dscr: 'Beschreibung',id: '2'} ,
            {shortcut:'DATE',name: 'date',dscr: 'Änderungsdatum',id: '3'} ,
            {shortcut:'LAST',name: 'last',dscr: 'k&uuml;rzlich angesehen',id: '4'}, 
            {shortcut:'MOST',name: 'most',dscr: 'am meisten angesehen',id: '5'} 
        ];

        var store = Ext.create('Ext.data.Store', {
            model: model,
            storeId:'sortbyStore',
            data: data
        });  

        return store;
    },


    initEpobDialogStore : function(cfg){ 

        var fields = [

            {type: 'string', name: 'mainInstr'},
            {type: 'string', name: 'suppInstr'},
            {type: 'number', name: 'epobTypeId'},
            {type: 'string', name: 'epobType'},
            {type: 'string', name: 'epobTypeDscr'},
            {type: 'number', name: 'epimId'},
            {type: 'string', name: 'epobDscr'},
            {type: 'string', name: 'parentDscr'},
            {type: 'string', name: 'path'},
            {type: 'string', name: 'shortcut'},
            {type: 'string', name: 'description'},
            {type: 'string', name: 'catchwords'},
            {type: 'string', name: 'language'},
            {type: 'string', name: 'tags'},
            {type: 'string', name: 'sortby'},
            {type: 'boolean',name: 'sortOrderASC'},
            {type: 'boolean',name: 'showText'},
            {type: 'boolean',name: 'showInNewWindow'},
            {type: 'string', name: 'color'}    	         

        ];


        var epobModel = 	Ext.define('newEpob', {
            fields: fields,
            extend: 'Ext.data.Model'
        });

        var startIndex  =0; var  stopIndex =105;

        var epobStore =   Ext.create('Ext.data.Store', {
            model: epobModel, 
            autoLoad: true,
            storeId:'newEpobStore',
            pageSize:cfg?cfg.pageSize: extVia.stores.mengengridPageSize,

            proxy: {
                data: extVia.stores.getEpobDummyData({startIndex:startIndex, stopIndex:stopIndex}),
                reader: {
                    type: 'json'
                }
            }
        });
        return epobStore;	
    }, 
    initDQCStore : function(cfg){
        var me = this;
        Ext.define('DQC', {
            extend: 'Ext.data.Model',
            fields: [{type:'number', name:'id'},
                     {type: 'string', name: 'name'},
                     {type: 'string', name: 'command'},
                     {type: 'string', name: 'summary'},
                     {type: 'string', name: 'definition'},
                     {type: 'string', name: 'formula'},
                     {type: 'string', name: 'epobType'},
                     {type: 'string', name: 'Typ'},
                     {type: 'string', name: 'status'},
                     {type: 'string', name: 'ruleSet'},
                     {type: 'string', name: 'qualityIndex'}]
        });

        var DQCStore = Ext.create('Ext.data.Store', {
            storeId: 'DQCStore',
            model:'DQC',
            groupField: 'ruleSet',
            data: [
                { id: 1, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Handheld PowerTools', qualityIndex:'Web' },
                { id: 2, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Handheld PowerTools', qualityIndex:'Web' },
                { id: 3, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Handheld PowerTools', qualityIndex:'Web' },
                { id: 4, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Semi Stationary Tools', qualityIndex:'Web' },
                { id:5, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Semi Stationary Tools', qualityIndex:'Web' },
                { id: 6, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Semi Stationary Tools', qualityIndex:'Web' },
                { id: 7, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Other tools', qualityIndex:'Web' },
                { id: 8, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Other tools', qualityIndex:'Web' },
                { id: 9, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Other tools', qualityIndex:'Web' },
                { id: 10, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Handheld PowerTools', qualityIndex:'Print' },
                { id: 11, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Handheld PowerTools', qualityIndex:'Print' },
                { id: 12, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', Typ: 'Rule', status: 'Started', ruleSet:'Handheld PowerTools', qualityIndex:'Print' },
            ]
        });

        me.DQCStore = DQCStore;
    },

    getDQCStore:function(){
        var me = this;
        return me.DQCStore;
    },

    initQualityDimensionsStore : function(cfg){
        var me = this;
        Ext.define('Dimensions', {
            extend: 'Ext.data.Model',
            fields: [{type:'number',name:'id'},{type: 'string', name: 'dscr'},{type: 'string', name: 'value'}]
        });

        var qualityDimensionsStore = Ext.create('Ext.data.Store', {
            storeId: 'qualityDimensionsStore',
            model:'Dimensions',
            data: [{ id:1,dscr: 'Entries', value: 'Entries' },
                   { id:2,dscr: 'Accessibility', value: 'Accessibility' }, 
                   { id:3,dscr: 'Accuracy', value: 'Accuracy' },
                   { id:4,dscr: 'Completeness', value: 'Completeness' },
                   { id:5,dscr: 'Consistency', value: 'Consistency' },
                   { id:6,dscr: 'Relevance', value: 'Relevance' },
                   { id:7,dscr: 'Timeliness', value: 'Timeliness' },
                   { id:8,dscr: 'Validity', value: 'Validity' }
                  ]
        });
        me.qualityDimensionsStore = qualityDimensionsStore;
    },

    getQDCurentStore:function(){
        var me = this;
        return me.qualityDimensionsStore;
    },
    
    initQualityGatesStore : function(cfg){
        var me = this;
        Ext.define('QualityGates', {
            extend: 'Ext.data.Model',
            fields: [{type:'number',name:'id'},{type: 'string', name: 'text'},{type: 'string', name: 'name'}]
        });

        var QualityGatesStore = Ext.create('Ext.data.Store', {
            storeId: 'QualityGatesStore',
            model:'QualityGates',
            data: [{ id:1, text: 'Web', name: 'Web' },
                   { id:2, text: 'Print', name: 'Print' }, 
                   { id:3, text: 'Shop', name: 'Shop' },
                   { id:4, text: 'Ecommerce', name: 'Ecommerce' },
                   { id:5, text: 'Spring Catalog', name: 'Spring Catalog' }
                  ]
        });
        me.QualityGatesStore = QualityGatesStore;
    },  
    
    addQualityGatesStore : function(record){
        var me = this;
        me.QualityGatesStore.add(record);
    },

    getQualityGatesStore:function(){
        var me = this;
        return me.QualityGatesStore;
    },
    
    initRuleSetStore : function(cfg){
        var me = this;
        Ext.define('EpobTypes', {
            extend: 'Ext.data.Model',
            fields: [{type:'number',name:'id'},{type: 'string', name: 'dscr'},{type: 'string', name: 'value'}]
        });

        var epobTypesStore = Ext.create('Ext.data.Store', {
            storeId: 'epobTypesStore',
            model:'EpobTypes',
            data: [{ id: 1, dscr: 'Handheld PowerTools', value: 'Handheld PowerTools' },
                   { id: 2, dscr: 'Semi Stationary Tools', value: 'Semi Stationary Tools' }, 
                   { id: 3, dscr: 'Other Tools', value: 'Other Tools' }
                  ]
        });
        me.epobTypesStore = epobTypesStore;
    },

    addRecordIntoStore : function(record){
        var me = this;
        me.epobTypesStore.add(record);
    },

    getCurentStore:function(){
        var me = this;
        return me.epobTypesStore;
    },

    initDQGStore : function(cfg){ 
        var me = this;

        var DQGStore = Ext.create('Ext.data.TreeStore', {
            storeId: 'DQGStore',
            root: {
                id: 1,
                text: "Data Quality Gates",
                name: "Data Quality Gates",
                expanded: true,
                cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                iconCls: 'xty_epobQualityIndex',
                epobType: 'root',
                children: [{
                    id: 2,
                    text: "Web",
                    name: "Web",
                    expanded: true,
                    cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                    iconCls: 'xty_epobQualityIndex',
                    epobType: 'QualityIndex',
                    children: [{
                        id: 3,
                        text: "Handheld PowerTools",
                        name: "Handheld PowerTools",
                        cls: 'xty_node-modifier',
                        iconCls: 'xty_epobRuleset',
                        expanded: true,
                        epobType: 'Ruleset',
                        children: [{ id: 4, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', cls: 'xty_node-modifier xty_node-level-1 xty_open-on-start-node', iconCls: 'xty_epobRule', expanded: true, epobType: 'Rule' },
                                   { id: 5, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true },
                                   { id: 6, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true }
                                  ]
                    },
                               {
                                   id: 7,
                                   text: "Semi Stationary Tools",
                                   name: "Semi Stationary Tools",
                                   cls: 'xty_node-modifier',
                                   iconCls: 'xty_epobRuleset',
                                   expanded: false,
                                   epobType: 'Ruleset',
                                   children: [{ id: 8, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', cls: 'xty_node-modifier xty_node-level-1 xty_open-on-start-node', iconCls: 'xty_epobRule', expanded: true, epobType: 'Rule' },
                                              { id: 9, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true },
                                              { id: 10, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true }
                                             ]
                               },
                               {
                                   id: 11,
                                   text: "Other tools",
                                   name: "Other tools",
                                   cls: 'xty_node-modifier',
                                   iconCls: 'xty_epobRuleset',
                                   expanded: false,
                                   epobType: 'Ruleset',
                                   children: [{ id: 12, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', cls: 'xty_node-modifier xty_node-level-1 xty_open-on-start-node', iconCls: 'xty_epobRule', expanded: true, epobType: 'Rule' },
                                              { id: 13, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true },
                                              { id: 14, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true }
                                             ]
                               }
                              ]
                },
                           {
                               id: 15,
                               text: "Print",
                               name: "Print",
                               expanded: true,
                               cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                               iconCls: 'xty_epobQualityIndex',
                               epobType: 'QualityIndex',
                               children: [{
                                   id: 16,
                                   text: "Handheld PowerTools",
                                   name: "Handheld PowerTools",
                                   cls: 'xty_node-modifier',
                                   iconCls: 'xty_epobRuleset',
                                   expanded: false,
                                   epobType: 'Ruleset',
                                   children: [{ id: 17, text: "Empathy", name: "Empathy", command: '', summary: '', definition: '', formula: '', cls: 'xty_node-modifier xty_node-level-1 xty_open-on-start-node', iconCls: 'xty_epobRule', expanded: true, epobType: 'Rule' },
                                              { id: 18, text: "Required", name: "Required", command: 'No empty fields', summary: 'Explaination why this rules is needed.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: '', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true },
                                              { id: 19, text: "Redlight", name: "Redlight", command: 'Do not cross the street when redlight is on', summary: 'You dontt want to have a traffic accident.', definition: 'Exact rule definition in words/prosa. Needed to build the tech-formula', formula: 'Look at the signs. If light is red. If light is green, check streetsides, if streetsides empty you can walk', iconCls: 'xty_epobRule', epobType: 'Rule', leaf: true }
                                             ]
                               }]
                           },
                           {
                               id: 20,
                               text: "Shop",
                               name: "Shop",
                               expanded: false,
                               cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                               iconCls: 'xty_epobQualityIndex',
                               epobType: 'QualityIndex',
                           },
                           {
                               id: 21,
                               text: "Ecommerce",
                               name: "Ecommerce",
                               expanded: false,
                               cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                               iconCls: 'xty_epobQualityIndex',
                               epobType: 'QualityIndex',
                           },
                           {
                               id: 22,
                               text: "Spring Catalog",
                               name: "Spring Catalog",
                               expanded: false,
                               cls: 'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',
                               iconCls: 'xty_epobQualityIndex',
                               epobType: 'QualityIndex',
                           }
                          ]
            }
        });
        me.DQGStore = DQGStore;
    },

    getDQGStore:function(){
        var me = this;
        return me.DQGStore;
    },

    initTreeStores : function(cfg){ 
        //Models
        Ext.define('Epob', {
            extend: 'Ext.data.Model',
            fields: [{type: 'string', name: 'text'},{type: 'string', name: 'dscr'},{type: 'number', name: 'epobTypeId'},{type: 'string', name: 'epobId'}]
        });

        var productsStore = Ext.create('Ext.data.TreeStore', {
            storeId:'productsTreeStore',
            model: 'Epob',
            root: {
                text: extVia.locales.hierarchies,iconCls:'xty_epobHierarchyies',
                expanded: true,

                // >>> PROD V4 Start (EPIM-7678) <<<
                children: [
                    { text: "ACME",  expanded: true,  cls:'xty_node-modifier xty_node-level-1 ',  iconCls:'xty_epobHierarchy xty_hasDummy', epobTypeId:extVia.enums.EpimObjects.HIERARCHY.id,     
                     children: [
                         { text: "Elektrowerkzeuge",  cls:'xty_node-modifier xty_node-level-2 ', iconCls:'xty_epobProductgroup xty_hasDummy', expanded: true, epobTypeId:extVia.enums.EpimObjects.PRODUCTGROUP.id,children: [ 

                             { text: "Akkuger&auml;te",  expanded: true, cls:'xty_node-modifier  xty_node-modifier-released  xty_node-level-3 ',  iconCls:'xty_epobProductgroup xty_hasDummy',epobTypeId:extVia.enums.EpimObjects.PRODUCTGROUP.id,
                              children: [
                                  { text: "Akku-Bohrschrauber", cls:'xty_node-modifier   xty_node-modifier-readonly  xty_node-level-4 ',  iconCls:'xty_epobProductgroup xty_hasDummy' , expanded: true, epobTypeId:extVia.enums.EpimObjects.PRODUCTGROUP.id,
                                   children:[
                                       { text: "ACME Power Maxx",    epobId:'ACME_Power_Maxx', cls:'xty_node-modifier xty_node-level-5 xty_open-on-start-node', iconCls:'xty_epobProduct xty_hasDummy' , expanded: true, epobTypeId:extVia.enums.EpimObjects.PRODUCT.id,
                                        children:[
                                            { text: "Structure", expanded: true, epobId:'ACME_Power_Maxx-structure',  iconCls:'xty_icon xty_iconStructure', 
                                             children:[
                                                 {text:'Bilder',  expanded: true,  cls:'xty_node-modifier xty_node-modifier-released xty_node-level-7 ',iconCls:'xty_epobElements', children:[{ text: "Produktbild ACME Power Maxx", id: "Produktbild_ACME_Power_Maxx", leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id}]},
                                                 {text:'Zubeh&ouml;r', expanded: true, cls:'xty_node-modifier xty_node-modifier-blocked xty_node-level-7 ',iconCls:'xty_epobProductAssignment', children:[{ text: "PowerMaxx Akku 50A", leaf: true,  iconCls:'xty_epobProduct', epobId:'PowerMaxx_Akku_50A', epobTypeId:extVia.enums.EpimObjects.PRODUCT.id }]},

                                                 {text:'Referenzen', expanded: true,iconCls:'xty_epobReferences', children:[{ text: "Ref ACME Power Maxx", leaf: true,  iconCls:'xty_epobProductReference', epobId:'Ref_ACME_Power_Maxx', epobTypeId:extVia.enums.EpimObjects.PRODUCT.id }]}


                                             ]

                                            },
                                            { text: "ACME Power Maxx BS Quick", expanded: true, epobId:'ACME_Power_Maxx_BS_Quick', iconCls:'xty_epobProductVariant xty_hasDummy', epobTypeId:extVia.enums.EpimObjects.PRODUCTVARIANT.id,
                                             children:[
                                                 { text: "Structure", expanded: true, epobId:'ACME_Power_Maxx_BS_Quick-structure', iconCls:'xty_icon xty_iconStructure', 
                                                  children:[
                                                      {text:'Bilder', cls:'xty_node-modifier xty_node-modifier-locked xty_node-level-8 ', expanded: true, iconCls:'xty_epobElements', children:[{text: "Produktbild ACME Power Maxx BSQuick", leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id}]},
                                                      {text:'Zubeh&ouml;r', expanded: true,iconCls:'xty_epobProductAssignment', children:[{ text: "PowerMaxx Akku 50A", leaf: true,  iconCls:'xty_epobProduct', epobId:'PowerMaxx_Akku_50A', epobTypeId:extVia.enums.EpimObjects.PRODUCT.id }]}
                                                  ]}]


                                            },
                                            { text: "ACME Power Maxx Li", epobId:'ACME_Power_Maxx_Li', iconCls:'xty_epobProductVariant',leaf: true, epobTypeId:extVia.enums.EpimObjects.PRODUCTVARIANT.id },
                                            { text: "ACME Power Maxx Li Pro", epobId:'ACME_Power_Maxx_Li_Pro', iconCls:'xty_epobProductVariant',leaf: true , epobTypeId:extVia.enums.EpimObjects.PRODUCTVARIANT.id},							 
                                            { text: "ACME Power Maxx 12", epobId:'ACME_Power_Maxx_12', iconCls:'xty_epobProductVariant',leaf: true, epobTypeId:extVia.enums.EpimObjects.PRODUCTVARIANT.id },
                                            { text: "ACME Power Maxx 12 Pro", disabled: true, cls:'xty_disabled-node',  epobId:'ACME_Power_Maxx_12_Pro', iconCls:'xty_epobProductVariant',leaf: true, epobTypeId:extVia.enums.EpimObjects.PRODUCTVARIANT.id }						 							 
                                        ]
                                       },
                                       { text: "ACME BS", iconCls:'xty_epobProduct', leaf: true },
                                       { text: "Ref ACME Power Maxx", leaf: true,  iconCls:'xty_epobProductReference', epobId:'Ref_ACME_Power_Maxx', epobTypeId:extVia.enums.EpimObjects.PRODUCT.id }
                                   ]
                                  },
                                  { text: "Akku-Bandfeilen",iconCls:'xty_epobProductgroup',leaf: true },
                                  { text: "Akku-Baustellenradio",iconCls:'xty_epobProductgroup',leaf: true },
                                  { text: "Akku-Handkreiss&auml;gen",iconCls:'xty_epobProductgroup',leaf: true}
                              ] 
                             }, 
                             { text: "Bohrmaschinen", iconCls:'xty_epobProductgroup', children: [ { text: "ACME B",iconCls:'xty_epobProduct', leaf: true }, { text: "ACME BDE",iconCls:'xty_epobProduct', leaf: true }] }  ,
                             { text: "Bohrhammer", iconCls:'xty_epobProductgroup', children: [ { text: "ACME BHE", iconCls:'xty_epobProduct',leaf: true }] } ,
                             { text: "Stichs&auml;gen",   iconCls:'xty_epobProductgroup  xty_hasDummy',
                              children: [ 

                                  { text: "Attrappen",  expanded: true, iconCls:'xty_epobProductgroup xty_hasDummy',
                                   children: [
                                       { text: "Test dummy", iconCls:'xty_epobProduct xty_hasDummy',epobId:'Test_dummy', leaf: true }, 
                                       { text: "Product 1", iconCls:'xty_epobProduct xty_hasDummy',epobId:'product_1', leaf: true }
                                   ]
                                  },
                                  { text: "ACME STE", iconCls:'xty_epobProduct  xty_hasDummy' , epobId:'ACME_STE',
                                   children:[
                                       { text: "STE 100 Plus", iconCls:'xty_epobProductVariant',leaf: true },
                                       { text: "STE 100 SCS", iconCls:'xty_epobProductVariant', leaf: true },
                                       { text: "STE 100 SCS", iconCls:'xty_epobProductVariant', leaf: true },
                                       { text: "STE 135 Plus", iconCls:'xty_epobProductVariant',leaf: true },
                                       { text: "STE 135 Plus", iconCls:'xty_epobProductVariant', leaf: true },
                                       { text: "STE 90 SCS", iconCls:'xty_epobProductVariant', leaf: true }							 
                                   ]
                                  },
                                  { text: "ACME STEB", iconCls:'xty_epobProduct' ,
                                   children:[
                                       { text: "STEB 135 Plus", iconCls:'xty_epobProductVariant',leaf: true },
                                       { text: "STEB 70 Quick", iconCls:'xty_epobProductVariant', leaf: true },
                                       { text: "STEB 80 Quick", iconCls:'xty_epobProductVariant', leaf: true }

                                   ]
                                  }
                              ] 
                             }


                         ] },
                         { text: "Halbstation&auml;re und station&auml;re ger&auml;te", iconCls:'xty_epobProductgroup',   children: [ { text: "A", leaf: true } ] }, 
                         { text: "Zubeh&ouml;r",  iconCls:'xty_epobProductgroup', expanded: true, children: [ { text: "PowerMaxx Akku 50A", leaf: true,  iconCls:'xty_epobProduct', epobId:'PowerMaxx_Akku_50A', epobTypeId:extVia.enums.EpimObjects.PRODUCT.id } ] }, 
                         { text: "Ersatzteile", iconCls:'xty_epobProductgroup', children: [ { text: "A", leaf: true } ] }

                     ] },
                    { text: "Sortiment",iconCls:'xty_epobProductgroup', expanded: false, children: [
                        { text: "book report", leaf: true },
                        { text: "book report6", leaf: true }
                    ] },	                


                    { text: "Spielautomaten",iconCls:'xty_epobHierarchy', expanded: false, children: [ 
                        { text: "Flipper",  expanded: true, children: [ { text: "Kiss", leaf: true }, { text: "Flash Gordon", leaf: true }] }, 
                        { text: "Videospiele", expanded: true, children: [ { text: "Arcade", leaf: true }, { text: "Defender", leaf: true }] }  ,
                        { text: "Konsolen", expanded: true, children: [ { text: "XBox", leaf: true }, { text: "Wii", leaf: true }] }  
                    ] },
                    { text: "Produktkataloge", iconCls:'xty_epobHierarchy',expanded: false, children: [ 
                        { text: "Fr&uuml;hling",  expanded: true, children: [ { text: "A", leaf: true }] }, 
                        { text: "Sommer", expanded: true, children: [ { text: "B", leaf: true }, { text: "C", leaf: true }] }  ,
                        { text: "Herbst", expanded: true, children: [ { text: "C", leaf: true }, { text: "D", leaf: true }] }  
                    ] }
                ]}
        });
        // >>> PROD V4 End (EPIM-7678) <<<

        var elementsStore = Ext.create('Ext.data.TreeStore', {
            model: 'Epob',
            storeId:'elementsTreeStore',
            root: {
                text: extVia.locales.categories, id:'Kategorien', iconCls:'xty_epobCategory',
                expanded: true,
                children: [
                    { text: "ohne Kategorie", id:'ohne Kategorie', iconCls:'xty_epobCategory', children: [
                        { text: "15", leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id}]},


                    { text: "Objekt-Bild",id:'Objekt-Bild', iconCls:'xty_epobCategory',children: [
                        { text: "Aussen", id:'Aussen',iconCls:'xty_epobCategory',children: [
                            { text: "Unterputze",id:'Unterputze',iconCls:'xty_epobCategory',children: [
                                { text: "Fliesen-Verlegesysteme",id:'Fliesen-Verlegesysteme',iconCls:'xty_epobCategory',children: []},
                                { text: "Sanierung/Renovierung/&Ouml;ko",id:'Sanierung/Renovierung/&Ouml;ko',iconCls:'xty_epobCategory',children: []}
                            ]
                            },
                            {text:'WDVS', id:'WDVS',iconCls:'xty_epobCategory',children:[]}


                        ]
                        },
                        { text: "Innen", id:'Innen',iconCls:'xty_epobCategory',children: [
                            { text: "Unterputze",id:'Unterputze',iconCls:'xty_epobCategory',children: []}
                        ]
                        }
                    ]},

                    // >>> PROD V4 Start (EPIM-7678) <<<
                    { text: "Produkt-Bild", id:'Produkt-Bild', iconCls:'xty_epobCategory',expanded:true,children: [

                        { text: "Produktbild",id:'Produktbild', iconCls:'xty_epobCategory',expanded:true,children: []},
                        { text: "Katalog Maschinen und WDVS-Werkzeuge",id:'Katalog Maschinen und WDVS-Werkzeuge', expasnded:true, iconCls:'xty_epobCategory',children: [{text:'DE_WD_Mai Klebepistole WDVS', leaf: true ,iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id}]},

                        { text: "Preisliste/Katalog farbig", id:'Preisliste/Katalog farbig', iconCls:'xty_epobCategory',children: [
                            { text: "Randd&auml;mmstreifen 80 / 10_DE_ES_Verpackungsbild_Produktbild", epobId:'Randd&auml;mmstreifen 80 / 10_DE_ES_Verpackungsbild_Produktbild', leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "PowerMaxx BS Quick mit Winkelvorsatz", epobId: "PowerMaxx_BS_Quick_mit_Winkelvorsatz",leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "PowerMaxx BS Quick Hauptfoto (-)",  epobId: "PowerMaxx_BS_Quick_Hauptfoto",leaf:true,iconCls:'xty_epobImage',  epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "PowerMaxx BS Quick Anwendungsfoto (-)", epobId: "PowerMaxx_BS_Quick_Anwendungsfoto", leaf: true, iconCls:'xty_epobImage',  epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "PowerMaxx Lieferumfang (-)",  epobId: "PowerMaxx_Lieferumfang", leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "Produktbild PowerMaxx (-)",epobId: "Produktbild_PowerMaxx",leaf: true, iconCls:'xty_epobImage',  epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "Anwendungsbild 1 PowerMaxx (-)", epobId: "Anwendungsbild_1_PowerMaxx", leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "Anwendungsbild 2 PowerMaxx (-)", epobId: "Anwendungsbild_2_PowerMaxx", leaf: true, iconCls:'xty_epobImage',  epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "Anwendungsbild 3 PowerMaxx (-)", epobId: "Anwendungsbild_3_PowerMaxx", leaf: true , iconCls:'xty_epobImage', epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "Anwendungsbild 4 PowerMaxx (-)", epobId: "Anwendungsbild_4_PowerMaxx", leaf: true, iconCls:'xty_epobImage',  epobTypeId:extVia.enums.EpimObjects.IMAGE.id},
                            { text: "Produktvideo ACME Power Maxx (-)", epobId: "Produktvideo_ACME_Power_Maxx",leaf:true, iconCls:'xty_epobVideo',  epobTypeId:extVia.enums.EpimObjects.VIDEO.id}
                        ]},
                        { text: "Preisliste sw", id:'Preisliste sw', iconCls:'xty_epobCategory',children: []}


                    ] },
                    { text: "Berechnungen", iconCls:'xty_epobCategory', expanded:true,children: [
                        { text: "15", leaf: true , iconCls:'xty_epobImage'}]} ,
                    { text: "Produktfoto", iconCls:'xty_epobCategory', children: [
                        { text: "15", leaf: true , iconCls:'xty_epobImage'}]} ,	
                    { text: "Produktwissen", iconCls:'xty_epobCategory',  children: [
                        { text: "Bedienungsanleitung kurz ACME Power Maxx (-)", epobId: "Bedienungsanleitung_kurz_ACME_Power_Maxx",leaf: true, iconCls:'xty_epobDocument',  epobTypeId:extVia.enums.EpimObjects.DOCUMENT.id}
                    ]} ,									
                    { text: "Tabellen", iconCls:'xty_epobCategory', children: [
                        { text: "ACME Bestellinformationen", epobId: "ACME_Bestellinformationen", leaf: true, iconCls:'xty_epobProdTable',  epobTypeId:extVia.enums.EpimObjects.PRODUCTTABLE.id},
                        { text: "Tabelle Lieferumfang ",epobId: "Tabelle_Lieferumfang_", leaf: true, iconCls:'xty_epobProdTable',  epobTypeId:extVia.enums.EpimObjects.PRODUCTTABLE.id},
                        { text: "Tabelle Produktvorteile Technik", epobId: "Tabelle_Produktvorteile_Technik", leaf: true, iconCls:'xty_epobProdTable',  epobTypeId:extVia.enums.EpimObjects.PRODUCTTABLE.id}
                    ]} 						

                ]}
        });
        // >>> PROD V4 End (EPIM-7678) <<<

        var collectionsStore = Ext.create('Ext.data.TreeStore', {
            model: 'Epob',
            root: {
                text: 'Collections',
                storeId:'collectionsTreeStore',
                expanded: true,
                children: [
                    { text: "Collections", leaf: true },
                    { text: "Neus", expanded: true, children: [
                        { text: "book report", leaf: true },
                        { text: "alegrbra", leaf: true},
                        { text: "book report1", leaf: true },
                        { text: "alegrbra", leaf: true},
                        { text: "book report2", leaf: true },
                        { text: "alegrbra1", leaf: true},
                        { text: "book report3", leaf: true },
                        { text: "alegrbra2", leaf: true},
                        { text: "book report4", leaf: true },
                        { text: "alegrbra3", leaf: true},
                        { text: "book report5", leaf: true },
                        { text: "alegrbra4", leaf: true},
                        { text: "book report6", leaf: true }
                    ] },
                    { text: "buy lottery tickets", leaf: true }
                ]}
        });
        return{
            productsStore : productsStore,
            elementsStore : elementsStore,
            collectionsStore : collectionsStore
        };
    },




    getEpobDummyData: function(cfg){


        var epobDummyData =[]; 
        var epobType;

        var startIndex  = 0; var stopIndex =25;
        if (cfg){
            startIndex = cfg.startIndex;
            stopIndex =cfg.stopIndex;
        }

        var i;
        for (i =startIndex; i<stopIndex; i++){
            if (extVia.ui.page.strings.epobs.epobTypeIds[i]){
                epobType =   extVia.module.epob.getEpobTypeFromTypeId (	extVia.ui.page.strings.epobs.epobTypeIds[i]);
            }
            else{
                epobType =   extVia.module.epob.getEpobTypeFromTypeId (	extVia.ui.page.strings.epobs.epobTypeIds[2]);
            }


            var typeImg ='<img src="../img/epobs/content/'+epobType.toLowerCase()+'_16.png" width="16px" style="margin-left:4px" />';

            //tags="<b style='background:#F2ED6D'>superhero</b> ";
            var tags="superhero ";
            var path ='root';//  'dieses &raquo; jenes &raquo; selles';

            if (i%5===0){path ='dieses &raquo; sonderbares &raquo; spezialformate &raquo; substitute';tags+=" marvel";}
            else if (i%3===0){path ='ebene 1 &raquo; ebene 2 &raquo; ebene 3';tags+=" media";}
            else if (i%2===0){path ='level 1 &raquo; level 2';tags+=" culture";}


            var epobDummy = {
                mainInstr:'',
                suppInstr:'',
                // {type: 'number', name: 'epobTypeId'},
                epobType: epobType,// {type: 'string', name: 'epobType'},
                // {type: 'string', name: 'epobTypeDscr'},
                epimId:  i*17,
                epobDscr:'epob_'+i,
                parentDscr:'parent_'+i,
                path:path,
                shortcut:'shortcut_'+i,
                description:'_'+i,
                catchwords:'_'+i,
                language:'_'+i,
                tags:'_'+i,
                sortby:'_'+i,
                sortOrderASC:(i%3===0),
                showText:(i%2===0),
                showInNewWindow:true,
                color:'#DDEEF'+i		
            };

            epobDummyData.push(epobDummy);

        }


        return epobDummyData;
    },    




    /**
	     * Provides Dummy Data
	     * @param cfg
	     */
    getMengenDummyData: function(cfg){

        var mengenData =[]; 

        var startIndex  = 0; var stopIndex =25;
        if (cfg){
            startIndex = cfg.startIndex;
            stopIndex =cfg.stopIndex;
        }

        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }


        var statusLen = extVia.stores.statusData.length;
        var statusIx = -1;

        var i;
        for (i =startIndex; i<stopIndex; i++){

            statusIx++;
            if (statusIx>statusLen){
                statusIx = 0;
            }
            var status = extVia.stores.statusData[statusIx];
            if(status) {status = status.value;}


            var epobTypeIx = i % (extVia.ui.page.strings.epobs.epobTypeIds.length);

            var typeId ;
            var type ;
            var typeDscr;

            if (! extVia.ui.page.strings.epobs.epobTypeIds[epobTypeIx]){
                if (i%2===0) {epobTypeIx = 2;} else {epobTypeIx =14;}
            }
            typeId = extVia.ui.page.strings.epobs.epobTypeIds[epobTypeIx];
            type = extVia.module.epob.getEpobTypeFromTypeId (	typeId);
            typeDscr = extVia.module.epob.getEpobTypeDscrFromTypeId (	typeId);	     		

            //	     		if (i%2===0)epobTypeIx = 2; else epobTypeIx =14;
            //     			type = extVia.module.epob.getEpobTypeFromTypeId (	extVia.ui.page.strings.epobs.epobTypeIds[ epobTypeIx]);

            var png='';
            if (typeId<2000){
                png ='content/'+type.toLowerCase()+'_16.png"';
            }
            else if (typeId<3000){
                png ='products/'+type.toLowerCase()+'_16.png"';
            }
            else if (typeId<4000){
                png ='publish/'+type.toLowerCase()+'_16.png"';
            }
            else{
                png ='user/'+type.toLowerCase()+'_16.png"';
            }

            var typeImg ='<img src="../img/epobs/'+png+'" width="16px" style="margin-left:4px" />';
            var image = '<img src="../img/icons/asThumbsAspect.gif" widdth="48px" hedight="32px" style="" />';

            //tags="<b style='background:#F2ED6D'>superhero</b> ";
            var tags="superhero ";
            var path ='root';//  'dieses &raquo; jenes &raquo; selles';

            var progress = 50;
            if (i%5===0){path ='dieses &raquo; sonderbares &raquo; spezialformate &raquo; substitute';tags+=" marvel"; progress = 70;}
            else if (i%3===0){path ='ebene 1 &raquo; ebene 2 &raquo; ebene 3';tags+=" media"; progress = 30;}
            else if (i%2===0){path ='level 1 &raquo; level 2';tags+=" culture"; progress = 20;}

            else if (i%7===0){path ='level 1 &raquo; level 2';tags+=" culture"; progress = 100;}

            //mengenData.push(  { typ: typeImg, image:'<img src="../img/icons/asThumbsAspect.gif" widdth="48px" hedight="32px" style="" />', name:i+type+" "+i, path:path, epimId:i*17, parentId:i*19});
            mengenData.push(   { progress:progress,typ: typeDscr, image:typeImg, name:typeDscr+" "+(i+1), productnumber:getRandomInt(i,10000)+"-"+getRandomInt(0,i), tags:tags,path:path,status:status, epimId:i*17, parentId:i*19, dbIndex:i});
        }
        return mengenData;
    },


    initMengenStore : function(cfg){ 
        var mengenModel = 	Ext.define('Mengen', {
            fields: [{name:'typ'},{name:'progress', type:'number'}, {name: 'image'},{name: 'name'},{name: 'productnumber'},{name: 'tags'},{name: 'path'},{name: 'epimId'},{name: 'status'},{name: 'parentId'},{name:'dbIndex'}],
            extend: 'Ext.data.Model'
        });

        var startIndex  =0; var  stopIndex =10025;

        var mengenStore =   Ext.create('Ext.data.Store', {
            model: mengenModel, //"Mengen",
            autoLoad: true,
            storeId:'mengenStore',
            pageSize:cfg?cfg.pageSize: extVia.stores.mengengridPageSize,

            proxy: {
                type: 'pagingmemory',
                data: extVia.stores.getMengenDummyData({startIndex:startIndex, stopIndex:stopIndex}),
                reader: {
                    type: 'json'
                }
            }
        });
        return mengenStore;	
    },


    initCollectionsStore : function(cfg){

        // Define the model for a Collection
        var modelName = 'Collection';
        var storeId = 'collectionsStore';
        Ext.define('Collection', {
            extend: 'Ext.data.Model',
            fields: [
                {type: 'string', name: 'id'},
                {type: 'string', name: 'name'},
                {type: 'string', name: 'status'} // released, linked, 


            ]
        });

        // The data for all collection
        var data = [

            {"id": "*" , "name":   "Neuen Tabellentyp anlegen,","newEntry":true} , 
            {"id":"01_DEF","name":"Standard"},
            {"id":"123_SA","name":"tabtyp-onlyvalues"},
            {"id":"123_AP","name":"tabtyp-columnwidths-100-50"},
            {"id":"123_CU","name":"tabtyp-columnwidths-xl-s"},
            //{"id":"123_HT","name":"lty_onlyValuesFrom-clmn3"},
            {"id":"123_GOO","name":"tabtyp-onlyvalues-fromcolumn3"},
            {"id":"123_SA","name":"tabtyp-evenodd-rows"},
            {"id":"123_SA","name":"tabtyp-evenodd-columns"}
            //	            {"id":"01_EXP","name":"Exportorder 01"},
            //	            {"id":"02_EXP","name":"Exportorder 02"},
            //	            {"id":"03_EXP","name":"Exportorder 03"}, 
            //	            {"id":"123_AN","name":"android"},
            //	            {"id":"123_IP","name":"iphone"}
        ];

        var store = Ext.create('Ext.data.Store', {
            model: modelName,
            storeId:storeId,
            data: data
        });  

        return store;
    },


    initTagsStore : function(cfg){

        // Define the model for a Tag
        var modelName = 'Tags';
        var storeId = 'tagsStore';
        Ext.define(modelName, {
            extend: 'Ext.data.Model',
            fields: [
                {type: 'string', name: 'shortcut'},
                {type: 'string', name: 'name'},
                {type: 'string', name: 'occurance'},
                {type: 'string', name: 'id'}

            ]
        });

        // The data for all tags
        var data = [
            {"shortcut":"AL","name":"action","occurance":"The Heart of Dixie"},
            {"shortcut":"AK","name":"boys","occurance":"The Land of the Midnight Sun"},
            {"shortcut":"AZ","name":"culture","occurance":"The Grand Canyon State"},
            {"shortcut":"AR","name":"drawing","occurance":"The Natural State"},
            {"shortcut":"CA","name":"fantasy","occurance":"The Golden State"},
            {"shortcut":"CO","name":"media","occurance":"The Mountain State"},
            {"shortcut":"CT","name":"Connecticut","occurance":"The Constitution State"},
            {"shortcut":"DE","name":"power","occurance":"The First State"},
            {"shortcut":"DC","name":"superhero","occurance":"The Nation's Capital"},
            {"shortcut":"FL","name":"work","occurance":"The Sunshine State"},
            {"shortcut":"GA","name":"world","occurance":"The Peach State"},
            {"shortcut":"HI","name":"writing","occurance":"The Aloha State"},
            {"shortcut":"ID","name":"television","occurance":"Famous Potatoes"},
            {"shortcut":"IL","name":"text","occurance":"The Prairie State"},
            {"shortcut":"IN","name":"popular","occurance":"The Hospitality State"},
            {"shortcut":"IA","name":"images","occurance":"The Corn State"},
            {"shortcut":"KS","name":"meaning","occurance":"The Sunflower State"},
            {"shortcut":"KY","name":"narratives","occurance":"The Bluegrass State"},
            {"shortcut":"LA","name":"concerns","occurance":"The Bayou State"},
            {"shortcut":"ME","name":"representation","occurance":"The Pine Tree State"},
            {"shortcut":"MD","name":"identity","occurance":"Chesapeake State"},
            {"shortcut":"MA","name":"literacy","occurance":"The Spirit of America"},
            {"shortcut":"MI","name":"feuer","occurance":"Great Lakes State"},
            {"shortcut":"MN","name":"complex","occurance":"North Star State"},
            {"shortcut":"MS","name":"aesthetic","occurance":"Magnolia State"},
            {"shortcut":"MO","name":"adults","occurance":"Show Me State"},
            {"shortcut":"MT","name":"age","occurance":"Big Sky Country"},
            {"shortcut":"NE","name":"art","occurance":"Beef State"},
            {"shortcut":"NV","name":"audiences","occurance":"Silver State"},
            {"shortcut":"NH","name":"learning","occurance":"Granite State"},
            {"shortcut":"NJ","name":"interest","occurance":"Garden State"},
            {"shortcut":"NM","name":"violence","occurance":"Land of Enchantment"},
            {"shortcut":"NY","name":"settings","occurance":"Empire State"},
            {"shortcut":"NC","name":"social","occurance":"First in Freedom"},
            {"shortcut":"ND","name":"researchersa","occurance":"Peace Garden State"},
            {"shortcut":"OH","name":"understand","occurance":"The Heart of it All"},
            {"shortcut":"OK","name":"weapons","occurance":"Oklahoma is OK"},
            {"shortcut":"OR","name":"fire","occurance":"Pacific Wonderland"},
            {"shortcut":"PA","name":"form","occurance":"Keystone State"},
            {"shortcut":"RI","name":"feelings","occurance":"Ocean State"},
            {"shortcut":"SC","name":"range","occurance":"Nothing Could be Finer"},
            {"shortcut":"SD","name":"picture","occurance":"Great Faces, Great Places"},
            {"shortcut":"TN","name":"plot","occurance":"Volunteer State"},
            {"shortcut":"TX","name":"represent","occurance":"Lone Star State"},
            {"shortcut":"UT","name":"university","occurance":"Salt Lake State"},
            {"shortcut":"VT","name":"different","occurance":"Green Mountain State"},
            {"shortcut":"VA","name":"stories","occurance":"Mother of States"},
            {"shortcut":"WA","name":"used","occurance":"Green Tree State"},
            {"shortcut":"WV","name":"young","occurance":"Mountain State"},
            {"shortcut":"WI","name":"books","occurance":"America's Dairyland"},
            {"shortcut":"WY","name":"genre","occurance":"Like No Place on Earth"}
        ];

        var store = Ext.create('Ext.data.Store', {
            model: modelName,
            storeId:storeId,
            data: data
        });  

        return store;
    },



    initTagsDataview : function(cfg){  

        var imageTpl = new Ext.XTemplate(
            '<tpl for=".">',
            '<div style="margin-bottom: 10px;" class="thumb-wrap">{name}',
            '<br/><span>{occurance}</span>',
            '</div>',
            '</tpl>'
        );

        var view =  Ext.create('Ext.view.View', {
            store: Ext.data.StoreManager.lookup('tagsStore'),
            tpl: imageTpl,
            itemSelector: 'div.thumb-wrap',
            emptyText: 'No images available'
        });

        return view;
    }, 




    initDBViewsStore : function(cfg){
        // Define the model for a databaseview
        var modelName = 'DatabaseViews';
        var storeId = 'dbViewsStore';
        Ext.define(modelName, {
            extend: 'Ext.data.Model',
            fields : [ 'dscr', 'id', 'count', 'checked','isReadonlyView', 'readonly'  ]
        });
        // The data for all DatabaseViews
        // >>> PROD V4 Start (EPIM-7678) <<<
        var data = [ 
            {
                dscr : 'Alle Attribute', id:Ext.id(),
                count : '2377', checked:'true', isReadonlyView:'false',readonly:'false'}, 
            {
                dscr : 'Test View',  id:Ext.id(),
                count : '17', isReadonlyView:'false',readonly:'true'
            }, {
                dscr : 'Attribute',  id:Ext.id(),
                count : '188', checked:true, isReadonlyView:'false',readonly:'true'
            }, {
                dscr : 'Alle', id:Ext.id(),
                count : '474', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Preisliste', id:Ext.id(),
                count : '177', isReadonlyView:'true',readonly:'true'
            }, {
                dscr : 'DOP1', id:Ext.id(),
                count : '677', isReadonlyView:'true',readonly:'true'
            }, {
                dscr : 'Systemfinder', id:Ext.id(),
                count : '177', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Preisliste', id:Ext.id(),
                count : '188', checked:'true',isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Baufachbuch', id:Ext.id(),
                count : '177', checked:'true', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : "Total Longer Name Collection AttributeCollection", id:Ext.id(),
                count : '237',checked:'true', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'DE Produkt&uuml;bersicht', id:Ext.id(),
                count : '177', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Preisliste 2', id:Ext.id(),
                count : '488', checked:'true',isReadonlyView:'false',readonly:'true'
            }, {
                dscr : 'TM', id:Ext.id(),
                count : '1773', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'TM Attribute', id:Ext.id(),
                count : '173', checked:'true',isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Produktattribute_Piktogramme', id:Ext.id(),
                count : '657', checked:'true',isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Aufnahme-Anlageblatt', id:Ext.id(),
                count : '177', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'Sicherheitsdatenblatt', id:Ext.id(),
                count : '279', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'AutoTestView', id:Ext.id(),
                count : '188', isReadonlyView:'false',readonly:'false'
            }, {
                dscr : 'CE-Kennzeichnung', id:Ext.id(),
                count : '779', isReadonlyView:'false',readonly:'false'
            } 
        ];
        // >>> PROD V4 End (EPIM-7678) <<<
        var store = Ext.create('Ext.data.Store', {
            model: modelName,
            storeId:storeId,
            data: data
        });  
        return store;
    },


    /**
	     *  Copied  01.03.2013 from ext.Via.extVia.ui.cmp.factory.component.js
	     * Calls {@link extVia.ui.cmp.factory.component#inputTextautoCompleteInsert}
	     * onENTER?
	     * 
	     * @param {} target
	     * @param {} e
	     */
    inputTextautoCompleteInsertonEnter: function(target, e){
        if((e.getCharCode()   === Ext.EventObject.ENTER)){// ENTER
            this.autoCompleteInsert();
            //	            var task = new Ext.util.DelayedTask(function(){
            //	              extVia.regApp.submit();
            //	            });
            //	            task.delay(100);
        }
    },


    /**
	     * Copied  01.03.2013 from ext.Via.extVia.ui.cmp.factory.component.js
	     * @param {} target
	     * @param {} e
	     */
    inputTextautoCompleteInsert: function(target, e){
        this.store.clearFilter(true);
        var insert = this.getRawValue();

        var TopicRecord = Ext.ModelManager.getModel('QuickSearchField');
        var myNewRecord = new TopicRecord({
            value: this.getRawValue(),
            dscr: this.getRawValue()
        });

        var i;
        if(this.store.findBy(function(record){
            var totalCount = this.getCount();
            var records = this.getRange();
            for(i = 0; i < totalCount; i++){
                if(records[i].get('dscr')   === insert){
                    return true;
                }
            }
            return false;
        })){
            var store = this.store;
            store.suspendEvents();
            store.add(myNewRecord);
            store.sort('dscr', "ASC");
            store.resumeEvents();
        }


        var totalCount = this.store.getCount();
        var records = this.store.getRange();
        var searchCookie = '[';

        for(i = 0; i < totalCount; i++){
            if(i > 0){
                searchCookie = searchCookie + ',';
            }
            var v = records[i].get('dscr');
            var d = records[i].get('dscr');
            searchCookie = searchCookie + '[\"' + v + '\",\"' + d + '\"]';
        }
        searchCookie = searchCookie + ']';

        document.cookie = this.name + "=" + escape(searchCookie);
    },



    getProcessStateStore : function(cfg){ 
        var store = Ext.data.StoreManager.lookup('ProcessStateStore');
        if (!store){
            var model = Ext.define('ProcessState', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'value'},{type: 'string', name: 'dscr'},{type: 'string', name: 'id'}] });
            var data = [ 
                {value: 'RUNNING', dscr: 'laufend',id: '0'} , 
                {value: 'FINISHED',dscr: 'beendet',id: '10'} , 
                {value: 'FINISHED_SUCCESS', dscr: 'beendet mit Erfolg',id: '1'}  ,
                {value: 'FINISHED_ERROR', dscr: 'beendet mit Fehler',id: '2'}  ,
                {value: 'FINISHED_WARNING', dscr: 'beendet mit Warnung',id: '2'}  ,
                {value: 'ABORTED', dscr: 'Abgebrochen',id: '3'}  ,
                {value: 'STOPPED', dscr: 'Gestoppt',id: '12'}  ,
                {value: 'PAUSED', dscr: 'Pausiert',id: '13'}  ,
                {value: 'LOCKED', dscr: 'Gesperrt',id: '14'}  ,
                {value: 'TIMEOUT', dscr: 'Zeit&uuml;berschreitung',id: '4'},  
                {value: 'FAILED', dscr: 'Fehlgeschlagen',id: '5'} 
            ];
            store = Ext.create('Ext.data.Store', { storeId:'ProcessStateStore', model: model,data: data});  
        }
        return store;	
    },



    getSearchareaStore : function(cfg){ 
        var store = Ext.data.StoreManager.lookup('SearchareaStore');
        if (!store){
            var model = Ext.define('Searcharea', {extend: 'Ext.data.Model', fields: [{type: 'number', name: 'value'},{type: 'string', name: 'key'},{type: 'string', name: 'dscr'}] });

            var data = [];
            data.push({value: extVia.module.epob.ALL ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ALL +"_P"]} );
            if (!cfg.searchareaProductsOFF){

                data.push({value: extVia.module.epob.PRODUCT , key: extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"] , dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCT +"_P"]} ); 
                data.push({value:  extVia.module.epob.PRODUCTVARIANT ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTVARIANT +"_P"]} );
                data.push({value:  extVia.module.epob.PRODUCTANDVARIANT ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTANDVARIANT +"_P"]} );	                     
                data.push({value:  extVia.module.epob.HIERARCHY ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.HIERARCHY +"_P"]} ); 
                data.push({value:  extVia.module.epob.PRODUCTGROUP ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTGROUP +"_P"]} ); 
                data.push({value:  extVia.module.epob.MYPRODUCT ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYPRODUCT +"_P"]} );
            }            
            //data.push({value: -1 ,  dscr:  ""} ); 

            data.push({value:  extVia.module.epob.ELEMENTS ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"]} ); 
            data.push({value:  extVia.module.epob.IMAGE ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"]} ); 
            data.push({value:  extVia.module.epob.AUDIO ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"]} ); 
            data.push({value:  extVia.module.epob.VIDEO ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"]} ); 
            data.push({value:  extVia.module.epob.GRAPHIC ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"]} ); 
            data.push({value:  extVia.module.epob.DOCUMENT ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"]} ); 


            store = Ext.create('Ext.data.Store', { storeId:'SearchareaStore', model: model,data: data});  
        }
        return store;	
    },


    getDistributionAssetTypesStore : function(cfg){ 
        var store; // = Ext.data.StoreManager.lookup('distributionAssetTypesStore');
        if (!store){
            var model = Ext.define('distributionAssetType', {extend: 'Ext.data.Model', 
                                                             fields: [
                                                                 {type: 'string', name: 'assetType'},
                                                                 {type: 'string', name: 'dscr'},
                                                                 {type: 'string', name: 'syncType'},
                                                                 {type: 'string', name: 'nextSync'},
                                                                 {type: 'string', name: 'status'},
                                                                 {type: 'string', name: 'schedulingSummary'}
                                                             ] 
                                                            });


            var statusCnt =0;


            var nextSync =  function (){
                var nxtsy = 'heute 18:30'; 
                if (statusCnt%3===0){nxtsy='in 4 Minuten';}
                if (statusCnt%5===0){nxtsy='morgen 10:30';}
                if (statusCnt%7===0){nxtsy='06.06.1666 6:66';}
                if (statusCnt%7===0){nxtsy='in 1 Stunde';}
                statusCnt++;
                return nxtsy; 
            };  



            var status =  function (){
                var stat = 'Unknown'; 
                if (statusCnt%3===0){stat='Success';}
                if (statusCnt%5===0){stat='Uploading';}
                if (statusCnt%7===0){stat='Waiting';}
                if (statusCnt%9===0){stat='Error';}
                if (statusCnt%11===0){stat='Deprecated';}
                statusCnt++;
                return stat; 
            };

            var data = [];
            //data.push({value: extVia.module.epob.ALL ,  dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ALL +"_P"]} );

            //see jira  #1686
            data.push({SYNC_ASSETTYPES_ID: 1, dscr: 'CSVImportFile', assetType:'File',  progress:3, syncType:'sofort', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 9, dscr: 'CustomerSpecificProfile', assetType:'Profile',  progress:12, syncType:'geplant', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 1, dscr: 'CustomerXSLTScript', assetType:'File',  progress:10, syncType:'geplant', nextSync: nextSync(), status: status() });           
            data.push({SYNC_ASSETTYPES_ID: 1, dscr: 'CustomJSfunction', assetType:'File',  progress:2, syncType:'sofort', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 4, dscr: 'CustomResource', assetType:'Resource',  progress:3, syncType:'sofort', nextSync: nextSync(), status: status() });

            data.push({SYNC_ASSETTYPES_ID: 3, dscr: 'DictionaryFormulaImage', assetType:'Image',  progress:3, syncType:'geplant', nextSync: nextSync(), status: status() });           
            data.push({SYNC_ASSETTYPES_ID: 1, dscr: 'ElementFile', assetType:"File", progress:3, syncType:'sofort', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 1, dscr: 'ElementPreviewsFile', assetType:'File',  progress:30, syncType:'geplant', nextSync: nextSync(), status: status() });

            data.push({SYNC_ASSETTYPES_ID: 5, dscr: 'PreviewXSLTTemplate', assetType:'XML',  progress:100, syncType:'sofort', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 5, dscr: 'ProductPreviewXMLExport', assetType:'XML',  progress:300, syncType:'geplant', nextSync: nextSync(), status: status() });

            data.push({SYNC_ASSETTYPES_ID: 9, dscr: 'WebServiceExportSettingsProfile', assetType:'Profile',  progress:13, syncType:'geplant', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 6, dscr: 'XMLExport', assetType:'Folder',  progress:17, syncType:'geplant', nextSync: nextSync(), status: status() });
            data.push({SYNC_ASSETTYPES_ID: 5, dscr: 'XMLImportFile', assetType:'XML',  progress:100, syncType:'geplant', nextSync: nextSync(), status: status() });           


            //			data.push({dscr:"Custom viaResource entries ", assetType:'Resource' , syncType:'sofort'   , status:status(), nextSync: nextSync(), status: status(),   progress:100, scheduling:'Start: ' }  );
            //			data.push({dscr:"Element previews ", assetType:'File' ,syncType:'sofort' , status:status(), nextSync: nextSync(), status: status(),   progress:10});
            //			data.push({dscr:"Formula  images ", assetType:'Images',syncType:'sofort' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			data.push({dscr:"Custom JS-Functions", assetType:'Script',syncType:'nightly' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			data.push({dscr:"Preview XSLTs", assetType:'XML',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			data.push({dscr:"Preview Templates ", assetType:'XML',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			
            //			data.push({dscr:"EPIMFS/produktion directory", assetType:'Folder',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:10} );
            //			data.push({dscr:"CSV-Imports ", assetType:'',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			data.push({dscr:"XML-Imports ", assetType:'',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			data.push({dscr:"Export markupgroup XSLT", assetType:'',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:60} );
            //			data.push({dscr:"Export markupgroup batchjobs", assetType:'Script',syncType:'keine' , status:status(), nextSync: nextSync(), status: status(),   progress:10} );
            //			data.push({dscr:"WebService-ExportSettings profile", assetType:'',syncType:'sofort' , status:status(), nextSync: nextSync(), status: status(),   progress:80} );
            //			data.push({dscr:"Support datacheck", assetType:'',syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );
            //			data.push({dscr:"Exportfolders", assetType:'Folder',syncType:'sofort' , status:status(), nextSync: nextSync(), status: status(),   progress:50} );
            //
            //            data.push({dscr:"Element files ",syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:100} );   
            //            data.push({value:  extVia.module.epob.ELEMENTS , assetType:'File', dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"],syncType:'sofort' , status:status(), nextSync: nextSync(), status: status(),   progress:23} ); 
            //            data.push({value:  extVia.module.epob.IMAGE , assetType:'File', dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"],syncType:'sofort' , status:status(), nextSync: nextSync(), status: status(),   progress:100} ); 
            //            data.push({value:  extVia.module.epob.AUDIO , assetType:'File', dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:65} ); 
            //            data.push({value:  extVia.module.epob.VIDEO , assetType:'File', dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],syncType:'geplant' , status:status(), nextSync: nextSync(), status: status(),   progress:70} ); 
            //            data.push({value:  extVia.module.epob.GRAPHIC , assetType:'File', dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],syncType:'keine' , status:status(), nextSync: nextSync(), status: status(),   progress:100} ); 
            //            data.push({value:  extVia.module.epob.DOCUMENT , assetType:'File', dscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"],syncType:'keine' , status:status(), nextSync: nextSync(), status: status(),   progress:55} ); 
            //               

            if (cfg.rowsCount) { 
                data = data.slice(0, cfg.rowsCount); 
            }

            store = Ext.create('Ext.data.Store', { storeId:'distributionAssetTypesStore', model: model,data: data});  
        }
        return store; 
    },


    getPlannerStore : function(cfg){ 
        var store;
        if (!store){
            var model = Ext.define('Planning', {extend: 'Ext.data.Model', 
                                                fields: [{type: 'string', name: 'plannerType'},{type: 'string', name: 'dscr'},{type: 'string', name: 'duration'}, {type: 'string', name: 'start'}, {type: 'string', name: 'startTime'},  {type: 'string', name: 'syncType'},{type: 'string', name: 'nextRun'},{type: 'string', name: 'lastRun'}] });

            var startTime='08:30';
            var start = 0;
            var duration = 0; 

            var statusCnt = 0;
            var nextRun =  function (){
                var nxtRu = 'heute 18:30'; 
                if (statusCnt%3===0){
                    nxtRu='in 4 Minuten';
                }
                if (statusCnt%5===0){
                    nxtRu='morgen 10:30';
                    startTime='10:30';
                    start=10.5;
                }
                if (statusCnt%7===0){
                    nxtRu='06.12.2017 6:66';
                    startTime='06:30';
                    start=6.5;
                }
                if (statusCnt%7===0){
                    nxtRu='in 1 Stunde';
                    startTime='12:30';
                    start=1.5;
                }
                statusCnt++;
                return nxtRu; 
            }; 



            var lastRun =  function (){

                var lastR = 'heute 18:30'; 
                if (statusCnt%3===0){
                    lastR='heute<br> vor 4 Minuten';
                }
                if (statusCnt%5===0){
                    lastR='gestern 10:30';

                }
                if (statusCnt%7===0){
                    lastR='06.06.1666 6:66';

                }
                if (statusCnt%7===0){
                    lastR='heute<br> vor 1 Stunde';

                }
                // statusCnt++;



                return lastR;
            };


            var status =  function (){
                var stat = 'Unknown'; 
                if (statusCnt%3===0){stat='Success';}
                if (statusCnt%5===0){stat='Uploading';}
                if (statusCnt%7===0){stat='Waiting';}
                if (statusCnt%9===0){stat='Error';}
                if (statusCnt%11===0){stat='Deprecated';}
                statusCnt++;
                return stat; 
            };
            var blockCnt = 1;
            var cnt = 0;
            var county = function(){
                cnt++;
                if (cnt>13){blockCnt++; cnt = 0; }
                return blockCnt;
            };


            var data = [];

            data.push({ dscr: 'CSVImportFile', plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile', plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript', plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction', plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource', plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage', plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile', plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile', plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate', plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport', plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile', plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport', plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile', plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           


            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           

            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           

            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           

            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           

            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           

            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           

            data.push({ dscr: 'CSVImportFile '+county(), plannerType:'CSV',  progress:13, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 0, duration: 2 });
            data.push({ dscr: 'CustomerSpecificProfile '+county(), plannerType:'CSV-event',  progress:12, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 2, duration: 3 });
            data.push({ dscr: 'CustomerXSLTScript '+county(), plannerType:'CSV',  progress:10, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1.0 });           
            data.push({ dscr: 'CustomJSfunction '+county(), plannerType:'XML-event',  progress:20, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 22 });
            data.push({ dscr: 'CustomResource '+county(), plannerType:'XML',  progress:30, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'DictionaryFormulaImage '+county(), plannerType:'CSV-event',  progress:3, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 12, duration: 9 });           
            data.push({ dscr: 'ElementFile '+county(), plannerType:"CSV", progress:3, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 10 });
            data.push({ dscr: 'ElementPreviewsFile '+county(), plannerType:'CSV-once',  progress:30, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 14 });
            data.push({ dscr: 'PreviewXSLTTemplate '+county(), plannerType:'XML',  progress:100, syncType:'sofort', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 1 });
            data.push({ dscr: 'ProductPreviewXMLExport '+county(), plannerType:'XML-once',  progress:90, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 4, duration: 2 }); 
            data.push({ dscr: 'WebServiceExportSettingsProfile '+county(), plannerType:'CSV',  progress:13, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: start, duration: 3.5 });
            data.push({ dscr: 'XMLExport '+county(), plannerType:'XML',  progress:17, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 20, duration: 10 });
            data.push({ dscr: 'XMLImportFile '+county(), plannerType:'XML-once',  progress:100, syncType:'geplant', nextRun: nextRun(), lastRun: lastRun(), status: status(), startTime: startTime, start: 16, duration: 4 });           



            if (cfg.rowsCount) { 
                data = data.slice(0, cfg.rowsCount); 
            }

            store = Ext.create('Ext.data.Store', { storeId:'distributionAssetTypesStore', model: model,data: data});  
        }
        return store; 
    },    


    getDistributionsStore : function(cfg){ 
        var store = Ext.data.StoreManager.lookup('distributionsStore');
        if (!store){
            var model = Ext.define('distributions', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'name'},{type: 'string', name: 'status'},{type: 'string', name: 'ip'}, {type:'boolean', name :'usersplace'}, {type:'string',name:'geolocation'} ] });

            // >>> PROD V4 Start (EPIM-7678) <<<
            var data = [
                {name:'Karlsruhe', status:'Success',  ip:'192.0.2.1', progress:80, geolocation:'49.0113, 8.40248'},
                {name:'Ettlingen', status:'Success', usersplace:true, ip:'192.0.2.2', progress:99, geolocation:'48.94502, 8.38163'},
                {name:'Kassel', status:'Loading', ip:'xxx.yyy.zzz.vvv', progress:70, geolocation:'51.3149724,9.3904039,12' },
                {name:'Brussel', status:'Waiting', ip:'xxx.yyy.zzz.vvv' , progress:10, geolocation:'50.8550624,4.3051789'},
                {name:'Walldorf', status:'Error', ip:'xxx.yyy.zzz.vvv', timegap:'8h', geolocation:'49.2986116,8.6307386'}
            ];
            // >>> PROD V4 End (EPIM-7678) <<<

            store = Ext.create('Ext.data.Store', { storeId:'distributionsStore', model: model,data: data});  
        }
        return store; 
    },    


    getTimezonesStore : function(cfg){ 

        // http://www.timeanddate.com/time/map/#!cities=141  
        //  http://www.timeanddate.com/time/zones/

        var store = Ext.data.StoreManager.lookup('timezonesStore');
        if (!store){
            var model = Ext.define('timezone', {extend: 'Ext.data.Model', fields: [{type: 'string', name: 'offset'},{type: 'string', name: 'name'},{type: 'string', name: 'shorty '}, {type:'string',name:'geolocation'}, {type:'string',name:'cities'}  ] });

            var data = [

                {offset:'UTC', name:'', geolocation: '', cities: ''},
                {shorty:'WESZ', offset:'UTC + 1:00', name:'Westeurop&auml;ische Sommerzeit', geolocation: '', cities: 'Lissabon'},
                {shorty:'', offset:'UTC + 1:00', name:'Mitteleurop&auml;ische Zeit', geolocation: '', cities: 'Berlin, Paris'},
                {offset:'UTC + 2:00', name:'Mitteleurop&auml;ische Sommerzeit', geolocation: '', cities: 'Berlin, Paris'},
                {offset:'UTC + 2:00', name:'South Africa Standard Time', geolocation: '', cities: 'Kapstadt'},
                {offset:'UTC + 3:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC + 4:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC + 5:00', name:'', geolocation: '', cities: ''},

                {offset:'UTC + 5:30', name:'Indian Standard Time', geolocation: '', cities: ''},


                {offset:'UTC + 6:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC + 7:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC + 8:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC + 9:00', name:'Japan Time Zone', geolocation: '', cities: 'Tokio'},
                {offset:'UTC + 10:00', name:'', geolocation: '', cities: ''}, 
                {offset:'UTC + 11:00', name:'', geolocation: '', cities: ''}, 
                {offset:'UTC + 12:00', name:'', geolocation: '', cities: ''},      
                {offset:'UTC - 12:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 11:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 10:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 9:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 8:00', name:'Pazifische Zeitzone', geolocation: '', cities: 'Los Angeles'},
                {offset:'UTC - 7:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 6:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 5:00', name:'', geolocation: '', cities: 'New York'},
                {offset:'UTC - 4:00', name:'', geolocation: '', cities: ''},
                {offset:'UTC - 3:00', name:'', geolocation: '', cities: 'Rio de Janeiro'}, 
                {offset:'UTC - 2:00', name:'', geolocation: '', cities: ''}, 
                {offset:'UTC - 1:00', name:'', geolocation: '', cities: ''}       
            ];

            store = Ext.create('Ext.data.Store', { storeId:'timezonesStore', model: model,data: data});  
        }
        return store; 
    },  




    getCategoriesStore : function(cfg){ 
        return extVia.stores.getHierachiesStore(cfg);
    },


    getHierachiesStore : function(cfg){ 
        // Define the model for a State
        Ext.define('Hierarchies', {
            extend: 'Ext.data.Model',
            fields: [
                {type: 'string', name: 'path'},
                {type: 'string', name: 'name'},
                {type: 'string', name: 'slogan'}
            ]
        });


        var hierarchies = [
            {"path":"AL","name":"Nahrungsmittel","slogan":""},

            {"path":"AK1","name":"Durlach","slogan":""},
            {"path":"AK2","name":"S&uuml;dsatdt","slogan":""},
            {"path":"AK3","name":"Weststadt","slogan":""},
            {"path":"AK4","name":"Nordweststadt","slogan":""},
            {"path":"AK5","name":"Gr&uuml;nwinkel","slogan":""},
            {"path":"AK6","name":"Innestadt","slogan":""},
            {"path":"AK7","name":"Bulach","slogan":""},
            {"path":"AK8","name":"Ettlingen","slogan":""},


            {"path":"AK","name":"Nahrungsmittel » Obst","slogan":""},
            {"path":"AZ","name":"Nahrungsmittel » Gem&uuml;se","slogan":""},
            {"path":"AR","name":"Nahrungsmittel » Fleisch","slogan":""},
            {"path":"AK1","name":"Nahrungsmittel » Obst » Bio","slogan":""},
            {"path":"AZ2","name":"Nahrungsmittel » Gem&uuml;se » Bio","slogan":""},
            {"path":"AR3","name":"Nahrungsmittel » Fleisch » Bio","slogan":""},
            {"path":"AR4","name":"Nahrungsmittel » Fleisch » Bio » Futtermittel","slogan":""},
            {"path":"AR5","name":"Nahrungsmittel » Fleisch » Bio » K&auml;fighaltung","slogan":""},
            {"path":"AR6","name":"Nahrungsmittel » Fleisch » Bio » Freilaufend","slogan":""},

            {"path":"KL_1","name":"Kleidung","slogan":""},
            {"path":"KL_2","name":"Kleidung » Damen","slogan":""},
            {"path":"KL_3","name":"Kleidung » Herren","slogan":""},
            {"path":"KL_4","name":"Kleidung » Kinder","slogan":""},
            {"path":"KL_5","name":"Kleidung » Kinder » Jungen","slogan":""},
            {"path":"KL_6","name":"Kleidung » Kinder » M&auml;dchen","slogan":""},

            {"path":"SCH_1","name":"Schuhe","slogan":""},
            {"path":"SCH_D","name":"Schuhe » Damen"},


            {"path":"SCH_D1","name":"Schuhe » Damen » Stiefeletten"},
            {"path":"SCH_D2","name":"Schuhe » Damen » Stiefeletten » klassische Stiefeletten"},
            {"path":"SCH_D3","name":"Schuhe » Damen » Stiefeletten » Schn&uuml;rstiefeletten"},
            {"path":"SCH_D4","name":"Schuhe » Damen » Stiefeletten » Cowboy- Bikerstiefeletten"},
            {"path":"SCH_D5","name":"Schuhe » Damen » Stiefel"},
            {"path":"SCH_D6","name":"Schuhe » Damen » Stiefel » klassische Stiefel"},
            {"path":"SCH_D7","name":"Schuhe » Damen » Stiefel » Cowboy- Bikerboots"},
            {"path":"SCH_D8","name":"Schuhe » Damen » Stiefel » Snowboots"},
            {"path":"SCH_D9","name":"Schuhe » Damen » Stiefel » Overknees"},
            {"path":"SCH_D10","name":"Schuhe » Damen » Stiefel » Schn&uuml;rstiefel"},
            {"path":"SCH_D11","name":"Schuhe » Damen » Stiefel » Keilstiefel"},	
            {"path":"SCH_D12","name":"Schuhe » Damen » Stiefel » Plateaustiefel"},	
            {"path":"SCH_D13","name":"Schuhe » Damen » Stiefel » Gummistiefel"},			
            {"path":"SCH_D14","name":"Schuhe » Damen » Pumps"},
            {"path":"SCH_D15","name":"Schuhe » Damen » Sneaker"},		
            {"path":"SCH_D16","name":"Schuhe » Damen » Ballerinas"},
            {"path":"SCH_D17","name":"Schuhe » Damen » Schn&uuml;rschuhe"},		
            {"path":"SCH_D18","name":"Schuhe » Damen » Halbschuhe"},
            {"path":"SCH_D18a","name":"Schuhe » Damen » Halbschuhe » Slipper"},
            {"path":"SCH_D18b","name":"Schuhe » Damen » Halbschuhe » Mokassins"},
            {"path":"SCH_D18c","name":"Schuhe » Damen » Halbschuhe » Espadrilles"},
            {"path":"SCH_D19","name":"Schuhe » Damen » High Heels"},	
            {"path":"SCH_D20","name":"Schuhe » Damen » Sandaletten"},		
            {"path":"SCH_D21","name":"Schuhe » Damen » Pantoletten"},
            {"path":"SCH_D21a","name":"Schuhe » Damen » Pantoletten » klassische Pantoletten"},
            {"path":"SCH_D21b","name":"Schuhe » Damen » Pantoletten » Clogs"},
            {"path":"SCH_D22","name":"Schuhe » Damen » Outdoor"},
            {"path":"SCH_D23","name":"Schuhe » Damen » Hausschuhe"},
            {"path":"SCH_D24","name":"Schuhe » Damen » Badschuhe"},

            {"path":"SCH_3","name":"Schuhe » Herren","slogan":""},
            {"path":"SCH_4","name":"Schuhe » Kinder","slogan":""},
            {"path":"SCH_5","name":"Schuhe » Kinder » Jungen","slogan":""},
            {"path":"SCH_6","name":"Schuhe » Kinder » M&auml;dchen","slogan":""},

            {"path":"SONDER_1","name":"Dollar » $$$$ money","slogan":""},
            {"path":"SONDER_1","name":"Dollar » four","slogan":""},

            {"path":"SONDER_X","name":"* $ +  $ . {[^]} ? ","slogan":""},
            {"path":"SONDER_dreFr","name":"Die drei ?","slogan":""},
            {"path":"SONDER_dreFrs","name":"Die drei ??? Fragezeichen","slogan":""},

            {"path":"FAVS_0","name":"Stars »  zero 0","slogan":""},
            {"path":"FAVS_1","name":"Stars » * » one 1","slogan":""},
            {"path":"FAVS_2","name":"Stars » ** » two 2","slogan":""},
            {"path":"FAVS_3","name":"Stars » *** » three 3","slogan":""},
            {"path":"FAVS_4","name":"Stars » **** » four 4","slogan":""},
            {"path":"FAVS_5","name":"Stars » ***** » five 5","slogan":""},

            {"path":"FAVS_0+","name":"Stars »  zero 0","slogan":""},
            {"path":"FAVS_1+","name":"Stars » + » one 1","slogan":""},
            {"path":"FAVS_2+","name":"Stars » ++ » two 2","slogan":""},
            {"path":"FAVS_3+","name":"Stars » +++ » three 3","slogan":""},
            {"path":"FAVS_4+","name":"Stars » ++++ » four 4","slogan":""},
            {"path":"FAVS_5+","name":"Stars » +++++ » five 5","slogan":""}

        ];




        var hierarchiesStore = Ext.create('Ext.data.Store', {
            model: 'Hierarchies',
            data: hierarchies,
            filterMode:'dbWildcard'
        });


        extVia.currentRawValue = "";


        // try 2 use Ext.Fumnction:   interceptBefore( Object object, String methodName, Function fn ) : Function
        // ??? Ext.Fumnction.interceptBefore( statesStore, filter, Function fn )???

        hierarchiesStore.filter =  function(filters, value) {

            ////// start of interceptBefore ////////
            extVia.currentRawValue = value;// workaround

            switch (this.filterMode) {
                case "dbWildcard": 
                    value= value.replace(/\*/g,".*");
                    value =  new RegExp(value);    
                    break;
                default:
                    break;
            }
            ////// end of interceptBefore ////////


            if (Ext.isString(filters)) {
                filters = {
                    property: filters,
                    value: value
                };
            }

            var me = this,
                decoded = me.decodeFilters(filters),
                i = 0,
                doLocalSort = me.sortOnFilter && !me.remoteSort,
                length = decoded.length;

            for (; i < length; i++) {
                me.filters.replace(decoded[i]);
            }

            if (me.remoteFilter) {
                //the load function will pick up the new filters and request the filtered data from the proxy
                me.load();
            } else {
                /**
	                 * A pristine (unfiltered) collection of the records in this store. This is used to reinstate
	                 * records when a filter is removed or changed
	                 * @property snapshot
	                 * @type Ext.util.MixedCollection
	                 */
                if (me.filters.getCount()) {
                    me.snapshot = me.snapshot || me.data.clone();
                    me.data = me.data.filter(me.filters.items);

                    if (doLocalSort) {
                        me.sort();
                    }
                    // fire datachanged event if it hasn't already been fired by doSort
                    if (!doLocalSort || me.sorters.length < 1) {
                        me.fireEvent('datachanged', me);
                    }
                }
            }
        };



        return hierarchiesStore;

    }



};


extVia.stores = new extVia.stores();


/*
 * 
 * $Revision: 1.158.2.19 $
 * $Modtime: 05.02.13 9:56 $ 
 * $Date: 2019/12/11 15:00:45 $
 * $Author: lowen $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 