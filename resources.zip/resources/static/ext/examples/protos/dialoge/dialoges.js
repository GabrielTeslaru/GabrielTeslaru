Ext.namespace('extVia.dialoges');
/**
 * @class extVia.dialoges
 * Delivers models stores and dummy-data
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2019/12/11 15:21:14 $
 *            $Revision: 1.69.6.7 $
 */

extVia.dialoges = function(config){
	

	var tagsStore = extVia.stores.initTagsStore({pageSize:extVia.stores.mengengridPageSize});
	var languageStore = extVia.stores.initLanguageStore({pageSize:extVia.stores.mengengridPageSize});
	
	var availableEpobsStore = extVia.stores.initAvailableEpobsStore({pageSize:extVia.stores.mengengridPageSize});
	var sortbyStore = extVia.stores.initSortbyStore({pageSize:extVia.stores.mengengridPageSize});	
	
	
  Ext.apply(this,config,{    
    id          : "extVia.dialoges",
    name        : "extVia.dialoges"
  });
};
    
extVia.dialoges.prototype = {

  
       closeAllBut: function(notcloseId){ 
        var activeId = Ext.WindowManager.getActive().id;
        Ext.WindowManager.each(
          function(win){
            if (win.id!==activeId){
              win.close();
            }
           } 
        );
       },
  

	   dialogDefaultWidth  : 420 ,
	    
	    getWindowIconCls: function getWindowIconCls(status){return'xty_icon xty_icon' + status; },
	    
	    getLabelSeparator4Required : function getLabelSeparator4Required(){	
	        return ':<span class="xty_requiredStar"> *</span>';
	    },
	    
	    okButtonHandler : function okButtonHandler(button, evt, msg){	
	    	if (!button.executeAction){
	    		msg = ['OK / Speichern / Erstellen'];
	    	}
	    	else {
	    		msg = button.executeAction;
	    	}
	    	
	    	
	    	var formPan = button.up("window").getComponent("myFormPanel");
	    	if (formPan){
	    		window.alert(button.ownerCt.ownerCt.title+"\n FormValues:\n"+Ext.encode(formPan.getForm().getValues()).replace(/,/g ,",\n") ); // do not use getFieldValues !!
	    	}
	    	
	    	
	    	Ext.example.msg('Button Click', '{0} <br><br> execute ['+msg+'] instruction', msg);
	    	button.ownerCt.ownerCt.hide(); 
	    },
	    noButtonHandler : function noButtonHandler(button, evt, msg){	
	    	Ext.example.msg('Button Click', '{0} <br><br> execute the NO-instruction', ['NO']);
	    	button.ownerCt.ownerCt.hide(); 
	    },
	    cancelButtonHandler :function cancelButtonHandler(button, evt){	
	    	var formPan = button.up("window").getComponent("myFormPanel");
	    	if (formPan){
	    		window.alert("cancelButtonHandler dirty "+formPan.getForm().isDirty()); 
	    	}
	    	
	    	button.ownerCt.ownerCt.hide();   
	    },
	    applyButtonHandler : function applyButtonHandler(button, evt, applyMsg){	
	    	Ext.example.msg('Button Click', '{0} <br><br> execute instruction', ['&Uuml;bernehmen']);
	    },
	    resetButtonHandler : function resetButtonHandler(button, evt, applyMsg){	
	    	var formPan = button.up("window").getComponent("myFormPanel");
	    	if (formPan){
	    		formPan.getForm().reset();
	    	}
	    	//Ext.example.msg('Button Click', '{0} <br><br> execute instruction', ['reset']);
	    },
	    
        getInstructionPanel : function getInstructionPanel (cfg){
          return extVia.dialoges.getInstructionPanelCfg(cfg);
        },
	    getInstructionPanelCfg : function getInstructionPanelCfg (cfg){
			   
				// TODO: resourceKeys START
				if ( !extVia.ui.page.strings.newEpobDialog){   
				
				   extVia.ui.page.strings.newEpobDialog={
				 		  mainInstrCreate:"Erstellen Sie ein ",
				 		  mainInstrEdit:"Bearbeiten Sie das ",
				 		  suppInstrSetMetadata : "Legen Sie allgemeine und typspezifische Metadaten fest."
				   };
				   
				   extVia.ui.page.strings.epobs["Epob_"+extVia.module.epob.DASHBOARD_TEMPLATE+"_S"]="Layout-Template";

				   extVia.ui.page.strings.widgetCfgDialog={
				 		  mainInstr:"Konfigurieren Sie Ihren ",
				 		  suppInstr : "Legen Sie das Anzeigeverhalten und Erscheinungsbild fest."
				   };
				   extVia.ui.page.strings.epobs["Epob_"+extVia.module.epob.MENUPOINT+"_S"]="Men&uuml;punkt";
				}   
				// resourceKeys END     

				var    mainInstr = cfg.mainInstr ? cfg.mainInstr : extVia.ui.page.strings.getString(cfg.mainInstrKey);
				
				var    suppInstr ;
				if (cfg.suppInstr || cfg.suppInstrKey){
					suppInstr = cfg.suppInstr ? cfg.suppInstr : extVia.ui.page.strings.getString(cfg.suppInstrKey);
				}
				
				
				   
				if (cfg.epobTypeId){
					mainInstr+=  extVia.ui.page.strings.getEpobTypeDscr(cfg.epobTypeId);
				}
				   
				// REMEMBER: better use XTEMPLATE
				var instructionPanelCfg =   
			  	 {
			         border : false,
			         itemId : 'instructionPanel',
			         
               setMainInstruction:function(instruction){
                 var instructionPanel = this;
                 var mainInstructionPanel = instructionPanel.getComponent('mainInstruction');
                 mainInstructionPanel.getEl().dom.firstChild.innerHTML =   '<div class="xty_dialog-mainInstr">'+instruction +'</div>';
               },
			         setSupplementalInstruction:function(instruction){
			           var instructionPanel = this;
			           var supplementalInstructionPanel = instructionPanel.getComponent('supplementalInstruction');
			           supplementalInstructionPanel.getEl().dom.firstChild.innerHTML =   '<div class="xty_dialog-supplementalInstr">'+instruction+'</div>';
			         },

			         width:'100%',
			         style : cfg.style ? cfg.style :'padding:10px 0px 15px 10px',
			         items : [ {
			           itemId : 'mainInstruction',
			           border : false,
			           style : 'padding:0px 0px 4px 0px',
			           // Better use XTEMPLATE
			           html : '<div class="xty_dialog-mainInstr">'+mainInstr +'</div>'
			         } ]
			       };
				
				
				
				if (suppInstr){
				   instructionPanelCfg.items.push( {
					           itemId : 'supplementalInstruction',
					           hiddsen : true,
					           border : false,
					           // Better use XTEMPLATE
					           html : '<div class="xty_dialog-supplementalInstr">'+suppInstr+'</div>'
					  }	
				   );
				}
				
				return instructionPanelCfg;   
			   },
			   
	    
	    notifyFormEvent : function notifyFormEvent( eventType, eventTypeValueDscr, eventTypeValue, dialogTitle){
	   		Ext.create('widget.uxNotification', {
				title: 'Form Event '+eventType,
				position: 'tr',
				manager: 'instructions',
				cls: 'ux-notification-light',
				iconCls: 'ux-notification-icon-information',
				html:  'Dialog: <i>'+dialogTitle+'</i><br>form is '+eventTypeValueDscr+': '+eventTypeValue,
				autoCloseDelay: 1000,
				slideBackDuration: 500,
				slideInAnimation: 'bounceOut',
				slideBackAnimation: 'easeIn'
			}).show();
	    	
	    },

	    
	    getGalleryView : function getGalleryView(cfg){	
	    	
	    	var imageStore = extVia.stores.initImageStore({epobType:cfg.epobType,pageStart:cfg.pageStart,pageSize:cfg.pageSize});
	    	
	    	
	    	var storeId = "imageStore" + (cfg?cfg.epobType:'');
	    	
	        var  gallery  =
	        	Ext.create('Ext.view.View', {
	                store: storeId,
	                cls:'xty_view-thumbs-bin',
	                tpl: [
	                      '<tpl for=".">',
	                          '<div class="thumb-wrap" id="{name}">',
	                          '<div class="thumb" qtip="{name}" ><img src="../img/{url}" title="{name}"></div>',
	                          //'<span class="x-editable">{shortName}</span>',
	                          '</div>',
	                      '</tpl>'
	                  ],
	                multiSelect: true,
	                heisght: 200,
	                width:400,
	                style:'min-width:400px;',
	                trackOver: true,
	                overItemCls: 'x-item-over',
	                itemSelector: 'div.thumb-wrap',
	                emptyText: 'No images to display',
//	                plugins: [
//	                    Ext.create('Ext.ux.DataView.DragSelector', {}),
//	                    Ext.create('Ext.ux.DataView.LabelEditor', {dataIndex: 'name'})
//	                ],
	                prepareData: function(data) {
	                    Ext.apply(data, {
	                        shortName: Ext.util.Format.ellipsis(data.name, 15),
	                        sizeString: Ext.util.Format.fileSize(data.size),
	                        dateString: Ext.util.Format.date(data.lastmod, "m/d/Y g:i a")
	                    });
	                    return data;
	                },
	                
	                
	            	openUrl :  function openUrl(url, target, targetDscr){
	          		  var result = null;
	          		  window.focus();
	          		  result = window.open(url);
	          		  return result;	
	          		},

	                
	                listeners: {
	                	
	                	itemdblclick:function( dataview, record, item, index, e, eOpts ){
	                	  window.alert("Not implemented! This is a demo only.");
	                	},
	                	
	                    selectionchange: function(dv, nodes ){
	                        var l = nodes.length,
	                            s = l !== 1 ? 's' : '';
	                        this.up('fieldset').setTitle('Produkte (' + l + ' item' + s + ' selected)');
	                    }
	                }
	            });
	        
	        return gallery;
	    }, 
	    
      
      
    getSaveAndUpdateAssignmentsDialog : function getSaveAndUpdateAssignmentsDialog(cfg){     
        var fieldsetsHidden = true;
        var switchConflictContent  = function(){
          window.alert("switchConflictContent");
        };
      
        var dialog = Ext.create('widget.window', {
      
          width: 580,//extVia.dialoges.dialogDefaultWidth,
          x: cfg.x,
          y: cfg.y,

          
          title:'Speichern und Beziehungen aktualisieren',
          iconCls:extVia.dialoges.getWindowIconCls('ErrorValidate'),
          plain: true,
          tools:[{id:'refresh', qtip:'Aktualisieren'}], 
          items : [ {
              border : false,
              minHeight : 300,
              
              itemId:'myFormPanel',
              xtype:'form',

              fieldDefaults : {
               msgTarget : 'side'
              },
              defaults : {
                 style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                 anchor : '100%',
                 labelWidth : 130,
                 width : 350,
                 mssgTarget:'side'
              },
  
              
              items : [ 
                       extVia.dialoges.getInstructionPanel ({
                         mainInstr:'Folgende Hierarchien haben Konflikte mit Attribut <i style="font-weight:normal">myABC</i>.',
                         suppInstr:'L&ouml;sen sie die Konflikte und aktualisieren Sie diese Meldung.'
                       }),
                                   
                         
                     {xtype:'tbspacer', height:4, hidden:fieldsetsHidden}, 
                     { xtype:'displayfield', value:'<b onclick="switchConflictContent">Hierarchien mit Konflikten</b>', hidden:fieldsetsHidden },  
                         
                         
                        {xtype:'tbspacer', height:5, hidden:fieldsetsHidden},  
                        { xtype:'fieldset', title:'<span class="xty_epobHierarchy" style="padding-left:16px;">handgef&uuml;hrte Maschinen</span> [&raquo;]', collapsible : true,collapsdsed:true, hidden:fieldsetsHidden,
                         items:[
                         
                                { width: 420, xtype:'displayfield', value:'<span class="xty_icon xty_iconErrorValidate" style="padding-left:22px;">Die Hierarchiestruktur enth&auml;lt Duplikate.</span> ' },
                                { width: 420, xtype:'displayfield', value:'<span class="xty_icon xty_iconWarning" style="padding-left:22px;">Die aktuelle Vermehrbarkeit ist gr&ouml;sser al die die Sie gew&auml;hlt haben unter Umst&auml;nden k&ouml;nnten Datenverloren gehen</span> ' },
                         
                         
                                { width: 420, xtype:'displayfield', value:'<span class="xty_icon xty_iconError" style="padding-left:22px;">Die folgenden dynamischen Teilattribute sind in der Zielhierarchie nicht zugerordnet.</span> ' },
                                { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbsp<span class="xty_epobString" style="padding-left:16px;">&nbsp;Drehmoment</span> [&raquo;]</li><li>&nbsp;&bull;&nbsp;<span class="xty_epobNumber" style="padding-left:16px;">&nbsp;Schlagzahl </span>[&raquo;]</li></ul>'}
                             
                         ]   
                       },   
                       

                       
                       {xtype:'tbspacer', height:5, hidden:fieldsetsHidden},  
                        { xtype:'fieldset', title:'<span class="xty_epobProductgroup" style="padding-left:16px;">Einzel- und Konstruktionsteile</span> [&raquo;]', collapsible : true,collapsed:true, hidden:fieldsetsHidden,
                         items:[
                         
                                { width: 420, xtype:'displayfield', value:'<span class="xty_icon xty_iconErrorValidate" style="padding-left:22px;">Ung&uuml;ltige Werteeingabe f&uuml;r die Wertebereiche.</span> [&raquo;]' }
  
                         ]   
                       },   
                       
 
                       
                       
                       {xtype:'tbspacer', height:10, hidden:fieldsetsHidden}, 
                       { xtype:'fieldset', title:'<span class="xty_epobProductgroup" style="padding-left:16px;">Rohre</span> [&raquo;]', collapsible : true,collapsed:true, hidden:fieldsetsHidden,
                         items:[
                                {width: 420,  xtype:'displayfield', value:'<span>Die ge&auml;nderten Attribute k&ouml;nnten Seiteneffekte auf folgende Publikationen haben in denen das Produkt bereits verwendet wird.</span> ' },
                                { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbsp;Winterkatalog</li><li>&nbsp;&bull;&nbsp;Herbstflyer</li></ul>'}
                             
                         ]   
                       }, 
                       
                       {xtype:'tbspacer', height:10, hidden:fieldsetsHidden}, 
                       { xtype:'fieldset', title:'<span class="xty_epobHierarchy" style="padding-left:16px;">Marktplatz</span> [&raquo;]', collapsible : true,collapsed:true, hidden:fieldsetsHidden,
                         items:[
                                {width: 420,  xtype:'displayfield', value:'<span>Das Verschieben aus einer Hierarchietypenstruktur ist nicht erlaubt.</span> [&raquo;]' }
                             
                         ]   
                       },                        

                       {xtype:'tbspacer', height:5},
                       
                       
                       
                       {
                          xtype:'grid',
                          id:'conflictsGrid',
                          width:548,
                          margin:'0 10 10 10',

                          hidden: !fieldsetsHidden,
                          
                          
                         getColumnName:function(){                            
                           var columnFieldName = this.features[0].getGroupField();
                           var i;
                           for (i = 0; i < this.columns.length; i++){
                            if (columnFieldName ==  this.columns[i].dataIndex && this.columns[i].headerDscr){
                              columnFieldName = this.columns[i].headerDscr;
                            } 
                           }  
                           return  columnFieldName ;
                          },
                          
                          features: [Ext.create('Ext.grid.feature.Grouping',{
                                //groupHeaderTpl: '{[Ext.getCmp("conflictsGrid").getColumnName()]} : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
                                groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
                            })], 
                          
                          
                          columns:[


                          { header:'Hierarchie', headerDscr:'Hierarchie', dataIndex:'targetEpobDscr', width:220, 
                          
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                
                                var html ='';
                                
                                var lastTargetEpobId = view.lastTargetEpobId;
                                
                                if (lastTargetEpobId && lastTargetEpobId == record.get('targetEpobId')){
                                 var jslintyy = 1;
                                }
                                else{
                                 html = '<div title="'+record.get('targetEpobType')+'" style="height:18px;padding-left:16px;" class="xty_epob'+record.get('targetEpobType')+'"> &nbsp;&nbsp;&nbsp;'+value+'</div>';
                                }
                                view.lastTargetEpobId = record.get('targetEpobId');
                                
                                return html;
                             }
                           
                           },
                          {header:'Status', dataIndex:'status', width:40,
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                return '<div title="'+record.get('status')+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_icon xty_icon'+record.get('status')+'"> &nbsp;&nbsp;&nbsp;</div>';
                            }
                          },
                           { header:'Konflikt',headerDscr:'Konflikt', dataIndex:'conflictDscr', width:320, 
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                var usedItems = record.get('usedItems');
                                var html =   
                                  //'<div title="'+record.get('status')+'" style="height:18px;padding-left:16px;float:left;" class="xty_icon xty_icon'+record.get('status')+'">&nbsp;&nbsp;&nbsp;'+'</div>' +
                                  '<div style="padXXding-left:22px;width:280px;white-space:normal;">'+ (usedItems? usedItems.length+' ' :'' )+   record.get('conflictDscr')+
                                  (usedItems? '<span class="xty_action-assignedattributes" style="cursor:pointer;"> [&raquo;]</span><span class="xty_action-opendetails" style="cursor:pointer;"> [+]</span>':'' )+
                                  '</div>';
                                if (usedItems){
                                  var i;
                                  for (i = 0; i < usedItems.length; i++){
                                    var item = usedItems[i];
                                    html+= '<div id="usedItem_targetId'+record.get('targetEpobId')+'_assignId'+item.epobId+'_'+i+'" title="'+item.epobType+'" style="height:18px;padding-left:32px;background-position:18px 0px;display:block;" class="xty_epob'+item.epobType+'"> &nbsp;&nbsp;&nbsp;'+item.epobDscr+' <span class="xty_action-assignattribute" style="cursor:pointer;" epobid="'+item.epobId+'">[&raquo;]</span></div>';
                                  }
                                }
                                return html;
                            }
                           },                          
                           
                           
                           { header:'Teilattribut', dataIndex:'assignEpobDscr', width:220, hidden:true, headerDscr:'Teilattribut', 
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                return '<div title="'+record.get('assignEpobType')+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+record.get('assignEpobType')+'"> &nbsp;&nbsp;&nbsp;'+value+'</div>';
                            }
                           }

                          ],
                          
                          listeners:{
                           itemclick:function(view , record, item, index, evt, eOpts ){

                            var targetEl = Ext.get(evt.target);
                            
                            var action = evt.target.className.replace('xty_action-','');

                            if (action=='opendetails' || action=='closedetails'){
                                if (action=='opendetails' ){
                                  targetEl.dom.innerHTML ='[-]';
                                  targetEl.removeCls('xty_action-opendetails');
                                  targetEl.addCls('xty_action-closedetails'); 
                                }
                                else{
                                  targetEl.dom.innerHTML ='[+]';
                                  targetEl.removeCls('xty_action-closedetails');                                  
                                  targetEl.addCls('xty_action-opendetails'); 
                                }
    
                                var usedItems = record.get('usedItems');
                                if (usedItems){
                                  var i;
                                  for (i = 0; i < usedItems.length; i++){                                  
                                    var itemx = usedItems[i];
                                    var usedItemElId = 'usedItem_targetId'+record.get('targetEpobId')+'_assignId'+itemx.epobId+'_'+i;
                                    var usedItemEl = Ext.get(usedItemElId);   
                                    if (action=='opendetails' ){ usedItemEl.show();}
                                    else{ usedItemEl.hide();}
                                  } 
                                }  
                            }
 
                           },
                            
                           itemdblclick:function(view , record, item, index, evt, eOpts ){
                             window.alert("Double-click not implemented! This is a demo only.");
                           }
                          },
                          
                          store :  Ext.create('Ext.data.Store', {
                            storeId:'conflictsStore',
                            model: Ext.define('conflicts', {extend: 'Ext.data.Model', 
                             fields: [
                                {type: 'string', name:'targetEpobType'},{type: 'string', name:'targetEpobDscr'},{type: 'string', name: 'targetEpobId'},
                                {type: 'string', name: 'status'}, {type: 'string', name: 'conflictDscr'},
                                
                                {type: 'array', name: 'usedItems'}
                                ]
                            }),
                            data: [
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'sl_Beckensortiment', targetEpobId:'6796', status:'NotAllowed', conflictDscr:'Die aktuelle Vermehrbarkeit ist gr&ouml;sser al die die Sie gew&auml;hlt haben unter Umst&auml;nden k&ouml;nnten Datenverloren gehen', assignEpobType:'', assignEpobId:'', assignEpobDscr:''},
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'sl_Beckensortiment', targetEpobId:'6796', status:'ErrorValidate', conflictDscr:'Ung&uuml;ltige Werteeingabe f&uuml;r die Wertebereiche.', assignEpobType:'', assignEpobId:'', assignEpobDscr:''},
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'sl_Beckensortiment', targetEpobId:'6796', status:'NotAllowed', conflictDscr:' dynamische Teilattribute sind in der Zielhierarchie nicht zugerordnet.', 
                              
                              usedItems:[
                                  {epobType:'Number', epobId:'1058', epobDscr:'L&auml;nge'},
                                  {epobType:'Number', epobId:'1059', epobDscr:'Breite'},
                                  {epobType:'Number', epobId:'1060', epobDscr:'H&ouml;he'},
                                  {epobType:'String', epobId:'1059', epobDscr:'mein Wert'},
                                  {epobType:'Dictionary', epobId:'1059', epobDscr:'mein Wert'}
                                  
                                  
                                  ],
                              
                              assignEpobType:'', assignEpobId:'', assignEpobDscr:''},
                            
                              
                                
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Automarkt', targetEpobId:'431r', status:'NotAllowed', conflictDscr:' Dynamisches Teilattribut ist in der Zielhierarchie nicht zugerordnet.', assignEpobType:'String', assignEpobId:'57731r', assignEpobDscr:'L&auml;nge'},
                              
                              
                              { targetEpobType:'Productgroup' , targetEpobDscr:'Automarkt', targetEpobId:'431r', status:'NotAllowed', conflictDscr:' abc'},
                              { targetEpobType:'Productgroup' , targetEpobDscr:'Fixit Spezialbohrer', targetEpobId:'431sr', status:'OK', conflictDscr:' abc'},
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Bohrmaschinen', targetEpobId:'4316', status:'OK', conflictDscr:' abc'},
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Sortimente', targetEpobId:'6779', status:'OK', conflictDscr:' abc'}

                          ]
                          })

                         }
                       
                       
                       ]
            }
          ],

           buttons:{itemId:'myButtons', items:[
          
             {itemId:'refresh',text:'Meldung aktualisieren', handler:extVia.dialoges.okButtonHandler},// {xtype:'tbspacer', width:30},
             {itemId:'cancel', text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}
           ] }     
      })  ;
        
      return dialog;
      },
      
      
    getMultiAssignmentsConflictDialog : function getMultiAssignmentsConflictDialog(cfg){  
        var fieldsetsHidden = true;
        var switchConflictContent  = function(){
          window.alert("switchConflictContent");
        };
      
        var diaWidth = 780;
        var gridWidth =  diaWidth-42;
        
        var textCellWidth = 220;
        
        
        extVia.dialoges.groupHeaderCheckboxClick= function(element){

          var groupHdRow = Ext.get(element).up('.x-grid-group-hd');
          var groupBody = Ext.get(groupHdRow).dom.nextSibling;  
          var groupBodyId = groupBody.id;  
          


          groupBody =  Ext.get(groupBodyId);    
          groupBody.addCls('xty_grid-group-body-no-collapse'); 

          
          var chckbxArr = Ext.get(groupBody).dom.getElementsByTagName('INPUT');
          var i;
          for(i =0; i <chckbxArr.length; i++){
            var chckbx = chckbxArr[i];
            chckbx.checked=  element.checked;
          }

          var task = new Ext.util.DelayedTask(function(){
             var groupBody =  Ext.get(groupBodyId);  
             groupBody.removeCls('x-grid-group-collapsed');
             groupBody.removeCls('xty_grid-group-body-no-collapse');

          });
          task.delay(20);
          
          if (element.checked){
            groupHdRow.addCls('xty_groupHdRow-selected');
            groupBody.addCls('xty_grid-group-body-selected'); 
          }
          else{ 
            groupHdRow.removeCls('xty_groupHdRow-selected');
            groupBody.removeCls('xty_grid-group-body-selected');
          }
          
          
        };
        
        
        var conflicts = {
          
          
          noConflict:{  status:'Nothing',  dscr:'', solution:'Zuordnungsf&auml;hig'},
          
          multiTooBig:{ status:'Warning',  dscr:'Die aktuelle Vermehrbarkeit ist gr&ouml;sser als die die Sie gew&auml;hlt haben unter Umst&auml;nden k&ouml;nnten Datenverloren gehen', solution:'Vermehrbarkeit anpassen'},

          errorValidate:{  status:'ErrorValidate', dscr:'Ung&uuml;ltige Werteeingabe f&uuml;r die Wertebereiche.', solution:'always challenge the old ways.'},
          
          noDatabase:{  status:'Cancelled',  dscr:'Datenbank abgeraucht.', solution:false},
         
          dirtyRead:{  status:'Unable',  dscr:'Ein anderer User hat das Zielobjekt ge&auml;ndert', solution:'It\'s simple until you make it complicated.'},
          
          targetDeleted:{  status:'Deleted',  dscr:'Ein anderer User hat das Zielobjekt gel&ouml;scht', solution: false},
          
          dynPratNotAssigned:{  status:'Unable',  dscr:'Dynamisches Teilattribut ist in der Zielhierarchie nicht zugerordnet.', solution:'Teilattribut jetzt zuordnen.'},
          
          dynPratsNotAssigned:{  status:'Unable',  dscr:' dynamische Teilattribute sind in der Zielhierarchie nicht zugerordnet.', solution:'Teilattribute jetzt zuordnen.'},
          
          pratNotAssigned:{  status:'Unable',  dscr:'Attribut ist in der Zielhierarchie nicht zugerordnet.', solution:'Attribut jetzt zuordnen.'},

          uiIntuitivity:{  status:'Unknown',  dscr:'Der User hat ne Frage', solution:'A User interface is like a joke. If you have to explain it, it\'s no that good.'}
  
        };
        
        
        var dialog = Ext.create('widget.window', {
      
          width: diaWidth,//extVia.dialoges.dialogDefaultWidth,
          x: cfg.x,
          y: cfg.y,

          
          title:'Attribute zuordnen',
          iconCls:extVia.dialoges.getWindowIconCls('ErrorValidate'),
          plain: true,
          tools:[{id:'refresh', qtip:'Aktualisieren'}], 
          items : [ {
              border : false,
              minHeight : 300,
              
              itemId:'myFormPanel',
              xtype:'form',

              fieldDefaults : {
               msgTarget : 'side'
              },
              defaults : {
                 style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                 anchor : '100%',
                 labelWidth : 130,
                 width : 350,
                 mssgTarget:'side'
              },
  
              
              items : [ 
                       extVia.dialoges.getInstructionPanel ({
                         mainInstr:'Folgende Attribute haben Konflikte mit Zuordnungen der Collection <i style="font-weight:normal">myColly</i>.',
                         suppInstr:'Pr&uuml;fen Sie die Zuordnungsf&auml;higkeit und fahren Sie fort?'
                       }),
                                   


                       {xtype:'tbspacer', height:5},
                       
                       
                       
                       {
                          xtype:'grid',
                          
                          cls:'xty_grid-group-paranthesis', 
                          
                          id:'multiAssignmentsConflictsGrid',
                          //selModel: Ext.create('Ext.selection.CheckboxModel'),
                          itemId:'conflictsGrid',
                          width:gridWidth,
                          margin:'0 10 10 10',

                          hidden: !fieldsetsHidden,
                          
                          
                          getGroupedColumn:function(){                            
                           var columnFieldName = this.features[0].getGroupField();
                           var column; 
                           var i;
                           for (i = 0; i < this.columns.length; i++){
                            if (columnFieldName ==  this.columns[i].dataIndex){
                              column = this.columns[i];
                            } 
                           }  
                           return  column ;
                          },
                          
                          getGroupedFieldName:function(){                            
                           var columnFieldName = this.getGroupedColumn().headerDscr;
                           return  columnFieldName ;
                          },

                          
                          
                         getGroupedFieldRecordIds:function(rows){  
                            var column  = this.getGroupedColumn();
                            var columnId = column.id;
                            var groupedFieldRecordIds =[];
                            var i;
                            for (i=0; i < rows.length;i++){
                               var cellStr = Ext.encode(rows[i][columnId]);
                               var recordIdIx = cellStr.indexOf('data-recordid');
                               var recordId = cellStr.substring(recordIdIx+16, cellStr.length);
                               recordId = recordId.substring(0, recordId.indexOf('\\'));
                               groupedFieldRecordIds.push(recordId);
                            }
                            return  groupedFieldRecordIds;
                          },
                          getGroupedFieldRecordIdsHtmlAttribute:function(rows){  
                           var groupedFieldRecordIds = this.getGroupedFieldRecordIds(rows);
                           return ' data-recordids="['+groupedFieldRecordIds+']" ';
                          },
                          
                         
                         
                         getGroupedFieldRecordIxs:function(rows){  
                            var column  = this.getGroupedColumn();
                            var columnId = column.id;
                            var groupedFieldRecordIxs =[];
                            
                            var i;
                            for (i=0; i < rows.length;i++){
                               var cellStr = Ext.encode(rows[i][columnId]);
                               var recordIxIx = cellStr.indexOf('data-recordix');
                               var recordIx = cellStr.substring(recordIxIx+16, cellStr.length);
                               recordIx = recordIx.substring(0, recordIx.indexOf('\\'));
                               groupedFieldRecordIxs.push(recordIx);
                            }
                            return  groupedFieldRecordIxs;
                          },
                          
                          getGroupedFieldRecordIxsHtmlAttribute:function(rows){  
                           var groupedFieldRecordIxs = this.getGroupedFieldRecordIxs(rows);
                           return ' data-recordixs="['+groupedFieldRecordIxs+']" ';
                          },

                       
                         
                         getGroupedFieldAssignabiltyHtmlAttribute:function(rows){  
                           var groupedFieldRecordIxs = this.getGroupedFieldRecordIxs(rows);
                           var store = this.getStore(); // groupName
                           var groupHasNoConflicts = true;
                           
                            var i;
                            for (i=0; i < groupedFieldRecordIxs.length;i++){
                             var record = store.getAt( groupedFieldRecordIxs[i] );
                             var conflict = record.get('conflict');
                             if (!Ext.isEmpty(conflict)){
                               var conflictStatus = conflict.status;
                               if (conflict.status!='Nothing' && conflict.status!='Able'){
                                groupHasNoConflicts = false;
                                break;
                               }
                             }
                            }
                           
                           
                           return groupHasNoConflicts?'  checked title="group has no conflicts " ':'';
                         },
                         
                         
                         
                          groupedTplFieldCnt:0,
                          getGroupedFieldFirstRecord:function(){   
                            
                           var grid = Ext.getCmp("multiAssignmentsConflictsGrid");
                           
                           var groupsFirstRecords = grid.getStore().first(true); // needs  groupField set on grid Level
                           var groupsFirstRecordsArr = Ext.Object.getValues( groupsFirstRecords ); 
                           var groupFirstRecord = groupsFirstRecordsArr[this.groupedTplFieldCnt]; 
                           this.groupedTplFieldCnt++;
                           if (this.groupedTplFieldCnt == groupsFirstRecordsArr.length){
                            this.groupedTplFieldCnt = 0;
                           }
                           return groupFirstRecord;
                          },
                          
                          
                          
                          getGroupedHeaderHtmlAttributes:function(){    
                           var groupFirstRecord = this.getGroupedFieldFirstRecord();
                           var epobType = groupFirstRecord.data['assignEpobType'];
                           var epobId = groupFirstRecord.data['assignEpobId'];
                           return ' class="xty_epob'+epobType+'" data-qtip="'+epobType+'   &lt;i&gt;id:'+epobId+'&lt;/i&gt; " data-epobid="'+epobId+'" ';
                          },
                          
                          
                                                      
                          groupField: 'assignEpobDscr', // needed for groupHeaderTpl Record Access
                          features: [Ext.create('Ext.grid.feature.Grouping',{
                            
                            hideGroupedHeader : true,
                            //startCollapsed : true,
                            enableNoGroups :false,

                                
                                groupHeaderTpl: 
                                    '<div {[Ext.getCmp("multiAssignmentsConflictsGrid").getGroupedHeaderHtmlAttributes()]}  {[Ext.getCmp("multiAssignmentsConflictsGrid").getGroupedFieldRecordIxsHtmlAttribute(values.rows)]} style="background-position:0px -1px;padding-left:18px">' +
                                    
                                    
                                      '<span class="xty_group-dscr">{name} &raquo; {rows.length} Zuordnung{[values.rows.length > 1 ? "en" : ""]}</span>' +

                                      '<input onclick="extVia.dialoges.groupHeaderCheckboxClick(this);" {[Ext.getCmp("multiAssignmentsConflictsGrid").getGroupedFieldAssignabiltyHtmlAttribute(values.rows)]} style="position:absolute;right:277px;" type="checkbox"/>' +
                                      //'<img onclick="extVia.dialoges.groupHeaderCheckboxClick(this);" style="position:absolute;right:277px;" src="../img/icons/unchecked_16.png" />' +
                                      
                                     '</div>'
         
                                      
                            })], 
                          
                          
                          columns:[


                          { header:'Attribut', dataIndex:'assignEpobDscr', width:60, headerDscr:'Attribut', 
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                
                                var html = 
                                '<input type="hidden" name="groupTplRecordAccess" data-epobtype="'+record.get('assignEpobType')+'"  data-recordid="'+record.getId()+'"  data-recordix="'+rowIndex+'" />'+
                                '<div title="'+record.get('assignEpobType')+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+record.get('assignEpobType')+'"> &nbsp;&nbsp;&nbsp;'+record.get('assignEpobDscr')+'</div>';
                                return html;
                            }
                           },
                          
                          
                          
                          { header:'Zuordnung', headerDscr:'Zuordnung', dataIndex:'targetEpobDscr', width:220, 
                          
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                
                                var html ='';
                                
                                var lastTargetEpobId = view.lastTargetEpobId;
                                
                                if (lastTargetEpobId && lastTargetEpobId == record.get('targetEpobId')){
                                 html = '';
                                }
                                else{
                                 html = '<div title="'+record.get('targetEpobType')+'" style="height:18px;padding-left:16px;" class="xty_epob'+record.get('targetEpobType')+'"> &nbsp;'+value+'</div>';
                                }
                                //view.lastTargetEpobId = record.get('targetEpobId');
                                
                                return html;
                             }
                           
                           },
  
                           
                          {header:'State', dataIndex:'conflictStatus', width:36, hidden:true,
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                return '<div title="'+record.get('conflictStatus')+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_icon xty_icon'+record.get('conflictStatus')+'"> &nbsp;&nbsp;&nbsp;</div>';
                            }
                          },
                           
                           
                           { header:'Konflikt',headerDscr:'Konflikt', dataIndex:'conflict', width:textCellWidth, 
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                var usedItems = record.get('usedItems');
                                
                                var conflict = value;
                                var conflictStatus;
                                var conflictDscr;
                                
                                if (!Ext.isEmpty(conflict)){
                                    conflictDscr = conflict.dscr;
                                    conflictStatus = conflict.status;
                                }
                                else{ 
                                   conflictStatus = record.get('conflictStatus');
                                   conflictDscr = record.get('conflictDscr');
                                }
                                
                                
                                
                                var html =   '<div title="'+conflictStatus+'" style="height:18px;padding-left:16px;float:left;" class="xty_icon xty_icon'+conflictStatus+'">&nbsp;&nbsp;&nbsp;'+'</div>' +
                                  '<div style="padding-left:22px;white-space:normal;">'+ (usedItems? usedItems.length+' ' :'' )+  conflictDscr +
                                  (usedItems? '<span class="xty_action-assignedattributes" style="cursor:pointer;"> [&raquo;]</span><span class="xty_action-opendetails" style="cursor:pointer;"> [+]</span>':'' )+
                                  '</div>';
                                if (usedItems){
                                  var i;
                                  for (i = 0; i < usedItems.length; i++){
                                    var item = usedItems[i];
                                    html+= '<div id="'+view.id+'-usedItem_targetId'+record.get('targetEpobId')+'_assignId'+item.epobId+'_'+i+'" title="'+item.epobType+'" style="height:18px;padding-left:32px;background-position:18px 0px;display:none ; " class="xty_epob'+item.epobType+'"> &nbsp;&nbsp;&nbsp;'+item.epobDscr+' <span class="xty_action-assignattribute" style="cursor:pointer;" epobid="'+item.epobId+'">[&raquo;]</span></div>';
                                  }
                                }
                                return html;
                            }
                           },                           

                           
                           {header:'Zuordungsf&auml;higkeit / L&ouml;sung', dataIndex:'solution',  dataIndexNEW:'assignability', width:textCellWidth,
                            renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                             var chbxId = Ext.id();
                             
                             var solution = record.get('solution');
                             var conflict = record.get('conflict');
                             if (!Ext.isEmpty(conflict)){
                               solution=conflict.solution;
                             }

                             
                             var mySolution  = record.get('solution');
                             
                             var html = '';
                             if(solution){
                              solution+=' '+mySolution;
                              
                              var checked = conflict.status=='Nothing' ||  conflict.status=='Able'   ?' checked ':'';
                              
                              html =   '<div style="">' +
                                  '<input type="checkbox" id="solution-chbx-'+chbxId+'" name="solution-chbx" '+checked+' disabled style="opacity:0.8"/></div><div style="margin-top:-16px;padding-left:22px;white-space:normal;"><label for="'+chbxId+'" style="">'+solution+'</label></div>';
                             }
                             return html;
                            }
                           },
                           
                          {header:'Zugeordnet', dataIndex:'solutionStateProtoplaceholder', width:66 }, 
                          {header:'Zugeordnet', dataIndex:'solutionState', dataIndexNEW:'assignState', width:66, hidden:true,
                              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                return (Ext.isEmpty(value))?'':'<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_icon xty_icon'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
                            }
                          }
    

                          ],
                          
                          listeners:{
                           itemclick:function(view , record, item, index, evt, eOpts ){

                            var targetEl = Ext.get(evt.target);
                            
                            var action = evt.target.className.replace('xty_action-','');

                            if (action=='opendetails' || action=='closedetails'){
                                if (action=='opendetails' ){
                                  targetEl.dom.innerHTML ='[-]';
                                  targetEl.removeCls('xty_action-opendetails');
                                  targetEl.addCls('xty_action-closedetails'); 
                                }
                                else{
                                  targetEl.dom.innerHTML ='[+]';
                                  targetEl.removeCls('xty_action-closedetails');                                  
                                  targetEl.addCls('xty_action-opendetails'); 
                                }
    
                                var usedItems = record.get('usedItems');
                                if (usedItems){
                                  var i;
                                  for (i = 0; i < usedItems.length; i++){                                  
                                    var itemx = usedItems[i];
                                    var usedItemElId = view.id+'-usedItem_targetId'+record.get('targetEpobId')+'_assignId'+itemx.epobId+'_'+i;
                                    var usedItemEl = Ext.get(usedItemElId);   
                                    if (action=='opendetails' ){ usedItemEl.show();}
                                    else{ usedItemEl.hide();}
                                  } 
                                }  
                            }
 
                           },
                            
                           itemdblclick:function(view , record, item, index, evt, eOpts ){
                             window.alert("Double-click not implemented! This is a demo only.");
                           }
                          },
                          
                          store :  Ext.create('Ext.data.Store', {
                            storeId:'collectionAssignmentsConflictsStore',
                            model: Ext.define('conflicts', {extend: 'Ext.data.Model', 
                             fields: [
                                {type: 'string', name:'assignEpobType'},{type: 'string', name:'assignEpobDscr'},{type: 'string', name:'assignEpobId'},
                                {type: 'string', name:'targetEpobType'},{type: 'string', name:'targetEpobDscr'},{type: 'string', name: 'targetEpobId'},
                                {type: 'string', name: 'conflictStatus'}, 
                                                               
                                {type: 'object', name: 'conflict'}, {type: 'array', name: 'usedItems'}, {type: 'string', name: 'conflicXXXtDscr'}, 
                                {type: 'string', name: 'solution'}, {type: 'string', name: 'solutionState'}

                                ]
                            }),
                            
                            groupField: 'assignEpobDscr',
                            data: [
                            
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Beckensortiment', targetEpobId:'6796', conflict:conflicts.noConflict ,  assignEpobType:'Flag', assignEpobDscr:'Gewicht', assignEpobId:'444'},
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Beckensortiment', targetEpobId:'6796', conflict:conflicts.noConflict ,  assignEpobType:'String', assignEpobDscr:'Gewicht', assignEpobId:'444',  solutionState:'Success',
                                solution:'The longer it takes to develop the less likely it is to launch'
                              },
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Beckensortiment', targetEpobId:'6796', conflict:conflicts.dynPratsNotAssigned ,
                                 solutionState:'Loading',
                                usedItems:[
                                  {epobType:'Number', epobId:'1058', epobDscr:'L&auml;nge'},{epobType:'Number', epobId:'1059', epobDscr:'Breite'}, {epobType:'Number', epobId:'1060', epobDscr:'H&ouml;he'}, {epobType:'String', epobId:'1059', epobDscr:'mein Wert'}, {epobType:'Dictionary', epobId:'1059', epobDscr:'mein Wert'}
                                  ],
                                 assignEpobType:'DynString', assignEpobId:'666', assignEpobDscr:'Zusammengesetztes Attribut'
                              },
                            
                              
                                
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Universaladapter', targetEpobId:'431r', conflict: conflicts.dynPratNotAssigned,  assignEpobType:'Number', assignEpobId:'333', assignEpobDscr:'H&ouml;he', solutionState:'Yes' ,
                              solution:'Don\'t guess. measure.'},
                              
                              
                              { targetEpobType:'Productgroup' , targetEpobDscr:'Automarkt', targetEpobId:'431r', conflict:conflicts.uiIntuitivity,  solutionState:'No',assignEpobType:'Dictionary', assignEpobDscr:'Durchmesser', assignEpobId:'777'},
                              
                              { targetEpobType:'Productgroup' , targetEpobDscr:'Fixit Spezialbohrer', targetEpobId:'431sr', conflictStatus:'Unable', conflictDscr:' abc', solutionState:'Unknown',assignEpobType:'Dictionary', assignEpobDscr:'Durchmesser', assignEpobId:'777',
                              solution:'Quality is the best business plan'},
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Bohrmaschinen', targetEpobId:'4316', conflict: conflicts.noDatabase , conflictStatus:'Error', conflictDscr:'Datenbank abgeraucht',  assignEpobType:'String', assignEpobDscr:'Ziehkraft', assignEpobId:'555',
                              solution:'It\'s simple until you make it complicated'},
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Sortimente', targetEpobId:'6779', conflictStatus:'Unable', conflictDscr:' abc', solutionState:'Loading',assignEpobType:'String', assignEpobDscr:'Druck', assignEpobId:'222',
                              solution:'Experiment fail learn repeat'},
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Sortimente', targetEpobId:'6779', conflict: conflicts.targetDeleted, assignEpobType:'Dictionary', assignEpobDscr:'Druck', assignEpobId:'222',
                              solution:' I like my coffee how I like myself: Dark, bitter and too hot for you.'},
                              
                              { targetEpobType:'Hierarchy' , targetEpobDscr:'Sortimente', targetEpobId:'6779', conflictStatus:'Unable', conflictDscr:' abc', solutionState:'No',assignEpobType:'String', assignEpobDscr:'Druck', assignEpobId:'222',
                              solution:'Move fast and break things'}
                              
                          ]
                          })
                         }
                  ]
            }
          ],

           buttons:{itemId:'myButtons', items:[

            {itemId:'reload',text:'Meldung aktualisieren', margins:'0 360 0 0'},


             {itemId:'further',text:'Zuordnen', tooltip:'Ausgew&auml;hlte zuordnen',
              handler: function(button){
                
                if (!button.clickCount){button.clickCount=0;}
                 
                button.clickCount++;
                
                var bar =  button.ownerCt ; 
                
                var reloadButt = bar.getComponent('reload');
                var finishButt = bar.getComponent('finish');
                var cancelButt = bar.getComponent('cancel');
                
                
                if (button.clickCount==1){
                  finishButt.show();
                  cancelButt.hide();
                  finishButt.setDisabled(false);
                }
                if (button.clickCount==2){
                  button.setDisabled(true);
                 
                  button.hide();
                  reloadButt.hide();
                }

                var grid = bar.ownerCt.getComponent('myFormPanel').getComponent('conflictsGrid');
                var columnSolutionState;
                var columnSolutionStateProtoplaceholder;
                var i;
                for (i = 0; i < grid.columns.length; i++){
                 if (grid.columns[i].dataIndex =='solutionState'){
                   columnSolutionState = grid.columns[i];
                 } 
                 if (grid.columns[i].dataIndex =='solutionStateProtoplaceholder'){
                   columnSolutionStateProtoplaceholder = grid.columns[i];
                 }
                } 
               columnSolutionState.show();
               columnSolutionStateProtoplaceholder.hide();
             }},
             
              {itemId:'finish',text:'Beenden', masrgins:'0 40 0 0', disabled:true, hidden:true, handler:extVia.dialoges.cancelButtonHandler},
              {itemId:'cancel', text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}
           ] }     
      })  ;
        
      return dialog;
      },
      
     
      
      
      
      
	  getMoveProductsDialog : function getMoveProductsDialog(cfg){		
	    var  galleryElements  =	 extVia.dialoges.getGalleryView({epobType:'ELEMENTS',pageStart:0,pageSize:7});
	    var  galleryProd  =	 extVia.dialoges.getGalleryView({epobType:'PRODUCTS',pageStart:7,pageSize:3});
	    	
	    	
	    	var dialog = Ext.create('widget.window', {
	    
	        width: 480,//extVia.dialoges.dialogDefaultWidth,
	        x: cfg.x,
	        y: cfg.y,

	        
	        title:'Produkte verschieben',
	        iconCls:extVia.dialoges.getWindowIconCls('Warning'),
	        plain: true,

	        items : [ {
	            border : false,
	            minHeight : 300,
	            
	            itemId:'myFormPanel',
	            xtype:'form',
	            
	            dirtyAndValiditychange:function( basic, dirty, valid, eOpts){	
	        		var dialogButtons = this.ownerCt.getComponent('myButtons');

	        		var activate = dirty ;
	        		if (!valid) activate = false;

	        		if (activate) dialogButtons.getComponent('create').enable();//or ok or save
	        		else dialogButtons.getComponent('create').disable();
	        		
	        		if (activate) dialogButtons.getComponent('apply').enable();
	        		else dialogButtons.getComponent('apply').disable();
		
	        	},
	  
	            listeners:{
	            	validitychange:function( basic, valid, eOpts ){
	            		extVia.dialoges.notifyFormEvent('validitychange','valid',valid,this.ownerCt.title);
	            		this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts );	
	            	},	
	            	dirtychange:function( basic, dirty, eOpts){
	            		extVia.dialoges.notifyFormEvent('dirtychange','dirty',dirty,this.ownerCt.title);
	            		this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts );	
	            	}
	             },

	            
	            fieldDefaults : {
	             msgTarget : 'side'
	            },
	            defaults : {
	               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
	               anchor : '100%',
	               labelWidth : 130,
	               width : 350,
	               msgTarget:'side'
	            },
	            items : [ 
	                     extVia.dialoges.getInstructionPanel ({
	                    	 mainInstr:'Beim Verschieben gibt es bei folgenden Produkten Konflikte.',
	                    	 suppInstr:'Legen Sie außerdem die Verschiebeoptionen fest.'
	                     }),
	                     
//	                     extVia.dialoges.getInstructionPanel ({
//	                    	 itemId:'verlustfrei', id:'verlustfrei',
//	                    	 mainInstr:'Sie k&ouml;nnen verlustfrei oder komplett verschieben.',
//	                    	 suppInstr:'Wenn Sie <i>komplett verschieben</i> wird es bei folgenden Produkten zu Problemen kommen.',
//	                     }),

	                     
	                     

                 		 { xtype:'displayfield', value:'<b>Verschiebeoptionen</b>' },	
            	         { xtype:'checkbox', name:'p_bCopyNotEdiAttri' , fieldLabel:'&nbsp;Nicht pflegbare Attributwerte vom Quellknoten kopieren', labelWidth : 330 },
            	         { xtype:'checkbox', name:'p_bDeleteAvailPrev' , fieldLabel:'&nbsp;Vorhandene Previews l&ouml;schen' , labelWidth : 330},

	                              
                         
                 		 {xtype:'tbspacer', height:15},	
                 		 { xtype:'displayfield', value:'<b>Produkte mit Konflikten</b>' },	
                         
                         
                         {xtype:'tbspacer', height:5},	
	                 		 { xtype:'fieldset', title:'<b>handgef&uuml;hrte Maschinen</b> » Attributsverlust', collapsible : true,coldlapsed:true, resizable:true,
	                 			 items:[
	                 			        { width: 420, xtype:'displayfield', value:'<span>Die folgenden Produktattribute sind in der Zielhierarchie nicht definiert und werden beim Verschieben unwiderruflich gel&ouml;scht.</span> ' },
	                 			        { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbspDrehmoment</li><li>&nbsp;&bull;&nbsp;Schlagzahl</li></ul>'}
	   	                 			 
	                 			 ]	 
	                 		 },		
	                 		 
	                 		 
	                 		 {xtype:'tbspacer', height:10},	
	                 		 { xtype:'fieldset', title:'<b>Einzel- und Konstruktionsteile</b> » Attributsverlust', collapsible : true,collapsed:true,
	                 			 items:[
	                 			        { width: 420, xtype:'displayfield', value:'<span>Die folgenden Produktattribute sind in der Zielhierarchie nicht definiert und werden beim Verschieben unwiderruflich gel&ouml;scht.</span> ' },
	                 			        { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbsp;Zubeh&ouml;ranzahl</li><li>&nbsp;&bull;&nbsp;maximale Drehzahl</li></ul>'}
	   	                 			 
	                 			 ]	 
	                 		 },	
	                 		 
	                 		 
	                 		 {xtype:'tbspacer', height:10},	
	                 		 { xtype:'fieldset', title:'<b>Rohre</b> » Publikations Seiteneffekt', collapsible : true,collapsed:true,
	                 			 items:[
	                 			        {width: 420,  xtype:'displayfield', value:'<span>Die ge&auml;nderten Attribute k&ouml;nnten Seiteneffekte auf folgende Publikationen haben in denen das Produkt bereits verwendet wird.</span> ' },
	                 			        { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbsp;Winterkatalog</li><li>&nbsp;&bull;&nbsp;Herbstflyer</li></ul>'}
	   	                 			 
	                 			 ]	 
	                 		 },	
	                 		 
	                 		 {xtype:'tbspacer', height:10},	
	                 		 { xtype:'fieldset', title:'<b>Marktplatz</b> » Verschieben nicht erlaubt', collapsible : true,collapsed:true,
	                 			 items:[
	                 			        {width: 420,  xtype:'displayfield', value:'<span>Das Verschieben aus einer Hierarchietypenstruktur ist nicht erlaubt.</span> ' }
	   	                 			 
	                 			 ]	 
	                 		 },		                 		 
	                 		 
	                 		 
	                 		 {xtype:'tbspacer', height:15},	
	                 		 { xtype:'displayfield', value:'<b>Gallerien</b>' },	
	                 		 {xtype:'tbspacer', height:5},	
	                 		 { xtype:'fieldset', title:'<b>Elemente</b>', collapsible : true,coldlapsed:true, items:[ galleryElements ]	 
	                 		 },
	                 		 	
	                 		 {xtype:'tbspacer', height:5},	
	                 		 { xtype:'fieldset', title:'<b>Produkte</b>', collapsible : true,coldlapsed:true, items:[ galleryProd ]	 
	                 		 },
	                 		 
	                         {xtype:'tbspacer', height:5}
	                     ]
	        	}
	        ],

	         buttons:{itemId:'myButtons', items:[
	        
		         {itemId:'moveNoConflicts',text:'Konfliktfreie verschieben', handler:extVia.dialoges.okButtonHandler, executeAction:'moveNoConflicts'},// {xtype:'tbspacer', width:30},
		         {itemId:'moveAll',text:'Alle verschieben', hidyden:true, handler:extVia.dialoges.okButtonHandler,executeAction:'moveAll'},
		         {itemId:'cancel', text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}
	         ] }     
	    })  ;
	    	
	    return dialog;
	    },
	    
	    
	    getAddWidgetDialog : function getAddWidgetDialog(cfg){
	    	  var addWidgetDialog = Ext.create('widget.window', {
	    	        width: extVia.dialoges.dialogDefaultWidth,
	    	        x: cfg.x,
	    	        y: cfg.y,

	    	        title:'Widget hinzuf&uuml;gen',
	    	        iconCls:extVia.dialoges.getWindowIconCls('Information'),
	    	        
	    	        plain: true,

	    	        items : [ {
	    	            border : false,
	    	            minHeight : 200,
	    	            
	    	            itemId:'myFormPanel',
	    	            xtype:'form',
	    	            
	    	            dirtyAndValiditychange:function( basic, dirty, valid, eOpts){	
	    	            	
	    	        		var dialogButtons = this.ownerCt.getComponent('myButtons');

	    	        		var activate = dirty ;
	    	        		if (!valid) activate = false;

	    	        		if (activate) dialogButtons.getComponent('apply').enable();
	    	        		else dialogButtons.getComponent('apply').disable();
	    	        		if (activate) dialogButtons.getComponent('ok').enable();
	    	        		else dialogButtons.getComponent('ok').disable();
	    		
	    	        	},
	    	  
	    	            listeners:{	
	    	            	validitychange:function( basic, valid, eOpts ){
	    	            		extVia.dialoges.notifyFormEvent('validitychange','valid',valid,this.ownerCt.title);
	    	            		this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts );	
	    	            	},	
	    	            	dirtychange:function( basic, dirty, eOpts){
	    	            		extVia.dialoges.notifyFormEvent('dirtychange','dirty',dirty,this.ownerCt.title);
	    	            		this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts );	
	    	            	}
	    	             },

	    	            
	    	            fieldDefaults : {
	    	              msgTarget : 'side'
	    	            },
	    	            defaults : {
	    	               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
	    	               anchor : '100%',
	    	               labelWidth : 130,
	    	               width : 350,
	    	               msgTarget:'side'
	    	               
	    	            },
	    	            items : [ 
	    	                     
	    	                     extVia.dialoges.getInstructionPanel ({
	    	                    	 mainInstr:'Gestalten Sie Ihr <i>{Widget}:</i>',
	    	                         suppInstr:'Legen Sie <i>{das gew&uuml;nschte Objekt}</i>, das Anzeigeverhalten und das Erscheinungsbild fest.' 
	    	                         }),
	    	  
	    	                     		 {xtype:'combo', 
	    	                     			 store: 'tagsStore',
	    	                     			 name:'p_arrTags',
	    	                     			 queryMode: 'local',
	    	                     			 itemId:'epobs',
	    	                     			 labelSeparator : extVia.dialoges.getLabelSeparator4Required(), allowBlank:false,
	    	                     			 displayField: 'name',
	    	                  	  			 emptyText: 'Pick a object',
	    	                  	  			 valueField: 'abbr',
	    	                     			 fieldLabel: 'verf&uuml;gbare Objekte'},

	    	                            {xtype:'tbspacer', height:16},

	    	                    		 {	xtype:'combo', 
	    	                            	itemId:'sortby', 
	    	                    			 store: 'sortbyStore',
	    	                    			 name:'p_arrSort',
	    	                    			 queryMode: 'local',
	    	                    			 displayField: 'dscr',
	    	                 	  			 emptyText: 'Pick sorting',
	    	                 	  			 forceSelection:true,
	    	                 	  			 value:'1',
	    	                 	  			 valueField: 'id',
	    	                    			 fieldLabel: 'Sortieren nach'},
	    	                            
	    	                            
	    	                            {xtype:'radiogroup',name:'p_rgrpOrder', itemId:'order', fieldLabel: 'Reihenfolge', items:[  {name:'p_bSortUp', boxLabel: 'Aufsteigend'}, {name:'p_bSortDown',boxLabel: 'Absteigend'}]},
	    	                            
	    	                            {xtype:'checkboxgroup', name:'p_chckbxgrpShowas',  itemId:'showas', fieldLabel: 'Zeige', items:[  {name:'p_bShowText',boxLabel: 'Text'}, {name:'p_bShowInNewWin',boxLabel: 'Text', boxLabel: 'in neuem Fenster'}]},
	    	                            
	    	                    		
	    	                            {xtype:'tbspacer', height:16}, 
	    	                            
	    	                            Ext.create('Ext.ux.ColorField', {
	    	                            	itemId:'color',
	    	                   				xtype:'colorfield',
	    	                   				labelWidth : 130,
	    	                   				name:'p_sColor',
	    	                   				allowBlank:false, labelSeparator :extVia.dialoges.getLabelSeparator4Required(),
	    	                   				fieldLabel: 'Farbe',
	    	                   				width : 350,
	    	                   				value:'#A4C143'
	    	                   				}),
	    	                   				
	    	                   			 {xtype:'tbspacer', height:10}	
	    	                     ]
	    	        	}
	    	        ],

	    	         buttons:{itemId:'myButtons', items:[
	    	         {xtype:'tbspacer', width:30},{itemId:'ok',text:'OK', disabled:true, handler:extVia.dialoges.okButtonHandler},{itemId:'cancel',text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler},{itemId:'apply',text:'&Uuml;bernehmen', handler:extVia.dialoges.applyButtonHandler , disabled:true}] }     
	    	    });
	    	return   addWidgetDialog;
	    },

	    getAddEpobDialog : function getAddEpobDialog(cfg){
	    	
	    	var title = cfg.title?cfg.title:'neues <i>{Epob}</i> erstellen';
	    	var mainInstruction = cfg.mainInstruction?cfg.mainInstruction:'Erstellen Sie ein <i>{Epobtyp} in: </i><i style="font-weight:normal">{ParentNode.name}</i>';
	    	var supplementalInstruction = cfg.supplementalInstruction?cfg.supplementalInstruction:'Legen Sie allgemeine und typspezifische Metadaten fest.';
	    	
	    	var supplementalInstructionOff = cfg.supplementalInstructionOff;// ?cfg.supplementalInstruction:'Legen Sie allgemeine und typspezifische Metadaten fest.';
	    	
	    	var addEpobDialog = Ext.create('widget.window', {
	    
	        width: extVia.dialoges.dialogDefaultWidth,
            x:cfg.x?cfg.x:24,
            y:cfg.y?cfg.y:89,
	        
	        title:title,
	        iconCls:extVia.dialoges.getWindowIconCls('Information'),
	        plain: true,

	        items : [ {
	            border : false,
	            minHeight : 200,
	            
	            itemId:'myFormPanel',
	            xtype:'form',
	            
	            dirtyAndValiditychange:function( basic, dirty, valid, eOpts){	
	        		var dialogButtons = this.ownerCt.getComponent('myButtons');

	        		var activate = dirty ;
	        		if (!valid) activate = false;

	        		if (activate) dialogButtons.getComponent('reset').enable();//or ok or save
	        		else dialogButtons.getComponent('reset').disable();
	        		
	        		if (activate) dialogButtons.getComponent('create').enable();//or ok or save
	        		else dialogButtons.getComponent('create').disable();
	        		
	        		if (activate) dialogButtons.getComponent('apply').enable();
	        		else dialogButtons.getComponent('apply').disable();
		
	        	},
	  
	            listeners:{
	            	validitychange:function( basic, valid, eOpts ){
	            		extVia.dialoges.notifyFormEvent('validitychange','valid',valid,this.ownerCt.title);
	            		this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts );	
	            	},	
	            	dirtychange:function( basic, dirty, eOpts){
	            		extVia.dialoges.notifyFormEvent('dirtychange','dirty',dirty,this.ownerCt.title);
	            		this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts );	
	            	}
	             },

	            
	            fieldDefaults : {
	             msgTarget : 'side'
	            },
	            defaults : {
	               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
	               anchor : '100%',
	               labelWidth : 130,
	               width : 350,
	               msgTarget:'side'
	            },
	            items : [ 
	                     
	                     extVia.dialoges.getInstructionPanel ({
	                    	 mainInstr:mainInstruction,
	                    	 suppInstr: supplementalInstructionOff?null:supplementalInstruction
	                     }),
	                 		  
	                 		 { xtype:'displayfield', value:'<b>Allgemeine Metadaten</b>' },	
	                 		  
	                 		 {xtype:'textfield', value:'alternating current/direct current', name:'p_sName', itemId:'epobDscr', fieldLabel: '&nbsp;Name',  labelSeparator :extVia.dialoges.getLabelSeparator4Required(), allowBlank:false},
	                 		 {xtype:'textfield', value:'ac/dc', name:'p_sShortcut', itemId:'shortcut', fieldLabel: '&nbsp;K&uuml;rzel',  labelSeparator :extVia.dialoges.getLabelSeparator4Required(), allowBlank:false},
	                 		 
	                 		 {xtype:'textarea',  name:'p_sDescription', itemId:'description', fieldLabel: '&nbsp;Beschreibung', rows:2},
	                 		 {xtype:'textarea', name:'p_sCatchwords', itemId:'catchwords', fieldLabel: '&nbsp;Schlagworte', rows:2},
	                 		 
	                		 {xtype:'combo', itemId:'language', name:'p_sLanguage', 
	                			 store: 'languageStore',//extVia.stores.initLanguageStore({pageSize:extVia.stores.mengengridPageSize});
	                			 queryMode: 'local',
	                			 displayField: 'dscr',
	             	  			 emptyText: 'Pick language',
	             	  			 valueField: 'shortcut',
	             	  			 value: 'DE',
	                			 fieldLabel: '&nbsp;Sprache'},
	                 		 
	                 		 
	                		 {xtype:'combo', itemId:'tags', name:'p_arrTags', 
	                			 store: 'tagsStore',
	                			 queryMode: 'local',
	                			 displayField: 'name',
	                			 multiSelect:true,
	             	  			 emptyText: 'Pick tags',
	             	  			 valueField: 'abbr',
	             	  			 value: 'WA',
	                			 fieldLabel: '&nbsp;Tags'},
	                 		 
	                 		 
	                 		 
	                            
	                         {xtype:'tbspacer', height:16},
	                        
	                         { xtype:'displayfield', value:'<b>Typspezifische Metadaten</b>' },	   


	                		 {	xtype:'combo', 
	                        	itemId:'sortby', name:'p_sSortby', 
	                			 store: 'sortbyStore',
	                			 queryMode: 'local',
	                			 displayField: 'dscr',
	             	  			 emptyText: 'Pick sorting',
	             	  			 forceSelection:true,
	             	  			 value:'1',
	             	  			 valueField: 'id',
	                			 fieldLabel: '&nbsp;Sortieren nach'},
	                         
	                         
	                         {xtype:'radiogroup', name:'p_rdgrpSortOrder', itemId:'sortOrder', fieldLabel: '&nbsp;Reihenfolge', items:[  {name:'p_sSortOrderASC',  itemId:'sortOrderASC',boxLabel: 'Aufsteigend'}, {name:'p_sSortOrderASC', itemId:'sortOrderDESC',boxLabel: 'Absteigend'}]},
	                         
	                         {xtype:'checkboxgroup', name:'p_chbxgrpShow', itemId:'show', fieldLabel: '&nbsp;Zeige', items:[  {name:'p_sShowText', itemId:'showText',boxLabel: 'Text'}, {name:'p_sShowInNewWindow',  itemId:'showInNewWindow', boxLabel: 'in neuem Fenster'}]},
	                         
	                 		
	                         {xtype:'tbspacer', height:16}, 
	                         
	                         (Ext.ux && Ext.ux.ColorField) ? Ext.create('Ext.ux.ColorField', {
	                         	itemId:'color',
	                				xtype:'colorfield',
	                				name:'p_sColor',
	                				labelWidth : 130,
	                				allowBlank:false, labelSeparator :extVia.dialoges.getLabelSeparator4Required(),
	                				fieldLabel: '&nbsp;Farbe',
	                				width : 350,
	                				value:'#A4C143'
	                				}) : {xtype:'tbspacer', height:10},
	                   				
	                   			 {xtype:'tbspacer', height:10}	
	                     ]
	        	}
	        ],

	         buttons:{itemId:'myButtons', items:[{itemId:'reset',text:'Reset', disabled:true, handler:extVia.dialoges.resetButtonHandler},
	         {xtype:'tbspacer', width:70},{itemId:'create',text:'Erstellen', disabled:true, handler:extVia.dialoges.okButtonHandler},{itemId:'cancel', text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler},{itemId:'apply',text:'&Uuml;bernehmen', handler:extVia.dialoges.applyButtonHandler, disabled:true}] }     
	    })  ;
	    	
	    return addEpobDialog;
	    },
	    

	    getInfoDialog : function getInfoDialog(cfg){ 
		    
			var title =  cfg.action;
			var mainInstr =  cfg.mainInstruction ? cfg.mainInstruction :'mainInstruction';
			var suppInstr =  cfg.suppInstr; // ? cfg.suppInstr :'supplementalInstr';
			
		    var infoDialog = Ext.create('widget.window', {
		    	    
			        width: cfg.width?cfg.width:extVia.dialoges.dialogDefaultWidth-20,
                    height: cfg.height?cfg.height:null,
			        x:cfg.x?cfg.x:24,
                    y:cfg.y?cfg.y:89,

			        title:title,
			        iconCls:extVia.dialoges.getWindowIconCls('Information'),
			        
			        plain: true,

			        items : [ {
			            border : false,
			            minHeight : 200,
			            defaults : {
			               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
			            },
			            items : [ 
			                     extVia.dialoges.getInstructionPanel ({ mainInstr: mainInstr,suppInstr: suppInstr }),
			                     
			                     {
			                    	xtype:'textarea', 
			                    	value:cfg.info,
			                    	width:extVia.dialoges.dialogDefaultWidth-30,
                                    height: cfg.height?cfg.height-80:200,
                                    width: cfg.width?cfg.width-80:null
			     		        	},
			     		          {xtype:'tbspacer', width:16}
			                     
			                     
			                     ]
			        	}
			        ],

			        buttons:[
                          {text:'json edi', handler:function(button){ window.open('http://www.jsoneditoronline.org/');}},
                          {text:'OK', handler:function(button){ button.up("window").close();}}
                      
                      ]      
			           
			    }) ;
			    	
			    return infoDialog;
		},
	    
	    
	    
	    
	    getPinfoRowDialog : function getPinfoRowDialog(cfg){
	    	
	    	var reqSep = extVia.dialoges.getLabelSeparator4Required();
	    	
	    	var title = cfg.title?cfg.title:'Produktinformation hinzuf&uuml;gen';
	    	var mainInstruction = cfg.mainInstruction?cfg.mainInstruction:'Erstellen Sie eine Produktinformation';
	    	var supplementalInstruction = cfg.supplementalInstruction?cfg.supplementalInstruction:'Legen Sie Werte f&uuml;r Arbeits- und versionierte Version fest.';
	    	
	    	var supplementalInstructionOff = cfg.supplementalInstructionOff;

	    	
	    	var copyValues = function(field){
	    		
	    		var src ='Work'; var targ ='Version';
	    		
	    		if (field.itemId.indexOf("Up")>-1){
	    			 src ='Version'; targ ='Work';
	    		}

	    		//window.alert("field.itemId "+field.itemId +" src "+src+" targ "+targ);
	    		
	    		
	    		var myFormPanel = field.ownerCt.ownerCt;

		    	var valueSrc =  myFormPanel.getComponent('value'+src);
	    		var valueTarg = myFormPanel.getComponent('value'+targ);
	    		
	    		valueTarg.changeSetterOFF =true;
	    		valueTarg.setValue(valueSrc.getValue());
	    		valueTarg.changeSetterOFF = false;
	    		
	    		var changedatetimeSrc =  myFormPanel.getComponent('changedatetime'+src);

                var datumFieldSrc = changedatetimeSrc.getComponent('changedate'+src); 
                var timeFieldSrc =  changedatetimeSrc.getComponent('changetime'+src); 
                var userFieldSrc =  myFormPanel.getComponent('user'+src);
                
	    		var changedatetimeTarg =  myFormPanel.getComponent('changedatetime'+targ);
                var datumFieldTarg = changedatetimeTarg.getComponent('changedate'+targ); 
                var timeFieldTarg =  changedatetimeTarg.getComponent('changetime'+targ); 
                var userFieldTarg =  myFormPanel.getComponent('user'+targ);
                
                datumFieldTarg.setValue(datumFieldSrc.getValue());
                timeFieldTarg.setValue(timeFieldSrc.getValue());
                userFieldTarg.setValue(userFieldSrc.getValue()); 	    		
	    	};
	    	
	    	
	    	var valueChangeinfoSetter = function(field){
	    		
	    		if (field.changeSetterOFF)return;
	    		
		    	var nowDate = new Date();
		    	var datum =Ext.Date.format(nowDate,'d.m.Y');
		    	var zeit = Ext.Date.format(nowDate,'H:i:s'); 	
	    		
		    	var side ='Work';
		    	if (field.name.indexOf('Version')>-1){
		    		side='Version';
		    	}

		    	var changedatetime =  field.ownerCt.getComponent('changedatetime'+side);
		        var datumField = changedatetime.getComponent('changedate'+side); 
		        var timeField =  changedatetime.getComponent('changetime'+side); 
		        
		        var userField =  field.ownerCt.getComponent('user'+side);
		       
		        
		        Ext.Function.defer(function(){
		        	var usersCount =34; // initUsersStore Data
			        var userIx =Math.floor((Math.random()*usersCount)); 
			        //userField.setValue(userField.getStore().getAt(userIx).get('name'));
		        }, 300);
 
		        datumField.setValue(datum);
		        timeField.setValue(zeit);	
	    	}; 
	    	
	      var getUserComboCfg = function(side){
	    	var userComboCfg ={xtype:'combo', itemId:'user'+side, name:'user'+side,
   			 store:   extVia.stores.initUserStore(),
   			 queryMode: 'local',
   			 displayField: 'name',
	  	     emptyText: 'Benutzer',
	  		 valueField: 'name',
             value:  (side.indexOf('ork')>-1)?'Bernard Purdie':'',
   			 fieldLabel: '&nbsp;Benutzer'
   			 };
	    	return userComboCfg;
	        };

	    	
	    	var pinfoRowDialog = Ext.create('widget.window', {
	    	itemId:'pinfoRowDialog',	
	        x:24,y:59,
	        width: extVia.dialoges.dialogDefaultWidth-20,
	        title:title,
	        iconCls:extVia.dialoges.getWindowIconCls('Information'),
	        plain: true,

	        items : [ {
	            border : false,
	            minHeight : 200,
	            
	            itemId:'myFormPanel',
	            xtype:'form',
	            
	            dirtyAndValiditychange:function( basic, dirty, valid, eOpts){	
	        		var dialogButtons = this.ownerCt.getComponent('myButtons');

	        		var activate = dirty ;
	        		if (!valid) activate = false;

	        		if (!valid || dirty) dialogButtons.getComponent('reset').enable();//or ok or save
	        		else dialogButtons.getComponent('reset').disable();
	        		
	        		if (activate) dialogButtons.getComponent('create').enable();//or ok or save
	        		else dialogButtons.getComponent('create').disable();
	        		
	        		if (activate) dialogButtons.getComponent('apply').enable();
	        		else dialogButtons.getComponent('apply').disable();
		
	        	},
	  
	            listeners:{
	            	validitychange:function( basic, valid, eOpts ){
	            		//extVia.dialoges.notifyFormEvent('validitychange','valid',valid,this.ownerCt.title);
	            		this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts );	
	            	},	
	            	dirtychange:function( basic, dirty, eOpts){
	            		//extVia.dialoges.notifyFormEvent('dirtychange','dirty',dirty,this.ownerCt.title);
	            		this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts );	
	            	}
	             },

	            
	            fieldDefaults : {
	             msgTarget : 'side'
	            },
	            defaults : {
	               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
	               
	               labelWidth : 130,
	               width : 350,
	               msgTarget:'side'
	            },
	            items : [ 
	                     
	                     extVia.dialoges.getInstructionPanel ({
	                    	 mainInstr:mainInstruction,
	                    	 suppInstr: supplementalInstructionOff?null:supplementalInstruction
	                     }),
	                 		  
	                 		{ xtype:'displayfield', value:'<b>Eigenschaften</b>' },	
	                 		 
	                 		{xtype:'textfield', name:'name', itemId:'name', fieldLabel: '&nbsp;Name',  labelSeparator :reqSep, allowBlank:false, listeners:{change:valueChangeinfoSetter} }, 
	                 		
	                 	    {
                 		        xtype: 'fieldcontainer', itemId:'areatype',layout:'hbox',fieldLabel: '&nbsp;Bereich / Typ',labelSeparator :reqSep, allowBlank:false,
                 		        items:[ 
                 		        {xtype:'combo', itemId:'area', name:'area', labelSeparator :reqSep, allowBlank:false,
	                			 store: extVia.stores.initProductinfoareaStore(),
	                			 queryMode: 'local',
	                			 flex:0.5,
	                			 emptyText: 'Produktbereich',
	                			 forceSelection:true,
	                			 displayField: 'dscr',
	                			 //valueField: 'value', value:'attributes',
	             	  			 valueField: 'dscr', value:'Attribute',
	                             listConfig : {
	                             	    minWidth:160
	                             	    },
	                             listeners:{

	                            	 change:function(combo, newValue, oldValue){
	                            		 
	                            		 var myFormPanel = combo.ownerCt.ownerCt;
	                            		 
	                            		 var mystore =  combo.getStore();	                            		 
	                            		 var record = mystore.findRecord(combo.valueField, combo.value);
	                            		 
	                            		 var pinfoarea = 'attributes';
	                            		 var areaorder=0;
	                            		 if (record){
		                            		 pinfoarea = record.get('value');
		                            		 areaorder = record.get('areaorder');
	                            		 }
	                            		 
	                            		 combo.ownerCt.getComponent('areaorder').setValue(areaorder);
	                            		 
	                            		 var data = extVia.stores.getPinfoareaTypes(pinfoarea);
	                            		 
	                            		 var dataTypeCombo = combo.ownerCt.getComponent('dataType');
	                            		 var dtstore =  dataTypeCombo.getStore();
	                            		 dtstore.loadData(data);
	                            		 dataTypeCombo.setValue(data[0].value);

	                            		 var specificPropertiesDscr=myFormPanel.getComponent('specificPropertiesDscr');
	                            		 var specificPropertiesAttributes=myFormPanel.getComponent('specificPropertiesAttributes');
	                            		 var specificPropertiesElements=myFormPanel.getComponent('specificPropertiesElements');
	                            		 var specificPropertiesProductrelations=myFormPanel.getComponent('specificPropertiesProductrelations');
	                            		 
	                            		 specificPropertiesAttributes.hide();
	                            		 specificPropertiesElements.hide();
	                            		 specificPropertiesProductrelations.hide();
	                            		 specificPropertiesAttributes.disable();
	                            		 specificPropertiesElements.disable();
	                            		 specificPropertiesProductrelations.disable();
	                            		 
	                            		 if (pinfoarea=="attributes"||pinfoarea=="elements"||pinfoarea=="productrelations" ){
	                            			 specificPropsAvailable =true;
	                            			 specificPropertiesDscr.enable();
	                            		 }
	                            		 else{
	                            			 specificPropertiesDscr.disable();
	                            		 }
	                            		 
	                            		 
	                            		 if (pinfoarea=="attributes"){
	                            			 specificPropertiesAttributes.show();
	                            			 specificPropertiesAttributes.enable();
	                            		 }
	                            		 else if (pinfoarea=="elements"){
	                            			 specificPropertiesElements.show();
	                            			 specificPropertiesElements.enable();
	                            		 }
	                            		 else if (pinfoarea=="productrelations"){
	                            			 specificPropertiesProductrelations.show();
	                            			 specificPropertiesProductrelations.enable();
	                            		 }	                            		 	                            		
	                            	 }
	                             },	    
	                			 fieldLsabel: '&nbsp;Bereich'},
	                			 
	                			 {xtype:'hiddenfield', itemId:'areaorder', name:'areaorder' ,value:' 4'},
	                			 
	                 		 
	                			 {xtype:'tbspacer', width:16},
	                			 
	                			 {xtype:'combo', itemId:'dataType', name:'dataType',labelSeparator :reqSep, allowBlank:false,
	                			 store:   extVia.stores.initPinfoareaTypesStore({area:'attributes'}),
	                			 queryMode: 'local',
	                			 forceSelection:true,
	                			 displayField: 'dscr',
	                			 flex:0.5,
	             	  			 emptyText: 'Datentyp',
	             	  			 valueField: 'value',
                                 value: 'Dictionary',
	                             listeners:{
	                            	 change:function(combo, newValue, oldValue){
	                            		var myFormPanel = combo.ownerCt.ownerCt;
	                            		var specificPropertiesAttributes=myFormPanel.getComponent('specificPropertiesAttributes');
	                            		
	                            		
	                            		var collectionEntryTypeName=specificPropertiesAttributes.getComponent('collectionEntryTypeName'); 
	                            		var collectionEntries=specificPropertiesAttributes.getComponent('collectionEntries'); 
	                            		if (newValue=='Collection' || newValue=='AttributeCollection'){
	                            			collectionEntryTypeName.enable();
	                            			collectionEntries.enable();
	                            		}
	                            		else{
	                            			collectionEntryTypeName.disable();
	                            			collectionEntries.disable();
	                            		} 
	                            	 }
	                			 },
	                             listConfig : {
	                             	    minWidth:210,
	                                    getInnerTpl : function(displayField) {
	                                      var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div></div>';
	                                      return tpl;
	                                    }
	                                  }
	                			 }]
                 		        	
	                 	    },
	                 		 
	                 	  {xtype:'textfield', name:'baseAction', itemId:'baseAction', fieldLabel: '&nbsp;Aktion'},   
	                 	    
              	           {
                 		        xtype: 'fieldcontainer',layout:'hbox',fieldLabel: '&nbsp;ist Parent',itemId:'isParentEntryProps',
                 		        items:[
                     		        {xtype:'radiofield',itemId:'isParent', name:'childOrParent',inputValue:'parent',
	                     		        handler:function(field){
	                     		        	if (this.checked){
	                     		        		this.ownerCt.ownerCt.getComponent('isChildEntryProps').getComponent('isChildEntry').setValue(false);
	                     		        		this.ownerCt.ownerCt.getComponent('isChildEntryProps').getComponent('isLastChild').setValue(false);
	                     		        	}	
	                     		        }	
	                     		        }
	                     		        ]
             	            },

	                        {
                 		        xtype: 'fieldcontainer',layout:'hbox',fieldLabel: '&nbsp;ist Kind Info',itemId:'isChildEntryProps', 
                 		        items:[
                 		        {xtype:'radiofield',itemId:'isChildEntry', name:'childOrParent',inputValue:'child',
	                 		        handler:function(field){
	                 		        	this.ownerCt.getComponent('parentId').setDisabled(!this.checked);
	                 		        }	
                 		        },
                 		       {xtype:'tbspacer', width:16},
                 		        {xtype:'checkbox',itemId:'isLastChild', name:'isLastChild',fieldLabel:'last',labelWidth : 28,
                     		        handler:function(field){
                     		        	if (this.checked){
                     		        		this.ownerCt.getComponent('isChildEntry').setValue('child');
                     		        	}
                     		        }	
                     		        },
                 		        {xtype:'tbspacer', width:16},
                 		        {xtype:'textfield', flex:0.6, name:'specprop-parentId',  labelWidth : 28,fieldLabel: 'von', disabled:true,  itemId:'parentId', emptyText: 'parent epobId' }
                 		       ]
             	            },
	                 	    
	                 	    
 
	                 	    { xtype:'displayfield', itemId:'specificPropertiesDscr', value:'<b>spezifische Eigenschaften</b>', dissabled:true },	
	                 	    { xtype: 'fieldset',itemId:'specificPropertiesAttributes', title:'<b>Attribute</b>', collapsible : true, 
	                 		  width : 360,
	                 		  defaults:{
	        	               labelWidth : 118,
	        	               width : 338,
	        	               msgTarget:'side'
	                 		  },
	                 	      items:[
	                 	            {xtype:'tbspacer',height:8}, 
	                 	            {xtype:'numberfield', width:220, name:'specprop-multiplicity', itemId:'multiplicity', fieldLabel: 'Vermehrbarkeit', emptyText: 'Vermehrbarkeit',  value:1 },

	                 	            
	    	                        {
	                     		        xtype: 'fieldcontainer',layout:'hbox',fieldLabel: 'add Collection Entry',itemId:'collectionEntryTypeName', disabled:true, 
	                     		        items:[
		                 	            
	    	                			     {xtype:'combo', fieldLdabel: 'Collection Typ',  flex :0.5,
	    	                				 itemId:'collectionEntryType', name:'collectionEntryType', empytText:'collectionEntryType',
		                 	            	 labelSeparator :reqSep,
	        	                			 store:   extVia.stores.initPinfoareaTypesStore({area:'attributes'}),
	        	                			 queryMode: 'local',
	        	                			 forceSelection:true,
	        	                			 value:'String',
	        	                			 displayField: 'dscr',
	        	             	  			 emptyText: 'Datentyp',
	        	             	  			 valueField: 'value',
	        	                			 fieldLsabel: '&nbsp;Typ',
	        	                             listConfig : {
	        	                             	    minWidth:210,
	        	                                    getInnerTpl : function(displayField) {
	        	                                      var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div></div>';
	        	                                      return tpl;
	        	                                    }
	        	                                  }
	        	                			 },
	        	                			 {xtype:'tbspacer', width:16},
		                 	                 {xtype:'triggerfield', flex :0.5, name:'collectionEntryName', itemId:'collectionEntryName', emptyText: 'Name',
	        	                				 triggerCls : 'x-form-plus-trigger', 
		        	                			 onTriggerClick:function(evt){
			         	                				var triggerfield = this;
			         	                				var combo = triggerfield.ownerCt.getComponent('collectionEntryType');
			      	                					var collectionEntries = combo.ownerCt.ownerCt.getComponent('collectionEntries');
			      	                					collectionEntries.setValue(collectionEntries.getValue()+combo.getValue()+":"+triggerfield.value+", ");
			         	                			 }
		                 	                 }
	        	                			 ]
	                 	           		},
	                 	               {xtype:'textarea', disabled:true, height:48,flex :0.5, name:'specprop-collectionEntries', itemId:'collectionEntries', fieldLabel: 'Collection Inhalte', emptyText: 'collection Entries' }
	                 	            ]	
	                 	    },

	                 	    
	                 	   { xtype: 'fieldset',itemId:'specificPropertiesElements', title:'<b>Elemente</b>',hidden:true, collapsible : true ,
	                 	    	width : 360,
	                 	    	defaults:{
		        	               labelWidth : 118,
		        	               width : 338,
		        	               msgTarget:'side'
		                 	   },
	                 	       items:[
	                 	          {xtype:'tbspacer',height:8}, 
	                 	          {xtype:'textfield', name:'specprop-link', itemId:'link', fieldLabel: 'Link', emptyText: 'link'}
	                 	       ]	
	                 	   },
	                 	   
	                 	   { xtype: 'fieldset',itemId:'specificPropertiesProductrelations', title:'<b>Productrelations</b>', hidden:true,collapsible : true,
	                 		  width : 360,
	                 		  defaults:{
		        	               labelWidth : 118,
		        	               width : 338,
		        	               msgTarget:'side'
		                 	   },
	                 	       items:[
	                 	         {xtype:'tbspacer',height:8},   
     	                		 {	xtype:'combo', 
     	                        	 itemId:'prodrel', name:'specprop-prodrel', 
     	                        	 store:   extVia.stores.initProductRelationsStore(),
     	                			 queryMode: 'local',
     	                			 displayField: 'dscr',
     	             	  			 emptyText: 'prodrel',
     	             	  			 valueField: 'value',
     	                			 fieldLabel: 'Beziehung'
     	                	     } 
	                 	       ]   
	                 	   },
   
	                         {xtype:'tbspacer', height:16},
	                        
	                         { xtype:'displayfield', value:'<b>Inhalte Produkt</b>' },	   


	                         {xtype:'textfield', name:'valueWork', itemId:'valueWork', fieldLabel: '&nbsp;Wert',  listeners:{change:valueChangeinfoSetter} }, 
	                         getUserComboCfg("Work"),
	                         {
	                 		        xtype: 'fieldcontainer',layout:'hbox',fieldLabel: '&nbsp;Datum',itemId:'changedatetimeWork',
	                 		        items:[  {xtype:'datefield', name:'changedateWork',  itemId:'changedateWork', flex:0.6,format : 'd.m.Y'},
	                 		                 {xtype:'tbspacer', width:16}, 
	                 		                 {xtype:'timefield', name:'changetimeWork', itemId:'changetimeWork',flex:0.4, triggerCls:'xty_form-trigger-timefield',format:'H:i:s'} 	 
	                 		                 ]
	                         },
	                         
	                         {xtype:'tbspacer', height:4},
	                        
	                         {
	                 		        xtype: 'fieldcontainer',layout:'hbox',fieldLasbel: 'Kopieren', hideEmptyLabel:false,
	                 		        items:[ 
	                 		              {xtype:'button', tooltip:'copyDown', itemId:'copyDown', scale:'small', handler:copyValues, iconCls:'xty_pgtoolbar-assignDown'},
	                 		              {xtype:'tbspacer', width:170},
	                 		              {xtype:'button', tooltip:'copyUp', itemId:'copyUp', scale:'small', handler:copyValues, iconCls:'xty_pgtoolbar-assignUp'}
	                 		         ]
	                         },
	                         
	                         { xtype:'displayfield', value:'<b>Inhalte Version</b>' },	   
	                         {xtype:'textfield', name:'valueVersion', itemId:'valueVersion', fieldLabel: '&nbsp;Wert', listeners:{change:valueChangeinfoSetter} }, 
	                         getUserComboCfg("Version"),
	                                                
	                         {
	                 		        xtype: 'fieldcontainer',layout:'hbox',fieldLabel: '&nbsp;Datum',itemId:'changedatetimeVersion',
	                 		        items:[  {xtype:'datefield', name:'changedateVersion', itemId:'changedateVersion', flex:0.6,format : 'd.m.Y'},
	                 		                 {xtype:'tbspacer', width:16}, 
	                 		                 {xtype:'timefield', name:'changetimeVersion', itemId:'changetimeVersion',flex:0.4, triggerCls:'xty_form-trigger-timefield',format:'H:i:s'} 	 
	                 		                 ]
	                         },
	                 		
	                         {xtype:'tbspacer', height:16}
	                     ]
	        	}
	        ],

	         buttons:{itemId:'myButtons', 
	        	items:[
	        	     {itemId:'reset',text:'Reset', disabled:true, handler:extVia.dialoges.resetButtonHandler},
			         {xtype:'tbspacer', width:70},
			         {itemId:'create',text:'Erstellen', disabled:true, handler:extVia.versionsProto.statics.getAddPIMRowOkButtonHandler},
			         {itemId:'cancel', text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler},
			         {itemId:'apply',text:'&Uuml;bernehmen', handler:extVia.dialoges.applyButtonHandler, disabled:true}
	         ] }     
	    })  ;
	    	
	    return pinfoRowDialog;
	    },
	    
	    
	    
	    
		getErrorDialog : function getErrorDialog(cfg){ 
		    
			var title =  cfg.title ? cfg.title :'Bildjob starten {action}';
			var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'Keine Datenbank Verbindung.<span class="xty_dialog-mainInstr-epobDscr" style="font-weight:normal" > {EpimError.dscr}</span> ';
			//var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'Image Daemon nicht verf&uuml;gbar.<span class="xty_dialog-mainInstr-epobDscr" style="font-weight:normal" > {EpimError.dscr}</span> ';
			var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Bitte wendem Sie sich an den Administrator {EpimError.advice}';
			//var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Die Struktur kann nicht mehr angezeigt werden {EpimError.advice}';
			
			var status = 'Error';
			
		    var epobDeleteDialog = Ext.create('widget.window', {
		    	    
			        width: extVia.dialoges.dialogDefaultWidth,
			        cls:'xty_Notification'+status,
			        x: cfg.x,
			        y: cfg.y,
			        mosdal:true,//normally true, here for proto use false 

			        title:title,
			        iconCls:extVia.dialoges.getWindowIconCls(status),
			        
			        plain: true,

			        items : [ {
			            border : false,
			            minHeight : 200,
			            defaults : {
			               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
			            },
			            items : [ 
			                     extVia.dialoges.getInstructionPanel ({
			                    	 mainInstr: mainInstr,
			                    	 suppInstr: suppInstr
			                     }),
			                     
//		                 		 { xtype:'displayfield', value:'<b>Fehlerbeschreibung</b>' },	 
//		                 		 { xtype:'displayfield', value:'Es existiert bereits ein Objekt mit dem gleichen Namen. Bitte verwenden Sie einen eindeutigen Namen.'},		                 		 
//		                 		 {xtype:'tbspacer', height:10},		
		                 		 
		                 		 { xtype:'displayfield', value:'<b>Details</b>' },	 		                 		 
		                 		 
		                 		 
		                 		 { 	 xtype:'fieldset', 
			                    	 //title:'<b>Details</b>', 
			                    	 collapsible : true,
			                    	 collapsed:true,
			                    	 
		                 			 items:[
		                 			        
		                 			        
		   		                 		 { fieldLabel:'Fehlercode',  xtype:'displayfield',   vsalue:'ora-4711: Foreignkey UniqueKey Constrain Violation'},	
		   		                 	    
		   		                 		 {  xtype:'displayfield',   
		   		                 			 value:
		                 			        	'<div style="width:360px;word-break:break-all;" class="xty_stacktrace">'+	
		                 			        	'' 
		   		                 				 +'ora-4711: Foreignkey UniqueKey Constrain Violation'
		   		                 				+'</div>'	
		   		                 				 },	
		   		                 		 
		   		                 		 
		   		                 	     {xtype:'tbspacer', height:14},			 
		   		                 		 { fieldLabel:'Stacktrace',  xtype:'displayfield'},	
		                 			        
		                 			        {    
		                 			        	autoScroll:true,
		                 			        	height:180,
		                 			        	width:370,
		                 			        	layout:'fit',
		                 			        	//fieldLabel:'Stacktrace', 
		                 			        	xtype:'displayfield', 
		                 			        	value:
		                 			        		
		                 			        	'<div style="width:360px;word-break:break-all;" class="xty_stacktrace">'+	
		                 			        	''	
		                 			        		+'Exception in thread "main" java.lang.NullPointerException'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.evaluateProperties(ResourceKeysSorter.java:83)'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.main(ResourceKeysSorter.java:181)' 
		                 			        		+'Exception in thread "main" java.lang.NullPointerException'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.evaluateProperties(ResourceKeysSorter.java:83)'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.main(ResourceKeysSorter.java:181)' 
		                 			        		+'Exception in thread "main" java.lang.NullPointerException'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.evaluateProperties(ResourceKeysSorter.java:83)'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.main(ResourceKeysSorter.java:181)' 
		                 			        		+'Exception in thread "main" java.lang.NullPointerException'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.evaluateProperties(ResourceKeysSorter.java:83)'
		                 			        		+'at com.viaMEDICI.gui.lty.dto.test.ResourceKeysSorter.main(ResourceKeysSorter.java:181)' 
		                 			        		+'</div>'	
		                 			        }
		                 			 ]	 
		                 		 },	

              			        {xtype:'tbspacer', height:14}		

			                 ]
			        	}
			        ],

			        buttons:[{xtype:'tbspacer', width:30},{text:'OK', handler:extVia.dialoges.okButtonHandler, executeAction:'DELETE'},{text:'Helpdesk', handler:extVia.dialoges.noButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}]      
			           
			    }) ;
			    	
			    return epobDeleteDialog;
		},    
	    
    
	  getLookTransformerDialog : function getLookTransformerDialog(cfg){ 
	      
	        var title =  'Generate Look';
	        var mainInstr =  'Look Transformer generated Look {GRAPE} ';

	        var suppInstr = 'Dateien: GRAPE_Look.css  viaExt_GRAPE_Look.css   GRAPE_NAVI.css ';

	        
	      var lookTransformerDialog = Ext.create('widget.window', {         
	            width: 420,
	            x: cfg.x,
	            y: 120, //cfg.y ,
	            modal:true,
	            title:title,
	            iconCls:extVia.dialoges.getWindowIconCls('Information'),
	            plain: true,
	            bodyStyle : 'background-color:white;',
	            items : [ {
	                border : false,
	                minHeight : 200,
	                style : 'background-color:white;',
	                itemId:'dialogBody',
	                items : [ 
	                         extVia.dialoges.getInstructionPanel ({
	                           mainInstr: mainInstr,
	                           suppInstr:suppInstr
	                         })
	                         ]
	  
	               },

                 { xtype:'fieldset', title:'<b>Details<b>', collapsible : true, cosllapsed:true, 
	                 style : 'background-color:white;',
                   margin:'4 4 4 4',
                   items:[
                          { xtype:'displayfield', 
                            value:'  generateLook[GRAPE]<br>'+
                            'line[12]: [/* $Revision: 1.69.6.7 $] revision[1.1.2.1]<br>'+
                            '<b>readCUSTOMVariables[GRAPE]</b> [&raquo;]<br>'+
                            'wrongdefVars[0][  ] innerWrongdefVars[0] <br>'+
                            'undefVars[0][  ] innerUndefVars[0] <br>'+
                            'emptyVars[0][  ] innerEmptyVars[0]<br>'+
                            'line[387]: [/* $Revision: 1.69.6.7 $] revision[1.52]<br>'+
                            '<b>readVariables[GRAPE]</b> [&raquo;]<br>'+
                            'wrongdefVars[0][  ] innerWrongdefVars[0] <br>'+
                            'undefVars[0][  ] innerUndefVars[0] <br>'+
                            'emptyVars[0][  ] innerEmptyVars[0]<br>'+
                            '<b>generateLook[GRAPE]</b> [&raquo;]<br>'+
                            'wrongdefVars[0][  ] innerWrongdefVars[0] <br>'+
                            'undefVars[0][  ] innerUndefVars[0] <br>'+
                            'emptyVars[0][  ] innerEmptyVars[0]'  
                           
                          }
                   ]   
                 },  
	            ],
	            buttons:[{xtype:'tbspacer', width:30},
	              {text:'&Uuml;bernehmen', handler:function(button ){ 
	              }},
	              {text:'Nochmal',  handler:function(button ){ 
	              }},
	              {text:'Abbrechen', handler:function(button ){button.ownerCt.ownerCt.hide();   }}
	            ]      
	        }) ;
	          
	        return lookTransformerDialog;
	  },	    
	    
	  
	  
	  
	  
	  
	  
	getDeleteEpobDialog : function getDeleteEpobDialog(cfg){ 
	    
        var title =  cfg.title ? cfg.title :'L&ouml;schen';
        var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'M&ouml;chten Sie den {Epobtyp} <i style="font-weight:normal">Name</i>  wirklich l&ouml;schen?';
    
		
        var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'M&ouml;chten Sie die ausgew&auml;hlten Objekte aus dem Produkt l&ouml;schen?';
        var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Zuordnung l&ouml;schen von 21 Texten, 66 Bildern, &hellip;';
      
        
        var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'102 Bilder, 12 Grafike, 400 Texte, 1 Dokument, 45 Produktabellen, 666 Redaktionelle Tabellen, 10 Audios, 33 Videos';
        // M&ouml;chten Sie die ausgew&auml;hlten Sammlungsobjekte aus der Sammlung entfernen?
        // Zuordnung l&ouml;schen von n Texten, n Bildern, &hellip;
        
        
        
       
	    var epobDeleteDialog = Ext.create('widget.window', {
	    	    
		        width: 420,
		        x: cfg.x,
		        y: 120, //cfg.y ,
                modal:true,

		        title:title,
		        iconCls:extVia.dialoges.getWindowIconCls('Question'),
		        
		        plain: true,

		        items : [ {
		            border : false,
		            minHeight : 200,
		            
		            itemId:'dialogBody',
		            
		            defaults : {
		               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
		            },
		            items : [ 
		                     extVia.dialoges.getInstructionPanel ({
		                    	 mainInstr: mainInstr,
		                    	 suppInstr:suppInstr
		                     })
		                     ]
  
		        	}
		        
		         ,{border:false, hidden:true, itemId:'dackel', heiaght:100, html:'<img style="margin-left:120px; margin-bottom:40px; height:200px;" src="../img/loading/augenaufschlag.gif">'}
		        
		        
		        ],
		        
		        listeners:{
		          hide: function(){
		          },
              close: function(){
              }
		          
		        },

		        buttons:[{xtype:'tbspacer', width:30},
//		          {text:'Entfernen', handler:extVia.dialoges.okButtonHandler, executeAction:'DELETE'},
//		          {text:'Nein', handler:extVia.dialoges.noButtonHandler},
		          
              {text:'L&ouml;schen', handler:function(button ){ 
              
               var dialog =  button.ownerCt.ownerCt;           
               dialog.getComponent('dackel').show(); 
               dialog.getComponent('dialogBody').getComponent('instructionPanel').setMainInstruction('Wirklich?'); 
              
              }},
              {text:'Nein',  handler:function(button ){ 
                
                var dialog =  button.ownerCt.ownerCt;           
                dialog.getComponent('dackel').hide(); 
                dialog.getComponent('dialogBody').getComponent('instructionPanel').setMainInstruction('Uff!'); 

                }},
		          
		          {text:'Abbrechen', handler:function(button ){button.ownerCt.ownerCt.hide();   }}
		        ]      
		           
		    }) ;
		    	
		    return epobDeleteDialog;
	},
	
  
   getClientConfigDialog : function getClientConfigDialog(cfg){ 
      
    var title =  cfg.title ? cfg.title :'Client-Konfiguration';
    //var mainInstr = 'Ihre Computerkonfiguration wird von EPIM nicht unterst&uuml;tzt.';
   // var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Installieren Sie den neuesten Firefox <br>und beachten Sie außerdem die zul&auml;ssigen Konfugurationen.';
    //var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Installieren Sie einen neueren Firefox.';

    
    
    
    var clientCfg = {
       os :'Windows',
       osversion:'XP', 
       browser:'Firefox',
       browserversion:'45.0',
       java:'8',
       javaversion:'1.82.0'
    }; 

    
    var okCfg = {
       os : null,
       osversion:null,
       browser:null,
       browserversion:null,
       java:null,
       javaversion:null
    }; 
    
    if ( (clientCfg.os=='Windows' &&  (clientCfg.osversion=='7' ||  clientCfg.osversion=='8') )
       || (clientCfg.os=='Mac OS' &&  (clientCfg.osversion=='10.8.4' ||  clientCfg.osversion=='10.11.3') )
    ) {
      okCfg.os = true;
    }
    else{ okCfg.os = false; }

    
if (okCfg.os){
    if ( (clientCfg.browser=='FF' ||  clientCfg.browser=='Firefox' ) ) {
      okCfg.browser = true;
    }
    else if ( (clientCfg.browser=='IE'  ||  clientCfg.browser=='Internet Explorer' )  ) {
      okCfg.browser = true;
    }
    else{ okCfg.browser = false; }

    
    if (okCfg.browser){
	    if ( (clientCfg.browser=='FF' ||  clientCfg.browser=='Firefox' ) &&  (clientCfg.browserversion.indexOf('4')==0)) {
	      okCfg.browserversion = true;
	    }
	    else if ( (clientCfg.browser=='IE'  ||  clientCfg.browser=='Internet Explorer' ) &&  (clientCfg.browserversion=='9' ||  clientCfg.browserversion=='10' ||  clientCfg.browserversion=='11') ) {
	      okCfg.browserversion = true;
	    }
	    else{ okCfg.browserversion = false; }
    }
}    
    
    
    var state='Warning';


   var supportedConfigs =  [                         
        { epimversion:'3.9',  os :'Windows', osversion:'7',  browser:'IE',  browserversion:'9 - 11',  java:'7',  javaversion:'1.7.25 - 1.7.69'  },
        { epimversion:'3.9',  os :'Windows', osversion:'7',  browser:'IE',  browserversion:'9 - 11',  java:'8',  javaversion:'1.80 - 1.802'  },
        { epimversion:'3.9',  os :'Windows', osversion:'7',  browser:'Firefox',  browserversion:'40.0 - 45.02',  java:'7',  javaversion:'1.80 - 1.802'  },
        { epimversion:'3.9',  os :'Windows', osversion:'7',  browser:'Firefox',  browserversion:'40.0 - <span style="font-size:13px;"> &infin;</span>',  java:'8',  javaversion:'1.80 - 1.802'  },
        
        { epimversion:'3.9',  os :'Windows', osversion:'8',  browser:'IE',  browserversion:'9-11',  java:'7',  javaversion:'1.7.25 - 1.7.69'  },
        { epimversion:'3.9',  os :'Windows', osversion:'8',  browser:'IE',  browserversion:'9-11',  java:'8',  javaversion:'1.80 - 1.802'  },
        { epimversion:'3.9',  os :'Windows', osversion:'8',  browser:'Firefox',  browserversion:'40.0 - 45.02',   java:'7',  javaversion:'1.7.25 - 1.7.69'  },
        { epimversion:'3.9',  os :'Windows', osversion:'8',  browser:'Firefox',  browserversion:'40.0 - <span style="font-size:13px;"> &infin;</span>',  java:'8',  javaversion:'1.80 - 1.802'  },
      
        { epimversion:'3.9',  os :'Mac OS', osversion:'10.8.4',  browser:'Firefox',  browserversion:'29',  java:'7',  javaversion:'1.7.25'  } ,
        { epimversion:'3.9',  os :'Mac OS', osversion:'10.11.3',  browser:'Firefox',  browserversion:'44',  java:'8',  javaversion:'1.7.4'  }                                           
] ;                                
 
   
   var supportedShowConfigs =  [];
   var i;
   var suppCfg;
   if (okCfg.os){
    for (i =0; i<supportedConfigs.length; i++){
     suppCfg = supportedConfigs[i];
     if  (clientCfg.os == suppCfg.os  && clientCfg.osversion == suppCfg.osversion) {
       supportedShowConfigs.push(suppCfg);
     }
    }
   }
   else{
    for (i =0; i<supportedConfigs.length; i++){
     suppCfg = supportedConfigs[i];
     if  (clientCfg.os == suppCfg.os ) {
       supportedShowConfigs.push(suppCfg);
     }
    }
   }
  
  
    
   
    
    var everythingOK = false;
    
    everythingOK  = state=='OK';
    
    var suppInstr = 'Ihre Computerkonfiguration wird so von EPIM nicht unterst&uuml;tzt.';
    var mainInstr = 'Installieren Sie einen unterst&uuml;tzen Browser.';
    
    //var mainInstr = 'Installieren Sie eine unterst&uuml;tze Browserversion.';

    if (everythingOK){
       suppInstr = 'Ihre Computerkonfiguration wird von EPIM unterst&uuml;tzt.'; 
       mainInstr = 'Alles OK';
    }

 
    
    
    var instructionPanelCfg = extVia.dialoges.getInstructionPanelCfg ({
                           mainInstr: mainInstr,
                           suppInstr: suppInstr
                         });
    
                         
                         
     var getButtonStyle = function(isOK){ 
      return isOK ? 'border: 1px solid #549C00;backsground-color:#DFF2BF;' : isOK===false ? 'border: 2px solid red; background-color:#FFBABA;' : null; 
     };                 
     var getButtonIconCls = function(isOK){ 
      return isOK ? 'xty_icon xty_iconOK' : isOK===false ? 'xty_icon xty_iconError' : 'xty_icon xty_iconUnknown'; 
     };                      
    
                 
     var checkedClientPanelCfg =   {
      border:false,
      layout:'hbox',
      margin:'14 0 6 0',
      cls:'xty_checked-states-panel',
      defaults:{
        xtype:'button',
        cls:'xty_iconError',
        margin:'0 0 0 8',
        iconCls:'xty_icon xty_iconUnknown',
        iconAlign:'bottom',
        minWidth:80,
        height:40 
        },
      items:[
      
        
      {
        text: '<b>Betriebs system</b><br>&nbsp;'+clientCfg.os+' '+clientCfg.osversion, 
        style: getButtonStyle(okCfg.os), iconCls:getButtonIconCls(okCfg.os) 
      },
      {
        text: '<b>Browser</b><br>&nbsp;'+clientCfg.browser, 
        style: getButtonStyle(okCfg.browser),  iconCls: getButtonIconCls(okCfg.browser) 
      },           
      {
        text: '<b>Browserversion</b><br>&nbsp;'+clientCfg.browserversion,
        style: getButtonStyle(okCfg.browserversion),  iconCls: getButtonIconCls(okCfg.browserversion) 
      },
      
      {
        text: '<b>Java</b><br>'+clientCfg.java,
        style: getButtonStyle(okCfg.java),  iconCls: getButtonIconCls(okCfg.java) 
      },
      {
        text: '<b>Javaversion</b><br>'+clientCfg.javaversion ,
        style: getButtonStyle(okCfg.javaversion),  iconCls: getButtonIconCls(okCfg.javaversion) 
      }
      ]

      };                    
                         
                         
     instructionPanelCfg.items=[
      instructionPanelCfg.items[0],
     
      instructionPanelCfg.items[1],
       checkedClientPanelCfg
      
      ];
                         
               
      
    
      var clientConfigDialog = Ext.create('widget.window', {
            
            width: 580,
            x: cfg.x,
            y: cfg.y,
            cls:'xty_window'+state,
            title:title,
            iconCls:extVia.dialoges.getWindowIconCls(state),
            
            plain: true,

            items : [ {
                border : false,
                minHeight : 200,
               
                defaults : {
                   stxyle : 'margin:0px 5px 0px 6px;'
                },
                items : [ 
                         instructionPanelCfg,
                         
                         {
                          xtype:'grid',
                          id:'supportedConfigsGrid',
                          hidden: everythingOK,
                          title:'unterst&uuml;tzte Konfigurationen',
                          margin:'0 5 0 6',
                          heisght:80,
                          columns:[                    
                          
                           {header:'Betriebssystem',dataIndex:'os', widath:80, hidden: okCfg.os,
                            renderer:  function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                              return value + ' '+ record.get('osversion'); 
                            }
                           },
                           //{header:'Version',dataIndex:'osversion', width:50},
                           {header:'Browser',dataIndex:'browser', wjidth:60},
                           {header:'Version',dataIndex:'browserversion', widjth:80},                         
                           {header:'Java',dataIndex:'java', wijdth:50},
                           {header:'Version',dataIndex:'javaversion', wjidth:100}
                          
                          
                          
                          ],
                          
                          getColumnName:function(){                            
                           var columnFieldName = this.features[0].getGroupField();
                           var i;
                           for (i = 0; i < this.columns.length; i++){
                            if (columnFieldName ==  this.columns[i].dataIndex && this.columns[i].headerDscr){
                              columnFieldName = this.columns[i].headerDscr;
                            } 
                           }  
                           return  columnFieldName ;
                          },
                           features: [Ext.create('Ext.grid.feature.Grouping',{
                                groupHeaderTpl: '{[Ext.getCmp("supportedConfigsGrid").getColumnName()]} : {name} ({rows.length} unterst&uuml;tzte Konfiguration{[values.rows.length > 1 ? "en" : ""]})'
                            })], 
                          store :  Ext.create('Ext.data.Store', {
                            storeId:'usedEpobStore',
                            model: Ext.define('usedEpob', {extend: 'Ext.data.Model', 
                             fields: [{type: 'string', name:'epimversion'} , {type: 'string', name:'os'},{type: 'string', name: 'osversion'},{type: 'string', name: 'browser'},{type: 'string', name: 'browserversion'},{type: 'string', name: 'java'},{type: 'string', name: 'javaversion'}]
                            }),
                            data: supportedShowConfigs
                          })

                         },
                         {xtype:'tbspacer', height:8}
                         
                         ]
              }
            ],

            buttons:[{xtype:'tbspacer', width:30},{text:'OK', handler:extVia.dialoges.okButtonHandler}]      
               
        }) ;
          
        return clientConfigDialog;
  },   
  
   getDeleteUsedEpobDialog : function getDeleteUsedEpobDialog(cfg){ 
      
    var title =  cfg.title ? cfg.title :'{Epobtyp} l&ouml;schen';
    var mainInstr =  cfg.mainInstr ? cfg.mainInstr :'M&ouml;chten Sie den {Epobtyp} <i style="font-weight:normal">Name</i> wirklich l&ouml;schen?';
    var suppInstr =  cfg.suppInstr ? cfg.suppInstr :'Der {Epobtyp} wird in folgenden {Epobtypen} verwendet.';

      var usedEpobDeleteDialog = Ext.create('widget.window', {
            
            width: extVia.dialoges.dialogDefaultWidth,
            x: cfg.x,
            y: cfg.y,

            title:title,
            iconCls:extVia.dialoges.getWindowIconCls('Question'),
            
            plain: true,

            items : [ {
                border : false,
                minHeight : 200,
                defaults : {
                   style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
                },
                items : [ 
                         extVia.dialoges.getInstructionPanel ({
                           mainInstr: mainInstr,
                           suppInstr: suppInstr
                         }),
                         
                         {
                          xtype:'grid',
                          heisght:80,
                          columns:[
                          
                           {header:'<div class="xty_icon xty_iconWarning" title="Warnungen" style="padding-left:18px;height:16px;margin-top:1px !important;" ></div>',dataIndex:'required',width:32,
                             renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                              if (value){return '<span class="xty_requiredStar"  title="Das Objekt ist ein erforderliches Feld im verwendetem Objektyp" style="font-size:22px !important;padding-left:4px;" >*</span>'; }
                             }
                           },
                          
                           {header:'Epob', dataIndex:'name', width:220,
                           
                           renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                                return '<div title="'+record.get('epobType')+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+record.get('epobType')+'"> &nbsp;&nbsp;&nbsp;'+value+'</div>';
                            }
                           
                           },
                           {header:'EPIM-Id',dataIndex:'id',width:40,hidden:true},
                           {header:'Besitzer',dataIndex:'user'}
                          ],
                          
                          listeners:{
                           itemdblclick:function(view , record, item, index, e, eOpts ){
                             window.alert("Double-click not implemented! This is a demo only.");
                           }
                          },
                          
                          store :  Ext.create('Ext.data.Store', {
                            storeId:'usedEpobStore',
                            model: Ext.define('usedEpob', {extend: 'Ext.data.Model', 
                             fields: [{type: 'string', name:'epobType'},{type: 'string', name:'name'},{type: 'string', name: 'user'},{type: 'boolean', name: 'required'},{type: 'string', name: 'id'}]
                            }),
                            data: [
                              { epobType:'Dashboard' , name:'mein Board', user:'Simon Lederer',id:'231r', required:0,url:''},
                              { epobType:'Chart' , name:'Automarkt', user:'Hajo St&auml;ck',id:'431r', required:1,url:''},
                              { epobType:'Product' , name:'Fixit Spezialbohrer', user:'Hajo St&auml;ck',id:'431r',required:0,url:''},
                              { epobType:'Hierarchy' , name:'Bohrmaschinen', user:'Bernard Purdie',id:'4316', required:0,url:''},
                              { epobType:'Publication' , name:'Katalog', user:'Boris Strugatzki',id:'4317',required:0, url:''}

                          ]
                          })

                         },
                         {xtype:'tbspacer', height:8}
                         
                         ]
              }
            ],

            buttons:[{xtype:'tbspacer', width:30},{text:'L&ouml;schen', handler:extVia.dialoges.okButtonHandler, executeAction:'DELETE'},{text:'Nein', handler:extVia.dialoges.noButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}]      
               
        }) ;
          
        return usedEpobDeleteDialog;
  },  
  
  
	getCloseEpobDialog : function getCloseEpobDialog(cfg){ 
		    
		    var epobCloseDialog = Ext.create('widget.window', {
		    	    
			        width: extVia.dialoges.dialogDefaultWidth,
			        x: cfg.x,
			        y: cfg.y,

			        title:'{Epobtyp} schliessen',
			        iconCls:extVia.dialoges.getWindowIconCls('Information'),

			        
			        plain: true,

			        items : [ {
			            border : false,
			            minHeight : 200,
			            defaults : {
			               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
			            },
			            items : [ 
			                     extVia.dialoges.getInstructionPanel ({
			                    	 mainInstr:'{Epobtyp} <span class="xty_dialog-mainInstr-epobDscr" style="font-weight:normal">{EpobDscr}</span> wurde ge&auml;ndert',
			                    	 suppInstr:'M&ouml;chten Sie die &Auml;nderungen speichern?'
			                     })
			                 ]
			        	}
			        ],

			        buttons:[{xtype:'tbspacer', width:30},{text:'Ja', handler:extVia.dialoges.okButtonHandler, executeAction:'SAVE'},{text:'Nein', handler:extVia.dialoges.noButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}]           
			    });
			    return epobCloseDialog;
		},   
  
	getRuleBasedDialog : function getRuleBasedDialog(cfg){ 

		var  galleryProd  =	 extVia.dialoges.getGalleryView({epobType:'PRODUCTS',pageStart:0,pageSize:6});
		
	    var ruleBasedDialog = Ext.create('widget.window', {
	    	    
		        width: 520,

		        title:'Regelbasiert hinzuf&uuml;gen',
		        iconCls:extVia.dialoges.getWindowIconCls('Information'),

		        y:50,
		        modal:true,
		        plain: true,

		        items : [ {
		            border : false,
		            minHeight : 200,
		            defaults : {
		               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
		            },
		            items : [ 
		                     extVia.dialoges.getInstructionPanel ({
		                    	 mainInstr:'Legen Sie Regeln f&uuml;r Ihre Produktplanung fest.',
		                    	 suppInstr:'Die Produktbeziehungen werden aufgel&ouml;st und die Produkte der Planung hinzugef&uuml;gt'
		                     }),
		                     
		                 
		                     { xtype:'displayfield', value:'<b>Produkte</b>' },
		                     { xtype:'combo', fieldLabel:'Beziehungen' },
		                     { xtype:'combo', fieldLabel:'Beziehungen von Beziehungen' },
//	                 		 { 	 xtype:'fieldset',title:'<b>Produktbeziehungen</b> » ', collapsible : true,coldlapsed:true,
//	                 			 
//		                    	 items:[ { xtype:'combo', fieldLabel:'Beziehungen' }]
//	                 		 },
//	                 		 
	                 	    {xtype:'tbspacer', height:15},	
	                 		 { xtype:'displayfield', value:'<b>Optionen</b>' },	
	            	         { xtype:'checkbox', name:'p_bCopyNotEdiAttri' , fieldLabel:'&nbsp;Beziehungen von Beziehungen kopieren', labelWidth : 330 },
	            	         { xtype:'checkbox', name:'p_bDeleteAvailPrev' , fieldLabel:'&nbsp;Vorhandene Beziehungen aufl&ouml;sen' , labelWidth : 330},

		                              
	                         
	                 		 {xtype:'tbspacer', height:5},	
		                 	 { xtype:'fieldset', title:'<b>Regeln</b> » ', collapsible : true,colslapsed:true, tools:[{id:'plus'}],
		                 			 items:[
		                 			        { width: 420, xtype:'displayfield', value:'Wenn Bez dann fez ' },
		                 			        { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbspBez =1</li><li>&nbsp;&bull;&nbsp;fez =2</li></ul>'}
		                 			 ]	 
		                 		 },	
		                 		{xtype:'button',text:'Regel anwenden', style:'margin-top:-6px;margin-left:14px;'},
		                 		{xtype:'tbspacer', height:15},
		                 		
		                 		 { xtype:'fieldset', title:'<b>resultiernde Produkte</b>', collapsible : true,collapsed:true, items:[ galleryProd ]	 },
			                 	 {xtype:'button',text:'Resultiernde &uuml;bernehmen', style:'margin-top:-4px;margin-left:14px;'},
			                 		{xtype:'tbspacer', height:15},
		                 		 {xtype:'tbspacer', height:5},
		                         
		                    {xtype:'tbspacer', height:15}	
		                     
		                 ]
		        	}
		        ],

		        buttons:[{xtype:'tbspacer', width:30},{text:'Regel &uuml;bernehmen',handler:extVia.dialoges.cancelButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}]           
		    });
		    return ruleBasedDialog;
	},   
	
	
	getSelectTemplateDialog : function getSelectTemplateDialog(cfg){ 

		    var selectTemplateDialog = Ext.create('widget.window', {
		    	    
			        width: 520,

			        title:'Vorhandene Planungen hinzuf&uuml;gen',
			        iconCls:extVia.dialoges.getWindowIconCls('Information'),

			        y:50,
			        //modal:true,
			        plain: true,

			        items : [ {
			            border : false,
			            minHeight : 200,
			            defaults : {
			               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
			            },
			            items : [ 
			                     extVia.dialoges.getInstructionPanel ({
			                    	 mainInstr:'W&auml;hlen Sie vorhandene Planungen.',
			                    	 suppInstr:'Sie k&ouml;nnen Produkte direkt oder verlinkt &uuml;bernehmen'
			                     }),
			                     
			                 
			                     { xtype:'displayfield', value:'<b>Publikationen mit StandardProduktplanungen</b>' },
			                     { xtype:'combo', fieldLabel:'Publikationen' },

 
		                 	    {xtype:'tbspacer', height:15},	
		                 		 { xtype:'displayfield', value:'<b>Optionen</b>' },	
		            	         { xtype:'checkbox', name:'p_bCopyNotEdiAttri' , fieldLabel:'&nbsp;Beziehungen von Beziehungen kopieren', labelWidth : 330 },
		            	         { xtype:'checkbox', name:'p_bDeleteAvailPrev' , fieldLabel:'&nbsp;Vorhandene Beziehungen aufl&ouml;sen' , labelWidth : 330},

			                              
		                         
		                 		 {xtype:'tbspacer', height:5},	
			                 	 { xtype:'fieldset', title:'<b>Produkte Planung der Publikation</b> » ABC', height:300, collapsible : true,colslapsed:true, tools:[{id:'plus'}],
			                 		items:[
			                 			    extVia.publications.statics.getSelectedPlanungenCfg()		
									  ]	 
			                 		 },	
			                 		//{xtype:'button',text:'Regel anwenden', style:'margin-top:-6px;margin-left:14px;'},
			                 		{xtype:'tbspacer', height:15},
		
				                 	// {xtype:'button',text:'Resultiernde &uuml;bernehmen', style:'margin-top:-4px;margin-left:14px;'},
				                 		{xtype:'tbspacer', height:15},
			                 		 {xtype:'tbspacer', height:5},
			                         
			                    {xtype:'tbspacer', height:15}
			                     
			                 ]
			        	}
			        ],

			        buttons:[{xtype:'tbspacer', width:30},{text:'Produkte &uuml;bernehmen',handler:extVia.dialoges.cancelButtonHandler},{text:'Planung &uuml;bernehmen',handler:extVia.dialoges.cancelButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}]           
			    });
			    return selectTemplateDialog;
		},
    
    
    
    getQuickviewTeaserPanel : function getQuickviewTeaserPanel(cfg){ 
    
     var getItemCfg = function(item){
      var itemCfg;
       if (item.type === extVia.ui.dto.ety.IMAGE){
//         var landscape = true;
//         
//         var aspectRatio = item.width/ img.height;
//         var landscape = aspectRatio>1;
//         
//         if (landscape){
////          item.width = 1000;
////          item.height = 714;
//          
//          if (!item.srcUrl){
//            item.srcUrl='../img/fakes/success-strategies.jpg';
//          }
//
//         }
//         else{// portrait
////          item.width = 517;
////          item.height = 714;
//          if (!item.srcUrl){ item.srcUrl='../img/fakes/success-strategies-portrait.jpg';}
//         }

         item.aspectRatio = item.width / item.height;
         var aspectRatio = item.aspectRatio;
         var imgHeight = item.height;
         var imgWidth = item.width; 
         var width='' ;
         var height='';
         
         if (aspectRatio > 1){
           width = 'width:'+(imgWidth > 180 ? 180 : imgWidth) +'px;';
         }
         else{
           height = 'height:'+( (imgHeight === undefined || imgHeight === 0 || imgHeight ) > 227 ? 220 : imgHeight ) +'px;';
         }
        itemCfg = {
          cls:'xty_quickview-fieldset-item xty_quickview-fieldset-image-item', 
          //style:'text-alsign:center; vertical-align:middle;',
           margin:'4 0 0 0',
          itemId:item.name,
          border:false,
          html:'<img id="'+item.name+'-img"  style="width:120px;" src="'+item.srcUrl+'"/>'
          //html:'<img id="'+item.name+'-img"  style="'+width+height+'" src="'+item.srcUrl+'"/>'
          };
       }
       else {

        if (item.type === extVia.ui.dto.ety.LINK){
         item.value += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="cursor:pointer;text-decoration:none;" target="_blank" href="'+item.href+'">[&raquo;]</a>' ;
        }

//        itemCfg = {
//            fieldLabel: item.dscr,
//            itemId:item.name,
//            hidden:item.hidden,
//            cls:'xty_quickview-fieldset-item',
//            iconCls:item.cssclass,
//            fieldBodyCls:'xty_cntv',
//            labelClsExtra:'xty_dscr',
//            value: item.value,
//            name: item.name 
//        };

        itemCfg = {
        fieldLabel: item.dscr,
        hidden:item.hidden,
        itemId:item.name,
        cls:item.iconCls,
        xtype: 'displayfield',
        margin:'0 0 0 0',
        cls:'xty_quickview-fieldset-item',
        fieldBodyCls:'xty_cntv',
        labelClsExtra:'xty_dscr',
        value: item.value,
        name: item.name 
        };
      } 
      return itemCfg;
     };
    
     var qvteaserDto = cfg.dto; 
     
     var quickviewTeaserPanelCfg  = {
        xtype:'fieldset',
        collapsible:true,
        collapsed:true,
//        width:containerWidth,
        itemId:'quickview-teaser-panel',
        cls:'xty_quickview-teaser-panel',

        margin:'10 10 14 8',
        defaults: {anchor: '100%', border:false},
        layout: 'column',

        lsayout: {
         type: 'column',
         columns: 2
        }
        
       };

       quickviewTeaserPanelCfg.items =
       [{  columnWidth: .3, items:[] },
        { columnWidth: .7, items:[] }
       ];

      
       
       var i;
       for (i=0; i< qvteaserDto.items.length ; i ++){
         var qvteaserItem = qvteaserDto.items[i];
         
        // quickviewTeaserPanelCfg.items.push(getItemCfg(qvteaserItem));
         
         if (i===0){
           quickviewTeaserPanelCfg.items[0].items.push(getItemCfg(qvteaserItem));
         }
         else{
          quickviewTeaserPanelCfg.items[1].items.push(getItemCfg(qvteaserItem));
         }
       }
       return quickviewTeaserPanelCfg;
    }
    
	
};


extVia.dialoges = new extVia.dialoges();


/*
 * 
 * $Revision: 1.69.6.7 $
 * $Modtime: 05.02.13 9:56 $ 
 * $Date: 2019/12/11 15:21:14 $
 * $Author: lowen $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 