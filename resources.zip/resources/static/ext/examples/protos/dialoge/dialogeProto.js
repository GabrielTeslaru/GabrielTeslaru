/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

Commercial Usage
Licensees holding valid commercial licenses may use this file in accordance with the Commercial Software License Agreement provided with the Software or, alternatively, in accordance with the terms contained in a written agreement between you and Sencha.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/
Ext.require([
    'Ext.window.Window',
    'Ext.tab.*',
    'Ext.toolbar.Spacer',
    'Ext.layout.container.Card',
    'Ext.layout.container.Border'
]);

Ext.onReady(function(){

    Ext.util.Region.override({
        colors: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
        nextColor: 0,
        show: function(){
            var style = {
                display: 'block',
                position: 'absolute',
                top: this.top + 'px',
                left: this.left + 'px',
                height: ((this.bottom - this.top) + 1) + 'px',
                width: ((this.right - this.left) + 1) + 'px',
                opacity: 0.3,
                'pointer-events': 'none',
                'z-index': 9999999
            };
            if (!this.highlightEl) {
                style['background-color'] = this.colors[this.nextColor];
                Ext.util.Region.prototype.nextColor++;
                this.highlightEl = Ext.getBody().createChild({
                    style: style
                });
                if (this.nextColor >= this.colors.length) {
                    this.nextColor = 0;
                }
            } else {
                this.highlightEl.setStyle(style);
            }
        },
        hide: function(){
            if (this.highlightEl) {
                this.highlightEl.setStyle({
                    display: 'none'
                });
            }
        }
    });

	   
    
    var dialogDefaultWidth =420;
    
    var pos_col_1 = 30, 
    pos_col_2 = 1*dialogDefaultWidth+2*pos_col_1,  
    pos_col_3 = 2*dialogDefaultWidth+3*pos_col_1, 
    pos_col_4 = 3*dialogDefaultWidth+4*pos_col_1; 
    
    
    pos_col_5 = 4*dialogDefaultWidth+4*pos_col_1; 
   
    var pos_row_1 = 100, pos_row_2 = 450,  pos_row_3 = 670  , pos_row_4 =800;
    

     pos_row_5 =1200;
    
    
	var availableEpobsStore = extVia.stores.initAvailableEpobsStore({pageSize:extVia.stores.mengengridPageSize});

    
	
	extVia.dialoges.getMoveProductsDialog({x: pos_col_3,y: pos_row_3}).show();

	//var addWidgDialog = extVia.dialoges.getAddWidgetDialog({x: pos_col_2,y: pos_row_1-40});
	//addWidgDialog.show();

    addEpobDialog = extVia.dialoges.getAddEpobDialog({x: pos_col_3 ,y: pos_row_1});
    addEpobDialog.show();
    
    
    var cfgWidgDialog = Ext.create('widget.window', {
        width: extVia.dialoges.dialogDefaultWidth,
        x: pos_col_2,
        y: pos_row_2,

        title: 'Widget konfigurieren (reset Variante)',
        iconCls:extVia.dialoges.getWindowIconCls('Information'),
        plain: true,

        items : [ {
            border : false,
            minHeight : 200,
            itemId:'myFormPanel',
            xtype:'form',
            
            listeners:{
            	dirtychange:function( basic, dirty, eOpts){	
            		extVia.dialoges.notifyFormEvent('dirtychange','dirty',dirty,this.ownerCt.title);
            		var dialogButtons = this.ownerCt.getComponent('myButtons');
            		if (dirty) dialogButtons.getComponent('apply').enable();
            		else dialogButtons.getComponent('apply').disable();
            		if (dirty) dialogButtons.getComponent('save').enable();
            		else dialogButtons.getComponent('save').disable();          		
            		
            		if (dirty) {
            			dialogButtons.getComponent('reset').enable();
            			dialogButtons.getComponent('reset').show();
            			}
            		else {
            			dialogButtons.getComponent('reset').disable();
            		}
            	}
             },
            fieldDefaults : {
            // msgTarget : 'side',
            },
            defaults : {
               style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
               anchor : '100%',
               labelWidth : 120,
               width : 350
            },
            items : [
			  
                    
                     extVia.dialoges.getInstructionPanel ({ mainInstr:'gestalten Sie Ihr <i>{Widget}:</i>'  }),
                     
                            { xtype:'displayfield', value:'W&auml;hlen Sie <i>{das gew&uuml;nschte Objekt}</i>' },	
                            
                            
                    		 {xtype:'combo', 
                    			 store: availableEpobsStore,
                    			 queryMode: 'local',
                    			 itemId:'epobs',
                    			 labelSeparator : extVia.dialoges.getLabelSeparator4Required(), 
                    			 allowBlank:false,
                    			 displayField: 'name',
                 	  			 emptyText: 'Pick a object',
                 	  			 valueField: 'abbr',
                    			 fieldLabel: '&nbsp;verf&uuml;gbare Objekte'},
                            
                            {xtype:'tbspacer', height:16},
                            
                            { xtype:'displayfield', value:'Legen Sie das Anzeigeverhalten fest' },	
                            
                    		 {	xtype:'combo', 
                            	itemId:'sortby', 
                    			 store: 'sortbyStore',
                    			 queryMode: 'local',
                    			 displayField: 'dscr',
                 	  			 emptyText: 'Pick sorting',
                 	  			 valueField: 'id',
                 	  			 forceSelection:true,
                 	  			 value:'1',
                    			 fieldLabel: '&nbsp;Sortieren nach'},
                    			 
                            {xtype:'radiogroup', fieldLabel: '&nbsp;Reihenfolge', items:[  {boxLabel: 'ASC'}, {boxLabel: 'DESC'}]},
                            
                            {xtype:'checkboxgroup', fieldLabel: '&nbsp;Zeige', items:[  {boxLabel: 'Text'}, {boxLabel: 'in neuem Fenster'}]},
                            
                    		
                            {xtype:'tbspacer', height:16},
                            
                            { xtype:'displayfield', value:'Legen Sie die Erscheinungsfarbe fest' },	
                            
                            Ext.create('Ext.ux.ColorField', {
                   				xtype:'colorfield',
                   				labelWidth : 120,
                   				fieldLabel:  '&nbsp;Farbe',
                   				width : 350,
                   				value:'#A4C143',
                   				name: 'color'
                   				}),
                   				
                   			 {xtype:'tbspacer', height:10}
		
                     ]
        	}
        ],

        buttons:{itemId:'myButtons', items:[            
         {itemId:'reset',text:'reset',disabled:true,hidden :true,
       	 handler: function(){
    		 this.ownerCt.ownerCt.getComponent('myFormPanel').getForm().reset(); 
    	 }	 
     },{xtype:'tbspacer', width:30},{text:'Speichern',itemId:'save', disabled:true},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler},{itemId:'apply',text:'&Uuml;bernehmen', handler:extVia.dialoges.applyButtonHandler,disabled:true}] }  
    });
    //cfgWidgDialog.show();   
       

    


    var  deleteEpobDialog = extVia.dialoges.getDeleteEpobDialog({x: pos_col_1,y: pos_row_1 });
    deleteEpobDialog.show();

    //var  deleteManyEpobsDialog = extVia.dialoges.getDeleteEpobDialog({x: pos_col_1,y: pos_row_2-50, title:'Freigaben l&ouml;schen  <span style="margin:30px;color:#FFF;font-weight:normal;font-style:italic;">multicase</span>', mainInstr:'7 Freigaben ausgew&auml;hlt', suppInstr:'M&öuml;chten Sie diese Freigaben l&ouml;schen?'});
    //deleteManyEpobsDialog.show();
    
    //var getErrorDialog = extVia.dialoges.getErrorDialog({x: pos_col_1,y: pos_row_1 });
    //getErrorDialog.show();
    
    var  deleteUsedEpobDialog = extVia.dialoges.getDeleteUsedEpobDialog({x: pos_col_1,y: pos_row_1+200 });
    deleteUsedEpobDialog.show();
    
    

    
    var resOkCancelApplytWin = Ext.create('widget.window', {
        heisght: 220,
        width: dialogDefaultWidth,
        x: pos_col_1,
        y: pos_row_2+130,

        title: '{DialogHeader} must be the same as callingElement',
        
        iconCls:extVia.dialoges.getWindowIconCls('Information'),
        
        plain: true,
        items: [ 
                {
                  border:false,   
                  bodyStyle:'padding:5px 5px 5px',
                  items:[
                         {
                           border:false,  
                           bodyStyle:'padding:5px 5px 5px',   
                   	       html:'<div class="xty_dialog-mainInstr"><i>{mainInstruction}:</i> Handlungsaufforderung oder Zustand</div>'   
   
                          },
                         {
                           border:false,  
                           bodyStyle:'padding:5px 5px 5px',
                   	       html:'<div class="xty_dialog-supplementalInstr"><i>{supplementalInstruction}:</i> Handlungsaufforderung oder Frage. Erg&auml;nzend nicht wiederholend</div>'
                   	    	+'<br><br> Buttons: <br>reset= is on the left because it is dialogspecific Option <br> OK = do-Your-Action and close<br> Apply = do-Your-Action and NOT close<br> Cancel = close'
                         }	
                         ]
          		}                
                ],    
    	buttons:[{text:'Reset', tip:'it is an specific OptionsButton', handler:extVia.dialoges.resetButtonHandler},{xtype:'tbspacer', width:60},{text:'OK', tooltip:'save and close', handler:extVia.dialoges.okButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler},{text:'&Uuml;bernehmen' , handler:extVia.dialoges.applyButtonHandler,tooltip:'Save not close'}]
    });
    resOkCancelApplytWin.show();
    

    
   var saveErrorDetailsWin = Ext.create('widget.window', {
        heisght: 220,
        width: dialogDefaultWidth,
        x: 800,
        y: 50,

        title: 'Zuordnung speichern{1}',
        
        iconCls:extVia.dialoges.getWindowIconCls('Error'),
        
        plain: true,
        items: [ 
                {
                  border:false,   
                  bodyStyle:'padding:5px 5px 5px',
                  items:[
                         {
                           border:false,  
                           bodyStyle:'padding:5px 5px 2px',   
                           html:'<div class="xty_dialog-mainInstr">Die maximale Gr&ouml;sse des Feldes <i>Artikelnummer{2}</i> ist &uuml;berschritten.</div>'
                           //html:'<div class="xty_dialog-mainInstr">Die maximale Gr&ouml;sse eines Feldes  ist &uuml;berschritten.</div>'  
   
                          },
                         {
                           border:false,  
                           bodyStyle:'padding:0px 5px 5px',
                           //html:'<div class="xty_dialog-supplementalInstr">Erlaubte Gr&ouml;sse 50 Zeichen aktuelle Gr&ouml;sse 70 Zeichen.<br> &Auml;ndern Sie Ihre Eingabe.</div>',
                           html:'<div class="xty_dialog-supplementalInstr">Erlaubte Gr&ouml;sse 50{3} Zeichen aktuelle Gr&ouml;sse 70{4} Zeichen.</div>',
                           hxtml:'<div class="xty_dialog-supplementalInstr">&Auml;ndern Sie Ihre Eingabe.'
                         }, 
                         {
                           border:false,  
                           bodyStyle:'padding:10px 5px 5px',
                           html:'<div class="xty_dialog-supplementalInstr">Das Attribut <i>dynattriXY{5} / EPIM-Id{6}</i> ist Bestandteil einer Metadatengenerierung.<br> Lesen Sie dazu in der Onlinehilfe das Thema: Parametrisierte Metadatengenerierung. </div>'
                         } 
                         ]
              }                
                ]   
      //buttons:[{xtype:'tbspacer', width:60},{text:'OK', tooltip:'save and close', handler:extVia.dialoges.okButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler},{text:'&Uuml;bernehmen' , handler:extVia.dialoges.applyButtonHandler,tooltip:'Save not close'}],
    });
    //saveErrorDetailsWin.show({x: pos_col_1,y: pos_row_1 });
    //  extVia.dialoges.closeAllBut();
  
    //extVia.dialoges.getSaveAndUpdateAssignmentsDialog({x: pos_col_,y: pos_row_2}).show();
    
    

   
    
    extVia.dialoges.getMultiAssignmentsConflictDialog({x: pos_col_1,y: pos_row_4}).show();
    
    resOkCancelApplytWin.close();
    

    var  clientConfigDialog = extVia.dialoges.getClientConfigDialog({x: pos_col_2,y: pos_row_1 });
    clientConfigDialog.show();
    
    
    
    
    var lookTransformerDialog = extVia.dialoges.getLookTransformerDialog({x: pos_col_2,y: pos_row_1 });
    lookTransformerDialog.show();
    
    
    
    
    // extVia.dialoges.closeAllBut();

   Ext.QuickTips.init();
    
});

