 
 Ext.namespace('extVia.dummies','extVia.dummies.elements', 'extVia.dummies','extVia.dummies.images'   );
 
 
 // // explorer rows    
 extVia.dummies.images =

//              0         1       2        3           4            5           6        7         8          9        10      11      12              
//fields = [ "etypId","preview","name","filename","categories", "language","objectId","rootId","crossref","external","path","specid","isVar","etype","menuId", "imgWidth","imgHeight","hasDefaultImg" ];
 // fields : [  {name: 'etypId'},{name: 'preview'},{name:'name'},{name:'filename'}, {name:'categories'}, {name:'language'}, {name:'objectId'},{name:'rootId'},{name:'crossref'},{name:'external'}, {name:'path'},{name:'specid'},{name:'isVar'},{name:'etype'}, {name:'menuId'},{name: 'imgWidth'},{name:'imgHeight'},{name:'hasDefaultImg'} ]
 
 
 //data: 
[
   
{"etypId":"xty_epobImageVar","preview":"/preview/Roefix/Image/IM0008764.jpg?1438104038055","name":"CCC (-)","filename":"IM0008764.JPG","categories":"<span title=\"Masterkategorie\" class=\"xty_masterCat\">Objekt-Bild</span>","language":"-","objectId":"672131","rootId":"672130","crossref":"","external":false,"path":"/EPIMFS/daten/Archiv/Image/2013/1/23/IM0008764/IM0008764.JPG","specid":"372403","isVar":true,"etype":1011,"menuId":"epim_grid_menukevdwn","imgWidth":640,"imgHeight":480,"hasDefaultImg":true} 
    
// >>> PROD V4 Start (EPIM-7678) <<<    
// >>> PROD V4 End (EPIM-7678) <<<
];

// >>> PROD V4 Start (EPIM-7678) <<< 
   extVia.dummies.elasticResponse ={
     "took":1,"timed_out":false,"_shards":{"total":5,"successful":5,"failed":0},
    "hits":{"total":7931,"max_score":1.0,
    "hits":[
      {"_index":"ele_de","_type":"elementdata","_id":"9038","_score":1.0,
    "_source":
        {"epimId":9038,"root_obje_id":9037,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_UP_Gips-Maschinenputz_Sackbild_V1","addkeywords":"DE_UP_Gips-Maschinenputz_Sackbild_V1","creation_date":"2004-05-10T17:17:19","creation_user":"John Smith","creation_user_id":107,"change_date":"2008-07-22T14:07:37","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0000463.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\5\\\\10\\\\IM0000463","phy_preview_file":"../Image/IM0000463.JPG","orig_file_name":"IM0000463.EPS","imag_height":315,"imag_width":623,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"10:11","hierarchy_names":"Produkt-Bild:Preisliste/Katalog farbig"}
        },
      {"_index":"ele_de","_type":"elementdata","_id":"20038","_score":1.0,
    "_source":
      {"epimId":20038,"root_obje_id":20037,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_WD_Loch bei EPS bohren","addkeywords":"Loch bei EPS bohren EJOT STR U Verd�belung D�bel Zubeh�r Verarbeitung","creation_date":"2004-11-05T09:13:17","creation_user":"Jane Silver","creation_user_id":105,"change_date":"2008-07-11T12:55:56","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0002853.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\11\\\\5\\\\IM0002853","phy_preview_file":"../Image/IM0002853.JPG","orig_file_name":"IM0002853.EPS","imag_height":819,"imag_width":819,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"6:8:549","hierarchy_names":"Verarbeitungs-Bild:in Verarbeitung:WDVS"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"232557","_score":1.0,
    "_source":
      {"epimId":232557,"root_obje_id":232556,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"Randd�mmstreifen 80 / 10_DE_ES_Verpackungsbild_Produktbild","addkeywords":"Randd�mmstreifen 80 / 10_DE_ES_Verpackungsbild_Produktbild","creation_date":"2008-11-19T10:09:06","creation_user":"System Administrator","creation_user_id":2,"change_date":"2012-12-12T17:21:49","change_user":null,"change_user_id":null,"phy_file_name":"IM0006509.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2008\\\\11\\\\19\\\\IM0006509","phy_preview_file":"../Image/IM0006509.JPG","orig_file_name":"IM0006509.EPS","imag_height":629,"imag_width":1245,"imag_colouring":null,"imag_compression_rate":null,"imag_resolution":400,"hierarchy_ids":"10:11","hierarchy_names":"Produkt-Bild:Preisliste/Katalog farbig"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"9040","_score":1.0,
    "_source":
      {"epimId":9040,"root_obje_id":9039,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_UP_Wellness Hotel","addkeywords":"Wellness Hotel 510 610 Sauna Ref I","creation_date":"2004-05-10T17:17:19","creation_user":"John Smith","creation_user_id":107,"change_date":"2008-07-11T12:54:51","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0000464.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\5\\\\10\\\\IM0000464","phy_preview_file":"../Image/IM0000464.JPG","orig_file_name":"IM0000464.EPS","imag_height":819,"imag_width":819,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"3:4:516","hierarchy_names":"Objekt-Bild:Innen:Unterputze"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"9042","_score":1.0,
    "_source":
      {"epimId":9042,"root_obje_id":9041,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_UP_Hotel Wellness","addkeywords":"Hotel Wellness Sauna UP Ref I 510 610 Kalkputz Kalk","creation_date":"2004-05-10T17:17:20","creation_user":"John Smith","creation_user_id":107,"change_date":"2012-12-12T17:41:17","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0000465.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\5\\\\10\\\\IM0000465","phy_preview_file":"../Image/IM0000465.JPG","orig_file_name":"IM0000465.EPS","imag_height":819,"imag_width":819,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"3:5:515","hierarchy_names":"Objekt-Bild:Aussen:Unterputze"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"232559","_score":1.0,
    "_source":
      {"epimId":232559,"root_obje_id":232558,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"Randd�mmstreifen 120/10_DE_Verpackungsbild_Produktbild","addkeywords":"Randd�mmstreifen FL 120/10_DE_ES_Verpackungsbild_Produktbild","creation_date":"2008-11-19T10:09:07","creation_user":"System Administrator","creation_user_id":2,"change_date":null,"change_user":null,"change_user_id":null,"phy_file_name":"IM0006510.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2008\\\\11\\\\19\\\\IM0006510","phy_preview_file":"../Image/IM0006510.JPG","orig_file_name":"IM0006510.EPS","imag_height":629,"imag_width":1245,"imag_colouring":null,"imag_compression_rate":null,"imag_resolution":400,"hierarchy_ids":"10:11","hierarchy_names":"Produkt-Bild:Preisliste/Katalog farbig"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"9050","_score":1.0,
    "_source":
      {"epimId":9050,"root_obje_id":9049,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_UP_Wellness Dampfbad","addkeywords":"Wellness Dampfbad Sauna UP Ref I Kalkputz Kalkfarbe Fliese","creation_date":"2004-05-10T17:17:20","creation_user":"John Smith","creation_user_id":107,"change_date":"2008-07-11T12:54:51","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0000469.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\5\\\\10\\\\IM0000469","phy_preview_file":"../Image/IM0000469.JPG","orig_file_name":"IM0000469.EPS","imag_height":819,"imag_width":819,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"3:4:516","hierarchy_names":"Objekt-Bild:Innen:Unterputze"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"232561","_score":1.0,
    "_source":
      {"epimId":232561,"root_obje_id":232560,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"PFM Pflasterfugenm�rtel_DE_GB_Verpackungsbild_Produktbild","addkeywords":"Pflasterfugenm�rtel_DE_GB_Verpackungsbild_Produktbild","creation_date":"2008-11-19T10:09:18","creation_user":"System Administrator","creation_user_id":2,"change_date":"2012-12-12T16:29:48","change_user":null,"change_user_id":null,"phy_file_name":"IM0006511.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2008\\\\11\\\\19\\\\IM0006511","phy_preview_file":"../Image/IM0006511.JPG","orig_file_name":"IM0006511.EPS","imag_height":629,"imag_width":1245,"imag_colouring":null,"imag_compression_rate":null,"imag_resolution":400,"hierarchy_ids":"10:11","hierarchy_names":"Produkt-Bild:Preisliste/Katalog farbig"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"20040","_score":1.0,
    "_source":
      {"epimId":20040,"root_obje_id":20039,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_WD_LARGE_D�belproduktbild sw","addkeywords":"DE_WD_LARGE_D�belproduktbild sw","creation_date":"2004-11-05T09:13:36","creation_user":"Adriane Metzler","creation_user_id":109,"change_date":"2009-10-08T18:24:04","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0002854.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\11\\\\5\\\\IM0002854","phy_preview_file":"../Image/IM0002854.JPG","orig_file_name":"IM0002854.EPS","imag_height":220,"imag_width":315,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"10:1202","hierarchy_names":"Produkt-Bild:Preisliste sw"}
      },
      {"_index":"ele_de","_type":"elementdata","_id":"9052","_score":1.0,
    "_source":
      {"epimId":9052,"root_obje_id":9051,"epob_type_Id":1011,"lang_id":-1,"lang_iso":null,"clie_id":1,"name":"DE_UP_Wellness Hotel","addkeywords":"Wellness Hotel Kalkputz I Ref 620 610","creation_date":"2004-05-10T17:17:20","creation_user":"John Smith","creation_user_id":107,"change_date":"2008-07-11T12:54:51","change_user":"System Administrator","change_user_id":2,"phy_file_name":"IM0000470.EPS","phy_file_extension":"EPS","phy_directory":"\\\\\\\\E:\\\\EPIMFS\\\\daten\\\\Archiv\\\\Image\\\\2004\\\\5\\\\10\\\\IM0000470","phy_preview_file":"../Image/IM0000470.JPG","orig_file_name":"IM0000470.EPS","imag_height":819,"imag_width":819,"imag_colouring":null,"imag_compression_rate":"undefiniert: 100","imag_resolution":400,"hierarchy_ids":"3:4:516","hierarchy_names":"Objekt-Bild:Innen:Unterputze"}
      }
    ]
    }
// >>> PROD V4 End (EPIM-7678) <<< 
    };


