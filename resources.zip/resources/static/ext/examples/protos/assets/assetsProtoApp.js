
Ext.application({
    name: 'assetsApp',
    
    /**
     * Place 
     */
    appMode:{},

    getShutterstockPanelCfg: function(cfg) {
       var shutterSrc='http://www.shutterstock.com/cat.mhtml?lang=de&language=de&ref_site=photo&search_source=search_form&version=llv1&anyorall=all&safesearch=1&search_tracking_id=ZZ6iVsbi7SG1U0KBuE1_7g&searchterm=kataloge&show_color_wheel=1&orient=&commercial_ok=&media_type=images&search_cat=&searchtermx=&photographer_name=&people_gender=&people_age=&people_ethnicity=&people_number=&color=';
       // >>> PROD V4 Start (EPIM-7678) <<<
       var shutterstockPanelCfg =    {
       setIframeSrc:function(url){
        Ext.get('assetsResultsPanel-iframePanel').dom.src= cfg.url; //'http://www.istockphoto.com/';
        Ext.get('assetsResultsPanel-iframePanel').removeCls('xty_iframePanel_topminus100');
       },
        itemId:'iframePanel',
        html:'<iframe id ="assetsResultsPanel-iframePanel" class="xty_iframePanel_topminus100" width="'+cfg.centerWidth+'" height="800" style="msargin-top:-100px;"  frameborder="0" '
        +'src="'+shutterSrc+'" '
        +'src="http://www.istockphoto.com/" '
        +' ></iframe>', margin:'24 24 24 24'};
       // >>> PROD V4 End (EPIM-7678) <<<
      return shutterstockPanelCfg;
    },
    
    clearHandler: function(evt){
      var targetEl = Ext.get(evt.target.id); 
      var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
      var field = Ext.getCmp(fieldId);
      if (field.isDirty()){field.setValue('');}
     },
    
     assetsResultsPanelId:null,
     
	 
     loadMask:null,
	 
     querySubmit: function(queryCfg) {
      var me = this; 

                            
        if ( me.viewAs ){queryCfg.viewAs = me.viewAs;}

	  
        // ///////////////////// CALLBACK START //////////////////////////
        var queryCallback = function(result, ex) {
          if (ex) { extVia.notifyException("queryCallback Exeption", ex);} 
          else {//DO WHAT YOU HAVE TO DO
          var resultStr  = ( typeof result === 'string') ?  result : Ext.encode(result[0]);       
          
           queryCfg.mode =(queryCfg.filters &&  queryCfg.filters.length>0)?'extend':'quick';
		   
           queryCfg.extendmode = queryCfg.mode.indexOf('extend')>-1;
	       queryCfg.quickmode = queryCfg.mode.indexOf('quick')>-1;
	       
	       //var pgjobDscr = queryCfg.extendmode? queryCfg.filters[0].type:'Assets'; 
           var pgjobDscr = 'Assets'; //queryCfg.extendmode? queryCfg.filters[0].type:'Assets'; 
         
	       var epobDscr = null; //queryCfg.extendmode? queryCfg.filters[0].type:null; 
         
	       if (queryCfg.extendmode && queryCfg.filters[0]){
	        pgjobDscr = queryCfg.filters[0].value? queryCfg.filters[0].value : queryCfg.filters[0].type;
          
            if (queryCfg.filters[0].value && queryCfg.filters[0].type==='epobType'){
              var textEpobTypeId = queryCfg.filters[0].value;
              if (textEpobTypeId!== extVia.module.epob.ELEMENTS &&  textEpobTypeId!== extVia.module.epob.PRODUCTTABLE){
                textEpobTypeId-=1;
              }
              pgjobDscr = extVia.ui.page.strings.epobs["Epob_" + textEpobTypeId +"_P"];
            }

	        //epobDscr = queryCfg.filters[0].type;
	       }
           queryCfg.pgjobDscr=pgjobDscr;
           queryCfg.epobDscr=epobDscr;


          var resultCfg = {
            count:(Math.floor((Math.random() * 100) + 1)),
            queryCfg:queryCfg
          };

	      var assetsResultsPanel = Ext.getCmp(me.assetsResultsPanelId);      
	     // if (!assetsResultsPanel){me.assetsResultsPanelId=null;}
        
        
        // neues Panel statt update
        if (assetsResultsPanel){assetsResultsPanel.destroy();}
        assetsResultsPanel =null; me.assetsResultsPanelId=null;

        var centerTabPan  = extVia.regApp.myRaster.getCenterTabPanel();
	      if (!me.assetsResultsPanelId){
            //queryCfg.id = 'assetsResultsPanel';

	        assetsResultsPanel = centerTabPan.addAndActivate(me.getAssetsResultsPanel(resultCfg));			
	        me.assetsResultsPanelId = assetsResultsPanel.id;
	      }
	      else{
	        assetsResultsPanel = Ext.getCmp(me.assetsResultsPanelId);
	        centerTabPan.setActiveTab( me.assetsResultsPanelId);
	        assetsResultsPanel.update(resultCfg);
	      }
        
          me.loadMask.hide();
		  me.loadMask = new Ext.LoadMask(Ext.get(assetsResultsPanel.id+'-body'), {msg:"Lade Assets..."});
		  
          assetsResultsPanel.getApplicationbar().getPagejobbar().getComponent('searchtext').focus();
          assetsResultsPanel.getApplicationbar().getPagejobbar().getComponent('searchtext').setValue(queryCfg.searchtext);
          extVia.regApp.myRaster.getWestTabPanel().getComponent('assetsQueryTab').syncUI(queryCfg);
          

          }
        };
        /////////////////////// CALLBACK ENDE //////////////////////////

        if (!me.loadMask){
         me.loadMask = new Ext.LoadMask(Ext.get('panel_mC'), {msg:"Lade Assets..."});
        }
        
        me.loadMask.show();
		
		var task = new Ext.util.DelayedTask(function(){
		 queryCallback(queryCfg);
		});
		task.delay(200);

     },

     quickviewTabCount : 0,     
     showQuickview: function(cfg){
      var me = this;
      
      var record = cfg.record;
      
      if(record.$className !== "ExtVia.model.elastic.Element" && record.$className !== "ExtVia.model.elastic.Image") {
      	record = Ext.create('ExtVia.model.elastic.Element', cfg.record.raw || {});
      }
      
      
      var hierachies =record.get('hierarchies');
      var path = hierachies.replace(/:/g,' &raquo ');
      var hierachy = hierachies.replace(/.*:/,'');
      
      var dateFormat ='d.m.Y';
      var changeDate = Ext.util.Format.date(record.get('changeDate'), dateFormat) ;
      var creationDate = record.get('creationDate');
      creationDate = Ext.util.Format.date(creationDate, dateFormat) ; 
      if(creationDate.indexOf('01.01.1011')>-1){creationDate='01.02.2006';}
      

      var aspectRatio =  Math.round(record.get('width')/record.get('height') * 100) / 100; // Math.round(record.get('width')/record.get('height'), -2);
      
	   var quickviewDTO = {
	  "dscr": "Details",
	  "epobType": "Image",
	  "items": [
    
        // Vorschaubild
        { "cssclass": "xty_topic",  "dscr": "Vorschaubild", "name": "preview","type": 43, "typeName": "TOPIC" },
	    { "dscr": "Bild", "name": "previewimage", "type": extVia.ui.dto.ety.IMAGE, "typeName": "IMAGE", 
          "srcUrl": 'http://'+record.get('previewUrl'), aspectRatio:aspectRatio, width:record.get('width'), height:record.get('height')},

      // >>> PROD V4 Start (EPIM-7678) <<<
      // >>> PROD V4 End (EPIM-7678) <<<
          
        // Allgemein as FIELDSET
	     {
	      "items": [
            { "dscr": "Name", "name": "asset-name",  "type": 123,  "typeName": "BASEITEM",  "value": record.get('name') },   
            { "dscr": "Eigent&uuml;mer", "name": "asset-owner",  "type": 123,  "typeName": "BASEITEM",  "value": record.get('creationUser') },
            { "dscr": "Kategorie","name": "asset-categories","type": 123,"typeName": "BASEITEM", "value":  hierachy },
            { "dscr": "Pfad", "name": "asset-path",  "type": 123,  "typeName": "BASEITEM",  "value": path }, 
            { "dscr": "Kommentar", "name": "asset-comment", "type": 123, "typeName": "BASEITEM","value":  record.get('comment') },
            { "dscr": "Ge&auml;ndert am", "name": "asset-changedate",  "type": 123,  "typeName": "BASEITEM",  "value": changeDate },
            { "dscr": "Erstellt am", "name": "asset-creationdate",  "type": 123,  "typeName": "BASEITEM",  "value": creationDate },
            { "dscr": "ID", hidden:true,"name": "asset-id","type": 123, "typeName": "BASEITEM", "value": record.get('epimId')}
	      ],
	      "name": "attribute", "dscr": "Allgemein FS", "title": "Attribut","type": 13, "typeName": "FIELDSET"
	    },

      
        // Asset specific
        { "cssclass": "xty_topic", "dscr": "Spezifisch", "name": "asset-specific-props", "type": 43, "typeName": "TOPIC"},
      
        { "dscr": "Dateiname", "name": "asset-filename",  "type": 123,  "typeName": "BASEITEM",  "value": record.get('filename') }, 

        { "dscr": "Breite * H&ouml;he", "name": "asset-height_width",  "type": 123,  "typeName": "BASEITEM",  "value": record.get('width')+"px * "+record.get('height')+"px" }, 
        //{ "dscr": "Aspect Ratio w/h", "name": "asset-aspectRatio",  "type": 123,  "typeName": "BASEITEM",  "value": ""+aspectRatio+"" }, 
        { "dscr": "Aufl&ouml;sung", "name": "asset-resolution",  "type": 123,  "typeName": "BASEITEM",  "value":  record.get('resolution') }, 
        { "dscr": "Kompression", "name": "asset-compressionRate",  "type": 123,  "typeName": "BASEITEM",  "value":  record.get('compressionRate') }, 
        { "dscr": "Farbraum", "name": "asset-color",  "type": 123,  "typeName": "BASEITEM",  "value":  record.get('color') }, 
        //{ "dscr": "Gr&ouml;sse", "name": "asset-size",  "type": 123,  "typeName": "BASEITEM",  "value": "4 MB" }, 
        
        { "dscr": "Typ | Format", "name": "asset-type_format", "type": 123, "typeName": "BASEITEM", "value": "Bild | jpg" },
        
        
        // Zuordnung EPIM
        { "cssclass": "xty_topic", "dscr": "Zuordnung EPIM",  "name": "assignment", "type": 43, "typeName": "TOPIC"},
        {
	        "dscr": "Importstatus",
	        "name": "assign-importState",
	        "type": 123,
	        "typeName": "BASEITEM",
	        "value":  "bereits importiert"
	      },
	    {
	      "dscr": "EPIM-ID",
	      "name": "assign-id",
	      "type": 41,
	      "typeName": "LINK",
	      "href": '../ajsp/Forward.jsp?p_sFromPage=ObjectsTree&p_sPageType=PageMain&p_sType=&p_sObjeId='+ record.get('epimId'),//+'&p_sCallbackF=oTreeHierarchyMenu.replaceNode',
	      "value": record.get('epimId')
	    },
	    {
	      "dscr": "Kategorie",
	      "href": "../jsp/QueryApp.jsp?appModeName=queryCategories&epobType=CATEGORY&category="+hierachy,
	      "name": "assign-hierachy-name_id",
	      "type": 41,
	      "typeName": "LINK",
	      "value": hierachy
	    }
	  ],
	  "name": "detailsInfo",
	  "type": 11,
	  "typeName": "PANEL"
	};
    

     var epobDscr = cfg.record.get('text');
  
     me.quickviewTabCount++;
  
     var quickviewTabitemId = 'quickviewTab_'+me.quickviewTabCount; 
     
     
	 var eastTabPanCfg = {
	   border:false,
	   items:[
	    { closable:true, 
	      itemId:quickviewTabitemId, 
	      cls:'xty_quickview-host', 
	      title:'Kurzansicht' ,
	      listeners:{
	       close:function(tab){
	         tab.ownerCt.ownerCt.hide();
	       }
	     }
	   }]
	  };


    var tabPanelEast;
    if (me.singleApp  && extVia.regApp.myRaster.initEastTabPanel){
      tabPanelEast = extVia.regApp.myRaster.initEastTabPanel(eastTabPanCfg);
      extVia.regApp.myRaster.addToWest(tabPanelEast);
    }else{
      eastTabPanCfg =  eastTabPanCfg.items[0]; 
      tabPanelEast = extVia.regApp.myRaster.getEastTabPanel();
      var lastQuickviewTabitemId = 'quickviewTab_'+ ( me.quickviewTabCount-1) ;   
      tabPanelEast.remove(lastQuickviewTabitemId);
      tabPanelEast.addAndActivate(eastTabPanCfg);     
    }
    var quickviewTab = tabPanelEast.getComponent(quickviewTabitemId); 
    var quickviewTabId = quickviewTab.id;
  
   

    var  getQuickviewFieldsets = function(dtoElement, containerWidth){
     var getItemCfg = function(item){
      var itemCfg;
       if (item.type === extVia.ui.dto.ety.IMAGE){
//         var landscape = true;
//         
//         var aspectRatio = item.width/ img.height;
//         var landscape = aspectRatio>1;
//         
//         if (landscape){
////          item.width = 1000;
////          item.height = 714;
//          
//          if (!item.srcUrl){
//            item.srcUrl='../img/fakes/success-strategies.jpg';
//          }
//
//         }
//         else{// portrait
////          item.width = 517;
////          item.height = 714;
//          if (!item.srcUrl){ item.srcUrl='../img/fakes/success-strategies-portrait.jpg';}
//         }

         item.aspectRatio = item.width / item.height;
         var aspectRatio = item.aspectRatio;
         var imgHeight = item.height;
         var imgWidth = item.width; 
         var width='' ;
         var height='';
         
         if (aspectRatio > 1){
           width = 'width:'+(imgWidth > 180 ? 180 : imgWidth) +'px;';
         }
         else{
           height = 'height:'+( (imgHeight === undefined || imgHeight === 0 || imgHeight ) > 227 ? 220 : imgHeight ) +'px;';
         }
        itemCfg = {
          cls:'xty_quickview-fieldset-item xty_quickview-fieldset-image-item', 
          style:'text-align:center',
          anchor: '100%',
          itemId:item.name,
          html:'<img id="'+item.name+'-img"  style="width:220px;" src="'+item.srcUrl+'"/>'
          //html:'<img id="'+item.name+'-img"  style="'+width+height+'" src="'+item.srcUrl+'"/>'
          };
       }
       else {

        if (item.type === extVia.ui.dto.ety.LINK){
         item.value += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="cursor:pointer;text-decoration:none;" target="_blank" href="'+item.href+'">[&raquo;]</a>' ;
        }

        itemCfg = {
            fieldLabel: item.dscr,
            itemId:item.name,
            hidden:item.hidden,
            cls:'xty_quickview-fieldset-item',
            iconCls:item.cssclass,
            fieldBodyCls:'xty_cntv',
            labelClsExtra:'xty_dscr',
            value: item.value,
            name: item.name 
        };

        itemCfg = {
        fieldLabel: item.dscr,
        hidden:item.hidden,
        itemId:item.name,
        cls:'xty_quickview-fieldset-item',
        fieldBodyCls:'xty_cntv',
        labelClsExtra:'xty_dscr',
        value: item.value,
        name: item.name 
        };
      } 
      return itemCfg;
     };
     
   var fieldsets=[];
   var i;
   for (i=0; i<dtoElement.items.length ; i++){
     var item = dtoElement.items[i];
     var fieldsetCfg ;
     
     if (item.type === extVia.ui.dto.ety.TOPIC || item.type === extVia.ui.dto.ety.FIELDSET){
       fieldsetCfg  = {
        xtype:'fieldset',
        width:containerWidth,
        itemId:item.name,
        cls:'xty_quickview-fieldset',
        columnWidth: 0.5,
        title: item.dscr, 
        defaultType: 'displayfield',
        defaults: {anchor: '100%'},
        layout: 'anchor'
       };
       fieldsetCfg.items = [];
       
       if (item.type === extVia.ui.dto.ety.FIELDSET){
        var fsi;
        for (fsi=0; fsi<item.items.length ; fsi ++){
          var fsitem = item.items[fsi];
          fieldsetCfg.items.push(getItemCfg(fsitem));
        }
       } 
       fieldsets.push(fieldsetCfg);
     }
     else{  
        fieldsetCfg.items.push(getItemCfg(item));
     }
   }
   return fieldsets;
  }; // eo getQuickviewFieldsets
  
  
  
  var quickviewFieldsets= getQuickviewFieldsets(quickviewDTO );

  
   
   var centerPanel = extVia.regApp.myRaster.getCenter();

   var findInArray = function(  prop, value, arr){
       var retItems = [];   
	   Ext.Array.each( arr, function(item){
	     if (item[prop] === value){
           retItems.push(item);
         }
	   });
     return retItems;
   };
   var findFirstInArray = function(  prop, value, arr){
     return findInArray(  prop, value, arr)[0];
   };

   var isImported = false;
   var isImportedItem = findFirstInArray('name' , 'assign-importState' , quickviewDTO.items);
   if (isImportedItem){
     isImported = isImportedItem.value &&  !Ext.isEmpty (isImportedItem.value);
   }

   var quickviewPanel = Ext.create('Ext.panel.Panel', {
    labelWidth: 75,
    border:false,
    height:centerPanel.getHeight()-28,
    autoScroll:true,

    html: ' <div class="xty_epob'+quickviewDTO.epobType+'" style="width:16px;position:absolute;right:3px;top:4px; background-color:#FFF">&nbsp;&nbsp;&nbsp;</div>',
    bbar:['->',{iconCls:'xty_pgtoolbar-assignUp', tooltip:'&Uuml;bernehmen',scale:'small'},{tooltip:'Link zeigen', iconCls:'xty_pgtoolbar-link-view', disabled: !isImported},{tooltip:'Download', iconCls:'x-tool x-tool-download'}],
    cls:'xty_quickview-panel',
    bodyStyle: 'padding:5px 5px 0',
    defaults: {
        bodyPadding: 4
    },
    items: quickviewFieldsets
   });
   
   quickviewTab.add(quickviewPanel);
   
   var eastPanel = extVia.regApp.myRaster.getEast();
   eastPanel.show();
   eastPanel.expand();
   
   if (me.singleApp){
    extVia.regApp.myRaster.addToEast(tabPanelEast);  
   }

   },
     

   
   
   
   
     viewAsImages:{
       list :  'rolandGrid.png',
       thumbsBig :'rolandBigThumbs.png',
       thumbsBigger :'rolandBiggerThumbs.png',
       thumbsSmall: 'rolandSmallThumbs.png',
       contentList: 'contentList.png'
     },

   
    pageSize:50,   
    pageStartsFrom : 1,
     
    assetsResultsPanelCnt: 1,
    getAssetsResultsPanel: function(result) {
      var me = this;
      
      var centerPan = extVia.ui.page.raster.getCenter();
      var centerWidth = centerPan.getWidth()-50;
      var centerHeight = centerPan.getHeight()-138;
      
      var queryCfg = result.queryCfg;

      
      var changeViewHandler = function(button){

        if (button.itemId ==='thumbsSmall'){
         me.pageSize=80; 
        }
        
        button.ownerCt.getComponent('list').toggle(false,true);
        button.ownerCt.getComponent('thumbsBig').toggle(false,true);
        button.ownerCt.getComponent('thumbsBigger').toggle(false,true);
        button.ownerCt.getComponent('thumbsSmall').toggle(false,true);
        button.ownerCt.getComponent('contentList').toggle(false,true);

        queryCfg.viewAs = button.itemId;
        me.viewAs = queryCfg.viewAs;
        
        var searchfield = button.ownerCt.ownerCt.getComponent('searchtext');
        queryCfg.searchtext=searchfield.getValue();		
        
        var realViewAvailable = queryCfg.viewAs==='contentList' || queryCfg.viewAs==='thumbsSmall';
        if (realViewAvailable){
         me.querySubmit(queryCfg);
        }
        else{
	        var viewFakeImg =  'rolandBigThumbs.png';
	        if (queryCfg.viewAs){
	         viewFakeImg = me.viewAsImages[queryCfg.viewAs];
	        }
          
            var assetsFakeview = button.ownerCt.ownerCt.ownerCt.ownerCt.getComponent('assetsFakeview');
            assetsFakeview.show();
	        var viewLoadMask = new Ext.LoadMask( me.assetsResultsPanelId+'-body', {msg:"Lade Ansicht..."});
	        viewLoadMask.show();
	        button.toggle(true);
		    var task = new Ext.util.DelayedTask(function(){
		       var fakeImgBase = '../img/fakes/';     
		       if (me.embeddedApp){fakeImgBase = '../jsp/js/extjs/ext/examples/protos/img/fakes/';}
		       document.getElementById('assetsFakeview-img').src=fakeImgBase+'dataviews/'+viewFakeImg;
		       viewLoadMask.hide();
		    });
		    task.delay(700);
        }
        

      };

      var title ='Gefunden <i>'+result.count+'</i>';

      var pgjobDscr = queryCfg.pgjobDscr;
      var epobDscr = queryCfg.epobDscr;

      
      var searchfieldCfg = { 
          xtype: 'triggerfield',  
          width:360,
          height:30,
          
          //emptyText:'Suchbegriff', 
          itemId:'searchtext',
          cls:'xty_formfield-XL xty_has-insidetrigger',  
          trigger2Cls:'xty_form-trigger-searchable' , trigger1Cls:'xty_inside-trigger-clear' , 

          onTrigger1Click:me.clearHandler,
          onTrigger2Click:function(evt){
            var targetEl = Ext.get(evt.target.id); 
            var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
            var field = Ext.getCmp(fieldId);
			queryCfg.searchtext = field.getValue();
            me.querySubmit(queryCfg); 
          },
          enableKeyEvents:true,
          listeners:{
            keydown:function(field, evt){
           if (evt.getKey()===Ext.EventObject.ENTER){
		   	 queryCfg.searchtext = field.getValue();
             me.querySubmit(queryCfg); 
           }
             else if (evt.getKey()===Ext.EventObject.DELETE){
                  field.setValue(''); 
             }
            } 
            
          }

          
       };


       
      var queryCfgHtmlStr  = '';
      Ext.Object.each(queryCfg, function(key, value) {
        if (!Ext.isEmpty(value)){
            if (key === 'filters') {
              queryCfgHtmlStr+= '<b>'+key + '</b>: <br>';
              var i;
              for (i=0; i<value.length; i++){
				if (!Ext.isEmpty(value[i])){
			      queryCfgHtmlStr+= '&nbsp;&nbsp;&nbsp;<b>'+value[i].type + '</b>: '+ value[i].value +'<br>';
				}  
              }
            }
            else if (key === 'pgjobDscr' || key === 'epobDscr' || key === 'extendmode' || key === 'quickmode' || key === 'categoriesTreeFilter') {var forJSLINT;}
            else{
             queryCfgHtmlStr+= '<b>'+key + '</b>: '+ value +'<br>';
            }  
           }
		});
      
      
	  var epobTypesItemHandler = function(item){
	  	if(!queryCfg.filters){
			queryCfg.filters=[];
		}
		var filterCfg = { type:'epobType',  epobType:item.type, value: item.epobTypeId, valueDscr: item.text};
		if (item.replace) {
			if (Ext.isDefined(item.myButtonFilterIx)) {
				queryCfg.filters[item.myButtonFilterIx] = filterCfg;
			}
		}
		else {
			queryCfg.filters.push(filterCfg);
		}
		me.querySubmit(queryCfg);
	  };

        var querybehaviourItemHandler = function(item){
//	      if(!queryCfg.filters){
//	       queryCfg.filters=[];
//	      }
       };
    
    
    
      
      var pagejobButtons = [    
          '->',
         searchfieldCfg,
         '->',

         { xtype: 'buttongroup', margins:'0 0 0 20',
               cls:'xty_resultas-btngrp',
               columns: 5,
               defaults:{enableToggle:true, scale:'small'},
               items: [  

                  {itemId:'list',  iconCls:'xty_pgtoolbar-list',  pressed:queryCfg.viewAs==='list',  tooltip:'Liste', handler:changeViewHandler},
                  {itemId:'contentList',iconCls:'xty_pgtoolbar-contentList',  pressed:queryCfg.viewAs==='contentList',tooltip:'Inhalt',  handler:changeViewHandler},
                  {itemId:'thumbsSmall',iconCls:'xty_pgtoolbar-thumbsSmall', pressed:queryCfg.viewAs==='thumbsSmall',  tooltip:'Thumbs klein',  handler:changeViewHandler},
                  {itemId:'thumbsBig',iconCls:'xty_pgtoolbar-thumbsBig',   pressed:queryCfg.viewAs==='thumbsBig', tooltip:'Thumbs gross',handler:changeViewHandler},
                  {itemId:'thumbsBigger',cls:'xty_scale-small-17',  pressed:queryCfg.viewAs==='thumbsBigger', iconCls:'xty_pgtoolbar-thumbsBigger', width:23, tooltip:'Thumbs gr&ouml;sser',handler:changeViewHandler}
                  
               ]
          },
          
          
          { xtype: 'buttongroup', marsgins:'0 0 0 20',
            columns: 1,
            defaults:{enableToggle:true},
            items: [  
              
                  {itemId:'more',  iconCls:'xty_pgtoolbar-more',xtype:'splitbutton',style:'margin-left:10px;', margisns:'0 0 0 10',tooltip:'mehr Kriterien', 
                    menu:{
                      items:[

                      
                            {xtype:'toolbar', itemId:'epobTypesToolbar', width:340, //text:'Objekttypen',
                              defaults:{
                               iconAlign:'top',
                               handler:epobTypesItemHandler,
                               scale:'large'
                              },
                              
                              items:[
                            {epobTypeId:extVia.enums.EpimObjects.ELEMENTS.id, type:'Element', iconCls:'xty_epob'+    extVia.enums.EpimObjects.ELEMENTS.key,   text:  'Alle ' + extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"]} ,
                            {epobTypeId:extVia.enums.EpimObjects.IMAGEVAR.id, type:'Image',iconCls:'xty_epob'+  extVia.enums.EpimObjects.IMAGE.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"]}, 
                            {epobTypeId:extVia.enums.EpimObjects.AUDIOVAR.id, type:'Audio',iconCls:'xty_epob'+  extVia.enums.EpimObjects.AUDIO.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"]} ,
                            {epobTypeId:extVia.enums.EpimObjects.VIDEOVAR.id, type:'Video',iconCls:'xty_epob'+  extVia.enums.EpimObjects.VIDEO.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"]},
                            {epobTypeId:extVia.enums.EpimObjects.GRAPHICVAR.id, type:'Graphic',iconCls:'xty_epob'+  extVia.enums.EpimObjects.GRAPHIC.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"]},
                            {epobTypeId:extVia.enums.EpimObjects.DOCUMENTVAR.id, type:'Document',iconCls:'xty_epob'+  extVia.enums.EpimObjects.DOCUMENT.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"]}, 
                            {epobTypeId:extVia.enums.EpimObjects.TEXTVAR.id, type:'Text',iconCls:'xty_epob'+  extVia.enums.EpimObjects.TEXT.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"]}
                                
                          ]},
                      
                       
                            {text:'<b>Sortierung</b>'},
                            {text:'Aufsteigend',checked:true, handler :querybehaviourItemHandler, itemId:'sort-asc', group:'SORT', value:'ASC'},
                            {text:'Absteigend', handler :querybehaviourItemHandler, itemId:'sort-desc', group:'SORT', value:'DESC'},
                            '-',
                            {text:'&Auml;nderungsdatum (Standard)', checked:true,handler :querybehaviourItemHandler, itemId:'sortby-changedate', group:'SORTBY', value:'CHANGEDATE'},
                            {text:'Erstellungsdatum', handler :querybehaviourItemHandler, itemId:'sortby-creationdate', group:'SORTBY', value:'CREATIONDATE' },
                            {text:'Typ',handler :querybehaviourItemHandler, itemId:'sortby-type', group:'SORTBY', value:'TYPE'},
                            {text:'Name',handler :querybehaviourItemHandler, itemId:'sortby-name', group:'SORTBY', value:'NAME'},
                            '-',
                            {text:'<b>Suchbegriff</b>'}, 
                            {text:'Als Wort enthalten <span data-qtip="Leerzeichen Komma Bindestrich Semikolon">&lang; Trenner: &not; , -  ; </span> &rang;', checked:true, itemId:'matching-word', group:'MATCHING', value:'WORD',handler :querybehaviourItemHandler},
                            {text:'Enthalten' , itemId:'matching-contains', group:'MATCHING', value:'CONTAINS',handler :querybehaviourItemHandler},
                            {text:'Beginnt mit', itemId:'matching-startswith', group:'MATCHING', value:'STARTSWITH',handler :querybehaviourItemHandler},
                            {text:'Endet mit', itemId:'matching-endswith', group:'MATCHING', value:'ENDSWITH',handler :querybehaviourItemHandler},    
                            {text:'Exakt', itemId:'matching-exact', group:'MATCHING', value:'EXACT',handler :querybehaviourItemHandler},    
		                     
		                          
		              '-'   
		             ,{  text:'Suchparams',iconCls:'xty_icon xty_iconSearchable', hidXden:true,
		              menu: {
		                items: [{xtype:'panel',title:'Suchparams', autoScroll:true, margins:'4 4 4 4', html: queryCfgHtmlStr}]
		              }
		              
		            }
            
                    ]
                    }
                  }
          ]}

      ];

              
      var pagetoolbarButtons = [ ];       
      
      pagetoolbarButtons.push(  {iconCls:'xty_pgtoolbar-assignList', itemId:'assignList',  tooltip:  '&Uuml;bernehmen ' , disabled:true, 
        handler:function (button){   
          
          var records = button.ownerCt.ownerCt.ownerCt.getSelection();
          var count = records.length;
          
          var doingHtml='';
          var doneHtml='';
          if (count===1){
            doingHtml = '&Uuml;bernehme  Element <i>'+records[0].get('name')+'</i> in EPIM';
           
            var href =  '../ajsp/Forward.jsp?p_sFromPage=ObjectsTree&p_sPageType=PageMain&p_sType=&p_sObjeId='+ records[0].get('epimId')+'&p_sCallbackF=oTreeHierarchyMenu.replaceNode';
            var linkHtml = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="cursor:pointer;text-decoration:none;" target="_blank" href="'+href+'">[&raquo;]</a>' ;
            doingHtml+=linkHtml;
            
            doneHtml= 'Element <i>'+records[0].get('name')+'</i> in EPIM &uuml;bernommen';
            doneHtml+=linkHtml;
            
            
            }
          else{
            doingHtml = '&Uuml;bernehme '+count+' Elemente in EPIM';
            doneHtml = count+' Elemente in EPIM &uuml;bernommen.';
          }
          
          
          //var notfierId = Ext.id();
          var centerPanel = extVia.regApp.myRaster.getCenter();
          
          var assignNotifier =  Ext.create('Ext.window.Window', {
            title: '&Uuml;bernehmen',
            //id : notfierId,
            //position: 'tr',
            width:240,
            bodyStyle:'padding:4px;',
            y:44,
            x:centerPanel.ownerCt.getWidth()-250,

            //cls: 'ux-notification-light',
            iconCls: 'xty_icon xty_iconLoading',
            html :  doingHtml,
            //modal:true,
            autoCloseDelay: 2000
    
          });

          assignNotifier.show(); 
          
          var task = new Ext.util.DelayedTask(function(){
			   assignNotifier.setIconCls('xty_icon xty_iconSuccess');
               //assignNotifier.modal = false;
               //Ext.get('uxNotification-'+notfierId+'-body').dom.innerHTML =doneHtml;
	      });
		  task.delay(2500); 
        }
        });
      pagetoolbarButtons.push(   { xtype: 'tbseparator', margins:'0 6 0 0'});

      var filterButtonClickHandler = function(button){
        button.hide();
        if (button.queryCfgProp){
        queryCfg[button.queryCfgProp] =null;
        }
        if ( Ext.isDefined(button.filterIx)){
        queryCfg.filters[button.filterIx] = null;
        }        
        me.querySubmit(queryCfg); 
      
      };
      
      
      var searchtextHidden = Ext.isEmpty(queryCfg.searchtext);
      
        pagetoolbarButtons.push( { xtype:'splitbutton', text:queryCfg.searchtext, queryCfgProp:'searchtext', hidden: searchtextHidden, 
        handler: filterButtonClickHandler, tooltip:'Suchtext',  itemId:'filterVal-searchtext', 
        cls:'xty_actionbar-filter-item xty_filter-item-searchtext', iconCls:'xty_icon xty_iconSearchable', scale:'small'
        });
      

      if (queryCfg.filters){ 
        var i;
        for (i =0; i< queryCfg.filters.length; i++){ 

		  var filter= queryCfg.filters[i];
		  
		  if (filter){
			
	          var filterType =  queryCfg.filters[i].type;
	          
	          var  epobType = queryCfg.filters[i].epobType;
	          
	          var tooltip = 'Filter: '+filterType;
	          var menu ;
	          if (filterType==='epobType'){
	          tooltip = 'Filter: Objekttyp';
	            menu ={items:[
	                    {epobTypeId:extVia.enums.EpimObjects.ELEMENTS.id, type:'Element',handler:epobTypesItemHandler, myButtonFilterIx:i, replace:true,   iconCls:'xty_epob'+  extVia.enums.EpimObjects.ELEMENTS.key,   text:  'Alle ' + extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"],scale:'large'} ,
	                    {epobTypeId:extVia.enums.EpimObjects.IMAGEVAR.id,type:'Image', handler:epobTypesItemHandler,  myButtonFilterIx:i, replace:true,   iconCls:'xty_epob'+  extVia.enums.EpimObjects.IMAGE.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"],scale:'large'}, 
	                    {epobTypeId:extVia.enums.EpimObjects.AUDIOVAR.id,type:'Audio', handler:epobTypesItemHandler,  myButtonFilterIx:i, replace:true,   iconCls:'xty_epob'+  extVia.enums.EpimObjects.AUDIO.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],scale:'large'} ,
	                    {epobTypeId:extVia.enums.EpimObjects.VIDEOVAR.id,type:'Video', handler:epobTypesItemHandler,  myButtonFilterIx:i, replace:true,   iconCls:'xty_epob'+  extVia.enums.EpimObjects.VIDEO.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],scale:'large'},
	                    {epobTypeId:extVia.enums.EpimObjects.GRAPHICVAR.id,type:'Graphic', handler:epobTypesItemHandler, myButtonFilterIx:i, replace:true,  iconCls:'xty_epob'+  extVia.enums.EpimObjects.GRAPHIC.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],scale:'large'},
	                    {epobTypeId:extVia.enums.EpimObjects.DOCUMENTVAR.id,type:'Document', handler:epobTypesItemHandler, myButtonFilterIx:i, replace:true,   iconCls:'xty_epob'+  extVia.enums.EpimObjects.DOCUMENT.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"],scale:'large'},
	                    {epobTypeId:extVia.enums.EpimObjects.TEXTVAR.id,type:'Text', handler:epobTypesItemHandler, myButtonFilterIx:i, replace:true,   iconCls:'xty_epob'+  extVia.enums.EpimObjects.TEXT.key ,  text:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"],scale:'large'}                
	                  ]};
	          }
	          
              var textEpobTypeId = queryCfg.filters[i].value;
              if (textEpobTypeId!== extVia.module.epob.ELEMENTS &&  textEpobTypeId!== extVia.module.epob.PRODUCTTABLE){
                textEpobTypeId-=1;
              }
              
              var text  = extVia.ui.page.strings.epobs["Epob_" + textEpobTypeId +"_P"];
              
              if (filterType==='Category'){
               text = queryCfg.filters[i].valueDscr;
              }


	          pagetoolbarButtons.push( { 
	            xtype:'splitbutton', 
	            //text: queryCfg.filters[i].value, //text: queryCfg.filters[i].valueDscr,  
	            text:   text,
	            menu:menu,
	            filterIx:i, 
	            handler: filterButtonClickHandler, 
	            tooltip: tooltip, 
	            itemId:'filter-'+filterType+'-'+epobType+'-'+i,
	            iconCls:'xty_epob'+epobType,  
	            cls:'xty_actionbar-filter-item xty_filter-item-'+ filterType,  
	            scale:'small'
	          });
		  
		  }
		  
		  
        }
      }

     pagetoolbarButtons.push(  '->');
     


     
     pagetoolbarButtons.push( {xtype:'tbspacer', width:20});
 
 
     var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: pgjobDscr, epobDscr:epobDscr,   pagetoolbarButtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );

      
     var viewFakeImg =  'rolandBigThumbs.png';
     if (queryCfg.viewAs){
       viewFakeImg = me.viewAsImages[queryCfg.viewAs];
     }
     
     var fakeImgBase = '../img/fakes/';     
     if (me.embeddedApp){fakeImgBase = '../jsp/js/extjs/ext/examples/protos/img/fakes/';}
	 
	 var assetsResultsPanelItems =[ {itemId:'assetsFakeview', height:1000, border:false, html:'<img id="assetsFakeview-img" src="'+fakeImgBase+'dataviews/'+viewFakeImg+'"/>'} ];
	 
     var dodataview = false;
     var doContentList = true;
     var dataview ;
     
     var viewPanel; // might be a thumbsview, a grid, a contenList, a tree a bird a plane
     
     if (queryCfg.viewAs==='thumbsSmall'){dodataview = true;}
     else if (queryCfg.viewAs==='contentList'){doContentList = true;}
  
     
     if (dodataview || doContentList){
		
     assetsResultsPanelItems[ 0 ].hidden = true;
		 
     
  var objectModelCfg  =  extVia.elastic.statics.getObjectModelCfg();
  var elementModelCfg  =  extVia.elastic.statics.getElementModelCfg();
  var imageModelCfg  =  extVia.elastic.statics.getImageModelCfg();
  
     

   var useElasticServer = true;
   var urlParamStr = location.href.replace(/.[^\?]*\?/,'');
   var urlParams = Ext.Object.fromQueryString(urlParamStr);
   if (urlParams.elasticOFF){useElasticServer = false;}
   if (urlParams.elasticON){useElasticServer = true;}
  

   
   var store; 
   // Get values from queryCfg modified by pagingBar
   queryCfg.pageSize=me.pageSize; 
   queryCfg.pageStartsFrom = me.pageStartsFrom;
   
   var loadParams;
   
   
   if (!useElasticServer){   
    store = extVia.elastic.statics.getObjectElementImageDummyStore({});
   } // eo not useElasticServer

    
   if (useElasticServer){ 
    // ElasticServerStore
    store = Ext.create('Ext.data.Store', {
	   model : 'ExtVia.model.elastic.Image',
	   //autoLoad : true,
	   //pageSize : 20,
	
	   proxy : {
           type : 'ajax',
           url : extVia.elastic.statics.getElementsUrl(),//?routing='+extVia.module.epob.IMAGEVAR,  //extVia.module.epob.IMAGEVAR=1011; // +'&size='+pageSize
           
           limitParam : 'size',
           startParam : 'from',
           actionMethods : {create: 'POST', read: 'POST', update: 'POST', destroy: 'POST'}, // read: 'POST' provides jsonObj auswertung in proxies 4.2 uses prop sendAsJson...
           reader : {
               type : 'json',
               root : 'hits.hits',
               totalProperty : 'hits.total',
               successProperty : '_shards.successful'
           }
	   },
     
       listeners:{
       
        load:function( store, records, successful, operation ){
          var hitsTotal = store.proxy.reader.jsonData.hits.total;
          var assetsResultsPanel = Ext.getCmp(me.assetsResultsPanelId);
          assetsResultsPanel.setHitsTotal(hitsTotal,queryCfg.pageSize); 
        }

       }
       
     });


	var params = extVia.elastic.statics.getElasticQueryParams(queryCfg);
	var encodedParams = Ext.encode(params);
	loadParams = {params : encodedParams};
	store.load({params : encodedParams});


//     var searchtext = queryCfg.searchtext;
//     if (Ext.isEmpty(searchtext)){searchtext='*';}
//     store.load({params:{q:'name:'+ searchtext }});

     
    
   } // eo useElasticServer  
     

   
    if (dodataview ){
      extVia.currentRawValue = queryCfg.searchtext;
      extVia.getHighValue = function getHighValue(value){
         var highValue = extVia.formatAutoCompleteText(value);
         //alert(value+' highValue '+highValue)
         return highValue;
      };

      
      
            viewPanel =  Ext.create('Ext.view.View', {
            itemId: 'viewPanel',
            cls:'xty_view-panel xty_'+queryCfg.viewAs+'-view-panel',
			store: store,
            tpl: [
                '<tpl for=".">',
                    '<div class="thumb-wrap" id="{name}">',
                    // >>> PROD V4 Start (EPIM-7678) <<<
                    // >>> PROD V4 End (EPIM-7678) <<<
                    '<div class="thumb"><img src="http://{previewUrl}" title="{name}"></div>',
                    '<span class="x-editable">{shortName}</span></div>', // shortName
                    //'<span class="x-editable">{[extVia.getHighValue(values.shortName)]}</span></div>', 
                '</tpl>',
                '<div class="x-clear"></div>'
            ],
            multiSelect: true,
            height: centerHeight,
            autoScroll:true,
            trackOver: true,
            overItemCls: 'x-item-over',
            itemSelector: 'div.thumb-wrap',
            emptyText: 'Keine Inhalte zum Anzeigen',
            plugins: [
                Ext.create('Ext.ux.DataView.DragSelector', {})
//                Ext.create('Ext.ux.DataView.LabelEditor', {dataIndex: 'name'})
            ],
            prepareData: function(data) {
                Ext.apply(data, {
                    shortName: Ext.util.Format.ellipsis(data.name, 15),
                    sizeString: Ext.util.Format.fileSize(data.size),
                    dateString: Ext.util.Format.date(data.lastmod, "m/d/Y g:i a")
                });
                return data;
            },
            listeners: {
             selectionchange:function(view,selections ){
                 var pagetoolbar = appbar.getPagetoolbar();
                 var assignList = pagetoolbar.getComponent('assignList');
                 //assignList.disable();
                 assignList.enable();
             },
             itemdblclick:function( view, record, item, index, evt ){
                  view.itemIsDblClicked = true;
                  me.showQuickview({record:record});
                  var resetIsDblClickedDelayed = new Ext.util.DelayedTask(
                  function(){view.itemIsDblClicked = false;});
                  resetIsDblClickedDelayed.delay(210);
                  
             }
            }
        });

     assetsResultsPanelItems.push( viewPanel );
    }
    else if (doContentList ){
            viewPanel = Ext.create('Ext.grid.Panel', {
            itemId:'viewPanel',
            cls:'xty_view-panel xty_'+queryCfg.viewAs+'-view-panel',
		    store: store,
            border:false,
            bodyBorder:false,
		    width: centerPan.getWidth()-2,
            multiSelect: true,
            height: centerHeight,
            autoScroll:true,
            emptyText: 'Keine Inhalte zum Anzeigen',
            columns: [
            { header: 'Vorschaubild',  dataIndex: 'previewUrl', width:52,
             renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
             var html = '<div class="thumsb" style="padding-left:6px;width:36px; overflow:hidden;"><img src="http://'+value+'" height="24" data-qtip="'+record.get('name')+
                '&lt;br&gt; &lt;img src=http://'+value+'  height=200 /&gt;' +
                '"/></div>';  
             return html;
            }},
            { header: 'Name',  dataIndex: 'name', flex: 0.5  ,
             renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
              
              extVia.currentRawValue = queryCfg.searchtext;
              var highName = extVia.formatAutoCompleteText (value);
              var highID = extVia.formatAutoCompleteText (record.get('epimId'));
              
               var hierarchies = record.get('hierarchies'); //.replace(/:/g,' &raquo ');
               var path = hierarchies; //.replace(/:/g,' &raquo ');
               //var hierachy = hierarchies.replace(/.*:/,'');
               path = path.replace(/:/g,' &raquo ');
               if ( queryCfg.filters && queryCfg.filters[0] && queryCfg.filters[0].type && queryCfg.filters[0].type==='Category'){
                  extVia.currentRawValue = queryCfg.filters[0].value;
                  path = extVia.formatAutoCompleteText (path);
               }
               
              var html = 
                '<div class="xty_mainLine" style="font-size:14px;">'+highName+ ' ('+highID+')</div>' +
                '<div class="xty_addiLine" style="font-size:11px;" > '+path+'</div>';  
              return html;
              }
            },
            { header: 'Size', dataIndex: 'height',width:74,
               renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {

                var html = 
                '<div class="xty_dscr" style="font-size:8pt;"><span class="xty_dscr" style="color:#888" >Breite:</span><span class="xty_cntv" >'+record.get('width')+'px</span></div>' +
                '<div class="xty_dscr" style="font-size:8pt;"><span class="xty_dscr" style="color:#888" >H&ouml;he: </span><span class="xty_cntv" >'+record.get('height')+'px</span></div>' ;
                return html;
              }
            },
            
            
            { header: 'Datum', dataIndex: 'changeDate', width:140,
              renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {

                var dateFormat ='d.m.Y';
                var changeDate = Ext.util.Format.date(record.get('changeDate'), dateFormat) ;
                var creationDate = record.get('creationDate');
                creationDate = Ext.util.Format.date(creationDate, dateFormat) ; 
                if(creationDate.indexOf('01.01.1011')>-1){creationDate='01.02.2006';}

                var html = 
                '<div class="xty_dscr" style="font-size:8pt;"><span class="xty_dscr" style="color:#888" >&Auml;nderung:</span><span class="xty_cntv" > '+changeDate+'</span></div>' +
                '<div class="xty_dscr" style="font-size:8pt;"><span class="xty_dscr" style="color:#888" >Erstellung:</span><span class="xty_cntv" > '+creationDate+'</span></div>' ;
                return html;
              }
              }

           ],
 
           hideHeaders:true,
           listeners: {
             selectionchange:function(view,selections ){
                 var pagetoolbar = appbar.getPagetoolbar();
                 var assignList = pagetoolbar.getComponent('assignList');
                 assignList.enable();
             },
             itemdblclick:function( view, record, item, index, evt ){
                  view.itemIsDblClicked = true;
                  me.showQuickview({record:record});
                  var resetIsDblClickedDelayed = new Ext.util.DelayedTask(
                  function(){view.itemIsDblClicked = false;});
                  resetIsDblClickedDelayed.delay(210);
                  
             }
            }

		});
      assetsResultsPanelItems.push( viewPanel );
     }

     }// eo  idodataview or  doContentList)
     

      
      var assetsResultsPanel = Ext.create('Ext.panel.Panel',{ 
	      id: 'images-view', // wegen css id selectors
	      cls:'xty_view-panel-bin xty_assetresult-panel',
	      title:queryCfg.title?queryCfg.title:'Assets',
	      closable: true,
	      //id:queryCfg.panelId,
	      setEpobDscr:function(epobDscr){ 
	          appbar.setEpobDscr(epobDscr);
	      },
          setHitsTotal:function(hitsTotal, pageSize){ 
            appbar.setEpobDscr(hitsTotal);
            this.getComponent('pagingbar').setHitsTotal(hitsTotal, pageSize);
          },
          setPagejobDscr:function(pgjobDscr){  
            appbar.setPagejobDscr(pgjobDscr);
          },
		  getApplicationbar:function(){return appbar;},
          
          getSelection:function(){ 
            var selection;
            var viewPanel = this.getComponent('viewPanel');
            if (viewPanel){
              var selectionModel = viewPanel.getSelectionModel();
              if (selectionModel){
                selection = selectionModel.getSelection();
              }
            }
            return selection;
          },

	      update:function(result){ 
            var queryCfg = result.queryCfg;
			var me = this; //Ext.getCmp('assetsResultsPanel');
			var actionbar = appbar.getActionbar();
			var filterValSearchtext = actionbar.getComponent('filterVal-searchtext');
			if (filterValSearchtext){
				filterValSearchtext.setText(queryCfg.searchtext);
                filterValSearchtext.setVisible(!Ext.isEmpty(queryCfg.searchtext));
			}
	        this.setEpobDscr(queryCfg.epobDscr);
            this.setPagejobDscr(queryCfg.pgjobDscr);
			var title ='Gefunden <i>'+result.count+'</i>';
	        me.setTitle(title);
	      },
		  
	      tbar : appbar, 
          border:false,
          height:centerHeight+112,
	      items:assetsResultsPanelItems,
          bbar:{
            itemId:'pagingbar',
            setHitsTotal:function(hitsTotal, pageSize){ 
              this.getComponent('hitsTotal').setText('Treffer:'+hitsTotal);
              var allPagesCount = (Math.round(hitsTotal/pageSize));
              allPagesCount+=1;
              this.allPagesCount = allPagesCount;
              this.getComponent('pages').setText('/'+  allPagesCount);
             },
          
            cls:'xty_result-pagingbar', 
            
            defaults:{
             scale:'small',
             handler: function(button){
             
              if (button.itemId==='next'){
                me.pageStartsFrom+=1;
              }
              else if (button.itemId==='prev'){
                me.pageStartsFrom-=1;
              }
              else if (button.itemId==='first'){
                me.pageStartsFrom=1;
              }
              else if (button.itemId==='last'){
                me.pageStartsFrom=button.ownerCt.allPagesCount;
              }
              me.querySubmit(queryCfg);
             }
            },
            
            items:[
              //'|',
              {itemId:'first',iconCls:'x-tbar-page-first'},
              {itemId:'prev',iconCls:'x-tbar-page-prev'},
              //'|',
              {xtype:'tbtext',text:'Seite', itemId:'page'},
              {xtype:'textfield', cls:'xty_pagingbar-field xty_pagingbar-field-pageNr',width:24, value: queryCfg.pageStartsFrom, itemId:'pageNr'},
              {xtype:'tbtext',text:'/', itemId:'pages'},
              {itemId:'next',iconCls:'x-tbar-page-next'},
              {itemId:'last',iconCls:'x-tbar-page-last'},
              '->',
              {xtype:'tbtext',text:'Treffer:', itemId:'hitsTotal'}
              
              ]
           },
            listeners:{
              resize:function(panel, adjWidth, adjHeight){
                var pagejobbar = appbar.getPagejobbar();
                var searchtext = pagejobbar.getComponent('searchtext');
                var newWidth = panel.getWidth();
                
                appbar.setWidth(newWidth);
                pagejobbar.setWidth(newWidth);
                
                if (newWidth<1000){
                  searchtext.setWidth(200);
                }
                else{
                 searchtext.setWidth(360);
                }
              }
           }
           
           
      });

      
      
    // HERE ? 
    //  if (store) store.load(loadParams);
      
      
      return assetsResultsPanel;
      
    },
    
    
     
    initQueryPanel: function(cfg) {
      var me = this;
      var clearHandler = me.clearHandler;
    
       Ext.define('Epob', {
          extend: 'Ext.data.Model',
          fields: [{type: 'string', name: 'text'},{type: 'string', name: 'dscr'},{type: 'number', name: 'epobTypeId'},{type: 'string', name: 'epobId'}]
        });
       me.elementTreeStore  = Ext.create('Ext.data.TreeStore', {
        model: 'Epob',
        storeId:'elementsTreeStore',
        root: {
	        text: 'Kategorien', id:'Kategorien', iconCls:'xty_epobCategory'
	        }
        });
       me.elementTreeStore.setRootNode({});

       
       var westTabPanCfg = {
              //itemId: is generated by BaseRaster will be: "panel_mWTabs" 
              items:[
                {
                 title:'Assets'+ (me.singleApp?' suchen':''),
                 itemId: 'assetsQueryTab',
                 cls: 'xty_assetsQueryTab',
                 tabCfg:{
                  itemId:'assetsQueryTab-tab'
                 },
                 
//                 bbar:{ 
//                      itemId: 'typefilterbar',
//                      defaults:{
//	                       enableToggle:true,
//	                       handler:function(button){  
//	                       button.ownerCt.ownerCt.submit();}
//	                    },
//	                    items:[
//	                        //'->',
//		                    {epobTypeId:extVia.enums.EpimObjects.ELEMENTS.id,  itemId:'Element',  type:'Element', iconCls:'xty_epob'+    extVia.enums.EpimObjects.ELEMENTS.key,  tooltip:  'Alle ' + extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"]} ,
//		                    {epobTypeId:extVia.enums.EpimObjects.IMAGEVAR.id,   itemId:'Image', type:'Image', iconCls:'xty_epob'+  extVia.enums.EpimObjects.IMAGE.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"]}, 
//		                    {epobTypeId:extVia.enums.EpimObjects.AUDIOVAR.id,   itemId:'Audio',  type:'Audio', iconCls:'xty_epob'+  extVia.enums.EpimObjects.AUDIO.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"]} ,
//		                    {epobTypeId:extVia.enums.EpimObjects.VIDEOVAR.id,   itemId:'Video', type:'Video', iconCls:'xty_epob'+  extVia.enums.EpimObjects.VIDEO.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"]},
//		                    {epobTypeId:extVia.enums.EpimObjects.GRAPHICVAR.id, itemId:'Graphic', type:'Graphic', iconCls:'xty_epob'+  extVia.enums.EpimObjects.GRAPHIC.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"]},
//		                    {epobTypeId:extVia.enums.EpimObjects.DOCUMENTVAR.id, itemId:'Document', type:'Document',iconCls:'xty_epob'+  extVia.enums.EpimObjects.DOCUMENT.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"]},
//		                    {epobTypeId:extVia.enums.EpimObjects.TEXTVAR.id, itemId:'Text', type:'Text',iconCls:'xty_epob'+  extVia.enums.EpimObjects.TEXT.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"]} 
//	                    ]
//                    },
                  
                  getEpobTypeFilters:function(){
                    var  epobTypeFilters=[];
                    //var typefilterbar = this.getDockedComponent('typefilterbar');  
                    
                    var typefilterbar = this.getTypeFilterbar(); 
                    
                    var i;
                    for (i = 1 ; i < typefilterbar.items.length; i++ ){
                      var item = typefilterbar.items.get(i);                     
                      if (item.pressed){                      
                        epobTypeFilters.push({ type:'epobType', epobType:item.type, value: item.epobTypeId, valueDscr: item.tooltip});
                      }
                    }
                    return epobTypeFilters; 
                  },

                  getTypeFilterbar:function(){
                   return this.getComponent('assetsQueryForm').getComponent('typefilterbar-bin').getComponent('typefilterbar');
                  },
                  syncUI:function(queryCfg){
                   
                    var assetsQueryTab =  extVia.regApp.myRaster.getWestTabPanel().getComponent('assetsQueryTab');
                    var assetsQueryForm = assetsQueryTab.getComponent('assetsQueryForm');
                    var searchtext = assetsQueryForm.getComponent('searchtext').setValue(queryCfg.searchtext); 
                    
                    var typefilterbar = assetsQueryTab.getTypeFilterbar(); //getDockedComponent('typefilterbar');
                    var i;
                    for (i = 1 ; i < typefilterbar.items.length; i++ ){
                      var item = typefilterbar.items.get(i);     
                      item.toggle(false);
                    }
                    
                    if (queryCfg.filters){
	                    for (i = 0 ; i < queryCfg.filters.length; i++ ){
	                      var filter = queryCfg.filters[i]; 
                          if (filter && filter.type==='epobType'){
                           var epobTypeButton = typefilterbar.getComponent(filter.epobType);
                           if (epobTypeButton) {
                           epobTypeButton.toggle(true);
                           }
                          }
	                  }
                    }
                  },
                  
                  getCategoryFilters:function(){
                    var  categoryFilters=[];
                    var categoriesTreePanel = this.getComponent('categoriesTreePanel');
                    var selectedRecords = categoriesTreePanel.getSelectionModel().getSelection(); 
                    var store = categoriesTreePanel.getStore(); 
                    
                    var i;
                    for (i = 0 ; i < selectedRecords.length; i++ ){
                      var record = selectedRecords[i];                
                      categoryFilters.push({ type:'Category', epobType: 'Category', path:record.getPath('id',':'), value:record.raw.value, valueDscr:record.get('text')});
                    }
                    return categoryFilters; 
                  },
                  
                  
                  submit:function(cfg){
                    var epobTypeFilters = this.getEpobTypeFilters(); 
                    var categoryFilters = this.getCategoryFilters();
                    var filters = Ext.Array.merge(categoryFilters, epobTypeFilters);
                    var fieldValues = this.getComponent('assetsQueryForm').getForm().getFieldValues();
 
                    fieldValues.filters=filters;
                    me.querySubmit(fieldValues); 
                  },

                  listeners:{
//                      activate : function(tab) {
//                      },
	                  show:function( panel){  
	                    if (!panel.beenShown){
	                     me.initModulePanel();
	                     panel.beenShown = true;
	                    } 
	                  }
                  },
                  
                  
                  items:[    
                   {
	                xtype: 'form',  // container
	                itemId: 'assetsQueryForm',
	                cls:'xty_queryQuick-formpanel',
	                border: false,
	                padding: '0 0 5 0',
	                defaults:{
	                  width:  310 ,
                    labelWidth: 130
	                },
                    submit:function(cfg){ return this.ownerCt.submit(cfg);},                 
	                items: [

                        { xtype: 'triggerfield',  
                          margin: '5 0 4 4',
                          name: 'searchtext', 
                          itemId:'searchtext',
                          //emptyText:'Suchtext', 
                          fieldLabel:'Suchtext', 
                          cls:'xty_has-insidetrigger', trigger2Cls:'xty_form-trigger-searchable' , trigger1Cls:'xty_inside-trigger-clear' , 
 
                          onTrigger1Click:clearHandler,
                          onTrigger2Click:function(evt){
                            var targetEl = Ext.get(evt.target.id); 
						    var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
						    var field = Ext.getCmp(fieldId);
                            field.ownerCt.submit({});
                          },
                          enableKeyEvents:true,
                          listeners:{
	                          keydown:function(field, evt){
			                   if (evt.getKey()===Ext.EventObject.ENTER){
                                 field.ownerCt.submit({});
			                   }
                               else if (evt.getKey()===Ext.EventObject.DELETE){
                                  field.setValue(''); 
                               }
			                } 
                          }
                        },  
                        
  
                        
                      { xtype: 'fieldcontainer',  
                      cls:'xty_form-field-toolbar-bin',
                      itemId:'typefilterbar-bin',
                      margin: '4 0 0 4',
                      fieldLabel:'Typen' ,
                      items:[
	                      { xtype: 'toolbar',  
	                          padding: '0 0 0 0',
                              cls:'xty_form-field-toolbar',
	                          name: 'typefilterbar', 
		                      itemId: 'typefilterbar',
		                      defaults:{
                                 margin: '0 1 0 0',
		                         enableToggle:true,
		                         handler:function(button){  
		                         button.ownerCt.ownerCt.ownerCt.submit();}
		                      },
		                       items:[
		                        //'->',
		                        {margin: '0 1 0 2', epobTypeId:extVia.enums.EpimObjects.ELEMENTS.id,  itemId:'Element',  type:'Element', iconCls:'xty_epob'+    extVia.enums.EpimObjects.ELEMENTS.key,  tooltip:  'Alle ' + extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"]} ,
		                        {epobTypeId:extVia.enums.EpimObjects.IMAGEVAR.id,   itemId:'Image', type:'Image', iconCls:'xty_epob'+  extVia.enums.EpimObjects.IMAGEVAR.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"]}, 
		                        {epobTypeId:extVia.enums.EpimObjects.AUDIOVAR.id,   itemId:'Audio',  type:'Audio', iconCls:'xty_epob'+  extVia.enums.EpimObjects.AUDIOVAR.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"]} ,
		                        {epobTypeId:extVia.enums.EpimObjects.VIDEOVAR.id,   itemId:'Video', type:'Video', iconCls:'xty_epob'+  extVia.enums.EpimObjects.VIDEOVAR.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"]},
		                        {epobTypeId:extVia.enums.EpimObjects.GRAPHICVAR.id, itemId:'Graphic', type:'Graphic', iconCls:'xty_epob'+  extVia.enums.EpimObjects.GRAPHICVAR.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"]},
		                        {epobTypeId:extVia.enums.EpimObjects.DOCUMENTVAR.id, itemId:'Document', type:'Document',iconCls:'xty_epob'+  extVia.enums.EpimObjects.DOCUMENTVAR.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"]},
		                        {epobTypeId:extVia.enums.EpimObjects.TEXTVAR.id, itemId:'Text', type:'Text',iconCls:'xty_epob'+  extVia.enums.EpimObjects.TEXTVAR.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"]} 
		                        ] 
	                       }
                       ]
                       },               
                 
	                 // searchbehaviour
	                //{xtype: 'hiddenfield', name: 'operator',  itemId: 'operator', value: 'OR', values:'AND|OR'},
                        
                    {xtype: 'hiddenfield', name: 'viewAs',   itemId: 'viewAs', value: 'list' , values:'list|thumbsBig|thumbsBigger|thumbsSmall|contentList|tree'},    
	                {xtype: 'hiddenfield', name: 'matching',   itemId: 'matching', value: 'CONTAINS' , values:'CONTAINSWORD|CONTAINS|STARTSWITH|ENDSWITH|EXACT'},
	                {xtype: 'hiddenfield', name: 'sortDir',    itemId: 'sortDir',  value: 'ASC' , values:'ASC|DESC'},
	                {xtype: 'hiddenfield', name: 'sortBy',     itemId: 'sortBy',   value: 'NAME' , values:'name|type|changedate|creationdate|id'},
                    //{xtype: 'hiddenfield', name: 'pageSize',   itemId: 'pageSize', value: me.pageSize , values:'10|20|50|100|200|500'},
                    //{xtype: 'hiddenfield', name: 'pageStartsFrom',   itemId: 'pageStartsFrom', value: me.pageStartsFrom },
                    {xtype: 'hiddenfield', name: 'startIndex',   itemId: 'startIndex', value: 0 }
                        
                        
	                    ]
	                 },
	                 
                   Ext.create('Ext.tree.Panel', {
                    title:'Kategorien',
                    style:'border-top:1px solid #99BCE8;',
                    itemId:'categoriesTreePanel',
                    bodyStyle:'padding:4px;',
                    emptyText:'keine Assets f&uuml;r diesen Filter',

					// >>>>>>>>>>>>>>>> filter Func Start <<<<<<<<<<<<<<<<<<<<< //                  
					// Copied from  extjs4-treefilter.js   https://gist.github.com/colinramsay/1789536 07.07.2015       
				    filterByText: function(text) {
				     this.filterBy(text, 'text');
				    },
				    /**
				     * Filter the tree on a string, hiding all nodes expect those which match and their parents.
				     * @param The term to filter on.
				     * @param The field to filter on (i.e. 'text').
				     */
				    filterBy: function(text, by) {
				 
				        this.clearFilter();
				        
				        if(Ext.isEmpty(text)) {
				        	return;
				        }
				 
				        var view = this.getView(),
				            me = this,
				            nodesAndParents = [];
				 
				        // Find the nodes which match the search term, expand them.
				        // Then add them and their parents to nodesAndParents.
				        this.getRootNode().cascadeBy(function(tree, view){
				            var currNode = this;
				 
				            if(currNode && !currNode.isLeaf() && currNode.data[by] && currNode.data[by].toString().toLowerCase().indexOf(text.toLowerCase()) > -1) {
				                me.expandPath(currNode.getPath());
				 
				                while(currNode.parentNode) {
				                    nodesAndParents.push(currNode.id);
				                    currNode = currNode.parentNode;
				                }
				            }
				        }, null, [me, view]);
				            

				 
				        // Hide all of the nodes which aren't in nodesAndParents
				        this.getRootNode().cascadeBy(function(tree, view){
				            var uiNode = view.getNodeByRecord(this);
				 
				            if(uiNode && !Ext.Array.contains(nodesAndParents, this.id)) {
				                Ext.get(uiNode).setDisplayed('none');
				            }
				        }, null, [me, view]);
				    },
				    clearFilter: function() {
				        var view = this.getView();
				 
				        this.getRootNode().cascadeBy(function(tree, treeView){
				        	var node = this,
				        		nodeView;
				        		
				            nodeView = treeView.getNode(node);
				 
				            if(!Ext.isEmpty(nodeView)) {
				            	
				            	new Ext.Element(nodeView).setDisplayed('table-row');

				            }
				        }, null, [this, view]);
				    },  
                    // >>>>>>>>>>>>>>>> filter Func Ende  <<<<<<<<<<<<<<<<<<<<< //                   
                  
                  
	                multiSelect:true,
	                rootVisible:true,
	                //collapsed:true,
	                store: me.elementTreeStore,
	                border: false,
	                bodyBorder:false,
	                height: (Ext.getCmp('panel_mw').getHeight() - 132),//500,//myContentPanelHeight/3,
	                //preventHeader: true,
	                header: false,
	                hideHeader: true,
	                viewConfig: {
                      plugins: {
                          ptype: 'treeviewdragdrop'
                      }
	                  },
	                useArrows: true,
	                itemIsDblClicked:false,
                    submit:function(cfg){return this.ownerCt.submit(cfg);},
                  
	                listeners: {
                       afterrender:function( panel){  
                            var header = panel.down('header');
						    if(header) {
						      header.addCls('x-accordion-hd');
						      //header.addCls('xty-header-accordionstyle');
						    }
                        },
                        itemclick:function( view, record, item, index, evt ){  
                          var itemClickAction = function(){
                           if (!view.itemIsDblClicked){
                             if (record.isLeaf()){
                                var forJSLINT;
                               // me.showQuickview({record:record})
                               }
                             }
                           };
                           var itemClickDelayed = new Ext.util.DelayedTask(itemClickAction);
                           itemClickDelayed.delay(200);
                          },
                          itemdblclick:function( view, record, item, index, evt ){
                          view.itemIsDblClicked = true;
                          if (!record.isLeaf()){
//	                              var itemDblClickAction = function(){
//                                    view.ownerCt.submit({});
//	                              };
//	                              itemDblClickAction();    
                              view.ownerCt.submit({});                         
                          } 
                          else{
                           me.showQuickview({record:record});
                          }
                              

                          var resetIsDblClickedDelayed = new Ext.util.DelayedTask(
                          function(){view.itemIsDblClicked = false;});
                          resetIsDblClickedDelayed.delay(210);
                          
                        }
                      }
              })   ,
              
              
                { xtype: 'triggerfield',  margin: '18 0 0 10' ,  
                
                  style:'position: absolute; top:44px; left:128px;z-index:9999;',
                  //emptyText:'Kategorienfilter',
                  //fieldLabel:'Kategorienfilter',
                   width:176,
                   height:18,
                  name: 'categoriesTreefilter', 
                  cls:'xty_panelheader-field xty_has-insidetrigger', trigger2Cls:'xty_form-trigger-filterable',  trigger1Cls:'xty_inside-trigger-clear', 
                  onTrigger1Click:clearHandler,
                  enableKeyEvents:true,
                  listeners:{
                   keydown:function(field, evt){
                    if (evt.getKey()===Ext.EventObject.DELETE){
                     field.setValue(''); 
                    }
                   }, 
                   change:function( field, newValue, oldValue ){
                    var delayedFilterTask = new Ext.util.DelayedTask(function(){
                       var categoriesTreePanel = field.ownerCt.getComponent('categoriesTreePanel');
                       categoriesTreePanel.filterBy(newValue, 'text');
		              });
		              delayedFilterTask.delay(500);
                   }
                  }
                }         
                 
            ]
          } 
       ] 
      };
      
      var queryPanel ;
      var tabPanelWest;
      if (me.singleApp  && extVia.regApp.myRaster.initWestTabPanel){
        tabPanelWest = extVia.regApp.myRaster.initWestTabPanel(westTabPanCfg);
        queryPanel = extVia.regApp.myRaster.addToWest(tabPanelWest);
      }else{ // embeddedApp
        westTabPanCfg =  westTabPanCfg.items[0]; 
        westTabPanCfg.tabConfig = {epob :{typeId:6019}} ;
        tabPanelWest = extVia.regApp.myRaster.getWestTabPanel();
        queryPanel =  tabPanelWest.insert(2,westTabPanCfg);     

        
        var  westTabPan = extVia.regApp.myRaster.getWestTabPanel();
        westTabPan.on('tabchange' , function ( tabPanel, newCard, oldCard ){
 
        if ( (oldCard.itemId==='elasticQueryTab' && newCard.itemId==='assetsQueryTab') 
           || (oldCard.itemId==='assetsQueryTab' && newCard.itemId==='elasticQueryTab')  ){

            var  centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
            var elasticHomePanel  = centerTabPan.getComponent('elasticHomePanel');
            var assetsHomePanel  = centerTabPan.getComponent('assetsHomePanel');
            
            if (oldCard.itemId==='elasticQueryTab'){
              elasticHomePanel.tab.hide();
              assetsHomePanel.tab.show();
              centerTabPan.setActiveTab(assetsHomePanel);
            }
            else {
              assetsHomePanel.tab.hide();
              elasticHomePanel.tab.show();
              centerTabPan.setActiveTab(elasticHomePanel);
            }          
        } 
          
        });
      }
      
      	
      extVia.elastic.statics.getCategoryTreeRoot(function(root){
			me.elementTreeStore.setRootNode(root);	
      });
      
       return queryPanel;
      
     },

     
    initUtilFunctions : function(cfg){
      
      extVia.formatAutoCompleteText = function (textStr, outermatchHighlighting  , boundlistId, boundlistParentId) {
      var formattedStr = textStr;
      try{ 
            //var combo = Ext.getCmp(boundlistParentId).items[0];
            
            var searchVal = extVia.currentRawValue;// workaround in set store filters
            searchVal = searchVal.replace( /[*%]/g, ".*");
            var valX  = new RegExp("("+searchVal+")", 'i');
        // if googleHighlighting
        if(outermatchHighlighting){      
         // whats not found
         //formattedStr = formattedStr.replace(valX,"</b>$1<b style='background:#eaf4f9'>");
           //formattedStr = "<b style='background:#eaf4f9'>"+formattedStr+"</b>"       
         // whats left
         formattedStr = formattedStr.replace(valX,"$1<b style='background:#f4fbba' class='xty_hit'>");
         formattedStr = formattedStr+"</b>";
        }
        else {
          // whats found
          formattedStr = formattedStr.replace(valX,"<span style='background:#f4fbba;' class='xty_hit'>$1</span>");
        } 
      }catch(ex){ }
      return formattedStr;
    };
    
    
    }, 
    
    
    getCenterTabPanelCfg : function(cfg){ 
      var me = this;
      var centerTabPanelCfg = {
         modulePanelCfg: me.getModulePanelCfg(cfg),
         layout:'fit',
         autoScroll : true
      };
      return centerTabPanelCfg;
    },
    
    
    getModulePanelCfg : function(cfg){
        var me = this;
        var centerPan =  extVia.regApp.myRaster.getCenter();
        
        var centerWidth = centerPan.getWidth()-50;
        var centerHeight = centerPan.getHeight()-138;
        
        var buttonHandler = function(button){
            var searchtext =  button.ownerCt.ownerCt.getComponent('pgContentPanel').getComponent('searchfield-XXXXXL-bin').getComponent('searchfield').getValue();   
            me.querySubmit({ mode:'extend',  filters:[{ type:'epobType', epobType:button.epobType, value:button.epobTypeId}], searchtext:searchtext}); 
         };
        
        var modulePanelCfg = {
                showTabItem: true,
                iconCls : 'xty_home-icon',
                itemId:'assetsHomePanel',
                title:' ', 
                pgjobDscr: 'Asset Browser', 
                tbar:{
                defaults:{               
                    scale:'large'
                  
                    },

                   items:[
                    '->',
                    {epobTypeId:extVia.enums.EpimObjects.ELEMENTS.id, scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Element', iconCls:'xty_epob'+    extVia.enums.EpimObjects.ELEMENTS.key,  tooltip:  'Alle ' + extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"]} ,
                    {epobTypeId:extVia.enums.EpimObjects.IMAGEVAR.id,scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Image', iconCls:'xty_epob'+  extVia.enums.EpimObjects.IMAGE.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"]}, 
                    {epobTypeId:extVia.enums.EpimObjects.AUDIOVAR.id,scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Audio', iconCls:'xty_epob'+  extVia.enums.EpimObjects.AUDIO.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"]} ,
                    {epobTypeId:extVia.enums.EpimObjects.VIDEOVAR.id,scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Video', iconCls:'xty_epob'+  extVia.enums.EpimObjects.VIDEO.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"]},
                    {epobTypeId:extVia.enums.EpimObjects.GRAPHICVAR.id,scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Graphic', iconCls:'xty_epob'+  extVia.enums.EpimObjects.GRAPHIC.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"]},
                    {epobTypeId:extVia.enums.EpimObjects.DOCUMENTVAR.id,scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Document', iconCls:'xty_epob'+  extVia.enums.EpimObjects.DOCUMENT.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"]} ,
                    {epobTypeId:extVia.enums.EpimObjects.TEXTVAR.id,scale:'large',enableToggle:true, handler: buttonHandler, epobType:'Text', iconCls:'xty_epob'+  extVia.enums.EpimObjects.TEXT.key ,  tooltip:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"]} 
                    // {itemId:'list'},{itemId:'thumbsBig'},{itemId:'thumbsSmall'},
                    
                    //{tooltip:'heavyweigt proto', scale:'small', iconCls:'xty_pgtoolbar-protoui', handler:function(){ window.open("../../../../../../../jsp/QueryApp.jsp?epobType=PRODUCT&appModeName=queryLoadModule&map=loadModule:mam,loadModuleMain:mamMain","newwindow");}}  
                  ]
              },

             
              items:[
              
                 {itemId:'pgContentPanel',border:false,
                 
	               layout: {
	                    type: 'vbox',
	                    pack: 'center',
	                    align : 'center'
	                },
			        height:centerHeight,
                     
                     items:[
                     
//                     {  cls:'xty_clipboard-selection-bin xty_clipboard-selection', 
//                        tbar:[{text:'clicky'}],
//                        html:'<div class="" style="padding:50px; ">  ' +
//                        ' <div class="xty_clipboard-selection" style="padding:50px;width:300px ; height:50px; backgsround-color:gold; ">clipboard-selection test</div> ' +
//                        '</div>'
//                     },
                     
                     
                  {
                   xtype: 'fieldcontainer', 
                   //margin:'0 0 10 0',
                   itemId:'searchfield-XXXXXL-bin', cls:'xty_formfield-XXXXXL-bin', layout: {type: 'table', cols:2,  alsign: 'left'}, 
                   items:[ 
                      {xtype:'button', itemId:'searchbutton', scale:'large',  cls: 'xty_searchtrigger-button', iconCls: 'xty_searchtrigger-XXXXXL' , width:84, height:84,
                         handler:function(butt){
                          var searchtext = butt.ownerCt.getComponent('searchfield').getValue();
                          me.querySubmit({ mode:'quick', searchtext:searchtext}); 
                        }
                        },
                      {xtype:'triggerfield', itemId:'searchfield', border:true, cls:'xty_formfield-XXXXXL xty_has-insidetrigger',  
                         trigger1Cls:'xty_inside-trigger-clear' ,  
                         onTrigger1Click: me.clearHandler, 
                         emptyText:'Bilder, Grafiken, Dokumente und mehr finden...',
                         //width:centerPan.getWidth()-(340), 
                         
                         height:84,
                         enableKeyEvents : true,
                         listeners:{
                          keydown:function(field, evt){
			                  if (evt.getKey()===Ext.EventObject.ENTER){
			                    me.querySubmit({mode:'quick', searchtext:field.getValue()}); 
			                  }
	                            else if (evt.getKey()===Ext.EventObject.DELETE){
	                             field.setValue(''); 
	                            }
			                },
                          focus:function(field){
                           var searchbutton = field.ownerCt.getComponent('searchbutton');
                           searchbutton.addCls('xty_focus-by-sibling');
                          },
                          blur:function(field){
                           var searchbutton = field.ownerCt.getComponent('searchbutton');
                           searchbutton.removeCls('xty_focus-by-sibling');
                          }
                         }
                         
                         }
                     ],
                     doResize:function(){
                      var centerWidth = centerPan.getWidth();
                      var newWidth = centerWidth-340;
                      this.setWidth(newWidth+84);    
                      var  searchfield =  this.getComponent('searchfield');
                      searchfield.setWidth(newWidth);    
                      centerPan.doLayout();
                     } 
                   }
                  ],
                  
                  listeners:{// pgContentPanel
                   resize:function(panel){
                    var fieldcontainer = panel.getComponent('searchfield-XXXXXL-bin');
                    fieldcontainer.doResize();
                   }
                 }
                  
                }
                ] 
              };
      return modulePanelCfg;
    },
     
    
    initModulePanel: function() {
        var me = this;
        var centerTabPanelCfg = me.getCenterTabPanelCfg();
        var centerTabPan;
        var modulePanel;
	    if (me.singleApp  && extVia.regApp.myRaster.initCenterTabPanel){
	      centerTabPan  =  extVia.regApp.myRaster.initCenterTabPanel(centerTabPanelCfg); 
          modulePanel  = centerTabPan.getComponent('modulePanel');
          extVia.regApp.myRaster.addToCenter(centerTabPan);
          centerTabPan.setActiveTab(modulePanel);
          
          modulePanel.getComponent('pgContentPanel').getComponent('searchfield-XXXXXL-bin').getComponent('searchfield').focus();
	    }else{
	      var modulePanelCfg = me.getModulePanelCfg();
          
	      centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
	      modulePanel = centerTabPan.addAndActivate(modulePanelCfg);   
	      var task = new Ext.util.DelayedTask(function(){
			 modulePanel.getComponent('pgContentPanel').getComponent('searchfield-XXXXXL-bin').getComponent('searchfield').focus();
		   });
		  task.delay(500);   
	    }
        
        me.loadMask = new Ext.LoadMask(Ext.get('panel_mC'), {msg:"Lade Assets..."});
        
        //var centerTabPan  =  extVia.regApp.myRaster.initCenterTabPanel(centerTabPanelCfg);      
        //var modulePanel  = centerTabPan.getComponent('modulePanel');
//        extVia.regApp.myRaster.addToCenter(centerTabPan);
//        centerTabPan.setActiveTab(modulePanel);
       
        
        me.modulePanel = modulePanel;
        return modulePanel;
    },
    
    
    launch: function() {
      

      var me = this;
      var embeddedApp=false;
      embeddedApp = location.href.indexOf('QueryApp.jsp')>-1 ;
      var singleApp= !embeddedApp;
      singleApp = location.href.indexOf('assetsProto.html')>-1 ;

      me.singleApp = singleApp;
      me.embeddedApp = embeddedApp;
      
      
      extVia.assetsApp = me;
      
      var objectModelCfg  =  extVia.elastic.statics.getObjectModelCfg();
	  var elementModelCfg  =  extVia.elastic.statics.getElementModelCfg();
	  var imageModelCfg  =  extVia.elastic.statics.getImageModelCfg();
        
	    Ext.define('ExtVia.model.elastic.Object', {
		    extend : 'Ext.data.Model',
		    fields : objectModelCfg.fields
	    });
		Ext.define('ExtVia.model.elastic.Element', {
			extend : 'ExtVia.model.elastic.Object',
	        fields : elementModelCfg.fields
		});
		Ext.define('ExtVia.model.elastic.Image', {
		    extend : 'ExtVia.model.elastic.Element',
		    fields : imageModelCfg.fields
		});

	
      
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	
      
        me.initUtilFunctions();
      
        if (singleApp) {
          extVia.regApp = this;
	    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside
	    	//var viewCfg = {hideNorth:false,hideWest:false, buildEast:false, buildSouth:false};
	        //var viewCfg  = extVia.ui.page.BaseRaster.prototype.getViewConfigFromUrl();
	        //viewCfg.buildEast =true; viewCfg.hideEast=true;
	    	//extVia.ui.page.raster = new extVia.ui.page.BaseRaster(viewCfg); //BaseRaster({viewCfgFromUrl:true});
	      
	        extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true,buildEast:true, hideEast:true});
	
	    	extVia.ui.page.raster.onReady(this);
        
            me.initQueryPanel({});

	        extVia.constants.raster.eastWidth+=20 ;
	    
	        me.initModulePanel({});  
          
//	        var centerTabPanelCfg = me.getCenterTabPanelCfg();
//	        var centerTabPan  =  extVia.regApp.myRaster.initCenterTabPanel(centerTabPanelCfg);        
//	        var modulePanel  = centerTabPan.getComponent('modulePanel');
//	    	extVia.regApp.myRaster.addToCenter(centerTabPan);
//	        centerTabPan.setActiveTab(modulePanel);
//	        me.loadMask = new Ext.LoadMask(Ext.get('panel_mC'), {msg:"Lade Assets..."});
//	        modulePanel.getComponent('pgContentPanel').getComponent('searchfield-XXXXXL-bin').getComponent('searchfield').focus();
        }
        
         

    }
});


