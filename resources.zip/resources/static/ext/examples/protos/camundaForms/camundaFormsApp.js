/*


*/
Ext.application({
    name: 'camundaForms',
    
    appMode:{},
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (cfg){
     var me = this;
     return me.getCenterHeight(cfg); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerHeight = centerPan.getHeight()-28; // 28 tabstrip
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=86;
      }
      if (cfg && cfg.hasSubtabs){
        //centerHeight-=86;
        var a = 2;
      }      
      return centerHeight;
    },
    
    
    getFormSnippetsList : function(){
          var me = this;
          var formSnippetModel = Ext.define('FormSnippet', {
              extend: 'Ext.data.Model',
              fields: [{type: 'string', name:'type'},{type: 'string', name:'name'},{type: 'string', name:'type'}, {type: 'string', name:'uicontrols'},{type: 'string', name:'status'}]
          });
          var data =   [
          
            {name:'form-snippet-definition.html', uicontrols:'text', type:'definitions',  status:''}, 

            {name:'simple-nickname.html', uicontrols:'text', type:'2344 examples',  status:''}, 
            {name:'simple-responsible.html', uicontrols:'select', type:'2344 examples',  status:''}, 
            {name:'simple-deadline.html', uicontrols:'date', type:'2344 examples',  status:''}, 
            {name:'simple-decision.html', uicontrols:'checkbox,radio', type:'2344 examples',  status:''}, 
            {name:'deeplinks.html', uicontrols:'checkbox,,button', type:'2344 examples',  status:''}, 
            {name:'simple-price.html', uicontrols:'range', type:'2344 examples',  status:''}, 

            {name:'basic-booking.html', uicontrols:'text,select,range,date,textarea,checkbox', type:'2344 examples',  status:''}, 

            {name:'all-supported-fields.html', uicontrols:'text,number,date,select,range,checkbox,radio,textarea,messages', type:'2344 examples',  status:''}, 
            
          //       basic Form

           //text combo textarea check date

            
          //  fullStack Form(all supported fields)

            
            {name:'approve-invoice.html', uicontrols:'text,checkbox', type: 'old', status:''}, 
            {name:'approveLoan.html', uicontrols:'text,date,select',  type: 'old', status:''}, 
            {name:'assign-reviewer.html',  uicontrols:'text,select', type: 'old', status:''}, 
            {name:'my-form.html', uicontrols:'text,select,range,date,button,textarea,checkbox',type: 'old', status:''}, 
            {name:'prepare-bank-transfer.html',  uicontrols:'message,text', type: 'old', status:''}, 
            {name:'reviewing.html', uicontrols:'text,select,checkbox',  type: 'old', status:''}, 
            {name:'review-invoice.html',  uicontrols:'text,select,checkbox,button', type: 'old', status:''}, 
            {name:'start-form.html',  uicontrols:'text,file,number', type: 'old', status:''},
            {name:'request-loan.html', uicontrols:'text,select,checkbox,button', type: 'old', status:''},
            {name:'variablesForm.html', uicontrols:'message,select,number,text,textarea', type: 'old', status:''}
        ];

        var formSnippetsStore = Ext.create('Ext.data.Store', {
          model: formSnippetModel,
          storeId:'formSnippetsStore',
          groupField : 'type',
          data: data
        });  

      
      var   formSnippetsListCfg ={
       xtype:'grid',
       itemId:'formSnippetsGrid',
       id:'formSnippetsGrid',
       store: formSnippetsStore,
       //viewConfig : { emptyText:'keine Inhalte zum Anzeigen.'},
       
       getColumnName:function(){                           
         var columnFieldName = this.features[0].getGroupField();
         return  columnFieldName ;
       },  
       features: [Ext.create('Ext.grid.feature.Grouping',{
            groupHeaderTpl: '{name} ({rows.length})'
       })], 
       
       
       border:false,
       autoScroll:true,
       height:me.getContentPanelHeight(),
       columns:  [
       {header:'Typ', dataIndex:'type', width:42},
       {header:'Name', dataIndex:'name',
         width:160   ,
         renderer:function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           var isnew = rowIndex<5;
           if (isnew){
             metaData.tdCls='xty-task-isnew'; 
             value+='<span class="xty-task-isnew-star">&nbsp;&nbsp;&nbsp;</span>';
           }
           return value;
           }
       },
       {header:'UI controls', dataIndex:'uicontrols',
        renderer:function ( value, metaData, record, rowIndex, colIndex, store, view )  {
          var html = '';
          var controls= value.split(',');
		  var i;
		  for (i=0; i < controls.length; i++){
           var control = controls[i];
           html+='<span class="xty_uicontrol-icon" title="'+control+'" style="background-image: url(../img/epobs/uicontrols/'+control+'.png);">&nbsp;&nbsp;&nbsp;</span>';
          }
          return html;
        }
       },
       {header:'Status', dataIndex:'status', width:42,
         renderer:function ( value, metaData, record, rowIndex, colIndex, store, view )  {
          var status = value ? value :'Nothing'; 
         return '<div class="xty_icon xty_icon'+status+'" data-qtip="'+status+'"  ></div>'; 
         }
       }
 
     
       ],
       listeners:{
          itemdblclick: function( view, record, item, index, evt ){ 
            
            if (evt.hasModifier()){
              window.open('./formSnippets/'+record.get('name'),"newwindow");
            }
            else{
             me.addFormSnippetsEditor({record:record});
            }
           
          }
        } 
      };
      return formSnippetsListCfg;
    },
    
    
    
    addFormSnippetsEditor : function(cfg){
      
       var me = this;
      
      var name = cfg.record.get('name');
      var formId = name.replace(/\.html/, '');
      var epobDscr = name;
      var url = './formSnippets/'+name;
      var editorId = Ext.id(null,'editor');
      
      
      
	// Desired display Panel to show the camunda Form    
	 var transformedFormPanel =   Ext.create('Ext.form.Panel', {
	    title: 'Transformed ',
	    width: 580,
	    height: 500,
	    cls:'xty_bpm-dialog-form-panel',
	    autoScroll:true,
      
//      standardSubmit : Boolean
//      standardSubmit : Boolean, BaseParams, url
      
        editorId: editorId+'-transformedFormPanel',
      
        listeners:{
         afterrender: function ( formpanel ){
           // contact  parentDialog iCamSDKDialog
           // send Height and mainInstructon and hide LoadingMask
         },
         
         validitychange: function( basicform, valid){ 
          var formpanel = basicform.owner; 
          var parentDialog = formpanel; // iCamSDKDialog
          //var buttonsbar = parentDialog.getDockedComponent( 'buttons' );
          var buttonsbar = parentDialog.getDockedComponent(1);
          //alert('validitychange  valid '+valid+'  buttonsbar '+ buttonsbar);            
          var submitBtn = buttonsbar.getComponent('submit');
          if (submitBtn){
           submitBtn.setDisabled( !valid );
          }
         }
        },

        buttons:{ 
            itemId:'buttons', 
            items: [
              {text:'submit',itemId:'submit', 
               handler:function(btn){
			    var formPan = btn.ownerCt.ownerCt; 
			    var form = formPan.getForm();
		        
			    //alert('try to submit transformed Form is valid['+form.isValid()+'] '+ Ext.encode(form.getValues()));
			    window.alert('try to submit transformed Form is valid['+form.isValid()+'] ' +
		            '\n form.getValues\n'+ Ext.encode(form.getValues()) +
		            '\n form.getFieldValues\n'+ Ext.encode(form.getFieldValues())
			    );
		       }
            }]
        }
	});      
      




var transformSnippet = function(){  
  

   var holderId = editorId+'-domHolderPanel';  
   
   // Better if We should start one step higher on the FORM TAG
   var formId = name.replace(/\.html/, '');
   var formHtmlEl   = extVia.camundaForms.FormParser.statics.findForm({containerEl: Ext.get(holderId), formId: formId});    

   var formGroupsCfgs   = extVia.camundaForms.FormParser.statics.findFormItems({containerEl: formHtmlEl, formId:formId});    
  
    var i;
     for (i=0; i <formGroupsCfgs.length; i++){
       transformedFormPanel.add(formGroupsCfgs[i]); 
     }
     var newOrgFormId =  Ext.id(null , 'formSnippet')+ '-'+formId ;
     formHtmlEl.id=newOrgFormId; 
   return formId;
};    



var transformTask = new Ext.util.DelayedTask(function(){
  transformSnippet();
});

     
 var holderPanel =   Ext.create('Ext.form.Panel', {
    title: 'DOM Holder ',
    width: 360,
    height:500,
    id: editorId+'-domHolderPanel',
    tools:[{itemId:'transform', type:'right', cls:'x-tool-gear', title:'transform', handler : transformSnippet}],
    buttons:[{text:'submit', handler:function(btn){
      var formelements = document.forms[formId].elements;
      var formvalues = {};
      var i;
      for(i=0; i<formelements.length; i++){
       var formEl = formelements[i];
       formvalues[formEl.id]= formEl.value;
      }
      window.alert('try to submit original Form ['+ formId +'] '+ Ext.encode(formvalues));
      }
      }]
});      
      
      

     var topPanelsHeight = 180;
 
      
      var pagejobButtons = [{itemId:'tree'},{itemId:'list'},{itemId:'back'}];
      var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
      var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Form Snippet', epobDscr: epobDscr,   pagetoolbarButtons: null, pgjobButtons: null } ); 
//        // Your App
        var appPanel = {
           tbar :appbar,
           title:epobDscr,
           defaults:{margin:'12 12 12 12', animCollapse : false},
           layout:{
            type:'table',
            columns:2
           },
           height: me.getEditorContentPanelHeight(),
           autoScroll:true,
           items:[

            {title: 'IFRAME ', colslapsed:true,  collapsible:true, itemId:'snippetIframe', width:360, height:topPanelsHeight, 
             listeners:{
              collapse: function(panel){panel.ownerCt.getComponent('sourcecode').collapse();}
             },
            html:    '<div><iframe id="'+editorId+'-snippetIframe" frameborder="0"  style="height:'+topPanelsHeight+'px; width:360px;" src="'+url+'" /></div>'},

            
            {xtype:'panel', title:'sourcecode', itemId:'sourcecode', collsapsed:true,  collapsible:true, width:580, height:topPanelsHeight,
             listeners:{
              collapse: function(panel){panel.ownerCt.getComponent('snippetIframe').collapse();}
             },
            
            items:{
	        xtype: 'htmleditor',height:topPanelsHeight,
            itemId:'htmleditor',
            collapsible:true, 

           enableAlignments : false, enableColors :  false, 
           enableFont :  false, enableFontSize :  false, 
           enableFormat : false, enableLinks :  false, enableLists: false,
           enableSourceEdit : true,

            listeners:{  
             afterrender: function(htmleditor){
              
              
              var collapsePanelTask = new Ext.util.DelayedTask(function(){ 
               htmleditor.ownerCt.collapse();
              });
              
              
              var loadTask = new Ext.util.DelayedTask(function(){ 
              var iframe = document.getElementById(editorId+'-snippetIframe');
              var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
              
              var snipHTML = iframeDocument.body.innerHTML;
              
               htmleditor.setValue(snipHTML);
               
               var domHolderPanel = Ext.getCmp(editorId+'-domHolderPanel');
               domHolderPanel.add({ margin:'4 4 4 4',id:editorId+'-snip',itemId:editorId+'-snip', html:snipHTML});

               //Ext.removeNode(iframe);   //inputEl.destroy();
               
               
				});
              loadTask.delay(200);   

              transformTask.delay(200);   

              collapsePanelTask.delay(200);
              
              
              }
            }
           }
            },
           
           holderPanel,
           transformedFormPanel
            ] 
        };

      appPanel.closable=true;

      var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
      centerTabPan.addAndActivate(appPanel);

    },

    showFormSnippetDialog: function(cfg) {
     
	      var formSnippetDialog = Ext.create('widget.window', {
		      width: 580,
              //height : 224,
		      y: 120,
	          title:'formSnippet ',
              border:false,
	          plain: true,
              cls: 'xty_bpm-form-dialog xty_dialog-isloading', 
	          items : [
               {
		          style : 'margin:0;padding:0px; border:1px solid #d0d0d0; bodrder-right:1px solid #99BCE8;bodrder-bottom:1px solid #99BCE8;',
		          width:570,
                  //height:320,

		          //maxHeight: config.maxHeight,
		          //minHeight: config.minHeight,
		          itemId : 'iframe',
		          //cls : 'xty_dialog-item-panel  xty_dialog-content-item-panel  xty_dialog-iframe-panel ',
		          xtype : "component",
		          autoEl : {
		            border : true,
		            layout : 'fit',
		            tag : "iframe",
		            name: 'CamFormFrame',
		            frameborder : 0,
                    src : './SnippetTransformer.html' //srcUrl
		          }
               }
  
	           ],
               buttons:{ 
                defaults:{
                 markDisabled : function(disabled){
                   if (disabled){
                     this.addCls('x-item-disabled'); // x-disabled x-btn-disabled x-btn-default-small-disabled')
                   }
                   else{
                     this.removeCls('x-item-disabled'); // x-disabled x-btn-disabled x-btn-default-small-disabled')
                   }
                 }
               },  
              itemId:'buttons', 
	            items: [
	              {text:'reset',itemId:'reset', margin:'0 160 0 0', 
	                dissabled:true,
	                cls:'x-item-disabled',
	                handler:  function resetButtonHandler(btn){  
	                 var dialog = btn.ownerCt.ownerCt; 
	                // noramlly its this
	                //var formpanel = dialog.getComponent('myForm'); 
	                // in our iframecase we use this
	                var formpanel =  dialog.formpanel;
	                if (formpanel){
	                  var form = formpanel.getForm();
	                  form.reset();
	                }
	               } 
	              },
	              
	              {text:'submit',itemId:'submit', 
	               handler:function(btn){ 
	                 
                   var dialog = btn.ownerCt.ownerCt; 
                   // noramlly its this
                   //var formpanel = dialog.getComponent('myForm'); 
                   // in our iframecase we use this
                   var formpanel =  dialog.formpanel;
                   if (formpanel){
                     var form = formpanel.getForm(); 
                     if (form.isValid()){
                       //alert('try to submit transformed Form is valid['+form.isValid()+'] '+ Ext.encode(form.getValues()));
                       window.alert('try to submit transformed Form is valid['+form.isValid()+'] ' +
                             '\n form.getValues\n'+ Ext.encode(form.getValues()) +
                             '\n form.getFieldValues\n'+ Ext.encode(form.getFieldValues())
                       ); 
                     }
                   }
	              }
	            },
                {text:'cancel',itemId:'cancel', handler: function(btn){btn.ownerCt.ownerCt.hide();}}
              
              ]
	        }  
 
                
          });
          formSnippetDialog.show();
          extVia.iCamSDKDialog = formSnippetDialog;
 
     
    },
    
    showTasklist: function(cfg) {
     var me = this;
     var topPanelsHeight = 180;
     var editorContentPanelHeight = me.getEditorContentPanelHeight();

     
     
     var appbar;
     
     var taskviewsBtnHandler = function (btn){
       appbar.setPagejobDscr(btn.tooltip);
     };
     
     
     
     var checkHandler = function(btn){
      
       

 
       
       var fullCaseMainInstruction ='Do you want to complete all tasks?'; 
       
       var completeTasksFullCaseDialogCfg = {
         width: 480,
         x:400,
         y: 160,
         modal:true,
         itemId:'completeTasksDialog',
         title: 'Completing 5 Tasks <span class="xty_dialog-title-hint"> full case</span>',
         iconCls: 'xty_icon xty_iconQuestion',
         plain: true,
         items : [ 
           {
             border : false,
             minHeight : 200,
             itemId:'completeTasksDialog-body',
             items : [ 
               {
                 itemId : 'mainInstruction',
                 border : false,
                 margin:'10 10 10 10',
                 html : '<div class="xty_dialog-mainInstr">'+fullCaseMainInstruction +'</div>'
               }
               ]
           }
         ],
         buttons:[
           {xtype:'tbspacer', width:30},
           {text:'Yes'},
           {text:'No', handler:function(button ){ button.ownerCt.ownerCt.hide();   }},
           {text:'Cancel', handler:function(button ){ button.ownerCt.ownerCt.hide();   }}
         ]            
     };

      var completeTasksFullCaseDialog  = Ext.create('widget.window', completeTasksFullCaseDialogCfg);

      completeTasksFullCaseDialog.show();
       
       

       
       var mixedCaseMainInstruction = 'Do you like to complete the 2 completable tasks?';
       
       var mixedCaseSuppInstr = '3 out of 5 cannot be completed, because of missing field values.';
  
       

       
       
       var completeTasksMixedCaseDialogCfg = {
         width: 480,
         y: 320,
         x: 400,
         itemId:'completeTasksDialog',
         title: 'Completing 5 Tasks  <span class="xty_dialog-title-hint"> mixed case</span>',
         iconCls: 'xty_icon xty_iconQuestion',
         plain: true,
         items : [ 
           {
             border : false,
             minHeight : 200,
             itemId:'completeTasksDialog-body',
             items : [ 
               {
                 itemId : 'mainInstruction',
                 border : false,
                 margin:'10 10 10 10',
                 html : '<div class="xty_dialog-mainInstr">'+mixedCaseMainInstruction +'</div>'
               } ,
               {
                 itemId : 'suppInstruction',
                 border : false,
                 margin:'10 10 10 10',
                 html : '<div class="xty_dialog-supplementalInstr">'+mixedCaseSuppInstr +'</div>'
               } 
               ]
           }
         ],
         buttons:[
           {xtype:'tbspacer', width:30},
           {text:'Yes'},
           {text:'No', handler:function(button ){ button.ownerCt.ownerCt.hide();   }},
           {text:'Cancel', handler:function(button ){ button.ownerCt.ownerCt.hide();   }}
         ]       
     };
     
    var completeTasksMixedCaseDialog  = Ext.create('widget.window', completeTasksMixedCaseDialogCfg);
    completeTasksMixedCaseDialog.show();


    
    var completeTasksMixedCaseDetailsDialogCfg = Ext.apply(
      completeTasksMixedCaseDialogCfg,
      {
       x:900,
       title: 'Completing 5 Tasks  <span class="xty_dialog-title-hint"> mixed case with details</span>'
      });

    var detailsCfg = {xtype:'fieldset', margin:'4 4 4 4', title:'<b>Uncompletable</b>', collapsible:true, 
    
         items:[
           { width: 420, margin:'4 0 0 0', xtype:'displayfield',  value:'<span>The following tasks have mandatory field values</span> ' },
           { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbsp;Crop Images</li></ul>'},
           
           { width: 420,   margin:'4 0 0 0',  xtype:'displayfield', value:'<span>The following tasks must be completed out side EPIM in camunda</span> ' },
           { xtype:'displayfield', value:'<ul><li>&nbsp;&bull;&nbsp;Dance like a devil</li><li>&nbsp;&bull;&nbsp;Ride like a tiger</li></ul>'}
           
         ]             
    
    };
    
    
    completeTasksMixedCaseDetailsDialogCfg.items[0].items.push(detailsCfg);
    
    
    var completeTasksMixedCaseDetailsDialog  = Ext.create('widget.window', completeTasksMixedCaseDetailsDialogCfg);
    completeTasksMixedCaseDetailsDialog.show();
    
    
    
    
    
     
     var worstCaseInstruction ='You can\'t complete any task.';
     var suppInstr = 'The tasks are uncompletable because of missing field values.';
     
     var completeTasksWorstcaseDialog = Ext.create('widget.window', {
       width: 480,
       y: 160,
       x: 900,
      
       itemId:'completeTasksDialog',
       title: 'Completing 5 Tasks  <span class="xty_dialog-title-hint"> worst case</span>',
       iconCls: 'xty_icon xty_iconInactive',
       plain: true,
       items : [ 
         {
           border : false,
           minHeight : 200,
           itemId:'completeTasksDialog-body',
           items : [ 
             {
               itemId : 'mainInstruction',
               border : false,
               margin:'10 10 10 10',
               html : '<div class="xty_dialog-mainInstr">'+worstCaseInstruction +'</div>'
             } ,
             {
               itemId : 'suppInstruction',
               border : false,
               margin:'10 10 10 10',
               html : '<div class="xty_dialog-supplementalInstr">'+suppInstr +'</div>'
             } 
             ]
         }
       ],
       buttons:[
         {xtype:'tbspacer', width:30},
         {text:'OK', handler:function(button ){ button.ownerCt.ownerCt.hide();   }},
         {text:'Cancel', handler:function(button ){ button.ownerCt.ownerCt.hide();   }}
       ]      
          
   }) ;
     completeTasksWorstcaseDialog.show();
     
     
     
     
       
     };
     
     
     
     
      var pagejobButtons = [
        
//        extVia.ui.page.pagejob.getFinderBtnGrpCfg ({hideFilterBtn:false}),
//      
//        '->',
//        
      {itemId:'check', handler:checkHandler },{itemId:'comment'},{itemId:'transferTask'} , 
       
      
    //  '->',
      

      
      {xtype:'tbseparator', margin:'0 2 0 2'},    
      {xtype:'button', itemId:'startProcess', xmenu:[{text: 'Prozess Deadline', iconCls: 'xty_menu-deadline' }, { text :'Prozess l&ouml;schen', iconCls: 'xty_menu-process-kill'}]},
      
      '->',
      
      extVia.ui.page.pagejob.getFinderBtnGrpCfg ({hideFilterBtn:false}),
    
      
      
      {tooltip:'Daten laden' , hidden:true, scale: 'small', itemId:'refresh', cls:'xty_pgtoolbar-refresh-btn',  iconCls:'x-tool x-tool-refresh', overCls:'x-tool-over'},
      
      //'->',
      
    
     // {xtype:'tbseparator', margin:'20 2 2 2'},    
      
      {
      hidden:true,
      xtype:'buttongroup',
      itemId:'views-btn-grp',
	    cls:'xty_groupbuttons-btn-grp xty_taskviews-btn-grp',  margin:'0 4 0 0',
        columns: 3,
	    defaults:{enableToggle:true, handler:taskviewsBtnHandler},
	    items:[
	     {tooltip:'My Tasks' , itemId:'myTasks',  iconCls:'xty_btn-user-tasks' , xmenu:[{text: 'my Tasks', iconCls: 'xty_btn-user-tasks' }, {text: 'my Role Tasks', iconCls: 'xty_btn-role-tasks' }, { text :'My Process Admin Tasks', iconCls: 'xty_btn-processadmin-tasks'}]},
	    // {tooltip:'Refresh' , handler: null, sscale: 'small', itemId:'refresh', cls:'xty_pgtoolbar-refresh-btn',  iconCls:'xty_pgtoolbar-refresh', overCls:'x-tool-over'},
	     {tooltip:'My Role Tasks' , itemId:'roleTasks',  iconCls:'xty_btn-role-tasks'},
	     {tooltip:'My Process Admin Tasks' , itemId:'processAdminTasks',  iconCls:'xty_btn-processadmin-tasks'}

	    ]
	  }
      
      


    //,{tooltip:'Daten laden' , scale: 'small', itemId:'refresh', cls:'xty_pgtoolbar-refresh-btn',  iconCls:'xty_pgtoolbar-refresh', overCls:'x-tool-over'}
      
      
      
      ];
      var pagetoolbarButtons = null;
      appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Tasks', epobDscr: null,  pgjobtnAlsignLeft:true,  pagetoolbarButtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } ); 

       var taskModel = Ext.define('Task', {
              extend: 'Ext.data.Model',
              fields: [{type: 'string', name:'type'},{type: 'string', name:'name'},{type: 'string', name:'type'}, {type: 'string', name:'uicontrols'},{type: 'string', name:'status'}]
       });
       var tasksData =   [  
            {name:'form-snippet-definition', uicontrols:'text', type:'definitions',  status:''}, 
            {name:'simple-nickname', uicontrols:'text', type:'2344 examples',  status:''}, 
            {name:'simple-responsible', uicontrols:'select', type:'2344 examples',  status:''}, 
            {name:'simple-deadline', uicontrols:'date', type:'2344 examples',  status:''}, 
            {name:'simple-decision', uicontrols:'checkbox,radio', type:'2344 examples',  status:''}, 
            {name:'deeplinks', uicontrols:'checkbox,button', type:'2344 examples',  status:''}, 
            {name:'simple-price', uicontrols:'range', type:'2344 examples',  status:''}, 
            {name:'basic-booking', uicontrols:'text,select,range,date,textarea,checkbox', type:'2344 examples',  status:''}, 
            {name:'all-supported-fields', uicontrols:'text,number,date,select,range,checkbox,radio,textarea,messages', type:'2344 examples',  status:''}
        ];

        var tasksStore = Ext.create('Ext.data.Store', {
          model: taskModel,
          storeId:'formSnippetsStore',
          //groupField : 'type',
          data: tasksData
        });
      

     
     
     var tasklistGridCfg =  {
             title:'my Tasks',
             xtype:'grid', 
             border:false,
             //forceFit: true,
             store: tasksStore,
             height: editorContentPanelHeight,
             
             plugins: [{
               ptype: 'rowexpander',
               rowBodyTpl : [
                   '<p><b>Company:</b> {company}</p><br>',
                   '<p><b>Summary:</b> {desc}</p>'
               ]
           }],
             
             columns:[                     
              {
                  header: "Aufgabe",
                  cls:'xty_task-columns-bin',
                  defaults:{width:100, dragsgable:false, cls:'xty_task-column'},
                  columns: [
                    { header: "Name", dataIndex:'name', tooltip:'tooltip', title:'title', qtip:'qtip',columnName: "task-name"},
                    { header: "F&auml;lligkeit", columnName: "task-date"},
                    { header: "Bearbeiter", columnName: "task-asignee"},
                    { header: "Priorit&auml;t", columnName: "task-prio"},
                    //{ header: "Verantwortlicher", columnName: "task-responsible", width:null,columns:[ { header: "Benutzer", columnName: "task-responsible-user-clmn", width:80},{ header: "Rolle", columnName: "task-responsible-role-clmn", width:80}]},
                    
                    
                    { header: "Verantwortlicher", columnName: "task-responsible-user", width:null},
                    { header: "Verantwortliche Rolle", columnName: "task-responsible-role", width:null},
                    { header: "Status", columnName: "task-status", width:40},
                    { header: "Aufgeschoben", columnName: "task-status"},
                    { header: "Nachfolgetermin", columnName: "task-status"}
                  ]
              },
              {
                    header: "Prozess",
                    cls:'xty_process-columns-bin',
                    defaults:{width:100, cls:'xty_process-column'},
                    columns: [
                      { header: "Prozess", columnName: "process-name"},
                    { header: "Prozessdiagramm", columnName: "process-diagram"},
                    { header: "Deadline", columnName: "process-date"},
                    { header: "Typ", columnName: "process-epob-type" ,width:30},
                    { header: "Objektname", columnName: "process-epob-name"},
                    { header: "Verantwortlicher Benutzer", columnName: "process-responsible-user", width:null},
                    { header: "Verantwortliche Rolle", columnName: "process-responsible-role", width:null},
                    { header: "Erstellungsdatum", columnName: "process-creationdate"}                                     
                    ]
              }                                       
              ], // eo columns
              
              listeners:{
                  columnmove: function ( ct, column, fromIdx, toIdx, eOpts ){
                      column.setWidth(column.getWidth()+10);
                  },
                  itemdblclick: function( view, record, item, index, evt ){ 
                   me.showFormSnippetDialog();
                  },
                
                
          itemcontextmenu: function( view, record, item, index, evt ){ 
                    evt.preventDefault();
            
                    var getLoc = function(str){ 
                      str = str.replace(/Module.Bpm.Action./,'');
                      return str;
                    };
            
            
                  var myTasksEnable = false;
                  var processAdminTasksEnable = false;
                  var myRoleViewEnable = false;
                  
                  Ext.create('Ext.menu.Menu', {items : [
                
              {
                text : 'Aufgabe bearbeiten', //getLoc('Module.Bpm.Action.EditTask'),
                iconCls : 'xty_menu-edit-task', hidden:myTasksEnable
              },  
              {
                text : 'Kommentar hinzuf&uuml;gen', //getLoc('General.Action.AddNote'),
                iconCls : 'xty_menu-add-comment', hidden:myTasksEnable&&processAdminTasksEnable
              },
              
              {
                text :'Aufgabe Deadline', //getLoc('Module.Bpm.Action.UserTaskDeadline'),//change here later -->Action
                iconCls : 'xty_menu-deadline', hidden:processAdminTasksEnable
              },
              
              
              {
                text : 'Aufgabe abschliessen', //getLoc('Module.Bpm.Action.CompleteTask'),
                iconCls : 'xty_formbutton-checked', hidden:myTasksEnable
              },
              {
                text : 'Aufgabe weitergeben', //getLoc('Module.Bpm.Action.TransferTask'),
                iconCls : 'xty_menu-transfer-task',  hidden:myTasksEnable&&processAdminTasksEnable 
              },
              {
                text :'Aufgabe &uuml;bernehmen', //getLoc('Module.Bpm.Action.TakeOverTheTask'),
                iconCls : 'xty_menu-take-task', hidden:myRoleViewEnable
              },
              {
                text :'Aufgabe zuweisen', //getLoc('Module.Bpm.Action.AssigneeTask'),
                iconCls : 'xty_menu-transfer-task',hidden:processAdminTasksEnable
              },
              
              { xtype: 'menuseparator' },
//              { text :'Prozess starten', //getLoc('Module.Bpm.Action.KillProcess'),//change here later -->Action
//                iconCls : 'xty_menu-process-kill', hidden:processAdminTasksEnable
//              },
              {
                text :'Prozess Deadline', //getLoc('Module.Bpm.Action.ProcessDeadline'),
                iconCls : 'xty_menu-deadline', hidden:processAdminTasksEnable
              },     
              {
                text :'Prozess l&ouml;schen', //getLoc('Module.Bpm.Action.KillProcess'),//change here later -->Action
                iconCls : 'xty_menu-process-kill', hidden:processAdminTasksEnable
              },
              
               '-',
              {
                text :'Objekt bearbeiten', //getLoc('Module.Bpm.Action.Object.Maintenance'),
                iconCls : 'xty_menu-edit'
              }
              ]
            }).showAt(evt.getXY());
                            
               } // eo itemcontextmenu
             } // eo listeners 
            };// eo tasklistGridCfg



     
     
     
     var tasklistTabsCfg = {
        xtype:'tabpanel',
        border:false,
       // height: editorContentPanelHeight,
        refresh:function(){extVia.notify({action: '"refresh on'  , mssg:  this.title});},
        
        
        tabBar:{  
          
          cls : 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
          
          tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
          handler:function(button){
              var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
              extVia.notify({action: 'Refresh Subtab'  , mssg:  '<b>'+activeTab+'</b>'}); 
           },
         iconCls:'x-tool x-tool-refresh'}]  }, 
        
        
        
        items:[
          
          tasklistGridCfg,
          {title:'my Role Tasks'},
          {title:'my Process Admin Tasks'}
          
          
          ]
      };
        
     
     
     

      var tasklistPanelCfg = {
           tbar :appbar,
           //title:'Taskliste', 
           defaults:{margsin:'12 12 12 12', animCollapse : false},

          // height: editorContentPanelHeight+130,
           autosScroll:true,
           items:[
             tasklistTabsCfg 
            ] 
        };
 
     return  tasklistPanelCfg;
      
      
    },
    
    
    launch: function() {
            
      var me = this;
      
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      //this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside
      var  modulDscr = 'camundaForms';
      var epobDscr = 'Objektname';
      
      
      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, mosdulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);


      
      // Need some west?
      // >>> PROD V4 Start (EPIM-7678) <<<
      var tabPan = extVia.regApp.myRaster.initWestTabPanel({
         items:[
           {
            title:'Form Snippets',
              tbar:[
              {iconCls:'xty_menu-editText', tooltip:'tasklist', itemId:'tasklist',
               handler:function(btn){
                me.showTasklist();
               }
              }
              ],
            items:[me.getFormSnippetsList()]
           }
          ] 
          });
      // >>> PROD V4 End (EPIM-7678) <<<
      extVia.regApp.myRaster.addToWest(tabPan);

      var pagejobButtons = [{itemId:'tree'},{itemId:'list'},{itemId:'back'}];
      var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
      var appbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:modulDscr, epobDscr:epobDscr,   pagetoolbarButtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );      

    
      var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel();
      extVia.regApp.myRaster.addToCenter(centerTabPan); 

      var centerPan = extVia.regApp.myRaster.getCenter();
      centerPan.add(me.showTasklist()); 

      //me.showFormSnippetDialog();
      
    }
});


