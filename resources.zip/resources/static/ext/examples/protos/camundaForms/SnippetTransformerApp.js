/*


*/
Ext.application({
    name: 'SnippetTransformer',    
    appMode:{},


    transformSnippet: function(cfg) {
	 var states = Ext.create('Ext.data.Store', {
	    fields: ['abbr', 'name'],
	    data : [
	        {"abbr":"AL", "name":"Alabama"},
	        {"abbr":"AK", "name":"Alaska"},
	        {"abbr":"AZ", "name":"Arizona"}
	        //...
	    ]
	  });

      
      
      
      // Desired display Panel to show the camunda Form    
    var transformedFormPanel =   Ext.create('Ext.form.Panel', {
      //title: 'Transformed ',
      border:false,
     // margin:'4 4 4 4',
      style:'padding:10px;',
      
      //width: 580,
      //height: 500,
      cls:'xty_bpm-dialog-form-panel',
      renderTo:Ext.getBody(),
      defaults:{ xtype:'textfield', msgTarget:'side', width: 420, labelWidth:180},
      items:[
      { xtype:'textfield', fieldLabel:'Name', heiwght:80, allowBlank:false, labelSeparator : ':<span class="xty_requiredStar"> *</span>'},

      
      { xtype:'numberfield', fieldLabel:'Nummer' , minValue:4, maxValue:12, vtypeText:'Alles mögliche'},
      
      
      
      { xtype:'textfield', fieldLabel:'Email', vtype:'email', v_alue:'kermit@muppets.de',  vtypeText:'Alles mögliche'},
      

      { xtype:'textfield', fieldLabel:'unique Name', emptyText:'type something containing uniq', validateOsnBlur : true,

        validator: function(value){
          if (Ext.isEmpty(value)){
            return true;
          }
          else if (value.indexOf('uniq')>-1){
            return true;
          }
          else{ return '<b>Backend</b> said value does not contain unique.';}
        }
      },
      
      
      {fieldLabel:'req Field X', allowBlank:false, labelSeparator : ':<span class="xty_requiredStar"> *</span>'},   
      
      
       {fieldLabel:'Field 2'},   {fieldLabel:'Field 3'},   
        //{fieldLabel:'Field 4'},   {fieldLabel:'Field 5'},   {fieldLabel:'Field 6'},
      
      {
	      xtype:'combo',
          fieldLabel: 'Choose State',
	      store: states,
	      queryMode: 'local',
	      displayField: 'name',
	      valueField: 'abbr'
      },
      
      {
        xtype:'combo',
        fieldLabel: 'Choose User',
        store: extVia.stores.initUserStore({}),
        queryMode: 'local',
        displayField: 'name'
      },      
      { xtype:'textfield', fieldLabel:'abc'}
      
      
      ],
      autoScroll:true,  
//      standardSubmit : Boolean
//      standardSubmit : Boolean, BaseParams, url

        listeners:{
         afterrender: function ( formpanel ){
           // send Height 
          
            var parentDialog = top.extVia.iCamSDKDialog;
            if (parentDialog){
              parentDialog.removeCls('xty_dialog-isloading'); 
              var buttonsbar = parentDialog.getDockedComponent(1);          
              if (buttonsbar){
                var submitBtn = buttonsbar.getComponent('submit');
                  if (submitBtn){
                    var form = formpanel.getForm();
                    //var valid = !form.isValid();         // marks all fields red
                    var valid = !form.hasInvalidField();   // does not mark fields
                    //submitBtn.setDisabled(!valid);
                    submitBtn.markDisabled(!valid);   
                  }
              }

              
              parentDialog.formpanel = formpanel ;
              var formpanelHeight = formpanel.getHeight();
              //if (formpanelHeight>224){
              
                var diaAdd = 63;
                var ifrAdd = diaAdd-61;
              
                parentDialog.setHeight(formpanel.getHeight()+ diaAdd);

               //7 window-1373-body
                
                var iframe = parentDialog.getComponent('iframe');
                iframe.setHeight(formpanel.getHeight() + ifrAdd );
                //iframe.setHeight(220);
              //}

            }
         },
         
         validitychange: function( basicform, valid){ 
            //var formpanel = basicform.owner; 
            var parentDialog = top.extVia.iCamSDKDialog;
            if (parentDialog){
            var buttonsbar = parentDialog.getDockedComponent(1);         
              if (buttonsbar){
                var submitBtn = buttonsbar.getComponent('submit');
                  if (submitBtn){
                    submitBtn.setDisabled(!valid );  
                    //submitBtn.markDisabled(!valid); 
                  }
              }
            }
          },
          
          dirtychange: function( basicform, dirty){  
            //var formpanel = basicform.owner;            
            var form = basicform;
            //var valid = !form.isValid();         // marks all fields red, no good here
            //var valid = !form.hasInvalidField();   // does not mark fields

            var parentDialog = top.extVia.iCamSDKDialog;
            if (parentDialog){
            var buttonsbar = parentDialog.getDockedComponent(1);         
              if (buttonsbar){
                var resetBtn = buttonsbar.getComponent('reset');
                  if (resetBtn){
                    //resetBtn.setDisabled(!dirty );
                    resetBtn.markDisabled(!dirty); 
                  }
              }
            }
          }
                   
        }

        
      });    

    },
   
    launch: function() {
      var me = this;
      me.transformSnippet();
    }
});



/*
 * 
 * $Revision: 1.7 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/01/12 09:20:45 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 

