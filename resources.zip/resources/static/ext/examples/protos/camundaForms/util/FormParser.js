
Ext
    .define(
        'extVia.camundaForms.FormParser.statics',
        {
          statics : {

            findForm : function(cfg) {
              // Provide id
              if (Ext.isEmpty(cfg.containerEl.id)) {
                Ext.get(cfg.containerEl);
              }
              var holderId = cfg.containerEl.id;
              var forms = Ext.DomQuery.select('#' + holderId + ' FORM');
              // var forms = Ext.DomQuery.select('#'+holderId+' #'+cfg.formId);

              var form = forms[0];
              // Provide id
              if (Ext.isEmpty(form.id)) {
                form.id = cfg.formId;
              }
              this.initLocalizedFormats();
              return form;
            },

            findFormItems : function(cfg) {
              var formItemsCfgs = [];

              // Provide id
              if (Ext.isEmpty(cfg.containerEl.id)) {
                // Ext.get(cfg.containerEl);
                var formId = ( cfg && cfg.formId ) ? cfg.formId : Ext.id(null, 'form');
                Ext.get(cfg.containerEl).dom.setAttribute('id', formId);
              }
              var holderId = cfg.containerEl.id;

              // looks for form-groups or form-messages
              var formItems = Ext.DomQuery.select('#' + holderId + ' .form-group, #' + holderId + ' P.form-message');
 
              var getSubmitValueFunc =  function(){  
                var field = this; 
                return { value: field.getValue(), camundaAttributes: field.camundaAttributes};
              };
              
              var afterRenderFunction = function(field)
              {
                var xtype = field.getXType();
                // Maybe we should define a slider extension
                if (xtype === 'slider') {
                  var inputEl2Cfg = {
                    id : field.id + '-inputEl2',
                    tag : 'input',
                    type : 'hidden',
                    style : 'opacity:0.3; ',
                    value : field.getValue(),
                    cls : 'xty_slider-inputEl2'
                  };
                  field.inputEl2 = Ext.DomHelper.append(field.inputEl.id, inputEl2Cfg); // inputfield for holding camVars in case we send the new Form back
                } else if (xtype === 'combobox') {
                  if (field.expandedList) {
                    field.expand();
                    var picker = field.getPicker();
                    if (picker) {
                      picker.comboId = field.id;
                      picker.getEl().on('mousedown', function(boundlist) {
                        var combo = field;
                        var hasFocus = Ext.get(combo.getInputId()).hasCls('x-form-focus');
                        // var pickerfieldOpen = combo.hasUICls('x-pickerfield-open' );
                        if (!combo.delayedExpand) {
                          combo.delayedExpand = new Ext.util.DelayedTask(function() {
                            combo.expand();
                          });
                        }
                        if (!hasFocus) {
                          combo.delayedExpand.delay(10);
                        }
                      });
                    }

                    field.on('validitychange', function(field, isValid) {
                      if (isValid) {
                        picker.removeCls('xty_invalid-picker');
                        if (picker.reducedInvWidth) {
                          picker.setWidth(picker.getWidth() + 18);
                          picker.reducedInvWidth = false;
                        }
                      } else {
                        picker.addCls('xty_invalid-picker');
                        if (!picker.reducedInvWidth) {
                          picker.setWidth(picker.getWidth() - 18);
                          picker.reducedInvWidth = true;
                        }
                      }

                    });

                    Ext.get(field.getInputId()).dom.setAttribute('readonly', 'true');
                    Ext.get(field.getInputId()).dom.setAttribute('disabled', 'true');
                  }
                } else if (xtype === 'comboboxselect') {
                  var si, selrecords = [];
                  var selectedValues = field.selectedValues;
                  var store = field.getStore();
                  for (si = 0; si < selectedValues.length; si++) {
                    var selval = selectedValues[si];
                    var selrec = store.findRecord('field1', selval);
                    if (selrec !== null) {
                      selrecords.push(selrec);
                    }
                  }
                  if (selrecords.length > 0) {
                    field.select(selrecords);
                  }
                }

                if (field.camundaAttributes && ( field.inputEl || field.inputEl2 )) {
                  try {
                    if (field.inputEl2) {
                      Ext.get(field.inputEl2).set(field.camundaAttributes);
                    } else {
                      field.inputEl.set(field.camundaAttributes);
                    }
                  } catch (ex) {
                    extVia.notify(field.id + ' cannot write camundaAttributes on inputEl or inputEl2');
                  }
                }
              };
              
              var changeFunction = function(field, newValue, oldValue)
              {   
                  var orgfield = Ext.get(field.originalControlId);
                  var valprop = field.valprop ? field.valprop : 'value';
                  var value = field.getValue();
                  var xtype = field.getXType();

                  if (field.returnFormat) {
                    if (xtype === 'datefield' || xtype === 'timefield') {
                      var newDate = new Date(value);
                      value = Ext.Date.format(newDate, field.returnFormat);
                    }
                  }
                  if (xtype === 'radiogroup') { // Workaround for writing option-values on a select                  
                   value = newValue[field.name];
                  } 

                  if (field.dynload) {
                    if (xtype === 'combobox') {
                      var dynloadTarget = field.ownerCt.getComponent(field.dynload);
                      var treeSelectionData = Ext.decode(field.ownerCt.treeSelectionData);

                      if (!field.ownerCt.treeSelectionStore) {
                        field.ownerCt.treeSelectionStore = Ext.create('Ext.data.TreeStore', {
                          storeId : 'treeSelectionStore-' + field.ownerCt.id,
                          root : treeSelectionData
                        });
                      }

                      var treeSelectionStore = field.ownerCt.treeSelectionStore;
                      var selectedChildNode = treeSelectionStore.getRootNode().findChild('id', value, true);

                      if (dynloadTarget) {
                        dynloadTarget.setDisabled(Ext.isEmpty(value));

                        // Ext.get(dynloadTarget.originalControlId).dom.disabled=Ext.isEmpty(value);
                        dynloadTarget.setValue('');
                        dynloadTarget.setRawValue('');
                        dynloadTarget.getEl().down('.x-form-item-label').update('');
                        dynloadTarget.fieldLabel = '';

                        var targetStore = dynloadTarget.getStore();
                        targetStore.data.clear();

                        if (selectedChildNode) {
                          var childData = [ [ "", "&#8203;" ] ];
                          selectedChildNode.eachChild(function(child) {
                            childData.push([ child.get('id'), child.get('text') ]);
                          });
                          targetStore.loadData(childData);

                          var qtitle = selectedChildNode.get('qtitle');
                          var dynloadTargetFieldLabel = qtitle ? qtitle : '';
                          dynloadTarget.getEl().down('.x-form-item-label').update(
                              dynloadTargetFieldLabel + dynloadTarget.labelSeparator);
                          dynloadTarget.fieldLabel = dynloadTargetFieldLabel;

                        }

                      }
                    }
                  }// eo dynload

                  if (field.multiSelect && orgfield.dom.tagName === 'SELECT') {
                    var multiValues = value;
                    var oi;
                    for (oi = 0; oi < orgfield.dom.options.length; oi++) {
                      var option = orgfield.dom.options[oi];
                      option.selected = ( option && multiValues.indexOf(option.value) > -1 ) ? 'selected' : null;
                    }
                  } else {
                    orgfield.dom[valprop] = value;
                  }
                  if (field.inputEl2) {
                    // alert('field.inputEl2')
                    field.inputEl2[valprop] = value;
                  }

                  // if(field.writeBack){
                  // //extVia.notify(field.id +' try to write back on '+field.originalControlId);
                  // field.writeBack(field, Ext.get(field.originalControlId) );
                  // }
                  // else{
                  // extVia.notify(field.id +' NO write back on '+field.originalControlId+' '+field.getValue());
                  // }                
              }; //eo changeFunction            
              
              
              // Loop over formItems and build Configs
              var i;
              for (i = 0; i < formItems.length; i++) {
                var formItemHtmlEl = formItems[i];

                // Provide id
                if (Ext.isEmpty(formItemHtmlEl.id)) {
                  // formItemHtmlEl.id = holderId+'-formitem'+ (i+1);
                  formItemHtmlEl.setAttribute('id', holderId + '-formitem' + ( i + 1 ));
                }

                var formItemTag = formItemHtmlEl.tagName;
                var formcomponentCfg;

                var me = extVia.camundaForms.FormParser.statics;
                if (formItemTag === "P") {
                  formcomponentCfg = {
                    xtype : 'displayfield',
                    //value : formItemHtmlEl.innerHTML,
                    value : me.getInnerHTML(formItemHtmlEl),
                    margin : '4 4 4 4'
                  };
                  if (formItemHtmlEl.className.indexOf('main-instruction') > -1) {
                    formcomponentCfg.componentCls = 'xty_dialog-mainInstr xty_dialog-instruction';                
                  }
                  else if (formItemHtmlEl.className.indexOf('supplemental-instruction') > -1) {
                    formcomponentCfg.componentCls = 'xty_dialog-supplementalInstr xty_dialog-instruction';
                  }

                } else {
                  var formcontrolItems = extVia.camundaForms.FormParser.statics.findFormControlsInGroup({
                    containerEl : formItemHtmlEl
                  });

                  var formcomponentDefaults = {
                    msgTarget : 'side',
                    hideEmptyLabel : false,
                    width : 420,
                    labelWidth : 180,
                    componentCls:'xty_dialog-content-item',
                    getSubmitValue: getSubmitValueFunc,
                    listeners : {                
                      afterrender : afterRenderFunction,  
                      change : changeFunction
                      }
                    }; 

                  formcomponentCfg = {
                    margin : '4 4 4 4',
                    xtype : 'fieldcontainer',
                    cls : 'xty_dialog-content-item xty_transformed-group-fieldcontainer',
                    defaults : formcomponentDefaults,
                    items : formcontrolItems
                  };

                  // Defaultcase
                  // xtype: 'fieldcontainer' not needed when only 1 control item
                  if (formcontrolItems.length === 1) {
                    formcontrolItems[0].margin = '5 5 5 5';

                    // No individual listeners right now
                    // alert(formcontrolItems[0].listeners)

                    Ext.apply(formcontrolItems[0], formcomponentDefaults);
                    formcomponentCfg = formcontrolItems[0];
                  }

                }

                if (formItemHtmlEl.className.indexOf('tree-selection') > -1) {
                  var treeSelectionData = Ext.DomQuery.select('#' + formItemHtmlEl.id + ' .tree-selection-data');
                  if (treeSelectionData && treeSelectionData[0]) {
                    formcomponentCfg.treeSelectionData = treeSelectionData[0].innerHTML;
                    // alert(formcomponentCfg.treeSelectionData);
                  }
                }

                formItemsCfgs.push(formcomponentCfg);
              }// eo  Loop over formItems
              
              return formItemsCfgs;
            },

            findFormControlsInGroup : function(cfg) {
              var formControlCfgs = [];

              // Provide id
              if (Ext.isEmpty(cfg.containerEl.id)) {
                // Ext.get(cfg.containerEl); // normally this is enough to generate ids
                // cfg.containerEl.id = Ext.id(null, 'formgroup-');
                // Ext.get(cfg.containerEl).dom.setAttribute('id' , Ext.id(null, 'formgroup-'));
                cfg.containerEl.setAttribute('id', Ext.id(null, 'formgroup-'));
              }

              var holderId = cfg.containerEl.id;

              // var formControls = Ext.DomQuery.select('#'+holderId+' .form-control');
              var formControls = Ext.DomQuery.select('#' + holderId + ' [class="form-control"]');

           
              var selectedValues = [];
              var buildStoreDataFromOptionEl = function(option)
              {                
                  if (option.selected) {
                    selectedValues.push(option.value);
                  }
                  return [ option.value, option.text ];                
              };
              
              
              var me = extVia.camundaForms.FormParser.statics;
              var i;
              for (i = 0; i < formControls.length; i++) {
                var formControlHtmlEl = formControls[i];

                // Provide id
                if (Ext.isEmpty(formControlHtmlEl.id)) {
                  // formControlHtmlEl.id = holderId+'-control'+ (i+1);
                  formControlHtmlEl.setAttribute('id', holderId + '-control' + ( i + 1 ));
                }

                var formControlCfg = {
                  xtype : 'textfield'
                };
                var formControlTag = formControlHtmlEl.tagName;

                var isSELECT = false;
                var inputType = formControlHtmlEl.getAttribute("type");

                var idAtt = formControlHtmlEl.getAttribute("id");
                var nameAtt = formControlHtmlEl.getAttribute("name");
                formControlCfg.name = nameAtt ? nameAtt : idAtt;
                formControlCfg.itemId = formControlHtmlEl.name;

                // formControlCfg.writeBack = function(extfield, orgfield){
                // var valprop = extfield.valprop?extfield.valprop:'value';
                // orgfield.dom[valprop] = extfield.getValue();
                // }

                //formControlCfg.value = formControlHtmlEl.value;
                
                var formControlHtmlElValue = formControlHtmlEl.value;

                if(Ext.isEmpty(formControlHtmlElValue)){
                  formControlHtmlElValue = formControlHtmlEl.getAttribute("value");     
                } 

                if(!Ext.isEmpty(formControlHtmlElValue)) {
                  formControlCfg.value = formControlHtmlElValue;                
                }

                
          

                var requiredAtt = formControlHtmlEl.getAttribute('required');
                var isRequired = requiredAtt !== null;
                if (isRequired) {
                  formControlCfg.allowBlank = false;
                  formControlCfg.labelSeparator = ': *';
                }

                if (formControlTag === "INPUT") {

                  var camVariableType = formControlHtmlEl.getAttribute("cam-variable-type");
                  // alert('inputType['+inputType+'] camVariableType['+camVariableType+'] ')
                  if (inputType === "date" || camVariableType === 'Date') {
                    formControlCfg.xtype = "datefield";
                    formControlCfg.format =  me.localizedFormats ? me.localizedFormats.extDateDscrFormat : "d.m.Y"; 
                    formControlCfg.altFormats = me.localizedFormats.extDateAltFormats;
                    formControlCfg.returnFormat = "Y-m-d\\Th:i:s"; // elastic wants that format otherwise : localizedFormats ? localizedFormats.extDateReturnFormat+'' :
                  }
                  else if (inputType === "time" || camVariableType === 'Time') {
                    formControlCfg.xtype = "timefield";
                    formControlCfg.returnFormat = "h:i:s";
                    formControlCfg.triggerCls = 'xty_form-trigger-timefield';
                    formControlCfg.pickerMaxHeight=160;
                    formControlCfg.format = 'H:i';
                  } else if (inputType === "range" || camVariableType === 'Range') {
                    formControlCfg.xtype = "slider";
                  } else if (inputType === "checkbox" ) {
                    formControlCfg.valprop = 'checked';
                    formControlCfg.xtype = "checkbox";
                  } else if (inputType === "radio") { 
                    formControlCfg.valprop = 'checked';
                    formControlCfg.xtype = "radio";
                    formControlCfg.inputValue = formControlHtmlEl.id;
                    formControlCfg.itemId = formControlHtmlEl.id;
                  } else if (inputType === "number" || camVariableType === 'Double' || camVariableType === 'Long') {
                    formControlCfg.xtype = "numberfield";
                    formControlCfg.thousandSeparator = me.localizedFormats.tsSeparator;
                    if(camVariableType === 'Long') {
                      formControlCfg.allowDecimals = false;
                    }
                    else{
                      formControlCfg.decimalSeparator =  me.localizedFormats.decSeparator; 
                      // decimalPrecision = formControlHtmlEl.getAttribute('decimalPrecision');
                    }
     
                  } else if (inputType === "file" || camVariableType === 'File') {
                    formControlCfg.xtype = "filefield";
                  } else if (inputType === "button") {
                    // formControlCfg.xtype="fieldcontainer";
                    // if (!formControlCfg.items){formControlCfg.items=[];}
                    // formControlCfg.items.push({xtype:'button',text:formControlHtmlEl.value, width:80});
                    formControlCfg.xtype = "button";
                    formControlCfg.text = formControlHtmlEl.value;
                    formControlCfg.width = 80;
                  }
                  // else if(inputType==="hidden"){formControlCfg.xtype="hiddenfield";}

                } else if (formControlTag === "BUTTON") {
                  formControlCfg.xtype = "button";
                  formControlCfg.text = formControlHtmlEl.innerHTML;
                  formControlCfg.width = 80;
                } else if (formControlTag === "TEXTAREA") {
                  formControlCfg.xtype = "textareafield";
                  var grow = formControlHtmlEl.getAttribute("grow")==="true";
                  formControlCfg.grow = grow;
                } else if (formControlTag === "SELECT" && inputType==='radio') { 
                  formControlCfg.xtype = "radiogroup";
                  var horizontal = formControlHtmlEl.getAttribute("horizontal")!==null;
                  formControlCfg.items = [];
                  var selectHtmlEl = formControlHtmlEl;
                  if (selectHtmlEl) {                    
                    var oi;
                    for (oi = 0; oi < selectHtmlEl.options.length; oi++) {
                      var option = selectHtmlEl.options[oi];
                      var selected = option.getAttribute("selected")!==null;
                      var disabled = option.getAttribute("disabled")!==null;
                      if (!horizontal){
                       formControlCfg.layout= 'column';
                       formControlCfg.vertical= true; 
                      }
                      formControlCfg.defaults={
                       xtype:'radio' , name: idAtt, width:160
                      };
                      var cls = option.className ? 'xty_radio-'+option.className :'';
                      formControlCfg.items.push({checked: selected, disabled: disabled, cls: cls, boxLabel: option.text, inputValue: option.value, value: option.value});
                    }  
                  } 
                } else if (formControlTag === "SELECT") {  
                  isSELECT = true;
                  formControlCfg.xtype = "combo";
                  var multipleAtt = formControlHtmlEl.getAttribute("multiple");
                  var isMultiple = multipleAtt !== null;
                  formControlCfg.multiSelect = isMultiple;
                  var allowArbitraryText = formControlHtmlEl.getAttribute("forceSelection")==="false";
                  formControlCfg.forceSelection = !allowArbitraryText;
                  var transformSelect = Ext.getDom(formControlHtmlEl);
                  if (transformSelect) {                    
                    var storeData = Ext.Array.map(Ext.Array.from(transformSelect.options),  buildStoreDataFromOptionEl); 

                    formControlCfg.selectedValues = selectedValues;

                   // sorters 
                   // sortprop + sortdir should be attributes in SELECT tag        
                   // <SELECT sort="true"       ->  sorters: [{property : 'text'}] 
                   // <SELECT sortprop="value"  ->  sorters: [{property : 'text'}] 
                   // <SELECT sortdir="DESC"    ->  sorters: [{property : 'text', direction:'DESC'}] 
                   // <SELECT sortprop="value"  ->  sorters: [{property : 'value'}]  
                   // <SELECT sortprop="value" sortdir="DESC" ->  sorters: [{property : 'value', direction:'DESC'}] 
                    
                   // date , reihenfolge or prio 
                   // <SELECT sortprop="date">  // ist dann ASC oder DESC das neueste?
                   //     <option date="19.10.2017" value="entryid-564">Eintrag</option>   actually additional option-props are not fetched by buildStoreDataFromOptionEl
                   //  ->  sorters: [{property : 'date'}]  

                    // <SELECT sortprop="sortval">
                    //     <option sortval="19.10.2017" value="entryid-564">Eintrag</option>   actually sortval option-attribute is not fetched by buildStoreDataFromOptionEl
                    //  ->  sorters: [{property : 'sortval'}]                      
                    
                    var selectStoreCfg = {                   
                      fields: [ 'value', 'text' ], // sortprop
                      data: storeData ,
                      sorters: [{property : 'text', direction:'DESC'}]             
                    };
                    var selectStore = new Ext.data.ArrayStore(selectStoreCfg);
                    //formControlCfg.store = selectStore; // selected values does not work anymore here

                    formControlCfg.store = storeData;

                    formControlCfg.queryMode = 'local';
                  }

                  if (isMultiple) {
                    formControlCfg.value = formControlCfg.selectedValues;
                  }

                  var sizeAtt = formControlHtmlEl.getAttribute("size");
                  var sizeGT1 = sizeAtt > 1;

                  var boxselectAtt = formControlHtmlEl.getAttribute("boxselect");
                  var doBoxSelect = boxselectAtt !== null;

                  var multiselectAtt = formControlHtmlEl.getAttribute("multiselect");
                  var doMultiselect = multiselectAtt !== null;

                  if (isMultiple && doBoxSelect && Ext.ux.form.field && Ext.ux.form.field.BoxSelect) {
                    formControlCfg.xtype = "boxselect";
                    formControlCfg.value = null;
                    formControlCfg.values = formControlCfg.selectedValues;

                  } else if (isMultiple && doMultiselect && Ext.ux.form && Ext.ux.form.MultiSelect) {
                    // Does NOT work properly
                    var height = 60;
                    formControlCfg.height = height; // 22* sizeAtt;
                    formControlCfg.xtype = "multiselect";
                    formControlCfg.anchor = '100%';
                    formControlCfg.queryMode = 'all';
                    formControlCfg.width = 300;
                    //CriSen: Check this where's this one used!? I commented it out for now, because I see no usage of it.
                    //selectedData = formControlCfg.selectedValues;
                    formControlCfg.listConfig = {
                      minWidth : 300,
                      minHeight : height, // 22* sizeAtt;
                      maxHeight : height
                    // 22* sizeAtt;
                    };
                  } else if (sizeGT1) {
                    formControlCfg.height = 22 * sizeAtt;

                    formControlCfg.expandedList = true;

                    formControlCfg.queryMode = 'all';

                    formControlCfg.cls = 'xty_expanded-combo';
                    formControlCfg.pickerOffset = [ 0, -22 ];

                    formControlCfg.listConfig = {
                      // hideMode : 'offsets',

                      floating : false,
                      renderTo : idAtt + '-combo',
                      style : 'margin-left:185px;', // labelWidth+4
                      shadow : false,
                      cls : 'xty_expanded-combo-boundlist',
                      minHeight : 22 * sizeAtt,
                      maxHeight : 22 * sizeAtt
                    };

                    var floatingOFF = true;
                    if (floatingOFF) {
                      formControlCfg.id = idAtt + '-combo';
                      formControlCfg.height = null;
                    }

                  }

                } else if (formControlTag === "DIV") {
                  formControlCfg.xtype = "displayfield";
                  formControlCfg.fieldLabel = "panel";
                  formControlCfg.value = formControlHtmlEl.innerHTML;
                  formControlCfg.value = me.getInnerHTML(formControlHtmlEl);
                }

                // Read all Attributes
                var camundaAttributes;
                
                
                var additionalformControlCfgs;
                var additionalBtn;
                
                
                var att, ai, atts, attsLen;
                for (att, ai = 0, atts = formControlHtmlEl.attributes, attsLen = atts.length; ai < attsLen; ai++) {
                  att = atts[ai];
                  
                  
                  
                  
                  if (inputType === "checkbox" ) {
                    var hasLink = att.nodeName.indexOf('link')>-1; 
                    if(hasLink){
                      var link =  att.nodeValue;
                      var linkname = link;
                      var linkArr = att.nodeValue.split('|');
                      if (linkArr.length>1){
                        linkname = linkArr[0];
                        link = linkArr[1];
                      } 
                      additionalBtn = {xtype:'button', cls:'xty_deeplink-btn',  text:'&raquo;', tooltip:linkname, href:link, width: 24, heigsht:32,}
                    }
                  }

                  
                  

                  
                  
                  var textIx = att.nodeName.indexOf('text'); 
                  //if (att.nodeName.indexOf('cam-variable')>-1 || att.nodeName.indexOf('cam-choices')>-1){
                  if (att.nodeName.indexOf('cam-') === 0) {
                    if (Ext.isEmpty(camundaAttributes)) {
                      camundaAttributes = {};
                    }
                    camundaAttributes[att.nodeName] = att.nodeValue;
                  } else if (att.nodeName === 'min') {
                    formControlCfg.minValue = att.nodeValue;
                  } else if (att.nodeName === 'minlength') {
                    formControlCfg.minLength = att.nodeValue; 
                  } else if (att.nodeName === 'max') {
                    formControlCfg.maxValue = att.nodeValue; 
                  } else if (att.nodeName === 'maxlength') {
                    formControlCfg.maxLength = att.nodeValue; 
                  } else if (att.nodeName === 'step' || att.nodeName === 'increment') {
                    formControlCfg.step = att.nodeValue;      // numberfield
                    formControlCfg.increment = att.nodeValue; // timefield + slider
                  } else if (att.nodeName === 'vtype') {
                    formControlCfg.vtype = att.nodeValue;
//                  } else if (att.nodeName === 'regex') { // needs regexPattern + regexFlags
//                    formControlCfg.regex = new RegExp(att.nodeValue); 
                  } else if (textIx > -1 && textIx === att.nodeName.length - 4 ) {
                    // supports 
                    // minText maxText minLengthText maxLengthText negativeText nanText invalidText emptyText   vtypeText 
                    // yet unsupported: disabledDatesText disabledDaysText regexText
                    var textProp = att.nodeName.replace(/text$/,'Text' );
                    formControlCfg[textProp]= att.nodeValue; // nodeValue should be a resKey
                  } else if (att.nodeName === 'disabled') {
                    formControlCfg.disabled = true;
                  } else if (att.nodeName === 'readonly') {
                    formControlCfg.readOnly = true;
                  } else if (att.nodeName === 'placeholder') {
                    formControlCfg.emptyText = att.nodeValue;
                  } else if (att.nodeName === 'dynload') {
                    formControlCfg.dynload = att.nodeValue;
                  }
                }
                formControlCfg.camundaAttributes = camundaAttributes;

                var fieldLabel = '';
                //convention to bind labels to inputs: <label class="form-control-label" for="$control-id" >
                var labelFound = false;

                // label is parentNode checkbox case
                var labelHtmlEl = formControlHtmlEl.parentNode;
                if (labelHtmlEl && labelHtmlEl.tagName === "LABEL") {
                  fieldLabel = labelHtmlEl.innerHTML.replace(/<.[^>]*>/, '');
                  labelFound = true;
                }

                var formLabels;
                // label TAG with FOR-Attri 
                if (!labelFound) {
                  //alert('#['+holderId+'] formControlHtmlEl.id['+formControlHtmlEl.id+'] labelFinder case FOR attri');
                  var controlElId = formControlHtmlEl.id ? formControlHtmlEl.id : ( formControlHtmlEl.name ? formControlHtmlEl.name : formControlHtmlEl
                      .getAttribute("cam-variable-name") );
                  formLabels = Ext.DomQuery.select('#' + holderId + ' LABEL[for="' + controlElId + '"]');
                  if (formLabels && formLabels[0]) {
                    labelHtmlEl = formLabels[0];
                    //fieldLabel = labelHtmlEl.innerHTML;
                    fieldLabel = me.getInnerHTML(labelHtmlEl);

                    var boxlabelAtt = labelHtmlEl.getAttribute("boxlabel");
                    var doBoxlabel = boxlabelAtt !== null;
                    if (doBoxlabel) {
                      //formControlCfg.boxLabel = formLabels[0].innerHTML;
                      formControlCfg.boxLabel = me.getInnerHTML(formLabels[0]);
                      fieldLabel = '';
                    }
                    if (formLabels[1]) {
                      //formControlCfg.boxLabel = formLabels[1].innerHTML;
                      formControlCfg.boxLabel = me.getInnerHTML(formLabels[1]);
                    }

                    labelFound = true;
                  }
                }

                // Previous Sibling case + Index
                //      if(!labelFound){
                //        //alert('labelFinder case any label here ');
                //        formLabels = Ext.DomQuery.select('#'+holderId+' LABEL'); 
                //        if (formLabels && formLabels[i]){
                //        labelHtmlEl = formLabels[i];
                //         if(labelHtmlEl && labelHtmlEl.tagName==="LABEL"){
                //          fieldLabel = labelHtmlEl.innerHTML;
                //          labelFound=true;
                //         } 
                //        }
                //      }

                formControlCfg.fieldLabel = fieldLabel;

                // for writing the values back
                formControlCfg.originalControlId = formControlHtmlEl.id;

                formControlCfgs.push(formControlCfg);
                
                if(additionalBtn){
                  formControlCfgs.push(additionalBtn);
                  additionalBtn = null;
                }
                
                
                
              }

              return formControlCfgs;
            },
            
            getInnerHTML : function(domEl){
             // if proto 
             return extVia.camundaForms.FormParser.statics.localizeVal(domEl.innerHTML);
             //return domEl.innerHTML;
            },            
            
            localizeVal : function(value){
              var retStr = value;
              if (!Ext.isEmpty(value) && value.indexOf('{extVia.ui.page.strings.Cam.')>-1){
                var resKey = value.replace(/(\{extVia.ui.page.strings.Cam.)(.*)(\}$)/,'$2'); 
                if (extVia.camundaForms  && extVia.camundaForms.locales && extVia.camundaForms.locales[resKey]){
                  retStr = extVia.camundaForms.locales[resKey];
                }
                else if (extVia.ui && extVia.ui.page && extVia.ui.page.strings  && extVia.ui.page.strings.Cam && extVia.ui.page.strings.Cam[resKey]){
                  retStr = extVia.camundaForms.locales[resKey];
                }
                else{
                  retStr = '{'+resKey+'}';
                }
              }
              return retStr;
            },
            
            localizedFormats: null,
            initLocalizedFormats : function(){
               var localizedFormats = {
                    // validationTextDateFormat
		          extDateDscrFormat :  "d.m.Y", 
		          extDateAltFormats :  "d.m.y|dmy|d.m.|d.m|dmY|j.n.|j.n|j.n.Y|j.n.y",
		          decSeparator :  ",",
		          tsSeparator : "."
               };
               if (extVia.app  && extVia.app.setup && extVia.app.setup.extDateDscrFormat){
                 localizedFormats = {
		          extDateDscrFormat : extVia.app.setup.extDateDscrFormat , //[ "d.m.Y", "d/m/Y",''],
		          extDateAltFormats : extVia.app.setup.extDateAltFormats , //[ "d.m.y|dmy|d.m.|d.m|dmY|j.n.|j.n|j.n.Y|j.n.y", "d/m/y|dmy|d/m/|d/m|dmY|j/n/|j/n|j/n/Y|j/n/y",''],
		          decSeparator : window.iboxValidateDecSeparator , //[ ",",'.',''],
		          tsSeparator : window.iboxValidateTsSeparator  // [ ".", "", '']
                 };
               }
               
               else if (extVia.camundaForms  && extVia.camundaForms.locales ){
                localizedFormats = {
		          extDateDscrFormat : extVia.camundaForms.locales.extDateDscrFormat , //[ "d.m.Y", "d/m/Y",''],
		          extDateAltFormats : extVia.camundaForms.locales.extDateAltFormats , //[ "d.m.y|dmy|d.m.|d.m|dmY|j.n.|j.n|j.n.Y|j.n.y", "d/m/y|dmy|d/m/|d/m|dmY|j/n/|j/n|j/n/Y|j/n/y",''],
		          decSeparator : extVia.camundaForms.locales.decSeparator , //[ ",",'.',''],
		          tsSeparator : extVia.camundaForms.locales.tsSeparator  // [ ".", "", '']
		        };               
               }
		          
               this.localizedFormats = localizedFormats;   
               return localizedFormats; 
           }

          }
        });

/*
 * 
 * $Revision: 1.13.6.4 $
 * $Modtime: 14.03.17 10:21 $ 
 * $Date: 2018/11/08 12:32:26 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 