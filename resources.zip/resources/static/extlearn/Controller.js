 Ext.define("myApp.controller", {//define de app
        extend: 'Ext.Base',
        constructor : function(config){
            var me = this;
            Ext.apply(this, config);
        },

        myButtonHandler : function (){
        alert('you clicked me');
        },

        itemdblclickHandler :  function (cmp, record, item, index, e, eOpts, store ){
            store.remove(record);
        }
});
