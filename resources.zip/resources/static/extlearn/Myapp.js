 Ext.define("myApp", {//define the app
     constructor : function(config){
     Ext.apply(this, config);
     console.log(config);
     var me = this;
         var myAppController = Ext.create("myApp.controller", { //call and create app
             controllerProperty1:"ceva",
             controllerProperty2:1+2,
         });

         var myAppView = Ext.create("myApp.view", { //call and create app
         //config to be sent
          customMessage:'My message to be displayed',
          customTitile : 'My custom title',
          controller : myAppController
         });
         myAppController.myAppView = myAppView;
     }
});