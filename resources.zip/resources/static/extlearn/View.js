Ext.define("myApp.view", {//define de app
        extend: 'Ext.Base',
        constructor : function(config){
            Ext.apply(this, config);
            var me = this;
            var panel  = Ext.create('Ext.panel.Panel', {
                title: me.customTitile,
                width: 700,
                items: [me.getGridPanel()],
                renderTo: Ext.getBody()
            });
        },

        viewButtonHandler : function (){
            alert("ok1");
        },

        getGridPanel: function() {
          var me = this;
          var store =  me.getStore();
          var grid = Ext.create('Ext.grid.Panel', {
               store: store,
               columns: me.getColumns(),
               height: 200,
               width: 700,
               renderTo: Ext.getBody(),
               listeners : {//adauga eventuri
                   itemdblclick : function (cmp, record, item, index, e, eOpts ){//event de dbl click pe record
                        //store.insert(index, record);
                        me.controller.itemdblclickHandler(cmp, record, item, index, e, eOpts, store);
                   }
               }
           });
           return grid;
        },

        getStore : function (){
           var me = this;
           var store = Ext.create('Ext.data.Store', {
               storeId: 'simpsonsStore',
               fields:[ 'name', 'email', 'phone']
           });
           store.loadData(me.getStoreData());
           return store;
        },

        getStoreData : function (){
          var data = [];
          for (var i = 0; i <100; i++){
             var object = { name: 'Lisa'+i, email: 'lisa@simpsons.com'+i, phone: '555-111-1224'+i };
             data.push(object);
          }
          return data;
        },

        getColumns : function (){
          return columns =[
                  { text: 'Name', dataIndex: 'name' },
                  { text: 'Email', dataIndex: 'email', flex: 1 },
                  { text: 'Phone', dataIndex: 'phone' }
             ]
          }
});