Ext.onReady(function(){
     Ext.define("test.app", {//define de app
            extend: 'Ext.Base',
            constructor : function(config){
            var panel  = Ext.create('Ext.panel.Panel', {
                    title: config.customTitile,
                    width: 200,
                    height: 400,
                    html: config.customMessage,
                    renderTo: Ext.getBody()
                });
            panel.show();
            }
     	});
    Ext.create("test.app", { //call and create app
    //config to be sent
     customMessage:'My message to be displayed',
     customTitile : 'My custom title'
    });
});