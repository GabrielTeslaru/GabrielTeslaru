
Ext.define('extVia.publicationsData', {
    statics: {
 
    	
    }
});
