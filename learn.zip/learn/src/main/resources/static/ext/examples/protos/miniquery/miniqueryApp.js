/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

Commercial Usage
Licensees holding valid commercial licenses may use this file in accordance with the Commercial Software License Agreement provided with the Software or, alternatively, in accordance with the terms contained in a written agreement between you and Sencha.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/
 Ext.namespace('extVia.miniquery');
Ext.application({
    name: 'miniqueryApp',

    //controllers: ['Users'],
    
    appMode:{},

    launch: function() {

    	//this.appMode = extVia.app.setup.appMode; // preconfigured oby Url on javaside
    	

        // NOTE: This is an example showing simple state management. During development,
        // it is generally best to disable state management as dynamically-generated ids
        // can change across page loads, leading to unpredictable results.  The developer
        // should ensure that stable state ids are set for stateful components in real apps.
        //Ext.state.Manager.setProvider(Ext.create('Ext.state.CookieProvider'));
    	

    	
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster();
    	extVia.ui.page.raster.onReady(this);
    	
    	// fake miniquery raus
    	extVia.ui.page.raster.mainNorth.items.get(2).destroy();

	    var miniqueryComp = Ext.createWidget('miniquery', {xtype:'miniquery', style: {marginTop: '3px', marginLeft: '55px'}});
	   // extVia.ui.page.raster.addToNorth({border:false, height: 30, width:205, items:[miniqueryComp], bodyStyle:"background:transparent"});		 
	    extVia.ui.page.raster.mainNorth.insert(2,{border:false, height: 30, width:205, items:[miniqueryComp], bodyStyle:"background:transparent"});
		
		extVia.ui.page.BaseRaster.miniqueryNorth = miniqueryComp;
  
		var centerTabPanel = extVia.regApp.myRaster.initCenterTabPanel(extVia.epimTree.getCenterTabsCfg()); 
    	extVia.regApp.myRaster.addToCenter(centerTabPanel);
    	

	    var  westTabPan  =  extVia.regApp.myRaster.initWestTabPanel(extVia.epimTree.getWestTabsCfg()); 
    	extVia.regApp.myRaster.addToWest(westTabPan);

    }
});


/*
 * 
 * $Revision: 1.5 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2013/01/18 11:33:24 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
