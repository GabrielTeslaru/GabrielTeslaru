Ext.namespace('extVia.ui.page.BaseRaster');
/**
 * @class extVia.ui.page.BaseRaster 
 * A lightweight BaseRaster  for all borderLayout-combinations.
 * It should be not more or less be a layoutManager.
 * Usage for Layout:<code> <br>
        var viewCfg ={}; // empty  viewCfg means {hideNorth:false,hideWest:false, buildEast:false, buildSouth:false};
        extVia.ui.page.raster = new extVia.ui.page.BaseRaster(viewCfg); <br>
        extVia.ui.page.raster.onReady(this);<br>
        ...goAhead<br>
      <br>
     </code> 
  * Usage for using + filling  Regions :<code> <br>     
        var centerTabPan  =  extVia.regApp.myRaster.initCenterTabPanel(tabCfg); <br> 
        // same as
        var centerTabPan  =  extVia.regApp.myRaster.initMainRegionTabPanel("center", tabCfg);<br>  
        extVia.regApp.myRaster.addToCenter(centerTabPan);<br>   
        ...goAhead<br> 
      <br>
    </code> 
    * 
    * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/07/12 09:54:54 $
 *            $Revision: 1.1.2.6 $
 */

if (extVia.ui.cmp && extVia.ui.cmp.factory && extVia.ui.cmp.factory.component){
    extVia.ui.cmp.factory.component.extViaLayoutRegion = extVia.ui.layout.region.Center;
}



extVia.ui.page.BaseRaster = function(config){
    if (config && config.viewCfgFromUrl){
        var viewCfgFromUrl = this.getViewConfigFromUrl();
        Ext.apply(config, viewCfgFromUrl);
    }
  Ext.apply(this,config,{    
    id          : "extVia.ui.page.BaseRaster",
    name        : "extVia.ui.page.BaseRaster",
    viewport    : null,
    mainNorth   : null,
    mainEast    : null,
    mainCenter  : null,
    //menu
    showMenubar : true,
    mainMenu    : null
  });
};
    
extVia.ui.page.BaseRaster.prototype = {
        
  /**
   * Raster + Region specific<br>
   * REFAC: init your regions here, call from extVia.regApp.myRaster.onReady
   */
  initRegions : function initRegions() {
  },

  /**
   * Raster + Region specific<br>
   * init your Margins here
   */
  initMargins : function initMargins() {
    var northMargins = '0 12 12 12';
    var westMargins = '0 5 12 12';
    var centerMargins = '0 12 12 5';
    var eastMargins = '0 12 12 5';
    var southMargins = '5 12 12 12';
    
   northMargins = '0 0 8 0';

    extVia.regApp.myRaster.northMargins = northMargins;
    extVia.regApp.myRaster.westMargins = westMargins;
    extVia.regApp.myRaster.centerMargins = centerMargins;
    extVia.regApp.myRaster.eastMargins = eastMargins;
    extVia.regApp.myRaster.southMargins = southMargins;
    extVia.regApp.myRaster.pgBoxMargins = extVia.constants.raster.pgBoxMargin+' ' +extVia.constants.raster.pgBoxMargin+' ' +extVia.constants.raster.pgBoxMargin+' ' +extVia.constants.raster.pgBoxMargin;
     

  },
        
  /**
   * Called from every Applications . Builds the pageraster. The events are send to the default handlers of the given
   * Application (regApp).
   * 
   * @param {extVia.xyApp} regApp the given Application Object
   * @param {JSON - Object} params whatever needed
   */
  onReady : function onReady(regApp, params) {
    // Set as global Applicatian
    extVia.regApp = regApp;
    extVia.regApp.myRaster = this;
    if (!extVia.regApp.appMode){
        extVia.regApp.appMode = extVia.app.setup.appMode;
    }


    Ext.getBody().addCls('xty_proto-app');

    extVia.regApp.myRaster.initMargins();

    extVia.ui.page.raster.showMenubar = false;
    
    this.mainNorth = new Ext.panel.Panel({
      layout : 'hbox', // proto-specific
      pack : 'start',// proto-specific
      id : 'panel_mNorth',
      cls : 'xty_region xty_regionNorth ',
      bodyCls : 'xty_region-body xty_regionNorth-body',
      itemId : 'suitebar',
      region : 'north',
      myApp : 'extVia.app.area.navi.main',
      preventHeader : true,
      border : false,
      frame : false,
      bodyBorder : false,
      split : true,
      collapsible : false,
      titleCollapse : false,
      autoScroll : false,
      height : 50,
      margin : extVia.regApp.myRaster.northMargins
      //,items : [ this.mnPan ]
    });

    // -- west --
    if (!this.hideWest) {
      this.mainWest = new Ext.panel.Panel({
        id : 'panel_mw',
        // title : 'west',
        region : 'west',
        width : 380, //extVia.constants.raster.mainWestWidth,
        cls : 'xty_region xty_regionWest',
        bodyCls:'xty_region-body',
        collapseFirst : false,
        margin : extVia.regApp.myRaster.westMargins,
        bodyBorder : false,
        border : false,
        split : true,
        header : false,
        collapsible : true,
        listeners:{
          expand:function(){
           this.doLayout();
          }
        }
      });

    }

    
    // -- east --
    if (this.buildEast) {
      this.mainEast = new Ext.panel.Panel({
        id : 'panel_me',
        hidden: this.hideEast,
        // title : 'east',
        region : 'east',
        width : extVia.constants.raster.eastWidth,
        cls : 'xty_region xty_regionEast',
        bodyCls:'xty_region-body',
        collapseFirst : false,
        margin : extVia.regApp.myRaster.eastMargins,
        bodyBorder : false,
        border : false,
        split : true,
        header : false,
        collapsible : true,
        listeners:{
           show:function(panel ){
              var centerPanel =  extVia.regApp.myRaster.getCenter();
              centerPanel.margins.right=12;
           },
           hide:function(panel ){
              var centerPanel =  extVia.regApp.myRaster.getCenter();
              centerPanel.margins.right=24;
           }                      
           
        }
      });
    }

    
    // -- south --
    if (this.buildSouth) {
      this.mainSouth = new Ext.panel.Panel({
        id : 'panel_ms',
        region : 'south',
        hidden: this.hideSouth,
        cls : 'xty_region xty_regionSouth',
        bodyCls:'xty_region-body',
        height: extVia.constants.raster.southHeight,
        collapseFirst : false,
        margin : extVia.regApp.myRaster.southMargins,
        bodyBorder : false,
        border : false,
        split : true,
        header : false,
        collapsible : true
      });
    }
    
    
    // -- center --
    this.mainCenter = new Ext.panel.Panel({
      id : 'panel_mC',
      region : 'center',
      cls : 'xty_region xty_regionCenter',
      bodyCls:'xty_region-body',
      collapseFirst : false,
      margin : extVia.regApp.myRaster.centerMargins,
      bodyBorder : false,
      border : false
      //,bbar: {xtype:'toolbar', items:['->',{text:'DOWNLO'}]}   
    });

    
    if (this.modulDscr){
        var modulPagejob =  extVia.ui.page.pagejob.getPagejobBar({pgjobDscr:this.modulDscr }) ;
        this.mainCenter.add(modulPagejob);
        this.mainCenter.modulPagejob = modulPagejob;
    }
    
    var vpItems = [ this.mainCenter ];
    if (!this.hideNorth) {
      vpItems.push(this.mainNorth);
    }
    if (!this.hideWest) {
      vpItems.push(this.mainWest);
    }
    if (this.buildEast) {
        vpItems.push(this.mainEast);
    }
    if (this.buildSouth) {
        vpItems.push(this.mainSouth);
    }
    
    
    // -- viewport --
    this.viewport = new Ext.container.Viewport({
      id : 'viewport',
      layout : 'border',
      items : vpItems
    });
    
      

    // Needed on every center
    Ext.panel.Panel.prototype.setTabTip = function(msg) {
      var tabPanel = this.findParentByType(Ext.tab.Panel);
      if (tabPanel) {
        var tabEl = Ext.fly(tabPanel.getTabEl(this).id);
        if (tabEl) {
          var tsTxt = tabEl.child('span.x-tab-strip-text', true);
          if (tsTxt) {
            tsTxt.qtip = msg.toString();
          }
        }
      }
    };
    
    
    
    Ext.panel.Panel.prototype.addHeaderCls =  function(headerCls,cfg) {
           if(Ext.isDefined(this.header)){
             var a, hasCls = false;
             for(a = this.header.additionalCls.length-1; a >= 0; a--){
               if(this.header.additionalCls[a] === headerCls){
                 hasCls = true;
                 break;
               }
             }
             if(!hasCls){
               this.header.addCls('xty_accordionHd');
             }
           }
         };
    
    
    Ext.panel.Panel.prototype.setPagejobText = function(pgjobText, pgjobEpobDscr) {
    Ext.getCmp( this.getTopToolbar().id).setPagejobText(pgjobText, pgjobEpobDscr);
    };
    Ext.panel.Panel.prototype.setMeasuredTabTitle = function(title) {
      // var shortTitle = extVia.ui.layout.factory.getMeasuredTabTitle(epobDscr);
      // this.setTitle(shortTitle);
      // this.setTabTip(title);
    };
    Ext.panel.Panel.prototype.setTip = function(msg) {
       var span = Ext.getCmp(this.id).header.child('span');
       span.dom.setAttribute('ext:qtip',msg );
    };
    /**
     * Shows and Hides Tools and sets invisible Property.<br>
     * to provides persitance of visibility-State
     * <code>this.tools[toolId].invisible = !visible; </code>
     *  So the Tool can be asked about its visibility state
     * @param {String } toolId 
     * @param {boolean} visible
     */
    Ext.panel.Panel.prototype.setToolVisibility = function(toolId, visible) {
      if (this.tools && this.tools[toolId]) {
        if (visible) {
          this.tools[toolId].show();
        } else {
          this.tools[toolId].hide();
        }
        this.tools[toolId].invisible = !visible;
      }
    };
    /**
     * Triggers our Ext.panel.Panel.prototype.setToolVisibility
     */
    Ext.panel.Panel.prototype.hideTool = function(toolId) {
      this.setToolVisibility(toolId, false);
    };    
    /**
     * Triggers our Ext.panel.Panel.prototype.setToolVisibility
     */
    Ext.panel.Panel.prototype.showTool = function(toolId) {
      this.setToolVisibility(toolId, true);
    };
    
    // ------ Start navigationbar ------ //
    var doNavigationbar = false;
    if (extVia.regApp.myRaster.showMenubar) {
        extVia.ui.page.raster.addToNorth( { 
            //hidden:true,
            itemId : 'navigationbar-bin', 
            //itemId:'menubar-modules-wrapper',
            style:'padding-top:2px;',
            xtype:'panel', 
            width:692, 
            height:36 , 
            flex:3,
            border:false, 
            text:'resp' ,
            tbar:{
                height:35, 
                border: false,
                cls:'xty_navigationbar',
                itemId: 'navigationbar',
                items: [
                        {xtype:'button', tesxt:'home', iconCls:'xty_viaMenubar-home', cls:'xty_viaMenubar-level1',
                         menu:{items:[{text:'sublevel 1: entry 1', menu:{items:[{text:'sublevel 1: entry 2', menu:{items:[{text:'sublevel 1: entry 3', menu:{items:[{text:'sublevel 1: entry 4', menu:{items:[{text:'sublevel 1: entry 5',menu:{items:[{text:'sublevel 1: entry 7', menu:{items:[{text:'sublevel 1: entry 8', menu:{items:[{text:'sublevel 1: entry 9',menu:{items:[{text:'sublevel 1: entry 10' }]} }]}}]}}]} }]}}]}}]} }]}}]}
                        }              
                    ]
             }
        });
       var navigationToolsPanel =  extVia.ui.page.raster.addToNorth( {  
         xtype:'toolbar', 
         width:342, 
         cls:'xty_navigationTools-panel', 
         itemId:'navigationTools-wrapper',
         style:'border:0px;',
         border: false, 
         bodyBorder: false, 
             items: [  {xtype:'button'}
          ]
     });
  
    }
    // ------ End navigationbar ------ //
  }, // eo onReady
  

  
  /**
   * Inits main Region TabPanel with id panel_m{r}Tabs. {r} is the first Char of the region.
   * @param region {String}
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initMainRegionTabPanel : function initMainRegionTabPanel(region, tabCfg){
       
      var regionChar = region.substring(0,1).toLowerCase();
      var id = "panel_m"+regionChar+"Tabs";
      
      var cfg =  {
              activeTab: 0,
              id:id,
              itemId:id,
              border:false,
              addAndActivate:function(tabCfg){    
                 var tab = this.getComponent(tabCfg.itemId);
                 
                 if (! tab){
                     tab =  this.add(tabCfg);
                 }
                 this.setActiveTab(tab);
                 if (this.ownerCt.collapsed){
                     this.ownerCt.expand();
                     this.ownerCt.doLayout();
                 } 
                return tab;  
              },
              addUnique:function(tabCfg){     
                     var tab = this.getComponent(tabCfg.itemId);
                     if (! tab){
                         tab =  this.add(tabCfg);
                     } 
                    return tab;  
                  },
              defaults :{
                  border:false,
                  bodysPadding: 10
              }
      };
         
      Ext.apply(cfg, tabCfg);
      cfg.tabBar ={cls:'xty_regiontabpanel-tabbar xty_tabbar-noborder-rl'};

      if (tabCfg && tabCfg.tabBar  && tabCfg.tabBar.tools){
        cfg.tabBar.tools = tabCfg.tabBar.tools;
      }
      
      
      var regionTabPan = Ext.createWidget('tabpanel', cfg  ); 
      extVia.ui.page.BaseRaster[region+"TabPanel"] =  regionTabPan;
      return regionTabPan;
  },
  
  
  createModulePanel : function createModulePanel(cfg){  
     var title = cfg.title; //(cfg && cfg.title) ? cfg.title : 'Module';  
     var pgjobDscr = (cfg && cfg.pgjobDscr) ? cfg.pgjobDscr : title ;
  
     var  pgjobButtons = (cfg&& cfg.tbar && cfg.tbar.items)?cfg.tbar.items:null;
     
     var modulePanel = Ext.create('Ext.panel.Panel', {
      layout : 'fit',
      title: title,
      cls:'xty_modulePanel-bin',
      tabConfig: {
            iconCls:'xty_module-home',
            cls:'xty_ modulePanel-tabitem',
            style:(cfg && cfg.showTabItem)?'':'display:none;'
        },
      tbar :   extVia.ui.page.pagejob.getPagejobBar({pgjobDscr: pgjobDscr ,pgjobButtons: pgjobButtons}),
      id : 'mcModulePanel',
      border:cfg.border,
      style:cfg.style,
      html:cfg.html,
      listeners:cfg.listeners,
      items:cfg.items,
      itemId : 'modulePanel',
      myApp : extVia.regApp.id,
      toolscope : '-'
    });
    return modulePanel;    
    },
  
  /**
   * Inits centerTabPanel with id panel_mcTabs
   * 
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initCenterTabPanel : function initCenterTabPanel(tabCfg){ 
      
    if (!tabCfg){tabCfg={};}
    tabCfg.tabBar = Ext.apply(this.getTabBarCfg(),tabCfg.tabBar );   
    
    var centerTabPanel = this.initMainRegionTabPanel("center", tabCfg);
    
  
    var onTabPanelCenterChange = function(tab, newcard, oldcard, obj) {
      if (tab.tabBar && tab.tabBar.handleTabChange)  {
        tab.tabBar.handleTabChange(newcard,tab.tabBar ); 
      }
    };  
    centerTabPanel.mon(centerTabPanel, 'tabchange', onTabPanelCenterChange);  
  
    if (tabCfg.modulePanelCfg){
     extVia.regApp.modulePanel = this.createModulePanel(tabCfg.modulePanelCfg);
     centerTabPanel.add(extVia.regApp.modulePanel);
    }
    

  
    centerTabPanel.on('add', function(tabPanel, component, index, eOpts){
        if(extVia.regApp.myRaster.mainCenter.modulPagejob){
            extVia.regApp.myRaster.mainCenter.modulPagejob.hide();  
        }
    });

    centerTabPanel.on('remove', function(tabPanel, component, eOpts){
        if(tabPanel.items.length===0 && extVia.regApp.myRaster.mainCenter.modulPagejob){
            extVia.regApp.myRaster.mainCenter.modulPagejob.show();  
        }   
     });

     return centerTabPanel;
  },
 
  /**
   * Inits westTabPan with id panel_mwTabs
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initWestTabPanel : function initWestTabPanel(tabCfg){
   
    
    var striptools;
    if (tabCfg && tabCfg.tabBar && tabCfg.tabBar.tools){
      striptools = tabCfg.tabBar.tools;
    }
    
    
    if (!tabCfg){tabCfg={};}  
    tabCfg.tabBar = Ext.apply(this.getTabBarCfg(),tabCfg.tabBar );   
    
    if (striptools){
        tabCfg.tabBar.tools = striptools;
    }


    var onTabPanelWestChange = function(tab, newcard, oldcard, obj) {
      
    if (tab.tabBar && tab.tabBar.handleTabChange)  {
      tab.tabBar.handleTabChange(newcard,tab.tabBar ); 
    }
    var modulePanel =  extVia.regApp.modulePanel;
    if (modulePanel){
      var pgjobDscr = extVia.regApp.getModulePagejobDscr ? extVia.regApp.getModulePagejobDscr(newcard) : newcard.title; 
      modulePanel.getComponent('pagejobbar').setPagejobDscr(pgjobDscr);
     }
    };    
    var tabPanelWest = this.initMainRegionTabPanel("west", tabCfg);
    tabPanelWest.mon(tabPanelWest, 'tabchange', onTabPanelWestChange);  
    return tabPanelWest;
  },
  
  /**
   * Inits eastTabPan with id panel_mwTabs
   * @param tabCfg
   * @returns TabPanel {Component}
   */
  initEastTabPanel : function initEastTabPanel(tabCfg){
      return this.initMainRegionTabPanel("east", tabCfg);
  },  
  
  
  /**
   * Gets main Region TabPanel with id panel_m{r}Tabs. {r} is the first Char of the region.
   * @param region {String}
   * @returns TabPanel {Component}
   */
  getMainRegionTabPanel : function getMainRegionTabPanel(region, regionPan){
      var regionTabPan  = extVia.ui.page.BaseRaster[region+"TabPanel"];
      return regionTabPan;
  },
  
  /**
   * Gets centerTabPanel with id panel_mcTabs.
   * @returns TabPanel {Component}
   */
  getCenterTabPanel : function getCenterTabPanel(){ return this.getMainRegionTabPanel("center");},
  /**
   * Gets westTabPanel with id panel_mwTabs.
   * @returns TabPanel {Component}
   */
  getWestTabPanel : function getWestTabPanel(){ return this.getMainRegionTabPanel("west");},
  /**
   * Gets eastTabPanel with id panel_meTabs.
   * @returns TabPanel {Component}
   */
  getEastTabPanel : function getEastTabPanel(){ return this.getMainRegionTabPanel("east");},
  /**
   * Gets southTabPanel with id panel_msTabs.
   * @returns TabPanel {Component}
   */
  getSouthTabPanel : function getSouthTabPanel(){  return this.getMainRegionTabPanel("south");},
  
  showMainCenterMessageMask : function showMainCenterMessageMask(bShow, sMessage) {
    return this.showMainRegionMessageMask("Center", bShow, sMessage);
  },
  
  
  /**
   * 
   * @param region
   * @param bShow
   * @param sMessage
   */
  showMainRegionMessageMask : function showMainRegionMessageMask(region, bShow, sMessage, cfg) {

    if (!region ) {region = "Center";}
    var regionCmp = this["main"+region]; 
    if (region==="viewport") { regionCmp = Ext.getBody();}
      
      if (bShow) {  
          
        var defCfg ={msg : sMessage,removeMask : true};  
        if (cfg){
            Ext.apply(defCfg, cfg);
        } 

        regionCmp.loadingMask = regionCmp.loadingMask || new Ext.LoadMask(regionCmp.id, defCfg);
        regionCmp.loadingMask.show();
        } else {
          // delay the loading mask switch off to prevent flash the loading mask if a function is lightning fast.
          var func = Ext.bind(function() {
             regionCmp.loadingMask.hide();
          }, this);
          Ext.defer(func, 1000);
        }
      return regionCmp.loadingMask;
      },
  

  
  /**
   * Adds Component to viewports border-Layout center Panel
   * @param oObject
   */
  addToCenter : function addToCenter(oObject) {
    return this.mainCenter.add(oObject);
  }
  ,
  /**
   * Adds Component to viewports border-Layout north Panel
   * @param oObject
   */
  addToNorth : function addToNorth(oObject) {
      if (this.mainNorth){
         return  this.mainNorth.add(oObject);
      }  
  },
  /**
   * Adds Component to viewports border-Layout west Panel
   * @param oObject
   */
  addToWest : function addToWest(oObject) {
    if (this.mainWest){
      return this.mainWest.add(oObject);    
    }
  },
  /**
   * Adds Component to viewports border-Layout east Panel
   * @param oObject
   */ 
  addToEast : function addToEast(oObject) {
    if (this.mainEast) {
        return  this.mainEast.add(oObject);
    }
  },
  /**
   * Adds Component to viewports border-Layout south Panel
   * @param oObject
   */
  addToSouth : function addToSouth(oObject) {
      if (this.mainSouth){
          return  this.mainSouth.add(oObject);  
      } 
  },
  
  
   getCenterRight : function getCenterRight() {
    return this.mainCenter.getEl().getRight(); 
   },
  
  
  /**
   * Returns viewports border-Layout center Panel
   * @returns Panel
   */
  getCenter : function getCenter() {return this.mainCenter; },
  /**
   * Returns viewports border-Layout west Panel
   * @returns Panel
   */
  getWest : function getWest() {return this.mainWest; }, 
  /**
   * Returns viewports border-Layout north Panel
   * @returns Panel
   */
  getNorth : function getNorth() {return this.mainNorth; }, 
  /**
   * Returns viewports border-Layout east Panel
   * @returns Panel
   */
  getEast : function getEast() {return this.mainEast; }, 
  /**
   * Returns viewports border-Layout south Panel
   * @returns Panel
   */
  getSouth : function getSouth() {return this.mainSouth; },
  
  
   getUrlParams : function getUrlParams() {
      var qStr = location.href.replace(/.[^\?]*\?/,'');
      var urlParams = Ext.Object.fromQueryString(qStr);
      return urlParams;
  },
  /*
   * Looks for regions Param in Url. Sets border-region-flags for upperCase chars (hideNorth:false for N, hideWest:false for W, buildEast:true for E, buildSouth:true for S)
   * @returns Object
   */
  getViewConfigFromUrl : function getViewConfigFromUrl() {
        var qStr = location.href.replace(/.[^\?]*\?/,'');
        var viewCfg = {hideNorth:false,hideWest:false, buildEast:false, buildSouth:false};
        var urlParams = Ext.Object.fromQueryString(qStr);
        if (urlParams.regions){
            if (urlParams.regions.indexOf("N")===-1){viewCfg.hideNorth=true;}
            if (urlParams.regions.indexOf("W")===-1){viewCfg.hideWest=true;}
            if (urlParams.regions.indexOf("E")>-1){viewCfg.buildEast=true;}
            if (urlParams.regions.indexOf("S")>-1){viewCfg.buildSouth=true;}
        }
      return viewCfg;
  },
  
  getRoutingConfigFromUrl : function getRoutingConfigFromUrl() {

     function capitalizeFirstLetter(string) {
       return string.charAt(0).toUpperCase() + string.slice(1);
     }
     function evenSeperator(routeStr) {
       //routeStr = routeStr.replace(/=/,'/'); // jslint does not like this 
       var equalX = new RegExp("=");
       routeStr = routeStr.replace(equalX,'/');
       routeStr = routeStr.replace(/:/,'/');
       return routeStr;
     }
     
      var routingCfg = null;
      var url = location.href;
      if (url.indexOf('#')>-1){
          var routeStr = url.replace(/.[^\#]*\#/,'');
          if  (!Ext.isEmpty(routeStr) ){
            routingCfg = {};
            var routes = routeStr.split('#');
            routingCfg.routes = routes;
            if  (!Ext.isEmpty(routes[0])){
               routes[0] = evenSeperator(routes[0]); 
               var loadArr = routes[0].split('/'); 
               if (loadArr.length===1){
                routingCfg.loadType = 'Product';
                routingCfg.loadId = loadArr[0];
               }else{
                 routingCfg.loadType = (!Ext.isEmpty(loadArr[0]) ) ? capitalizeFirstLetter(loadArr[0]) : 'Product';
                 routingCfg.loadId = (!Ext.isEmpty(loadArr[1]) ) ? loadArr[1] : '*';
               }    
               
            }
            if  (!Ext.isEmpty(routes[1])){
               routes[1] = evenSeperator(routes[1]); 
               var subloadArr = routes[1].split('/');
               if (subloadArr.length===1){
                routingCfg.subloadType = 'tab';
                routingCfg.subloadId = subloadArr[0];
               }
               else{
                routingCfg.subloadType = subloadArr[0];
                routingCfg.subloadId = subloadArr[1];
               } 
            } 
          } 
      }
    return routingCfg;
  },
  
  

  getTabBarCfg : function getTabBarCfg(cfg) {  
   return {
      handleTabChange: function(newcard, tabBar){
       var tabBarItemsLen =0;
       if (tabBar.items){tabBarItemsLen = tabBar.items.length;}
       var i;
       for(i =0; i<tabBarItemsLen; i++){
        var tabBarItem = tabBar.items.get(i);
        if (tabBarItem && tabBarItem.isStriptoolButton){
          if(newcard && newcard[tabBarItem.itemId]){tabBarItem.show();}
          else{tabBarItem.hide();}
        }
       }
      },
      items:[
        {xtype: 'tbfill'},
        this.getStriptoolButton({itemId:'moveHoriz',hidden:true}),
        this.getStriptoolButton({itemId:'refresh'}),
        this.getStriptoolButton({itemId:'preferences',hidden:true})
      ]
   };
  },
  
  getStriptoolButton : function getStriptoolButton(cfg) {           
    var striptoolButtonHandler = function(btn,e){ 
      var acttab =  btn.up('tabpanel').getActiveTab();
        if (acttab[btn.itemId]){
          try {
           acttab[btn.itemId]();
          } catch (oEx) {extVia.notify('BaseRaster.activeTab['+acttab.title+']#'+btn.itemId+"\n"+oEx);}
        }
        else{
          extVia.notify(btn.itemId + " not avilable on "+acttab.title) ;
        }
     };

    var btnCfg =  {
      xtype:'button', 
      cls:'xty_striptool-button', 
      isStriptoolButton:true,
      handler:striptoolButtonHandler,
      tooltip:'resKey: '+cfg.itemId,
      iconCls:'xty_button-tool xty_button-tool-'+cfg.itemId,
      height:22   
    };
    Ext.apply(btnCfg, cfg);
    return btnCfg;
  },    
    
  
  // >>> START copied from V3.8 extVia.ui.layout.factory. 18.01.2013 <<<  
  /**
   * Returns measuredTitles for Tabs which are not wider than 160px, if so they have an ellipsis(...)<br>
   * to add a tab tooltip with the original long text, use the following in the tab panel item config:<br>
   * 
   *       tabConfig: {<br>
   *         tooltip: longTitle<br>
   *       },<br>
   * 
   * @param title
   * @param region
   */
  getMeasuredTabTitle: function(title, region) {
    var center_tabItemMaxWidth = 150;
    return extVia.regApp.myRaster.getMeasuredText(title, center_tabItemMaxWidth, "x-tab") ; 
  },
  
  /**
   * Returns measuredText with is cutted and added an ellipsis(...), if wider thean given maxWidth
   * @param text
   * @param maxWidth
   * @param targetCls
   */  
  getMeasuredText: function(text, maxWidth, targetCls) {
        var measuredText = text;
        var fullWidth = extVia.regApp.myRaster.getTextMetricsWidth(text, targetCls);
        if (fullWidth>maxWidth){
          var diff = fullWidth - maxWidth;
          var diffProz = diff/fullWidth;
          var textLen = text.length;
          var strLenRounded = Math.round(textLen - (textLen * diffProz));
          //measuredText = text.substring(0, strLen_n)+'...';    
          measuredText = Ext.String.ellipsis(text, strLenRounded);
        }
        return measuredText;
      },
    /**
   * Will be used by  {@link extVia.regApp.myRaster.getTextMetricsWidth} or {@link extVia.regApp.myRaster.getTextMetricsHeight},
   */  
  textMetricsInstances: [],
   /**
   * Will be used by  {@link extVia.regApp.myRaster.getTextMetricsWidth} or {@link extVia.regApp.myRaster.getTextMetricsHeight},
   * Represents the div-classes these UI-Element are to be measured in.
   */  
  textMetricsEtys: null,
  /**
   * maps ety to cssclasses, for text measuring
   */
  textMetricsEtysInit: function ()  { 
      extVia.regApp.myRaster.textMetricsEtys=[];
      extVia.regApp.myRaster.textMetricsEtys["_"+extVia.ui.dto.ety.NOTIFICATION] ="x-window-mc";
      extVia.regApp.myRaster.textMetricsEtys["_"+extVia.ui.dto.ety.BUTTON] ="x-btn-text";
      extVia.regApp.myRaster.textMetricsEtys["_"+extVia.ui.dto.ety.MENU] ="x-menu-item-text";
  },
  
   /**      
   * Returns the measured width of the specified text.
   * Uses Ext.util.TextMetrics.createInstance({@link extVia.regApp.myRaster.textMetricsDefaultInst})
   * @param {String} text The text to measure
   * @param {Number| String} etyCls The target-UI-Element to be measured in
   * @return {Number} width The width in pixels
   */     
    getTextMetricsWidth: function (text, etyCls)  { 
      if (!extVia.regApp.myRaster.textMetricsEtys){
        //Ext.Msg.alert("Message", "textMetricsEtysInit");
        extVia.regApp.myRaster.textMetricsEtysInit();
      }  
      if (Ext.isEmpty(extVia.regApp.myRaster.textMetricsInstances["_"+etyCls])){
        var div  = document.createElement("div");
        var cls ;
        if (extVia.regApp.myRaster.textMetricsEtys["_"+etyCls]){
         cls = extVia.regApp.myRaster.textMetricsEtys["_"+etyCls];
        }else{
          cls = etyCls; 
        }
        div.setAttribute("class",cls);
        extVia.regApp.myRaster.textMetricsInstances["_"+etyCls] =  new Ext.util.TextMetrics( div  );
      }
     
      var currInst =  extVia.regApp.myRaster.textMetricsInstances["_"+etyCls];
        
      if (currInst){
       return currInst.getWidth(text);
      }else{
        return -1; 
      }
    }
  // >>> END copied from V3.8 extVia.ui.layout.factory. 18.01.2013 <<<  
  
  
  
};

