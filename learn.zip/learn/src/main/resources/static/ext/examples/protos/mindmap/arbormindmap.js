Ext.define('extVia.component.ArborMindmap', {
	extend : 'Ext.panel.Panel',
	alias : 'widget.mindmap',

	/**
	 * @cfg {Object} renderer Specific renderer object for rendering the mindmap, for emxaple the
	 *      {@link extVia.renderer.Mindmap}.
	 */
	renderer : null,

	/**
	 * @private
	 * @cfg {Object} particleSystem The particle system from the arbor.js framework.
	 */
	particleSystem : null,

	/**
	 * @private
	 * @cfg {String} viewId ID of the canvas.
	 */
	viewId : null,
	
	/**
	 * @config {Object} arborParameters Parameters for the particle system of arbor.
	 */
	arborParameters : {
		/**
		 * @cfg {Number} repultion (ger.: Rückstoß).
		 */
		repulsion : 1000,
		/**
		 * @cfg {Number} stiffness (ger.: Starre)
		 */
		stiffness : 600,
		/**
		 * @cfg {Float} friction (ger.: Reibung)
		 */
		friction : 0.5,
		/**
		 * @cfg {Boolean} gravity
		 */
		gravity : true,
		/**
		 * @cfg {Number} fps Frames per second.
		 */
		fps : 25
	},

	/**
	 * @private
	 * @param {Object} config User config for initializaion.
	 */
	constructor : function(config) {
		this.viewId = Ext.id();
		this.html = '<canvas id="' + this.viewId + '" width="' + (config.width || 0) + '" height="'
			+ (config.height || 0) + '">Your Browser doens\'t support the canvas element.</canvas>';
		this.addEvents('receivenode');

		this.callParent(arguments);
	},

	// @private
	listeners : {
		/**
		 * Initializes a {@link arbor#Particlesystem()} with the canvas HTMLElement and a renderer
		 * {@link extVia.renderer.Mindmap}.
		 * 
		 * @private
		 * @param {extVia.component.Mindmap} me instance of the current mindmap object
		 * @param {Object} eOpts event options
		 */
		afterrender : function(me, eOpts) {
			me.draw(me.root);
		},
		/**
		 * @private
		 * @param {Ext.data.NodeInterface} node a node given with this listener.
		 */
		receivenode : function(node) {
			console.log(arguments);
		}
	},

	/**
	 * @private
	 */
	initParticleSystem : function() {
		var me = this;
		if (me.particleSystem) {
			me.particleSystem.stop();
		}
		me.particleSystem = arbor.ParticleSystem();
		me.particleSystem.parameters(me.arborParameters || {});
//		me.particleSystem.renderer = new extVia.renderer.Mindmap({
//				viewId : me.viewId
//			});
		
		me.particleSystem.renderer = Renderer("#" + me.viewId) ;
	},

	/**
	 * @param {Ext.data.NodeInterface} node
	 */
	draw : function() {
		var node = this.root;
		var me = this;
		if(me.particleSystem) {
			me.particleSystem.stop();
		}
		me.initParticleSystem();
		me.particleSystem.addNode(node.data.text, {
			'color' : 'red',
			'shape' : 'dot',
			'label' : node.data.text,
			'visible' : true,
			'expanded' : node.isExpanded() 
		});
		node.childNodes.forEach(function(child) {
			me.drawChild(node, child);
		});
		console.log(node);
	},

	/**
	 * @private
	 */
	drawChild : function(parent, node) {
		var me = this;
		me.particleSystem.addNode(node.data.text, {
			'color' : '#999999',
			'label' : node.data.text,
			'visible' :  parent.isExpanded() && parent.isVisible(),
			'expanded' : node.isExpanded() 
		});
		me.particleSystem.addEdge(parent.data.text, node.data.text);
		node.childNodes.forEach(function(child) {
			me.drawChild(node, child);
		});
	},
	
	setRoot : function(node) {
		this.root = node;
	}

});
