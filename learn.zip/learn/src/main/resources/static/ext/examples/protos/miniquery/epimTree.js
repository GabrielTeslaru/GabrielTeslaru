Ext.namespace('extVia.epimTree');
/**
 * @class extVia.epimTree
 * 
 * 
 * @author    Artur Taranyuk, Viamedici Software GmbH
 */

extVia.epimTree = function(config){
  Ext.apply(this,config,{    
    id          : "extVia.epimTree",
    name        : "extVia.epimTree"
  });
};
    
extVia.epimTree.prototype = {

	
    getTreePanels : function getTreePanels(treeStores){
    	
    	var stores = treeStores ; 
    	
	    var productsTree = Ext.create('Ext.tree.Panel', {
	        store: stores.productsStore,
	        border: false,
	        preventHeader: true,
	        header: false,
	        hideHeader: true,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true
	    });
	    
	    var elementsTree = Ext.create('Ext.tree.Panel', {
	        store: stores.elementsStore,
	        border: false,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true
	    });
	    
	    var collectionsTree = Ext.create('Ext.tree.Panel', {
	        store: stores.collectionsStore,
	        border: false,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },	        useArrows: true
	    });
	    
	    return{
	    productsTree : productsTree,
	    elementsTree : elementsTree,
	    collectionsTree : collectionsTree
	    };

    },
    
    showSammlungsDialog : 	function getSammlungsDialog(item, cfg){
    	 
    	var sammlungsDialog = Ext.create('widget.window', {
    		title:"Elemente &uuml;bernehmen",
    		items:[
    		       {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img  src='../img/fakes/collectionWidg.png'/>"}
    		       ]
    	});
    	
    	
    	sammlungsDialog.show();
    	
    },
    
    
    getWestTabsCfg : 	function getWestTabsCfg(){
    	
    	
    	var treeStores = extVia.stores.initTreeStores();
    	
    	var treePanels = extVia.epimTree.getTreePanels(treeStores);
    	
    	
	    var structureTree = Ext.create('Ext.tree.Panel', {
	    	rootVisible:false,
	        store: treeStores.productsStore,
	        border: false,
	        preventHeader: true,
	        header: false,
	        hideHeader: true,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true
	    });
	    
     	var tabsCfg =  {
        activeTab: 1,
        width: '100%',
	    height: '100%',
        items: [

        	{
        	title: 'Hierarchien',itemId:'hierarchien',
        	 items:[
        	        treePanels.productsTree ,
        	        treePanels.elementsTree 
        	        ]
			},
        	{title: 'Collections',itemId:'collections',
       	 	items:[
       	        treePanels.collectionsTree    
       	        ]
			},       	
        	{ 
				id:'westTabItem_productstructure',
				itemId:'productstructure',
				title: 'ProduktStruktur',
				tbar:{
					items:[
					       '->',
					       
					       
					       {xtype:'splitbutton',tsext:"Samm",icon: '../../protos/img/epobs/collection_16.png',
					    	   handler :function(item){extVia.epimTree.showSammlungsDialog(item);},
					    	   menu:{items:[  {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img  src='../img/fakes/collectionWidg.png'/>"}]} 	       
					       },
					       
					       {xtype:'splitbutton',text:"Zuordnen",
					    	   handler:function(item){
					    		   
					    		   extVia.regApp.myRaster.getWest().setWidth(610);
					    		   extVia.regApp.myRaster.getWest().addCls("xty_hasEmbeddedQuery");
					    		   
					    		   
					         		var mask = extVia.ui.page.raster.showMainRegionMessageMask("West", true,"load Query", {modal:true});
					          		var lmHide = new Ext.util.DelayedTask(function(){
					          			extVia.ui.page.raster.showMainRegionMessageMask("West", false);
					          		});
					          		lmHide.delay(500);
					    		   
					          	   extVia.regApp.myRaster.getWest().setWidth(940);
					    		   extVia.regApp.myRaster.getWest().items.get(0).hide();
					    	   },
					    	   
					    	menu:{
					    		items:[
								       
								 {
					    		icon: '../../protos/img/epobs/P_STANDARD_REL0_REF0.png',
					    		text: extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCT +"_P"],
					    	    value: extVia.module.epob.PRODUCTS,
					    	    tooltip: {
					        		text: extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCT +"_P"],
					        		anchor: 'top'
					      		}
					    	    
					    		},{
					    		icon: '../../protos/img/epobs/productAndVariants.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTANDVARIANT +"_P"],
					    	    value: extVia.module.epob.PRODUCTANDVARIANT,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTANDVARIANT +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/V_STANDARD_REL0_REF0.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTVARIANT +"_P"],
					    	    value: extVia.module.epob.PRODUCTVARIANT,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTVARIANT +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/G_STANDARD_REL0_REF0.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTGROUP +"_P"],
					    	    value: extVia.module.epob.PRODUCTGROUP,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTGROUP +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/myProducts.png',	text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYPRODUCT +"_P"],
					    	    value: extVia.module.epob.MYPRODUCT,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYPRODUCT +"_P"],
					        		anchor: 'top'
					      		}
					    		},
					    		
					    			
					    		{width:10,html:'<div class="x-toolbar-separator x-box-item x-toolbar-item x-toolbar-separator-horizontal" style="margin: 0px;margin-left: 4px;top:-2px " ></div>'}
					    		
					    		
					    		,{
					        		icon: '../../protos/img/epobs/category_16.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.CATEGORY +"_P"],
					        	    value: extVia.module.epob.CATEGORY,
					        	    tooltip: {
					            		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.CATEGORY +"_P"],
					            		anchor: 'top'
					          		}
					        	}
					    		
					    		
					    		,{
					    		icon: '../../protos/img/epobs/e_elements.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"],
					    	    value: extVia.module.epob.ELEMENTS,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"],
					        		anchor: 'top'
					      		}
					    		}
					    		
					    		
					    		,{
					    		icon: '../../protos/img/epobs/e_myElements.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYCATEGORIES +"_P"],
					    	    value: extVia.module.epob.MYCATEGORIES,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.MYCATEGORIES +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_image_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"],
					    	    value: extVia.module.epob.IMAGE,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_graphic_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],
					    	    value: extVia.module.epob.GRAPHIC,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_text_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"],
					    	    value: extVia.module.epob.TEXT,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.TEXT +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_document_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"],
					    	    value: extVia.module.epob.DOCUMENT,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_edtable_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.EDTABLE +"_P"],
					    	    value: extVia.module.epob.EDTABLE,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.EDTABLE +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_prodtable.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTTABLE +"_P"],
					    	    value: extVia.module.epob.PRODUCTTABLE,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.PRODUCTTABLE +"_P"],
					        		anchor: 'top'
					      		}
					    		}
					    		
					    		
					    		
					    		,{
					    		icon: '../../protos/img/epobs/e_audio_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],
					    	    value: extVia.module.epob.AUDIO,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],
					        		anchor: 'top'
					      		}
					    		},{
					    		icon: '../../protos/img/epobs/e_video_var.png',text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],
					    	    value: extVia.module.epob.VIDEO,
					    	    tooltip: {
					        		text:  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],
					        		anchor: 'top'
					      		}
					    		}/**/
					    		
					    		,{width:10,html:'<div class="x-toolbar-separator x-box-item x-toolbar-item x-toolbar-separator-horizontal" style="margin: 0px;margin-left: 4px;top:-2px " ></div>'}
 
					    		]
					    	}   
					       }
					      ]
				},
				items:[structureTree],
                listeners:{
                	activate:function(){
                		extVia.regApp.myRaster.getCenter().getComponent("panel_mcTabs").setActiveTab("product_myriad");
                		
                		}
                }
            	}
        	
        	]
    };	
    return tabsCfg;
    },
    
    getCenterTabsCfg : function getCenterTabsCfg(){
    
         var rechBrch = "produkte";
         if (recherchebereich){
         	rechBrch = recherchebereich
         }
    
    	 var tabsCfg = {
            activeTab: 0,
            defaults :{
                bodyPadding: 10
            },
            items: [

            {
               
                title: 'Rechercheergebnisse',
                id:'queryCenterTab',
                itemId:'queryResults',
                tbar : extVia.ui.page.pagejob.getPagejobBar({pgjobDscr:rechBrch}),
                // >>> PROD V4 Start (EPIM-7678) <<<
                html:'<iframe width="603" height="832" id="queryAppIFRAME" style="margin-top:-38px" frameborder="0" src="../jsp/QueryApp.jsp?appModeName=queryWestRun&embeddedin=productmaintenance&epobType=ELEMENTS" ></iframe>',
                // >>> PROD V4 End (EPIM-7678) <<<
            },
            
            {
                html:'Produkt MYRIAD', 
                itemId:'product_myriad',
                tbar : extVia.ui.page.pagejob.getPagejobBar({pgjobDscr:"Produktpflege",epobDscr:"MYRIAD 50 Einbauleuchte, schwarz, blendreduziert"}),
                
                
                
                tbar : extVia.ui.page.pagejob.getApplicationBar( 
                	{ 
                	pgjobDscr:"Produktpflege", epobDscr:"MYRIAD 50 Einbauleuchte, schwarz, blendreduziert", 
                	pagetoolbarButtons: [
				           { iconCls : 'xty_pgtoolbar-save',scale : 'large'},
                	       {
					        xtype : 'splitbutton',
					        name : 'collection',
					        handler :function(item){extVia.epimTree.showSammlungsDialog(item);},
					        menu:{items:[  {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img  src='../img/fakes/collectionWidg.png'/>"}]},     
					        margin : '0 0 0 10',
					        tooltip : 'sammlungen',
					        iconCls : 'xty_pgtoolbar-collection',
					        scale : 'large',
					        listeners : {
					        }
					      },
				          { iconCls : 'xty_pgtoolbar-delete',scale : 'large'}
                	  ]
                	} 
                	),
                
                
                title: extVia.regApp.myRaster.getMeasuredTabTitle('MYRIAD 50 Einbauleuchte, schwarz, blendreduziert'),
                listeners:{
                	activate:function(){
                		extVia.regApp.myRaster.getWest().getComponent("panel_mwTabs").setActiveTab("productstructure");
                		
                		}
                }
            }
            
            
            ]
        };
    	 
    	// extVia.ui.page.BaseRaster.centerTabPanel =  tabs;
    	 
    	 return tabsCfg;
    }
    
  
};


extVia.epimTree = new extVia.epimTree();


/*
 * 
 * $Revision: 1.10.12.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2019/12/10 10:46:40 $
 * $Author: lowen $
 * $viaMEDICI Release: 3.9 $
 * 
 */