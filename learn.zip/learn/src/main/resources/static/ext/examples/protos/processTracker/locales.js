Ext.namespace('extVia.locales' ,'extVia.processTracker.locales');
/**
 * @class extVia.processTracker.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2013/06/07 16:00:05 $
 *            $Revision: 1.6 $
 */

extVia.processTracker.locales = {
        appName:'Prozess Tracker',

        searchtermAsRegex:'als reg. Ausdruck',
        startdate:'Startdatum',
        starttime:'Startzeit',
        enddate:'Enddatum',
        endtime:'Endzeit',
        interfaceTo: 'Schnittstelle',
       
        refreshIntervall :'Lade Intervall', 
        process :'Prozess',
        processId :'Prozess Id', 
        description : 'Bezeichnung'
};

Ext.apply(extVia.locales, extVia.processTracker.locales);



/*
 * 
 * $Revision: 1.6 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2013/06/07 16:00:05 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 