
Ext.namespace('extVia.historyProto.dummies');
Ext.define('extVia.historyProto.statics', {
    statics: {

//  gridPinfoValueRendererHistory: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
//     return extVia.versionsProto.statics.gridPinfoValueRendererByCfg( value, metaData, record, rowIndex, colIndex, store, view, {isVersionColumn:false, imagesExanded:true} );
//  },
   
      
  getActionDscr: function(  objdepAction,  record  ) {
//    var causeAction  = record.get('causeAction'); 
//    var targetAction = record.get('targetAction'); 
//    var objdepAction = record.get('objdepAction'); 
    var actionDscr =  '';
    
    var targetPropEpobType='';
    
//    var depEpobType= record?record.get('objedepEpobType'):' nnix recca ';   
//    
//    var depEpobTypeDscr = ''; 
//    
//    if (  extVia.ui.page.strings.epobs['Epob_'+ depEpobType+'_P']){
//      depEpobTypeDscr = extVia.ui.page.strings.epobs['Epob_'+ depEpobType+'_P'];
//    }


   var actions = 

    'GPV_UPD_GPV_ASSIGNMENT_DIRECT_DIRECT' +  // Productrelations     Produktbeziehungen // Zubeh�r
    'GPV_UPD_GPV_ASSIGNMENT_DIRECT_INHERITED' + // Productrelations
    'GPV_UPD_GPV_ASSIGNMENT_CHILD_DIRECT' +  // Productrelations   Kinder von Produktbeziehungen 
    'GPV_UPD_GPV_ASSIGNMENT_CHILD_INHERITED' + // Productrelations
    'GPV_UPD_GPV_SORTIMENT_1' +  // Back-referenz
    'GPV_UPD_GPV_SORTIMENT_N' +  // Back-referenz
    'GPV_UPD_GPV_REFERENCE_1' +
    'GPV_UPD_GPV_REFERENCE_N' +
    'GPV_UPD_GPV_PARENT_1' + // Elternobjekte
    'GPV_UPD_GPV_PARENT_N' + //
    'GPV_UPD_GPV_CHILD_1' +  // Kindobjekte Produkte 
    'GPV_UPD_GPV_CHILD_N' +

  
'ELEMENT_ROOT_UPD + Sub-HistoryComment' +
'ELEMENT_VARIANT_INS + obje_id + obje_name' +
'ELEMENT_VARIANT_INS + obje_id + obje_name' +
'ELEMENT_VARIANT_INS + obje_id + obje_name' +
'ELEMENT_ROOT/VARIANT_UPD + obje_id + obje_name + Sub-HistoryComment' +
'ELEMENT_ROOT/VARIANT_UPD + obje_id + obje_name + Sub-HistoryComment' +
'ELEMENT_VARIANT_UPD + obje_id + obje_name + Sub-HistoryComment' +
'ELEMENT_VARIANT_UPD + obje_id + obje_name + Sub-HistoryComment' +
'ELEMENT_VARIANT_UPD + obje_id + obje_name + Sub-HistoryComment' +

'ELEMENT_VARIANT_DEL + obje_id + obje_name' +
'ELEMENT_VARIANT_DEL + obje_id + obje_name' +
'ELEMENT_ROOT/VARIANT_DEL + obje_id + obje_name' +
'ELEMENT_ROOT/VARIANT_DEL + obje_id + obje_name' +
    
    
    ////////////////////////
    'dict.upd_value_obpd_metadata' +   
    'dict.upd_value_prat' +
    'gpv.upd_prat' +
    'gpv.upd_prat_inherit' +
    'gpv.upd_prat_dynprat' +
    'gpv.upd_prat_dynprat_inherit';
    
      
    
    switch (objdepAction) {
      
      case "GPV_UPD_GPV_CHILD_1" :
        actionDscr =   ' Produktvarianten'; 
        break;
      case "GPV_UPD_GPV_PARENT_1" :
        actionDscr =   ' Elternobjekte'; 
        break;  
      case "GPV_UPD_GPV_ASSIGNMENT_DIRECT_DIRECT" :
        actionDscr =   'Elemente'; 
        break;
      case "GPV_UPD_GPV_ASSIGNMENT_DIRECT_INHERITED" :
        actionDscr =   'ererbte Element'; 
        break;
      case "GPV_UPD_GPV_REFERENCE_1" :
       actionDscr =   'Referenzen';
        break;
      default  :
        actionDscr =  '??';
        break;       
    }
    
    return  actionDscr;
     
  },    
      
      
      
  gridHistoryActionRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
     
    var causeAction  = record.get('causeAction'); 
    var targetAction = record.get('targetAction'); 
    var objdepAction = record.get('objdepAction'); 
      
    //return objdepAction;
     return '<div class="xty-history-targetAction xty_icon xty_iconHere" style="padding-left:18px;width:100%;"> '+targetAction+'</div><div class="xty-history-causeAction xty_icon xty_iconOrigin" style="padding-left:18px;width:100%;"> '+causeAction+'</div><div class="xty-history-objdepAction "style="padding-left:18px;width:100%;"> '+objdepAction+'</div>';
  },      
      
      
  
  gridPinfoAreaRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    //metaData.tdCls ="xty_histgrid-area-cell-XX  ";
    var actionAreaDscr = '';
    var pastDscr = '';
    var even = rowIndex %2===0 ;
    var even9 = rowIndex %9===0 ;
    var even19 = rowIndex %19===0 ;
      
    actionAreaDscr ='dies und das';
    actionAreaDscr = even ? 'Stammdaten' :'Attribute';
    pastDscr = even19?'gel�scht':  even9?'erstellt':  'ver�ndert';
    var objdepAction = record.get('objdepAction'); 

     if (objdepAction){
            actionAreaDscr = '<span class="xty_objdepActionDscr" > '+extVia.historyProto.statics.getActionDscr(objdepAction, record)+'</span>';
            //action = 'Es wurden '+actionAreaDscr+' '+pastDscr+'. ';
     }
    var action = actionAreaDscr+' <br> '+pastDscr+'. ';
   return action;
  
  },
  
  
  gridPinfoValueRendererHistory: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
     //metaData.tdCls ="xty_lockedColumnFake ";
     var oldvalue = record.get('oldvalue');
     
     if (!oldvalue){oldvalue = record.get('valueVersion');}
    
     oldvalue = value.substring(1,value.length-2);
     
     
     return '<div>'+value+'</div><div style="text-decoration:line-through;">'+oldvalue+'<div>';
  },   
    
    
  
  gridPinfoWhenGroupRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    

     //value = value.replace(/.:..$/,'0:00') 
    
    
     return extVia.historyProto.statics.gridPinfoWhenRenderer( value, metaData, record, rowIndex, colIndex, store, view ); 
    
  },
  
  
  
  
  timeRelatedRenderer: function ( value )  {
 
    var timeRelatedValue = value;
    var time = value.substring(11,value.length);

    var datum =  '';
    
    //'cause_change_date": "2015-10-15T18:37:46",'
    if (timeRelatedValue.indexOf('2016')===0){
     timeRelatedValue = timeRelatedValue.replace(/T/,' ');
     timeRelatedValue = timeRelatedValue.replace(/-/g,'/');  
     datum =  timeRelatedValue.substring(0,10).replace(/(....)(\/)(..)(\/)(..)/,"$5.$3.$1");
    }
    else {
     datum  = timeRelatedValue.substring(0,10);
    }
    
     timeRelatedValue = timeRelatedValue.substring(0,10);// cuts time turns  "30.04.2014 13:28:00" >> "30.04.2014";
     

     if (value.indexOf('2016-12-12T16')>-1){
      timeRelatedValue ="      heute";
     }
     else{
      timeRelatedValue = extVia.versionsProto.statics.timeRelatedDiffFromDate(timeRelatedValue); 
     }

     return timeRelatedValue;
   },

   
  
  gridPinfoWhenRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    metaData.tdCls ="xty_histgrid-when-cell  ";
    var timeRelatedValue = value;
    var time = value.substring(11,value.length-3);
    if (time.length<1){
     time = record.get('changetimeWork');
    }
    
    var datum =  '';
    
    //'cause_change_date": "2015-10-15T18:37:46",'
    if (timeRelatedValue.indexOf('2016')===0){
     timeRelatedValue = timeRelatedValue.replace(/T/,' ');
     timeRelatedValue = timeRelatedValue.replace(/-/g,'/');  
     datum =  timeRelatedValue.substring(0,10).replace(/(....)(\/)(..)(\/)(..)/,"$5.$3.$1");
    }
    else {
     datum  = timeRelatedValue.substring(0,10);
    }
    
     timeRelatedValue = timeRelatedValue.substring(0,10);// cuts time turns  "30.04.2014 13:28:00" >> "30.04.2014";
     var timeRelatedValueHtml = extVia.versionsProto.statics.timeRelatedDiffFromDate(timeRelatedValue);
     
    // timeRelatedValue=timeRelatedValue.replace(/\//g,'.');
     
     //record.set('timeRelatedValue' , timeRelatedValueHtml);
     
     
     timeRelatedValueHtml+='<div class="xty_histgrid-cell-subdscr">'+datum+' '+time+'</div>';
    
     return 'hat '+timeRelatedValueHtml;
    },
    
  gridPinfoWhatRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    metaData.tdCls ="xty_diffgrid-pinfo-dscr ";  
    return value;
  },
    
  gridPinfoWhatExpanderRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    metaData.tdCls ="xty_diffgrid-pinfo-dscr ";

    var html ='';
    var actionAreaDscr;
    var  pastDscr;
    var  action ;
    var detailsPanelHtml='';
    var actionTag ;
    var valueTag;
    var line1;  
    var line2; 
    
        var area = record.get('area');

        if (area){
	        var actionArea = record.get('actionArea');
	        if (!actionArea){
	         actionArea = extVia.module.epob.getActionAreaFromArea(area);
	        }
	        var isUPDATE =false;
	        action = record.get('baseAction');
	        if (!action){action ='UPDATE'; isUPDATE = true;}
	        var dataType = record.get('dataType');
	        var isDict =   (dataType.toLowerCase().indexOf('dictionary')>-1 );
	        if (isDict &&  isUPDATE){
	         actionArea  = extVia.enums.ActionAreas.MASTERDATA;
	        }
	        actionAreaDscr = actionArea.dscr;
	        pastDscr = extVia.enums.BaseActions[action].pastDscr;        
	         action = "Es wurden "+actionAreaDscr+" <br>"+pastDscr+". ";
            html =   value +'<div style="font-weight:normal" class="xty_histgrid-cell-susbdscr">'+action+'</div>'; 
        }
        else{
          
          var even = rowIndex %2===0 ;
          var even9 = rowIndex %9===0 ;
          var even19 = rowIndex %19===0 ;
          
          actionAreaDscr ='dies und das';
          actionAreaDscr = even ? 'Stammdaten' :'Attribute';
          pastDscr = even19?'gel�scht':  even9?'erstellt':  'ver�ndert';
          
          var objdepAction = record.get('objdepAction'); 

          
          var valFirst = false;
          var noAction = true;
          
          var detailsPanelExpander  ='';
          if (objdepAction){
             actionAreaDscr = '<span class="xty_objdepActionDscr" > '+extVia.historyProto.statics.getActionDscr(objdepAction, record)+'</span>';

            //detailsPanelExpander  = '<span class="xty_minitool-plus">&nbsp;&nbsp;&nbsp;&nbsp;</span>';
            
            //detailsPanelExpander  = '<span class="xty_vg-row-detail-expander-icon " style="flsoat:right;">&#160;</span>';
            
            var causeName = record.get('causeName');
            
            
            
            var detailsPanelId =  Ext.id('', 'histgrid-row-details-panel-'); //.replace(/ext-gen/,'');
            
            detailsPanelHtml = 
                '<div id="'+detailsPanelId+'" class="xty_histgrid-row-details-panel xty_collapsed">' +
	                '<div id="'+detailsPanelId+'-header" class="xty_histgrid-row-details-panel-header">'+

	                    '<span id="'+detailsPanelId+'-header-text" style="padding-left:6px;font-weight:normal;">' +causeName+'</span>' +
                        '<span id="'+detailsPanelId+'-header-arrow" class="xty_tree-end-minus xty_details-panel-header-toggler" style="padding-left:6px;font-weight:normal;cursor:pointer;">&nbsp;&nbsp;</span>' +
	                 '</div>'+ 
	                 '<div id="'+detailsPanelId+'-body" class="xty_histgrid-row-details-panel-body" style ="margin-left:12px; font-weight:normal;">' +
	                    '<a>FULL</a>&nbsp;&nbsp;&laquo;&nbsp;&nbsp;<a>BLOWN</a>&nbsp;&nbsp;&laquo;&nbsp;&nbsp;<a>DEPENDENCY</a>&nbsp;&nbsp;&laquo;&nbsp;&nbsp;<a>PATH</a> ' +
	                 '</div>' +
                 '</div>' ;



            
             action = 'Es wurden '+actionAreaDscr+' '+pastDscr+'. '+detailsPanelExpander;
             
             actionTag = noAction?'':'<div style="font-weight:normal;" class="xty_histgrid-cell-XXXX">'+action+'</div>';
             valueTag = '<div style="font-weight:bold;" class="xty_histgrid-cell-susbdscr">'+value+'</div>';

             line1 = valFirst ? valueTag : actionTag ;
             line2 = valFirst ? actionTag : valueTag ; 
             
             html =   line1 + line2 + detailsPanelHtml;
             
             
//             var depobjEpopType  = 'Elements'; //extVia.module.epob.getEpobKeyFromTypeId(value);
//             var epobIcon =  '<div title="'+depobjEpopType+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+depobjEpopType+'"> &nbsp;&nbsp;&nbsp;</div>'
//             html = epobIcon+html;
             
          }
          else{ // no objecDEP

             action = 'Es wurden '+actionAreaDscr+' '+pastDscr+'. ';
             actionTag = noAction?'':'<div style="font-weight:normal;" class="xty_histgrid-cell-XXXX">'+action+'</div>';
             
             valueTag = '<div style="font-weight:bold;" class="xty_histgrid-cell-susbdscr">'+value+'</div>';
             
             line1 = valFirst ? valueTag : actionTag ;
             line2 = valFirst ? actionTag : valueTag ; 
             
             html =   html =   line1 + line2 ;
          }

        }

        
      return  html;
    },     
         
    
    gridTimelineRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {   
      metaData.tdCls ="xty_grid-timeline-cell";
      
      var timeRelated = record.get('timeRelated'); 

      var isFirstOfTimeRelatedGroup = true; // should be set on backend record.get('isFirstOfGroup');
 
      if (view.lastTimeRelated){ // proto only done in frontend
        if ( timeRelated === view.lastTimeRelated){
          isFirstOfTimeRelatedGroup = false;
        }
      }
      view.lastTimeRelated = timeRelated;
      
      record.isFirstOfTimeRelatedGroup=isFirstOfTimeRelatedGroup;

      if(isFirstOfTimeRelatedGroup){  
        metaData.tdCls+=" xty_grid-groupstarts-timeline-cell";
      }

      var timeRelatedGroupHeaderHtml ='';      
      if(isFirstOfTimeRelatedGroup){  
        timeRelatedGroupHeaderHtml =
          '<div class="xty_timeRelated-group-header xty_timeRelated-group-starts" >'+
           '<div class="x-grid-group-title" >'+
            ' <a class="xty_grid-group-title-link" >'+timeRelated+'  <span class="xty_grid-group-title-items-count">(8 Aktivi&auml;ten)</span></a>'+
           '</div>'
        +'</div>' ;
      }
        
      
     return  timeRelatedGroupHeaderHtml;
      
    },
    
    gridCardRendererEmpty:  function ( value, metaData, record, rowIndex, colIndex, store, view )  { return value; },
    
    
    gridCardUserActionTimeRelatedTpl : new Ext.Template(extVia.locales.userActionTimeRelated), 
    
    gridCardRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {   
      metaData.tdCls ="xty_grid-card-cell";
      var timeRelated = record.get('timeRelated'); 
      var changedate = record.get('changedate');
      
      var isFirstOfTimeRelatedGroup = record.isFirstOfTimeRelatedGroup; //false; // should be set on backend record.get('isFirstOfGroup');
      
      var groupstartsHtml ='';  
      var groupstartsCls ='';  
      
      if(isFirstOfTimeRelatedGroup){  
        metaData.tdCls+=" xty_grid-groupstarts-card-cell";
        groupstartsCls ='xty_grid-groupstarts-card';    
        
        if (record.groupCollapsed===false){
          metaData.tdCls+=" xty_grid-collapsed-groupstarts-card-cell";  
        }
        groupstartsHtml ='<div class="xty_grid-groupstarts-before-card" >group starts</div>'; 
      }

      var dt = new Date(changedate);
      //var formattedDt = Ext.Date.format(dt, 'l d. F Y G:i')+' Uhr'; // -> Mittwoch 19. Oktober 2016 18:39 Uhr
      //var formattedDt = Ext.Date.format(dt, 'l d.m. G:i')+' Uhr';
      
      var datetime = Ext.Date.format(dt, 'l d.m. G:i')+' Uhr';
    
      var user = record.get('user'); 
      var userNames = user.split(' ');
      
      var initialen = '';
      if (user){  
        userNames = user.split(' ');
        initialen = userNames[0].substring(0,1);
        if (userNames[1]){
           initialen+=userNames[1].substring(0,1);
        }
      }

      var epobType = record.get('causeEpobType');
      var epobDscr = record.get('name'); // Was
      var newWert = record.get('newvalue');
      
      var oldValue = newWert.substring(1,newWert.length-2);

      // Action should be provided in BACKEND
      var actionKey = record.get('targetAction');
      if (!actionKey){
       actionKey = record.get('causeAction');
      }
      if (actionKey){
        if (actionKey.toLowerCase().indexOf('.upd_')>-1){actionKey='updated';}
        else if (actionKey.toLowerCase().indexOf('.ins_')>-1){actionKey='inserted';}
        else if (actionKey.toLowerCase().indexOf('.ass')>-1){actionKey='assigned';}
        else if (actionKey.toLowerCase().indexOf('.del_')>-1){actionKey='deleted';}
 
      }
      else{actionKey='updated';}
      var action = extVia.locales[actionKey];


      
 
//      var userRepr =     rowIndex%3===0  ? '<img class="xty_activity-thumbnail xty_activity-default-thumbnail" src="../img/epobs/user/User_32.png"   style="margin:3px;margin-top:0px;width:32px; height;32px;">' 
//                                 :'<span class="xty_activity-user-initialen" style="font-size:18pt; color:#888;">'+initialen+'</span>' ;     
//      if (rowIndex%5===0 ){
//        epobType='Image';
//        userRepr =  '<img class="xty_activity-thumbnail xty_activity-default-thumbnail" src="../img/epobs/content/image_32.png"   style="margin:3px;margin-top:0px;width:32px; height;32px;">' ;
//      }
                                 

      // langDscr + langISO should be provided by Backend 
      var langDscr = 'Deutsch'; 
      var langCls = 'xty_icon_de xty_icon_deu xty_icon_deu_DEU'; 
      
      var langId = record.get('langId');
      if(langId==='1'){
         langDscr = 'Deutsch'; 
         langCls = 'xty_icon_de xty_icon_deu xty_icon_deu_DEU'; 
      }
      else if(langId==='3'){
         langDscr = 'Englisch'; 
         langCls = 'xty_icon_en xty_icon_eng xty_icon_eng_GBR'; 
      }
      else if(langId==='4'){
         langDscr = 'Franz&ouml;sisch'; 
         langCls = 'xty_icon_fr  xty_icon_fra xty_icon_fra_FRA';  
      }      
       
      var objecDepLine = '';
      
      
      var doObjecDep = false;
      if (epobType.indexOf('Related')>-1 || epobType.indexOf('Reference')>-1 || epobType.indexOf('Assignment')>-1){
        doObjecDep = true;
//	      objecDepLine = 
//          '<div> &raquo; <span title="" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epobAttribute "> &nbsp;&nbsp;&nbsp;'+'</span>'+
//	       '<span class="xty_card-epobDscr" >Attribut: Sandrieselgeschwindigkeit</span></div>' 
//          // +  '<span class="xty_card-action"> '+action+'</span>' 
          
      }
      
      
      var epobTypeId;
      var epobTypeDscr =  epobType;
      var epobTypeDscrPronom = extVia.locales.epobPronomNeutral; 
      var epob;
      
      
  
      
      if (epobType && extVia.locales.uiLangIso==='de'){
       epob = extVia.enums.EpimObjects[epobType.toUpperCase()];
       if (!epob){
         epob = extVia.enums.EpimObjects['PRAT_'+epobType.toUpperCase()];
       }
       if (epob){
         epobTypeId = epob.id;
         epobTypeDscr = extVia.module.epob.getEpobTypeDscrFromTypeId(epobTypeId, "S") ;  // extVia.enums.EpimObjects.DICTIONARYCATEGORY=
         if (epob.male){
          epobTypeDscrPronom = extVia.locales.epobPronomAkkMale;
         }
         else if (epob.female){
          epobTypeDscrPronom = extVia.locales.epobPronomFemale;
         }
       }
       //else{alert( 'gridCardRenderer else  '+epobType)}
      }


      
       epobTypeDscr = epobTypeDscrPronom+' ' + epobTypeDscr;
      
      //var epobTypeId = extVia.enums.EpimObjects[epobType.toUpperCase()].id;
      //var epobTypeDscr   = extVia.module.epob.getEpobTypeDscrFromTypeId(epobTypeId, "S") ;  // extVia.enums.EpimObjects.DICTIONARYCATEGORY=
      
    
             
      var userActionTimeRelatedHtmlCfg = {
           user:         '<span class="xty_card-user"> '+user+'</span>' ,
           timeRelated:  '<span class="xty_card-timeRelated">'+timeRelated+'</span>' ,
           epobTypeDscr: '<span class="xty_card-epobType-dscr"> '+epobTypeDscr+'</span>' ,
           epobDscr: '<br><span class="xty_card-epob-dscr">'+epobDscr+'</span>' ,
           action: ' <span class="xty_card-action">'+action+'</span>'
      };  
       
      var userActionTimeRelatedHtml =  extVia.historyProto.statics.gridCardUserActionTimeRelatedTpl.applyTemplate(userActionTimeRelatedHtmlCfg);

      
      //alert('gridCardRenderer record.isFirstOfTimeRelatedGroup '+record.isFirstOfTimeRelatedGroup);

      
//      if (view.lastTimeRelated){ // proto only done in frontend
//        if ( timeRelated === view.lastTimeRelated){
//          isFirstOfTimeRelatedGroup = false;
//        }
//      }
//      view.lastTimeRelated = timeRelated
      
      
      
      

      
      
      var eyecatchSize = 42;

      var activityCard =

       // groupstartsHtml+ 
        
      '<div class="xty_grid-card-bin"  >' +
        
     
        
      '<div class="xty_grid-card xty_activity-card '+groupstartsCls+'" >' +
        
        '<div class="xty_card-header">'+

	      '<div class="xty_card-eyecatcher"  style="border:1px solid #ccc; border-radius:'+(eyecatchSize/2)+'px; min-width:'+eyecatchSize+'px; width:'+eyecatchSize+'px; height:'+eyecatchSize+'px; min-height:'+eyecatchSize+'px;overflow:hidden;display: table-cell; position: absolute; margin-left:-4px; text-align:center; padding-left:0px; padding-top:3px;" >' +
           '<img class="xty_eyecatcher-icon xty_epob'+epobType+'" src="../img/icons/spacer.gif"  style="mxargin:3px;mxargin-top:0px;width:32px; height;32px;">'+
          '</div>' +
          
	      
          
          '<div class="xty_card-primary-header"  style="margin-left:50px;  white-space: normal;">' +
        
        
          userActionTimeRelatedHtml+
          
//            '<span class="xty_card-user"> '+user+'</span>' +
//            ' hat <span class="xty_card-timeRelated"  >'+timeRelated+'</span>' +
//            '<span class="xty_card-epobType-dscr"  > '+epobTypeDscr+'</span>' +
//            '<br>' +
//            //'<br>' + 
//           ' <span class="xty_card-epob-dscr" style="">'+epobDscr+'</span>' +
//           ' <span class="xty_card-action"> '+action+'.</span>' +
           
           
          '</div>' + // eo primary header
          
          
          
          
          
          
          '<div class="xty_card-secondary-header"  style="margin-left:50px; ">' +
           ((doObjecDep)?
           '<div class="xty_related-epob" >' +
            '<span title="" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epobMetadata "> &nbsp;</span>'+
            '<span class="xty_card-rel-epobDscr" >&nbsp;&nbsp;Attribut: Sandrieselgeschwindigkeit</span>' +
           '</div>'
           :'')+
          
          '</div>' + // eo secondary header
        '</div>'+  // eo card header
        '<div class="xty_card-body"  style="margin-left:50px;">'+    

//          ((doObjecDep)?
//           '<div class="xty_related-epob">' +
//            '<span title="" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epobAttribute "> &nbsp;&nbsp;&nbsp;'+'</span>'+
//            '<span class="xty_card-epobDscr" >Attribut: Sandrieselgeschwindigkeit</span>' +
//           '</div>'
//           :'')+
           
          '<div title="'+langDscr+'" style="marsgin-left:50px;min-width:18px; margin-top:10px; position:absolute;" class="xty_card-language '+langCls+'"> &nbsp;&nbsp;&nbsp;</div>'+
           
           '<div class="xty_card-newvalue" style="padding-top:6px; padding-left:26px;  font-stylee:italic;"> '+ newWert+'</div>' +
           '<div class="xty_card-oldvalue" style="padding-left:26px;  padding-top:4px; font-stylee:italic; text-decoration:line-through; color: #888;">'+oldValue+'</div>' +

         '</div>'+  // eo card body
        
         
          '<div class="xty_card-footer"  style="margin-left:50px;">'+    
           '<div class="xty_card-datetime" style="padding-top:4px; color: #adadad;"> '+datetime+'</div>' +
          '</div>'  // eo card footer

      +'</div>' // eo card
      
      +'</div>'; // eo card-bin
      
      
      var html = activityCard;
        
      return html;
    },
    
    
    
    gridDatatypeColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {   
           metaData.tdCls ="xty_lockedColumnFake-left ";
      var epobType = value;
      return '<div title="'+epobType+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+epobType+'"> &nbsp;&nbsp;&nbsp;'+'</div>';
    },
    
    gridDatatypeIdColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
      var epobType  = extVia.module.epob.getEpobKeyFromTypeId(value);
      return '<div title="'+epobType+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+epobType+'"> &nbsp;&nbsp;&nbsp;'+'</div>';
    },   
    
    gridObjdepPropDatatypeIdColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
      
      var objdepAction = record.get('objdepAction'); 
      if (objdepAction && objdepAction.length>0 ){
        var epobTypeId =   record.get('targetEpobType'); 
      }
      var epobType  = extVia.module.epob.getEpobKeyFromTypeId(value);
      return '<div title="'+epobType+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+epobType+'"> &nbsp;&nbsp;&nbsp;'+'</div>';
    }, 
    
    gridLanguageColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {    
      //metaData.tdCls ="xty_lockedColumnFake ";
      var langDscr = 'deutsch';
      var langCls = 'xty_flag-DEU';
      return '<div title="'+langDscr+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="'+langCls+'"> &nbsp;&nbsp;&nbsp;'+value+'</div>';
    },

    infoItemContextmenuCount : 0,
    getInfoItemContextmenuHandler : function(cfg , epob){

      
         var cardView2 = extVia.historyProto.statics.infoItemContextmenuCount%2===0;
         extVia.historyProto.statics.infoItemContextmenuCount++;
      
      
       var infoItemContextmenuHandler =  function( view, record, item, index, evt, eOpts ){
        

              var isCauseColumn = true; 
              
              // Better user  up 'xty_diffgrid-pinfo-dscr' 
              var targCls = evt.target.className;
              var targOwnerCls = evt.target.parentNode.className;
              var targOwnerOwnerCls = evt.target.parentNode.parentNode.className;
              var targOwnerOwnerOwnerCls = evt.target.parentNode.parentNode.parentNode.className;
              if (targCls.indexOf('xty_diffgrid-pinfo-dscr')>-1 || 
                  targOwnerCls.indexOf('xty_diffgrid-pinfo-dscr')>-1 || 
                  targOwnerOwnerCls.indexOf('xty_diffgrid-pinfo-dscr')>-1 ||
                  targOwnerOwnerOwnerCls.indexOf('xty_diffgrid-pinfo-dscr')>-1 ){
                  isCauseColumn = false;
              }
        
        
              var dateStr = record.get('changedate');
              dateStr = ' <i>'+ dateStr.replace(/(....)(-)(..)(-)(..)(T)(.*)/,'$5.$3.$1 $7 ') +'  </i>';
               
        
              evt.preventDefault();
              var infoItem = {
                dscr:record.get('name'),                      
                infoId :  record.get('infoId')
               };
               var widthy =580;
               
               widthy = 380;
               
               var histgridMenu = Ext.create('Ext.menu.Menu', {
                    width:widthy,
                    //modal:true,
                    margin: '0 0 10 0',
                    defaults:{
                         myGridView :view,

                          listeners: {
                              afterrender: function(panel) {
                                panel.header.el.on('click', function() {
                                  if (panel.collapsed) { panel.expand();}
                                  else {panel.collapse();}                      
                                });
                              }
                           } 
                         
                         
                        },
                    items: [
                    
	                    { title: ' <i>' +record.get('name')+ '</i>&nbsp;&nbsp;in '+ epob.dscr, 
	                     layout:'accordion', xtype:'panel', height:300, width:widthy,text:'sagv',
	                     items:[
	                      extVia.historyProto.statics.getInfoHistoryListCfg({width:widthy, height:800},infoItem, epob),
	                       {title:'&nbsp;&nbsp;&nbsp;&nbsp;Auswirkungen', height:600,
                           html: '<img  style="" src="../img/fakes/versioning/causeAndEffects.png"/>' // http://www.graphdracula.net/showcase/ 
                           //html: '<img  style="" src="../img/fakes/history/historyTabCardViewEast_09.png"/>' 

                           }
	                     ]
	                    },
                      
                       extVia.historyProto.statics.getInfoHistoryListCfg({width:widthy, height:320, collapsible:true, hidden: cardView2, collapsed: isCauseColumn},infoItem, epob),
                    
                       {  xtype:'panel', titsle:'&nbsp;Aktivit&auml;ten ', 
                         
                         title:"Aktivit&auml;ten auf<i>&nbsp;&nbsp;"+infoItem.dscr, //+"&nbsp;&nbsp;</i> in <i>&nbsp;&nbsp;"+epob.dscr+"&nbsp;&nbsp;</i> ",
                         height:520,width:widthy, hidden: !cardView2, collapsed: !isCauseColumn,
                           
                           items:[
                          // {border:false,html: '<div class="xty_epob'+record.get('causeEpobType')+'" style="padding-left:18px;font-size:11px;">'+record.get('newvalue')+'&nbsp;&nbsp;&laquo;&nbsp;&raquo;&nbsp;&nbsp;<span style="text-decoration:line-through;">'+record.get('oldvalue')+'</span><span style="color:#888">&nbsp;&nbsp;'+record.get('changedate')+'</span></div>'}
                           ],
                           autoScroll:true,
                           html: '<img  style="" src="../img/fakes/history/historyTabCardViewEast_09.png"/>' // http://www.graphdracula.net/showcase/
                           }

                    
                        //
                        ]
                  });
                  view.menu = histgridMenu;
    
                 
                view.menu.infoItem = infoItem;
                var posArr = evt.getXY();
                posArr[0]+=80;
                posArr[1]-=60;
                view.menu.showAt(posArr);
            };  
            
            return infoItemContextmenuHandler;
    },
    
   getHistoryRowDialogButtonCfg : function(cfg, epob){

    
    var buttonHandler = function(btn, evt){
      
     if (evt.hasModifier()){
      Ext.getBody().addCls('xty_show-card-layout');
      Ext.getCmp('historyGrid-'+epob.epobId).showFieldsSpec.delay(50);
     }
     else{
      var historyRowDialog  = Ext.create('Ext.window.Window', extVia.historyProto.statics.getHistoryRowDialogCfg(cfg, epob)); 
      //historyRowDialog.showAt(extVia.regApp.myRaster.getCenter().getWidth()-600, 40);
      historyRowDialog.showAt(extVia.regApp.myRaster.getCenter().getEl().getRight()-historyRowDialog.width-20, 40);
      Ext.getBody().removeCls('xty_show-card-layout');
     }

    };
    //historyRowDialog.showAt(extVia.regApp.myRaster.getCenter().getWidth()-300, 40);
    return  {tooltip:'add history row', iconCls:'xty_pgtoolbar-addItem xty_pgtoolbar-add-history-row', handler:buttonHandler};
   },

    
   getComboCfg : function(cfg){
    
     var data = [];
     var i;
     for (i = 0; cfg.values && i < cfg.values.length; i++){
      data.push({ "dscr": cfg.values[i] , "value" :cfg.values[i] });
     }
      var store; 
      if (cfg.store){
        store = cfg.store;
      }
      else{
       store = Ext.create('Ext.data.Store', {
          fields:[{name:'dscr' }, {name:'value'}],
          data: data
       });  
      }
      
      
      
      var comboCfg =  {
       xtype:'combo', 
       store: store,
       queryMode: 'local',
       displayField: cfg.displayField?cfg.displayField:'dscr',
       valueField: cfg.valueField?cfg.valueField:'value',
       allowBlank: cfg.allowBlank===false?false:true,
       value: cfg.value,
       name: cfg.name,
       //itemId: cfg.name,
       hidden: cfg.hidden,
       disabled: cfg.disabled,
       listeners: cfg.listeners,
       listConfig: cfg.listConfig
       };
     return comboCfg;
   },
   
   
   getHistoryRowDialogCfg : function(cfg, epob){
         
        var getComboCfg = extVia.historyProto.statics.getComboCfg;
    
        var timedId = new Date().getTime().toString();
        timedId = 'k-'+timedId.substring(5,timedId.length);
        
        var causeId = new Date().getTime().toString();
        causeId = 'c-'+causeId.substring(5,causeId.length);
        
        

        
        // analog to to extVia.historyProto.statics.historyFields,
        var historyFormFields  =  [
                  {name:"key_target_id" , value: epob.epobId, xtype:'displayfield', hidden: true },
                  //{name:"key_epob_type_Id", value: epob.epobTypeId ,xtype:'displayfield' },
                  {name:"key_hjob_id" , value: timedId , xtype:'displayfield'},
                  
                  getComboCfg({name:"key_type", value:'target', values:["cause", "target", "objedep" ],
                  
                  listeners:{ 
                   change: function(field) { 
                    var showOrHide = field.value==='objedep'   ?'show':'hide';
                    field.ownerCt.getComponent('objedep_target_id')[showOrHide]();
                    field.ownerCt.getComponent('objedep_epob_type_id')[showOrHide]();
                    field.ownerCt.getComponent('objedep_actionkey')[showOrHide](); 
                   }
                  }
                  
                  }),
                  //{name:"key_clie_id"},
                  //{name:"key_lang_id"},
                  
                  { value: '<b>Cause</b>', xtype:'displayfield' },
                  {name:"cause_epimId",  value: Ext.id(null,'') ,  cls:'xty_codefield'},
                  
                  //{name:"cause_epim_module"},

                  //{name:"cause_hjob_comment"},
                  //{name:"cause_data_id"},

                  
                  getComboCfg({name:"action", value:'ge�ndert', allowBlank:false, 
                     store: extVia.stores.getActionTypesStore({forbidBlank:true}),
                     listConfig:{
                       itemTpl : '<span class="xty_boundlist-item-dscr">{dscr}</span><span class="xty_boundlist-item-hits">&nbsp; ({value})</span>' 
                     },
                    
                    
                    
                    listeners:{
                     change:function(combo, newValue){
                      var cause_actionkey = combo.ownerCt.getComponent('cause_actionkey');
                      cause_actionkey.setValue('*.'+newValue+'_*');
                     }
                    } 
                   
                   }),
                  
                  

                  
                  {name:"cause_actionkey",  itemId:"cause_actionkey", value:'*.upd_*'},
  

                  
                  getComboCfg({name:"cause_change_user", allowBlank:false, store: extVia.stores.initUserStore({forbidBlank:true}), value:'Simon Lederer', displayField: 'name',   valueField: 'name'}),
                  {name:"cause_change_user_id"},

                  
                  {  xtype: 'hiddenfield', name: 'timeRelated'},
                  getComboCfg({name:"timeRelatedDscr", value:'jetzt', valueField:'timespan', store: extVia.stores.getTimeRelatedStore(),
                  
	                  listeners:{
	                   change:function(combo){ 
	                    
	                    // 
	                    var aDay = 1000*60*60*24;
	                    var aWeek = 1000*60*60*24*7;
	                    var aMonth = 1000*60*60*24*30.5;
	                    var aYear = 1000*60*60*24*365;
	                    
	
	                    var value = combo.getValue();
	                    var now = new Date().getTime();
	                    
	                    var dateInPast = now;
	                    
	 
	                    try{ dateInPast = now - parseInt(value, 10);}
	                    catch(minEx){extVia.notify(minEx);}
	
	                    
	                   var newDateInpAstDate  =  new Date(dateInPast);
	                   // var newChangeDate = now;
	                        
	                    var changeDate = combo.ownerCt.getComponent('cause_change_date');
	                    var newDtay =  Ext.Date.format(new Date(dateInPast), changeDate.format);
	                    
	                    changeDate.setValue(newDtay);
	 
	                    combo.ownerCt.getComponent('timeRelated').setValue(combo.getRawValue());
	                   // combo.setValue(combo.getRawValue())
	                    
	                   }
	                  }
                  
                  }),
                  
                  
                  
                  getComboCfg({name:"cause_data_epob_type", allowBlank:false, store:  extVia.stores.getHistoryEpobTypesStore(), 
                        listConfig : {
			             minWidth:180,
			             //cls:'x-menu  xty_boundlist-floating-offset', // if not x-menu a boundlist-select closes the whole menu>panel>combo>boundlist :(
			             getInnerTpl : function(displayField) {
			               var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '{epobType}</span></div>';
			               return tpl;
			             }
			           } 
                  }),
                  //{name:"cause_epob_type_Id"},
                  {name:"cause_data_name", allowBlank:false, value:'aThingWithNoName'},
                  getComboCfg({name:"cause_data_lang_id", store: extVia.stores.initLanguageStore(),   valueField: 'id',   value:'deutsch',
                    listConfig:{itemTpl : '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>'}
                  }),
                  {name:"cause_data_newvalue",  value:'newval'},
                  {name:"cause_data_oldvalue", value:'oldval'},

                  
                  {name:"cause_change_date" , allowBlank:false, itemId:"cause_change_date" , xtype:'datefield', format:'Y-m-d\\TH:i:s', foormat: "d.m.Y", fooarmat: "d.m.Y h:i:s",
                   listeners:{
                     change:function(datefield, newValue){ 

                      var timeRelated = extVia.historyProto.statics.timeRelatedRenderer( datefield.getRawValue());

                      datefield.ownerCt.getComponent('timeRelated').setValue(timeRelated);
                      datefield.ownerCt.getComponent('timeRelatedDscr').setRawValue(timeRelated);
                     
                     }
                   }
                  },
                  {name:"cause_change_time" , itemId:"cause_change_time" , xtype:'timefield', formsat: "d.m.Y h:i:s"},

                  

                  //{name:"cause_hist_msg"},

                  { value: '<b>Target</b>', xtype:'displayfield' },
                  {name:"target_id", value: epob.epobId },
                  {name:"target_epob_type_id", value: epob.epobTypeId},
                  { value: '<b>Target datafield</b>', xtype:'displayfield' },
                  {name:"target_data_id", value: 'same as cause',disabled:true},
                  {name:"target_data_epob_type", value: 'same as cause',disabled:true},
                  {name:"target_data_name", value: 'same as cause',disabled:true},
                  {name:"target_data_newvalue", value: 'same as cause',disabled:true},
                  {name:"target_actionkey", disabled:true},
                  //{name:"target_hist_msg"},
  
                    
                  { name: '<b>Object Dependency</b>', xtype:'checkbox', handler: function(field) { 
                    var showOrHide = field.checked?'show':'hide';
                    
                    var key_type = field.ownerCt.getComponent('key_type');
                    key_type.setValue(  field.checked? 'objedep' :'target'  );
  
                    field.ownerCt.getComponent('objedep_target_id')[showOrHide]();
                    field.ownerCt.getComponent('objedep_epob_type_id')[showOrHide]();
                    field.ownerCt.getComponent('objedep_actionkey')[showOrHide]();
                  } 
                  },
                  {name:"objedep_target_id",hidden:true},
                  {name:"objedep_epob_type_id",hidden:true},
                  getComboCfg({name:"objedep_actionkey", listWidth:200, hidden:true,
                   values:[
					    'GPV_UPD_GPV_ASSIGNMENT_DIRECT_DIRECT' ,  // Productrelations     Produktbeziehungen // Zubeh�r
					    'GPV_UPD_GPV_ASSIGNMENT_DIRECT_INHERITED' , // Productrelations
					    'GPV_UPD_GPV_ASSIGNMENT_CHILD_DIRECT' ,  // Productrelations   Kinder von Produktbeziehungen 
					    'GPV_UPD_GPV_ASSIGNMENT_CHILD_INHERITED' , // Productrelations
					    'GPV_UPD_GPV_SORTIMENT_1' ,  // Back-referenz
					    'GPV_UPD_GPV_SORTIMENT_N' ,  // Back-referenz
					    'GPV_UPD_GPV_REFERENCE_1' ,
					    'GPV_UPD_GPV_REFERENCE_N' ,
					    'GPV_UPD_GPV_PARENT_1' , // Elternobjekte
					    'GPV_UPD_GPV_PARENT_N' , //
					    'GPV_UPD_GPV_CHILD_1' ,  // Kindobjekte Produkte 
					    'GPV_UPD_GPV_CHILD_N' 
                  ]
                  })
                  //,{name:"objedep_hist_msg"}
                  
                  
                  // NEW Fields 
                 // ,{name:"objedep_targetProperty_epobTypeId"} // same as ?target_data_epob_type?
                 // ,{name:"objedep_targetProperty_id"}
                 // ,{name:"objedep_targetProperty_name"}  // ?target_data_name?
                  
                  
                  //,{name:"whatDscr"}  


                  ];

    
    var i;
    for (i = 0;  i < historyFormFields.length; i++){
     var field = historyFormFields[i];
      field.itemId = field.name;
      field.fieldLabel = field.name;  
      
      
      if (field.allowBlank ===false){
      
      field.labelSeparator =extVia.editor.baseEditor.statics.getLabelSeparator4Required();
      }
      
//      for (var fi = 0; fi< extVia.historyProto.statics.historyFields.length; fi++ ){
//        var historyField = extVia.historyProto.statics.historyFields[fi];
//        if (historyField.mapping === field.name){
//         if(!Ext.isEmpty(historyField.name)){
//          field.name = historyField.name;
//         }
//        }
//      }
      
      
      

      
      
      
    }
  
    var historyRowDialogCfg =     {
    title: 'Historyrow  &raquo '+epob.dscr,
    
    height: extVia.regApp.myRaster.getCenter().getHeight()+30,
    width: 600,
    autoScroll:true,
    bodyStyle:'background-color:white;',
    
    
    renderFormJSON:function(){
      var win  = Ext.getCmp(this.id);
      var jsonFieldBin = win.getComponent('jsonField-bin');
      jsonFieldBin.renderForm();
    },
    
    
    addFormRow:function(){
      var win  = Ext.getCmp(this.id);
      
      var formPan = win.getComponent('formPanel');
      var form = formPan.getForm();

      var editorTab =  extVia.regApp.myRaster.getCenterTabPanel();
      var editorSubTabsPanel = editorTab.getActiveTab().getComponent("editorSubTabsPanel"); 

      var historyTab = editorSubTabsPanel.getComponent("history"); 
      var historyGrid = historyTab.getComponent("historyGrid"); 
 
      var formValues = form.getValues(); 
      var fi;
      for (fi = 0; fi< extVia.historyProto.statics.historyFields.length; fi++ ){
        var historyField = extVia.historyProto.statics.historyFields[fi];
        if (formValues[historyField.mapping]){
          formValues[historyField.name] = formValues[historyField.mapping];
        }
      }
      
      //Ext.encode(formValues).replace(/"name:"/g, '"mapping:"');
      // formValues = Ext.decode(formValues);
      
      
      var isValid =  form.isValid();
      if (isValid){
       historyGrid.getStore().add(formValues);
//      var  historyEntry = Ext.create('historyEntry', formValues);
//      historyGrid.getStore().add(historyEntry);
      }
      else{
       extVia.notify('Da fehlt nochwas');
      }
      

      

      
    },
    
    
    
    items: [
    
    
    //{xtype:'panel' , itemId:'jsonPanel', name:'jsonPanel',  resizable:true, margin:'4 4 10 4', width: 580, height:70, html:'acdc'},
    
    
      {xtype:'fieldcontainer', itemId:'jsonField-bin',  margin:'4 4 10 4', width: 566, height:70,
               renderForm: function(){
                       var fieldcontainer = Ext.getCmp(this.id);
                       var jsonField = fieldcontainer.getComponent('jsonField');
                       jsonField.renderForm();
               },
              layout:'hbox', 
              
              items:[
    
                {xtype: 'textarea', cls:'xty_codefield', trigger1Cls:'x-form-trigger',  itemId:'jsonField', name:'jsonField', emptyText:'row JSON' ,  width: 526, height:70,

                    renderForm: function(){
                       var field = Ext.getCmp(this.id);
                       var formPan = field.ownerCt.ownerCt.getComponent('formPanel');
                       
                       var form = formPan.getForm();
                       
                       form.isValid();
                       
                       field.setValue(Ext.encode(form.getValues()).replace(/","/g, '", "') );

//                    //>>>    JSON highlight Start    <<<
//					// copied from   http://stackoverflow.com/questions/4810841/how-can-i-pretty-print-json-using-javascript
//					// http://jsfiddle.net/KJQ9K/554/ 
//					                       
//						function syntaxHighlight(json) {
//						    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
//						    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
//						        var cls = 'number';
//						        if (/^"/.test(match)) {
//						            if (/:$/.test(match)) {
//						                cls = 'key';
//						            } else {
//						                cls = 'string';
//						            }
//						        } else if (/true|false/.test(match)) {
//						            cls = 'boolean';
//						        } else if (/null/.test(match)) {
//						            cls = 'null';
//						        }
//						        return '<span class="' + cls + '">' + match + '</span>';
//						    });
//						}
//						//var obj = {a:1, 'b':'foo', c:[false,'false',null, 'null', {d:{e:1.3e5,f:'1.3e5'}}]};
//						var jsonStr = JSON.stringify(form.getValues(), undefined, 4);
//						var jsonPanel = field.ownerCt.getComponent('jsonPanel');                     
//						jsonPanel.getEl().dom.innerHTML =   syntaxHighlight(jsonStr) ;    
//                    //>>>    JSON highlight End    <<<             
                       
                       
                       
                       
                    },
                    listeners:{
                      afterrender:function(field){
                        //field.renderForm(field);
                        field.getEl().on('click', field.renderForm);
                      }
                    }
                  
                  }
                  
                  
                    ,{ xtype: 'buttongroup',  height:70, columns:1,margin:'0 0 0 2',items:[  
                    { xtype: 'button', tooltip:'render Form JSON',
                      itemId:'run', iconCls:'xty_formbutton-start' , margin:'0 0 0 2',
                      handler:function(button){
                       button.ownerCt.ownerCt.getComponent('jsonField').renderForm();
                       }
                     }, 
                     
                    { xtype: 'button', tooltip:'clear',
                      itemId:'clear', iconCls:'xty_formbutton-backspace' , margin:'0 0 0 2',
                      handler:function(button){
                       button.ownerCt.ownerCt.getComponent('jsonField').reset();
                      }
                     }
                   ]}
                  
                  ]} ,
    
    
    
    
     {xtype:'form',border:false,
       itemId:'formPanel',
       cls:'halleluja',
       autoScroll:true,
       margin:'4 4 4 4',
       defaults:{
        xtype:'textfield',
        width:500,
        labelWidth:200
       },
     items:historyFormFields
    }
    ],
    buttons:[
     {text:'add history entry',
     handler:function(button){
      var win = button.ownerCt.ownerCt;
      win.renderFormJSON();
      
      win.addFormRow();
      
//      var formPan = win.getComponent('formPanel');
//      var form = formPan.getForm();
//
//      var editorTab =  extVia.regApp.myRaster.getCenterTabPanel();
//      var editorSubTabsPanel = editorTab.getActiveTab().getComponent("editorSubTabsPanel"); 
//
//      var historyTab = editorSubTabsPanel.getComponent("history"); 
//      var historyGrid = historyTab.getComponent("historyGrid"); 
//
//      
//      historyGrid.getStore().add(form.getValues())

      //extVia.notify('<textarea style="width:600px;height:200px;">'+ Ext.encode(form.getValues())  + '</textarea>' );  

     }
    }]
    };
    return historyRowDialogCfg;
   }, 

   showFilterPanelON: false,
   
   
   showFilterPanel: function(button){
  
    var     historyFilterPanelCfId = 'historyFilterPanel_1';
    
   var  historyFilterPanel = Ext.getCmp(historyFilterPanelCfId);
   
   if (!historyFilterPanel){
   
    var historyFilterPanelCfg =  extVia.historyProto.statics.getHistoryFilterPanelCfg(); 
    historyFilterPanelCfg.style='position:absolute;z-index:1999;';
    historyFilterPanelCfg.renderTo= Ext.getBody();
    historyFilterPanelCfg.border = true;
    
    
    //var x = 798, y = 166; // @ button
    var x = 808, y = 238; // @ tab
    
    x = 420; // genau dr�ber
    
    //x =  extVia.regApp.myRaster.getCenter().getWidth()-100;
    
    //x=542;
    //x = button.getPosition()[0]-410;
    
    historyFilterPanelCfg.x = x;
    historyFilterPanelCfg.y = y;
    historyFilterPanelCfg.id = historyFilterPanelCfId;
    
    historyFilterPanelCfg.draggable=true;
    
    // bodyPadding: 5,  // Don't want content to crunch against the borders

    //
    
    
    var fakePanel = false;
    
    
    if (fakePanel){
        historyFilterPanelCfg.width=1000;
	    historyFilterPanelCfg.x-=41;
	    historyFilterPanelCfg.height=106;
	    historyFilterPanelCfg.items = null;
	    historyFilterPanelCfg.html= '<img  style="margin-left:32px;" src="../img/fakes/history/historyFilterForm_2columns.png"/>';
	    historyFilterPanel = Ext.create('Ext.panel.Panel',historyFilterPanelCfg );
    }
    else{
     historyFilterPanel = Ext.create('Ext.panel.Panel',historyFilterPanelCfg );
    }
    


    
   }
    
   if (extVia.historyProto.statics.showFilterPanelON){
      historyFilterPanel.hide();
      extVia.historyProto.statics.showFilterPanelON = false;
   }
   else{
      historyFilterPanel.show();
      extVia.historyProto.statics.showFilterPanelON = true;
   }
	
//   var filterWin = Ext.create('Ext.window.Window', {
//	    //title: 'Aktivit&auml;ten filtern',
//	    //height: 200,
//	    //width: 400,
//	    //layout: 'fit',
//    
//        //headerPosition : 'off',
//	    items: historyFilterPanelCfg
//	});
//  
//    filterWin.showAt(800,60);
   
   

    //filterPanel.show();
    
   },

   
   getHistoryFilterPanelCfg: function(cfg){ 
 
//    var epobTypeComboCfg = {
//          xtype:'combo',
//          fieldLsabel : "Typ",  
//          itemId:'epobTypes',
//          width: 1,
//          name:'type',
//          cls:'xty_eyecatch-btn-boundlist-combo',
//          emptyText: 'Objekte',
//          queryMode: 'local', displayField: 'dscr',  valueField: 'value',   
//          // multiSelect:true,
//          store:  extVia.stores.getHistoryEpobTypesStore(),
//           
//          listConfig : {
//             minWidth:180,
//             //cls:'x-menu  xty_boundlist-floating-offset', // if not x-menu a boundlist-select closes the whole menu>panel>combo>boundlist :(
//             getInnerTpl : function(displayField) {
//               var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}">' +
//                   '<span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '{epobType}</span>' +
//                   '<span class="xty_boundlist-item-hits" style="">' + '&nbsp; ({hits}' + 'hits Z)</span>' +
//                  '</div>';
//               return tpl;
//             }
//           } 
//       };

       
      var historyFilterPanelCloseHandler  = function(event, toolEl, panel){
        panel.ownerCt.ownerCt.hide();
      }; 
       

      
      var clearTriggerHandler = function(evt){

        var targetEl = Ext.get(evt.target.id); 
       var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
        var field = Ext.getCmp(fieldId);
        if (field.isDirty()){
          field.reset();
        }
      };
      
      
      var formClearInside =  false;
      
      
      
      
      var timeRelatedComboCfg= {
        xtype:'combo', hidaeEmptyLabel:false, itemId : "timeRelated", width:140, margin:'0 0 0 0',
        emptyText: extVia.locales.today,
        queryMode: 'local', displayField: 'dscr',  valueField: 'dscr',   
          cls:'xty_has-insidetrigger ',   
          trigger1Cls:'xty_inside-trigger-clear' , onTrigger1Click:clearTriggerHandler,
          trigger2Cls:'x-form-trigger',
          store: extVia.stores.getTimeRelatedStore(),
          listConfig:{
            itemTpl : '<span class="xty_boundlist-item-dscr">{dscr}</span><span class="xty_boundlist-item-hits">&nbsp; ({hits})</span>' 
          }
       };
       
       
      var actionTypeComboCfg =  {
         xtype:'combo', hidaeEmptyLabel:false,   itemId : "actiontype" , width:140,  margin:'0 0 0 0',
          emptyText: extVia.locales.updated,
          queryMode: 'local', displayField: 'dscr',  valueField: 'value',   
          cls:'xty_has-insidetrigger ',   
          trigger1Cls:'xty_inside-trigger-clear' , onTrigger1Click:clearTriggerHandler,
          trigger2Cls:'x-form-trigger',
          store: extVia.stores.getActionTypesStore(),
           listConfig:{
                itemTpl : '<span class="xty_boundlist-item-dscr">{dscr}</span><span class="xty_boundlist-item-hits">&nbsp; ({hits})</span>' 
           }    
      };
      
      
      var middleOfSentenceComboCfg = actionTypeComboCfg;
      var endOfSentenceComboCfg = timeRelatedComboCfg;

      if (extVia.locales.uiLangIso==='de'){
        middleOfSentenceComboCfg = timeRelatedComboCfg;
        endOfSentenceComboCfg = actionTypeComboCfg;
      }
      
      endOfSentenceComboCfg.width=257;
      
      
      var historyFilterPanelCfg =  {
             xtype:'form',

             //title:'Historie filtern',
             tools:[
                //{id:'minus', handler:function(event, toolEl, panel){panel.collapse();}},
                {id:'close', handler: historyFilterPanelCloseHandler}],
             //preventsHeader:true,
             

             //draggable:true,
             
             collapsible:true,
             //border:false,
             layout : 'vbox',
             defaults:{margin:'0 0 2 0', width:426, hideEmptyLabel: false, labelWidth:72},
             width : 440,
             
             //height :274 -(formClearInside? 30:0),
             height :294,
             
             cls:'xty_filterPanel xty_history-filter-panel xty_has-merged-hd',
             itemId:'filterPanel',
             setTimeRelatedValue:function(value){
               var timeRelatedCombo = this.getComponent('whatWhoAndWhen-bin1').getComponent('timeRelated');
               timeRelatedCombo.setValue(value);
             },
             
             items : [ 
                   
                  {xtype:'tbspacer', height: 4},

                  
                
                  
                  {xtype:'fieldcontainer',    itemId : "whatWhoAndWhen-bin1",  hideEmptyLabel: true, 
                      
	                layout:{
	                   type: 'table',
                       columns: 3
	                 },  
                  
                    defaults:{labelWidth:52},
                   
                    items:[
                     {
                      xtype:'combo',
                      
                      rowspan:2,
                      
                      labelClsExtra :'xty_eyecatch-multicombo-label',
                      hideEmptyLabel:false, labelSeparator:'',
                      fieldLabelX: // needed for multiSelect
                        '<li class="x-boxselect-item xty_eyecatch-multicombo-item xty_epobGraphic"  style="" qtip="Grafiken" >' +
                        '<div class="x-tab-close-btn x-boxselect-item-close"></div></li>' +
                        '<li class="x-boxselect-item xty_eyecatch-multicombo-item xty_epobImage"  style="" qtip="Image" >' +
                        '<div class="x-tab-close-btn x-boxselect-item-close"></div></li>' +
                         '<br><li class="x-boxselect-item xty_eyecatch-multicombo-item xty_epobAudio"  style="" qtip="Audio" >' +
                        '<div class="x-tab-close-btn x-boxselect-item-close"></div></li>' 
                        ,
                      labelAlign : 'bottom',
                      labelWidth:52,

                      itemId:'epobTypes',
                      margin:'0 0 0 2',
                      width: 52,  
                      height: 52,
                      pickerOffset : [42,22], // rechts
                      //xpickerOffset : [6,40], // drunter
                      
                      triggerCls:'xty_eyecatch-trigger',
                      forceSelection:true,
                      name:'epobType',
                      tooltip:'epobType',
                      componentCls :'xty_eyecatch-combo',
                      cls :'xty_eyecatch-epobTypes-combo',
                      overCls:'xty_eyecatch-combo-over',
                      queryMode: 'local', displayField: 'dscr', valueField: 'value',   
                      value:'Any',
                      //multiSelect:true,
                      store:  extVia.stores.getHistoryEpobTypesStore(),

                      listeners:{
                        afterrender : function(field) {
                          // readonly: we must prevent user typing
                          // but we needed input visible for boundlist key events
                          this.inputEl.dom.setAttribute('readonly','true'); 
                          
                          this.triggerEl.on('mousedown', function(){
                            field.addCls('xty_trigger-pressed');
                          });
                          this.triggerEl.on('mouseup', function(){
                            field.removeCls('xty_trigger-pressed');
                          });

                          var triggerEl = this.triggerEl;
                           triggerEl.setTooltip = function(tip){
                           if (!triggerEl.tip) {
                             tip = Ext.create('Ext.tip.ToolTip', {target: triggerEl, html: tip });
                             triggerEl.tip = tip;
                            }
                           else{
                            triggerEl.tip.update(tip);    
                           }
                          };
                         },                  
                        change : function(combo, newValue, oldValue) {

                          this.triggerEl.removeCls('xty_epob'+oldValue);
                          this.triggerEl.addCls('xty_epob'+newValue);
                          
                          this.triggerEl.setTooltip(combo.getRawValue());

                          // TO DO;
                          // + multiSelect shoot inside fieldLabel
 
                          var tab = combo.ownerCt.ownerCt.ownerCt.myTab;
                          var historyGrid = tab.getComponent('historyGrid');
                          
                          // historyGrid.getView().emptyText =  '<div class="xty_inplaceMessage-bin"><div class="xty_inplaceMessage-empty"> Keine Aktivit&auml;ten auf '+newValue+'</div></div>';
                           
                          var epobTypeDscr = extVia.module.epob.getEpobTypeDscrFromType(newValue, "P"); 
                          
                          
                          
                          extVia.historyProto.statics.clearGridFilter = function(){
                            historyGrid.store.clearFilter();
                          };
                          
                          historyGrid.getView().emptyText =
                           '<table class="x-grid-table x-grid-table-resizer" style="width: 578px;" cellspacing="0" cellpadding="0" border="0">' +
                            '<tr class="x-grid-group-hd  xty_empty-group-hd">' +
                            '<td class="x-grid-cell" colspan="15" style="padding-left:0px;padding-bottom: 100%;">' +
                            '<div class="x-grid-cell-inner"><div class="x-grid-group-title" onclick="extVia.historyProto.statics.clearGridFilter();" data-qtip="Filter '+extVia.locales.reset+'"><span class="xty_grid-group-filter-value">Filter: '+epobTypeDscr+'</span>  <span class="xty_grid-group-title-items-count">( '+extVia.locales.noActivities+' )</span></div></div>' +
                            '</td></tr>' +
                           '</table>';
                           
                          

                          historyGrid.store.clearFilter();
                          
                          var doFiltering = true;
                          
                          doFiltering = newValue!=='Any';
                          
                          if(doFiltering){
	                      historyGrid.store.filterBy(function(filterRecord,id){
		                    //var epobType = filterRecord.get('epobType'); 
                            var epobType = filterRecord.get('causeEpobType');
                            
		                    if (epobType === newValue){
		                      return true;
		                    }
		                    else{
		                      return false;
		                      }
	                      });
                          }

			             }
                      },       
                      listConfig : {
                          minWidth:300,
                          maxHeight:480,
                          
                         //cls:'x-menu  xty_boundlist-floating-offset', // if not x-menu a boundlist-select closes the whole menu>panel>combo>boundlist :(
                         componentCls :'xty_eyecatch-epobTypes-boundlist xty_boundlist-floating-offset',
                         //tpl : '<tpl for="."><li class="x-boundlist-item <tpl if="!dscr">xty_empty-list-item" unselectable="on</tpl>"><div class="" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div></div></li></tpl>',
                         
                         getInnerTpl : function(displayField) {
                           var tpl = '<div class="xty_list-item <tpl if="!dscr">xty_empty-list-item</tpl><tpl if="isarea"> xty_list-area-item</tpl>" style="" >' +
                              '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}" data-qtip="{value}:{epobTypeId}">' +
                                '<span class="xty_boundlist-item-dscr"  style="margin-top:-8px;">&nbsp; {dscr}</span>' +
                                '<span class="xty_boundlist-item-hits">&nbsp; ({hits})</span>' + // '<span class="xty_boundlist-item-epobType">&nbsp; ({[extVia.module.epob.getEpobTypeIdFromType(values.value)]} - {epobTypeId})</span>' +
                               '</div></div>';
                                return tpl;
                           }
                         } 
                      }, // eo eyecatchcombo
                    
                      {xtype:'combo', hidaeEmptyLabel:false,   itemId : "who" , width:180,  margin:'0 16 0 23',
                          emptyText:extVia.locales.someone,
                          allowBlank:true,
                          cls:'xty_has-insidetrigger ',   
                          trigger1Cls:'xty_inside-trigger-clear', onTrigger1Click:clearTriggerHandler,
                          trigger2Cls:'x-form-trigger',
                          
                          queryMode: 'local', displayField: 'name',  valueField: 'who',   
                          store:  extVia.stores.initUserStore(),
                          listConfig:{
                            itemTpl : '<span class="xty_boundlist-item-dscr">{name}</span><span class="xty_boundlist-item-hits">&nbsp; ({hits})</span>' 
                          }
                          
                          
                      }, 
                      
                      
                      middleOfSentenceComboCfg,
                      
//                      {xtype:'combo', hidaeEmptyLabel:false, itemId : "timeRelated", width:140, margin:'0 0 0 0',
//                         emptyText: extVia.locales.today,
//                         queryMode: 'local', displayField: 'dscr',  valueField: 'dscr',   
//                          cls:'xty_has-insidetrigger ',   
//                          trigger1Cls:'xty_inside-trigger-clear' , onTrigger1Click:clearTriggerHandler,
//                          trigger2Cls:'x-form-trigger',
//                          store: extVia.stores.getTimeRelatedStore(),
//                          listConfig:{
//                            itemTpl : '<span class="xty_boundlist-item-dscr">{dscr}</span><span class="xty_boundlist-item-hits">&nbsp; ({hits})</span>' 
//                          }
//                       },
                       
                       //{xtype:'textfield',  colspan:2, emptyText:'Beziehung',  name : "objectRelation" , width:336, itemId : "objectRelation",  margin:'0 0 0 23' },
                       {xtype:'triggerfield',  colspan:2, emptyText:'Name',  disabled:true,
                       
                        cls:'xty_has-insidetrigger ',   triggerCls:'xty_inside-trigger-clear' , onTrigger1Click:clearTriggerHandler,
                       
                           name : "epobName" , width:336, itemId : "epobName",  margin:'0 0 0 23' }

                      ]
                     },                 
   
                    endOfSentenceComboCfg,
//                   {xtype:'combo', hidaeEmptyLabel:false,   itemId : "actiontype" , width:257,
//                      emptyText: extVia.locales.changed,
//                      queryMode: 'local', displayField: 'dscr',  valueField: 'value',   
//                      cls:'xty_has-insidetrigger ',   
//                      trigger1Cls:'xty_inside-trigger-clear' , onTrigger1Click:clearTriggerHandler,
//                      trigger2Cls:'x-form-trigger',
//                      store: extVia.stores.getActionTypesStore(),
//
//                       listConfig:{
//                            itemTpl : '<span class="xty_boundlist-item-dscr">{dscr}</span><span class="xty_boundlist-item-hits">&nbsp; ({hits})</span>' 
//                       }    
//                      }, 
                    
                    
                    {xtype:'tbspacer', height : 10},    
                    
                              

                  
                 {xtype:'fieldcontainer',    itemId : "change-bin",                   
                    layout:{
                     type: 'table',
                       columns: 2
                     },
                      items:[
	                     //{xtype:'triggerfield',  rowspan:2,emptyText:'Sprache',  itemId : "language",width:60, margin:'0 8 0 0'},

	          
	                     {xtype:'triggerfield',  cls:'xty_has-insidetrigger ',   triggerCls:'xty_inside-trigger-clear',  onTriggerClick:clearTriggerHandler, width:278, emptyText: extVia.locales.newValue, name : "newvalue" , itemId : "newvalue" },
	              
                       //{xtype:'splitbutton', tooltip:'Sprache', height:24, width: 48,  rowspan:2, margin:'-33 0 0 8'},
    
                          
                         {
                        
                            xtype:'combo',rowspan:2, margin:'-27 0 0 5', 
                            itemId:'language',
                            emptyText:'Sprachen ',
                            overCls:'xty_btnlike-combo-over',
                            width: 53,
                            pickerOffset : [-170, -1], // rechts
                            store:extVia.stores.initLanguageStore(), queryMode: 'local',displayField: 'dscr',  valueField: 'iso2',
                            cls:'xty_btnlike-combo',
                            trigger2Cls:'xty_form-splitbtn-trigger',
                            trigger1Cls:'xty_inside-trigger-clear', onTrigger1Click:clearTriggerHandler,
                            
                            listeners:{
		                        afterrender : function(combo, newValue, oldValue) {
		                          // readonly: we must prevent user typing
		                          // but we needed input visible for boundlist key events
		                          this.inputEl.dom.setAttribute('readonly','true'); 

                                  var comboEl = combo.getEl(); 
	                              comboEl.on('mousedown', function(evt, target){
	                                combo.addCls('xty_pressed xty_btnlike-combo-pressed');
	                              });
	                              comboEl.on('mouseup', function(){
	                                combo.removeCls('xty_pressed xty_btnlike-combo-pressed');
	                              });                              

		
		                          var triggerEl = this.triggerEl;
                                  this.inputEl.on('click', function(evt, target){
                                    // triggerEl is an CompositeElement holding all multi triggers
                                    triggerEl.elements[1].dom.click();
                                  });

		                           comboEl.setTooltip = function(tip){
		                           if (!comboEl.tip) {
		                             tip = Ext.create('Ext.tip.ToolTip', {target: comboEl, html: tip });
		                             comboEl.tip = tip;
		                            }
		                           else{
		                            comboEl.tip.update(tip);    
		                           }
		                          };
		                         },                  
		                        change : function(combo, newValue, oldValue) {
                                   this.inputEl.removeCls('xty_icon_'+oldValue);
                                   this.inputEl.addCls('xty_icon_'+newValue);
                                   
                                   
                                   combo.getEl().setTooltip(combo.getRawValue());
                                   
                                }
		                        
                            },
                            
                            
                            
                            name: 'language',
                                listConfig : {
                                   minWidth:210,
                                   componentCls :'xty_boundlist-floating-offset',
                                   getInnerTpl : function() {
                                      var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
                                      return tpl;
                               }
                                  }
                        },
                          
                          

                          
                          {xtype:'triggerfield',   cls:'xty_has-insidetrigger xty_oldvalue-field',   triggerCls:'xty_inside-trigger-clear', onTriggerClick:clearTriggerHandler,  width:278, emptyText: extVia.locales.oldValue , name : "oldvalue" , itemId : "oldvalue" } 
                          
                       ]
                 },
                      
                      
                 
                 
               //  {xtype:'splitbutton', tooltip:'Sprache', height:24, width: 48,  rowspan:2, margin:'-33 0 0 8'},
                 
                   {xtype:'tbspacer', height : 6},              
          

                    
                    // { xtype:'displayfield', value:'<b>Wann genau</b>' },  
                  
//                    {xtype:'fieldcontainer', fieldXLabel : "Wann",   itemId : "when-bin", layout:'hbox', wixxdth:580,
//                      items:[
//                      {xtype:'datefield', emptyText:'Wann genau', hidaeEmptyLabel:false,   width:200, itemId : "timeRelated-day", hiddsen:true }
//                     // {xtype:'textfield', emptyText:'10:00', itemId : "timeRelated-time", vtype:'time', width:70, margin:'0 0 0 4'}
//                     
//                      ]
//                     }, 
                     
//                     { xtype:'slider',  
//                       margin:'0 0 4 0',
//                       values: [0,  365], minValue:0, maxValue:365, width:405, hidden:true,
//                       tipText: function(thumb){
//                        var tip = '';
//                        tip = Ext.String.format('<b>Vor {0} Tagen</b>', thumb.value);
//                        return tip; 
//                      },
//                      listeners:{
//                       change:function(slider, newValue){alert('wepojg');}
//                      
//                      }
//                     },
  
  
//  
//                     { xtype:'fieldcontainer',  margin:'0 0 0 0',
//                       cls:'xty_slider-bin', itemId : "dateslider-bin",  layout:'hbox', 
//                       // hideEmptyLabel:true, 
//                       items:[
//
//                      {xtype:'dateslider', width:334,
//		                  minDate: '12/1/2016', //valid Ext.Date format
//		                  maxDate: '12/31/2016', //valid Ext.Date format
//		                  //dateFields: [], //array of Ext.form.field.Date items
//		                  //OR
//		                  values: ['1/1/2016','12/19/2016' ], //array of date string matching dateFormat
//		                  dateFormat: locales.dateFormat //'n/j/Y' //valid Ext.Date format (default 'n/j/Y')
//                       }
//  
//                     ]},
  
  
  
                  
  
  
  
                   { xtype:'fieldcontainer',  margin:'0 0 0 0',
                       cls:'xty_slider-bin', itemId : "whenslider-bin",  layout:'hbox', 
                       // hideEmptyLabel:true, 
                       items:[

                       
                      {xtype:'hidden', itemId:'boundSliderToFormHidden'},
                       
                     { xtype:'slider', itemId:'whenslider',  values: [0,  365], minValue:0, maxValue:365, width:334,
                       tipText: function(thumb){
                        var tip = '';
                        tip = Ext.String.format('<b>'+extVia.locales.daysAgo+'</b>', thumb.value); 
                        return tip; 
                      },
                      
                      
                      // values:[50,100],
                      
                      legendConfig:{               
                        minLabel: extVia.locales.today,
		                maxLabel: extVia.locales.oneyearago,
		                valLabel: ' '//extVia.locales.daysToDaysAgo,
		              },

                      listeners:{
                        
			            afterrender: function(slider){
                    
                         if (slider.legendConfig){
			                 var sliderEl = Ext.get(slider.id+'-bodyEl');
	                         var labelWidth =  0; // To do: if Label visible slider.labelWidth
			                 var legendEl = sliderEl.createChild( {
			                  tag:'div', id: slider.id+'-legendEl', cls:'xty_slider-legend',  style: 'width:'+ (slider.getWidth() - labelWidth)  +'px;', 
			                  children: [     
					              {tag: 'span', cls:'xty_slider-legend-min-dscr', id: slider.id+'-legend-minEl', html: slider.legendConfig.minLabel},
					              {tag: 'span', cls:'xty_slider-legend-val-dscr', id: slider.id+'-legend-valueEl',  html: slider.legendConfig.valLabel},
					              {tag: 'span', cls:'xty_slider-legend-max-dscr', id: slider.id+'-legend-maxEl', html: slider.legendConfig.maxLabel}
				              ]});
	                          var legendValueEl = Ext.get(slider.id+'-legend-valueEl');
	                          legendValueEl.on('click', function(){ slider.reset();});
	                          slider.setLegendValue = function (legendValue){
	                           legendValueEl.update(legendValue);
	                          };
                              slider.hasLegend =true;
                         } 
                          
			            },
                        
                       change:function(slider, newValue){
                          var clear = slider.ownerCt.getComponent("clear"); 
                          
                          var boundSliderToFormHidden = slider.ownerCt.getComponent("boundSliderToFormHidden"); 
                          
                          var values = slider.getValues();
                          if (values[0]===0 && values[1]===365){
                            if (slider.hasLegend){slider.setLegendValue('');}
                            clear.disable();
                            boundSliderToFormHidden.reset();
                          }
                          else{
                            if (slider.hasLegend){slider.setLegendValue(' '+Ext.String.format(extVia.locales.daysToDaysAgo, values[0], values[1]));}
                            clear.enable();
                            boundSliderToFormHidden.setValue(newValue);
                          }
                       }
                      }
                      
                      
                     },
                     
                      {  xtype:'button', 
                         itemId:'clear',
                          margin:'2 0 0 0',
                          width:24,
                          cls:'xty_clear-btn', disabled:true,
                          iconCls:'xty_formbutton-clear',
                          handler:function(button){  
                           var whenslider = button.ownerCt.getComponent("whenslider"); 
                           whenslider.reset();
                          }
                       }

                     
                     ]}
                     


             
             ],
             buttons: {itemId:'myButtons',  hidden:formClearInside, items:[{
                iconCls:'x-tool-filterOff',
                text: extVia.locales.reset,
                itemId:'reset',
                disabled:true,
                margin:'0 136 0 0',
                handler:function(button){  
		        var formPan = button.up("panel"); 
		        if (formPan){
                  //alert(formPan.getForm().isDirty())
		          formPan.getForm().reset();
                  formPan.dirty = false;
                  //formPan.getForm().fireEvent( 'dirtychange' );
		        }  
               }
              }          
             ]
             },
             
             listeners:{
                dirtychange:function( basic, dirty, eOpts){
                 // alert('dirtychange:function( basic '+basic+', dirty '+dirty+', eOpts '+eOpts);
                 var formPan = this;
                 //  alert('dirtychange ' + formPan.id)
                 var buttons = formPan.getComponent('myButtons');
                 if (dirty) {
                  buttons.getComponent('reset').enable();
                  //buttons.getComponent('reset').show();
                  }
                 else {
                  buttons.getComponent('reset').disable();
                 }
                },
              
              afterrendXXer:function(cmp){
              
                
              var close =  Ext.get(cmp.getEl().dom.firstChild).createChild({
                tag: 'div',
                cls: 'x-toxol xty_minitool-close',
                //overCls: 'xty_minitool-over',           
                style:'position:absolute; top:6px;right:2px;height:12px; width:12px;'
              });
             
              close.on('click', function() {
                // alert('You clicked the close!')
//                me.clearAll(true);
//                me.grid.hideFilterbar();
              });
 
              
              var filterOff =  Ext.get(cmp.getEl().dom.firstChild).createChild({
                tag: 'div',
                cls: 'x-tool-filterOff', 
                stsyle:'position:absolute; top: 6px; right:34px; height:16px; width:16px;',
                style:'position:absolute; bottom:20px;left:30px;height:16px; width:16px;'
              });
              
              
                
              }
             }
             
             
           };
        
          return  historyFilterPanelCfg;       
    
   },
   
   
   
    historyFields :  [
    
                  {name:"myId", mapping:"key_target_id"},//2111,
                  {name:"", mapping:"key_epob_type_Id"},//2020,
                  {name:"historyJobId", mapping:"key_hjob_id"},//190,
                  {name:"", mapping:"key_type"},//"target",
                  {name:"", mapping:"key_clie_id"},//1,
                  {name:"language", mapping:"key_lang_id"},//2,
                  {name:"", mapping:"cause_epimId"},//5893,
                  {name:"", mapping:"cause_epob_type_Id"},//1350,
                  {name:"module", mapping:"cause_epim_module"},//"XML Import",
                  {name:"causeAction", mapping:"cause_actionkey"},//"dict.upd_value",
                  {name:"comment", mapping:"cause_hjob_comment"},//"test with all dicts",
                  {name:"", mapping:"cause_data_id"},//5893,
                  {name:"langId", mapping:"cause_data_lang_id"},//2,
                  {name:"causeEpobType", mapping:"cause_data_epob_type"},//1350,
                  {name:"causeName", mapping:"cause_data_name"},//"Wand",
                  {name:"oldvalue", mapping:"cause_data_oldvalue"},//"OLDVALUE",
                  {name:"newvalue", mapping:"cause_data_newvalue"},//"Wand",
                  {name:"changedate", mapping:"cause_change_date"},//"2015-10-15T18:36:08",
                  {name:"user", mapping:"cause_change_user"},//"System Administrator",
                  {name:"", mapping:"cause_change_user_id"},//2,
                  {name:"", mapping:"cause_hist_msg"},//null,
                  {name:"", mapping:"target_id"},//2111,
                  {name:"", mapping:"target_epob_type_id"},//2020,
                  {name:"", mapping:"target_data_id"},//4352,
                  {name:"targetEpobType", mapping:"target_data_epob_type"},//2180,
                
                  {name:"name", mapping:"cause_data_name"},// Which one ????
                  {name:"name", mapping:"target_data_name"},//"Anwendungsbauteil",
                  
                  {name:"", mapping:"target_data_newvalue"},//"Wand",
                  {name:"targetAction", mapping:"target_actionkey"},//"dict.upd_value_dict_prat",
                  {name:"", mapping:"target_hist_msg"},//"LanguageGerman",
                  {name:"objedep_target_id", mapping:"objedep_target_id"},//null,
                  

                  
                  {name:"objedepEpobType", mapping:"objedep_epob_type_id"},
                  {name:"objdepAction", mapping:"objedep_actionkey"},
                  {name:"", mapping:"objedep_hist_msg"}
                  
                  
                  // NEW Fields 
                  ,{name:"objedep_targetProperty_epobTypeId"} // same as ?target_data_epob_type?
                  ,{name:"objedep_targetProperty_id"}
                  ,{name:"objedep_targetProperty_name"}  // ?target_data_name?
                  
                  
                  ,{name:"whatDscr"}  

                  ,{name:"childOrParent"}  
                  
                  ,{name:"timeRelated"}  
                  ,{name:"isFirstOfTimeRelatedGroup" }
                  
                  ],
   
   
   getHistoryGridCfg : function(cfg,info, epob){

     
     var toggleTimeRelatedRows = function(view,  record, timeRelatedGroup, collapse) {
       // collapsedGroup persistence
       if (!view.collapsedGroups){
         view.collapsedGroups = [];
       }
       if (collapse){
         view.collapsedGroups.push(timeRelatedGroup);
       }
       else{
         Ext.Array.remove( view.collapsedGroups, timeRelatedGroup );
       }

       // Filter
       view.store.filterBy(function(filterRecord,id){
         var timeRelatedGroupName = filterRecord.get('timeRelated').replace(/ /g,''); 
         if (Ext.Array.contains( view.collapsedGroups, timeRelatedGroupName )){
           var isFirstOfTimeRelatedGroup = filterRecord.isFirstOfTimeRelatedGroup; 
           var showRow = isFirstOfTimeRelatedGroup;
           if (!isFirstOfTimeRelatedGroup){
             showRow = !collapse;
           } 
           return showRow;
         }
         else{
           return true;
         }
       });
     };
     
     
     
    var collapseAllChildRows = function(store) {
       store.filterBy(function(filterRecord,id){
        var isParent = filterRecord.get("childOrParent").indexOf('parent')>-1;
         if (isParent){
          filterRecord.set('isCollapsed',true);
         }
        var isChild = filterRecord.get("childOrParent").indexOf('child')>-1;
        if (isChild){
          filterRecord.set('rowIsHidden',true); 
          return false;
        }
        else{return true;}
      });
    };
    
    var toggleChildRows = function(view,  record ) { 
          var parentId = record.get('historyJobId'); 
          var isCollapsed = record.get('isCollapsed');

            if (isCollapsed){
              record.set('isCollapsed',false);
              view.store.filterBy(function(filterRecord,id){
                var rowIsHidden = filterRecord.get('rowIsHidden'); 
                var myParentId = filterRecord.get('historyJobId'); 
                if (myParentId === parentId){
                  filterRecord.set('rowIsHidden',false); 
                  return true;
                }
                else{
                  if (rowIsHidden){return false;}
                  else{return true;}
                }
              });
            }
            else{
              record.set('isCollapsed',true);
              view.store.filterBy(function(filterRecord, id){
                var rowIsHidden = filterRecord.get('rowIsHidden'); 
                var myParentId = filterRecord.get('historyJobId'); 
                var isChild = filterRecord.get("childOrParent").indexOf('child')>-1;
                if ( (myParentId === parentId || rowIsHidden) && isChild){
                  filterRecord.set('rowIsHidden',true); 
                  return false;
                }
                else{return true;}
              });
            }
        };

    var gridData =[];
    try{
      if (epob && epob.epobId && extVia.historyProto.historyEntries[epob.epobId]){
      gridData = extVia.historyProto.historyEntries[epob.epobId]; 
      
      var gi;
      for(gi=0; gi < gridData.length; gi++){
        var row = gridData[gi];
        
        var when = '';
        if (row.cause_change_date){
         when = extVia.historyProto.statics.timeRelatedRenderer( row.cause_change_date);
        }

        // alert(Ext.encode(row.cause_change_date) +' row.cause_change_date '+row.cause_change_date+ 'when '+when);  
        row.timeRelated = when;
      }
     }
    }
    catch(ex){extVia.notify('var gridData = extVia.historyProto.historyEntries[epob.epobId]; '+ex);}

    

   var cardView = false;  
   var smallcards = false;  
   var showFilter = true;  
   if (epob.historyviewCfg){
    cardView = epob.historyviewCfg.cards;
    smallcards = epob.historyviewCfg.smallcards;
   }               
                  
  

    var historyEntryModel = Ext.define('historyEntry', {
	    extend: 'Ext.data.Model',
        fields: extVia.historyProto.statics.historyFields
	});
   

    
                  
                  
    var historyGridCfg  = {
        xtype:'grid',
        width:cfg.width-4,
      //  html: '<img  style="position:absolute;top:20px;z-index:999;" src="../img/fakes/versioning/histgrid-filterbar.png"/>',
//        tbar:{
//         itemId:'histgrid-filterbar',
//         height:26,
//         html: '<img  style="position:absolute;top:20px;z-index:999;" src="../img/fakes/versioning/histgrid-filterbar.png"/>'
//        },
//        
        
        margin:cfg.margin?cfg.margin:'0 0 0 0', 
        height:cfg.height?cfg.height:320,
        itemId:'historyGrid',
        id:'historyGrid-'+epob.epobId,
        cls:'xty_histgrid-bin '+   (cardView ?'xty_cardview-grid xty_cardview-histgrid':'')  +   (smallcards ?' xty_cardview-smallcards':'') ,
        
        iconCls:'xty_menu-history',
        preventHeader:cfg.preventHeader?cfg.preventHeader:false,
        //border:cfg.HideBorder?false:true,
        border:false,
        bodyBorder:false,
        bodyStyle:cfg.bodyStyle?cfg.bodyStyle:null, 
        
        
        //title:cfg.title?cfg.title:"Historie von<i>&nbsp;&nbsp;"+info.dscr+"&nbsp;&nbsp;</i> in <i>&nbsp;&nbsp;"+epob.dscr+"&nbsp;&nbsp;</i> ",
        title:"Aktivit&auml;ten ", //+epob.dscr+"&nbsp;&nbsp;</i> in <i>&nbsp;&nbsp;"+epob.dscr+"&nbsp;&nbsp;</i> ",
        //hideHeaders : cardView, //true,

        
         viewConfig: {       
              stripeRows: false,  
              emptyText: extVia.editor.baseEditor.statics.getEmptyTextHTML('Keine Aktivit&auml;ten'), deferEmptyText : false,
              getRowClass: function(record){    
                var collCls =" xty_defaultRow";
                var isParent = false;
                var isChild = false;
                var childOrParent = record.get('childOrParent') ; 
                if (childOrParent){
                    isChild = childOrParent==="child" || childOrParent==="lastchild"   ; 
                    isParent = childOrParent==="parent" ;
                    
                    if (isParent){
                      var isCollapsed =  record.get('isCollapsed');
                      var openCls = isCollapsed?'collapsed':'expanded';
                      collCls =" xty_histgrid-parent-row xty_histgrid-parent-row-"+openCls+" ";
                    }
                    else if (isChild){
                      collCls =" xty_histgrid-child-row ";
                      var isLastChild = record.get('isLastChild') || childOrParent==="lastchild";
                      if (isLastChild){
                          collCls =" xty_histgrid-child-row  xty_histgrid-lastchild-row ";
                          }
                      }
                }
                return 'xty_histgrid-row '+collCls;
              }
            },
        
        
              
        store: Ext.create('Ext.data.Store', {
                  //storeId:'historyStore_type_',
                  allowDeselect:true,
                  //fields: [{name:'inhXXeritance'},{name:'epobType', mapping:'cause_data_oldvalue'},{name:'cause_actionkey', mapping:1},{name:'name'},{ name:'id'},{ name:'productnumber'}],

                  
                  //model:historyEntryModel,
                  fields: extVia.historyProto.statics.historyFields,
                 
                //  groupField: 'timeRelated', 
                  
                
//                  myMappingsORGObj:{
//                  "key_target_id": 2111,
//                  "key_epob_type_Id": 2020,
//                  "key_hjob_id": 190,
//                  "key_type": "target",
//                  "key_clie_id": 1,
//                  "key_lang_id": 2,
//                  "cause_epimId": 5893,
//                  "cause_epob_type_Id": 1350,
//                  "cause_epim_module": "XML Import",
//                  "cause_actionkey": "dict.upd_value",
//                  "cause_hjob_comment": "test with all dicts",
//                  "cause_data_id": 5893,
//                  "cause_data_lang_id": 2,
//                  "cause_data_epob_type": 1350,
//                  "cause_data_name": "Wand",
//                  "cause_data_oldvalue": "OLDVALUE",
//                  "cause_data_newvalue": "Wand",
//                  "cause_change_date": "2015-10-15T18:36:08",
//                  "cause_change_user": "System Administrator",
//                  "cause_change_user_id": 2,
//                  "cause_hist_msg": null,
//                  "target_id": 2111,
//                  "target_epob_type_id": 2020,
//                  "target_data_id": 4352,
//                  "target_data_epob_type": 2180,
//                  "target_data_name": "Anwendungsbauteil",
//                  "target_data_newvalue": "Wand",
//                  "target_actionkey": "dict.upd_value_dict_prat",
//                  "target_hist_msg": "LanguageGerman",
//                  "objedep_target_id": null,
//                  "objedep_epob_type_id": null,
//                  "objedep_actionkey": null,
//                  "objedep_hist_msg": null },

                  data: gridData
//                  
//                  ,listeners:{
//                   load: function (store){ collapseAllChildRows(store);}
//                  }
                  
                  
             }),   
 
            
            
             getGroupedColumn:function(){                            
               var columnFieldName = this.features[0].getGroupField();
               var column; 
               var i;
               for ( i = 0; i < this.columns.length; i++){
                if (columnFieldName ===  this.columns[i].dataIndex){
                  column = this.columns[i];
                } 
               }  
               return  column ;
              },
              
              getGroupedFieldName:function(){                            
               var columnFieldName = this.getGroupedColumn().headerDscr;
               return  columnFieldName ;
              },
              
//                                      getGroupedFieldRecordIxs:function(rows){  
//                                        var column  = this.getGroupedColumn();
//                                        var columnId = column.id;
//                                        var groupedFieldRecordIxs =[];
//                                        
//                                        var i;
//                                        for (i=0; i < rows.length;i++){
//                                           var cellStr = Ext.encode(rows[i][columnId]);
//                                           var recordIxIx = cellStr.indexOf('data-recordix');
//                                           var recordIx = cellStr.substring(recordIxIx+16, cellStr.length);
//                                           recordIx = recordIx.substring(0, recordIx.indexOf('\\'));
//                                           groupedFieldRecordIxs.push(recordIx);
//                                        }
//                                        return  groupedFieldRecordIxs;
//                                      },
                                  
               
                features: [Ext.create('Ext.grid.feature.Grouping',{
                  //startCollapsed: true,
                  groupHeaderTpl: '{[Ext.getCmp("'+  'historyGrid-'+epob.epobId +'").getGroupedFieldName()]} {name}  <span  class="xty_grid-group-title-items-count" >({rows.length} {[values.rows.length > 1 ? "'+extVia.locales.activities+'" : "'+extVia.locales.activity+'"]})</span>'
                  //groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
                })],

            columns: [

               { header: 'Job Id',dataIndex: 'historyJobId', hidden:true},
               
               { header: '&nbsp;',  cls:'xty_timeline-column', width:58, hidden:!cardView, renderer: extVia.historyProto.statics.gridTimelineRenderer},
               { header: 'Aktivit&auml;ten', cls:'xty_activity-column', dataIndex: 'changedate', width:480,  hidden:!cardView, renderer: cardView ? extVia.historyProto.statics.gridCardRenderer :null},

                
                
                { header: 'Wer', dataIndex: 'user',   rXXenderer:extVia.versionsProto.statics.gridPinfoUserrXXenderer, hidden:cardView},
                //{ header: 'EPIM Id',width:32,dataIndex: 'epimId'},
                { header: 'Wann', dataIndex: 'changedate',  width:120, renderer:extVia.historyProto.statics.gridPinfoWhenRenderer , hidden:cardView},
                { header: 'Wann timeRelated', dataIndex: 'timeRelated',  width:120, hidden:true},
                { header: '<div class="xty_menu_contains" data-qtip="Typ hier">&nbsp;&nbsp;&nbsp;</div>', hidden: cardView, width:31, dataIndex: 'targetEpobType',renderer:extVia.historyProto.statics.gridObjdepPropDatatypeIdColumnRenderer},
                { header: 'Was', dataIndex: 'name',  width:200, renderer:extVia.historyProto.statics.gridPinfoWhatRenderer, hidden:cardView}, 
                { header: '&Auml;nderung', dataIndex: 'name',  width:100, renderer: extVia.historyProto.statics.gridPinfoAreaRenderer, hidden:cardView}, 
                { header: 'Wert', dataIndex: 'newvalue', width:320, renderer:extVia.historyProto.statics.gridPinfoValueRendererHistory, hidden:cardView},  
                 
                //{ header: 'o', width:31, dataIndex: 'objedepEpobType',renderer:extVia.historyProto.statics.gridDatatypeIdColumnRenderer},
                { header: '<div class="xty_icon xty_iconOrigin" data-qtip="Typ Ursache">&nbsp;&nbsp;&nbsp;</div>', hidden:true, width:31, dataIndex: 'causeEpobType',renderer:extVia.historyProto.statics.gridDatatypeColumnRenderer},
                { header: '<div class="xty_pgtoolbar-languages" data-qtip="Sprache">&nbsp;&nbsp;&nbsp;</div>', hidden:cardView, width:31, dataIndex: 'language',renderer:extVia.historyProto.statics.gridLanguageColumnRenderer},
                { header: 'Warum' , dataIndex:'comment', hidden:true,  width:220},
                { header: 'Wie / Ursache /' , dataIndex:'targetAction', hidden:true,  width:260,renderer:extVia.historyProto.statics.gridHistoryActionRenderer},
                { header: 'Woher' , dataIndex:'module',  width:80,rXXenderer:extVia.versionsProto.statics.gridAreaColumnRenderer, hidden: true}
   
            ],
            
        listeners:{ 
          'itemcontextmenu' : extVia.historyProto.statics.getInfoItemContextmenuHandler(cfg , epob),
          'itemclick' : function(view,  record, item, index, evt) {  
                var toggleEl = evt.getTarget('.x-grid-group-title');
                var isGridGroupTitle = toggleEl!==null; 
                if (isGridGroupTitle)  { 
                  var isFirstOfTimeRelatedGroup = record.isFirstOfTimeRelatedGroup;
                  if (isFirstOfTimeRelatedGroup){
                   var timeRelatedGroupName = record.get('timeRelated').replace(/ /g,''); 
                   var collapse =  record.groupCollapsed;
                   if ( record.groupCollapsed === undefined){
                     collapse = true;
                   }           
                   record.groupCollapsed = !collapse;
                   toggleTimeRelatedRows(view, record,timeRelatedGroupName, collapse) ;
                  }
                } 
            },    
        
           
              afterrender: function(grid){
                
                // just for spec visualisation
                var qtipTask = new Ext.util.DelayedTask(function(){   
                var createTip = function(cfg){
                  var  tip = Ext.create('Ext.tip.ToolTip', {
                  target: cfg.target,
                  title:cfg.title,
                  width: cfg.width?cfg.width:140,
                  anchor: cfg.anchor?cfg.anchor:'left',
                  
                  cls: cfg.anchor?'xty_tip-anchored-'+cfg.anchor:'',
                  
                  dismissDelay :50000,
                  autoShow : true,
                  mouseOffset:  cfg.mouseOffset,
                  html: cfg.html
                 }); 
                 return tip;
               };  
                  

                var cards = Ext.query('#'+grid.getView().id+' .xty_grid-card-cell');   
                var di;
                for (di=0; di<3; di++ ){
                 var card = Ext.get(cards[di]); 
                 var first = di===0;
                 var scnd = di===1;
                 var third = di===2;
                 
                 if(first) {createTip({target: card, title:'activity-card ', mouseOffset:[50,20],anchor:'bottom', html: 'header<br>&nbsp;&nbsp;&nbsp;body<br>&nbsp;&nbsp;&nbsp;footer'});}

                 var doObjecDep = false;
                 var header = Ext.get(Ext.query('#'+card.id+' .xty_card-header')[0]);  
                 if(first) {createTip({target: header, title:'card-header ',  mouseOffset:[-6,-10], html: 'epobType, user, timeRelated,epobTypeDscr, name, action '+(doObjecDep?',&lt;br&gt;relatedEpobType, relatedEpobDscr':'')});}

                 var body = Ext.query('#'+card.id+' .xty_card-body')[0];  
                 if(first){createTip({target: body, title:'card-body', mouseOffset:[-6,0], html: 'language, newValue,<br> oldValue'});}

                 var footer = Ext.query('#'+card.id+' .xty_card-footer')[0];  
                 if(first){createTip({target: footer, title:'card-footer', mouseOffset:[-6,0], html: 'date time'});}

                 var eyecatcher = Ext.query('#'+header.id+' .xty_card-eyecatcher')[0];  
                 if(first) {createTip({target: eyecatcher, title:'card-eyecatcher', mouseOffset:[14,0], width:170, anchor:'right', html:  'epobType &lsaquo;&ndash;cause_data_epob_type OR target_data_epob_type'});}
                 
                 
                 var user = Ext.query('#'+header.id+' .xty_card-user')[0];  
                 if(scnd){createTip({target: user, title:'user',   mouseOffset:[-18,10], anchor:'bottom', html:  'user &lsaquo;&ndash;cause_change_user'});}
                 
                 var timeRelated = Ext.query('#'+header.id+' .xty_card-timeRelated')[0];  
                 if(scnd){createTip({target: timeRelated, title:'timeRelated', mouseOffset:[22,10], anchor:'bottom',  html:  'changedate &lsaquo;&ndash;cause_change_date'});}

                 var epobTypeDscr = Ext.query('#'+header.id+' .xty_card-epobType-dscr')[0];  
                 if(scnd){createTip({target: epobTypeDscr, title:'epobTypeDscr',  anchor:'left',  html:  'epobTypeDscr &lsaquo;&ndash;cause_data_epob_type'});}
                 
                 var epobDscr = Ext.query('#'+header.id+' .xty_card-epob-dscr')[0];  
                 if(scnd){createTip({target: epobDscr, title:'name', mouseOffset:[10,0],  anchor:'right', width:180,  html:  'epobDscr&lsaquo;&ndash;cause_data_epob_type OR target_data_name'});}

                 var action = Ext.query('#'+header.id+' .xty_card-action')[0];  
                 if(scnd){createTip({target: action, title:'action', mouseOffset:[-8,-10],  anchor:'top',  html:  'action&lsaquo;&ndash;cause_actionkey'});}
                 
                 
                 
                 var language = Ext.query('#'+card.id+' .xty_card-language')[0];  
                 if(scnd){createTip({target: language, title:'language', mouseOffset:[10,-6], width:170, anchor:'right',  html:  'language&lsaquo;&ndash;cause_data_lang_id'});}
                 
                 var newValue = Ext.query('#'+card.id+' .xty_card-newvalue')[0];  
                 if(scnd){createTip({target: newValue, title:'newValue', mouseOffset:[-8,-8], width:180, anchor:'left',  html:  'newValue&lsaquo;&ndash;cause_data_newvalue'});}
                 var oldValue = Ext.query('#'+card.id+' .xty_card-oldvalue')[0];  
                 if(scnd){createTip({target: oldValue, title:'oldValue', mouseOffset:[-8,8], width:180, anchor:'left',  html:  'oldValue&lsaquo;&ndash;cause_data_oldvalue'});  }               
                 
                 var datetime = Ext.query('#'+card.id+' .xty_card-datetime')[0];  
                 if(scnd){createTip({target: datetime, title:'datetime', mouseOffset:[10,0], width:180, anchor:'right',  html:  'datetime&lsaquo;&ndash;cause_change_date?'});}
                 
                 
                }
				});

        
                grid.showFieldsSpec = qtipTask; 
        
                //grid.showFieldsSpec.delay(500);
              
              }
              
              
            }
            
            
            
          };
 
         return  historyGridCfg;
          
    },
    
    
    
    getHistoryTabCfg : function(cfg, epob){

      var centerRight = extVia.regApp.myRaster.getCenterRight();

      var historyTabCfg = {
           title: extVia.locales.history+extVia.editor.baseEditor.statics.addTabChooser('history'), 
           html: '<img id="histgrid-filterbar" style="position:absolute;top:-2px;z-index:999;display:none;" src="../img/fakes/history/histgrid-filterbar_02.png"/>',
           stateful:true,
           itemId:'history',
           
           badgeCfg :{
	           cls:'xty_tabs-badge',
	           count: 7, 
	           tooltip: 'neue Aktivit&auml;ten',
               handler:function(badge){
                var tab =  badge.myTab;
                var editorPanel = tab.ownerCt.ownerCt; 
                var moreButton = editorPanel.getApplicationBar().pagetoolbar.getComponent('more-btn');
                //moreButton.showMyMenu(); 
                
                moreButton.myMenu.getEl().slideIn();
                
                var filterPanel = moreButton.myMenu.items.get(0);
                filterPanel.setTimeRelatedValue('neue');
 
                var showTabNewsBadgeTask = new Ext.util.DelayedTask(function(){
                  badge.setText('1'); 
                  badge.setTooltip('1 neue Aktivit&auml;t'); 
                  badge.getEl().slideIn('b',{duration:100});
                  
                  // moreButton.showMyMenu(); 
                  
				});
                showTabNewsBadgeTask.delay(5000); 
                
               }
           },

           
           finderBtnGrpDscr:'Historydaten finden',
           autoScroll:false,
           stateId: cfg.editorMainTabItemId+'-history',
           moreBtnCfg:{
             dscr:'History filtern', 
             menuCfg:{ 
	             x: centerRight-466, y: 238,        
	             cls:'xty_morebtn-menu',
	             autoShow:true, 
                 //align:'tabitem',
                 showMode:'slideIn',
                 showSeparator:false,
	             items:[extVia.historyProto.statics.getHistoryFilterPanelCfg()]
             }
           },           
           activate:function(tab){
            var applibar =    tab.ownerCt.ownerCt.getApplicationBar();
            applibar.getComponent('pagetoolbar').getComponent('openDiff').show();
           },
           deactivate:function(tab){
            var applibar =    tab.ownerCt.ownerCt.getApplicationBar();
            applibar.getComponent('pagetoolbar').getComponent('openDiff').hide();
           },                                       
            
//            tbarX:{hidden:true, items:[
//            {xtype:'tbspacer', width: 54},
//            
//            
//                 {xtype: 'buttongroup', width:430,
//                 margin:'2 0 0 0',
//                 //title: 'Clipboard',
//                 defaults:{},
//                 columns:3,
//                 items:[  
//                      {xtxype:'tbspacer', width:66, scale:'large',rowspan:3, iconCls:'xty_pgtoolsbar-search'},
//                      {xtype:'combo', hidaeEmptyLabel:false,   itemId : "who" , width: 180, margin:'0 4 0 0', height:16,
//                          emptyText:'Jemand',
//                          queryMode: 'local', displayField: 'dscr',  valueField: 'value',   
//                         store: Ext.create('Ext.data.Store', {
//                          model: Ext.define('epobTypes', {fields: ['dscr', 'value'], extend: 'Ext.data.Model'}),
//                          data:[ {dscr:'Alle',value:''}, {dscr:'Ringo Starr'}, {dscr:"Gene Grupa"},{dscr:"John Bonham"} ]
//                         })
//                       }, 
//                       
//                       {xtype:'combo', hidaeEmptyLabel:false, itemId : "timeRelated", width:140, msargin:'2 0 0 0', height:16,
//                         emptyText:'heute',
//                         queryMode: 'local', displayField: 'dscr',  valueField: 'dscr',   vaxlue:'heute',
//                         store: extVia.stores.getTimeRelatedStore()
//                      },
//                     
//                      {xtype:'triggerfield', width:324, emptyText:'Objekte', margin:'2 0 2 0', cls : 'xty_inside-trigger', trigger1Cls : 'xty_miniquery-menu-trigger xty_search-inside-trigger',  trigger2Cls : 'xty_miniquery-menu-trigger xty_searssch-inside-trigger',  height:20, colspan:2},
//                      {xtype:'textfield', width:324, margin:'1 0 0 0',  emptyText:'Werte ge�ndert?', height:20, colspan:2}
//
//                  ]
//
//                 }
//            
//            
//              //{xtype:'combo'}
//            ]},
            
            
            items:[      
              
              extVia.historyProto.statics.getHistoryGridCfg({
              allInfos:true,
              bodyStyle:'border: solid 1px #c5c5c5;',
              height: extVia.regApp.myRaster.getCenter().getHeight()-178,
              preventHeader:true
              }
              ,
              {dscr:'alle'}, epob)

              ]
             
         };
       
       return historyTabCfg;
    },
    
    
      
    getInfoHistoryListCfg : function(cfg,info, epob){
    
      return  {
        xtype:'grid',
        width:cfg.width-4,
        margin:cfg.margin?cfg.margin:'0 0 0 0', 
        collapsed:cfg.collapsed,
        hidden:cfg.hidden,
        height:cfg.height?cfg.height:extVia.regApp.myRaster.getCenter().getHeight()-276,
        //height: extVia.regApp.myRaster.getCenter().getHeight()-276,
        itemId:'HistoryGrid',
        cls:'xty_histgrid-bin',
        iconCls:'xty_menu-history', 
        preventHeader:cfg.preventHeader?cfg.preventHeader:false,
        border:cfg.HideBorder?false:true,
        bodyStyle:cfg.bodyStyle?cfg.bodyStyle:null, 
        title:cfg.title?cfg.title:"Aktivit&auml;ten auf<i>&nbsp;&nbsp;"+info.dscr, //+"&nbsp;&nbsp;</i> in <i>&nbsp;&nbsp;"+epob.dscr+"&nbsp;&nbsp;</i> ",
        emptyText:'Keine Inhalte zum anzeigen',
        
        listeners:{
         afterrender: function(panel) {
           if (panel.header && panel.header.el){
              panel.header.el.on('click', function() {
              if (panel.collapsed) { panel.expand();}
              else {panel.collapse();}                      
            });
           }
          },
          'itemcontextmenu' : extVia.historyProto.statics.getInfoItemContextmenuHandler(cfg , epob)
          },
        
        store:extVia.versionsProto.statics.initDiffStore(
          { 
        allInfos:cfg.allInfos,
        historyView:true,
        infoId:info.infoId,
        sorters: { field: 'changedateWork', direction:'DESC',
                     sorterFn: function(rec1, rec2){
                    var getMilliseconds = function(rec){
                        var milliseconds = rec.get('changedateWork');
                              milliseconds = milliseconds.replace(extVia.versionsProto.statics.dateFormatDe2EeX,"$5/$3/$1"); 
                              milliseconds = milliseconds+" "+rec.get('changetimeWork');
                              milliseconds  = new Date(milliseconds).getTime(); 
                              return milliseconds;
                    },
                    millis1 = getMilliseconds(rec1),
                    millis2 = getMilliseconds(rec2);
                    if (millis1 > millis2) {return 1;}
                    if (millis1 < millis2) {return -1;}
                    return 0;
                }
              }}
              ,epob), 
            columns: [
                // HISTORY GRID VERSION 1
                { header: 'Wer', dataIndex: 'userWork',   renderer:extVia.versionsProto.statics.gridPinfoUserRenderer},                
                //{ header: 'EPIM Id',width:32,dataIndex: 'epimId'},
                { header: 'Wann', dataIndex: 'changedateWork',  width:80, renderer:extVia.historyProto.statics.gridPinfoWhenRenderer },
                { header: 'Was' ,dataIndex: 'name', hidsden:!cfg.allInfos, width:180, renderer:extVia.historyProto.statics.gridPinfoWhatRenderer}, 
                { header: '', width:31, dataIndex: 'dataType',renderer:extVia.versionsProto.statics.gridDatatypeColumnRenderer},
                { header: 'Wert',dataIndex: 'valueWork', width:200, renderer:extVia.historyProto.statics.gridPinfoValueRendererHistory},  
                { header: 'Warum' , dataIndex:'comment',  width:cfg.allInfos?220:160},
                { header: 'Wo' , dataIndex:'area',  width:80,renderer:extVia.versionsProto.statics.gridAreaColumnRenderer}
                //{ header: 'Datum', dataIndex: 'changedateWork',  width:120, renderer:extVia.versionsProto.statics.gridDatetimeColumnRendererW }
                //{ header: 'VersionNr', dataIndex: 'versionNr'}
            ]
          };
    }
    
    
    

    }
});

