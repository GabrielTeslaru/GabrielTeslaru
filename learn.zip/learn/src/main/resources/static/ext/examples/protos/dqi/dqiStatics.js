


Ext.define('extVia.dqi.statics', {
    statics: {

    getSubTabPanelCfg: function(cfg, epob) { 
      
      var loc = extVia.locales;
      
      
      
      var reqSep = extVia.dialoges.getLabelSeparator4Required();
      
      
      var galleryHeight = 154;
      
      var centerWidth =  extVia.regApp.myRaster.getCenter().getWidth();
      var galleryWidth =  centerWidth-84;
      
      
      var panelsWidth = centerWidth-84;
      var panelsMargin ='20 42 20 42';
      
      
      
      
      
      
      var actionRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
        var html =  
          '<span  class="xty_actions-bin"><span title="view" style="height:18px;vertical-align:bottom;" class="xty_action-view">&nbsp;V&nbsp;</span>' +
          '<span title="edit" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_action-edit">&nbsp;E&nbsp;</span>' +
          '<span title="delete" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_action-delete">&nbsp;&#10005;&nbsp;</span></span>'
        ;
        
        
        return html;
        
    };
    
      var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
        return '<div title="' + value + '" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob' + value + '"> &nbsp;&nbsp;&nbsp;</div>';
    };

    var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
        return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '"><span title="' + value + '"style="margin-top:-8px;"></span></div>';
    };
    
    
    var checkboxRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
      return '<input type="checkbox"/>';
  }; 
      var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
        clicksToEdit: 1
      });
      
    
      var rulesGrid  = Ext.create('Ext.grid.Panel', {
        itemId:'rulesGrid',
         margin:'10 10 10 10',

         plugins: [
           cellEditing
           ],
         
         store: Ext.data.StoreManager.lookup('structureplanningStore'),
         columns: [    
              { header: 'Typ',  dataIndex: 'epobType', width:32, editor : {xtype : 'combo'}, renderer: epobTypeRenderer},
              { header: 'Name',  dataIndex: 'name' , editor : {xtype : 'textfield'},   width:300},
              { header: 'Rule',  dataIndex: 'rule' , editor : {xtype : 'combo'}},
              { header: 'Validation',  dataIndex: 'validation' , editor : {xtype : 'combo'}}
 
         ],

          listeners:{
           itemdblclick: function( view, record, item, index, evt, eOpts ){
            extVia.notify('edit '+record.get('name') );
           }
          
          }
     });
      

      
      
      var childrensDqiGrid  = Ext.create('Ext.grid.Panel', {
        itemId:'childrensDqiGrid',
         margin:'10 10 10 10',
         store: Ext.data.StoreManager.lookup('structureplanningStore'),
         columns: [    
              { header: 'Typ',  dataIndex: 'epobType', width:32, editor : {xtype : 'combo'}, renderer: epobTypeRenderer},
              { header: 'Name',  dataIndex: 'name' , editor : {xtype : 'textfield'},   width:300},
              { header: 'Web', dataIndex: 'web' },
              { header: 'Print',  dataIndex: 'print' },
              { header: 'Ecommerce',  dataIndex: 'ecommerce'},
              { header: 'MediaPortal',  dataIndex: 'MediaPortal'},
              { header: 'Productportal',  dataIndex: 'Productportal'}
 
         ],

          listeners:{
           itemdblclick: function( view, record, item, index, evt, eOpts ){
            extVia.notify('edit '+record.get('name') );
           }
          
          }
     }); 
      
      
      
      
      
      
      var channelsClickHandler = function(evt, target){
        var channelPanel = this;
        
        if ( extVia.dqi.statics.lastClickedChannelPanelId){
          Ext.getCmp(extVia.dqi.statics.lastClickedChannelPanelId).removeCls('xty_gallery-content-panel-selected');
        }
        channelPanel.addCls('xty_gallery-content-panel-selected');
        extVia.dqi.statics.lastClickedChannelPanelId = channelPanel.id;
        
        var editorSubtabpanelEl = channelPanel.getEl().findParentNode('.xty_editor-subtabpanel'); 
        var editorSubtabpanel = Ext.getCmp(editorSubtabpanelEl.id);


        var detailsPanel = channelPanel.ownerCt.ownerCt.ownerCt.getComponent('detailsPanel');
        var channelGeneratedDate = '15.07.2019 11:11'; 
        detailsPanel.setTitle('Details: Channel '+channelPanel.name + ' <span class="xty_panel-header-title-modifier"> - '+channelGeneratedDate+'</span>');
        detailsPanel.expand();
       
       
       var applibar =  editorSubtabpanel.ownerCt.getApplicationBar();
       applibar.setSubEpobDscr('Channel: '+channelPanel.name);
       var dqiBtn = applibar.getPagetoolbar().getComponent('dqi').enable();
       
       

      };
      
      
      var subTabPanelCfg =  { 
       title: loc.dataQuality, 
       itemId:'dqi',
       items:[

         { 

           xtype:'panel',
           //title:'gallery-panel',  
           cls:'xty_gallery-panel',
           itemId:'gallery-panel',
           border:false,
           layout: {
             type: 'hbox'
           },
           
           margin:'4 4 4 4',
           items:[
             { xtype:'button', text:'&lang;', cls:'xty_gallery-btn', height:galleryHeight, width:32,  margin:'0 2 0 0'},
             { 
               
               //title: 'Quality Channels',
               xtype:'panel',
               itemId:'gallery-content-panel',
               cls:'xty_gallery-content-panel',
               
               layout: {
                 type: 'hbox'
               },

               height:galleryHeight,
               width: galleryWidth,
               autoScroll:true,
               
               border:false,
              
               defaults:{
                 xtype:'panel',
                 margin:'4 0 4 4',
                 width:120,
                 height:120,
                 componentCls:'xty_gallery-content-panel',
                 listeners:{
                   afterrender: function(panel){
                     panel.getEl().on( 'click', channelsClickHandler, this);
                   }
                 }
               },  
               items:[
                    {html:'Web', name:'Web', itemId:'web', colslapsible:true},
                    {html:'Print', name:'Print', itemId:'print'},
                    {html:'Shop', name:'Shop', itemId:'shop'},
                    {html:'Ecommerce', name:'Ecommerce', itemId:'ecommerce'},
                    {html:'MediaPortal', name:'MediaPortal', itemId:'mediaportal'},
                    {html:'Productportal', name:'Productportal', itemId:'productportal'},
                    
                    {html:'Web2', name:'Web2', itemId:'web2'},
                    {html:'Print2', name:'Print2', itemId:'print2'},
                    {html:'Shop2', name:'Shop2', itemId:'shop2'},
                    {html:'Ecommerce2', name:'Ecommerce2', itemId:'Ecommerce2'},
                    {html:'MediaPortal2', name:'MediaPortal2', itemId:'mediaportal2'},
                    {html:'Productportal2', name:'Productportal2', itemId:'productportal2'}

                 ]
               },
               
               { xtype:'button', text:'&rang;', cls:'xty_gallery-btn',  height:galleryHeight, width: 32,  margin:'0 0 0 2'}
             
             
             
           ]
  
         }, // eo gallery panel   

         
         
         {title:'Details', itemId:'detailsPanel', width: panelsWidth, margin:panelsMargin, height:400, collapsible:true, collapsed:true,
            items:[rulesGrid]  
         },
         
         
         
         {title:'Productvariants', itemId:'childsPanel', width: panelsWidth, margin:panelsMargin,  height:200,  collapsible:true,
           
           
           items:[
             childrensDqiGrid
           ]  
         
           
         }
         
         
         
         
       ],
       
       
       listeners:{
         afterrender: function(panel){
           var applibar =  Ext.getCmp(panel.ownerCt.ownerCt.id).getApplicationBar();
           
         }
       }

       
      };
      
      
      var dqiMenuCfg =  {
         showSeparator : false,  
         componentCls:'xty_grouped-menu-noicons',
         items: [
         { text:'<b>Scope</b>', cls:'xty_menu-groupheader', activeCls:'xty_menu-groupheader-active'} ,
         { text: 'Product'},
         { text: 'Product and Variants' },
         { text: 'Product and Elements'},     
         { text: 'Product, Variants and Elements'},     
         ]
       };
      
      var regenerateBtnHandler = function(btn){
        
        
        
        var progressBar = Ext.create('Ext.ProgressBar', {
          width: 366,
          cls:'xty_progress-bar-striped',
          height:20,
          text: '8/888',
          value:  0.9
       });


        
        var progressBar = Ext.create('Ext.ProgressBar', {
          width: 300
       });

       // Wait for 5 seconds, then update the status el (progress bar will auto-reset)
        progressBar.wait({
           interval: 500, //bar will move fast!
           duration: 50000,
           increment: 15,
           text: 'Channel:<span class="xty_epob-dscr" style="font-style:italic;">&nbsp;&nbsp; WEB</span>',
           scope: this,
           fn: function(){
               p.updateText('Done!');
           }
       });
        
        
        var centerPan =  extVia.regApp.myRaster.getCenter();
        var progressWinX = centerPan.getWidth()+200;

        
       var progressWin = Ext.create('Ext.window.Window', {

          
          title:'Regenerating Dqi',
          
          cls:'xty_vg-progress-dialog',
          y:50,
          x:progressWinX,
          width: 200,
          layout: 'fit',
          border: false,
          items:[
            progressBar
          ]});
        
       progressWin.show();

        
      };
      
      var regenerateBtn=  { itemId:'dqi',  tooltip: 'Regenerate Data Quality', disabled:true, tabscope:'dqi', handler: regenerateBtnHandler};

      
      
//    '|',
//    {xtype:'tbspacer', width:360},
// { itemId:'revalidate-dqi',  tooltip: 'Revalidate Data Quality', xtype:'splitbutton', tabscope:'dqi', menu:dqiMenuCfg},
// { itemId:'loop',  tooltip: 'Regenerate Data Quality',xtype:'splitbutton',  tabscope:'dqi', menu:dqiMenuCfg},
//   dqiBtn
// { itemId:'revalidate-gauge',  scale:'large', tooltip: 'Regenerate Data Quality',xtype:'splitbutton',  tabscope:'dqi', menu:dqiMenuCfg},
      
      
      subTabPanelCfg.pagetoolbarBtns =[  {xtype:'tbspacer', width:30}, regenerateBtn ];

      return subTabPanelCfg; 
    }
      
   
	
 }// eo dqiStatics



});
