
Ext.define('extVia.hierarchy.statics', {
    statics: {

 
   showExplorerPanel : function(cfg, epob){
     extVia.notify({action: 'Öffnen (Doppelclick)'  , mssg:  'Explorer <i>'+epob.dscr+'</i> '}); 
   },
      
  getHierarchyTabCfg : function(cfg){
	  
      //extVia.regApp.showExplorerPanel = extVia.hierarchy.statics.showExplorerPanel;

	  var myContentPanelHeight =  extVia.regApp.myRaster.getWest().getHeight() -52 ;
	  
	  var treeStores = extVia.stores.initTreeStores();

    
	  
	  var elementsTreeOnly = cfg.elementsOnly;

	  
    
    var openHistoryTab = function (item){

      var historyviewCfg = {show:true, smallcards:false};      
      historyviewCfg = item.historyviewCfg;  
      
      var epob =  { historyviewCfg: historyviewCfg, dscr :"Metabo Power Maxx", epobId :"Metabo_Power_Maxx", epobTypeId :2020 , breadcrumb: item.breadcrumb};
      
      if (historyviewCfg.eastTab){
      
        var east = extVia.regApp.myRaster.getEast();
        if (east){
          var eastTabPan = extVia.regApp.myRaster.getEastTabPanel();
          
          
          east.setWidth(296);
          
          if(!eastTabPan){
            eastTabPan = extVia.regApp.myRaster.initEastTabPanel();
	        //var tabPan = centerTabPan;
	        extVia.regApp.eastTabPan = eastTabPan;
	        extVia.regApp.myRaster.addToEast(eastTabPan);
          }       
           eastTabPan.add({title:'Historie: <span style="font-weight:normal;">Metabo Power Maxx </span>', itemId:'history',autoScroll:true, border:false,  bodyBoarder:false, height: extVia.regApp.myRaster.getCenter().getHeight()-28, 
           tbar:{items:[{xtype:'triggerfield', width:246,  hidxden:true, cls : 'xty_inside-trigger', trigger1Cls : 'xty_search-inside-trigger',  trigger2Cls :'sss', margin:'0 0 0 8'}]},
           html:'<img id="historyTabCardViewEast" src="../img/fakes/history/historyTabCardViewEast_09.png"/>'});
        }

      }
      
      else{
	      var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
	      var epobEditorTab = centerTabPan.getComponent('epobEditorPanel'+epob.epobId); 
	      if (epobEditorTab){epobEditorTab.close();}
	      var editorTab = centerTabPan.addAndActivate(extVia.editor.baseEditor.statics.getEpobEditorPanelCfg({},epob));
	      centerTabPan.setActiveTab(editorTab);
      }
    };
    


   var showOptionSettingsBuffered = Ext.Function.createBuffered( 
        function(item){
         //var optionsmenu =  item.ownerCt; // item is always null when buffered
         var optionsmenu =  Ext.getCmp('optionsmenu');

         var searchChecked = optionsmenu.getComponent('search').checked;
         var createChecked = optionsmenu.getComponent('create').checked;
         var editChecked = optionsmenu.getComponent('edit').checked;
         var deleteChecked = optionsmenu.getComponent('delete').checked;
         var filenameChecked = optionsmenu.getComponent('filename').checked;
         var adminChecked = optionsmenu.getComponent('admin').checked;

         var optionsettings='<div style="text-align:left;">'+
           '<input type="checkbox" disabled '+(searchChecked?' checked ':'')+'> Suchen :'+searchChecked+'<br>'+   
           '<input type="checkbox" disabled '+(createChecked?' checked ':'')+'> Erstellen :'+createChecked+'<br>'+
           '<input type="checkbox" disabled '+(editChecked?' checked ':'')+'> &Auml;ndern :'+editChecked+'<br>'+
           '<input type="checkbox" disabled '+(deleteChecked?' checked ':'')+'> L&ouml;schen :'+deleteChecked+'<br>'+   
           '<input type="checkbox" disabled '+(filenameChecked?' checked ':'')+'> Dateiname :'+filenameChecked+'<br>'+   
           '<input type="checkbox" disabled '+(adminChecked?' checked ':'')+'> Administrator :'+adminChecked+'<br>'+
           '</div>';

         extVia.notify({action: 'Sende ver&auml;nderte Optionen '  , mssg:  optionsettings});   
       }
  
       , 1600, this) ;
   

   

 var itemOpenEditor = function( view, record, item, index, evt, eOpts ){
  
     var breadcrumbSeparator = null; //'/'; // default is /   breadcrumbSeparator = '|'; 
     var breadcrumb = record.getPath('text', breadcrumbSeparator); 
     //var breadcrumb = record.getPath('text'); //, breadcrumbSeparator); 
   
     var cfg = {
          record:record, evt:evt
        };
        var epobTypeId  =  record.get('epobTypeId');
        if (!epobTypeId){
          var iconEpobType = record.get('iconCls');
          if (iconEpobType){
            iconEpobType=iconEpobType.replace(/xty_epob/, '');
            iconEpobType=iconEpobType.toUpperCase();
            if ( extVia.module.epob[iconEpobType]){
             epobTypeId =  extVia.module.epob[iconEpobType];
            }
          }
        }
      var epob = {
        dscr:record.get('text'),
        epobId:  record.get('epobId'),
        epobTypeId :  epobTypeId,
        breadcrumb:breadcrumb,
        breadcrssumbSeparator: breadcrumbSeparator
      };
      
      
      var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
        if (!epob.epobTypeId){  
          extVia.notify({action: 'Ändern (Doppelclick)'  , mssg:  'missing <i>'+epob.dscr+'</i> epobTypeId '}); 
        }
        else if (epob.epobTypeId=== extVia.module.epob.CATEGORY){
          extVia.regApp.showExplorerPanel(cfg, epob);
        }     
        else if (extVia.editor){
          var editorTab = centerTabPan.addAndActivate(extVia.editor.baseEditor.statics.getEpobEditorPanelCfg({},epob));
           centerTabPan.setActiveTab(editorTab);
      }  
     };
    
   
     
     if (cfg.itemOpenEditor){
       itemOpenEditor = cfg.itemOpenEditor;
     } 
     
    
      var listenersCfg = {
	         beforeitemclick: function(treeview, record, item, index, evt, eOpts) {
	            if (record.raw && record.raw.disabled === true) {                
                  return false;
	            }
	            return true;
	         },
             beforeitemdblclick: function(treeview, record, item, index, evt, eOpts) {
              if (record.raw && record.raw.disabled === true) {                
                  return false;
              }
              return true;
             },
             beforeitemmousedown: function(treeview, record, item, index, evt, eOpts) {
              if (record.raw && record.raw.disabled === true) {                
                  return false;
              }
              return true;
            },
            beforeitemcontextmenu: function(treeview, record, item, index, evt, eOpts) {
              if (record.raw && record.raw.disabled === true) {
                  evt.stopPropagation();
                  return false;
              }
              return true;
             },    
        
	        itemcontextmenu: function( view, record, item, index, evt, eOpts ){
	          evt.preventDefault();
            

	          var breadcrumb = record.getPath('text'); //, breadcrumbSeparator); 
            
	          var epob = {
	            dscr:record.get('text'),
	            epobId:  record.get('epobId'),
	            epobTypeId :  record.get('epobTypeId'),
	            breadcrumb: breadcrumb
	          };
	
	          var hierachiesMenu = Ext.create('Ext.menu.Menu', {
	            //width: 100,
	            //height: 100,
	            margin: '0 0 10 0',
	            items: [{
	            text: '&Auml;ndern', iconCls:'x-tool x-tool-edit',
                handler:function(){
                  var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
                  var editorTab = centerTabPan.addAndActivate(extVia.editor.baseEditor.statics.getEpobEditorPanelCfg({},epob));
                  centerTabPan.setActiveTab(editorTab);
                } 
	            },
                
                '-',  
                
                {
                text: 'History',iconCls:'xty_icon xty_iconExpired',
                menu:[
                   //{text: 'Historie' },
                   {text: 'Historie cards ', breadcrumb:breadcrumb, handler: openHistoryTab, historyviewCfg : { cards: true, show:true, smallcards:false} },
                   {text: 'Historie small', breadcrumb:breadcrumb, handler: openHistoryTab , historyviewCfg : {cards: true, show:true, smallcards:true} },
                   
                   {text: 'Historie Ost', breadcrumb:breadcrumb, handler: openHistoryTab , historyviewCfg : {cards: true, show:true, eastTab:true, smallcards:true} },
                   
                   {text: 'Historie Grid', breadcrumb:breadcrumb,  handler: openHistoryTab , historyviewCfg : {cards: false, show:false} }
                
                
                ]
                },
                
                
                
                {
	              iconCls:'x-tool-latestVersion', text: extVia.locales.latestVersion, handler:function(){extVia.versionsProto.statics.showVersionView (epob);}
	            },{
	              iconCls:'xty_pgtoolbar-view-diff', text: 'Vergleich', handler:function(){extVia.regApp.showDiffPanel(epob);}
	            },              
                '-',
                {
                iconCls:'x-tool x-tool-explore', text: 'Inhalte anzeigen', handler:function(){extVia.regApp.showExplorerPanel(epob);}
              },
	            

	             {text:'Optionen',
	               menu: {   
	                 id:'optionsmenu', // needed for buffering
	                 itemId:'optionsmenu',
	                 defaults:{
                     handler: showOptionSettingsBuffered
	                 },
                   items: [
                       {text:'Suchen', itemId:'search', checked:false},
                       {text:'Erstellen', itemId:'create', checked:false},
                       {text:'&Auml;ndern',itemId:'edit', checked:false},
                       {text:'L&ouml;schen',itemId:'delete', checked:false},
                       {text:'Dateiname',itemId:'filename', checked:false},
                       {text:'Administrator',itemId:'admin', checked:false}
                     ]
	               }
	             },
	             

               
               {text:'Optionen 2',
                 menu: {   
                   id:'optionsmenu2', 
                   itemId:'optionsmenu2',
                   showSeparator :false,
                   items: [
                     {xtype: 'form', 
                      defaults:{
                        margin:'4 4 4 4'
                      },
                     items:[
                       {boxLabel:'Suchen', xtype: 'checkbox', itemId:'search', checked:false},
                       {boxLabel:'Erstellen', xtype: 'checkbox', itemId:'create', checked:false},
                       {boxLabel:'&Auml;ndern',xtype: 'checkbox', itemId:'edit', checked:false},
                       {boxLabel:'L&ouml;schen',xtype: 'checkbox', itemId:'delete', checked:false},
                       {boxLabel:'Dateiname',xtype: 'checkbox', itemId:'filename', checked:false},
                       {boxLabel:'Administrator',xtype: 'checkbox', itemId:'admin', checked:false}
                       
                     ],
                     buttons:[{text:'&Uuml;bernehmen',xtype: 'button', itemId:'save'}  ]
                     }
                   ]
                 }
               }
	             
	            
	            ]
	        });  
	        hierachiesMenu.showAt(evt.getXY());
	        },
	        


	        
	        itemclick: function( view, record, item, index, evt, eOpts ){
	          // for remote opening
	          if (evt.target.openEditor){
	            itemOpenEditor( view, record, item, index, evt, eOpts );
	          }
	        },
	        
	        itemdblclick: function( view, record, item, index, evt, eOpts ){
	          itemOpenEditor( view, record, item, index, evt, eOpts );
	        } 
        };
    
    
      
      
      
    
	  var productsTreePan = Ext.create('Ext.tree.Panel', {
	        cls:'xty_hierarchy-tree-panel',
	      hidden:elementsTreeOnly,
	    	region:'center',
			  rootVisible:true,
	        store: treeStores.productsStore,
	        border: false,
			//resizable:true,
			height: 2*myContentPanelHeight/3,
			bodyBorder:false,
	        preventHeader: true,
	        header: false,
	        hideHeader: true,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true,
		    listeners: listenersCfg	
	    });
        
	  
	 
	  var elementsRegion = elementsTreeOnly  ? 'center' : 'south';
	  
	  var  elementsTreePan = Ext.create('Ext.tree.Panel', {
	    region: elementsRegion,
			split: true,
			rootVisible:true,
			store: treeStores.elementsStore,
			border: false,
			bodyBorder:false,
			height: myContentPanelHeight/3,
	        preventHeader: true,
	        header: false,
	        hideHeader: true,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true,
            listeners: listenersCfg
	    });
	  
	  
	  var hierarchyTabTitle = elementsTreeOnly  ? extVia.locales.categories : extVia.locales.hierarchies ;
	   var hierarchyTabCfg = 	
	     {title: hierarchyTabTitle,
		   id : 'hierarchy',
		   itemId : 'hierarchy',
		   height: myContentPanelHeight,
		   refresh:function(){extVia.notify({action: '"refresh on'  , mssg:  this.title});},
		   moveHoriz:function(){extVia.notify({action: '"moveHoriz on'  , mssg:  this.title}); },
		   layout:'border',
    	   tbar:['->',
               {iconCls:'xty_pgtoolbar-showPermissions', 
                tooltip: 'Berechtigungen einblenden',
                 handler:function(button){
                  var bodyEl = Ext.getBody();
                  if (bodyEl.hasCls('xty_node-permissions-show-big')){bodyEl.removeCls('xty_node-permissions-show-big'); button.setTooltip('Berechtigungen einblenden'); button.setIconCls('xty_pgtoolbar-showPermissions');}
                  else if (bodyEl.hasCls('xty_node-permissions-show')){bodyEl.removeCls('xty_node-permissions-show');bodyEl.addCls('xty_node-permissions-show-big');button.setIconCls('xty_pgtoolbar-hidePermissions');button.setTooltip('Berechtigungen ausblenden');}
                  else{bodyEl.addCls('xty_node-permissions-show'); button.setTooltip('Berechtigungen grösser einblenden');}
                 }
               },
    	         {iconCls:'xty_pgtoolbar-list', 
				    border: false,
    		   		handler:function(){
    		   			
    		   			var actTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
    		   			var applibar  = actTab.getComponent('applicationbar');
    		   			var pgjobbar;
    		   			if (applibar){pgjobbar =  applibar.getComponent('pagejobbar');}
    		   			else{pgjobbar =  actTab.getComponent('pagejobbar');}
    		   			pgjobbar.showDropzone(pgjobbar);	
    		   		}
    	         }
    	   ],
    	   items:[ productsTreePan, elementsTreePan ]};
		   
		return hierarchyTabCfg;   

   },

	getHierarchyFakeTabCfg : function(cfg){
		
		
    	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip
    	var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
    	var hierachiesItemsHeight =  (mainContentPanelHeight)/2;
		
    	var title = cfg.title?cfg.title:'Hierarchie';
    	
    	if (cfg.titleOFF){
    		title=null;
    	}
    	
		var hierarchyFakeTabCfg = 	    		
	       {  
	    	   title: title,
	    	   id : 'hierarchyF',
	    	   itemId : 'hierarchyF',
	    	   border:false,
	    	   margins : '0 0 0 0',
	    	   layout:'fit',
	           items:[
  	    	        {
  	    	        	border:false,
	    	        	itemId:'hierarchiesPanel',
	    	        	height:800,
	    	        	
		    	    	defaults:{border:false, height:hierachiesItemsHeight},
	    	        	items:[
	    	        	       {   
	    	        	    	   // FakeClicker Panel hierarchies
	    	        	    	   itemId:'hierarchies', 
	    	        	    	   cls:'xty_fake-panel',
	    	        	    	   style:'background-image:url(../img/fakes/hierarchies.png);background-repeat:no-repeat',
	    	        	    	   bodyStyle:'background-color:transparent;', 
	    	        	    	   
	    	        	    	   layout: 'absolute',
	    	        	    	   
	    	        	    	   defaults:{
	    	        	    		   style:'background-color: transparent;',
	    	        	    		   height:16,width:16,
	    	        	    		   border:false,
	    	        	    		   xtype:'button',
	    	        	    		   handler:function(item){
	    	        	             		Ext.create('widget.uxNotification', {
	    	        	        				title:'fakeClick' ,
	    	        	        				position: 'tr',
	    	        	        				manager: 'instructions',
	    	        	        				cls: 'ux-notification-light',
	    	        	        				iconCls: 'ux-notification-icon-information',
	    	        	        				html :  item.itemId+'<br> clicked  at '+item.x + '-'+item.y,
	    	        	        				slideInAnimation: 'bounceOut',
	    	        	        				slideBackAnimation: 'easeIn'
	    	        	        			}).show();
	    	        	    		   },
	    	        	    		   cls:'xty_fake-panel-clicker',
	    	        	    		   x:280
	    	        	    	   },
	    	        	    	   items:[
	    	        	    	      { itemId:'metaboSTE-clicker', width:32, y:189, menXXu:[{text:'so what'}],
	    	    	        			epobTypeId : extVia.module.epob.PRODUCT, epobDscr:'Metabo STE',
	    	        	    	        handler:function(item){
	        				            	var tabPan = extVia.regApp.myRaster.getCenterTabPanel();
	        				            	
	        				            	if (tabPan){
		        				            	var epob= {dscr:item.epobDscr, epobTypeId:item.epobTypeId};
		        				            	var prodEdiTab = tabPan.add(extVia.editor.baseEditor.statics.getEpobEditorPanelCfg({},epob));
		        				            	tabPan.setActiveTab(prodEdiTab);
	        				            	}
	        				            	
	        				            },	
	    	    	        			listeners:{
	    	    	        				'dblclick':function(){extVia.notify({action: 'dblclick'  , mssg:  'dblclick'});},
	    	    	        				'contextmenu':function(){extVia.notify({action: 'contextmenu'  , mssg:  'contextmenu'}); }	
	    	    	        			}
	    	        	    	      }

    	        	                ] 
	    	        	       },
	    	        	       {itemId:'categories',html:'<img id="categories" src="../img/fakes/categories.png"/>'}
	    	        	       ]
	    	        }
	              ],
				listeners:cfg.listeners
	    	 } ;
		
		return hierarchyFakeTabCfg;
	},
	
	
	
  getStructureTreePanelCfg : function(cfg){
    var loc = extVia.locales;    

    var structureTreeStore = Ext.create('Ext.data.TreeStore', {
       root: {
           expanded: true,

           text: "Bohrmaschine",
           iconCls:'xty_epobProduct',
           children: [
               { text: "Audios"},
               { text: "Bilder", expanded: true, children: [
                   { text: "book report", leaf: true, iconCls:'xty_epobImage'},
                   { text: "alegrbra", leaf: true,  iconCls:'xty_epobImage'}
               ] },
               { text: "Texte"}
           ]
       }
     });

     
     var structureTreeStoreCfg = {
       root: {
           expanded: true,
           text: "Bohrmaschine",
           iconCls:'xty_epobProduct',
           children: [
               { text: "Audios"},
               { text: "Bilder", expanded: true, children: [
                   { text: "book report", leaf: true, iconCls:'xty_epobImage'},
                   { text: "alegrbra", leaf: true,  iconCls:'xty_epobImage'}
               ] },
               { text: "Texte"}
           ]
         }
     };
     
     
     
     
     var structureTreePanelCfg =  {
       title: loc.productstructure,
       useArrows : true,  
       viewConfig: {
         plugins: {
             ptype: 'treeviewdragdrop'
         }
       },
       itemId:'structureTreeTab',
       border:false,
       store: structureTreeStore,
       tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, 
         {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign',
         
         menu:{
           items:[
           {text:'Wurzelbehandlung', iconCls:'xty_epobAssignment',
             handler: function(){

               var title =  'Zuordnen';
               var mainInstr =  '';
               
               //mainInstr =  'In Ihrer Auswahl befinden sich Elementvarianten.'; // EPIM empfiehlt Ihnen, nur Wurzelelemente zuzuordnen';
               //mainInstr =  'In Ihrer Auswahl f&uuml;r die Elementzuordnung befinden sich Varianten von Elementen.';
               
               //mainInstr =  'EPIM empfiehlt Ihnen, nur Wurzelelemente zuzuordnen';
               //mainInstr =  'Soll EPIM die Wurzelelemente der Varianten f&uuml;r die Zuordnung verwenden?';
               
               mainInstr ='M&ouml;chten Sie wirklich Elementvarianten zuordnen?';
               
               var suppInstr =  '';
               
//               suppInstr = 'EPIM empfiehlt Ihnen, nur Wurzelelemente zuzuordnen, damit die Mehrsprachigkeit in Publikationen gew&auml;hrleistet ist.'+
//               '<br>Soll EPIM die Wurzelelemente der Varianten f&uuml;r die Zuordnung verwenden?';


               suppInstr = 
                 'In Ihrer Auswahl sind Elementvarianten enthalten.'+
                 '<br><br> Wir empfehlen Ihnen nur Wurzelelemente zuzuordnen, damit sprachunabh&auml;ngig geplant werden kann.';
  
                // 'Sollen die Wurzelelemente der Elementvarianten zugeordnet werden?'
                // +'<br><br>EPIM empfiehlt Ihnen, nur Wurzelelemente zuzuordnen, damit die Mehrsprachigkeit in Publikationen gew&auml;hrleistet ist.'

               
//                 'EPIM empfiehlt Ihnen, nur Wurzelelemente zuzuordnen, damit die Mehrsprachigkeit in Publikationen gew&auml;hrleistet ist.'
//                 +'<br><br>M&ouml;chten Sie die Wurzelelemente der Elementvarianten zuordnen?'

                 
                 
                 
               
             var assignVariantOrRootialog = Ext.create('widget.window', {
                   width: 500,
                   x: 300,
                   y: 120,
                   modal:true,

                   title:title,
                   iconCls:extVia.dialoges.getWindowIconCls('Question'),
                   
                   plain: true,

                   items : [ {
                       border : false,
                       minHeight : 200,
                       defaults : {
                          style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
                       },
                       items : [ 
                                extVia.dialoges.getInstructionPanel ({
                                  mainInstr: mainInstr,
                                  suppInstr:suppInstr
                                })
                                ]
                     }
                   ]
                   
                   ,buttons:[ 
                     {xtype:'tbspacer', width:30},
                     {text:'Elementvarianten zuordnen'},
                     {text:'Wurzelelemente zuordnen', cls:'xty_recommended-btn'},
                     {text:'Abbrechen', handler:function(button){ button.ownerCt.ownerCt.hide(); }}
                     
                   ]      
                      
               }) ;
               assignVariantOrRootialog.show();
               

             }  // eo menuitem handler
            } // eo menuitem Wurzelbehandlung 
           ] 
         } // eo menu                 
        }
       ]
     };

     return structureTreePanelCfg;
      
    }
	
	
	
	
    	
    }
});
