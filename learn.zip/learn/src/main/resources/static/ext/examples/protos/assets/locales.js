Ext.namespace('extVia.plainProto', 'extVia.locales' ,'extVia.assetsProto.locales');
/**
 * @class extVia.resourcesProto.locales
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2015/07/06 14:22:24 $
 *            $Revision: 1.4 $
 */

extVia.plainProto.locales = {
        appName:'assetsProto'
};

Ext.apply(extVia.locales, extVia.assetsProto.locales);



/*
 * 
 * $Revision: 1.4 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2015/07/06 14:22:24 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 