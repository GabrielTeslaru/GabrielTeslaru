
Ext.namespace('extVia.versionsProto.dummies');
Ext.define('extVia.versionsProto.statics', {
    statics: {
    	
  
	initDiffStore : function(cfg,epob){ 

// When working with  Associations         
//		Ext.define('Productinfo', {
//		    extend: 'Ext.data.Model',
//		    fields: [
//			        {name:"name"},
//		            {name:"area"},
//		         	{name:"dataType"},
//		         	{name:"multiplicity", type:'int'},
//
//
//		         	{name:"epimId"},
//		         	{name:"value"},
//		         	{name:"user"},
//		         	{name:"changedate"},
//		         	{name:"changetime"}
//           ]
//		});

		
		
// When working with  Inheritance    
		Ext.define('Info', { 
		    extend: 'Ext.data.Model',
		    fields: [		             
				    {name:"infoId"},
					{name:"name"},
			        {name:"area"},
			        {naxme:"dataType"},		            		             
		         	{name:"epobType"}, //{name:"epobArea"},
		         	{name:"name"},
		         	{name:"epimId"},
		         	{name:"parentId"},
		         	{name:"path"},
		         	{name:"language"},
		         	{name:"preview"},
		         	{name:"changeInfo"},//{name:"creationuser"},{name:"creationdatetime"},{name:"changeuser"},{name:"changedatetime"},
		         	{name:"attributes"}
           ]
		});
		
		
		Ext.define('ProductinfoDiff', {
		    extend: 'Info',
		    fields: [
//			        {name:"name"},
//		            {name:"area"},
//		         	{name:"dataType"},
		         	{name:"multiplicity", type:'int'},
		         	
		         	{name:"specprops"},
		         	
		         	{name:"isParent"},
		         	{name:"isChild"},
		         	
		         	{name:"childOrParent"},
		         	{name:"isLastChild"},
		

		         	{name:"epimIdWork"},
		         	{name:"valueWork"},
		         	{name:"userWork"},
		         	{name:"changedateWork"},
		         	{name:"changetimeWork"},
		         	
		         	{name: 'diff'},
		         	
		         	{name:"epimIdVersion"},
		         	{name:"valueVersion"},
		         	{name:"userVersion"},
		         	{name:"changedateVersion"},
		         	{name:"changetimeVersion"}
           ]
		});


       var diffData =[];
       if (cfg.historyView){
	   	 diffData =  extVia.versionsProto.statics.getEpobInformationDataWithAllVersions({allInfos:cfg.allInfos, infoId:cfg.infoId},epob);
	   }
	   else{
	   	diffData =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId);
	   }
       
       var store = Ext.create('Ext.data.Store', {
            model: 'ProductinfoDiff',
            sorters:cfg.sorters?cfg.sorters:null,
            storeId:'diff',
            data:  diffData
        });  
    	
    	return store;	
	}, 	
 
 
    getEpobInformationData : function(epobId){ 
      var epobInfoData ={
            "infoData" : extVia.versionsProto[epobId]
      };      
      return epobInfoData.infoData ?epobInfoData.infoData:[];
    },  
 
    getEpobInformationDataWithAllVersions : function(cfg,epob){ 

	  var dataWork =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId);
	  var dataVersion1 =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId+'_v1');
	  var dataVersion2 =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId+'_v2');
	  var dataVersion3 =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId+'_v3');
	  var dataVersion4 =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId+'_v4');
	  
	  var allVersionData = dataWork;
	  
	  var dateInfoIds = [];
	  
	  allVersionData =[];

	  var pushData = function(data2push){
        var i;
	  	for (i = 0; i < data2push.length; i++) {
		 	var row = data2push[i];
      
            var empstr = '';
      
			var dateInfoId = row.infoId + empstr +row.changedateWork+ empstr +row.changetimeWork;

			if(!Ext.Array.contains(dateInfoIds, dateInfoId )){

				var doPush = true;

				if (!cfg.allInfos){
					doPush =  (row.infoId === cfg.infoId);
				}
				dateInfoIds.push(dateInfoId);
				if (doPush){
					allVersionData.push(row);
				}		
			}
	    }
	  };
	  pushData(dataWork);pushData (dataVersion1);pushData (dataVersion2);pushData (dataVersion3);pushData (dataVersion4);
	    
      return allVersionData;
    }, 
    getEpobInformationDataWithVersion : function(epob, versionNr){ 
  
	   var epobInfoDataIdVers = epob.epobId+'_v'+versionNr;
	   var dataWork =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId);
	   var dataVersion =  extVia.versionsProto.statics.getEpobInformationData(epobInfoDataIdVers);

	   var mergedData=[];
       var wi;
	   for (wi = 0; wi < dataWork.length; wi++) {			
			var rowWork = dataWork[wi];
			var mergedRow = Ext.clone(rowWork);
            var vi;
			for (vi = 0; vi < dataVersion.length; vi++) {
				var rowVersion = dataVersion[vi];

				if (rowVersion.infoId === rowWork.infoId){
					mergedRow.valueVersion = rowVersion.valueWork;
					mergedRow.userVersion = rowVersion.userWork;
					mergedRow.changedateVersion = rowVersion.changedateWork;
					mergedRow.changetimeVersion = rowVersion.changetimeWork;
					mergedRow.epimIdVersion = rowVersion.epimIdWork;
					
					rowVersion.merged =true;
					break;	
				}
			}
			mergedData.push(mergedRow);	
		}
        var vj;
		for (vj = 0; vj < dataVersion.length; vj++) {
				var rowVersion2 = dataVersion[vj];
				if (!rowVersion2.merged){
					var singleRow = Ext.clone(rowVersion2);
					rowVersion2.merged =true;
					mergedData.push(singleRow);
				}	
		}
      return  mergedData; 
    }, 

    	
	
    gridDiffColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {

//   var diffStates=[
//	'unknown', 
//    'equals',
//    'diff', 
//    'diff-empty-work', 
//    'diff-empty-version', 
//
//    'diff-all', 
//
//    'dscr-unknown',
//    'diff', 
//    'dscr-diff',
//    'equals', 
//    'dscr-equals',
//    'diff-empty',
//    'dscr-diff-empty',
//    'equals-newly',
//    'equals-elder',
//
//    'diff-bydateonly diff-newly,  diff-bydateonly dscr-diff-newly',
//    'diff-bydateonly diff-elder,  diff-bydateonly dscr-diff-elder',
//    	
//    ];
//   
//   var pinfoStates =[
//               	'unknown',   'equals',
//                'single','empty',
//            	'newly',  'elder'
//        ];
    	
        metaData.tdCls ="xty_diffColumn";

		
		var diffy = extVia.versionsProto.statics.getRecordDiff(record);
		
        var diffChar = '&sim;';
    	//&Xi; &sube; &ne;  &Xi; &ne; &equiv; &asymp; &lang;&laquo; &equiv; &raquo; &cap; &cong;&cup;&sim;
        
        
        if (diffy.rowState==='equals'){diffChar = '=';}
        else if (diffy.rowState==='equals-bydateonly'){diffChar = ' &asymp;';diffChar = ' =';}
        else if (diffy.rowState==='diff-bydateonly'){diffChar = '  &ne;';}
        else if (diffy.rowState==='diff-empty-work'){diffChar = '  <';}
        else if (diffy.rowState==='diff-empty-version'){
          diffChar = ' >';
          if (diffy.rowEquals){diffChar = ' &asymp;';}        
        }
        metaData.trCls ="xty_diffRow-"+diffy.rowState;
        return '<div style="font-weight:bold;fsont-size:12px;padding:0px 4px 0px 4px;" class="'+diffy.rowState+'"> '+diffChar+'</div>';
    },
	
    
    getRecordDiff : function(record){
    	if (!record.diffy){        	
            var workValue = record.get('valueWork');
            var versionValue = record.get('valueVersion');
            var workDate = record.get('changedateWork')+record.get('changetimeWork');
            var versionDate = record.get('changedateVersion')+record.get('changetimeVersion');
            var workUser = record.get('userWork');
            var versionUser = record.get('userVersion');
            var diffy ={workDate:workDate,versionDate:versionDate,workValue:workValue,versionValue:versionValue, workUser:workUser,versionUser:versionUser};

            extVia.versionsProto.statics.compareRowByDateOnly(diffy);
    		record.diffy = diffy;
    	}
    	return record.diffy;
    },
    
	compareRowByDateOnly : function(diffy){
		diffy.workState = 'unknown';
		diffy.versionState = 'unknown';
		diffy.rowState = 'unknown';
		
		if (diffy.workDate !== diffy.versionDate){	  
			diffy.rowState = 'diff-bydateonly';
			diffy.rowEquals=false;
			diffy.workState = 'diff-'  + ((diffy.workDate>diffy.versionDate)?"newly":"elder");
			diffy.versionState = 'diff-' + ((diffy.workDate<diffy.versionDate)?"newly":"elder");

			if (diffy.workValue === diffy.versionValue){
				diffy.valueState='valueequals';
				diffy.valueEquals=true;
			}
			if (diffy.workUser === diffy.versionUser){
				diffy.userState='userequals';
				diffy.userEquals=true;
			}	
		}
		else{
			diffy.workState = 'equals'; 
			diffy.versionState = 'equals';
			diffy.rowState = 'equals-bydateonly';
			diffy.rowEquals=true;
		}
		
		if (!diffy.workValue){
			diffy.rowState = 'diff-empty-work';
			diffy.workState = 'diff-empty'; 
			diffy.versionState = 'diff-single';	
		}
		if (!diffy.versionValue){
			diffy.rowState = 'diff-empty-version';
			diffy.workState = 'diff-single'; 
			diffy.versionState = 'diff-empty';	
		}
		if (diffy.workValue || diffy.versionValue){
           var jslint ; 
		}	
	},
	
	compareRow : function(diffy){
		diffy.workState = 'unknown';
		diffy.versionState = 'unknown';
		diffy.rowState = 'unknown';
		
		if (diffy.workValue === diffy.versionValue){
			diffy.workState = 'equals';
			diffy.versionState = 'equals';
			diffy.rowState = 'equals';
    		if (diffy.workDate !== diffy.versionDate){	
    			diffy.workState = 'equals-'  + ((diffy.workDate>diffy.versionDate)?"newly":"elder");
    			diffy.versionState = 'equal-' + ((diffy.workDate<diffy.versionDate)?"newly":"elder");
    		}
		}
		else{
			diffy.workState = 'diff'; 
			diffy.versionState = 'diff';
			diffy.rowState = 'diff';
			
			if (!diffy.workValue){
				diffy.rowState = 'diff-empty-work';
    			diffy.workState = 'diff-empty'; 
    			diffy.versionState = 'diff-single';	
			}
			if (!diffy.versionValue){
				diffy.rowState = 'diff-empty-version';
    			diffy.workState = 'diff-single'; 
    			diffy.versionState = 'diff-empty';	
			}  
			
			//if (diffy.workValue && diffy.workValue){}

		}
		//alert(Ext.encode(diffy) ); //+" (diffy.workDate>diffy.versionDate) "+(diffy.workDate>diffy.versionDate)+" (diffy.workDate<diffy.versionDate) " +(diffy.workDate<diffy.versionDate));
	},
    
    
    gridDatatypeColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
        metaData.tdCls ="xty_lockedColumnFake ";
    	return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;'+value+'</div>';
    },

    gridDatetimeColumnRendererW: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    	return  value  +" <i>"+record.get('changetimeWork')+"</i>";
    },
    gridDatetimeColumnRendererV: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    	return  value  +" <i>"+record.get('changetimeVersion')+"</i>";
    },   
    
    gridAreaColumnRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    	metaData.tdCls ="xty_diffgrid-area";
    	return  value ;
    },     

    gridPinfoUserRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
		var diffy = extVia.versionsProto.statics.getRecordDiff(record);
		if (!diffy.rowEquals){
			if (diffy.userEquals){
				metaData.tdCls=" xty_diffgrid-diffequals xty_diffgrid-userequals ";
			}	
		}
		return value;
    },
    
    gridPinfoShowDetail: function (imgEl)  {
    	var detailWinId = imgEl.getAttribute("detailWinId"); 
    	
        var detailWin;
      
    	if (detailWinId){
    		detailWin = Ext.getCmp(detailWinId);
    		//if (detailWin){}
    		if (detailWin.isHidden()){
    			detailWin.show();
    		}
    		else{
    			detailWin.hide();
    		}
    			
    	}
    	else{

    		var imgOtherId  = imgEl.getAttribute("imgotherid"); 
    		
            var imgOtherEl = Ext.get(imgOtherId);
            var imgOtherSrc ;
            
            var hasOtherImage =false;
            if (imgOtherEl){
             imgOtherSrc = imgOtherEl.dom.src;
             hasOtherImage = true;
            }

    		
        	detailWin = Ext.create('widget.window', {
        		title:imgEl.getAttribute('title'),
        		width:240,
        		x:300,
        		layout:'hbox',
        		autoScroll: true,
        		items:[
        		       {border:false,html:'<img   src="'+imgEl.src+'"/>'},
        		       
        		       {border:false,width:30, hidden:!hasOtherImage },
        		       
        		       {border:false,html:'<img   src="'+imgOtherSrc+'"/>', hidden:!hasOtherImage}
        		       ],
        		listeners:{
        			afterrender:function(win){
        				var clickEl = Ext.get(win.id);
        				clickEl.on('click',function(evt, elem){ 
        					win.hide();
        				});
	
        			var wA = win.items.get(0).getWidth();
        			var wB = win.items.get(2).getWidth();
        			var gesamtW = (wA+wB+40);
        			if (gesamtW>1200){
        				gesamtW=1200;
        				win.setWidth(gesamtW);
        			}
        			if (win.getWidth()<gesamtW){
        				win.setWidth(gesamtW);
        			}
        			
        			var hA = win.items.get(0).getHeight();
        			var hB = win.items.get(2).getHeight();
        			var gesamtH = (hA+hB);
        			if (hA>800|| hB>800){
        				win.setHeight(800);
        			}        			
        			
        			if (win.getWidth()>900){
                        var jslint;
        				//win.setPosition(330,win.getPosition());
        			}
        			}
        		}       
        	});
        	imgEl.setAttribute("detailWinId",detailWin.id);
        	detailWin.show();
    	}	
    },
    
    dateFormatDe2EeX: /(.[^\.]*)(\.)(.[^\.]*)(\.)(....)/,// turns "30.04.2014" >> "2014/04/30";
    
    timeRelatedDiffFromDate: function ( dateStr)  {
     var timeStr ='-';

    // alert('timeRelatedDiffFromDate dateStr '+dateStr)
     
     var dateinPast = dateStr.replace(extVia.versionsProto.statics.dateFormatDe2EeX,"$5/$3/$1"); 
     
     var daysSince =   parseInt(extVia.versionsProto.statics.timeDiffFrom(dateinPast,"","d"),10);  
     var weeksSince;
     var monthsSince;
     var yearsSince; 

    if (daysSince<1){timeStr = '    ' +extVia.locales.today;}
    else if (daysSince<2){timeStr = '   ' +extVia.locales.yesterday;}
    else {
        weeksSince =   parseInt(extVia.versionsProto.statics.timeDiffFrom(dateinPast,"","w"),10);  
	    if (weeksSince<1){timeStr = '  ' +extVia.locales.thisweek;}
	    else if (weeksSince<2){timeStr = '  ' +extVia.locales.lastweek; }
	    else {
	      monthsSince =  parseInt( extVia.versionsProto.statics.timeDiffFrom(dateinPast,"","MO")); 
	      if (monthsSince<1){timeStr = ' ' +extVia.locales.thismonth;}
	      else if (monthsSince<2){timeStr = '' +extVia.locales.lastmonth;}
          //else if (monthsSince<4){timeStr = 'vor '+monthsSince+' Monaten';}
	      else {
	       yearsSince =   parseInt(extVia.versionsProto.statics.timeDiffFrom(dateinPast,"","y"),10);  
           if (yearsSince<1){timeStr = '' +extVia.locales.thisyear;}
           else if (yearsSince<2){timeStr = '' +extVia.locales.lastyear;}
           else {timeStr = '' +extVia.locales.alongtimeago;}
	      }
	    }
    }
    
     return timeStr ;//dateStr+" . . . . . .  "+timeStr+ "  d" +daysSince + "  w" +weeksSince + "  MO" +monthsSince + "  y" +yearsSince  ;
        
    },
    
 
    timeDiffFrom: function (dfrom,dto,selector){

	 //dfrom: Startdatum als String, "" f�r das aktuelle Datum/Zeit oder Date-Object
	//dto:   Enddatum als String, "" f�r das aktuelle Datum/Zeit  oder Date-Object
	//selctor: 'ms' Millisekunden, 's' Sekunden, 'm' Minuten, 'h' Stunden,
	// 'd' tage, 'w' wochen, 'y' ganze Jahre
	var r,dfy,dy;
	var osl = {ms:1,s:1000,m:60000,h:3600000,d:86400000, MO:(30*86400000),  w:604800000,y:-1};
	var df = typeof(dfrom)==="object" ? dfrom : dfrom==="" ? new Date() : new Date(dfrom);
	var dt = typeof(dto)=="object" ? dto : dto==="" ? new Date() : new Date(dto);
	var sl = osl[selector] || 1;
	var sz= sl >= osl['d'] ? (df.getTimezoneOffset()-dt.getTimezoneOffset())*60000 : 0;
	if(sl > 0) return (dt.getTime() - df.getTime() +sz)/sl;
	else { dfy = df.getFullYear();
       dy = dt.getFullYear() - dfy;
       dt.setFullYear(dfy);
       return (dt.getTime() < df.getTime()) ? dy -1 : dy; }
    },
    
    gridPinfoValueRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
     return extVia.versionsProto.statics.gridPinfoValueRendererByCfg( value, metaData, record, rowIndex, colIndex, store, view, {isVersionColumn:false} );
    },
    gridPinfoValueRendererVersion: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
     return extVia.versionsProto.statics.gridPinfoValueRendererByCfg( value, metaData, record, rowIndex, colIndex, store, view, {isVersionColumn:true} );
    },
 
    gridPinfoValueRendererByCfg: function ( value, metaData, record, rowIndex, colIndex, store, view, cfg )  {
		var diffy = extVia.versionsProto.statics.getRecordDiff(record);
		if (!diffy.rowEquals){
			if (diffy.valueEquals){
				metaData.tdCls=" xty_diffgrid-diffequals xty_diffgrid-valueequals ";
			}	
		}
	
		var dataType = record.get('dataType');
        var rowHasImage = false;
        var valueArr;
		var imgSrc;
    	var isFlag =   (dataType.toLowerCase().indexOf('flag')>-1 );
      
         var isString  = dataType.indexOf('String')>-1;
         if (isString){
           if (record.get('name').indexOf('EPIM Objekttyp')>-1){
            var html = '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_pinfo-datatype xty_epob'+value+'">&nbsp;'+value+'</div>';
            value = html;
           }
         }
	    var hasPipe = (value.indexOf('|')>-1 );
		if (hasPipe) {
			var valueArr = value.split('|');
			var imgSrc = valueArr[1];
			rowHasImage = true;
			value = valueArr[0];
		}
		
        if (hasPipe && !isFlag ){ 		
    		var imgWrapId = Ext.id();

    		var imgWrapId = "imgWrapId_"+rowIndex;
    		var imgWrapIdOther = "imgWrapIdOther_"+rowIndex;
        
            if (cfg.isVersionColumn){
              imgWrapId = "imgWrapIdOther_"+rowIndex;
              imgWrapIdOther = "imgWrapId_"+rowIndex;
            }

    		
    		var imgHeight='100';
            var isText  = dataType.indexOf('Text')>-1;
            
            if (isFlag){imgHeight='40';}
            if (isText){imgHeight='500';}
        
    		var imgId =imgWrapId.replace(/Wrap/,''); 
    		var imgOtherId =imgWrapIdOther.replace(/Wrap/,''); 
    		
            //var  imageIsExpanded = true; //record.imageIsExpanded;
            var  imageIsExpanded = record.imageIsExpanded;
            
            if (imageIsExpanded===undefined){
             imageIsExpanded = cfg.imagesExanded;
            }
            
            var displayImg = imageIsExpanded?'block':'none';
            var expandIcon = imageIsExpanded?'minus':'plus';
        
    		value=' <img style="cursor:pointer;" height="9px" onclick="extVia.versionsProto.statics.gridPinfoValueShowImage(this,\''+imgWrapId+'\',\''+imgWrapIdOther+'\',\''+rowIndex+'\');" src="../img/icons/'+expandIcon+'.gif"/> '
    			+ ( isFlag?'': value)
    			+'<div id="'+imgWrapId+'" style="display:'+displayImg+';height:'+imgHeight+'px;ovxerflow:scroll;posixtion:absolute;">'
    				+'<img  id ="'+imgId+'" height="'+imgHeight+'px"  onclick="extVia.versionsProto.statics.gridPinfoShowDetail(this);" title="'+value+'" imgotherid="'+imgOtherId+'" src="'+imgSrc+'"/>'
    			+'</div>';	
    	}
    	 
		 
       if (value && isFlag ){
		  if (hasPipe) {
			var imgHeight = 20;
			if (value ==='true') {
				value = '<img  height="'+imgHeight+'px"  title="'+value+'" onclick="extVia.versionsProto.statics.gridPinfoShowDetail(this);"  src="'+imgSrc+'"/>&nbsp;&nbsp;';
		    }
			else {value='';}
		 }
          var checked =  (value==="true")?'checked':''   ;
          if (rowHasImage){
            checked =  (valueArr[0]==="true")?'checked':''   ;
          }
          var html ='<input onclick="return false;" '+checked+' type="checkbox"/>'; 
          if (rowHasImage){
            //value=value+" "+html; 
			value=html+'&nbsp;&nbsp;&nbsp;&nbsp;'+value;
          }
          else{value=html; } 
       }
       else  if (dataType.toLowerCase().indexOf('language')>-1){
    		var html ='';  
    		var langsArr = value.split(',');
    		
    		for (var i =0; i<langsArr.length; i++){
    			var iso2 = langsArr[i];
    			
    			var langDscr = iso2;
    			var langTooltip = iso2;
    			var language =  extVia.stores.getLanguageFromISO2(iso2);
    			if (language){langDscr = language.dscr;langTooltip = langDscr+' ('+iso2+')';}
    			if (langsArr.length>4){
    			 langDscr='';
    			}
    			
    			html+= '<span style=height:18px;padding-left:16px;padding-right:4px;" title="'+langTooltip+'" class="xty_icon_'+iso2+'">&nbsp;'+langDscr+'&nbsp;</span> ';	
    			if (i%5===6){
    				html+='<br>';
    			}
    		}
    		value=html;  		
//    		var iso2 = value;
//    		var langDscr = iso2;
//    		var language =  extVia.stores.getLanguageFromISO2(iso2);
//    		if (language){langDscr = language.dscr;}
//    		value= '<span style=height:18px;padding-left:16px;padding-right:4px;" title="'+langDscr+'" class="xty_icon_'+iso2+'">'+' </span> ' + value;	
    	}
       else if (value && dataType.toLowerCase().indexOf('change')>-1 ){
        var value = extVia.versionsProto.statics.timeRelatedDiffFromDate(value);
       }
    return value;
    },
    
    gridPinfoValueShowImage: function ( htmlEl,imgWrapId, imgWrapIdOther , recordIndex)  {
      var otherImgEl = Ext.get(imgWrapIdOther);
      var grid = extVia.versionsProto.statics.getCurrentDiffGrid();
      var record = grid.store.getAt(recordIndex);

      if (htmlEl.src.indexOf("plus")>-1){
    		Ext.get(imgWrapId).show();	
    		if (otherImgEl){otherImgEl.show();	}
    		htmlEl.src =htmlEl.src.replace(/plus/,"minus");
            record.imageIsExpanded =true;
    	}
    	else{
    		Ext.get(imgWrapId).hide();
            if (otherImgEl){otherImgEl.hide();  }
    		htmlEl.src =htmlEl.src.replace(/minus/,"plus");
            record.imageIsExpanded = false;
            grid.store.filterBy(function(filterRecord, id){
	           var rowIsHidden = filterRecord.get('rowIsHidden'); 
	           if ( rowIsHidden){
	              return false
	            }
	            else{return true;}
           });        
    	}
    },
   
    
    gridPinfoDscrRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
		metaData.tdCls ="xty_lockedColumnFakXe xty_diffgrid-pinfo-dscr ";
    	return value;
    }, 


    getLinenumbersbarCfg : function(cfg, epob){
       
        var store  =  cfg.store;
        var storeCount = 100;
        if (store){
           storeCount = store.getCount();
        }
        
        var barWidth = cfg.barWidth?cfg.barWidth:18;
        
        var linenumbersbarItems =[];
        var hitItemHeight =4;
        
        
        var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28 -150 ;// tabstrip appbar tabstrip
        
        //var abstandStep= 3;
        var abstandStep =  (mainContentPanelHeight - hitItemHeight * storeCount) / storeCount;
        
        var abstand = 0;

        for (var rxi = 0; rxi <storeCount ; rxi ++){
          //var record = store.getAt(rxi);
          abstand+=abstandStep;
          
         if (rxi % 7 === 0 || rxi % 9 === 0 || rxi % 13 === 0)   {//record.get('changedateWork') !=record.get('changedateVersion')){ 
            linenumbersbarItems.push({id:''+(rxi+1), margin:abstand+' 0 0 0'} );
           abstand = 0;
          } 
        }
        
    var linenumbersbarCfg ={
            itemId:'diffgrid_linenumbersbar', 
            cls:'xty_linenumbersbar', 
            width:barWidth,
                height:400,
                border:true,
                defaults:{
                 height:hitItemHeight,
                 width:12,
                 xtype:'tbtext',
                 cls:'xty_linenumbers-hit-item',
                 overCls:'xty_linenumbers-hit-item-over',
                 scale:'small',
                  listeners:{
                    afterrender: function(item){
                      item.getEl().dom.title ="Zeile "+item.id;
                    }
                  }
                 
                },
               items:linenumbersbarItems,
               listeners:{
                  afterrender: function(tbar){
                    var tbarEl = Ext.get(tbar.id);
                    tbarEl.on('click',function(evt, elem){ 
                      var rowNr = parseInt(elem.id);  
                      var gridscrollerEl = Ext.getCmp(tbar.ownerCt.id).getEl().down('.x-scroller-vertical'); 
                      var gridscroller = Ext.getCmp(gridscrollerEl.id);
                      gridscroller.setScrollTop(  rowNr*25 -25 );
                    });       
                }
               }
          };
    
          
          return linenumbersbarCfg;
    },
    
    
    
    getDiffGrid : function(cfg, epob){
    	var myContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28 -50 ;// tabstrip

        var isCONTENT = false;

        if ( extVia.module.epob.getAreaId(epob.typeId) ===  extVia.module.epob.CONTENT ||  extVia.module.epob.getAreaId(epob.epobTypeId) ===  extVia.module.epob.CONTENT ){ 
          isCONTENT = true;
        } 



        var diffGridStore = extVia.versionsProto.statics.initDiffStore({diffView:true},epob); 
        
        var linenumbersbarCfg = extVia.versionsProto.statics.getLinenumbersbarCfg({store:diffGridStore, barWidth:34}, epob);

 
        var grid = Ext.create('Ext.grid.Panel', {
            //id:'diffGrid-'+epob.epobId,
    	    itemId:'diffGrid',
    	    multiSelect:true,
    	    rbar:linenumbersbarCfg,
        	autoScroll:true,
            height:myContentPanelHeight,
            border:false,
            //margin:extVia.regApp.myRaster.pgBoxMargins,
            store:diffGridStore,
       	    getColumnName:function(){        		                
       		 var columnFieldName = this.features[0].getGroupField();
                return  columnFieldName ;
       	    },              
            features: [Ext.create('Ext.grid.feature.Grouping',{
                groupHeaderTpl: 'grouped by <i>{[extVia.versionsProto.statics.getCurrentDiffGrid().getColumnName()]}</i> : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
            })], 

            
            viewConfig: {		    
            	stripeRows:false,  emptyText: extVia.editor.baseEditor.statics.getEmptyTextHTML(), deferEmptyText : false,
            	getRowClass: function(record){  	
            		var collCls =" xty_defaultRow";
            		
            		var isParent = false;
            		var isChild = false;
            		var childOrParent = record.get('childOrParent') ;           		
            		if (childOrParent){
                		isChild = childOrParent==="child" || childOrParent==="lastchild"   ; 
                		isParent = childOrParent==="parent" ;
                		
                		if (isParent){
                			var isCollapsed =  record.get('isCollapsed');
                			var openCls = isCollapsed?'collapsed':'expanded';
                			collCls =" xty_diffgrid-parent-row xty_diffgrid-parent-row-"+openCls+" ";
                		}
                		else if (isChild){
                			collCls =" xty_diffgrid-child-row ";
                			var isLastChild = record.get('isLastChild') || childOrParent==="lastchild";
                			if (isLastChild){
                    			collCls =" xty_diffgrid-child-row  xty_diffgrid-lastchild-row ";
                        	}
                    	}
            		}
            		
            		var diffy = record.diffy;
            		return "xty_diffRow-"+diffy.rowState+collCls;
            	}
            },
            

            //selModel: new Ext.selection.CellModel() ,//'cellmodel' ,
            listeners:{
              
                  'itemcontextmenu' :extVia.historyProto.statics.getInfoItemContextmenuHandler(cfg , epob),
    
            	  'itemclick' : function(view,  record, item, index, e, eOpt) { 
            		// alert(e.getTarget('.x-grid-cell-first')) ;
            		var isFirstColumn = e.getTarget('.x-grid-cell-first')!=null;   
                	if (isFirstColumn)  {
                	  
                	var isParent = record.get("childOrParent")==="parent";
                	if (isParent){
                      	var parentId = record.get('epimIdWork');
                      	
                      	var isCollapsed = record.get('isCollapsed');
                      	if (isCollapsed){
                      		record.set('isCollapsed',false);
                    		view.store.filterBy(function(filterRecord,id){
                    			var rowIsHidden = filterRecord.get('rowIsHidden'); 
                    			var myParentId = filterRecord.get('specprop-parentId'); 
                    			if (myParentId=== parentId){
                    				filterRecord.set('rowIsHidden',false); 
                    				return true;
                    			}
                    			else{
                    				if (rowIsHidden){return false;}
                    				else{return true;}
                    				}
                    		});
                      	}
                      	else{
                      		record.set('isCollapsed',true);
                    		view.store.filterBy(function(filterRecord, id){
                    			var rowIsHidden = filterRecord.get('rowIsHidden'); 
                    			var myParentId = filterRecord.get('specprop-parentId'); 
                    			if (myParentId=== parentId || rowIsHidden){
                    				filterRecord.set('rowIsHidden',true); 
                    				return false;
                    			}
                    			else{return true;}
                    		});
                      	}
                      }//eo isParent
                	
                  	}//eo if column ===0	
                }
            	
            },

            columns: [

                {xtype: 'rownumberer', width:30},
                { header: 'Bereich' , dataIndex:'area',  width:80,renderer:extVia.versionsProto.statics.gridAreaColumnRenderer},
                { header: 'B.order' , dataIndex:'areaorder',  width:36, hidden:true}, 

                { header: 'Vermehrbarkeit',dataIndex: 'multiplicity', width:20,hidden:true},
                { header: (isCONTENT?'Element':'Produkt' )+'information', width:160,dataIndex: 'name',sortable:true, renderer:extVia.versionsProto.statics.gridPinfoDscrRenderer, cls:'xsty_lockedColumnFake'},
                
                { header: 'Typ', width:31, dataIndex: 'dataType',renderer:extVia.versionsProto.statics.gridDatatypeColumnRenderer, cls:'xty_lockedColumnFake'},
                
                { header: 'Info Id',width:42,dataIndex: 'infoId', hidden:true},
                { header: 'Spezifische Properties',dataIndex: 'specprops', widsth:20,hidden:true},
                
                {  header:'Work', columns: [
	                { header: 'EPIM Id',width:42,dataIndex: 'epimIdWork', sortable:true, hidden:true},
	                { header: 'Wert',dataIndex: 'valueWork', width:220, sortable:true,  renderer:extVia.versionsProto.statics.gridPinfoValueRenderer},
	                { header: 'Benutzer', dataIndex: 'userWork',  sortable:true, renderer:extVia.versionsProto.statics.gridPinfoUserRenderer},
	                { header: 'Datum', dataIndex: 'changedateWork', sortable:true, width:125, renderer:extVia.versionsProto.statics.gridDatetimeColumnRendererW }
                ]},

                { header: 'DIFF', dataIndex: 'diff', width:36 , renderer:extVia.versionsProto.statics.gridDiffColumnRenderer},

                {  header:'Version', columns: [
	                { header: 'EPIM Id Version',dataIndex: 'epimIdVersion',sortable:true,width:42, hidden:true},
	                { header: 'Wert  Version',dataIndex: 'valueVersion', width:220, sortable:true, renderer:extVia.versionsProto.statics.gridPinfoValueRendererVersion},
	                { header: 'Benutzer  Version', dataIndex: 'userVersion',sortable:true,  renderer:extVia.versionsProto.statics.gridPinfoUserRenderer},
	                { header: 'Datum  Version', dataIndex: 'changedateVersion', width:125, sortable:true,renderer:extVia.versionsProto.statics.gridDatetimeColumnRendererV }
                ]}
            ]
           
        });
        
        return grid ;
    },
    
    epimDummyId: 1,
    getEpimDummyId : function(formPan){	// dummy Data generate Function  	
    	var c1 =formPan.getComponent('name').value.toLowerCase().substring(0,2);
    	var c2 =formPan.getComponent('areatype').getComponent('area').value.toLowerCase().substring(0,2);
    	var c3 =formPan.getComponent('areatype').getComponent('dataType').value.toUpperCase().substring(0,2);
    	return c2+""+c3+""+c1+""+(extVia.versionsProto.statics.epimDummyId++);
    },
    
    filterDiffGridStore: function (showType, store){
        store.filterBy(function(filterRecord, id){
           if (filterRecord.diffy.rowState.indexOf(showType)>-1){
                   filterRecord.set('rowIsHidden',false);
             return true;
          }
          else {filterRecord.set('rowIsHidden',true);}
        });
    },
    
    getDiffFilterButtonGroupCfg: function (cfg, epob){
      
       var filterDiffGridStore = extVia.versionsProto.statics.filterDiffGridStore ;
      
    	
    	var filterdiffGridHandler =function(item){
            var button = item.ownerCt.floatParent;
            button.setIconCls(item.iconCls);
            button.setTooltip(item.text);
            button.showType = item.showType;
        
    		var grid = extVia.versionsProto.statics.getCurrentDiffGrid();
    		var selectedRecords = grid.getSelectionModel().getSelection( );
    	
    		if (item.showType==='selection'){
    			grid.getStore().remove(selectedRecords);
    		}
    		else if (item.showType==='all'){
    			filterDiffGridStore('e',grid.getStore() ); 
    		}    		 
    		else {
    			filterDiffGridStore(item.showType,grid.getStore() ); 
    		}
    	};
    	
    	
    	var diffFilterButtonsGroupCfg = {
               itemId:'filterbuttons1',
               xtype: 'buttongroup',
               columns: 6,
               items: [     
                 {xtype:'splitbutton',iconCls:'xty_pgtoolbar-search', tooltip:'query' , scale:'small',   
                 	menu:{  
	    	    	   border:false,
	    	    	   margins : '0 0 0 0',
	    	    	   layout:'fit',
	    	           items:[
	    	                  {border:false,height:125,width:330,html: "<img style='' src='../img/fakes/versio-timeline-query.png'/>"}
	    	                  ]
	    	           }
                 	},        
                  {xtype:'splitbutton',iconCls:'xty_compared-icon-diff-all', itemId:'filters', tooltip:'filter',
                       menu:{ 
                    	defaults:{
                    		handler:filterdiffGridHandler
                    	},   
                       	items:[
                               {iconCls:'xty_compared-icon-diff-all',text:'Alle', name:'all', showType:'all'} , 
                               {iconCls:'xty_compared-icon-diff-allnosingles',text:'Alle keine Singles', name:'allnosingles', showType:'bydateonly'} , 
                               {iconCls:'xty_compared-icon-diff',text:'Unterschiede', name:'diff', showType:'diff'} ,
                               {iconCls:'xty_compared-icon-diff-nosingles',text:'Unterschiede keine Singles', name:'diffnoempty', showType:'diff-bydateonly'} ,
                               { iconCls:'xty_compared-icon-equals',text:'Gleiche', name:'equals', showType:'equals'} ,
                               { iconCls:'xty_compared-icon-diff-empty-work',text:'Singles Work', name:'singlesWork', showType:'empty-version'},
                               { iconCls:'xty_compared-icon-diff-empty-froz',text:'Singles Version',name:'singlesVersion', showType:'empty-work'} , 
                               { iconCls:'xty_compared-icon-diff-empty',text:'Singles', name:'singles', showType:'empty'},
                               { iconCls:'x-tool-filter',text:'Filtere Auswahl', name:'filter', showType:'selection'},
                               { iconCls:'xty_pgtoolbar-databaseviews',text:'Sichten', name:'filter', showType:'selection'}
                               ]	
                       	}
                       
                       },
                       
                       {xtype:'splitbutton',itemId:'versions', iconCls:'xty_menu-versioning-version', tooltip:'Versionen' , scale:'small',  
                        menu:{  
                          border:false,
                          margins : '0 0 0 0',
                          layout:'fit',
                          items:[
                            extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob, width:240, threeColumnsOnly:true},epob)
                          ]
                        }
                  }  
                       
                       
//                       {xtype:'splitbutton',iconCls:'xty_pgtoolbar-list', tooltip:'all', hidden:true,
//                           menu:{ 
//								defaults:{
//						      	  handler: function(item){ 												         		
//						         		var appUrl = location.href.replace(/protos.*/,"");
//						         		appUrl+="protos/"+item.url;
//						         		window.open(appUrl,"newwindow"); 
//						   			}  
//							    },
//                           	items:[
//                             { scale:'small', iconCls:'xty_pgtoolbar-list',text:'Liste', url:'versionsProto/versionsProto.html?regions=NC&scrollnaviButtonsLeft=true' } , 
//                             { iconCls:'xty_pgtoolbar-tree',text:'Baum' , url:'versionsProto/versionsProto.html?regions=NC&treeView=true'}, 
//                             { iconCls:'xty_pgtoolbar-thumbsBig',text:'Thumbnails', url:'versionsProto/versionsProto.html?regions=NC&matrixView=true'} ,
//                             { iconCls:'xty_pgtoolbar-thumbsSmall',text:'kleine Thumbnails'} ,
//                             
//                             { iconCls:'xty_pgtoolbar-thumbsSmall',text:'Spalten',
// 								defaults:{
// 							      	  handler: function(item){ 												         		
// 							         		alert("w+ioghw+�");
// 							   			}  
// 								    },
//	                             menu:{
//	                            	 items:[
//	 	                                   { iconCls:'',text:'diff flat'} ,
//		                                   { iconCls:'',text:'diff all'},
//		                                   { iconCls:'',text:'view work'} ,
//		                                   { iconCls:'',text:'view version'}
//		                                   ]
//	                             }
//                             	}	  
//	                        ]	
//                           }
//                        }  
                        
                       ]
           };
    	return diffFilterButtonsGroupCfg;
    },
    
    
    
    getAddPIMRowOkButtonHandler : function(button, evt, msg){	

    	var formPan = button.up("window").getComponent("myFormPanel");
    	if (formPan){
    		 var pinfoCfg ={};
    		 
    		 pinfoCfg = formPan.getForm().getValues();    		 
    		 
    		 //pinfoCfg.epimIdWork = extVia.versionsProto.statics.getEpimDummyId(formPan);
    		 //pinfoCfg.epimIdVersion =   pinfoCfg.epimIdWork; 

		     var datetime  = (""+new Date().getTime()).substring(4,10);
             pinfoCfg.infoId = extVia.versionsProto.statics.getEpimDummyId(formPan)+"_"+ datetime ;;

    		 extVia.dialoges.getInfoDialog({action:'Erstellen', width:600,mainInstruction:'Informationsdaten', info:""+Ext.encode(pinfoCfg)+","}).show(); 
			 //extVia.dialoges.getInfoDialog({action:'Erstellen', width:600,mainInstruction:'Informationsdaten', info:"\"infoId\":"+Ext.encode(pinfoCfg.infoId)+","}).show(); 
    		 var multiplicity = formPan.getComponent('specificPropertiesAttributes').getComponent('multiplicity');
    		 var multiplicityVal = parseInt(multiplicity.value);
    		 if (!multiplicityVal || multiplicityVal<1){
    			 multiplicityVal=1;
    		 }
    		 
    		 var gridStore =  extVia.versionsProto.statics.getCurrentDiffGrid().store;
    		 for (var i=0; i<multiplicityVal; i++){
    			 var pinfo = new ProductinfoDiff(pinfoCfg);
    			 gridStore.insert(0, pinfo);
    		 }	
    	}
    },
    
    getCurrentDiffGrid : function(){    
      var activeTab  = extVia.regApp.centerTabPan.getActiveTab();
      var currentGrid  = activeTab.getComponent('diffGrid');
      if (!currentGrid){
       var historyTabPanel = activeTab.getHistoryTabPanel();
       var currentGrid = historyTabPanel.getComponent('HistoryGrid'); 
      }
      
      return currentGrid;
    },
    
    getDiffGridPanelCfg : function(epob){
    	var tabItemId = epob.epobId;	

    	var addPIMRowHandler =function(){
    		var addPinfoDialog  = extVia.dialoges.getPinfoRowDialog({x: 400,y: 60});
    		addPinfoDialog.show();
			//if (1===1){saveGridHandler();}
    	};
		                
        var saveGridHandler =  function(){
        var diffGrid = extVia.versionsProto.statics.getCurrentDiffGrid();
        var diffStore = diffGrid.getStore();
          
        function getJsonOfStore(store){
                var datar = new Array();
                var jsonDataEncode = "";
                var records = store.getRange();
                for (var i = 0; i < records.length; i++) {
                    datar.push(records[i].data);
                }
                jsonDataEncode = Ext.encode(datar);
                return jsonDataEncode;
            } 
        extVia.dialoges.getInfoDialog({action:'Speichere versions Grid', x:350,y:50,width:1400,height:700, mainInstruction:'Informationsdaten Produktvergleich', info:""+getJsonOfStore(diffStore)}).show(); 
           
//                    var count = diffStore.getCount();
//                    for (var i =0; i <count; i++){
//                      var model = diffStore.getAt(i);
//                      
//                      model.fields.each( function(item, index , length){
//                         alert(i+" - "+Ext.encode(item.name)+": "+model.get(item.name));                        
//                      } )
//                    }
        }; 
    	
    	var	pagetoolbarButtons =[];	
    	var	pgjobButtons =[   
   	            { itemId:'addPIMRow', xstype:'splitbutton', iconCls : 'xty_pgtoolbar-addDataX',scale:extVia.constants.raster.pagetoolbarCenterBtnScale, tooltip:'Produktinformation hinzuf&uuml;gen', handler:addPIMRowHandler,
                 mensu:[ { itemId:'saveGridDate',  text:'save Grid', iconCls : 'xty_pgtoolbar-save-small',handler:saveGridHandler}]
                },
                extVia.versionsProto.statics.getDiffFilterButtonGroupCfg ({}, epob)

    	];	

    	
    	var epobTypeDscr = 'Produkt';
      
        // isCONTENT
        //if (epob.epobTypeId ===1010 || epob.typeId ===1010){ // Warum ist hier bei Products meist 0?
        if ( extVia.module.epob.getAreaId(epob.typeId) ===  extVia.module.epob.CONTENT ||  extVia.module.epob.getAreaId(epob.epobTypeId) ===  extVia.module.epob.CONTENT ){ 
          epobTypeDscr = 'Bild';
        } 

    	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28 -136 ;// tabstrip appbar tabstrip
    	//var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
    	
    	//&Xi; &sube; &ne;  &Xi; &ne; &equiv; &asymp; &lang;&laquo; &equiv; &raquo; &cap; &cong;&cup;&sim;
    	
    	var prodName = epob.dscr;
    	var pgjobEpobDscr =  prodName; //+' &nbsp;&sim;&nbsp; ';
    	
    	var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:epobTypeDscr+"vergleich ", epobDscr:pgjobEpobDscr,subEpobDscr:'letzte Version', subEpobDscrSeparator:' &nbsp;&sim;&nbsp; ', pgjobButtons: pgjobButtons} );

    	var diffGridPanelCfg = {
    				title:'&Delta; '+epob.dscr, 
    				tbar : applibar,
    				closable:true,
    				active:true,
    				itemId:tabItemId,
    				//stateId:tabItemId,
    				autoScroll:true,
	                getApplicationBar:function(){
						return applibar;
					},           
		            skip:function(cfg, epob){
		             var diffGrid = this.getComponent('diffGrid');
		             if (diffGrid){
	
					   var applibar = this.getApplicationBar();
				 	   if (applibar) {
					   	var subEpobDscr='';
					   	if (cfg.versionNr){
							subEpobDscr = '<i> Version ' + cfg.versionNr + ' &nbsp; ' + cfg.versionDate + '</i>';
							applibar.setSubEpobDscr(subEpobDscr);
						}
						else{
							applibar.hideSubEpobDscr();
                            //applibar.setSubEpobDscr('keine Version');
						}
					   }	
					   
					   var epobInfoDataIdWork = epob.epobId;
					   var epobInfoDataIdVers = epob.epobId+'_v'+cfg.versionNr;
					   
					   var data ;
					   var dataWork =  extVia.versionsProto.statics.getEpobInformationData(epob.epobId); 
					   var dataVersion =  extVia.versionsProto.statics.getEpobInformationDataWithVersion(epob, cfg.versionNr);
					   //var dataVersion =  extVia.versionsProto.statics.getEpobInformationData(epobInfoDataIdVers, cfg.versionNr);

					   if (!cfg.versionNr ||cfg.versionNr==='*'){
						 data = dataWork;
                       }
					   else{
					   	data = dataVersion;
					   }
                       diffGrid.store.loadData(data);
                       
                       var showType = applibar.getComponent('filterbuttons1').getComponent('filters').showType;
                       if (showType && showType.indexOf('all') ===-1){
                          extVia.versionsProto.statics.filterDiffGridStore(showType,diffGrid.getStore() ); 
                       }  
                 
                     }
		             else{ extVia.notify({action:'skip', status:'inactive', mssg:'no sub-Navi on diffGridPanel  Panel '});}
		             },
    				items:[      
                      extVia.versionsProto.statics.getDiffGrid({},epob)
                    ]
    				};
    	
    	return diffGridPanelCfg;
    },

    
	getVersionsItemsListCfg : function(cfg,epob){
        var title = '&nbsp;&nbsp;&nbsp;'+ (cfg.title?cfg.title:'Versionen'); //'subtabItems';      
		title = title;
        var itemId = cfg.itemId?cfg.itemId:'versions'; //'subtabItemsList';
        var iconCls = cfg.iconCls?cfg.iconCls:'xty_menu-versioning-version'; //'subtabItemsList';      
        var simpleGrid = cfg.simpleGrid;
		var threeColumnsOnly = cfg.threeColumnsOnly;

        return  {
    	    xtype:'grid',
    	    title:title,
            iconCls:iconCls,
            margin: cfg.margin ,
    	    closable: cfg.closable ,
    	    collapsible : cfg.collapsible,  
    	    itemId:itemId,
        	viewConfig: { emptyText: 'keine Versionseintr&auml;ge',deferEmptyText : false } ,
        	width:cfg.width,
        	//height:160,
			hideHeaders : simpleGrid || threeColumnsOnly,
        	
        	listeners:{
        		select:function(rowModel, record, index, eOpts ) {
                    var versionNr = record.get('versionNr');
        			var version = 'v'+versionNr+': '+record.get('date').replace(/(20\d\d)( .*)/,"$1");
                    var versionDate = record.get('date').replace(/(20\d\d)( .*)/,"$1");
                    var dscr = record.get('dscr');
           		   	var editorPanel = extVia.regApp.centerTabPan.getActiveTab();
                    if (editorPanel && editorPanel.skip){ editorPanel.skip({dscr:dscr, versionNr:versionNr , version:version, versionDate:versionDate},epob);}
                    else{  extVia.notify({action:'skip', status:'inactive', mssg:'no skip subNavi on '+editorPanel.title});}
        		},
        		itemclick:function(gridView,  record, item, index, e, eOpt) {
        		},
        		itemdblclick:function(gridView,  record, item, index, e, eOpt){
        			var dscr = record.get('dscr');
        			extVia.versionsProto.statics.showVersionView ({dscr:dscr});
        		}
        	},
            //margin:extVia.regApp.myRaster.pgBoxMargins,

            store:extVia.stores.initVersionsStore({},epob), 
            columns: [
                { header: 'Nr', dataIndex: 'versionNr', width:20, hidden:simpleGrid},
                { header: 'Name',  dataIndex: 'dscr' , width:simpleGrid?cfg.width-10:120, hidden:!simpleGrid || threeColumnsOnly },
                {  header:extVia.stores.getColumnHeaderTexWithIcon('Datum','xty_epobChangeInfo'), hidden:simpleGrid, dataIndex: 'date', width:105 },
                { header: 'Benutzer', dataIndex: 'user', hidden:simpleGrid,
                    filter: {
                        type: 'list',
                        options: ['small', 'medium', 'large', 'extra large']
                    }	
                },
                { header: 'Kommentar', dataIndex: 'comment', width:100,hidden:simpleGrid|| threeColumnsOnly   },
                { header: 'b. Sprachen',  width:40,hidden:simpleGrid || threeColumnsOnly , dataIndex: 'blockedLanguages',renderer:extVia.editor.baseEditor.statics.gridColumnFlagRenderer},
                { header: 'Tiefe', dataIndex: 'versionsdepht', width:34,hidden:simpleGrid || threeColumnsOnly  }
                //{ header: 'Verwendung', dataIndex: 'crossref', width:24, renderer:extVia.editor.baseEditor.statics.gridColumnImageRenderer},
            ]
           
        };
	},
    	
	
	
	 getVersionTabCfg : function(cfg,epob){

	    var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth()-24;// scroll
	    var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip

	    var subpanelListsinPage = extVia.regApp.viewCfg.subpanelListsinPage;  
	    var subpanelboxesFullWidth = !subpanelListsinPage?true:extVia.regApp.viewCfg.subpanelboxesFullWidth;
	   
	   
	   var versionTabCfg = {  
      title: extVia.locales.version+extVia.editor.baseEditor.statics.addTabChooser('version'),
      tabConfig: {
        //tooltip: 'version A button tooltip',
        itemId:'versionTab-tabitem',
        listeners:{
          click: function(tab, evt){  
            var className = evt.target.className;
            if (className.indexOf('x-tab-center')>-1){
              var abstandRight = evt.getX() - Ext.get(tab.id).getX() ;
              var isChooserClick = false;
              if (abstandRight>53){
                isChooserClick = true;
                alert(tab.itemId+' ChooserClick')
              }
              //alert(Ext.get(tab.id).getX()+' '+className+' evt '+evt.getX() +'abstandRight['+abstandRight+'] isChooserClick['+isChooserClick)
            }
          }
        }
        
        
      },
      
      id:epob.epobId+'-versionTab',
      itemId:'versionTab',        
      items:[
        
        {  
          itemId:'versionsGrid', 
          hidden:true,
          border:false,
          height: mainContentPanelHeight,
          html: '<img id="versionViewPanelIMG"  style"height:100%;" src="../img/fakes/versioning/versionsview_03.png"/>'
        }
      ]
	   }
	   
	  
	   
	   
     if (subpanelListsinPage){
       var subpanelList =  extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob,closable:true,width:subpanelboxesFullWidth?null:580, collapsible : true, margin:'24 24 24 24' },epob);
       versionTabCfg.items.unshift(subpanelList);
     }   
	   
	   
	   return versionTabCfg; 
	 },
	
	
	getVersionTabCfg_A : function(cfg,epob){
		
		var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth()-24;// scroll
		var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip

        var subpanelListsinPage = extVia.regApp.viewCfg.subpanelListsinPage;  
        var subpanelboxesFullWidth = !subpanelListsinPage?true:extVia.regApp.viewCfg.subpanelboxesFullWidth;

	    var versionTabCfg = {  
	    		   title: extVia.locales.version+extVia.editor.baseEditor.statics.addTabChooser('version'),
				   id:epob.epobId+'-versionTab',
	               itemId:'versionTab',
                   moreBtnCfg:{
                    dscr:'Versionen',                   
                    menuCfg:{ items:[  extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob,width:420},epob)]}
                   },
                   finderBtnGrpDscr:'Versionsdaten finden',
                   filterBtnGrpDscr:'Filtern',
	               autoxScroll:true,
	               border:false,
	               //defaults:{ // Valid for all subtab boxes
	            	   //width:580, 
	            	   //margin:'24 24 24 24', 
	               //},

	               getItemListButtonMenu : function(){ 
                     if (!this.menu){this.menu=Ext.create('Ext.menu.Menu', { items:[  extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob,width:420},epob)]});}
                     return this.menu;
                   },
	               removeSelectedEpobs:function(){
	            	   var grid = this.getComponent('versions');
	           		   var selectedRecords = grid.getSelectionModel().getSelection( );
	        		   if (selectedRecords){
	        			grid.getStore().remove(selectedRecords);
	        		   }  
	               },
            	   activate:function(tab){
					var task = new Ext.util.DelayedTask(function(){
					    tab.getComponent('subItemViewPanel').doLayout();
					});
			        task.delay(100);
					
           		   	var editorPanel = tab.ownerCt.ownerCt; 
           		    var applibar =  	editorPanel.getApplicationBar();
                    applibar.setSubEpobDscr("<i>v5</i>");
                    applibar.getComponent('pagetoolbar').getComponent('openDiff').show();
                     
            	   },
            	   deactivate:function(tab){
           		   	var editorPanel = tab.ownerCt.ownerCt; 
                    var applibar =  editorPanel.getApplicationBar();
                    applibar.hideSubEpobDscr();
                    applibar.getComponent('pagetoolbar').getComponent('openDiff').hide();
            	   },
	            
				width:extVia.regApp.myRaster.getCenter().getWidth()-2,
				rbar:  { 
					width:138,	
					scrollToTop : function(value){
    					Ext.get(epob.epobId+'-versionTab-body').scrollTo('top',value ,{duration:500});  
    				},
					defaults:{
	    				scale:'medium',
	    				width:130,
	    				textAslign : 'right',
						enableToggle:true,
						iconCls:'xty_scrollnavi-button',
						handler:function(button){
							if (button.ownerCt.lastButton){
    							button.ownerCt.lastButton.toggle();
    						}
							button.ownerCt.scrollToTop(button.top);
							button.ownerCt.lastButton = button;
						}
					},
        			items:[      
                	    {text:'Metadata', itemId:'scrollnavi-button_0',  top:0},
                	    {text:'Workflows', itemId:'scrollnavi-button_264', top:264},
                	    {text:'ChangeInfo', itemId:'scrollnavi-button_344',top:344},
                	    {text:'Attributes',itemId:'scrollnavi-button_424',  top:424},
                	    //{text:'Verwendung', top:80},
                	    {text:'&raquo; Referenzen', disabled:true,top:524},
                	    {text:'&raquo; Publikationen', disabled:true, top:120},
                	    {text:'Elemente',itemId:'scrollnavi-button_1410', top:1410},
                	    {text:'&raquo; Bilder', itemId:'scrollnavi-button_1411',top:1411},
                	    {text:'&raquo; Documente',itemId:'scrollnavi-button_1610', top:1610},
                	    {text:'&raquo; Tabellen', itemId:'scrollnavi-button_1640',top:1640},
                	    {text:'Beziehungen',itemId:'scrollnavi-button_1712',top:1712},
                	    //{text:'Lieferanten', top:240},
                	    {text:'Vorschauen', disabled:true, top:1900},	
                        {text:'&nbsp;',  itemId:'scrollnavi-button_2000',top:2000}
        	      ],
                
                  listeners:{
	                 afterrender:function(){
                        var scrollingPanel =   Ext.get(epob.epobId+'-versionTab-body');
                        var navibar = this;
                        var delayedScrollingTask = new Ext.util.DelayedTask(function(){
	                        var scrollNow = scrollingPanel.getScroll().top;
                            var buttonTops = [0,264,344,424,1410,1610,1640,1712, 2000];
                            var butTop = '0';
                            for ( var bti = 0; bti <buttonTops.length; bti++){
                                if (scrollNow < buttonTops[bti]  ){
                                   if (bti===0){butTop=0;}
                                   else butTop = buttonTops[bti-1];
                                   break;
                                }
                            }
                            
                            if (scrollNow >= 1712  ){butTop = '2000';}
                            
                            var correspondingButton  = navibar.getComponent('scrollnavi-button_'+ butTop);
                            if (navibar.lastButton && navibar.lastButton.pressed){
                              navibar.lastButton.toggle();
					        }
					        correspondingButton.toggle();
					        navibar.lastButton = correspondingButton;
                        });
                        scrollingPanel.on('scroll', function(e, t) {
	                     delayedScrollingTask.delay(10);
	                    });
	                 }
                  }
                  },
				  
	               items:[
                       	  
                 {
                            title:subpanelListsinPage?'Versionsansicht':null,
                            margin:subpanelListsinPage?'24 24 24 24':'0 0 0 0', 
                            lbar: extVia.versionsProto.statics.getLinenumbersbarCfg({}, epob),
                       	    itemId:'subItemViewPanel',
                            width:subpanelboxesFullWidth?null:580,
                       	    //wixdth:subpanelListsinPage?580:mainContentPanelWidth,
                            //height:816,
							autoScroll:true,
                       	    border:subpanelListsinPage,
                            border:true,
                            bodyStyle:'border: solid 1px #c5c5c5;',
                       	    collapsible : subpanelListsinPage,
                       	    //collapsed : subpanelListsinPage,
                       	    skip:function(cfg, epob){
                       	    	if (cfg && cfg.version){
                           		   	var editorPanel = extVia.regApp.centerTabPan.getActiveTab();
                           		   	var applibar = editorPanel.getApplicationBar();
									applibar.setSubEpobDscr('<i>'+cfg.version+'</i>');
                       	    	}
                       	    	this.expand();
                            	if (!this.previewCnt){
                            		this.previewCnt = 1;
                            	}
                            	if (this.previewCnt >7){this.previewCnt = 1;}
                            	
                    			Ext.get('versionViewPanelIMG').dom.src= '../img/fakes/versioning/versionsview_0'+(this.previewCnt++)+'.png';
                       	    },
                       	    
                            tools: !subpanelListsinPage?null: [{id:'next',  handler:function(evt, tool, panel){
                            	panel.ownerCt.skip();
                            	panel.ownerCt.ownerCt.getComponent('versions').collapse();
                            	var applibar = panel.ownerCt.ownerCt.ownerCt.ownerCt.getDockedComponent('applicationbar');
                            	applibar.collapse();	
                            }}],
                            
                            html: '<img id="versionViewPanelIMG"  style"height:100%;" src="../img/fakes/versioning/versionsview_03.png"/>'
                       	   }	   
	                ]	      	   
	        };
      
       if (subpanelListsinPage){
         var subpanelList =  extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob,closable:true,width:subpanelboxesFullWidth?null:580, collapsible : true, margin:'24 24 24 24' },epob);
         versionTabCfg.items.unshift(subpanelList);
       }   

	    return versionTabCfg;
	},

	
	
	 
  showVersioningProgress : function(cfg){

    
    var northPan =  extVia.regApp.myRaster.getNorth();
    var centerPan =  extVia.regApp.myRaster.getCenter();

    var northWidth = northPan.getWidth();
    var centerHeight = centerPan.getHeight();
   
    var progressWinWidth = 380;
    var progressWinHeight = 280;
   
    var progressWinX = northWidth - progressWinWidth +40;
    var progressWinY = centerHeight - progressWinHeight +80;
  
    
//    var progressStoreData = [];
//    var alphabeth = 'a,b,c,d,e,f,g,h,i,j,k,l,m,o,p,q,r,s,t,u,v,w,x,y,z';
//    var alphArr = alphabeth.split(',');
//    
//    //var statArr = 'Success,Inactive,Running,Loading,Started,Initialized,Uploading,Downloading,Stopping,Error,Warning,Success,Inactive,Running,Loading,Error,Warning,Success,Inactive,Running,Loading,Error,Warning,Success,Inactive,Running,Loading,Error,Warning,Success,Inactive,Running,Loading,Error,Warning,Success,Inactive,Running,Loading,Error,Warning,Success,Inactive,Running,Loading,Error,Warning,g,h,i,j,k,l,m,o,p,q,r,s,t,u,v,w,x,y,z'.split(',');
//    var statArr = 'Loading,Success,Success,Success,Loading,Success,Success,Success,Error,Loading,Success,Success,Success,Loading,Success,Success,Success,Error,Loading,Success,Success,Success,Loading,Success,Success,Success,Error,Loading,Success,Success,Success,Loading,Success,Success,Success,Error,Loading,Success,Success,Success,Loading,Success,Success,Success,Error,Loading,Success,Success,Success,Loading,Success,Success,Success,Error'.split(',');
//    
//    var epobArr = [
//      "Product", "","","","",
//      "ProductVariant", "","","","",
//      "ProductVariant", "","","","",
//      "ProductVariant", "","","","",
//      "ProductVariant", "","","","",
//      
//      
//      "Product", "ProductVariant","ProductVariant","ProductVariant","ProductVariant","ProductVariant",
//      "Product", "ProductVariant","ProductVariant","ProductVariant","ProductVariant","ProductVariant",
//      "Product", "ProductVariant","ProductVariant","ProductVariant","ProductVariant","ProductVariant",
//
//    ];
//
//    var epobNamesArr = [
//      "Bohrmaschine ", "Bohrmaschine",  "Bohrmaschine", "Bohrmaschine",  "Bohrmaschine",
//      
//      "Bohrmaschine A", "Bohrmaschine A",  "Bohrmaschine A", "Bohrmaschine A",  "Bohrmaschine A",
//      
//      "Handsäge ", "Handsäge",  "Handsäge", "Handsäge",  "Handsäge",
//      "Motorroller ", "Motorroller",  "Motorroller", "Motorroller",  "Motorroller",
//      "Käsereibe ", "Käsereibe",  "Käsereibe", "Käsereibe",  "Käsereibe",
//    ];
//    
//    var epobAreaArr = [
//      "", "Metadata",  "Attribute", "Elements",  "Relation"
//    ];
//    
//    
//    var epobIx = 0;
//    for (var i=0; i <alphArr.length; i++){
//      var char = alphArr[i];
//      
//
//      if (epobIx==epobArr.length){epobIx=0;}
//      
//      progressStoreData.push(
//          {epobType : epobArr[epobIx] , 
//
//            name:  epobNamesArr[epobIx] +' '+epobAreaArr[i],
//            epobArea:  epobAreaArr[i%5],
//            
//            status: statArr[i] 
//          } 
//          
//      );
//    }
//
//    
// //   var progressStoreDataA = Ext.Array.slice( progressStoreData , 0, 8);
//    
    
    
    var progressStoreData = [ 
       {epobType:"Product",epobArea: "Epob",name:"Bohrmaschine",status:"Loading"} ,
     
    ];
    
    

    var progressStoreDataAdd = [ 
      
      {epobType:"",epobArea: "Metadata",name:"Bohrmaschine <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Bohrmaschine <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Bohrmaschine <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Bohrmaschine <i>Beziehungen<i/>", status:"Loading"} ,

      {epobType:"ProductVariant",epobArea: "Epob",name:"Bohrmashi A <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Bohrmashi A <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Bohrmashi A <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Bohrmashi A <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Bohrmashi A <i>Beziehungen<i/>", status:"Loading"} ,
      
      {epobType:"ProductVariant",epobArea: "Epob",name:"Bohrmashi B <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Bohrmashi B <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Bohrmashi B <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Bohrmashi B <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Bohrmashi B <i>Beziehungen<i/>", status:"Loading"} ,      
 
      
      
      {epobType:"Product",epobArea: "Epob",name:"Motorroller",status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Motorroller <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Motorroller <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Motorroller <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Motorroller <i>Beziehungen<i/>", status:"Loading"} ,

      {epobType:"ProductVariant",epobArea: "Epob",name:"Vespa A <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Vespa A <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Vespa A <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Vespa A <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Vespa A <i>Beziehungen<i/>", status:"Loading"} ,
      
      {epobType:"ProductVariant",epobArea: "Epob",name:"Vespa B <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Vespa B <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Vespa B <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Vespa B <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Vespa B <i>Beziehungen<i/>", status:"Loading"} ,  
    
      
      
      {epobType:"Productgroup",epobArea: "Epob",name:"Drumcomputer",status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Drumcomputer <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Drumcomputer <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Drumcomputer <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Drumcomputer <i>Beziehungen<i/>", status:"Loading"} , 
   
      {epobType:"Product",epobArea: "Epob",name:"Roland TR 707",status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Roland TR 707 <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Roland TR 707 <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Roland TR 707 <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Roland TR 707 <i>Beziehungen<i/>", status:"Loading"} ,

      {epobType:"ProductVariant",epobArea: "Epob",name:"Roland TR 707",status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Roland TR 707 <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Roland TR 707 <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Roland TR 707 <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Roland TR 707 <i>Beziehungen<i/>", status:"Loading"} ,
      
      {epobType:"ProductVariant",epobArea: "Epob",name:"Roland TR 727 <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Metadata",name:"Roland TR 727 <i>Metadata<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Attribute",name:"Roland TR 727 <i>Attribute<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Elements",name:"Roland TR 727 <i>Elemente<i/>", status:"Loading"} ,
      {epobType:"",epobArea: "Relations",name:"Roland TR 727 <i>Beziehungen<i/>", status:"Loading"} ,
      
      {epobType:"ProductVariant",epobArea: "Epob",name:"Roland TR 626 <i>Elemente<i/>", status:"Loading"} ,
      
   ];
    
    
    
    
    var progressStore = Ext.create('Ext.data.Store', {
      fields: [{name:'epobType'},{name: 'epobArea'}, {name: 'name'},{name: 'status'}] ,
      data : progressStoreData
    }); 
    
    var totalCount = progressStoreDataAdd.length; //100;
    
    
//    var versioningProgressCountDisplay =  Ext.create('Ext.Button', {
//      itemId:'countDisplay', 
//      cls:'xty_count-display',
//      html: '8 /&nbsp;'+totalCount+'&nbsp;',
//      totalCount:totalCount,
//      selectionCount:8,
//      setTotalCount:function(totalCount){
//        this.totalCount = totalCount;
//        this.setCountValues();
//      },
//      setSelectionCount:function(selectionCount){
//        this.selectionCount = selectionCount;
//        this.setCountValues();
//      },
//      setCountValues:function(){
//        var selCountHtml='';
//        if (this.selectionCount>0){
//          selCountHtml ='<span class="xty_selectionCount">'+this.selectionCount+'</span>/';
//        }
//        else{
//          selCountHtml ='<span class="xty_selectionCount"></span>';
//        }
//        this.getEl().dom.innerHTML = selCountHtml+'<span class="xty_totalCount">'+this.totalCount+'&nbsp;</span>';
//      }
//    });
    
    
    
    
    var progressBar = Ext.create('Ext.ProgressBar', {
      width: 366,
      text: '8/'+totalCount,
      value:  0.2
   });
    
    
   // progressWinX=600
   // progressWinY=100
    
    

    


    var statusRenderer =   function (value, metaData, record, rowIndex, colIndex, store, view) { metaData.tdCls='xty_grid-status-cell';   return '<div data-qtip="' + value + '" class="xty_icon xty_icon'+value+'"></div>'; };
    var epobTypeRenderer = function (value, metaData, record, rowIndex, colIndex, store, view) { metaData.tdCls='xty_grid-epobType-cell'; return '<div data-qtip="' + value + '"style="height:18px;padding-left:16px" class="xty_epob' + value + '" ></div>';};

    
    var progressWin;
    
    var windowMinimizeHandler = function () {
     progressWin.tools['minimize'].hide();
     progressWin.tools['restore'].show();
     progressWin.orgHeight = progressWin.getHeight();
     progressWin.orgPosition = progressWin.getPosition();
     Ext.get(progressWin.id).setHeight(56);
     progressWin.getComponent('bottombar').getEl().setTop(24);
     progressWin.setPosition(   progressWin.orgPosition[0] ,   progressWin.orgPosition[1]+progressWin.orgHeight-progressWin.getHeight(), {duration:400});
    };

    var windowRestoreHandler = function () {
      progressWin.tools['minimize'].show();
      progressWin.tools['restore'].hide();
      progressWin.setHeight(progressWin.orgHeight);
      progressWin.setPosition( progressWin.orgPosition[0], progressWin.orgPosition[1], {duration:400});
      progressWin.restore();   
    };
    
    
    if (!cfg){
      cfg = {epobDscr:'BAM'}
    }
    
    
    progressWin = Ext.create('Ext.window.Window', {

      
      title:'Version erstellen:<span class="xty_epob-dscr" style="font-style:italic;">&nbsp;&nbsp;'+cfg.epobDscr+'</span>',
      
      cls:'xty_vg-progress-dialog',
      y:progressWinY,
      x:progressWinX,
      tools:[{type:'restore',itemId:'restore', handler: windowRestoreHandler, hidden:true}, {type:'minimize', itemId:'minimize', handler: windowMinimizeHandler}],
      height: progressWinHeight,
      width: progressWinWidth,
      layout: 'fit',
      borsder: false,
      border: false,
      items:[
        {  
          hideHeaders : true,
          xtype: 'grid',
          itemId:'versioningProgeressGrid',
          columns: [
            {header: 'epobType', dataIndex: 'epobType', width:32, renderer: epobTypeRenderer},
            {header: 'epobArea', dataIndex: 'epobArea', width:32, renderer: epobTypeRenderer},
            {header: 'Name', dataIndex: 'name',width:250},
            {header: 'Status', dataIndex: 'status', width:32, renderer: statusRenderer}
          ],                
          store: progressStore
       }
       ],       
       bbar:{
         itemId:'bottombar',
         height:30, items:[progressBar]
       },
       listeners:{
         afterrender: function(win){
           var headerEl = Ext.get( Ext.get(win.id).dom.firstChild.id);
           headerEl.on('click',function(){
             var isMinimized = !progressWin.tools['minimize'].isVisible();
             if (isMinimized){windowRestoreHandler();}
             else{windowMinimizeHandler();}
           })
         }
       }
    });
    
    progressWin.showAt(progressWinX, progressWinY, true);
    
    var versioningProgeressGrid =  progressWin.getComponent('versioningProgeressGrid');
    var gridscroller = versioningProgeressGrid.verticalScroller;

    var progressCount = 0;
    var progressStoreIxCount = 0;

    var updateProgress = function(){
      var progressInProz = ( totalCount/100 ) * progressCount;
      progressBar.updateProgress(  progressCount/  ( totalCount-2) , progressCount +'/'+totalCount );

      progressStoreIx=progressCount; 
      var datarow = progressStoreDataAdd[progressStoreIx];

      if (progressCount >=totalCount  ){
        updateProgressRunner.stop(task);
        progressWin.addCls('xty_progress-finished');
        progressWin.setTitle('Version erstellt');
      }
      else{
        if (datarow.epobType.indexOf('Product')>-1){
          progressWin.setTitle('Version erstellen:<span class="xty_epob-dscr" style="font-style:italic;">&nbsp;&nbsp;'+datarow.name+'</span>');
        }
      }

      var lastRecord =  progressStore.getAt(versioningProgeressGrid.lastAddedRecordIx);
      if (lastRecord) {
        lastRecord.set('status', 'Success');
       };

      
      var record = progressStore.add(datarow)[0];
      record.set('status', 'Loading')
      
      versioningProgeressGrid.verticalScroller.scrollByDeltaY(50);
      versioningProgeressGrid.lastAddedRecordIx = progressStore.count()-1;


      progressCount++; 
    } 
    var task = {
        run: updateProgress,
        interval: 200 //1 or a half second
    }
    var updateProgressRunner = new Ext.util.TaskRunner();
    updateProgressRunner.start(task);

  },
	
	

	
	
	getCreateVersionButtonCfg : function(cfg,epob,editorMainTabItemId, bNot4Menu, versionMode){
		
	  var createVersionsBtn;
	  
    var activateVersionTab = function(){
      var centerItem_0 = extVia.regApp.myRaster.getCenter().items.get(0);
      var centerTabPanel = (centerItem_0.getXType()==='tabpanel') ?centerItem_0: extVia.regApp.myRaster.getCenter().items.get(1) ; // Why is that
      var editorSubTabsPanel = centerTabPanel.getActiveTab().getComponent('editorSubTabsPanel');
      var versionTab = editorSubTabsPanel.getComponent('versionTab');
      
      if (!versionTab){  
        var versionTabCfg = extVia.versionsProto.statics.getVersionTabCfg(cfg,epob);
          versionTab = editorSubTabsPanel.add(versionTabCfg);
      }
      editorSubTabsPanel.setActiveTab("versionTab");
      
      
    };
    
    
    
	  var createNewVersion = function(cfg){
	      var callingBtn = cfg.callingBtn;

        var centerTabPanel =  extVia.regApp.myRaster.getCenterTabPanel();
        var editorTab = centerTabPanel.getActiveTab();
        var applibar = editorTab.getComponent('applicationbar');
        var pagetoolbar;
        var epobDscr;
        if (applibar){  
          pagetoolbar =  applibar.getComponent('pagetoolbar');
          epobDscr = applibar.getEpobDscr();
        }
  
	      if(!callingBtn){
          if (pagetoolbar){ callingBtn =  pagetoolbar.getComponent('versioning-create');}
	      }
	      
	      if(callingBtn){
	        //callingBtn.setDisabled(true);
	        callingBtn.addCls('xty_versioning-create-running');
	        callingBtn.hideMenu();
	      }
	      
	      activateVersionTab();

	      extVia.versionsProto.statics.showVersioningProgress({epobDscr:epobDscr});
	  };
	  
	  

	  
	  
	   var createVersionHandler = function(btn, evt){
	     
	     createNewVersion({callingBtn:btn});
	     
      // if (evt.hasModifier()){ }
    	 
    		
	   };


	  
	    var createVersionButtonMenuCfg = {
	    		items:[ 
	    		       {xtype:'form', title:'Version erstellen', 
	    		    	   itemId:'createVersionForm',
	    		    	   height:180,width:360,
	    		    	   defaults:{labelWidth:100, width:344},
	    		    	   items:[
	    		    	       {xtype:'tbspacer', height:8},
    		    	           {
	    		    	    	  fieldLabel:  '&nbsp;Umfang' , //'&nbsp;Versionierungstiefe',
	    		    	    	  labelSeparator:extVia.editor.baseEditor.statics.getLabelSeparator4Required(),
    		    	              itemId:'versionsDepht',
    		    	              emptyText:'Versionierungstiefe',
    		    	              store:extVia.stores.initVersionsDephtStore(), queryMode: 'local',displayField: 'dscr',  valueField: 'value',     
    		    	              xtype:'combo',
    		    	              name: 'versionsdepht',
    		    	              forceSelect:false,
    		    	              value:'-',
    		    	              allowBlank:false
    		    	              
    		    	          },
    		    	           {
	    		    	    	  fieldLabel:'&nbsp;Sprachen blockieren', hidden:true,
    		    	              itemId:'versioningBlockLang',
    		    	              emptyText:'Sprachen blockieren',
    		    	              multiSelect:true,
    		    	              store:extVia.stores.initLanguageStore(), queryMode: 'local',displayField: 'dscr',  valueField: 'iso2',     
    		    	              xtype:'combo',
    		    	              name: 'blockedLanguages',
    		    	              forceSelect:false,
 	                              listConfig : {
	                             	   minWidth:210,
	 	   	                           getInnerTpl : function() {
			                                var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
			                                return tpl;
				                       }
	                                }
    		    	          },
    		    	          {xtype:'textarea', height:86, itemId:'comment',name:'comment',fieldLabel:'&nbsp;Kommentar'},
	    		    	       {xtype:'tbspacer', height:8}
	    		    	       
	    		    	       ],   
	    		            buttons:[
	    		                 //{text:'&Uuml;bernehmen'},
	    		                 {text:'Erstellen', handler:function(formBtn){ createNewVersion({}); }}
	    		            ]
	    		       }
	    		    ]
	    };
	       
	    var createVersionButtonCfg = {
	        itemId:'versioning-create', 
	    		hidden:versionMode,
	    		text: bNot4Menu?'':'Erstelle Version', 
	    	  //xtype:bNot4Menu?'splitbutton':'menuitem',
	    		//xtype:'splitbutton',    // why no event on handler when splitbutton
	    		tooltip: 'Version erstellen', 
	    		value: 'create', 
	    		menu:createVersionButtonMenuCfg,
	    		handler: createVersionHandler,
	    		iconCls:'xty_pgtoolbar-versioning-create', 
	    		scale:extVia.constants.raster.pagetoolbarCenterBtnScale
	    };

	    return createVersionButtonCfg;
		
	},
	
    	
	showVersionView : function(epob){
		

		if (!extVia.versionsProto.showViewCnt){
			extVia.versionsProto.showViewCnt = 1;
		}
		else{
			extVia.versionsProto.showViewCnt++;
		}
		var showViewCnt = extVia.versionsProto.showViewCnt;
		
		var navbarCfg =null;
		var navbarWidth =0;
			navbarWidth =92;
			navbarCfg = { 
				width:138,	
				defaults:{
	    			scale:'medium',
	    			width:130,
	    			textAslign : 'right'
				},
        		items:[      
                	    {text:'Metadata'},
                	    {text:'Workflows'},
                	    {text:'ChangeInfo'},
                	    {text:'Attributes'},
                	    {text:'Verwendung'},
                	    {text:'&raquo; Referenzen'},
                	    {text:'&raquo; Publikationen'},
                	    {text:'Elemente'},
                	    {text:'&raquo; Bilder'},
                	    {text:'&raquo; Documente'},
                	    {text:'&raquo; Tabellen'},
                	    {text:'Beziehungen'},
                	    {text:'Lieferanten'},
                	    {text:'Vorschauen'}	    
        	                 
        	      ]};

		
		var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip
		var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
		
		var versionsMainTabItemId ="versionsMainTabItemId_"+epob.dscr;

		
		var deltaPanelScrollToThis = function deltaPanelScrollToThis(){} ;
		var deltaPanelScrollFirst = function deltaPanelScrollFirst(){} ;
		var deltaPanelScrollPrev = function deltaPanelScrollPrev(){} ;
		var deltaPanelScrollNext = function deltaPanelScrollNext(){} ;
		var deltaPanelScrollLast = function deltaPanelScrollLast(){} ;
		
		var versionsPgjobButtons=[	
              {trigger2Cls:'xty_form-trigger-search', xtype:'triggerfield',
            	  onTriggerClick:function(evt){
            		var me = this;
    				var myMenu = Ext.create('Ext.menu.Menu', {
    				    items: [ {  html:'<img width="330px" height="125px" src="../img/fakes/versio-timeline-query.png" >'	,handler:function(item){ myMenu.hide();}}],
    				    listeners:{	}
    				});
    				myMenu.showAt(evt.getXY());
            	}  
              },
              {xtype:'tbspacer' , width:10},  
              extVia.editor.baseEditor.statics.getContentSwitcherCfg({editorMainTabItemId:versionsMainTabItemId, epob:epob, versionMode:true},epob),
            {xtype:'tbspacer' , width:30},               
            {itemId:'listingFirst', iconCls:'xty_pgtoolbar-listingFirst' , scale:'small', handler:deltaPanelScrollFirst},
            {itemId:'listingNext', iconCls:'xty_pgtoolbar-listingNext' ,scale:'small', handler:deltaPanelScrollNext},
            {itemId:'listingPrev', iconCls:'xty_pgtoolbar-listingPrev' ,scale:'small', handler:deltaPanelScrollPrev},
            {itemId:'listingLast', iconCls:'xty_pgtoolbar-listingLast' ,scale:'small', handler:deltaPanelScrollLast}
		 ];
		

		
    	var pgjobEpobDscr =  epob.dscr;
    	var pgjobDscr =  'Produktversion';
    	var epobDscr =  'Produkt';
    	var isPRODUCT=true;
    	var isCONTENT=false;

      
        if ( extVia.module.epob.getAreaId(epob.typeId) ===  extVia.module.epob.CONTENT ||  extVia.module.epob.getAreaId(epob.epobTypeId) ===  extVia.module.epob.CONTENT ){
            pgjobDscr="Bildversion";
    		epobDscr="Bild";
    		isPRODUCT=false;
    		isCONTENT=true;
    	}
		
		
		var versTab = extVia.regApp.centerTabPan.addAndActivate({
			title:epob.dscr,
	    	rbar : navbarCfg,
			tbar:extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: pgjobDscr, epobDscr:epob.dscr+" (20.01.2014)", pgjobButtons: versionsPgjobButtons} ),
			closable:true,
			height:mainContentPanelHeight,	
			autoScroll:true,
			iconCls:'xty_tabItemVersionModifier',
			items:[ {autoScroll:true,xtype:'panel',border:false, height: mainContentPanelHeight-48, width:mainContentPanelWidth-140, style:'border-right:1px solid #99bce8;',
				html: "<img  src='../img/fakes/versioning/versionsview_0"+showViewCnt+".png'/>"}]
			
		});
	}

    }
});
