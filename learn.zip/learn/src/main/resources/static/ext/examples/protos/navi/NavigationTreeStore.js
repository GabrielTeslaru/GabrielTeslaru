


Ext.define('ExtVia.data.NavigationTreeStore', {
	extend: 'Ext.data.TreeStore',
	
	storeId : 'navigationStore',
	
	root : {
		iconCls : 'xty_navi-homeicon',
		text : '',
		children : [
			{text : 'viaCONTENT', children : [
				{text : 'Element', iconCls : 'x-btn-default-toolbar-large xty_epobElements' , children : [
					{text : 'Text', leaf : true},
					{text : 'Bild', leaf : true},
					{text : 'Grafik', leaf : true},
					{text : 'Redaktionelle-Tabelle', leaf : true},
					{text : 'Produkt-tabelle', leaf : true},
					{text : 'Dokument', leaf : true},
					{text : 'Video', leaf : true},
					{text : 'Audio', leaf : true}
				]},
				{text : 'Suche', leaf : true, iconCls : 'xty_pgtoolbar-search'},
				{text : 'Kategorien', leaf : true, iconCls : 'xty_pgtoolbar-dropbox'},
				{text : 'Importordner', leaf : true, iconCls : 'xty_pgtoolbar-editItem'},
				{text : 'XML-Import', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'},
				{text : 'CSV-Import', leaf : true, iconCls : 'xty_pgtoolbar-edit'},
				{text : 'Importplanung', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'}
			]},
			{text : 'viaPRODUCT', children : [
				{text : 'Suche', leaf : true, iconCls : 'xty_pgtoolbar-search'},
				{text : 'Hierarchien', leaf : true, iconCls : 'xty_pgtoolbar-dropbox'},
				{text : 'Massendaten-pflege', leaf : true, iconCls : 'xty_pgtoolbar-refresh'}
			]},
			{text : 'viaPUBLISH', children : [
				{text : 'Publikations- pflege', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'},
				{text : 'Produktion', iconCls : 'xty_pgtoolbar-dropbox', children : [
					{text : 'XML-Export', leaf : true},
					{text : 'XML-Exportplanung', leaf : true},
					{text : 'DTD-Export', leaf : true},
					{text : 'Exportarchiv', leaf : true}
				]}
			]},
			{text : 'adminCONTENT', children : [
				{text : 'Kategorie', leaf : true, iconCls : 'xty_pgtoolbar-dropbox'},
				{text : 'Unicode-zeichen', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'},
				{text : 'Element-attribute', leaf : true, iconCls : 'x-btn-default-toolbar-large xty_epobElements'},
				{text : 'Element-attributsicht', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'},
				{text : 'Dateiformat', leaf : true, iconCls : 'xty_pgtoolbar-editItem'},
				{text : 'Farbraum', leaf : true, iconCls : 'xty_pgtoolbar-searchShow '},
				{text : 'Bildver-arbeitung', leaf : true, iconCls : 'xty_pgtoolbar-searchDelete'},
				{text : 'W&ouml;rterbuch<br />&nbsp;', iconCls : 'xty_pgtoolbar-pagingFirst', children : [
					{text : 'W&ouml;rterbuch-eintrag', leaf : true},
					{text : 'W&ouml;rterbuch-kategorie', leaf : true}
				]},
				{text : 'XSD/DTD-Datei', leaf : true, iconCls : 'xty_pgtoolbar-refresh '}
			]},
			{text : 'adminPRODUCT', children : [
				{text : 'Hierarchie-stufe', leaf : true, iconCls : 'xty_pgtoolbar-search'},
				{text : 'Vergleichs-operator', iconCls : 'xty_pgtoolbar-pagingFirst', children : [
					{text : 'Operator', leaf : true},
					{text : 'Operaturen-gruppe', leaf : true},
					{text : 'Operatoren-zuordnung', leaf : true}
				]},
				{text : 'Einheit', iconCls : 'xty_pgtoolbar-dropbox', children : [
					{text : 'Einheit', leaf : true},
					{text : 'Einheiten-gruppe', leaf : true},
					{text : 'Einheiten-zuordnung', leaf : true}
				]},
				{text : 'Auswahl-gruppe', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'},
				{text : 'Produkt-attribut', leaf : true, iconCls : 'xty_pgtoolbar-editItem'},
				{text : 'Produktattri-butsicht', iconCls : 'xty_pgtoolbar-edit', children : [
					{text : 'Typ', leaf : true},
					{text : 'Sicht-zuordnung', leaf : true}
				]},
				{text : 'Beziehungstypen', iconCls : 'xty_pgtoolbar-refresh', children : [
					{text : 'Typ', leaf : true},
					{text : 'Sicht-barkeit', leaf : true}
				]},
				{text : 'Hierarchietyp', leaf : true, iconCls : 'x-btn-default-toolbar-large xty_epobElements'},
				{text : 'Lieferant', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Lieferanten-attribut', leaf : true},
					{text : 'Lieferanten-stamm', leaf : true},
					{text : 'Lieferanten-export', leaf : true}
				]}
			]},
			{text : 'adminPUBLISH', children : [
				{text : 'Editor', iconCls : 'x-btn-default-toolbar-large xty_epobElements', children : [
					{text : 'Struktur-element', leaf : true},
					{text : 'Struktur-gruppe', leaf : true},
					{text : 'Struktur-zuordnung', leaf : true},
					{text : 'Struktur-definition', leaf : true}
				]},
				{text : 'Feld', iconCls : 'xty_pgtoolbar-pagingFirst', children : [
					{text : 'Feldgruppe', leaf : true},
					{text : 'Feldzu-ordnung', leaf : true}
				]},
				{text : 'Format', iconCls : 'xty_pgtoolbar-refresh', children : [
					{text : 'Format-element', leaf : true},
					{text : 'Format-gruppe', leaf : true},
					{text : 'Format-zuordnung', leaf : true}
				]},
				{text : 'Exportformat', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Exportformat-gruppe', leaf : true}
				]},
				{text : 'Master-publikation', iconCls : 'xty_pgtoolbar-dropbox', children : [
					{text : 'Hierarchie-stufe', leaf : true},
					{text : 'Master-publikation', leaf : true},
					{text : 'Publikations-struktur', leaf : true}
				]},
				{text : 'Produktplan-vorlage', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Vorlage', leaf : true},
					{text : 'Vorlagen-kategorie', leaf : true}
				]},
				{text : 'Strukturplan-ungsvorlage', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Vorlage', leaf : true},
					{text : 'Vorlagen-kategorie', leaf : true}
				]},
				{text : 'XML-Exportvorlage', iconCls : 'xty_pgtoolbar-searchShow', children : [
					{text : 'Vorlage', leaf : true},
					{text : 'Vorlagen-kategorie', leaf : true}
				]},
				{text : 'ecatDesigner', iconCls : 'xty_pgtoolbar-searchDelete', leaf : true}
			]},
			{text : 'System', children : [
				{text : 'Benutzer-pflege', iconCls : 'xty_pgtoolbar-edit', children : [
					{text : 'Benutzer', leaf : true},
					{text : 'Benutzertyp', leaf : true},
					{text : 'Benutzer-gruppe', leaf : true},
					{text : 'Benutzer-rolle', leaf : true},
					{text : 'Abteilung', leaf : true},
					{text : 'Rechte-verwaltung', leaf : true}
				]},
				{text : 'Daemon', iconCls : 'xty_pgtoolbar-refresh', children : [
					{text : 'Konfiguration', leaf : true},
					{text : 'Workflow', leaf : true},
					{text : 'Element-status', leaf : true},
					{text : 'Produktions-status', leaf : true}
				]},
				{text : 'Parameter', iconCls : 'xty_pgtoolbar-searchShow', leaf : true},
				{text : 'Workflow', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Workflow-pfege', leaf : true},
					{text : 'Objekt-workflow', leaf : true},
					{text : 'Publikations-workflow', leaf : true}
				]},
				{text : '&Uuml;bersetzung<br />&nbsp;', iconCls : 'xty_pgtoolbar-pagingFirst', children : [
					{text : '&Uuml;bersetz-ungsreport', leaf : true},
					{text : 'Produkt-export', leaf : true},
					{text : 'Publikations-export', leaf : true},
					{text : 'Sammlungen', leaf : true},
					{text : 'Stammdaten-export', leaf : true},
					{text : 'XML-Import', leaf : true},
					{text : 'Importordner', leaf : true},
					{text : 'Stammdaten-import', leaf : true},
					{text : '&Uuml;bersetz-ungsprotokoll', leaf : true},
					{text : 'Prozess', leaf : true}
				]},
				{text : 'TMS', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Acrosss-Projektverwaltung', leaf : true}
				]},
				{text : 'NLS', iconCls : 'xty_pgtoolbar-searchShow', children : [
					{text : 'Sprachen', leaf : true},
					{text : 'Sprach-sortierung', leaf : true},
					{text : '&Uuml;bersetzungs-abh&auml;ngigkeit', leaf : true},
					{text : 'Ressourcen-Export', leaf : true},
					{text : 'Ressourcen-Import', leaf : true},
					{text : 'Land', leaf : true}
				]},
				{text : 'Datenbank-bereiniung', leaf : true, iconCls : 'xty_pgtoolbar-refresh'},
				{text : 'Support', leaf : true, iconCls : 'xty_pgtoolbar-dropbox'}
			]},
			{text : extVia.locales.user, children : [
				{text : 'Benutzerprofil', leaf : true, iconCls : 'xty_pgtoolbar-edit'},
				{text : 'Jobliste', leaf : true, iconCls : 'xty_pgtoolbar-collectionAddTo'},
				{text : 'Sammlungen', leaf : true, iconCls : 'x-btn-default-toolbar-large xty_epobElements'},
				{text : 'Unicode-zeichen', leaf : true, iconCls : 'xty_pgtoolbar-refresh'},
				{text : 'Protokolle', iconCls : 'xty_pgtoolbar-searchShow', children : [
					{text : 'Element-import', leaf : true},
					{text : 'Element-export', leaf : true},
					{text : 'XML-Export', leaf : true},
					{text : 'XML-Import', leaf : true},
					{text : 'CSV-Import', leaf : true},
					{text : '&Uuml;bersetzung', leaf : true},
					{text : 'Produkt-vorschau', leaf : true},
					{text : 'System', leaf : true},
					{text : 'Prozess', leaf : true},
					{text : 'Datenbank-bereinigung', leaf : true}
				]},
				{text : 'Exportformat', iconCls : 'xty_pgtoolbar-searchDelete', children : [
					{text : 'Report-generierung', leaf : true},
					{text : 'Report-planung', leaf : true},
					{text : 'Report-verwaltung', leaf : true},
					{text : 'Report-variablen', leaf : true},
					{text : 'Report-export', leaf : true},
					{text : 'Report-import', leaf : true}
				]},
				{text : 'Statistiken', iconCls : 'xty_pgtoolbar-pagingFirst', leaf : true},
				{text : 'Lesezeichen<br />&nbsp;', iconCls : 'xty_pgtoolbar-editItem', children : [
					{text : 'Lesezeichen 1', leaf : true},
					{text : 'Lesezeichen 2', leaf : true},
					{text : 'Lesezeichen 3', leaf : true}
				]},
				{text : 'System-informationen', iconCls : 'xty_pgtoolbar-collectionAddTo', children : [
					{text : 'Logout', leaf : true}
				]}
			]}
		]
	}
	
});