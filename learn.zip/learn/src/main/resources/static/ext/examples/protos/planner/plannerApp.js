Ext.application({
    name: 'planner',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },

    getContentPanelWidth : function (){
      var me = this;
      return me.getCenterWidth(); 
     },
    
    
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },

    
    getCenterWidth : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerWidth = centerPan.getWidth()-50;
      return centerWidth;
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      //var centerWidth = centerPan.getWidth()-50;
      var centerHeight = centerPan.getHeight()-92; // ohne pagetoolbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=86;
      }      
      return centerHeight;
    },
    
    getCenterSize : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerSize = centerPan.getSize();    
      return centerSize;
    },
    
    showSchedulingDialog: function (cfg, record){
      
      cfg.epobDscr = cfg.record.get('dscr');
      
      
      Ext.create('Ext.window.Window', {
        title : 'Zeitplan bearbeiten',
        modal:true,
        y:120,
        //height: 200,
        width: 520,
        layout: 'fit',

        items : [ {
          border : false,
          minHeight : 200,
          itemId : 'myFormPanel',
          xtype : 'form',

          dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
            var dialogButtons = this.ownerCt.getComponent('myButtons');
            var activate = dirty;
          },

          fieldDefaults : {
            msgTarget : 'side'
          },
          defaults : {
            style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',

            ancshor : '100%',
            labelWidth : 150,
            width : 426,
            msgTarget : 'side'
          },

        items: [
          extVia.dialoges.getInstructionPanel({
           // mainInstr : cfg.mainInstr, 
            mainInstr : 'Zeitplan f&uumlr <i>'+cfg.epobDscr+'<i>'
          }),
          
          
          { itemId:'starttime-bin',  xtype:'fieldcontainer',  fieldLabel:'Startzeit', layout:'hbox', width : 540, items:[
            { itemId:'starttime-date', xtype:'datefield',  value:'', width:195},
            { itemId:'starttime-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
         ]},
          

         
         {xtype:'textarea', itemId:'email',  fieldLabel:'Emaillist',  rows:1,  vtype:'emaillist'}, 

         
         { xtype:'textarea',  itemId:'comment',  fieldLabel:'Kommentar', rows:1},
         
         
         {xtype:'tbspacer'}

//            {   
//                xtype:'combo', 
//                margins:'0 0 0 10',
//                width:2100,
//                fieldLabel:'Typ',
//                emptyText:'',     
//                store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
//                 data :  [   [ 'Sofort','Started'] , [  'geplant' ,'Scheduled' ], [  'keine', 'Inactive']]
//                 }) ,                              
//                displayField: 'dscr',
//                valueField: 'value',
//                typeAhead: true,
//                mode: 'local',
//                triggerAction: 'all',
//                listConfig : {
//               getInnerTpl : function(displayField) {
//                 var tpl = '<div style="width:100%;height:18px;padding-left:16px;" title="" class="xty_icon xty_icon{value} "><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
//                 return tpl;
//               }
//             }, 
//             
//             selectOnFocus:true
//            },
//
//            
//            { itemId:'scheduling-period-bin',  xtype:'fieldcontainer',  fieldLabel:'Zeitraum', layout:'hbox', width : 540, items:[
//              { itemId:'scheduling-period', xtype:'numberfield',  value:'', width:80},
//              { itemId:'scheduling-period-unit', xtype:'combo',  margin:'0 0 0 7', width:100,
//                store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
//                  data :  [ ['Tage'],  ['Stunden'],  ['Minuten'], ['Sekunden']]
//                  }) ,                              
//                 displayField: 'dscr',
//                 typeAhead: true,
//                 value:'Minuten',
//                 mode: 'local',
//                 triggerAction: 'all',
//                 selectOnFocus:true 
//              }
//            ]},
//            
//            
//            { itemId:'scheduling-bin',  xtype:'fieldcontainer',  fieldLabel:'N&auml;chste Synchronisation', layout:'hbox', width : 540, items:[
//               { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
//               { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
//            ]},
//            { itemId:'failover-bin', xtype:'fieldcontainer',  fieldLabel:'Ersatz Synchronisation', layout:'hbox', width : 540, items:[
//               { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
//               { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
//            ]}       
//
//          
          ]
        }
             
        ],
        buttons:[  
          {text:'&Uuml;bernehmen', 
              handler:function(btn){     
                extVia.notify({action: '&Uuml;bernehmen'  , mssg:  'Erfolgreich'});
                btn.ownerCt.ownerCt.hide();
              } 
          },

          {text:'Abbrechen', handler:function(btn){btn.ownerCt.ownerCt.hide(); } }
          ]
        }
      ).show();
 
    },
       
   
    
    
    
    
    showPlanningEditor: function (cfg, record){ // showPlanningEditorTAB

      
      var me = this;
      
      var isOnce = true;
      
      
     var  plannerType = record.get('plannerType');
      
      
      var pagetoolbarButtons =[{itemId:'save'}];
      
      var module = cfg ? cfg.module :''; 
      

      var isExport = module.toLowerCase().indexOf('export')>-1;
      
      var dscr = record.get('dscr');
  
      
      var doDialog = isExport && dscr.toLowerCase().indexOf ('x')>-1;
      
      
      me.createPlanningDialog ({dscr:dscr, module:module, isExport:isExport }, record);
      if (doDialog){       
        me.createPlanningDialog ({dscr:dscr, module:module, isExport:isExport }, record);
      }
      
      
      else{
      var ediHTML = '<img id="historyTabCardViewEast" style="margin:24px;" src="../img/fakes/planner/editor-import-'+(isOnce?'once':'event')+'-xml.png"/>';
      
      if (isExport){
        ediHTML = '<img id="historyTabCardViewEast" style="margin:24px;" src="../img/fakes/planner/editor-export-sourceAndSettings.png"/>';
      }
      

      var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: module+'planung ' +'('+plannerType+ ') ', epobDscr:  record.get('dscr'),   pagetoolbarButtons: pagetoolbarButtons } );
 
      var editorPanelCfg ={
                          //itemId:'settingsPanel',
                          title: record.get('dscr'),
                          tbar: applibar,
                          margin:'24 24 24 24',
                          closable:true,
                          xtype:'panel',
                          height: 840,
                          autoScroll: true,
                          border:false,
                          html: ediHTML//'<img id="historyTabCardViewEast" style="margin:24px;" src="../img/fakes/planner/editor-import-'+(isOnce?'once':'event')+'-xml.png"/>'
                       };
      
      
      var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
      var editorPanel = centerTabPan.addAndActivate(editorPanelCfg); 
    }
    },
    
    
    
    showPlanningEditorDIALOGS: function (cfg, record){ // showPlanningEditorDIALOGS
      var me = this;
      var  plannerType = record.get('plannerType');
      var dscr = record.get('dscr');
      var module = cfg ? cfg.module :''; 
      var isExport = true; // module.toLowerCase().indexOf('export')>-1;
      // >>> PROD V4 Start (EPIM-7678) <<<
      me.createPlanningIframeDialog ({dscr:dscr, module:module, isExport:isExport }, record);
      // >>> PROD V4 End (EPIM-7678) <<<
    },
    
    
    createPlanningIframeDialog: function (cfg, record){
      
      var me = this;

      // >>> PROD V4 Start (EPIM-7678) <<<
      var iframeSrc = ''; // TODO send with cfg and do not use hard-coded IPs
      // >>> PROD V4 End (EPIM-7678) <<<
      
      var planningDialog;
      
      var centerSize = me.getCenterSize();
      
     // alert('centerSize '+ Ext.encode(centerSize));
      
      var diaWidth =  centerSize.width-50; // me.getContentPanelWidth(),
      var diaHeight =  centerSize.height-180; // me.getContentPanelHeight(),
      
      var ifrWidth = diaWidth;
      var ifrHeight =  diaHeight;
      
      
      planningDialog = Ext.create('Ext.window.Window', {
        title : 'Planung erstellen',
        modal:true,
        y:40,
        //height: dialogHeightSource, 
        width:  diaWidth, 
        height: diaHeight,
        //layout: 'fit'
        
        items:[
          
            {        
              
                        
//            setIframeSrc:function(url){
//             Ext.get('xml-planner-iframePanel').dom.src= cfg.url; //'http://www.istockphoto.com/';
//             Ext.get('xml-planner-iframePanel').removeCls('xty_iframePanel_topminus100');
//            },
            
            
             itemId:'iframePaneXl',
             html:'<iframe id ="xml-planner-iframePanel" class="xty_iframePanel-some" width="'+ifrWidth+'" height="'+ifrHeight+'" style="msargin-top:-100px;"  frameborder="0" src="'+iframeSrc+'"  ></iframe>'}
          

          
          
        ],
        
        buttons:[{text:'Apply'}]
      
      });
      
      planningDialog.show();
      
    },
    
    
    createPlanningDialog: function (cfg, record){

      //var isExport = cfg.isExport ;
      var isExport = cfg.module.toLowerCase().indexOf('export')>-1;
      
      var  mainInstr  = isExport ? 'Exportquelle' : 'Importquelle';
      var  suppInstr  = '';
      var isOnce=cfg.dscr.indexOf('once')>-1;
      var isXML=cfg.dscr.indexOf('XML')>-1 ; //|| isXML  ;
      
      var sourcePanel ={};
      var timeplanningPanel ={};
      
      
      var sourceHeight = 400;
      var settingsHeight = 700;
      
      
      var html = isExport
        ? '<img id="historyTabCardViewEast" style="" src="../img/fakes/planner/editor-export-settings.png"/>'
        : '<img id="historyTabCardViewEast" style="margin-top:-210px;" src="../img/fakes/planner/editor-import-'+(isOnce?'once':'event')+'-xml.png"/>';
      
      var settingsPanel ={
         itemId:'settingsPanel',  
         xtype:'panel',
         height: settingsHeight,
         hidden:true,
         autoScroll: true,
         border:false,
//         html:'<img id="historyTabCardViewEast" style="margin-top:-210px;" src="../img/fakes/planner/editor-import-'+(isOnce?'once':'event')+'-xml.png"/>',
//         html:'<img id="historyTabCardViewEast" style="margsin-top:-210px;" src="../img/fakes/planner/editor-export-settings.png"/>'
         html:html
         
      };

      
    
      if (!isOnce || isXML){
        mainInstr = 'Exportplanung';
        mainInstr  = isExport ? 'Exportplanung' : 'Importplanung';
        suppInstr  = 'W&auml;hlen Sie Ihre Quelle';

        
        var diaItems = [
          {
            html:'<img  id="historyTabCardViewEast" style=" width:584px; height:532px;" src="../img/fakes/planner/editor-export-source.png"/>'  
          }
     
        ];
        
        if (!isExport){
          diaItems =[ 
            {fieldLabel:'Dienstname'},
            {fieldLabel:'Stammverzeichnis'},
            {fieldLabel:'Arbeitsverzeichnis'},
            {fieldLabel:'fehlerhafte Importe', fFieldLabel:'Verzeichnis f&uumlr fehlerhafte Importe'},
            {fieldLabel:'erfolgreiche Importe', fFieldLabel:'Verzeichnis f&uumlr erfolgreich abgeschlossene Importe'}
          ] ;
        }
        
        
        sourcePanel = {xtype:'fieldcontainer',  
          itemId:'sourcePanel',             
          defaults:{xtype:'textfield', width:420, labelWidth:120},
          items:  diaItems
        };
        
        
      }
      else{
        mainInstr  = 'Import einmalig';
        suppInstr  = 'W&auml;hlen Sie die Quelldatei.';
        isOnce = true;  
        

       var xmlFileTreeStore = Ext.create('Ext.data.TreeStore', {
          root: {
              expanded: true,
              children: [
                  { text: "detention", leaf: true },
                  { text: "homework", expanded: true, children: [
                      { text: "book report", leaf: true },
                      { text: "alegrbra", leaf: true}
                  ] },
                  { text: "buy lottery tickets", leaf: true }
              ]
          }
      });

       
       sourceHeight = 150;
       
       sourcePanel = Ext.create('Ext.tree.Panel', {
          //title: 'Dateiauswahl',
          itemId:'sourcePanel',
          width: 275,
          style : 'margin:0px 10px 10px 160px; padding-bottom:4px;',
          height: sourceHeight,
          store: xmlFileTreeStore,
          rootVisible: false
      });
 
        
      }      
      
      //mainInstr= (isXML? 'XML-' : 'CSV-'  ) +mainInstr;
      
      
      var planningDialog;
      
      planningDialog = Ext.create('Ext.window.Window', {
        title : 'Planung erstellen',
        modal:true,
        y:40,
        //height: dialogHeightSource, 
        width: 620,
        //layout: 'fit',

        currentPanel:'',
        next: function(){
          //extVia.notify({action: 'Weiter'  , mssg:  'Clicked'});
          var dialog = this;
          var dialogFormPanel =  dialog.getComponent('myFormPanel');
          dialogFormPanel.getComponent('sourcePanel').hide();
          dialogFormPanel.getComponent('settingsPanel').show();     

          var instructionPanel = dialogFormPanel.getComponent('instructionPanel');
          //instructionPanel.setMainInstruction('ACD');
          instructionPanel.setSupplementalInstruction('Konfigurieren Sie Ihre Einstellungen.');
        },
        previous: function(){
          //extVia.notify({action: 'Zur&uuml;'  , mssg:  'Clicked'});
          var dialog = this;
          var dialogFormPanel =  dialog.getComponent('myFormPanel');
          dialogFormPanel.getComponent('sourcePanel').show();
          dialogFormPanel.getComponent('settingsPanel').hide();  
          
          var instructionPanel = dialogFormPanel.getComponent('instructionPanel');
          //instructionPanel.setMainInstruction('ACD');
          instructionPanel.setSupplementalInstruction('W&auml;hlen Sie Ihre Quelle.');

        },
        
        items : [ {
          border : false,
          //minHeight : 200,

          itemId : 'myFormPanel',
          xtype : 'form',

          dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
            var dialogButtons = this.ownerCt.getComponent('myButtons');
            var activate = dirty;
          },

          fieldDefaults : {
            msgTarget : 'side'
          },
          defaults : {
            style : 'margin:0px 0px 0px 14px; padding-bottom:4px;',
            
            labelWidth : 150,

            msgTarget : 'side'
          },

        items: [
          extVia.dialoges.getInstructionPanel({  mainInstr: mainInstr, suppInstr: suppInstr }),
          
            //{xtype:'displayfield', value:'XML-Import-Datei'},

          
            {   
                xtype:'combo', 
                masrgins:'0 0 20 10',
                width:420,
                labelWidth:140,
                hidden: !isOnce,
                fieldLabel: isOnce ? 'Importprofil' :'Verzeichnis',
                emptyText:'',     
                store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                 data :  [  [ 'Default','Default'] , [  'Match Product' ,'Match Product' ], [  'Dictionary', 'Dictionary']]
                 }) ,                              
                displayField: 'dscr',
                valueField: 'value',
                typeAhead: true,
                mode: 'local',
                triggerAction: 'all', 
             
             selectOnFocus:true
            },
     
          
            sourcePanel,
            settingsPanel
//            
//            {xtype:'fieldcontainer',  hidden: !isOnce,
//              
//              defaults:{xtype:'textfield', width:420, labelWidth:140},
//              items:[ 
//                {xtype:'timefield', fieldLabel:'Startzeit '},
//                {xtype:'datefield', fieldLabel:'Startdatum'}
//                
//              ]  
//            }

          
          ]
        }
             
        ],
        buttons:[  
          {text:'Zur&uuml;ck', itemId:'previous', disabled:true ,
            handler:function(btn){     
              btn.ownerCt.getComponent('create').hide();
              btn.ownerCt.getComponent('next').show();
              btn.ownerCt.ownerCt.previous();
            } 
          },
          {text:'Weiter', itemId:'next',
              handler:function(btn){     
                btn.ownerCt.getComponent('previous').setDisabled(false);
                btn.ownerCt.getComponent('create').show();
                btn.ownerCt.getComponent('next').hide();
                btn.ownerCt.ownerCt.next();
              } 
          },
          {text:'Erstellen', itemId:'create', hidden:true,
            handler:function(btn){     
              btn.ownerCt.ownerCt.hide();
              extVia.notify({action: 'Planung erstellen'  , mssg:  'Erfolgreich'}); 
            } 
        },

          {text:'Abbrechen', handler:function(btn){btn.ownerCt.ownerCt.hide(); } }
          ]
        }
      ).show();
 
    },
       

    statusRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value+'" class="xty_icon xty_icon'+value+'"></div>'; },
    

  
    getPlannerGrid: function (){ 
      var me = this;

      var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
          clicksToEdit: 1
      });
        
      
      
   
       var scheduleTemplate = me.getScheduleTemplate();
      
        var planningsGrid ={
         xtype:'grid',
         id:'planingTypesPlanner',
         itemId:'planingTypesPlanner',
         //hideHeaders : true,
         tbar:{
           itemId:'filterbar', 
           cls:'xty_columnfilterbar',
           clearAll:function(){
             var me = this;
             var i;
             for ( i =1; i< me.items.length; i++){
               var field = me.items.get(i);
               field.setValue('');
               field.removeCls('xty_field-nullified');
               } 
           },
           defaults:{
             xtype:'triggerfield',
             resizable:true,
             cls:'xty_has-insidetrigger', 
             triggerCls:'xty_inside-trigger-clear',
             onTriggerClick: function(evt){
              var targetEl = Ext.get(evt.target.id); 
              var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
              var field = Ext.getCmp(fieldId);
              field.removeCls('xty_field-nullified');
              field.setValue('');
             },
             listeners:{

               resize: function(field, adjWidth, adjHeight){
                 if (field && field.myColumnId){
                   var grid = field.ownerCt.ownerCt;
                   var column = Ext.getCmp(field.myColumnId); //columns 
                   if (column){
                     column.setWidth(field.getWidth()+2);
                   }
                 }
               },
               
               change:function(field){
                 var clearfilters = field.ownerCt.getComponent('clearfilters');
                 var allEmpty = false;
                 if (Ext.isEmpty(field.getValue())){
                   allEmpty = true;
                   var tbar = Ext.getCmp(field.ownerCt.id);
                   var i;
                   for ( i =1; i< tbar.items.length; i++){
                     var tbitem = tbar.items.get(i);
                     if( tbitem.getValue  && !Ext.isEmpty(tbitem.getValue())){
                       allEmpty = false; 
                     }
                    } 
                 }
                 clearfilters.setDisabled(allEmpty);
                 field.removeCls('xty_field-nullified');
               },

               afterrender: function(item){
                if (item.getXType().indexOf('button')===-1){
                  var fieldEl = Ext.get(item.id);
                  fieldEl.on('contextmenu', function(evt) {  
                    item.showMenu(item, evt);
                  });
                  
                  var myGrid = item.ownerCt.ownerCt;
           
                  if (item.itemId){
                    var ci;
                    for (ci=0; ci<myGrid.columns.length; ci++ ){
                      var column = myGrid.columns[ci];
                      if (item.itemId  === column.itemId){
                        item.myColumnId = column.id;
                        break;
                      }
                      
                    }
                  }

                  
//                  fieldEl.on('click', function(evt) {  
//                    //item.removeCls('xty_field-nullified');
//                  });
                }
               } 
             },
             
             showMenu:function(field, evt){
               evt.preventDefault();
               var fieldMenu = Ext.create('Ext.menu.Menu', {
                 items: [
                   {text:'nach leeren Werten suchen ', iconCls:'xty_menuNull', enableToggle:true,
                     handler: function(){
                       field.setValue('NULL');
                       field.addCls('xty_field-nullified');
                     }
                   }
//                   //filterbehaviour
//                   '-',
//                   {text: 'einer enthalten ( = |)', iconCls:'xty_menu_contains'},
//                   {text: 'alle enthalten ( = &)', iconCls:'xty_menu_containsAll'},
//                   {text: 'nicht enthalten ( -)', iconCls:'xty_menu_containsNot'},
//                   {text: 'Beginnt mit &lang; <span data-qtip="Dach an den Anfang">^</span> &rang;', iconCls:'xty_menu_startsWith'},
//                   {text: 'Endet mit &lang; <span data-qtip="Dollar ans Ende">$</span> &rang;',   iconCls:'xty_menu_endsWith'},
//                   {text: 'Stimmt genau &uuml;berein ("")', iconCls:'xty_menu_exact'},
//                   '-',
//                   {text:'<b>Suchbegriff</b>'}, 
//                   {text:'Als Wort enthalten &lang;<span data-qtip="Leerzeichen Komma Bindestrich Semikolon"> Trenner: &not; , -  ; </span> &rang;', checked:true, itemId:'matching-word', group:'MATCHING', value:'WORD'},
//                   {text:'Enthalten' , itemId:'matching-contains', group:'MATCHING', value:'CONTAINS'},
//                   {text:'Beginnt mit', itemId:'matching-startswith', group:'MATCHING', value:'STARTSWITH'},
//                   {text:'Endet mit', itemId:'matching-endswith', group:'MATCHING', value:'ENDSWITH'},    
//                   {text:'Exakt', itemId:'matching-exact', group:'MATCHING', value:'EXACT'},    

                 ]
               
               });
               fieldMenu.showAt(evt.getXY());
             }
           },
           items:[
             
             {xtype:'tbspacer', width:34},
             
             { width: 39, itemId:'status', emptyText:'status'},
             { width:40, itemId:'type', emptyText:'Typ'},  
             { width:180, itemId:'name', emptyText:'Name'},  
             { width:96, itemId:'scheduling', emptyText:'Zeitplanung'},  
             { width:78 ,itemId:'scheduletype', emptyText:'Planungstyp'},    
             { width:98,itemId:'nextrun', emptyText:'nächster Lauf'},   
             { width:66, itemId:'starttime', emptyText:'Startzeit'},
             { width:98, itemId:'lastrun', emptyText:'letzter Lauf'},
             { width:98, itemId:'comment', emptyText:'Comment'},
             { width:98, itemId:'directory_file', emptyText:'Verzeichnis/Datei'},
             { width:98, itemId:'importtype', emptyText:'Importtyp'},

             '->',
             {overCls:'xty_minitool-over',itemId:'clearfilters',  xtype:'button', iconCls:'x-tool-filterOff', disabled:true, tooltip:'clear filters', 
               handler:function(btn){btn.ownerCt.clearAll();} 
             },
             
             {overCls:'xty_minitool-over',itemId:'close', xtype:'button', iconCls:'xty_minitool-close', width:11, iconAlign:'right', margin:'0 4 0 0', handler:function(btn){btn.ownerCt.hide();} }
           ]
         },
         
         
         
//         features: [Ext.create('Ext.grid.feature.Grouping',{
//              groupHeaderTpl: 'grouped by <i>{[Ext.getCmp("planingTypesPlanner").getColumnName()]}</i> : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
//          })], 
         
          getColumnName:function(){                            
           //var grid =this; //Ext.getCmp("planingTypesPlanner");
           var columnFieldName = this.features[0].getGroupField();
               return  columnFieldName ;
           },
         
         plugins: [cellEditing],
         store: extVia.stores.getPlannerStore({}),
         border:false,
         height:me.getCenterHeight(),
        
         selModel: Ext.create('Ext.selection.CheckboxModel', {
           injectCxheckbox : 1,
           isCheckerHd: false,
           headerWidth:36
          }),
        
         columns:[
           
           
 //     {header:'Alle Planner',   dataIndex:'allPlanners',  columns:[

           
      //   {header:'&nbsp;&nbsp;&nbsp;', width:52},  
         
         {header:'<span data-qtip="Status">Status</span>',itemId:'status',  dataIndex:'status',   width:42, renderer: me.statusRenderer},
         {header:'<span data-qtip="Type">Typ</span>', itemId:'type',  dataIndex:'plannerType', width:42,
          renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
             metaData.tdCls='xty_planner-type-cell xty_planner-cell-'+value.toLowerCase();
            return '<div data-qtip="'+value+'" class="xty_planner-'+ (value.toLowerCase()) +'">&nbsp;</div>'; 
            }
         },
         {header:'<span data-qtip="Name">Name</span>', itemId:'name', dataIndex:'dscr', width:182},
        
         
         //{ header: 'Files', dataIndex: 'progress',   width: 60 },
         {header:'<span data-qtip="Schedule"> Zeitplanung </span>', itemId:'scheduling', dataIndex:'startTime',  width: 98,        //<span data-qtip="">  
           renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { 

             var schedType = record.get('plannerType') ;
             schedType = schedType.replace(/.*once/,'einmalig');
             schedType = schedType.replace(/.*event/,'ereignisgesteuert');               
             schedType = schedType.replace(/XML/,'w&ouml;chentlich');
             schedType = schedType.replace(/CSV/,'t&auml;glich');
                          
             // >>> PROD V4 Start (EPIM-7678) <<<
             var emaillist = 'joe.smith@example.com, jane.doe@example.com, john.deere@example.com;';
             // >>> PROD V4 End (EPIM-7678) <<<
             var html= scheduleTemplate.applyTemplate({planningtype: schedType,   schedulingperiod: 'Every 3. Week',  schedulingdays: 'MO DI SA',startDate:'18.10.2018', startTime:'14:05', email: emaillist});

             return html;
           },
           
         editor: {   
                 xtype:'combo', 
                 margins:'0 0 0 10',
                 emptyText:'planningTypes',     
                 store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                  data :  [  ['Startzeit &auml;ndern']] //,['Datum &auml;ndern'],  ['Planungstyp &auml;ndern'],['Kommentieren']]
                  }) ,                              
                 displayField: 'dscr',
                 typeAhead: true,
                 mode: 'local',
                 triggerAction: 'all',
                 selectOnFocus:true,
                 
                 listConfig : {
                   minWidth:340,
                   maxHeight:240,
                   itemTpl:
                     '<div id="form-1505-body" class="x-panel-body  x-panel-body-default x-panel-body-default" style="width: 320px; left: 0px; tsop: 25px;">'+
                     '<div id="tbspacer-1506" class="x-toolbar-spacer x-toolbar-spacer-default" style="width: 300px; height: 8px;" role="presentation"></div>'+
                     '<div id="combobox-1507" class="x-field x-form-item x-field-default" style="width: 300px;"><label id="combobox-1507-labelEl" for="ext-gen1812" class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:140px;">&nbsp;Startzeit:<span class="xty_requiredStar-icon">&nbsp;&nbsp;&nbsp;</span></label><div class="x-form-item-body " id="combobox-1507-bodyEl" role="presentation" style="width: 155px;">'+
                     '<div class="x-hide-display x-form-data-hidden" role="presentation" id="ext-gen1813"><input name="versionsdepht" value="-" type="hidden"></div><input id="ext-gen1812" size="20" class="x-form-field x-form-text" autocomplete="off" aria-invalid="false" placeholder="Startzeit" data-errorqtip="" style="width: 138px; -moz-user-select: text;" role="textbox" aria-describedby="combobox-1507-errorEl" aria-required="true" type="text">'+
                     '<div id="combobox-1507-triggerWrap" class="x-form-trigger-wrap" role="presentation" style="width: 17px;"><div class="x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-last x-unselectable" role="button" id="ext-gen1814" style="-moz-user-select: none;"></div><div class="x-clear" role="presentation"></div></div></div>'+
                     '<div id="combobox-1507-errorEl" class="x-form-error-msg" style="display:none"></div><div class="x-clear" role="presentation"><!-- --></div></div>'+
                     '<div id="combobox-1508" class="x-field x-form-item x-field-default" style="width: 300px;"><label id="combobox-1508-labelEl" for="ext-gen1816" class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:140px;">&nbsp;Datum:</label><div class="x-form-item-body " id="combobox-1508-bodyEl" role="presentation" style="width: 155px;"><div class="x-hide-display x-form-data-hidden" role="presentation" id="ext-gen1817"></div><input id="ext-gen1816" size="20" class="x-form-field x-form-text x-form-empty-field" autocomplete="off" aria-invalid="false" placeholder="Datum" data-errorqtip="" style="width: 138px; -moz-user-select: text;" role="textbox" aria-describedby="combobox-1508-errorEl" aria-required="false" type="text">'+
                     '<div id="combobox-1508-triggerWrap" class="x-form-trigger-wrap" role="presentation" style="width: 17px;"><div class="x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-last x-unselectable" role="button" id="ext-gen1818" style="-moz-user-select: none;"></div><div class="x-clear" role="presentation"></div></div></div><div id="combobox-1508-errorEl" class="x-form-error-msg" style="display:none"></div><div class="x-clear" role="presentation"><!-- --></div></div><div id="textareafield-1509" class="x-field x-form-item x-field-default" style="width: 300px; height: 36px;"><label id="textareafield-1509-labelEl" for="ext-gen1820" class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:140px;">&nbsp;Kommentar:</label><div class="x-form-item-body " id="textareafield-1509-bodyEl" role="presentation" style="width: 155px; height: 36px;"><textarea id="ext-gen1820" name="comment" rows="4" cols="20" class="x-form-field x-form-text" autocomplete="off" aria-invalid="false" data-errorqtip="" style="width: 155px; height: 36px; -moz-user-select: text;" role="textbox" aria-describedby="textareafield-1509-errorEl" aria-required="false" aria-multiline="true"></textarea></div><div id="textareafield-1509-errorEl" class="x-form-error-msg" style="display:none"></div><div class="x-clear" role="presentation"><!-- --></div></div><div id="tbspacer-1510" class="x-toolbar-spacer x-toolbar-spacer-default" style="width: 300px; height: 8px;" role="presentation"></div><div class="x-clear" role="presentation" id="ext-gen1823"></div></div>'
                   }
     
             }
          },

          
         {header:'<span data-qtip="Planningtype">Planungstyp</span>', itemId:'scheduletype', width:80, dataIndex:'plannerType',
            
            renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
              
              var schedType = value; //.replace(/XML/,'').replace(/CSV/,'').replace(/-/,'');
              
              schedType = schedType.replace(/.*once/,'einmalig');
              schedType = schedType.replace(/.*event/,'ereignisgesteuert');
              
              schedType = schedType.replace(/XML/,'w&ouml;chentlich');
              schedType = schedType.replace(/CSV/,'t&auml;glich');

              
              return schedType;
            } 
         
         },
         
         {header:'<span data-qtip="NextRun">n&auml;chster Lauf</span>', itemId:'nextrun', width:101, dataIndex:'nextRun',  renderer: me.nextRunRenderer}, 
         {header:'<span data-qtip="StartTime">Startzeit</span>',  itemId:'starttime',  width: 68,dataIndex:'startTime'}, 

         {header:'<span data-qtip="LastRun">letzter Lauf</span>', itemId:'lastrun',  width:100, dataIndex:'lastRun',  renderer: me.lastRunRenderer}, 
         
        


         
//         {header:"ID", hidden:true},
//         {header:"CLIE_ID", hidden:true},
//         {header:"DELETED", hidden: true},
//         {header:"CREATION_DATE"},
//         {header:"CREATION_USRS_ID", hidden:true},
//         {header:"CHANGE_DATE"},
//         {header:"CHANGE_USRS_ID", hidden:true},
//         {header:"PLAN_TYPE", hidden:true},
//         {header:"START_HOUR"},
//         {header:"START_DAY"},
//         {header:"RUN_PERIOD"},
//         {header:"LASTRUN", hidden:true},
//         {header:"PUUN_ID", hidden:true},
//         {header:"NEXTRUN" ,hidden:true},
//         {header:"JOB_TYPE"},
//         {header:"XIMP_PARAMETERS", hidden:true},
//         {header:"RUNNING"},
//         {header:"REPO_ID", hidden:true},
//         {header:"REPORT_EMAIL"},
//         {header:"PUTE_ID", hidden:true},
//         {header:"PLAN_COMMENT"},
//         {header:"PPDF_ID", hidden:true},
//         {header:"SYNO_ID" , hidden:true},
         
         
        // {header:"Scheduling type"},

         {header:'<span data-qtip="Comment">Comment</span>'},
         
 //        ]}, //  eo Alle columns
         
//         
     //    {header:'Import Planner', dataIndex:'imports-planner', width: 200, columns:[
           {header:'<span data-qtip="Folder/File">Verzeichnis/Datei</span>', itemId:'directory_file', width: 100, dataIndex:'imports-source'},
           {header:'<span data-qtip="Importtype">Importtype</span>', itemId:'importtype', dataIndex:'plannerType',width: 100,
             renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
              return value.replace(/-.*/,'');
              }  
           },
     //    ]}, // eo  imports-planner columns
//         
//         
//         {header:'Export Planner', dataIndex:'exports-planner', widtsh: 200, hidden:true, columns:[
//           {header:"Publikation type", dataIndex:'exports-type', widsth: 100 ,hidden:true},
//           {header:"Scheduling type (1,daily,weekly)",  wisdth: 100 ,hidden:true, dataIndex:'exports-schedtype'}
//         ]},
//         
//         {header:'Report Planner', dataIndex:'reportsPlanner', hidden:true, columns:[
//           {header:"Scheduling type (1,daily,weekly)"}
//         ]},

         
         
         
         
         
         
         
         
         
         {
           header: '<span data-qtip="Duration">Start - Dauer </span>',  hidden:true,
           dataIndex: 'duration',
           width:362,
           renderer: function (value, metadata, record) {
             
             metadata.tdCls='xty_duration-cell';
             
               var id = Ext.id();
               Ext.defer(function () {
                   Ext.widget('progressbar', {
                       renderTo: id,
                       style:'left: '+ record.get('start') * 10 +'px;',
                       left:  record.get('start') * 10 +'px;',
                       text: value +'h',
                       resizable: true,

                       //resizeHandles: 'w' ,
                       value:  record.get('progress')/100 ,
                       width: record.get('duration') * 10,
                       
                       oldWidth: record.get('duration') * 10,
                       
                       listeners:{
                         afterrender:function( progressbar ){
                           progressbar.renderedOnce = true;  
                         },
                         resize:function( progressbar, newwidth, newheight){

                           progressbar.resizeDraggingOn = false;
                           progressbar.getEl().setWidth(progressbar.oldWidth);  
                           progressbar.resizeDraggingOn = true;
                           
                           if (progressbar.renderedOnce && progressbar.resizeDraggingOn){
                            var diff = newwidth - progressbar.oldWidth   ;
                            progressbar.getEl().setStyle('left', diff+'px');   
                          }

                         }
                         
                       }
                       
                       
                   });
               }, 50);
               return Ext.String.format('<div title="'+value+'%" id="{0}"></div>', id);
           }
        }
        
        //, { menuDisabled:true, header:'', itemId:'countDisplay', cls:'xty_grid-header-countDisplay'}
         
         ]
         
         
         ,listeners:{
           
           afterrender: function( view ){
             
             var checkboxColumnHeader  = Ext.query('#'+view.id+' .x-column-header-checkbox')[0];   
             
             var gridHeaderCt  = Ext.query('#'+view.id+' .x-grid-header-ct-default')[0];   
             
//             var selectAllBtnBig =  Ext.create('Ext.button.Split', {
//               enableToggle:true,
//               draggable:true,
//               text:'33.000',
//               style:'position:absolute;top:0px; right:17px; z-index:1999;',
//               height:24,
//               iconCls:'xty_checkbox-btn-icon',
//               renderTo: gridHeaderCt, 
//               //renderTo: Ext.getBody(), 
//               checked:true,
//               handler: function() {
//                 //extVia.notify("all  clicked");
//               },
//               
//               menuAlign:'b',
//               menu: new Ext.menu.Menu({
//                
//                 items: [
//                     {text: 'Select all visible ~33', handler: function(){ extVia.notify("all visible clicked"); }},
//                     {text: 'Select all in PageSize 99', handler: function(){ extVia.notify("all PageSize clicked"); }},
//                     {text: 'Select completeley all 33.000', handler: function(){ extVia.notify("completeley all clicked"); }},
//                     {text: 'Deselect completeley all', handler: function(){ extVia.notify("Deselect completeley all clicked"); }}
//                 ]
//               })
//             });
             
             
             
             var selectAllBtnSmall =  Ext.create('Ext.button.Split', {
               enableToggle:true,
               draggsable:true,
               width:39,
               //style:'position:absolute;top:183px;left:23px;z-index:1998;',
               style:'position:absolute;top:0px;left:12px; z-index:1998;',
               height:24,
               iconCls:'xty_checkbox-btn-icon',
               
               //renderTo: gridHeaderCt, 
               //renderTo: Ext.getBody(), 
               checked:true,
               handler: function() {
                 //extVia.notify("all  clicked");
               },
               
               menuAlign:'b',
               menu: new Ext.menu.Menu({
                
                 items: [
                     {text: 'Select all visible ~33', handler: function(){ extVia.notify("all visible clicked"); }},
                     {text: 'Select all in PageSize 99', handler: function(){ extVia.notify("all PageSize clicked"); }},
                     {text: 'Select completeley all 33.000', handler: function(){ extVia.notify("completeley all clicked"); }},
                     {text: 'Deselect completeley all', handler: function(){ extVia.notify("Deselect completeley all clicked"); }}
                 ]
               })
             });
             
             
             
             var selectionCount= 0;
             var totalCount= 0; 
             totalCount = view.getStore().getCount();
             var gridHeaderCtInner  = Ext.query('#'+view.id+' .x-grid-header-ct-default .x-box-inner')[0];  
             
             
             var countDisplay =  Ext.create('Ext.Component', {
               itemId:'countDisplay', 
               cls:'xty_count-display x-column-header',
               style:'position: absolute; top:0px; right:24px; padding-top:4px; text-align:right; border-right:0px;font-size:11px; min-height:28px;',
               renderTo: gridHeaderCtInner, 
               html: '&nbsp;'+totalCount,
               totalCount:totalCount,
               selectionCount:selectionCount,
               setTotalCount:function(totalCount){
                 this.totalCount = totalCount;
                 this.setCountValues();
               },
               setSelectionCount:function(selectionCount){
                 this.selectionCount = selectionCount;
                 this.setCountValues();
               },
               setCountValues:function(){
                 var selCountHtml='';
                 if (this.selectionCount>0){
                   selCountHtml ='<span class="xty_selectionCount">'+this.selectionCount+'</span>/';
                 }
                 else{
                   selCountHtml ='<span class="xty_selectionCount"></span>';
                 }
                 this.getEl().dom.innerHTML = selCountHtml+'<span class="xty_totalCount">'+this.totalCount+'</span>';
               }
             });
 

//// This approach needs a column  header          
//      var gridHeaderCountDisplay  = Ext.query('#'+view.id+' .xty_grid-header-countDisplay')[0];   
//      var countDisplay = Ext.get(gridHeaderCountDisplay);
//       Ext.apply(countDisplay, {
//          totalCount:totalCount,
//          selectionCount:selectionCount,
//          setTotalCount:function(totalCount){
//            this.totalCount = totalCount;
//            this.setCountValues();
//          },
//          setSelectionCount:function(selectionCount){
//            this.selectionCount = selectionCount;
//            this.setCountValues();
//          },
//          setCountValues:function(){
//            var selCountHtml='';
//            if (this.selectionCount>0){
//              selCountHtml ='<span class="xty_selectionCount">'+this.selectionCount+'</span>/';
//            }
//            else{
//              selCountHtml ='<span class="xty_selectionCount"></span>';
//            }
//            this.dom.firstChild.innerHTML = selCountHtml+'<span class="xty_totalCount">'+this.totalCount+'</span>';
//          }
//        });
//     countDisplay.setTotalCount(totalCount);          
            
            
            
            
             
             var selModel =  view.getSelectionModel();
             selModel.countDisplay = countDisplay;
             selModel.myView = view;

             
           },  
           

           selectionchange: function( selectionModel , selected){
             var selectionCount = selected.length;
             selectionModel.countDisplay.setSelectionCount(selectionCount);
           },
           
           
          
           
           
            itemdblclick: function( view, record, item, index, evt, eOpts ){
              me.showPlanningEditor({module:'Base'}, record);
            },
            
            
            
            itemcontextmenu: function( view, record, item, index, evt, eOpts ){
              evt.preventDefault();
    
           //   alert(record.get('dscr'))
              
              var recky = record;
              
              
             var schedulingHandler = function(menuItem ){
               menuItem.record = record;
               me.showSchedulingDialog(menuItem);
             };

              
              var importPLannerMenu = Ext.create('Ext.menu.Menu', {

                margin: '0 0 10 0',
                items: [{
                text: '&Auml;ndern', iconCls:'x-tool x-tool-edit',  disabled:true,
                  handler:function(){  } 
                  },
                  {  iconCls:'x-tool x-tool-view', text: 'Anzeigen'},
                  {  iconCls:'x-tool x-tool-copy', text: 'Duplizierenn'},
                  {  iconCls:'x-tool x-tool-delete', text: 'L&ouml;schen'},
                  
                  '-',  

                  {  iconCls:'xty_menu-start', text: 'Start / Stop'},
                  {  iconCls:'xty_menu-stop', text: 'Stop', disabled:true},

                  
                  '-',  
                  {  iconCls:'xty_menu-schedule', itemId:'schedule', text: 'Zeitplan bearbeiten', handler:schedulingHandler}
                  
                ]
            });  
              importPLannerMenu.showAt(evt.getXY());
            }
          }
         
        };

        
        return planningsGrid;
      },   
      
  
      getScheduleTemplate: function (cfg){ 
        var scheduleTpl = new Ext.Template(
            '<span class="xty_planner-scheduling-label xty_planner-planningtype-label" data-qtip="planningtype"><b>{planningtype}</b></span><br>',
            '<span class="xty_planner-scheduling-label" data-qtip="schedulingperiod schedulingdays">{schedulingperiod} {schedulingdays}</span><br>',
            '<span class="xty_planner-scheduling-label" data-qtip="StartDate StartTime">{startDate} {startTime}</span><br>',
            '<span class="xty_planner-scheduling-label" data-qtip="email">{email}</span><br>'
        
        );
        return scheduleTpl;
      },
      
      getExportPlannerGridCfg: function (){ 
        var me = this;

        
        var scheduleTemplate = me.getScheduleTemplate();
        
        
        var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
            clicksToEdit: 1
        });
          
          var exportPlannerGridCfg = {
           xtype:'grid',
           id:'ExportPlannerGrid',
           itemId:'ExportPlannerGrid',
           
//           features: [Ext.create('Ext.grid.feature.Grouping',{
//                groupHeaderTpl: 'grouped by <i>{[Ext.getCmp("planingTypesPlanner").getColumnName()]}</i> : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
//            })], 
           
            getColumnName:function(){                            
             //var grid =this; //Ext.getCmp("planingTypesPlanner");
             var columnFieldName = this.features[0].getGroupField();
                 return  columnFieldName ;
             },
           
           plugins: [cellEditing],
           store: extVia.stores.getPlannerStore({}),
           border:false,
           height:me.getCenterHeight()-20,
          
           selModel: Ext.create('Ext.selection.CheckboxModel'),
          
           columns:[
             
             
             

            // Checkbox column, for selecting and deselection (mulitselection) of a row
   /*
    *           the planner ID
             Name
             the XML-Exporttype
             Scheduling type (1,daily,weekly)
             Next run (value must be orderable)
             Status (as icon with tooltipp)
             Publikation type (publication, export template)
             Comment
             Scheduling
             Startdate
             email
*/
             
             
             
             
         //  {header:'Alle Planner',   dataIndex:'allPlanners',  columns:[


           {header:'<span data-qtip="Type">Typ</span>', dataIndex:'plannerType', width:42,
            renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
               metaData.tdCls='xty_planner-cell-'+value.toLowerCase();
              return '<div data-qtip="'+value+'" class="xty_planner-'+ (value.toLowerCase()) +'">&nbsp;</div>'; 
              }
           },
           {header:'<span data-qtip="Name">Name</span>', dataIndex:'dscr', width:180},
          
           
           //{ header: 'Files', dataIndex: 'progress',   width: 60 },
           {header:'<span data-qtip="Schedule">Zeitplanung</span>', dataIndex:'startTime',             
             renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {

               var schedType = record.get('plannerType'); 
               schedType = schedType.replace(/.*once/,'einmalig');
               schedType = schedType.replace(/.*event/,'ereignisgesteuert');               
               schedType = schedType.replace(/XML/,'w&ouml;chentlich');
               schedType = schedType.replace(/CSV/,'t&auml;glich');
                            
               // >>> PROD V4 Start (EPIM-7678) <<<
               var emaillist = 'joe.smith@example.com, jane.doe@example.com, john.deere@example.com;';
               // >>> PROD V4 End (EPIM-7678) <<<

               var html= scheduleTemplate.applyTemplate({planningtype: schedType,  schedulingperiod: 'Every 3. Week',  schedulingdays: 'MO DI SA', startDate:'18.10.2018', startTime:'14:05', email: emaillist});
               return html;
             },
             
           editor: {   
                   xtype:'combo', 
                   margins:'0 0 0 10',
                   emptyText:'planningTypes',     
                   store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                    data :  [  ['Startzeit &auml;ndern']] //,['Datum &auml;ndern'],  ['Planungstyp &auml;ndern'],['Kommentieren']]
                    }) ,                              
                   displayField: 'dscr',
                   typeAhead: true,
                   mode: 'local',
                   triggerAction: 'all',
                   selectOnFocus:true,
                   
                   
                   
                   listConfig : {
                     minWidth:340,
                     maxHeight:240,
                     itemTpl:
                       '<div id="form-1505-body" class="x-panel-body  x-panel-body-default x-panel-body-default" style="width: 320px; left: 0px; tsop: 25px;">'+
                       '<div id="tbspacer-1506" class="x-toolbar-spacer x-toolbar-spacer-default" style="width: 300px; height: 8px;" role="presentation"></div>'+
                       '<div id="combobox-1507" class="x-field x-form-item x-field-default" style="width: 300px;"><label id="combobox-1507-labelEl" for="ext-gen1812" class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:140px;">&nbsp;Startzeit:<span class="xty_requiredStar-icon">&nbsp;&nbsp;&nbsp;</span></label><div class="x-form-item-body " id="combobox-1507-bodyEl" role="presentation" style="width: 155px;">'+
                       '<div class="x-hide-display x-form-data-hidden" role="presentation" id="ext-gen1813"><input name="versionsdepht" value="-" type="hidden"></div><input id="ext-gen1812" size="20" class="x-form-field x-form-text" autocomplete="off" aria-invalid="false" placeholder="Startzeit" data-errorqtip="" style="width: 138px; -moz-user-select: text;" role="textbox" aria-describedby="combobox-1507-errorEl" aria-required="true" type="text">'+
                       '<div id="combobox-1507-triggerWrap" class="x-form-trigger-wrap" role="presentation" style="width: 17px;"><div class="x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-last x-unselectable" role="button" id="ext-gen1814" style="-moz-user-select: none;"></div><div class="x-clear" role="presentation"></div></div></div>'+
                       '<div id="combobox-1507-errorEl" class="x-form-error-msg" style="display:none"></div><div class="x-clear" role="presentation"><!-- --></div></div>'+
                       '<div id="combobox-1508" class="x-field x-form-item x-field-default" style="width: 300px;"><label id="combobox-1508-labelEl" for="ext-gen1816" class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:140px;">&nbsp;Datum:</label><div class="x-form-item-body " id="combobox-1508-bodyEl" role="presentation" style="width: 155px;"><div class="x-hide-display x-form-data-hidden" role="presentation" id="ext-gen1817"></div><input id="ext-gen1816" size="20" class="x-form-field x-form-text x-form-empty-field" autocomplete="off" aria-invalid="false" placeholder="Datum" data-errorqtip="" style="width: 138px; -moz-user-select: text;" role="textbox" aria-describedby="combobox-1508-errorEl" aria-required="false" type="text">'+
                       '<div id="combobox-1508-triggerWrap" class="x-form-trigger-wrap" role="presentation" style="width: 17px;"><div class="x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-last x-unselectable" role="button" id="ext-gen1818" style="-moz-user-select: none;"></div><div class="x-clear" role="presentation"></div></div></div><div id="combobox-1508-errorEl" class="x-form-error-msg" style="display:none"></div><div class="x-clear" role="presentation"><!-- --></div></div><div id="textareafield-1509" class="x-field x-form-item x-field-default" style="width: 300px; height: 36px;"><label id="textareafield-1509-labelEl" for="ext-gen1820" class="x-form-item-label x-form-item-label-left" style="margin-right:5px;width:140px;">&nbsp;Kommentar:</label><div class="x-form-item-body " id="textareafield-1509-bodyEl" role="presentation" style="width: 155px; height: 36px;"><textarea id="ext-gen1820" name="comment" rows="4" cols="20" class="x-form-field x-form-text" autocomplete="off" aria-invalid="false" data-errorqtip="" style="width: 155px; height: 36px; -moz-user-select: text;" role="textbox" aria-describedby="textareafield-1509-errorEl" aria-required="false" aria-multiline="true"></textarea></div><div id="textareafield-1509-errorEl" class="x-form-error-msg" style="display:none"></div><div class="x-clear" role="presentation"><!-- --></div></div><div id="tbspacer-1510" class="x-toolbar-spacer x-toolbar-spacer-default" style="width: 300px; height: 8px;" role="presentation"></div><div class="x-clear" role="presentation" id="ext-gen1823"></div></div>'
                     }
               }
            },

            
           {header:'<span data-qtip="Planningtype">Planungstyp</span>', width:80, dataIndex:'plannerType',
              
              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                
                var schedType = value; //.replace(/XML/,'').replace(/CSV/,'').replace(/-/,'');
                
                schedType = schedType.replace(/.*once/,'einmalig');
                schedType = schedType.replace(/.*event/,'ereignisgesteuert');
                
                schedType = schedType.replace(/XML/,'w&ouml;chentlich');
                schedType = schedType.replace(/CSV/,'t&auml;glich');

                
                return schedType;
              } 
           
           },
           
           {header:'<span data-qtip="nextRun">n&auml;chster Lauf</span>', width:100, dataIndex:'nextRun',  renderer: me.nextRunRenderer}, 
           {header:'<span data-qtip="Status">Status</span>', dataIndex:'status', width:42, renderer: me.statusRenderer},
           {header:'<span data-qtip="StartTime">Startzeit</span>', width:70,dataIndex:'startTime'}, 

           {header:'<span data-qtip="lastRun">letzter Lauf</span>', width:100, dataIndex:'lastRun',  renderer: me.lastRunRenderer}, 

           
           
          // {header:"Scheduling type"},

           {header:'<span data-qtip="Comment>Comment</span>"'},
           
          
           {header:'<span data-qtip="Source">Quelle</span>' , width:68,
             
             renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
               metaData.tdCls='xty_grid-epobType-cell xty_grid-publicationType-cell'; 
              // return 'publication, export template';
               var publicationType = 'Publication';
               if ( rowIndex%3===0){
                 publicationType = 'Template';
               }
               else if ( rowIndex%2===0){publicationType = 'Export';}
               return '<div data-qtip="'+publicationType+'" class="xty_epob'+publicationType+'" style="height:18px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>'; 
             }  
           }, 
           
           
           {header:'<span data-qtip="Email">Email</span>' ,renderer: function(){ return '<span style="color:#888;">@</span>';  }},
           
        //   ]}, //  eo Alle

           
           {
             header: '<span data-qtip="Duration">Start - Dauer </span>', hidden:true,
             dataIndex: 'duration',
             width:362,
             renderer: function (value, metadata, record) {
               
               metadata.tdCls='xty_duration-cell';
               
                 var id = Ext.id();
                 Ext.defer(function () {
                     Ext.widget('progressbar', {
                         renderTo: id,
                         style:'left: '+ record.get('start') * 10 +'px;',
                         left:  record.get('start') * 10 +'px;',
                         text: value +'h',
                         resizable: true,

                         //resizeHandles: 'w' ,
                         value:  record.get('progress')/100 ,
                         width: record.get('duration') * 10,
                         
                         oldWidth: record.get('duration') * 10,
                         
                         listeners:{
                           afterrender:function( progressbar ){
                             progressbar.renderedOnce = true;  
                           },
                           resize:function( progressbar, newwidth, newheight){

                             progressbar.resizeDraggingOn = false;
                             progressbar.getEl().setWidth(progressbar.oldWidth);  
                             progressbar.resizeDraggingOn = true;
                             
                             if (progressbar.renderedOnce && progressbar.resizeDraggingOn){
                              var diff = newwidth - progressbar.oldWidth   ;
                              progressbar.getEl().setStyle('left', diff+'px');   
                            }

                           }
                           
                         }
                         
                         
                     });
                 }, 50);
                 return Ext.String.format('<div title="'+value+'%" id="{0}"></div>', id);
             }
          }
          

           
           ]
           
           
           ,listeners:{
              itemdblclick: function( view, record, item, index, evt, eOpts ){
                me.showPlanningEditor({module:'Export'}, record);
              },
              
              
              
              itemcontextmenu: function( view, record, item, index, evt, eOpts ){
                evt.preventDefault();
      
                
               var schedulingHandler = function(menuItem ){
                 menuItem.record = record;
                 me.showSchedulingDialog(menuItem, record);
               };

                
                var exportPLannerMenu = Ext.create('Ext.menu.Menu', {
                  margin: '0 0 10 0',
                  items: [
                    {  iconCls:'xty_formbutton-stop', text: 'Stop', disabled:true},
                    {  iconCls:'xty_formbutton-start', text: 'Start / Stop'},
                    '-',  
                    {  iconCls:'x-tool x-tool-delete', text: 'L&ouml;schen'},
                    {  iconCls:'x-tool x-tool-copy', text: 'Duplizieren'},
                    {
                    text: '&Auml;ndern', iconCls:'x-tool x-tool-edit',  disabled:true,
                    handler:function(){ } 
                    },
                    {  iconCls:'x-tool x-tool-view', text: 'Anzeigen'},

                    '-',  
  
                    {  iconCls:'xty_menu-schedule', itemId:'editScheduling', text: 'Zeitplan bearbeiten', handler:schedulingHandler},
                    {  iconCls:'xty_icon xty_iconTemplate', itemId:'editSchedulingTemplate', text: 'Template bearbeiten', handler:schedulingHandler}
                    
                  ]
              });  
                exportPLannerMenu.showAt(evt.getXY());
              }
            }
           
          };
          return exportPlannerGridCfg;
        },   
        

      
      nextRunRenderer :function( value, metaData, record, rowIndex, colIndex, store, view ){
      var html = value;
      html='<span style="color:#888">'+value+'</span>';
      if (value.indexOf('in')===0){
       html='<b>'+value+'</b>';
      }
      return html;
    },
    lastRunRenderer :function( value, metaData, record, rowIndex, colIndex, store, view ){
      var html = value;
      html='<span style="color:#888">'+value+'</span>';
      if (value.indexOf('in')===0){
       html='<b>'+value+'</b>';
      }
      return html;
    },
    
    launch: function() {
      
      
/////// Copied from distributionsApp.js Proto START //////////////      
      // Copied from Ext.form.field.VTypes.js START
      var trimX = /^\s+|\s+$/g;
      /**
       * True if null or whitespacesOnly
       */
      var isEmpty = function(value) {
        if (Ext.isEmpty(value) === true) {
          return true;
        } else if (value.length === 0) {
          return true;
        } else {
          var trimVal = value.replace(trimX, "");
          return trimVal.length === 0;
        }
      };
      var emailX = /^(\w+)([\-+.][\w]+)*@(\w[\-\w]*\.){1,5}([A-Za-z]){2,4}$/;
      // Copied from Ext.form.field.VTypes.js END
      Ext.form.field.VTypes['emaillist'] = function(v) {
        var mailIsValid = true;
        if (isEmpty(v)){return true;}
        else{
           var mailArr = v.split(';');
           var mi;
           mailIsValid = true;
           for(mi=0; mi<mailArr.length && mailIsValid; mi++){
             var mail = mailArr[mi].replace(trimX, '');
             //mailIsValid = mail.indexOf('@')>-1;  
             mailIsValid = isEmpty(mail) || emailX.test(mail);  
             //extVia.notify({action: 'validate emaillist'  , mssg: mailIsValid+' ['+ mail+']'});
           }
        }
        return mailIsValid;
      };
      Ext.form.field.VTypes['emaillistText'] = 'Das Eingabefeld soll E-Mail-Adressen im Format "benutzer@beispiel.de" oder "b.nutzer@beispiel.de" enthalten. Trennzeichen (;). ';
      Ext.form.field.VTypes['emaillistMask'] =   /[a-z0-9_\.\-@;]/i;
      
////////////// Copied from distributionsApp.js Proto END //////////////     
      
      
      
      
      
      
      
      
      var me = this;
      
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      me = this;
      var  modulDscr = 'Planner';
      var epobDscr = 'Alle';
      
//      try{
//      alert(' extVia.dummies.pdkeditor.SYNC_Nodes '+ Ext.encode(extVia.dummies.pdkeditor) );
//      } catch(ex){alert(ex)}
      
      
    Array.prototype.move = function (old_index, new_index) {
	    if (new_index >= this.length) {
	        var k = new_index - this.length;
	        while ((k--) + 1) {
	            this.push(undefined);
	        }
	    }
	    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
	    return this; // for testing purposes
    };
      
      
      
      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      
      extVia.constants.raster.mainWestWidth = 360;
      
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:false, hideWest:true,  modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);

      
      var pgjobStartBtn = {itemId:'start', scale : extVia.constants.raster.pagetoolbarCenterBtnScale, xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}};
      var pgjobStopBtn = {itemId:'stop', scale : extVia.constants.raster.pagetoolbarCenterBtnScale};

      var pagejobButtons = [pgjobStartBtn, pgjobStopBtn];
      

      
      var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
      


      
      
      
      
   Ext.create('Ext.data.Store', {
    storeId:'exportsPlansStore',
    fields:['name', 'changedate', 'size'],
    data:{'items':[
        { name: 'Do it s',  changedate:"26.09.2016 17:09",  size:"111 kb"  },
        { name: 'Change dies und das',  changedate:"27.09.2016 11:09",  size:"555 kb" },
        { name: 'Copy all', changedate:"28.09.2016 12:09",  size:"222 kb"  },
        { name: 'Search and Destroy', changedate:"29.09.2016 11:55", size:"666 kb"  }
    ]},
    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            root: 'items'
        }
    }
});


      
      var  tbar = ['->',    {iconCls: 'xty_pgtoolbar-list'}, {iconCls: 'xty_pgtoolbar-new', itemId:'new'}, {iconCls: 'xty_pgtoolbar-edit',itemId:'edit'},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete'} ];         
   
      
      var exportplansWestTab = {
          title:'Exportplanung', 
          itemId:'exportplansTab',
          
          tbar:[
          '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'L�schen', handler: me.deleteEpobDialog}
          ],
          items:[         {
            xtype:'grid',
	       itemId:'exportsPlansGrid',
	       border:false,
	       store: Ext.data.StoreManager.lookup('exportsPlansStore'),
	        columns: [
	            { header: 'Typ',  datasIndex: 'name', width:32 },
	            { header: 'Name',  dataIndex: 'name' ,  flex: 1},
	            { header: 'Geändert', dataIndex: 'changedate', width:100 },
	            { header: 'Grösse', dataIndex: 'size', width:50 }
	        ],
	        height: 200,
	        width: 400
           } ] 
          };

 
      

      
      
      
      
     // Confluence Optimisation of the Planner Modules
      // >>> PROD V4 Start (EPIM-7678) <<<
      // >>> PROD V4 End (EPIM-7678) <<<
     /*      
Tabellenspalten f�r XML-Export
    Checkbox, Name, Schedulingtyp (1,daily,weekly)
    Next run (in sortierbarer Form), Status (als Icon mit Tooltipp)
    Publikationstyp (Publikation, Exportvorlage)
    Kommentar

Tabellenspalten f�r XML/CSV-Import (einmalig, Verz�berw)
    Checkbox, Name (einmalig=Dateiname; Verz�berw=Name + Verzeichnis)
    Verzeichnis (einmalig=Verzeichnis der Datei; Verz�berw=Verzeichnis der �berwachung)
    Schedulingtyp (einmalig, Verz�berw), Next Run (nur bei einmalig), Status (nur bei Verz�berw), Importtyp (XML, CSV)

Tabellenspalten f�r Report
    Checkbox, Name (Reportname), Schedulingtyp (1,daily,weekly), Next Run (wird aktuell nicht angeboten) ,Status (als Icon mit Tooltipp)  
   */       
       
          
          
       
      var importplansWestTab = { 
        title:'Importplanung', 
        itemId:'importplansTab',
        tbar:tbar
      };    
          
          
//      var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
//          tabBar:{ 
//            tools:[
//           {xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', 
//            handler:function(button){
//              var activeTab = button.ownerCt.ownerCt.getActiveTab();
//                extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
//              }
//             },
//            {xtype:'button', cls:'xty_striptool-button xty_striptool-button-moveRight', iconCls:'x-tool x-tool-moveRight',
//            handler:function(button){
//              var activeTab = button.ownerCt.ownerCt.getActiveTab();
//              
//               // extVia.regApp.myRaster.addToCenter(activeTab); 
//               var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
//               var moveToCenterTab = centerTabPan.addAndActivate(activeTab);
//               extVia.notify({action: 'moveRight West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
//              }
//             }
//            ]
//          },
//          
//          items:[ exportplansWestTab, importplansWestTab]
//         
//          ,listeners:{      
//
//          }
//
//          });
//      extVia.regApp.myRaster.addToWest(tabPanWest);


        // Your App
        var pdkAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Standorte', epobDscr:null,   pagetoolbarButtsons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
        var pdkPanel = {title:'Distribution &Uuuml;bersicht',closable:true,  tbar: pdkAppbar, items:[{html:'hello Distributions App', margin:'24 24 24 24'}] };
        //extVia.regApp.myRaster.addToCenter(appPanel); //  set BaseRaster modulDscr to null
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel(  {
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
       handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
      iconCls:'x-tool x-tool-refresh'}]  } });
      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
     // tabPanCenter.add(distributionsPanel);

      

      pagejobButtons =  ['->' ,pgjobStartBtn, pgjobStopBtn] ;
      
      var newBtnGrpHandler = function(btn){ 
          var module =extVia.regApp.myRaster.getCenterTabPanel().getActiveTab().itemId;
          me.createPlanningDialog({dscr:btn.text, module: module});
          
      };

      var newBtn = { margin:'0 4 0 0', rowspan:2, itemId:'new', iconCls:'xty_pgtoolbar-new', scale:'medium', tooltip:'Planung erstellen',  xtype:'splitbutton', arrowAlignX:'bottom',
                     menu:{items:[{text:'CSV once'},{text:'CSV event'}, {text:'XML once'},{text:'XML event'}]}
      };
      var newBtnGrp = {margin:'0 4 0 0', defaults:{handler:newBtnGrpHandler}, xtype:'buttongroup', headerPosition : 'bottom', title: 'Planung erstellen', columns:2, 
          items:[
            {text:'CSV once'},{text:'XML once'}, {text:'CSV event'},{text:'XML event'}]
      };
      
      

      
     

      
      var searchBtn = { 
        xtype: 'triggerfield',  
        margin: '3 0 2 2',
        name: 'searchtext', 
        itemId:'searchtext',
        tooltip:'searchy',
        //emptyText:'Suchen',
        cls:'xty_has-insidetrigger', 
        trigger2Cls : 'xty_search-inside-trigger',
        trigger1Cls:'xty_inside-trigger-clear' , 
        onTrigger1Click: function(evt){
         var targetEl = Ext.get(evt.target.id); 
         var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
         var field = Ext.getCmp(fieldId);
         field.setValue('');
        },
        onTrigger2Click:function(evt){
          var targetEl = Ext.get(evt.target.id); 
          var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
          var field = Ext.getCmp(fieldId);
          
          extVia.notify({mssg:'submit<br><b>'+field.getValue()+'<b>', action:'Search'});
        },
        enableKeyEvents:true,
        listeners:{
          keydown:function(field, evt){
            if (evt.getKey()===Ext.EventObject.ENTER){
               extVia.notify({mssg:'submit <br><b>'+field.getValue()+'<b>', action:'Search by ENTER '});
            }
             else if (evt.getKey()===Ext.EventObject.DELETE){
                field.setValue(''); 
             }
          } 
        }
      };
      
      
      
      
      
      
      //var filterField = {xtype:'triggerfield', margin:'0 0 2 0',itemId:'filter', cls : 'xty_inside-trigger', trigger1Cls : 'xty_filter-inside-trigger'}; 
      //var filterBtn = {xtype:'button', margin:'0 10 2 0',itemId:'filter', iconCls : 'xty_form-trigger-filter'};
      var filterBtnGrp = {margin:'0 8 0 0', defaults:{handler:newBtnGrpHandler}, xtype:'buttongroup', headerPosition : 'bottom', xtitle: 'Filter', columns:3, 
         items:[
           
           {  
             xtype:'spinnerfield', 
             fieldLabel:'0/0',
             labelWidth:16,
             labelSeparator: '',
             itemId:'searchMatchesSpinner',
             margin: '3 0 2 2',
             disabled:true,
             width:36, 
             editable : false , 
             cls:'xty_spinner-plain xty_spinner-left'
             }, 
           
           
           
           searchBtn,
           
           { iconCls:'x-tool-filter', tooltip:'filter', margin: '3 0 2 2', 

             handler:function(btn){
               var planningsGrid =  Ext.getCmp('planingTypesPlanner'); // Better with btn.ownerCt ....
               var filterbar  = planningsGrid.getComponent('filterbar');
               
               if(filterbar.isVisible()){
                 filterbar.hide();
               }
               else{
                 filterbar.show();
               }
              }
           }
           
           
           ]
      };
      

      pagejobButtons =  ['->' ,
        
//            { 
//            xtype:'splitbutton', 
//            text:   'text',
//            tooltip: 'tooltip', 
//            itemId:'filter-query-Product',
//            iconCls:'xty_epobProduct',  
//            cls:'xty_actionbar-filter-item xty_filter-item-Searchable',  
//            scale:'small'
//          },

        
        
        filterBtnGrp, newBtn ] ;

 
      
      var baseplansAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Baseplanner' , epobDscr: 'Alle ',  pgjosbbarHeight: 72 ,  pagetoolbarButxxtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var baseplansTab  = {title:'Base', itemId:'base', tbar: baseplansAppbar, xiconCls: 'xty_icon xty_iconPlanned',
        items:[  me.getPlannerGrid()  ]   
      };
      tabPanCenter.add(baseplansTab);  
      
      
      var importplansAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Importplanung' , epobDscr: 'Alle ',   pagetoolbarButxxtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var importplansTab  = {title:'Import',  itemId:'import', tbar: importplansAppbar, xiconCls: 'xty_icon xty_iconPlanned',
        items:[    ]   
      };
      importplansAppbar.setHeight(72);// because of btngrp headers
      tabPanCenter.add(importplansTab);  
      
      
      //  3082
      var exportGridCfg = me.getExportPlannerGridCfg();

      
      var exportplansAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Exportplanung' , epobDscr: 'Alle ',   pagetoolbarButxxtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var exportplansTab  = {title:'Export',  itemId:'export', tbar: exportplansAppbar, xiconCls: 'xty_icon xty_iconPlanned',
        items:[ exportGridCfg ]   
      };
      tabPanCenter.add(exportplansTab);    
      


      
      var reportplansAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Reportplanung' , epobDscr: 'Alle ',   pagetoolbarButxxtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var reportplansTab  = {title:'Report', itemId:'report', tbar: reportplansAppbar, xiconCls: 'xty_icon xty_iconPlanned',
        items:[  ]   
      };
      tabPanCenter.add(reportplansTab);       
      


      
      
      var anchor ;
      var url = location.href;
      var hashIndex = url.indexOf('#');
      if (hashIndex>-1){
        anchor = url.substring(hashIndex+1);  
        if (anchor){
            var centerTabPan = extVia.regApp.myRaster.getCenterTabPanel();
            var exportTab = centerTabPan.setActiveTab(anchor);
            centerTabPan.setActiveTab(exportTab);
        } 
      }
      
    }
});

