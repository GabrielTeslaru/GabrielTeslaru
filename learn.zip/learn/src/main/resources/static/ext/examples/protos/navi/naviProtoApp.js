/*


*/
Ext.application({
    name: 'naviProtoApp',
    
    /**
     * Place 
     */
    appMode:{},


    launch: function() {
    	var me = this;
    	
    	
    	Ext.Loader.setConfig({enabled: true});
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7))
    	}));
    	extVia.regApp = this;	
    	var  modulDscr = 'navi App';
    	

    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
    	extVia.ui.page.raster.onReady(this);
    	

    	var tabPan = extVia.regApp.myRaster.initWestTabPanel({items:[{title:'Liste'}] });
    	extVia.regApp.myRaster.addToWest(tabPan);
    	

    	
    	var navtype = me.getUrlParam('navtype');
    	tabPan = extVia.regApp.myRaster.initCenterTabPanel();
    	
    	if(!Ext.isEmpty(navtype)) {
    		var north = extVia.regApp.myRaster.getNorth();
    		
    		var menubarTbar = north.getComponent('menubar-bin').getComponent('menubar-tbar'); //getDockedComponent(
    		menubarTbar.removeAll();
    		
    		
    		Ext.create('ExtVia.data.NavigationTreeStore');
    		if("breadcrumb" === navtype) {
    			var breadcrumbtipp = me.getUrlParam('breadcrumbtipp') || 'true';
    			
    			menubarTbar.add(Ext.create('extVia.nav.Breadcrumb', {
    				mouseover : breadcrumbtipp === 'true'
    			}));
    		} else if("twolines" === navtype) {
    			var lev3 = me.getUrlParam('lev3') || 'inline';
    			var menubarItems = north.items.items.splice(1);
    			
    			north.removeAll();
    			
    			north.insert(0,Ext.create('extVia.nav.TwoLines', {
    				thridLevelType : lev3,
    				north: north,
    				menubarItems : menubarItems.splice(),
    				tabPan : tabPan
    			}));

    		} else if("palette" === navtype) {
    			north.removeAll();
    			
    			north.inser(0, Ext.create('extVia.navi.Palette', {
    				menubarItems : menubarItems.splice()
    			}));
    		}
    	}
    	
    	
    	extVia.regApp.myRaster.addToCenter(tabPan);	
    	
    },
    
    getUrlParam : function(param) {
    	var url = window.location.href,
    		paramString;
    	
    	paramString = url.split('?')[1] || '';
    	return Ext.Object.fromQueryString(paramString)[param] || null;
    }
});



/*
 * 
 * $Revision: 1.7 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2016/02/23 14:44:41 $
 * $Author: student2 $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
