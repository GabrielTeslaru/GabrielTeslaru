Ext.namespace('extVia.campaigns.statistics.view');
/**
 * @class extVia.campaigns.statistics.main Provides ui + data + models + stores + views<br>
 *        May run as subApp
 * 
 * @author Artur Taranyuk, Viamedici Software GmbH
 * @version $Date: 2013/05/06 17:07:49 $ $Revision: 1.19 $
 */
extVia.campaigns.statistics.view = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.statistics.view",
    name : "extVia.campaigns.statistics.view"
  });
};

extVia.campaigns.statistics.view.prototype = {

  // Chart f�f die Fertigstellung
  getGaugeChart : function getGaugeChart(chartStore) {

    var gaugeChart = Ext.create('Ext.chart.Chart', {
      style : 'background:#fff',
      animate : {
        easing : 'elasticIn',
        duration : 1000
      },
      store : chartStore,
      insetPadding : 25,
      flex : 1,
      axes : [ {
        type : 'gauge',
        position : 'gauge',
        minimum : 0,
        maximum : 100,
        steps : 10,
        margin : 7
      } ],
      series : [ {
        type : 'gauge',
        renderer : function(sprite, record, attr, index, store) {

          var value = record.get("FGrad");

          var color = null;
          if (value >= 20 & value < 40) {
            color = "#FE9A2E";
          } else if (value >= 40 & value < 60) {
            color = "#F7FE2E";
          } else if (value >= 60 & value < 80) {
            color = "#D0FA58";
          } else if (value >= 80) {
            color = "#3ADF00";
          } else {
            color = "#FF0000";
          }
          if (index == 0) {
            return Ext.apply(attr, {
              fill : color
            });
          } else {
            return Ext.apply(attr, {
              fill : '#ddd'
            });
          }

        },
        donut : 30,
        field : 'FGrad',
        colorSet : [ '', '#ddd' ]
      } ]
    });

    return gaugeChart;

  },
  // Chart f�r die Effizienz
  getGaugeChartEfficiency : function getGaugeChartEfficiency(chartStore) {

    var gaugeChartEfficiency = Ext.create('Ext.chart.Chart', {
      style : 'background:#fff',
      animate : {
        easing : 'elasticIn',
        duration : 1000
      },
      store : chartStore,
      insetPadding : 25,
      flex : 1,
      axes : [ {
        type : 'gauge',
        position : 'gauge',
        minimum : 0,
        maximum : 3,
        steps : 3,
        margin : 7
      } ],
      series : [ {
        type : 'gauge',
        renderer : function(sprite, record, attr, index, store) {

          var value = record.get("Efficiency");

          var color = null;
          if (value >= 1 & value < 2) {
            color = "#008000";
          } else if (value >= 2) {
            color = "#7fff00";
          } else if (value >= 0.8 & value < 1) {
            color = "#ffff00";
          } else {
            color = "#FF0000";
          }
          if (index == 0) {
            return Ext.apply(attr, {
              fill : color
            });
          } else {
            return Ext.apply(attr, {
              fill : '#ddd'
            });
          }

        },
        donut : 30,
        field : 'Efficiency',
        colorSet : [ '', '#ddd' ]
      } ]
    });

    return gaugeChartEfficiency;

  },

  // Chart f�r BudgetIst
  getPieChart : function getPieChart(chartStore) {

    var pieChart = Ext.create('Ext.chart.Chart', {

      animate : true,
      store : chartStore,// extVia.campaigns.statistics.main.getStorePie(),
      shadow : true,
      legend : {
        position : 'left'
      },
      // insetPadding: 60,
      theme : 'Base:gradients',
      series : [ {
        type : 'pie',
        field : 'BudgetI',
        showInLegend : true,
        tips : {
          trackMouse : true,
          width : 140,
          height : 28,
          renderer : function(storeItem, item) {
            // calculate percentage.
            var total = 0;
            chartStore.each(function(rec) {
              total += parseInt(rec.get('BudgetI'));
            });
            this.setTitle(storeItem.get('Name') + ': ' + Math.round(storeItem.get('BudgetI') / total * 100) + '%');
          }
        },
        highlight : {
          segment : {
            margin : 20
          }
        },
        label : {
          field : 'Name',
          display : 'rotate',
          contrast : true,
          font : '12px Arial'
        }
      } ]
    });

    return pieChart;
  },
  // Chart f�r BudgetIst/Soll
  getColumnChart : function getColumnChart(chartStore) {
    var max = 0;
    for ( var i = 0; i < chartStore.data.items.length; i++) {
      if (parseInt(chartStore.data.items[i].data.BudgetI) > max) {
        max = parseInt(chartStore.data.items[i].data.BudgetI);
      }
      ;
      if (parseInt(chartStore.data.items[i].data.BudgetS) > max) {
        max = parseInt(chartStore.data.items[i].data.BudgetS);
      }
      ;
      if (parseInt(chartStore.data.items[i].data.BudgetP) > max) {
        max = parseInt(chartStore.data.items[i].data.BudgetP);
      }
      ;
    }
    ;

    var columnChart = Ext.create('Ext.chart.Chart', {

      style : 'background:#fff',
      animate : true,
      shadow : true,
      legend : {
        position : 'left'
      },
      store : chartStore, // extVia.campaigns.statistics.main.getStorePie(),
      axes : [ {
        type : 'Numeric',
        position : 'left',
        fields : [ 'BudgetI', 'BudgetS', 'BudgetP' ],
        label : {
          renderer : Ext.util.Format.numberRenderer('0,0')
        },
        grid : true,
        minimum : 0,
        maximum : max
      }, {
        type : 'Category',
        position : 'bottom',
        fields : [ 'Name' ]
      } ],
      series : [ {
        type : 'column',
        axis : 'left',
        highlight : true,
        label : {
          display : 'insideEnd',
          'text-anchor' : 'middle',
          field : [ 'BudgetI', 'BudgetS', 'BudgetP' ],
          renderer : Ext.util.Format.numberRenderer('0'),
          orientation : 'vertical',
          color : '#333'
        },
        xField : 'Name',
        yField : [ 'BudgetI', 'BudgetS', 'BudgetP' ]
      } ]
    });

    return columnChart;

  },
  // Panel f�r parent charts
  getChartPanel : function getChartPanel(chart, dbwidth, dbheight, name) {

    var chartPanel = Ext.create('Ext.panel.Panel', {
      title : name,
      height : dbheight,
      width : dbwidth,
      animCollapse : false,
      layout : 'fit',
      collapsible : true,
      items : [ chart ]
    });

    return chartPanel;
  },
  
  
  // Panel f�r children charts
  getChildChartPanel : function getChildChartPanel(chart, dbwidth, dbheight, name) {

    var childChartPanel = Ext.create('Ext.panel.Panel',
            {
              // border: false,
              title : name,
              height : dbheight,
              width : dbwidth,
              animCollapse : false,
              // flex: 1,
              layout : 'fit',
              collapsible : true,
              tools : [ {
                type : 'gear',
                tooltip : 'Show menu',
                handler : function(event, toolEl, panel) {
                  // var menu;
                  var tempPanel = this.up().up();
                  if (!this.menu) {
                    this.menu = new Ext.menu.Menu(
                        {
                          floating : true,
                          items : [
                                   {
                                     text : 'Budget Ist',
                                     handler : function() {
                                       // var tempPanel = this.up().up().up();
                                       var pieStore = extVia.campaigns.statistics.main.createStore();
                                       var schTreeId = Ext.get('panel_mC').down('a').parent().id;
                                       var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
                                       var lockedTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().locked;
                                       var record = lockedTree.getSelectionModel().selected.items[0];
                                       var split = tempPanel.title.split(' &raquo');
                                       for ( var i = 0; i < record.data.children.length; i++) {
                                         var child = record.childNodes[i];
                                         if (record.data.children[i].Name == split[0]) {
                                           pieStore.add(child.data.children);
                                         }
                                       }
                                       tempPanel.removeAll();
                                       tempPanel.add(extVia.campaigns.statistics.view.getPieChart(pieStore));
                                       tempPanel.setTitle(split[0] + " &raquo; Budget Ist");
                                       // tempPanel.doLayout();
                                     }
                                   },
                                   {
                                     text : 'Budget Ist/Soll',
                                     handler : function() {
                                       // var tempPanel = panel;
                                       var columnStore = extVia.campaigns.statistics.main.createStore();
                                       var schTreeId = Ext.get('panel_mC').down('a').parent().id;
                                       var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
                                       var lockedTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().locked;
                                       var record = lockedTree.getSelectionModel().selected.items[0];
                                       var split = tempPanel.title.split(' &raquo');
                                       for ( var i = 0; i < record.data.children.length; i++) {
                                         var child = record.childNodes[i];
                                         if (record.data.children[i].Name == split[0]) {
                                           columnStore.add(child.data.children);
                                         }
                                       }
                                       tempPanel.removeAll();
                                       tempPanel.add(extVia.campaigns.statistics.view.getColumnChart(columnStore));
                                       tempPanel.setTitle(split[0] + " &raquo; Budget Ist/Soll");
                                       // tempPanel.doLayout();
                                     }
                                   },
                                   {
                                     text : 'Fertigstellung',
                                     handler : function() {
                                       // var tempPanel = panel;
                                       var gaugeStore = extVia.campaigns.statistics.main.createStore();
                                       var schTreeId = Ext.get('panel_mC').down('a').parent().id;
                                       var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
                                       var lockedTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().locked;
                                       var record = lockedTree.getSelectionModel().selected.items[0];
                                       var split = tempPanel.title.split(' &raquo');
                                       var items;
                                       for ( var i = 0; i < record.data.children.length; i++) {
                                         if (record.data.children[i].Name == split[0]) {
                                           gaugeStore.add(record.data.children[i]);
                                         }
                                       }
                                       if (gaugeStore.data.items[0].get('FGrad') != '') {
                                         items = extVia.campaigns.statistics.view.getGaugeChart(gaugeStore);
                                       } else {
                                         items = ( {
                                           border : false,
                                           bodyStyle : 'padding:10px 10px 10px 10px',
                                           html : '<div class="xty_dialog-mainInstr">Fertigstellung ist noch nicht angefangen</div>'
                                         } );
                                       }
                                       tempPanel.removeAll();
                                       tempPanel.add(items);
                                       tempPanel.setTitle(split[0] + " &raquo; Fertigstellung");
                                       // tempPanel.doLayout();
                                     }
                                   },
                                   {
                                     text : 'Effizienz',
                                     handler : function() {
                                       var schTreeId = Ext.get('panel_mC').down('a').parent().id;
                                       var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
                                       var lockedTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().locked;
                                       var record = lockedTree.getSelectionModel().selected.items[0];
                                       var gaugeStoreEfficiency = extVia.campaigns.statistics.main
                                           .createStoreEfficiency();
                                       var split = tempPanel.title.split(' &raquo');
                                       var items = null;
                                       for ( var i = 0; i < record.data.children.length; i++) {
                                         if (record.data.children[i].Name == split[0]) {
                                           var event = extVia.campaigns.statistics.control.getEvent(record,
                                               record.data.children[i].Id);
                                           if (event) {
                                             var efficiency = extVia.campaigns.statistics.control.getEfficiency(event,
                                                 record.data.children[i].FGrad);

                                             if (efficiency > 3) {
                                               gaugeStoreEfficiency.add({
                                                 Efficiency : '3'
                                               });
                                             } else if (efficiency < 0) {
                                               gaugeStoreEfficiency.add({
                                                 Efficiency : '0'
                                               });
                                             } else {
                                               gaugeStoreEfficiency.add({
                                                 Efficiency : efficiency
                                               });
                                             }
                                             if (efficiency >= 0) {
                                               items = extVia.campaigns.statistics.view
                                                   .getGaugeChartEfficiency(gaugeStoreEfficiency);
                                             } else {
                                               items = ( {
                                                 border : false,
                                                 bodyStyle : 'padding:10px 10px 10px 10px',
                                                 html : '<div class="xty_dialog-mainInstr">Projekt wurde noch nicht angefangen</div>'
                                               } );
                                             }
                                           } else {
                                             items = ( {
                                               border : false,
                                               bodyStyle : 'padding:10px 10px 10px 10px',
                                               html : '<div class="xty_dialog-mainInstr">Es ist kein Projekt vorhanden</div>'
                                             } );
                                           }

                                         }
                                       }
                                       tempPanel.removeAll();
                                       tempPanel.add(items);
                                       tempPanel.setTitle(split[0] + " &raquo; Effizienz");
                                     }
                                   }

                          ]
                        }).showAt(event.getXY());
                  }
                }
              } ],

              // tbar: [
              // { xtype: 'button',
              // text: 'Pie Chart',
              // listeners: {
              // click: function(){
              // var tempPanel = this.up().up();
              // var store = tempPanel.items.items[0].store;
              // tempPanel.removeAll();
              // tempPanel.add(extVia.campaigns.statistics.view.getPieChart(store));
              // tempPanel.doLayout();
              // }
              // }
              // },
              // { xtype: 'button',
              // text: 'Column Chart',
              // listeners: {
              // click: function(){
              // var tempPanel = this.up().up();
              // var store = tempPanel.items.items[0].store;
              // tempPanel.removeAll();
              // tempPanel.add(extVia.campaigns.statistics.view.getColumnChart(store));
              // tempPanel.doLayout();
              // }
              // }
              // }
              // ],

              items : [ chart ]
            });

    return childChartPanel;
  },

  /**
   * Das aeu�ere Panel f�r parents bzw. children charts
   */
  getChildPanel : function getChildPanel(height, width, name, isParent) {

    var pgBoxMargin = extVia.constants.raster.pgBoxMargin;
    var childPanel = Ext.create('Ext.panel.Panel', {
      titsle : name,
      bodyStyle : 'border:0px;',
      preventHeader : true,
      autoScroll : true,
      // bodyStyle: 'overflow-y: hidden !important;',
      height : height,
      width : width,
      defaults : {
        margins : pgBoxMargin+ ' 0 0 ' + pgBoxMargin
      },
      layout : 'vbox',
      tbar : Ext.create('Ext.toolbar.Toolbar', {
        baseCls : 'x-column-header',
        itemId : 'pagejobbar',
        height : 46,
        border : false,
        items : [ {
          xtype : 'tbtext',
          itemId : 'epobdscr_1',
          // cls: 'x-column-header',
          text : '<span id="pgjobEpobDscr-' + '" class="x-column-header-inner"> ' + name + '</span>',
        } ]
      })
    });

    return childPanel;
  },

  // Panel f�r die Statistik
  getPanel : function getPanel(height, width) {

    var panel = Ext.create('Ext.panel.Panel', {
      bodyStyle : 'border:0px;',
      autoScroll : true,
      layout : 'hbox'
    });

    return panel;
  }

};

// init Object as singleton
extVia.campaigns.statistics.view = new extVia.campaigns.statistics.view();

/*
 * 
 * $Revision: 1.19 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/06 17:07:49 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */