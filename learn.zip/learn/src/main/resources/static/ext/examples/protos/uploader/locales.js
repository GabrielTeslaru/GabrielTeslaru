Ext.namespace('extVia.locales' ,'extVia.uploader.locales');
/**
 * @class uploader
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2018/01/05 09:15:00 $
 *            $Revision: 1.1 $
 */





extVia.uploader.locales = {
        appName:'uploader',
        modul:'uploader',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.uploader.locales);



/*
 * 
 * $Revision: 1.1 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2018/01/05 09:15:00 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 