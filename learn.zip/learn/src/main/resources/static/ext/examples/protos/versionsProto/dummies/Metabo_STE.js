extVia.versionsProto.Metabo_STE = 
[
// Metadata areaorder: 1              
{"name":"Hierarchie","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Stichs\u00E4gen","userWork":"Douglas Crockford","changedateWork":"06.02.2014","changetimeWork":"11:03:14","valueVersion":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Stichs&auml;ge","userVersion":"Paul Coelho","changedateVersion":"06.02.2014","changetimeVersion":"11:03:23","epimIdWork":"ms_h-2","epimIdVersion":"ms_h-2"},                    
{"name":"Name","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo STE","userWork":"Lars Hinrichs","changedateWork":"05.02.2014","changetimeWork":"16:32:23","valueVersion":"Metabo STEb","userVersion":"Doug Engelbart","changedateVersion":"05.02.2014","changetimeVersion":"16:32:27","epimIdWork":"ms_n-1","epimIdVersion":"ms_n-1"},
{"name":"Id","area":"Metadata","areaorder":"1","dataType":"Number","valueWork":"13737","userWork":"Douglas Crockford","changedateWork":"05.02.2014","changetimeWork":"16:30:26","valueVersion":"1","userVersion":"Douglas Crockford","changedateVersion":"05.02.2014","changetimeVersion":"16:30:26","epimIdWork":"mn_i-1","epimIdVersion":"mn_i-1"},
{"name":"Mastersprache","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Deutsch","userWork":"Steve Krug","changedateWork":"06.02.2014","changetimeWork":"11:01:06","valueVersion":"Deutsch","userVersion":"Steve Krug","changedateVersion":"06.02.2014","changetimeVersion":"11:01:06","epimIdWork":"ms_m-1","epimIdVersion":"ms_m-1"},
{"name":"Letzte \u00c4nderung","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"John Bonham - 06.02.2014","userWork":"John Bonham","changedateWork":"06.02.2014","changetimeWork":"11:13:07","valueVersion":"Klausbernd Vollmar - 02.02.2014","userVersion":"Klausbernd Vollmar","changedateVersion":"02.02.2014","changetimeVersion":"11:13:43","epimIdWork":"ms_l-2","epimIdVersion":"ms_l-2"},

//Workflows areaorder: 2 
{"name":"Katalog","area":"Workflows","areaorder":"2","dataType":"WorkflowState","valueWork":"Freigegeben","userWork":"Oscar Wilde","changedateWork":"06.02.2014","changetimeWork":"10:46:46","valueVersion":"In Bearbeitung","userVersion":"Ringo Starr","changedateVersion":"06.02.2014","changetimeVersion":"10:47:19","epimIdWork":"ww_k-5","epimIdVersion":"ww_k-5"},

//ChangeInfo areaorder: 3 
{"name":"Letzte \u00c4nderung","area":"ChangeInfo","areaorder":"3","dataType":"Changeinfo","valueWork":"John Bonham - 06.02.2014","userWork":"John Bonham","changedateWork":"06.02.2014","changetimeWork":"11:13:07","valueVersion":"Klausbernd Vollmar - 02.02.2014","userVersion":"Klausbernd Vollmar","changedateVersion":"02.02.2014","changetimeVersion":"11:13:43","epimIdWork":"cc_l-3","epimIdVersion":"cc_l-3"},
{"name":"Anlage","area":"ChangeInfo","areaorder":"3","dataType":"Changeinfo","valueWork":"John Bonham - 05.01.2014","userWork":"Susanne Fischer-Rizzi","changedateWork":"05.01.2014","changetimeWork":"11:16:12","valueVersion":"John Bonham - 05.01.2014","userVersion":"Susanne Fischer-Rizzi","changedateVersion":"05.01.2014","changetimeVersion":"11:16:12","epimIdWork":"cc_a-4","epimIdVersion":"cc_a-4"},

//Languages
{"name":"Sprachen","area":"Sprachen","childOrParent":"parent",  "areaorder":"1","dataType":"Language","valueWork":"de,en,us,es,it,fr","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"de,en,us,es","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5","epimIdVersion":"ml_s-5"},
{"name":"Sprach&auml;nderung","area":"Sprachen","childOrParent":"child",  "specprop-parentId":"ml_s-5", "areaorder":"1","dataType":"Language","valueWork":"es,fr","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"de,es","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5c","epimIdVersion":"ml_s-5c"},
{"name":"&Uuml;bersetzungen","area":"Sprachen","childOrParent":"lastchild",  "specprop-parentId":"ml_s-5", "areaorder":"1","dataType":"Language","valueWork":"en,us","userWork":"Oscar Wilde","changedateWork":"19.02.2014","changetimeWork":"17:26:38","valueVersion":"en,us","userVersion":"Keith Moon","changedateVersion":"19.02.2014","changetimeVersion":"17:26:53","epimIdWork":"ml_s-5c","epimIdVersion":"ml_s-5c"},


//Attribute areaorder: 4 
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"String","multiplicity":"3","valueWork":"DSL","userWork":"Lisa Kekaula","changedateWork":"05.02.2014","changetimeWork":"16:33:06","valueVersion":"DSL","userVersion":"Lisa Kekaula","changedateVersion":"05.02.2014","changetimeVersion":"16:33:06","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"String","multiplicity":"3","valueWork":"WLAN","userWork":"Lisa Kekaula","changedateWork":"05.02.2014","changetimeWork":"16:33:06","valueVersion":"WLAN","userVersion":"Lisa Kekaula","changedateVersion":"05.02.2014","changetimeVersion":"16:33:06","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"String","multiplicity":"3","valueWork":"VoIP","userWork":"Lisa Kekaula","changedateWork":"05.02.2014","changetimeWork":"16:33:06","valueVersion":"VoIP","userVersion":"Lisa Kekaula","changedateVersion":"05.02.2014","changetimeVersion":"16:33:06","epimIdWork":"as_z-2","epimIdVersion":"as_z-2"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"Selection","multiplicity":"3","valueWork":"DSL","userWork":"Ringo Starr","changedateWork":"05.02.2014","changetimeWork":"16:33:39","valueVersion":"ISDN","userVersion":"Clemens Lutsch","changedateVersion":"05.02.2014","changetimeVersion":"16:34:00","epimIdWork":"as_z-3","epimIdVersion":"as_z-3"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"Selection","multiplicity":"3","valueWork":"WLAN","userWork":"Ringo Starr","changedateWork":"05.02.2014","changetimeWork":"16:33:39","valueVersion":"LAN","userVersion":"Clemens Lutsch","changedateVersion":"05.02.2014","changetimeVersion":"16:34:00","epimIdWork":"as_z-3","epimIdVersion":"as_z-3"},
{"name":"Feature","area":"Attribute","areaorder":"4","dataType":"Selection","multiplicity":"3","valueWork":"VoIP","userWork":"Ringo Starr","changedateWork":"05.02.2014","changetimeWork":"16:33:39","epimIdWork":"as_z-3"},

	

//Produktbeziehungen areaorder: 7 
{"name":"Ersatzteil","area":"Produktbeziehungen","areaorder":"7","dataType":"ProductAssignment","specprop-prodrel":"Products","valueWork":"Kugellager","userWork":"Phil Rudd","changedateWork":"07.02.2014","changetimeWork":"16:49:53","valueVersion":"Kugellager","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"16:49:53","epimIdWork":"pp_e-5","epimIdVersion":"pp_e-5"},

{"name":"Zubeh\u00f6r","area":"Produktbeziehungen","areaorder":"7","dataType":"ProductVariant","childOrParent":"parent", "valueWork":"Koffer","userWork":"Carlos Ruiz Zafon","changedateWork":"07.02.2014","changetimeWork":"17:32:47","valueVersion":"Koffer","userVersion":"Carlos Ruiz Zafon","changedateVersion":"11.12.2013","changetimeVersion":"17:32:47","epimIdWork":"pp_z-1","epimIdVersion":"pp_z-1"},
{"name":"Inhalt","area":"Attribute","areaorder":"4","dataType":"String","childOrParent":"child", "specprop-parentId":"pp_z-1","specprop-multiplicity":"3","collectionEntryType":"String","collectionEntryName":"","valueWork":"Schraubschl\u00fcssel","userWork":"Phil Rudd","changedateWork":"17.01.2014","changetimeWork":"10:05:07","valueVersion":"Steckschl\u00fcssel","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"17:35:07","epimIdWork":"as_i-2","epimIdVersion":"as_i-2"},
{"name":"Inhalt","area":"Attribute","areaorder":"4","dataType":"String","childOrParent":"child", "specprop-parentId":"pp_z-1","specprop-multiplicity":"3","collectionEntryType":"String","collectionEntryName":"","valueWork":"Nuss","userWork":"Phil Rudd","changedateWork":"07.01.2014","changetimeWork":"16:35:07","valueVersion":"Steckschl\u00fcssel","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"17:35:07","epimIdWork":"as_i-2","epimIdVersion":"as_i-33"},
{"name":"Inhalt","area":"Attribute","areaorder":"4","dataType":"String","childOrParent":"lastchild", "specprop-parentId":"pp_z-1","specprop-multiplicity":"3","collectionEntryType":"String","collectionEntryName":"","valueWork":"Steckschl\u00fcssel","userWork":"Phil Rudd","changedateWork":"07.02.2014","changetimeWork":"17:35:07","valueVersion":"Steckschl\u00fcssel","userVersion":"Phil Rudd","changedateVersion":"07.02.2014","changetimeVersion":"17:35:07","epimIdWork":"as_i-2","epimIdVersion":"as_i-44"},


//Beziehungen areaorder: 8 
{"name":"Audio","area":"Beziehungen","areaorder":"8","dataType":"Audio","valueWork":"Hurra Hurra die Schule brennt","userWork":"Dieter Rams","changedateWork":"05.02.2014","changetimeWork":"16:34:56","valueVersion":"Hurra Hurra die Schule brennt","userVersion":"Dieter Rams","changedateVersion":"05.02.2014","changetimeVersion":"16:34:56","epimIdWork":"ba_h-4","epimIdVersion":"ba_h-4"}


];

