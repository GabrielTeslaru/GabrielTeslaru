Ext.namespace('extVia.editor.baseEditor.dummies');
Ext.define('extVia.editor.baseEditor.statics', {
    statics: {
        getLabelSeparator4Required: function (){	
            return ':<span class="xty_requiredStar-icon">&nbsp;&nbsp;&nbsp;</span>';
        },
    	
        getEmptyTextHTML : function(emptyText){	    
    	    if (!emptyText){	  
    	    	emptyText = "Keine Inhalte zum Anzeigen vorhanden";
    	    }	  
    	  	return '<div class="xty_inplaceMessage-bin"><div class="xty_inplaceMessage-empty">'+emptyText+'</div></div>';
    	 },
        

       
       getPagePanelHeight : function (){  
         var me = this;
         var centerPan =  extVia.regApp.myRaster.getCenter();
         var centerHeight = centerPan.getHeight();
         var pagePanelHeight = centerHeight- 28; // substract center-tabstrip 
         return pagePanelHeight; 
        },
       
        getEditorPanelHeight : function (){
          var me = this;
          return me.getPagePanelHeight();
        },

     
        getEditorSubTabPanelHeight : function (cfg){
          var me = this;
          var editorPanelHeight = me.getEditorPanelHeight(); 
          var editorSubTabPanelHeight =  editorPanelHeight 
            - extVia.constants.raster.pgjobEditHeight // substract pagejobbar   -> extVia.constants.raster.pgjobEditHeight = 64;  
            - extVia.constants.raster.pgToolbarEditHeight;  // substract pagetoolbar  ->   extVia.constants.raster.pgToolbarEditHeight= 44; 
          return editorSubTabPanelHeight;
        },
       

        getEditorSubTabContentPanelHeight : function (){
          var me = this;
          var editorSubTabPanelHeight = me.getEditorSubTabPanelHeight(); 
          var editorSubTabContentPanelHeight =  editorSubTabPanelHeight -27;  // substract subtabstrip  
          return editorSubTabContentPanelHeight;
        },  
        
        

       
        flagDisplayTemplate:null,
        getFlagDisplayTemplate :function (cfg){
         var flagDisplayTemplate ;
         if (!extVia.editor.baseEditor.statics.flagDisplayTemplate){
          flagDisplayTemplate =  new Ext.XTemplate([
	        // GROSSE Flagge
	        '<div style="width:100%;height:18px;padding-left:16px;" class="xty_flag-{[values.languageOriginCountryISO3.toUpperCase()]}" title="{languageDscr}"  >' +
	          '<span  style="margin-top:-8px;"></span>' +
	        '</div>' +
	        
	        // kleine Flagge optional
	        '<tpl if="values.usedInCountryISO3!=null">'+  
            '<div style="position:absolute;width:100%;height:18px;" class="xty_flag-usedInCountry-bin" title="{usedInCountryDscr}"  >' +
	          '<img style="margin-top:13px;" height="8" width="10" src="../img/flags/countryISO3/{[values.usedInCountryISO3.toLowerCase()]}.png" />' +
	        '</div>'+     
	        '</tpl>' 
	        ]);
  
            extVia.editor.baseEditor.statics.flagDisplayTemplate =  flagDisplayTemplate;
         }
         
         return extVia.editor.baseEditor.statics.flagDisplayTemplate ;
        },
        

       
       
    	 gridColumnFlagRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
    		 
    		var html =''; 
    		 
    		var langsArr = value.split(',');
    		
    		var i ;
    		for (i =0; i<langsArr.length; i++){
    			var iso2 = langsArr[i];
    			
    			var langDscr = iso2;
    			var language =  extVia.stores.getLanguageFromISO2(iso2);
    			if (language){langDscr = language.dscr;}
    			
    			html+= '<span style=height:18px;padding-left:16px;padding-right:4px;" title="'+langDscr+'" class="xty_icon_'+iso2+'">'+' </span> ';	
    			if (i%5===4){
    				html+='<br>';
    			}
    		}
            return html;
        },
        
        gridColumnImageRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
            return value?'<div class="xty_icon xty_iconCrossref"></div>':'';
        },     
        
        gridColumnStatusRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
            return '<div class="xty_icon xty_icon{value}"></div>';
        }, 
           
        
    generateFlagCss : function(){
    
    
var epimCountryISO3s=[
'ARE','BHR','DZA','EGY','IRQ','JOR','KWT','LBN','LBY','MAR','OMN','QAT','SAU','SDN','SYR','TUN',
'YEM','BLR','BGR','ESP','AND','CZE','DNK','AUT','CHE','DEU','LUX','LIE','CYP','GRC','AUS','CAN',
'GBR','IND','IRL','MLT','NZL','PHL','SGP','USA','ZAF','EST','FIN','BEL','CAN','CHE','FRA','LUX',
'MCO','IRL', 'IRN', 'ISR','IND','HRV','HUN','IDN','ISL','CHE','ITA','SMR','JPN','KOR','LVA','LTU','MKD',
'MLT','MYS','BEL','NLD','NOR','POL','BRA','PRT','ROU','MDA','RUS','SVK','SVN','ARG','BOL','CHL',
'COL','CRI','DOM','ECU','ESP','GTM','HND','MEX','NIC','PAN','PER','PRI','PRY','SLV','URY','USA',
'VEN','ALB','BIH','MNE','MNG','SCG','SRB','SWE','THA','TUR','UKR','VNM','CHN','HKG','SGP','TWN'];


var famfamFlags=[ 
'abw','afg','ago','aia','alb','and','ant','are','arg','arm','asm','atf','atg','aus','aut','ax',
'aze','bdi','bel','ben','bfa','bgd','bgr','bhr','bhs','bih','blr','blz','bmu','bol','bra','brb',
'brn','btn','bvt','bwa','caf','can','catalonia','cck','che','chl','chn','civ','cmr','cod','cog',
'cok','col','com','cpv','cri','csk','cub','cxr','cym','cyp','cze','deu','dji','dma','dnk','dom',
'dza','ecu','egy','england','eri','esh','esp','est','eth','europeanunion','fam','fin','fji','flk',
'fra','fro','fsm','gab','gbr','geo','gha','gib','gin','glp','gmb','gnb','gnq','grc','grd','grl',
'gtm','gu','guf','guy','hkg','hmd','hnd','hrv','hti','hun','idn','ind','iot','irl','irn','irq',
'isl','isr','ita','jam','jor','jpn','kaz','ken','kgz','khm','kir','kna','kor','kwt','lao','lbn',
'lbr','lby','lca','lie','lka','lso','ltu','lux','lva','mac','mar','mco','mda','mdg','mdv','mex',
'mhl','mkd','mli','mlt','mmr','mne','mng','mnp','moz','mrt','msr','mtq','mus','mwi','mys','myt',
'nam','ncl','ner','nfk','nga','nic','niu','nld','nor','npl','nru','nzl','omn','pak','pan','pcn',
'per','phl','plw','png','pol','pri','prk','prt','pry','pse','pyf','qat','reu','rou','rus','rwa',
'sau','scotland','sdn','sen','sgp','sgs','shn','sjm','slb','sle','slv','smr','som','spm','srb','stp',
'sur','svk','svn','swe','swz','syc','syr','tca','tcd','tgo','tha','tjk','tkl','tkm','tls','ton',
'tto','tun','tur','tuv','twn','tza','uga','ukr','umi','ury','usa','uzb','vat','vct','ven','vgb',
'vir','vnm','vut','wales','wlf','wsm','yem','zaf','zmb','zwe'];


  var cssString ='';

  var noFlagCount =0;
  var noFlagAvai = [];
   
  var cssLoopArr = famfamFlags;
  
  var i;
  for (i =0; i <cssLoopArr.length; i++){
    var loopEl = cssLoopArr[i];
    
    var isInEPIM ='';
    var preInEPIM = '';var postInEPIM = '';
    if (epimCountryISO3s.indexOf(loopEl.toUpperCase())>-1){
      //isInEPIM="/* is in EPIM */"; 
      var v4lint;
    }
    else{
      preInEPIM="/*";
      postInEPIM="*/";
    }
    
    cssString+=preInEPIM+'.xty_flag-'+loopEl.toUpperCase()+' { background-image: url(./img/flags/countryISO3/'+loopEl.toLowerCase()+'.gif)!important;background-repeat:no-repeat;} '+isInEPIM+postInEPIM+' \n';   
  }  
  
  extVia.dialoges.getInfoDialog({action:'Erstellen', width:600,mainInstruction:'cssString', info:cssString+","}).show(); 
    
},    
        
        
    getAdminEpobEditorPanelCfg : function(cfg, epob){
      
      //this.generateFlagCss();
    
       var editorMainTabItemId = 'adminEpobEditor'+ epob.epobId ;  
       var pgjobDscr = cfg.pgjobDscr?cfg.pgjobDscr:'adminEpobEditorPanel';
       var pgjobEpobDscr = cfg.pgjobEpobDscr;
       var editorPgjobButtons =[
        {   itemId:'showAllCountryLanguages',iconCls:'xty_pgtoolbar-languages',tooltip : 'zeige alle Lokalisierten Sprachen', 
          handler:function(button){
            var editorTab = button.ownerCt.ownerCt.ownerCt;
             editorTab.getComponent('metadata').collapse(); 
             var localizedLanguagesGrid = editorTab.getComponent('localizedLanguages');
             localizedLanguagesGrid.show();
             localizedLanguagesGrid.expand(); 
             localizedLanguagesGrid.setTitle("Lokalisierte Sprachen (" +localizedLanguagesGrid.getStore().count()+")");
 
          }
        }
       ]; 
       var editorPagetoolbarButtons =[
          {   itemId:'save',tooltip : 'Speichern'}         
          ]; 
          
            
       var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:pgjobDscr, epobDscr:pgjobEpobDscr,  pagetoolbarButtons: editorPagetoolbarButtons,pgjobButtons: editorPgjobButtons} );

       var reqSep = extVia.dialoges.getLabelSeparator4Required();
       
       var booleanColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
        return value?'x':'';
      };
      var baseSetStatusColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
        return '<div style="width:100%;height:18px;padding-left:16px;" title="'+value+'"  class="xty_icon_'+value+'"><span style="margin-top:-8px;"></span></div>';
      };
       
      var baseSetTwoFlagsColumnRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {   
           
        var languageOriginCountryISO3 = record.get('languageISO3').toUpperCase();
        //languageOriginCountryISO3 = extVia.stores.countryLang.statics.getMainCountryForLanguage(languageOriginCountryISO3);    
        
        
        var usedInCountryISO3 = record.get('countryISO3').toLowerCase();
        var languageDscr = record.get('languageDscrDE');
        var usedInCountryDscr = record.get('countryDscrDE');
           
          var flagTplCfg ={
            languageOriginCountryISO3:languageOriginCountryISO3, 
            languageDscr:languageDscr,
            usedInCountryISO3:usedInCountryISO3, 
            usedInCountryDscr:usedInCountryDscr 
          };

        var rendererReturnVal =  extVia.editor.baseEditor.statics.getFlagDisplayTemplate({grid:true}).applyTemplate( flagTplCfg );  
        return rendererReturnVal;
      };
       

     
        
      
      var countryLangDisplayTemplate = new Ext.Template([
        '<div style="width:100%;height:18px;padding-left:{paddLeft}px;" class="xty_icon_{countryISO2}" title="{countryDscrDE}"  >' +
          '<span  style="margin-top:-8px;"></span>' +
        '</div>' +
		'<div style="position:absolute;top:-4px;left:11px;width:100%;height:18px;{displayCountry}" class="" title="{languageDscrDE}"  >' +
          '<img style="margin-top:13px;" height="8" width="10" src="../img/flags/countryISO2{languageISO2}.png" />' +
        '</div>'     
      ]);      
     
      
      
              
      var flagDisplayTemplate = new Ext.Template([
        '<div style="width:100%;height:18px;padding-left:18px;" class="xty_icon_{countryISO2}" title="{flagDscrDE}"  >' +
          '<span  style="margin-top:-8px;"></span>' +
        '</div>'    
      ]);  
      
    
      
     var flagDisplayTemplateBOTH =  extVia.editor.baseEditor.statics.getFlagDisplayTemplate();
      
      
      // die GROSSE Flagge
      // languageOriginCountryISO3, eine oder zwei Flaggen
      
      // die  Kleine Flagge usedInCountryISO3 bei zwei Flaggen
      // usedInCountryISO3
      
      // use in renderer like this
      //flagTplCfg f�r Arabisch in Rum�nien ara_ROU:
      var flagTplCfg ={languageOriginCountryISO3:'SAU', languageDscr:'Arabisch',usedInCountryISO3:'ROU', usedInCountryDscr:'Rum�nisch' };
      var rendererReturnVal =  flagDisplayTemplateBOTH.applyTemplate( flagTplCfg );
      //alert ("Doppelflagge:\n"+rendererReturnVal);
      //alert ("Einzelflagge:\n"+flagDisplayTemplateBOTH.applyTemplate({languageOriginCountryISO3:'DEU', languageDscr:'Deutsch' }));
      
      
      
       var labelWidth = 180;
       
       var epobEditorPanelCfg = {
            title:pgjobEpobDscr, 
            applibarId:applibar.id,
            tbar : applibar,
            getApplicationBar:function(){
              return applibar;
            },
            setPagejobDscr : function setPagejobDscr(pgjobDscr){ applibar.setPagejobDscr(pgjobDscr);},
            setEpobDscr : function setEpobDscr(epobDscr){applibar.setEpobDscr(epobDscr);},
            getPagejobDscr : function getPagejobDscr(){applibar.getPagejobDscr(); },
            getEpobDscr : function getEpobDscr(){ return applibar.getEpobDscr(); },
            closable:true,
            active:true,
            itemId:editorMainTabItemId,
            stateId:editorMainTabItemId,
            
            defaults:{ 
             width:580, margin:'24 24 24 24' 
            },
           items:[
           
                 {title:'Metadaten', 
                  itemId:'metadata',
                  xtype:'form',
                   collapsible:true,
                  //height:280,
				    defaults : {
		              style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
		              anchdor : '100%',
		              labelWidth : labelWidth,
		              width : 540,
		              msgTarget:'side'
		            },
                
//                    updateShorcutAndResourceFields:function(metadataForm){
//
//                                 var languageNameCombo = metadataForm.getComponent('languageBin').getComponent('languageName');                                  
//                                 var languageNameRecord = languageNameCombo.findRecordByValue(languageNameCombo.getValue());
//
//                                  var resText_deuDEU = metadataForm.getComponent('resText_deuDEU');
//                                  var resText_engGBR = metadataForm.getComponent('resText_engGBR');
//                                  
//                                 
//                                  var countryDscr = '...';
//                                  var countryISO3 = '...';
//                                  var countryDscrDE = '...';
//                                  var languageDscr = '...';
//                                  var languageDscrDE = '...';
//                                  var languageISO2 = '...';
//                                  var languageISO3 = '...';
//                                  
//                                  if (languageNameRecord){
//                                    countryDscr = languageNameRecord.get("countryDscr");
//                                    countryISO3 = languageNameRecord.get("countryISO3");
//                                    countryDscrDE = languageNameRecord.get("countryDscrDE");
//                                    languageDscr = languageNameRecord.get("languageDscr");
//                                    languageDscrDE = languageNameRecord.get("languageDscrDE");
//                                    languageISO2 = languageNameRecord.get("languageISO2");
//                                    languageISO3 = languageNameRecord.get("languageISO3");                                 
//                                  }
//                                  
//
//                                     var countryNameCombo = metadataForm.getComponent('countryBin').getComponent('countryName');
//                                     var  countryNameRecord = countryNameCombo.findRecordByValue(countryNameCombo.getValue());
//                                     var countryNameVal = '...';
//                                     var countryNameValDE = '...';
//                                     if (countryNameRecord){
//                                      countryNameVal = countryNameRecord.get("countryDscr");
//                                      countryNameValDE = countryNameRecord.get("countryDscrDE");
//                                      countryISO3 = countryNameRecord.get("countryISO3");
//
//                                     }
//                                     
//                                     resText_deuDEU.setValue(languageDscrDE+" in "+countryNameValDE);
//                                     metadataForm.ownerCt.setEpobDscr(languageDscrDE+" in "+countryNameValDE);
//                                     resText_engGBR.setValue(languageDscr+" in "+countryNameVal);              
//                    },
                
                
				  	items : [ 
        		 		
        		        {xtype:'tbspacer', height:16},

                    
                        { xtype:'displayfield', fieldLabel:'LocalXe', tooltip:'Land-Spr-Id' , value:'...X...' , itemId:'countryLangIdDisplay',name:'countryLangIdDisplay', hidden :true},   

                        
                       // { xtype:'tbspacer', height:8},
                       // { xtype:'displayfield', value:'<b>lokalisierte Sprache</b>' }, 
                        {xtype: 'fieldcontainer', width:580, itemId:'languageBin',name:'languageBin',layout:'hbox',fieldLabel: '&nbsp;Sprache', labelSeparator :reqSep, allowBlank:false,
                             defaults:{ 
                                listeners:{
  
                                  specialkey:function( combo, evt ){
                                   if (evt.getKey() === evt.ENTER && evt.hasModifier( )) {
                                      var countryCombo = combo.ownerCt.ownerCt.getComponent('countryBin').getComponent('countryName');
                                      var  languageNameRecord = combo.findRecordByValue(combo.getValue());
                                      countryCombo.setValue(languageNameRecord.get('countryLangId'));
                                   }
                                    
                                  },

                                  
                                 change:function( combo, newValue, oldValue, eOpts ){
                                  
                                   Ext.global.console.info('change language');
                                   if(this.doNotChange){
                                    this.doNotChange = false;
                                   }else if (newValue && newValue.length>1){
                                     var countryLangInStore = false;
                                     countryLangInStore = extVia.stores.countryLang.statics.getCountryLangForLanguageISO3(newValue); 
                                     if(countryLangInStore===null){
                                       countryLangInStore = extVia.stores.countryLang.statics.getCountryLangForLanguageISO2(newValue); 
                                     }                                        
                                     if(countryLangInStore!==null){
                                       combo.setValue(countryLangInStore.languageDscrDE);                         
                                     }
                                     
                                     var countryBin = combo.ownerCt.ownerCt.getComponent('countryBin');
                                     var countryCombo = countryBin.getComponent('countryName');
                                     countryCombo.store.clearFilter();
                                     var index = countryCombo.store.findExact('countryLangId', newValue);
                                     if(index >= 0){
                                       var countryFilter = countryBin.getComponent('countryFilter');
                                       if(!countryFilter.pressed){
                                         countryFilter.toggle();
                                       }
                                       countryFilter.handler(countryFilter);
                                       index = countryCombo.store.findExact('countryLangId', newValue);
                                       countryCombo.select(countryCombo.store.getAt(index));
                                     }
                                     
//                                     var customLanguageIconBn = combo.ownerCt.ownerCt.getComponent('customLanguageBin').getComponent('customLanguageIconBn');
//                                     customLanguageIconBn.enableCustomLanguages(true);
                                     
                                   } 
                                 
                                 var  languageNameRecord = combo.findRecordByValue(newValue);
                                 var metadataForm = combo.ownerCt.ownerCt;
                                 
                                 var countryLangIdDisplay = metadataForm.getComponent('countryLangIdDisplay');
                                 var countryLangDisplayBin = metadataForm.getComponent('countryLangDisplayBin');


                                  var languageName = combo.ownerCt.getComponent('languageName'); 
                                  
                                  var resText_deuDEU = metadataForm.getComponent('customLanguageBin').getComponent('resText_deuDEU');
                                  var resText_engGBR = metadataForm.getComponent('resText_engGBR');
                                  
                                  
                                  var languagOriginFlagIcon = combo.ownerCt.getComponent('languagOriginFlagIcon');  
                                  languagOriginFlagIcon.setIconCls("xty_icon_"+languageNameRecord.get("countryISO2"));
                                  languagOriginFlagIcon.setTooltip("Sprache Herkunftsland "+languageNameRecord.get("countryDscrDE"));
                                  
                                  languagOriginFlagIcon.countryLangId=languageNameRecord.get("countryLangId");
                                  countryLangDisplayBin.setLanguage(languageNameRecord.get("languageISO2"), languageNameRecord.get("languageISO3"),languageNameRecord);  
                                 
                                  var countryDscr = languageNameRecord.get("countryDscr");
                                  var countryDscrDE = languageNameRecord.get("countryDscrDE");
                                  var languageDscr = languageNameRecord.get("languageDscr");
                                  var languageDscrDE = languageNameRecord.get("languageDscrDE");
                                  var languageISO2 = languageNameRecord.get("languageISO2");
                                  var languageISO3 = languageNameRecord.get("languageISO3");
                                  var isDialect = languageNameRecord.get('isDialect');
                                  if (isDialect){ languageISO3 = languageNameRecord.get("languageISO3");}
                                 var countryNameCombo = metadataForm.getComponent('countryBin').getComponent('countryName');
                                
                                 var  countryNameRecord = countryNameCombo.findRecordByValue(countryNameCombo.getValue());
                                 var countryNameVal = '...';
                                 var countryNameValDE = '...';
                                 if (countryNameRecord){
                                  countryNameVal = countryNameRecord.get("countryDscr");
                                  countryNameValDE = countryNameRecord.get("countryDscrDE");
                                 }
                                 resText_deuDEU.setValue(languageDscrDE+" in "+countryNameValDE);
                                 metadataForm.ownerCt.setEpobDscr(languageDscrDE+" in "+countryNameValDE);
                                 resText_engGBR.setValue(languageDscr+" in "+countryNameVal);                                     
                                  
                                  var acrossLanguage = combo.ownerCt.ownerCt.getComponent('acrossBin').getComponent('acrossLanguage'); 
                                  acrossLanguage.setValue(languageDscrDE);
                                 
                                 } 
                                }
                              },
                            
                            items:[ 
                            
                            { xtype:'button', itemId:'languagOriginFlagIcon',  
                              margin:'0 4 0 0', border:false,width:22, height:22, 
                                name:'flagIcon', iconCls:'xty_icon_xx', tooltip:'Sprache Herkunftsland', value:'&nbsp;&nbsp;&nbsp;&nbsp;',
                                handler:function(button){
                                  var countryCombo = button.ownerCt.ownerCt.getComponent('countryBin').getComponent('countryName');
                                  countryCombo.setValue(button.countryLangId);
                                }                                
                                },
                            
				 	          {xtype:'combo', itemId:'languageName', name:'languageName', 
						         //hideTrigger:true,
						         allowBlank:false, labelSeparator : reqSep,
	                			 store: extVia.stores.initMainLanguagesStore({}),
	                			 queryMode: 'local',
	                			 displayField: 'languageDscrDE',
	             	  			 emptyText: 'Pick language',
	             	  			 valueField: 'countryLangId',
								 listConfig:{
                                    minWidth:280,
								 	getInnerTpl : function() {
	                                var tpl = '<div style="white-space:nowrap;width:100%;height:18px;padding-left:16px;" class="xty_icon_{[extVia.stores.countryLang.statics.getMainCountryForLanguage(values.languageISO3).countryISO2]}">' +
                                      '<span style="margin-top:-8px;">' + '&nbsp; {languageDscrDE}' + '</span>' +
                                      '<span style="font-weight:bold;color:#888;">' + '&nbsp; {languageDscrLANG}' + ' </span>' +
                                      ' <span style="color:#888;">&nbsp;({languageISO2}&nbsp;{languageISO3})</span></div>';
	                                return tpl;
		                       		}
								 }
//                                 listeners:{
//                                   expand: function(combo){
//                                     if(combo){
//                                       window.setTimeout(function(){
//                                         var languageFilter = combo.ownerCt.getComponent('languageFilter');
//                                         if(languageFilter.pressed){
//                                           languageFilter.handler(languageFilter);
//                                         }
//                                       }, 0);
//                                     }
//                                   }
//                                 }
							   },
                 
                                 {xtype:'button', itemId:'languageFilter',name:'languageFilter', iconCls:'x-tool-filter',  enableToggle:true, tooltip:'filtere Sprachen nach Land',
                                   handler:function(button){
                                     var metadataForm = button.ownerCt.ownerCt;
                                     var countryNameCombo = metadataForm.getComponent('countryBin').getComponent('countryName'); 
                                     var languageNameCombo = metadataForm.getComponent('languageBin').getComponent('languageName'); 
                                  
                                     var currentCountryName = countryNameCombo.getValue(); 
                                     var currentLanguageISO3 ='';
                                     var currentLanguageISOs =[];
                                    
                                     if (currentCountryName){
                                       currentLanguageISO3 = currentCountryName.replace(/..._/,'');

                                       var currentCountryISO3 = currentCountryName.replace(/_.../,'');
                                     
                                       currentLanguageISOs =  extVia.stores.countryLang.statics.getLanguageISOsForCountryISO3(currentCountryISO3);
                                     }
                                  
                                     var store = languageNameCombo.getStore();
                                     store.clearFilter();
                                     if (button.pressed){
                                       store.filterBy(function(filterRecord, id){
                                         var rowHasCountry = currentLanguageISOs.indexOf(filterRecord.get('languageISO3'))>-1;
                                         if (rowHasCountry){
                                           return true;
                                         }
                                         else{return false;}
                                       });
                                     }
                                  }
                                 }                         
								 ]
                              },

                              
                        {xtype: 'fieldcontainer', width:580, itemId:'countryBin',layout:'hbox',fieldLabel: '&nbsp;Land',
                        
                            setItemsDisabled:function(disabled){
                              var i;
                              for ( i =1; i< this.items.length; i++){this.items.get(i).setDisabled(disabled);} 
                            },

                            items:[ 
                            
                            
                            {xtype:'radio', itemId:'countryForLang',  margin:'1 2 0 0', name:'localizedBy', checsked:'true',boxLabel:'&nbsp;Land',width:180,disabled:false, hidden:true,
                            
                             handler:function(radio){
                             radio.ownerCt.setItemsDisabled(!radio.checked); }
                            }, 
                            
                            
                           { xtype:'button', itemId:'countryFlagIcon',  
                              margin:'0 4 0 0', border:false,width:22, height:22, 
                                name:'countryFlagIcon', iconCls:'xty_icon_xx', tooltip:'', value:'&nbsp;&nbsp;&nbsp;&nbsp;',
                                handler:function(button){
                                  var languageCombo = button.ownerCt.ownerCt.getComponent('languageBin').getComponent('languageName');
                                  languageCombo.doNotChange = true;
                                  languageCombo.setValue(button.countryLangId);
                                }
                                
                                },
                            
                            
				 	        {xtype:'combo', itemId:'countryName', name:'countryName', 

	                			 store: extVia.stores.initCountryLangCountriesStore({}),
	                			 queryMode: 'local',
	                			 displayField: 'countryDscrDE',

	             	  			 emptyText: 'Pick country',
	             	  			 valueField: 'countryLangId',

								 listeners:{
								   change:function( combo, newValue, oldValue, eOpts ){
                    
                                      Ext.global.console.info('change country');
                                      if (newValue && newValue.length>1){                                     
                                        var countryLangInStore = false;
                                        countryLangInStore = extVia.stores.countryLang.statics.getCountryLangForCountryISO3(newValue.toUpperCase()); 
                                        if(countryLangInStore===null){
                                         countryLangInStore = extVia.stores.countryLang.statics.getCountryLangForCountryISO2(newValue.toUpperCase()); 
                                        }                                        
                                        if(countryLangInStore!==null){
                                         combo.setValue(countryLangInStore.countryDscrDE);
                                        }
                                        
                                      } 
                    

                                      var metadataForm = combo.ownerCt.ownerCt;
                                     // metadataForm.updateShorcutAndResourceFields(metadataForm);
                                      var languageFilter = metadataForm.getComponent('languageBin').getComponent('languageFilter');
                                      if(languageFilter.pressed){
                                        languageFilter.handler(languageFilter);
                                      }

                                      var  countryNameRecord = combo.findRecordByValue(newValue);
                                      var flagIcon = combo.ownerCt.getComponent('countryFlagIcon');
                                      flagIcon.setIconCls("xty_icon_"+countryNameRecord.get("countryISO2"));
                                      flagIcon.setTooltip("Flagge "+countryNameRecord.get("countryDscrDE"));
                                       
                                      var languageISO3 = countryNameRecord.get("languageISO3");
                                      flagIcon.countryLangId = extVia.stores.countryLang.statics.getMainCountryForLanguage(languageISO3).countryLangId;
                                       
                                      var countryLangDisplayBin = metadataForm.getComponent('countryLangDisplayBin');
                                      countryLangDisplayBin.setCountry(countryNameRecord.get("countryISO2"), countryNameRecord.get("countryISO3"),countryNameRecord);
                                       
                                       
		            		       },
                                   expand: function(combo){
                                     if(combo){
                                       window.setTimeout(function(){
                                         var countryFilter = combo.ownerCt.getComponent('countryFilter');
                                         if(countryFilter.pressed){
                                           countryFilter.handler(countryFilter);
                                         }
                                       }, 0);
                                     }
                                   }
		            		     },
								 
								 listConfig:{
                                    minWidth:220,
								 	getInnerTpl : function() {
	                                var tpl = '<div style="white-space:nowrap;width:100%;height:18px;padding-left:16px;" class="xty_icon_{countryISO2}"><span style="margin-top:-8px;">' + '&nbsp; {countryDscrDE}' + '</span><span style="color:#888">&nbsp;({countryISO2}&nbsp;{countryISO3})</span></div>';
	                                return tpl;
		                       		}
								 }
								},

                                {xtype:'button', itemId:'countryFilter',name:'countryFilter', iconCls:'x-tool-filter',  enableToggle:true, tooltip:'filtere L&auml;nder nach Sprache',
                                  handler:function(button){
                                    var metadataForm = button.ownerCt.ownerCt;
                                    var combo = metadataForm.getComponent('countryBin').getComponent('countryName'); 
                                    var currentLanguageISO3 ='';
                                    var languageNameCombo = metadataForm.getComponent('languageBin').getComponent('languageName'); 
                                    var currentLanguageName = languageNameCombo.getValue(); 
                                    if (currentLanguageName){
                                      currentLanguageISO3 = currentLanguageName.replace(/..._/,'');
                                    }
                                
                                    var store = combo.getStore();
                                    store.clearFilter();
                                    if (button.pressed){
                                      store.filterBy(function(filterRecord, id){
                                        var rowHasLang = filterRecord.get('languageISO3')===currentLanguageISO3; 
                                        if ( rowHasLang){
                                          return true;
                                        }
                                        else{return false;}
                                      });
                                    }
                                  }
                               },

                             {xtype:'displayfield', itemId:'flagIcon',  margin:'3 2 0 4', name:'flagIcon', cls:'xty_icon_xx', value:'&nbsp;&nbsp;&nbsp;&nbsp;'}

                          
                         ]},
						
                         
                         
                       
                        {xtype: 'fieldcontainer', width:580, itemId:'countryLangDisplayBin',layout:'hbox', fieldLabel: '&nbsp;Flag' ,
                         setLanguage:function(languageISO2, languageISO3, languageRecord){
                          var languageFlag = this.getComponent('languageFlag');
                          languageFlag.setIconCls('xty_icon_'+ languageRecord.get('countryISO2'));
                          var langCountryLocaleDisplay = this.ownerCt.getComponent('langCountryLocaleDisplay');
                          langCountryLocaleDisplay.setValue(langCountryLocaleDisplay.getValue().replace(/.../,languageISO3)); 

                          var languageFlagDisplay = this.getComponent('languageFlagDisplay');
                          languageFlagDisplay.setValue( flagDisplayTemplate.applyTemplate( {countryISO2:languageRecord.get('countryISO2'), flagDscrDE:languageRecord.get('languageDscrDE')} ));

                          this.currentLanguageRecord = languageRecord;
                          this.setCombinedFlag();

                         },
                         setCountry:function(countryISO2, countryISO3, countryRecord){
                          var countryFlag = this.getComponent('countryFlag');
                          countryFlag.setIconCls('xty_icon_'+countryISO2);
                          var langCountryLocaleDisplay = this.ownerCt.getComponent('langCountryLocaleDisplay');
                          langCountryLocaleDisplay.setValue(langCountryLocaleDisplay.getValue().replace(/(.[^_]*_)(...)/,"$1"+countryISO3));
                          
//                          var countryFlagDisplay = this.getComponent('countryFlagDisplay');
//                          countryFlagDisplay.setValue( flagDisplayTemplate.applyTemplate( {countryISO2:countryISO2, flagDscrDE:countryRecord.get('countryDscrDE')} ));
                          
                          //alert("is isMainCountry4Lang "+ countryRecord.get('isMainCountry4Lang') )                        
                          
                          this.currentCountryRecord = countryRecord;
                          this.setCombinedFlag();
                          
                         },
                        
                         setCombinedFlag:function(){
                          var languageRecord =  this.currentLanguageRecord ;
                          var countryRecord  = this.currentCountryRecord ; 
                          var languageISO2="xx";
                          var languageISO3;
                          var countryISO3;
                          var languageDscrDE = "keine Auswahl";
                          var countryISO2="XX";
                          var countryDscrDE = "keine Auswahl";

                          if (languageRecord){
                            languageISO2=languageRecord.get('countryISO2');
                            languageISO3=languageRecord.get('countryISO3');
                            languageDscrDE=languageRecord.get('languageDscrDE');
                          
                          }
                          if (countryRecord){
                            countryISO2=countryRecord.get('countryISO2');
                            countryISO3=countryRecord.get('countryISO3');
                            countryDscrDE=countryRecord.get('countryDscrDE');
                          }
                          
                          
                          var paddLeft = 16;
                          
                          

                          // LanguageFirst
                          var langCountryRow =  {
                            paddLeft : paddLeft,
                            displayCountry:'',  
                            languageISO2:countryISO2.toLowerCase(),
                            languageDscrDE:countryDscrDE,
                            countryISO2:languageISO2,
                            countryDscrDE:languageDscrDE
                          };
//                          
//                          var flagTplCfg ={
//				            languageOriginCountryISO3:countryISO3.toLowerCase(), 
//				            languageDscr:countryDscrDE,
//				            usedInCountryISO3:languageISO3.toUpperCase(), 
//				            usedInCountryDscr:languageDscrDE 
//				          };
                          
                          var flagTplCfg ={
		                    languageOriginCountryISO3:'DEU',
		                    languageDscr:'deutsch',
		                    usedInCountryISO3:'USA',
		                    usedInCountryDscr:'amerikka'
		                  };
		                  
				                          
                          
                          var countryLangFlagDisplay =  this.getComponent('langCountryFlagDisplay');
                          //countryLangFlagDisplay.setValue( countryLangDisplayTemplate.applyTemplate( langCountryRow ));
                          
                          
                          countryLangFlagDisplay.setValue( extVia.editor.baseEditor.statics.getFlagDisplayTemplate().applyTemplate( flagTplCfg ));
                          
                          
                          // CountryFirst
//                          var countryLangRow =  {
//                            paddLeft : paddLeft,
//                            displayCountry:'',  
//                            languageISO2:languageISO2.toLowerCase(),
//                            languageDscrDE:languageDscrDE,
//                            countryISO2:countryISO2,
//                            countryDscrDE:countryDscrDE
//                          };
//                          var countryLangFlagDisplay =  this.getComponent('countryLangFlagDisplay');
//                          countryLangFlagDisplay.setValue( countryLangDisplayTemplate.applyTemplate( countryLangRow ));
 
                         },
                         
                         
                         items : [
                         { xtype:'radio',  tooltip:'use langCountryFlag ', name:'flagSelector',margin:'0 2 0 0',   itemId:'langCountryFlagRadio' },  
                         { xtype:'displayfield',  tooltip:'langCountryFlagDisplay' , value: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' , itemId:'langCountryFlagDisplay' },  
                         
//                         { xtype:'radio',  tooltip:'use countryLangFlag ', name:'flagSelector', margin:'0 2 0 8', itemId:'countryLangFlagRadio' },  
//                         { xtype:'displayfield',  tooltip:'countryLangFlagDisplay' , value: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' , itemId:'countryLangFlagDisplay'},  
                         
                         { xtype:'radio',  tooltip:'use LangFlag ', checked:true, name:'flagSelector', margin:'0 2 0 8', itemId:'langFlagRadio' }, 
                         { xtype:'displayfield',  tooltip:'languageFlagDisplay' , value: flagDisplayTemplate.applyTemplate( {countryISO2:'xx'} ) , itemId:'languageFlagDisplay'},  
                         
                         
                         { xtype:'button', hidden:true, itemId:'languageFlag',   margin:'0 2 0 2', border:false,width:22, height:22, name:'languageflagIcon', iconCls:'xty_icon_xx', tooltip:'Sprachflagge', value:'&nbsp;&nbsp;&nbsp;&nbsp;'},
                        
//                         { xtype:'radio',  tooltip:'use countryFlag ', name:'flagSelector', margin:'0 2 0 8', itemId:'countryFlagRadio' }, 
//                         { xtype:'displayfield',  tooltip:'countryFlagDisplay' , value:  flagDisplayTemplate.applyTemplate( {countryISO2:'xx'} )  , itemId:'countryFlagDisplay'},
                         { xtype:'button', hidden:true,itemId:'countryFlag',   margin:'0 2 0 2', border:false,width:22, height:22, name:'countryflagIcon', iconCls:'xty_icon_xx', tooltip:'Landesflagge', value:'&nbsp;&nbsp;&nbsp;&nbsp;'}
                        
                         
                         ]
                        },
                         
                       
                        { xtype:'displayfield', fieldLabel:'&nbsp;Id / Locale', tooltip:'Land-Spr-Id' , value:'..._...' , itemId:'langCountryLocaleDisplay'}, 
                        
                         
                       {xtype: 'fieldcontainer', width:580, itemId:'dialectBin',layout:'hbox',disabled:true, hidden:true,

                         setItemsDisabled:function(disabled){var i; for (i =1; i< this.items.length; i++){this.items.get(i).setDisabled(disabled);}}, 
                         items:[
                            {xtype:'checkbox', itemId:'region', boxLabel:'&nbsp;Dialekt',  name:'localizedBy',width:180,  margin:'1 2 0 0',              
		                        handler:function(radio){
		                             radio.ownerCt.setItemsDisabled(!radio.checked); 
		                        }
                            },
                            {xtype:'textfield', itemId:'dialectName',  name:'dialectName', disabled:true},
                            {xtype:'displayfield', itemId:'dialectISO3Dscr', name:'dialectISO3Dscr', value:'iso3&nbsp;', margin:'0 0 0 29',disabled:true},
                            {xtype:'textfield', itemId:'dialectISO3',  name:'dialectISO3', disabled:true, width:40}

                         ]},
                         
                         
						{xtype:'tbspacer', height:16},
            
                        {xtype:'displayfield', value:'<b>Backward Compatible</b>'},
                        {xtype:'textfield',fieldLabel: '&nbsp;ISO2-Fantasy', maxLength: 3, itemId:'backCompatible', name:'backCompatible', width: 216},
                        
                        {xtype:'tbspacer', height:16},
                        
                        {xtype:'displayfield', value:'<b>Ressource-Texte</b>'},
                        
                        {
                          xtype: 'fieldcontainer',
                          width:570, 
                          padding: '0 0 0 0',
                          itemId:'customLanguageBin',
                          layout:'hbox',
                          items: [
                            { xtype:'textfield',
                              fieldLabel: '&nbsp;Ressource-Text (deu, DEU)', 
                              labelWidth: labelWidth,
                              itemId:'resText_deuDEU',
                              name:'resText_deuDEU',  
                              labelSeparator :reqSep, 
                              allowBlank:false,
                              width: 520  
                            },
                            { 
                              xtype: 'label',
                              itemId: 'customLanguageIconBn',
                              checked: false,
                              cls: 'xty_pgtoolbar-customLanguagesDisable',
                              padding: '0 0 0 0',
                              margin: '0 0 4 2',
                              width: 16, 
                              height: 16,
                              
                              cleanCls: function(){
                                this.el.removeCls('xty_pgtoolbar-customLanguagesEnable');
                                this.el.removeCls('xty_pgtoolbar-customLanguagesEnableOver');
                                this.el.removeCls('xty_pgtoolbar-customLanguagesDisable');
                                this.el.removeCls('xty_pgtoolbar-customLanguagesDisableOver');
                              },
                              
                              toggleOver: function(over){
                                this.cleanCls();
                                if(over && this.checked){
                                  this.el.addCls('xty_pgtoolbar-customLanguagesEnableOver');
                                }else if(over && !this.checked){
                                  this.el.addCls('xty_pgtoolbar-customLanguagesDisableOver');
                                }else if(!over && this.checked){
                                  this.el.addCls('xty_pgtoolbar-customLanguagesEnable');
                                }else if(!over && !this.checked){
                                  this.el.addCls('xty_pgtoolbar-customLanguagesDisable');
                                }
                              },

                              toggle: function(){
                                this.cleanCls();
                                this.checked = !this.checked;
                                if(this.checked){
                                  this.el.addCls('xty_pgtoolbar-customLanguagesEnableOver');
                                }else{
                                  this.el.addCls('xty_pgtoolbar-customLanguagesDisableOver');
                                }
                              },  
                              
                              enableCustomLanguages: function(enable){
                                this.checked = enable;
                                this.toggleOver(false);
                                if(!this.checked){
//                                  this.ownerCt.ownerCt.getComponent('resText_deuDEU').hide();
                                  this.ownerCt.ownerCt.getComponent('resText_engGBR').hide();
                                  this.ownerCt.ownerCt.getComponent('resText_fraFRA').hide();
                                }else{
//                                  this.ownerCt.ownerCt.getComponent('resText_deuDEU').show();
                                  this.ownerCt.ownerCt.getComponent('resText_engGBR').show();
                                  this.ownerCt.ownerCt.getComponent('resText_fraFRA').show();
                                }
                              },
                              
                              listeners: {
                                afterrender: function(event, dom){
                                  this.el.on('click', function(event, dom){
                                    var label = Ext.getCmp(this.id);
                                    label.toggle();
                                    label.enableCustomLanguages(label.checked);
                                  });
                                  
                                  this.el.on('mouseover', function(event, dom){
                                    var label = Ext.getCmp(this.id);
                                    this.setStyle('cursor', 'pointer');
                                    label.toggleOver(true);
                                  });
                                  
                                  this.el.on('mouseout', function(event, dom){
                                    var label = Ext.getCmp(this.id);
                                    this.setStyle('cursor', 'default');
                                    label.toggleOver(false);
                                  });
                                }
                              }
                            }
                          ]
                       },       
                       
                       { xtype:'textfield',fieldLabel: '&nbsp;Ressource-Text (eng, GBR)', hidden:true,  itemId:'resText_engGBR', name:'resText_engGBR', labelSeparator :reqSep, allowBlank:false, width: 520},
                       { xtype:'textfield',fieldLabel: '&nbsp;Ressource-Text (fra, FRA)', hidden:true,  itemId:'resText_fraFRA', name:'resText_fraFRA', labelSeparator :reqSep, allowBlank:false, width: 520},
                       
                       {xtype:'tbspacer', height:8},
  
                       { xtype:'displayfield', value:'<b>Verwendung</b>' , itemId:'usingTopic'},     
                       { xtype:'numberfield',fieldLabel: '&nbsp;Reihenfolge',  itemId:'orderNr', name:'orderNr', width:230},
                       { xtype:'checkbox',fieldLabel: '&nbsp;Inhaltssprache', boxLabel: 'Sprache als Inhaltssprache verwenden', itemId:'contentLanguage', name:'contentLanguage',
                        handler: function(checkbox){ 
                          checkbox.ownerCt.getComponent('defaultReleaseView').setVisible(checkbox.checked);
                          checkbox.ownerCt.getComponent('defaultReleaseView').setDisabled(!checkbox.checked);
                          checkbox.ownerCt.getComponent('defaultReleaseEdit').setVisible(checkbox.checked);
                          checkbox.ownerCt.getComponent('defaultReleaseEdit').setDisabled(!checkbox.checked);
                          checkbox.ownerCt.getComponent('defaultReleaseExport').setVisible(checkbox.checked);
                          checkbox.ownerCt.getComponent('defaultReleaseExport').setDisabled(!checkbox.checked);
                          checkbox.ownerCt.getComponent('contentLangHint').setVisible(checkbox.checked);
                        }
                       },
                       { xtype:'displayfield', fieldLabsel:'&nbsp;' , hideEmptyLabel:false, masrgin:'-16 0 0 0',value:'<span style="margsin-top:-8px;color:#888;font-size:10px;">Die Verarbeitung kann laenger dauern...</span>' , itemId:'contentLangHint', hidden: true },                    
                       { xtype:'checkbox',boxLabel: 'Standardsprachfreigabe (Pflege) ',  hidden:true, disabled:true, hideEmptyLabel:false,  itemId:'defaultReleaseEdit', name:'defaultReleaseEdit'},
                       { xtype:'checkbox',boxLabel: 'Standardsprachfreigabe (Ansicht) ', hidden:true, disabled:true, hideEmptyLabel:false, itemId:'defaultReleaseView',name:'defaultReleaseView'},
                       { xtype:'checkbox',boxLabel: 'Standardsprachfreigabe (Export) ',  hidden:true, disabled:true, hideEmptyLabel:false, itemId:'defaultReleaseExport', name:'defaultReleaseExport'},
                       
                       {xtype:'tbspacer', height:8},
                       
                       {xtype:'displayfield', value:'<b>Externe Systeme</b>' , itemId:'externalsystems'},    
                       {xtype:'fieldcontainer', fieldLabel:'&nbsp;Across Mapping' , itemId:'acrossBin', layout:'hbox',
                        items: [{xtype:'combo', emptyText:'Sprache', widtsh:70, itemId:'acrossLanguage', margin:'0 4 0 0',disadbled:true},  {xtype:'combo', emptyText:'Land' , itemId:'acrossCountry'}]
                       },    
                       {xtype:'tbspacer', height:8}
            
            
				 	]
				  },
          
          
                     
                  { title:'Lokalisierte Sprachen', hidden:true,
                    xtype:'grid',
                    collapsible:true,
                    collapsed:true,
                    height:600,
                    width:920,
                    store:  extVia.stores.initCountryLanguageStore(),
                    itemId:'localizedLanguages',
	                columns:[
                       {header:'Sprach<br>Flagge', dataIndex:'languageISO2', renderer:baseSetTwoFlagsColumnRenderer, width:64},
                       {header:'Landes<br>Flagge', dataIndex:'countryISO2', renderer:baseSetStatusColumnRenderer, width:32, hidden :true},
	                   {header:'Sprache', dataIndex:'languageDscrDE',width:260, flex:1},
                       //{header:'in Landesprache', dataIndex:'languageDscrLANG'},
                       {header:'spr-ISO2', dataIndex:'languageISO2',width:52},
                       {header:'spr-ISO3', dataIndex:'languageISO3',width:52},
	                   {header:'Land', dataIndex:'countryDscrDE'},
                       {header:'land-ISO2', dataIndex:'countryISO2',width:52},
                       {header:'land-ISO3', dataIndex:'countryISO3',width:52},
	                   {header:'Herkunftsprache', dataIndex:'isMainCountry4Lang', width:32,renderer:booleanColumnRenderer},
	                   {header:'Global', dataIndex:'isGlobal', width:32, renderer:booleanColumnRenderer},
	                   {header:'Dialekt', dataIndex:'isDialect', width:32, renderer:booleanColumnRenderer},
                       {header:'LandSpr-Id', dataIndex:'countryLangId'},
                       {header:'SprLand-Id', dataIndex:'langCountryId'},
                       {header:'oldID', dataIndex:'countryLangId',
                         renderer:function( value, metaData, record, rowIndex, colIndex, store, view ){
                              return record.get('languageISO2') + '_'+ record.get('countryISO2');
                         }
                       }
	                ]
                  }
          
          
            ]
            
      };

      return  epobEditorPanelCfg;
       
    },
        
    addTabChooser : function(tabId){ // extVia.editor.baseEditor.statics.addTabChooser('')
      var tabchooserHTML = '<span id="'+tabId+'-tab-chooser"  class="xty_tab-chooser" >&nbsp;&#9013;&nbsp;</span>';
     
     //var tabchooserHTML =  '&nbsp;&#9013;&nbsp;';
     
     return tabchooserHTML;
    },
    

    
    getEditorPanelCfg : function(cfg, epob){

      var loc = extVia.locales;
      
      var editorMainTabItemId = 'epobEditorPanel'+ (epob.epobId?epob.epobId:epob.dscr) ;  
      
      var pgjobDscr = loc.editProduct;
      var pgjobEpobDscr = epob.dscr;
 
      
      

      
      
      var pagetoolbarButtons = [
        { itemId:'save', tooltip: loc.save},       
        { itemId: 'clear', tooltip:loc.reset},
        '|',
       //{xtype:'tbspacer' , width: 10},  
       {itemId:'export', tooltip:'Export'},        
       //{ xtype:'splitbutton', itemId : 'saw', tooltip:'Vererbung unterbrechen', }
       { itemId:'addToCollection', tooltip: loc.addToCollection, iconCls : 'xty_pgtoolbar-collectionAddTo'},
       { itemId:'versioning-create',  tooltip: loc.createVersion},

      ];
      
      
      
      
      
      
      var dqiBtn;
      var dqiSubTabPanelCfg = { title: loc.dataQuality, itemId:'dqi'};
      if (extVia.dqi && extVia.dqi.statics){
        dqiSubTabPanelCfg  = extVia.dqi.statics.getSubTabPanelCfg({}, epob); 
        if (dqiSubTabPanelCfg.pagetoolbarBtns){
          Ext.Array.insert(pagetoolbarButtons, pagetoolbarButtons.length, dqiSubTabPanelCfg.pagetoolbarBtns);
        } 
      }
      
      
      
      
      
      
      var pgjobButtons = [];

      if (extVia.collaboration){
        var btnGrp = extVia.collaboration.statics.getCollaborationsBtnGrpCfg(cfg, epob); 
        pgjobButtons.push(btnGrp);
      }
      
      
      var langIsoCls =  'xty_icon_'+  extVia.locales.uiLangIso.toUpperCase(); 
      var contentSwitcherCfg ={
         xtype: 'buttongroup', itemId:'contentSwitcherBtnGrp', margin:'0 2 0 0',
         items: [{  itemId:'language', iconCls : langIsoCls , iso2:extVia.locales.uiLangIso, cls:'xty_language-chooser',    height:22, width:22, scale: 'small',  
           handler:function(btn){
             var iso2 = btn.iso2;
             if (iso2==='en' ){
               iso2='de';
             }
             else{
               iso2='en';
             }
             extVia.ui.page.raster.reloadPage('uiLangIso='+iso2); 
           },
           tooltip: extVia.locales.uiLanguage
          }] 
         
      };
      
      
      pgjobButtons.push(contentSwitcherCfg);



     var subEpobDscr = epob.subEpobDscr;
            
      var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: pgjobDscr, epobDscr:pgjobEpobDscr,  subEpobDscr: subEpobDscr, pagetoolbarButtons: pagetoolbarButtons, pgjobButtons: pgjobButtons,  breadcrumb: epob.breadcrumb, breadcrumbSeparator: epob.breadcrumbSeparator} );

      
      var reqSep = extVia.editor.baseEditor.statics.getLabelSeparator4Required();

      

      
      var editorPanelCfg = {
        title:pgjobEpobDscr, 
        applibarId:applibar.id,
        tbar : applibar,
        getApplicationBar:function(){ return applibar;},
        closable:true,
        active:true,
        itemId:editorMainTabItemId,
        stateId:editorMainTabItemId,
        
        items:[
          { 
            xtype:'tabpanel',
            border:false, 
            margin : '0 0 0 0', 
            cls:'xty_editor-subtabpanel', 
            tabBar:{cls:'xty_subtabpanel-tabbar xty_tabbar-noborder-rl'},

            activeTab:  cfg.activeTab,
            stateful:true,

            itemId:'editorSubTabsPanel',
            stateId:'editorSubTabsPanel',
            doTabBadges:true,   
            defaults:{border:false,  margin:'24 24 24 24'},
            items:[
              {
                title: loc.metadata ,
                stateful:true,
                stateId:editorMainTabItemId+'-metadataTab',
                itemId:'metadata',
                defaults:{width:580, margin:'24 24 24 24'},
                items:[
                  {title:loc.general, hxeight:200, xtype:'form', 
                    
                    
                  bodyStyle:'padding:8px 4px 4px 8px;',
                  defaults:{
                    xtype:'textfield',
                    labelWidth:180,
                    width:440,
                    msgTarget:'side'
                    
                  },  
                  items:[
                    {fieldLabel: loc.name, allowBlank: false, labelSeparator: reqSep,  name:'name',  itemId:'name', value:epob.dscr},
                    {fieldLabel: loc.productnr, name:'productnr',  itemId:'productnr'},
                    {fieldLabel: loc.ordernr, name:'ordernr',  itemId:'ordernr'},
                    {fieldLabel:'ID', xtype:'displayfield', name:'epimId',  itemId:'epimId',  value: '<span data-qtip="'+epob.epobId+'">'+epob.epobId.length*100+'</span>' },
                    {fieldLabel: loc.masterlang, xtype:'displayfield',  name:'masterlang',  itemId:'masterlang', value: loc.uiLanguage},
                    {fieldLabel: loc.seqOrdernr, hideTrigger:true,  xtype:'numberfield', width:220, allowBlank: false,   itemId:'seqOrdernr' }
                    
                    
                    ]
                  }
                ]
                
              },
              { title: loc.attributes , itemId:'attributes'},
              { title: loc.variants , itemId:'variants'},
              { title: loc.elements , itemId:'elements'},
              { title: loc.relations , itemId:'relations'},
              { title: loc.previews , itemId:'previews'},
              { title: loc.tasks , itemId:'tasks'},
              dqiSubTabPanelCfg,
              { title: loc.versions , itemId:'versions'},
              { title: loc.history , itemId:'history'},
              { title: 'Custom' , itemId:'custom'},
              { title: loc.collaboration+'&nbsp;&nbsp;&nbsp;', itemId:'collaborations',
                badgesCfg :{ cls:'xty_hint-badge', count: 7, tooltip: 'neue Benachrichtigungen'}   
              }

            ],
            listeners:{          
              afterrender:function(tabPanel){                      
                if(tabPanel.doTabBadges){
                    var ti;
                    for(ti =0; ti< tabPanel.items.length; ti++ ){
                      var tab = tabPanel.getComponent(ti);
                        if (tab.badgeCfg){
                          extVia.editor.baseEditor.statics.createTabBadge(tab, ti );
                        }
                    } 
                 }// eo  doTabBadges  
                }              
             }// eo listeners

            }
        ]
      };
      
      return editorPanelCfg;
      
    },
    
    
    getEpobEditorPanelCfg : function(cfg, epob){
      var showVersioningDraftEditor =  extVia.editor.baseEditor.statics.epobEditor === 'versioningDraft';
      var showCollaborationsDraftEditor =  extVia.editor.baseEditor.statics.epobEditor === 'collaborationsDraft';
      
//      if(cfg){
//        cfg
//      }
      
      if(showVersioningDraftEditor ){//}|| showCollaborationsDraftEditor){
        return extVia.editor.baseEditor.statics.getVersionsHistoryDraftEditorCfg(cfg, epob);
      }
      else if(showCollaborationsDraftEditor){
        cfg.activeTab = extVia.editor.baseEditor.statics.activeTab;
        return extVia.editor.baseEditor.statics.getEditorPanelCfg(cfg, epob);
      }
      else{
        cfg.activeTab = extVia.editor.baseEditor.statics.activeTab;
        return extVia.editor.baseEditor.statics.getEditorPanelCfg(cfg, epob);
      }
    },
    
    
    
    createTabBadge : function(tab, tabIndex ){
      if (tab.badgeCfg){
       var badgecount = tab.badgeCfg.count;
       
       var tabPanel =  tab.ownerCt;

       /////////// helper functions   
       if (!tabPanel.tabbadgeHelpFuncs){
         tabPanel.getComponentIndex = function(itemId){
           var componentIndex =-1;
           //var tabPanel =  this;
            var ci;
            for(ci =0; ci< tabPanel.items.length; ci++ ){
              var subComp = tabPanel.getComponent(ci);
              if (subComp && subComp.itemId === itemId){
                componentIndex = ci;  
                break;
              }
            }
            return componentIndex;
         };
         tabPanel.getTabItem = function(itemId){
           //var tabPanel =  this;
           var tab =  tabPanel.getComponent(itemId);
           var tabIndex =  tabPanel.getComponentIndex(itemId); 
           var tabitem = tabPanel.getTabBar().items.get(tabIndex);
           return tabitem;
         }; 
         
         tabPanel.tabbadgeHelpFuncs = true;
       }
       // eo helper funcs
       
       if (!tabIndex) {tabIndex =  tabPanel.getComponentIndex(tab.itemId);}
        var tabitem = tabPanel.getTabBar().items.get(tabIndex);
        tabitem.addCls('xty_'+tab.itemId+'-tab xty_tab-hasbadge');
        var badgeCls = tab.badgeCfg.cls;                                 
        var left = tabitem.getEl().getLeft() - tabPanel.getEl().getLeft() + tabitem.getWidth() - 20;
            
        
          var badgeHandler = function(badge){
              tabPanel.setActiveTab(tab);   
              badge.getEl().slideOut();//on firstClick???
          };
          
          if (tab.badgeCfg.handler){   
              badgeHandler = Ext.Function.createSequence(badgeHandler, tab.badgeCfg.handler);
          }
  
        
        var badge = Ext.create('Ext.Button', {
          itemId:tab.itemId+'-badge',
          scale:'small',
          renderTo: tabPanel.ownerCt.id, 
          style:'position:absolute;top:104px; left:'+(left) +'px;z-index:19;',
          //renderTo: tabitem.id+'-btnWrap',
          //style:'position:absolute;top:-4px; left:60px;z-index:999;',
          cls:'xty_badge-btn xty_'+tab.itemId+'-badge-btn '+badgeCls+'-badge-btn  xty_badge-btn-3 '+(badgecount>9 ? badgeCls+'-badge-btn-len2' : badgeCls+'-badge-cipher xty_badge-cipher xty_badge-cipher-'+badgecount), 
          height:16,
          width:16,
          xtype:'button',
          text:badgecount,
          myTab: tab,
          tooltip: badgecount+' '+tab.badgeCfg.tooltip,
          badgecount:badgecount,
          handler:badgeHandler
       }); 
      }
     },

    
        
    getVersionsHistoryDraftEditorCfg : function(cfg, epob){

    	var editorMainTabItemId = 'epobEditorPanel'+ (epob.epobId?epob.epobId:epob.dscr) ;	
    		    	
    	var	editorPgjobButtons =[];	

//      editorPgjobButtons.push(
//          {xtype:'buttongroup',
//            cls:'xty_groupbuttons-btn-grp',
//            defaults:{enableToggle:true},
//            items:[
//             {tooltip:'Vererbung anzeigen' , itemId:'inheritance', enableToggle: true, iconCls:'xty_icon xty_iconInheritanceActive'},
//             {tooltip:'&Auml;nderungsinformation' , enableToggle: true, itemId:'changeinfo',  iconCls:'xty_epobChangeinfo'},
//             {tooltip: 'Sichten' , itemId:'views', enableToggle: false,  iconCls:'xty_pgtoolbar-databaseviews',
//              menu:[
//                {
//                  xtype:'boundlist', 
//                  queryMode: 'local',
//                  multiSelect : true,
//                  displayField: 'dscr',
//                  store: extVia.stores.initDbViewsStore(),
//                  listeners:{
//                    itemclick: function( view, record, item, index, e, eOpts ){ }
//                  },
//                  //listConfig : { minWidth:610  } ,
//                  width:160,
//                  itemTpl : '<div style="widtsh:180px; hceight:18px;" class="xty_dbviews-item">&nbsp; {dscr}  <span style="color:#ddd">({hits})</span> </div>' 
//                  }
//                ]  
//             }
//            ]
//          });
      
      
      
    	editorPgjobButtons.push(extVia.editor.baseEditor.statics.getContentSwitcherCfg({editorMainTabItemId:editorMainTabItemId, epob:epob, isInPgjobbar:true},epob));
    	
		
    	var removeItem = {itemId:'removeItem', tooltip:'Kindobjekt l&ouml;schen',iconCls : 'xty_pgtoolbar-removeItem',
    	 handler:function(button){
    		 var centerTabPanel = button.up('tabpanel');
        	 var editorSubTabsPanel = centerTabPanel.getActiveTab().getComponent('editorSubTabsPanel');
        	 var activeSubTab = editorSubTabsPanel.getActiveTab();
        	 //activeSubTab.close();
        	 
        	 
        	 if (activeSubTab.removeSelectedEpobs){
        		activeSubTab.removeSelectedEpobs(); 
        	 }
        	 else{
          		Ext.create('widget.uxNotification', {
    				title: button.tooltip,
    				status : "Inactive",
    				position: 'tr',
    				manager: 'instructions',
    				cls: 'ux-notification-light',
    				iconCls: 'ux-notification-icon-information',
    				html :  ' not available on this subtab',
    				autoCloseDelay: 2000,
    				slideBackDuration: 500,
    				slideInAnimation: 'bounceOut',
    				slideBackAnimation: 'easeIn'
    			}).show();
        	 }
        	 
    	 }	
    	};
    	
    	var	editorPagetoolbarButtons =[extVia.editor.baseEditor.statics.getSaveButtonCfg(editorMainTabItemId)];	
    	
    	//editorPagetoolbarButtons.push({itemIXd:'', tooltip:'Reset',iconCls : 'xty_pgtoolbar-clear'});
    	
    	editorPagetoolbarButtons.push(removeItem);
        editorPagetoolbarButtons.push({xtype:'splitbutton',itemId : 'saw',iconCls : 'xty_pgtoolbar-saw' , hidden:true,tooltip:'Vererbung unterbrechen', marssgins:'0 170 0 0',
         menu:[
         { text: 'Vererbung unterbrechen' ,iconCls:'xty_menu-inheritance-break' },
         { text: 'Vererbung aktivieren' ,iconCls:'xty_menu-inheritance-activate'},
         { text: 'Weitervererbung unterbrechen' ,iconCls:'xty_menu-furtherinheritance-break'  }
         ]
        });
    	
        //editorPagetoolbarButtons.push({xtype:'tbspacer' , width:30});  

    	editorPagetoolbarButtons.push({itemIXd:'', tooltip:'Export',iconCls : 'xty_pgtoolbar-export'});

    	editorPagetoolbarButtons.push({itemId:'addToCollection', tooltip:'Zur Standardsammlung hinzuf&uuml;gen',iconCls : 'xty_pgtoolbar-collectionAddTo'});
    	
    
    	
    	
    	 var  versionBtnCfg =  {
        itemId:'versioning-create', 
        tooltip: 'Version erstellen', 
        menu:[],
        iconCls:'xty_pgtoolbar-versioning-create'
       };
    	 
    	 
    	 

    	 
    	if (!Ext.isEmpty(extVia.configurator)  && !Ext.isEmpty(extVia.configurator.statics)){
    	  editorPagetoolbarButtons.push({itemId:'configurator', handler:extVia.configurator.statics.showConfiguratorDialog, tooltip:'Konfigurieren',iconCls : 'xty_pgtoolbar-configurator'});
    	}
    	
    	
    	
    	
    	 if (Ext.isDefined(extVia.versionsProto)){
    	   versionBtnCfg = extVia.versionsProto.statics.getCreateVersionButtonCfg({},epob,editorMainTabItemId, true);
    	 }
    	  editorPagetoolbarButtons.push( versionBtnCfg );
    
      

        editorPagetoolbarButtons.push({itemId:'openDiff', hidden:true, tooltip:'Vergleichsansicht &ouml;ffnen',  handler:function(){extVia.regApp.showDiffPanel(epob);},iconCls : 'xty_XXpgtoolbar-versioning-diff'});
      

        if (Ext.isDefined(extVia.historyProto )){
          editorPagetoolbarButtons.push( extVia.historyProto.statics.getHistoryRowDialogButtonCfg({}, epob) );  
        }
        
    	
    	editorPagetoolbarButtons.push('->');

      
//      
//     var areaComboCfg = {
//         fieldLabel : "Bereich", xtype:'combo', name:'area',  itemId:'area',
//         forceSelection:false,
//          queryMode: 'local',displayField: 'dscr',  valueField: 'value',     
//          store:
//            Ext.create('Ext.data.Store', {
//              model: Ext.define('Area', {fields: ['dscr', 'value'], extend: 'Ext.data.Model'}),
//              data:[{dscr:'', value:'', isEmpty:true},{dscr:'Metadaten', value:'Metadaten'},{dscr: 'Workflows',value:'Workflows'},{dscr:'Attribute',value:'Attribute'}, {dscr:'Elemente',value:'Elemente'},
//                  {dscr:'ererbte Elemente',value:'ererbte Elemente'}
//                  ]
//          }),  
//          listConfig : {
//            itemTpl : 
//                '<div style=" <tpl if="isEmpty">height:14px;</tpl>  ">'   // oder '<div class=" <tpl if="value === &quot;&quot; "> xty_optionEmpty</tpl>  ">'
//                + '{value}'
//                + '</div>'
//            }   
//      };
//                     
//       var epobTypeComboCfg = {
//          xtype:'combo',
//          fieldLsabel : "Typ",  
//          width:100,
//          name:'type',  
//          emptyText: 'Objekte',
//          itemId:'filter_type',
//          queryMode: 'local', displayField: 'dscr',  valueField: 'value',   
//          // multiSelect:true,
//          store:  extVia.stores.getHistoryEpobTypesStore(),
//           
//          listConfig : {
//             minWidth:180,
//             getInnerTpl : function(displayField) {
//               var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div></div>';
//               return tpl;
//             }
//           } 
//       };
      
       
       
    	var showFilterPanel ;
      if (Ext.isDefined(extVia.historyProto )){
        showFilterPanel = extVia.historyProto.statics.showFilterPanel;
      }
      
       
      var finderBtnGrpCfg = {
       xtype: 'buttongroup',
       itemId:'finderBtnGrp',
       tooltip:'Daten finden',
       columns: 7,
       defaults: {
           scale: 'small'
       },
       items:[  
      {  
      xtype:'spinnerfield', 
      itemId:'searchMatchesSpinner',
      disabled:true,
      width:16, 
      editable : false , 
      cls:'xty_spinner-plain xty_spinner-left'
      }, 
      {
          xtype:'triggerfield', 
          cls : 'xty_inside-trigger',
          trigger1Cls : 'xty_search-inside-trigger',
          onTriggerClick:function(){
           // versionGrid.getComponent('diffgrid_linenumbersbar').removeCls('xty_linenumbersbar-hide-items');
        }
      },
        {  
            xtype:'triggerfield' ,
            itemId:'searchfilterTrigger',
            triggerCls : 'xty_form-trigger-filsster',
            onTriggerClick: function(){
              var histgridFilterbar = Ext.get('histgrid-filterbar');
              if (histgridFilterbar.isVisible()){histgridFilterbar.hide();}
              else{histgridFilterbar.show();}
              },
            
            tooltip:'Filtern',
            disasbled:true,
            width:16, 
            editable : false , 
            cls:'xty_trigger-plain', 
            listeners:{
             afterrender:function(button){
              // Provide tooltips on button should be done by buttongroup
              var tip = Ext.create('Ext.tip.ToolTip', {
              target: button.id,
              html: button.tooltip
             });
             }
           } 
          },
          
           {xtype:'button',icsnCls : 'x-tool-filter', itemId:'filter',tooltip:'Aktivitäten filtern',
             width:16, 
             height:22,
             //xtype:'splitbutton',
             handler:showFilterPanel,
             fakePanel:true,
             menu:{},

            listeners:{
               afterrender:function(button){
               //showFilterPanel();
              }
             } 
           }
  
       ],
       setTooltip:function(tooltip){
        //alert("btngroup  setTooltip "+tooltip)
//          var tip = Ext.create('Ext.tip.ToolTip', {
//          target: this.id,
//          html: tooltip
//          });
          this.tip.html = tooltip;
       },
       listeners:{
         afterrender:function(btngroup){
          var tip = Ext.create('Ext.tip.ToolTip', {
          target: btngroup.id,
          html: btngroup.tooltip
          });
          btngroup.tip = tip;
         }
       } 
       
    };
      
    
    
    
     if (!epob.epobId) {
         epob.epobId = Ext.id();
     }
    
   

     editorPagetoolbarButtons.push( finderBtnGrpCfg );


      
    	if (!extVia.regApp.viewCfg.subpanelListsinPage) {
          editorPagetoolbarButtons.push( {cls : 'xty_morebutton  xty_btn-menu-arrow-off', width:40, enableToggle:true,  iconCls : 'xty_pgtoolbar-more', itemId:'more-btn', relatedTabIndex:6,  csls : 'x-btn-disabled',tooltip:'Liste Items', 
          //menu:{ items:[  extVia.versionsProto.statics.getVersionsItemsListCfg()]}
          menu:{ items:[ ]}
          });
        }  
    	
    	editorPagetoolbarButtons.push({xtype:'tbspacer' , width:10});  
    	
    	var epobTypeDscr = 'Produkt';
    	
    	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28 -136 ;// tabstrip appbar tabstrip
    	//var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
    	
    	var pgjobEpobDscr =  epob.dscr;
      
 
        
//       var alphabeth = {a:1,b:2,c:3,d:4,e:5,f:6,g:7,h:8,i:9,j:10,k:11,l:12,m:13,n:14,o:15,p:16,q:17,r:18,s:19,t:20,u:21,v:22,w:23,x:24,y:25,z:26};
//       var stringCharsAsNumbers = function (str){
//         var nrStr = '';
//         if (str){
//             str = str.toLowerCase().replace(/_/g,'');
//	         var ni; 
//	         for (ni = 0; ni< str.length; ni++){
//	          var ch = str.charAt(ni);
//              if (alphabeth[ch]){nrStr+=  alphabeth[ch];}
//              else {nrStr+=ch;}
//	          
//	         }
//         }
//         return nrStr;
//        }
//        epob.epobIdNr = stringCharsAsNumbers(epob.epobId);
      
      
    	var epobTabDscr =  extVia.locales.product; //'Produkt';
        var pgjobDscr= epobTabDscr +   extVia.locales.pflege; //"pflege";
    	var isPRODUCT = true;
        var isPRODUCTS = true;
        var isPRODUCTVARIANT = false;
        var isHIERARCHY = false;
    	var isCONTENT = false;

        if ( extVia.module.epob.getAreaId(epob.typeId) ===  extVia.module.epob.CONTENT ||  extVia.module.epob.getAreaId(epob.epobTypeId) ===  extVia.module.epob.CONTENT ){
    		
            epobTabDscr="Bild";
            if (epob.epobTypeId ===  extVia.module.epob.DOCUMENT){
              epobTabDscr="Dokument";
            }
            pgjobDscr= epobTabDscr+"pflege";
            
    		isPRODUCT=false;
            isPRODUCTS = false;
    		isCONTENT=true;
    	}
        else{
           isPRODUCTS = true;
           isCONTENT = false;
          
           if (epob.epobTypeId ===  extVia.module.epob.PRODUCTVARIANT){
              //epobTabDscr="Produktvariante";
              pgjobDscr= "Produktvariantenpflege";
              epobTabDscr="Variante";
              isPRODUCTVARIANT = true;
              isPRODUCT=false;
            }
           else if (epob.epobTypeId ===  extVia.module.epob.PRODUCTGROUP || epob.epobTypeId ===  extVia.module.epob.HIERARCHY){
              epobTabDscr="Hierarchie";
              isHIERARCHY = true;
              isPRODUCT=false;
              pgjobDscr= epobTabDscr+"pflege";
           } 
        }
 

    	var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:pgjobDscr, epobDscr:pgjobEpobDscr,  pagetoolbarButtons: editorPagetoolbarButtons,pgjobButtons: editorPgjobButtons,  breadcrumb:epob.breadcrumb} );

    	var showFakeMiniToolbarDIV = false;
      
        var getAttributesFakeHTML = function(){
          
        var createMiniToolbarMenu = function(cfg){
              var miniToolbarMenu= Ext.create('Ext.menu.Menu', { 
              //cls:'xty_minitoolbar-menu',// why does this not work?
              shadow:false,showSeparator : false,   
              currentCellId:'not set yet',
              items:[
                {xtype:'toolbar',    width: cfg.items.length*24,          
                  defaults:{ overCls:'xty_btn-over'},
                  items:cfg.items
               }] 
              });
         miniToolbarMenu.addCls('xty_minitoolbar-menu');
         return miniToolbarMenu;
        }; 
          
        var miniToolbarMenuValue = createMiniToolbarMenu({
                  itemId:'minitoolbar',
                  items:[
                  {iconCls:'xty_minitoolbar-updown',
                  listeners:{
                    'mouseover':function(button , evt){
                       if (evt.getY() - button.getPosition()[1]  > 10){
                        button.addCls('xty_minitoolbar-updown-down');  
                       }
                       else{
                        button.addCls('xty_minitoolbar-updown-up');  
                       }
                      },
                    'mouseout':function(button , evt){
                      button.removeCls('xty_minitoolbar-updown-up');  
                      button.removeCls('xty_minitoolbar-updown-down');   
                   } 
                  }
                  },
                  {iconCls:'xty_minitoolbar-cut', 
                    
                    handler:function(button){
                      
                      //alert(button.ownerCt.ownerCt.currentCellId)
                      
                      var currentCellId = button.ownerCt.ownerCt.currentCellId;
                      
                      if (button.lastCurrentCellDivEl){
                       button.lastCurrentCellDivEl.addCls('xty_fake_minitoolbar');
                       button.lastCurrentCellDivEl.removeCls('xty_clipboard-selection'); 
                      }
                      var cellEl = Ext.get(currentCellId);
                      var cellDiv = document.getElementById(cellEl.id).firstChild;
                      var cellDivEl = Ext.get(cellDiv);
                      
                      cellDivEl.removeCls('xty_fake_minitoolbar');
                      cellDivEl.addCls('xty_clipboard-selection');
                      button.lastCurrentCellDivEl = cellDivEl;
                      }
                      
                      
                    
                    },
                  {iconCls:'xty_minitoolbar-paste'},
                  {iconCls:'xty_minitoolbar-duplicate'},
                  {iconCls:'xty_minitoolbar-plus'},
                  {iconCls:'xty_minitoolbar-close'}
                ]        
        });
        var miniToolbarMenuDscr = createMiniToolbarMenu({
                  items:[
                  {iconCls:'xty_minitoolbar-cut'},
                  {iconCls:'xty_minitoolbar-paste'},
                  {iconCls:'xty_minitoolbar-editcell'}
                ]        
        });
    
        
          extVia.editor.baseEditor.statics.attributesFakeTABLEmouseover=function(element){
           
          //extVia.editor.baseEditor.statics.currentCellId=element.id;
            
          if (!showFakeMiniToolbarDIV){
             if (element.id.indexOf("prat")>-1){
              miniToolbarMenuDscr.showAt(Ext.get(element).getX()+200, Ext.get(element).getY()-2);
              miniToolbarMenuDscr.currentCellId=element.id; // How to acces menu from menuItem
             }
             else{
              miniToolbarMenuValue.showAt(Ext.get(element).getX()+180, Ext.get(element).getY()-2);
              miniToolbarMenuValue.currentCellId=element.id;
             }  
          }
          
            var cell = Ext.get(element.id);
            cell.addCls("xty_fakeTABLE-over");
          };
          
          
          extVia.editor.baseEditor.statics.attributesFakeTABLEmouseout=function(element){
            Ext.get(element.id).removeCls("xty_fakeTABLE-over");
          };          
          extVia.editor.baseEditor.statics.attributesFakeTABLEmouseclick=function(element){
            Ext.get(element.id).addCls("xty_fakeTABLE-selected");
            
           var dragSrc = new Ext.dd.DragSource(element.id, {dragData:{epobDscr: "Produkt 123"}});
            
            if (extVia.editor.baseEditor.statics.lastfakeTDclickedId){
               Ext.get(extVia.editor.baseEditor.statics.lastfakeTDclickedId).removeCls("xty_fakeTABLE-selected");
            }
            
            var deselect = false;
            if (extVia.editor.baseEditor.statics.lastfakeTDclickedId !== element.id){
               extVia.editor.baseEditor.statics.lastfakeTDclickedId = element.id;
               
            }
            else{
               deselect = true;
               extVia.editor.baseEditor.statics.lastfakeTDclickedId = null;
            }
           
            if (element.id.indexOf("prat")>-1){
              var childsArr  = Ext.DomQuery.select('#attributesFakeTABLE-bin [parentId='+element.id+']');
              var qi;
              for (qi = 0; qi< childsArr.length; qi++){
                
                if (deselect){
                  Ext.get(childsArr[qi]).removeCls("xty_fakeTABLE-selected");
                  Ext.get(childsArr[qi]).removeCls("xty_fakeTABLE-group-selected");
                  Ext.get(childsArr[qi]).removeCls("xty_fakeTABLE-group-selected-top");
                  Ext.get(childsArr[qi]).removeCls("xty_fakeTABLE-group-selected-bottom");
                  Ext.get(childsArr[qi]).removeCls("xty_fakeTABLE-group-selected-right");
                  Ext.get(childsArr[qi]).removeCls("xty_fakeTABLE-group-selected-left");
                }
                else{
	                Ext.get(childsArr[qi]).addCls("xty_fakeTABLE-group-selected");
	                if (qi<2){
	                  Ext.get(childsArr[qi]).addCls("xty_fakeTABLE-group-selected-top");
	                }
	                if (qi>childsArr.length-3){
	                  Ext.get(childsArr[qi]).addCls("xty_fakeTABLE-group-selected-bottom");
	                }
	                if (qi%2 === 1){
	                  Ext.get(childsArr[qi]).addCls("xty_fakeTABLE-group-selected-right");
	                }
	                else{
	                  Ext.get(childsArr[qi]).addCls("xty_fakeTABLE-group-selected-left");
	                }
                }  
              }
              
            }
            
            
            
          };   
          
          
         var html = '<div id ="attributesFakeTABLE-bin" style="margin-top:29px;margin-left:-1px;border:1px solid transparent;">';
           html+= '<table>';

           var mouseHandlerAttribsVal=' onclick="extVia.editor.baseEditor.statics.attributesFakeTABLEmouseclick(this)" onmouseout="extVia.editor.baseEditor.statics.attributesFakeTABLEmouseout(this)" onmouseover="extVia.editor.baseEditor.statics.attributesFakeTABLEmouseover(this)" ';
           
           
           
           var fakeAttriDscrs = [];
           fakeAttriDscrs[1]="AutoTDict";
           fakeAttriDscrs[4]="AutoTDate";
           fakeAttriDscrs[5]='';
           
           fakeAttriDscrs[8] = 'AutoTFlag';
           fakeAttriDscrs[11]='AutAutoTColfoTFlag';
          
           fakeAttriDscrs[17]='AutoTCol';
           fakeAttriDscrs[18]='AutoTColStr';
           fakeAttriDscrs[20] = 'AutoTDyn';
           
           fakeAttriDscrs[32] = 'AutoTColDict';
           fakeAttriDscrs[33] = 'AutoTColStr';
           fakeAttriDscrs[39] = 'Schnitzel';
           fakeAttriDscrs[40] = 'Bohrhammer';
           
           
           
           var i;
           for ( i =1; i < 42 ; i++){
             var mouseHandlerAttribsDscr=' onclick="extVia.editor.baseEditor.statics.attributesFakeTABLEmouseclick(this)" onmouseout="extVia.editor.baseEditor.statics.attributesFakeTABLEmouseout(this)" onmouseover="extVia.editor.baseEditor.statics.attributesFakeTABLEmouseover(this)" ';
            
            var height=28;
            
            var backgroundImgDscr='background-image:url(../img/fakes/prat/minitoolbar-dscr.png);background-position:90px 0px;background-repeat:no-repeat;';
            var backgroundImgValue='background-image:url(../img/fakes/prat/minitoolbar-value.png);background-position:130px 0px;background-repeat:no-repeat;';
            

            if (!showFakeMiniToolbarDIV){
              backgroundImgDscr='';
              backgroundImgValue='';
            }
            
            
            var noDscrTBarr = [2,3,5,6,7,9,10,11, 17,21,22,23,24,25,26,27, 30,34,35,36,37,38, 39, 40];
            

            var parentsId ="";
            if (i<4){parentsId ="AutoTDict";}
            else if (i<8){parentsId ="AutoTDate";}
            else if (i<11){parentsId ="AutoTFlag";}
            else if (i<16){parentsId ="";}
            else if (i<18){parentsId ="AutAutoTColfoTFlag";}
            else if (i<20){parentsId ="";}
            else if (i<28){parentsId ="AutoTColStr";}
            else if (i<33){parentsId ="";}
            else if (i<41){parentsId ="AutoTColStr2";}

            if (parentsId.length>0){
              parentsId='prat_'+parentsId;
            }
            
            
            if (i===2){height=35; }
            else if (i===11){height=41;backgroundImgDscr=''; backgroundImgValue='';}
            else if (i===12){height=35; }
            
            if (noDscrTBarr.indexOf(i)>-1){backgroundImgDscr='';mouseHandlerAttribsDscr='';}

 
            var showCount = false;
            
            var attriDscr = fakeAttriDscrs[i];
            attriDscr = Ext.isEmpty(attriDscr)? ''   :attriDscr;
            
            html+= 
            '<tr id="fakeTABLErow_'+i+'" class="xty_fakeTABLErow"  >'
              +'<td class="xty_fake_pratTD xty_fake_prat-rownumbererTD"  style="height: '+height+'px;width:51px;color:red;">'+(showCount?i:'')+'</td>'
              +'<td id="'+parentsId+'"  parentId="'+parentsId+'"  title="Name:&nbsp;'+i+'LO_Selection_unit_pratDatentyp:&nbsp;SelectionAuswahlgruppen:&nbsp;"   class="xty_fake_pratTD xty_fake_pratTD-dscr" style="text-align:left;width:280px;padding-left:4px;" '+mouseHandlerAttribsDscr+'>'
                 +'<span class="xty_fake_prat-dscr" style="font-style:italic; font-size:11px;font-weight:bold;background-color:white;" >'
                +attriDscr
               +'</span>'
                
                  +'<div class="xty_fake_minitoolbar "xty_fake_minitoolbar-dscr" style="padding:0px;width:280px !important;height:'+(height-1)+'px;'+backgroundImgDscr+'">&nbsp;&nbsp;&nbsp;</div>'
                +'</td>'
              +'<td class="xty_fake_pratTD xty_fake_pratTD-val" id="'+Ext.id()+'" parentId="'+parentsId+'" style="width:333px;" '+mouseHandlerAttribsVal+'>'
                  +'<div class="xty_fake_minitoolbar "xty_fake_minitoolbar-val" style="padding:0px;width:333px !important;height:'+(height-1)+'px;'+backgroundImgValue+'">&nbsp;&nbsp;&nbsp;</div>'
              +'</td>'
            +'</tr>';
           }
           html+= '</table>';
           html+= '</div>';
           return html;
           
        };
      
        var attributesFakeHTML = getAttributesFakeHTML();
        //attributesFakeHTML+= getAttributesFakeHTML();

        
        
        
        var elementsTabGridToolHandler = function(event, toolEl, headerpanel){
        var toolButton =  Ext.getCmp(Ext.get(toolEl.id).dom.parentNode.id);

        var panel = toolButton.ownerCt.ownerCt;

         if (toolButton.type==='restore'){ 
          toolButton.hide();
          headerpanel.tools.maximize.show();
          panel.setHeight(panel.getHeight()/2);
         }
         else if (toolButton.type==='maximize'){
           toolButton.hide();
           headerpanel.tools.restore.show();
           panel.setHeight(panel.getHeight()*2);  
         }
         else if (toolButton.type==='minus'){
           if (panel.collapsed){panel.expand();}
           else{panel.collapse();} 
         }
         
        };
        
  
        
       var elementsTabGridTools =[{type:'restore', hidden:true, handler:elementsTabGridToolHandler},{type:'maximize', handler:elementsTabGridToolHandler},{type:'minus',handler:elementsTabGridToolHandler}];
  
        
        var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();
        var elementsGridsWidth =  mainContentPanelWidth - 24 - 24 - 16; // margin LR , scrollbar
        
        var currentMultipleId;
        var currentMultipleIdCount = 0;
        var getSameIdMultipleTimes = function(howOften){
          if ( currentMultipleIdCount === 0){
           currentMultipleId = Ext.id();
          }
          currentMultipleIdCount ++;
          if (currentMultipleIdCount === howOften){
           currentMultipleIdCount = 0;
          }
          return currentMultipleId;
        };

        
      
        var reqSep = extVia.editor.baseEditor.statics.getLabelSeparator4Required();
        
        
      var me = this;
        
      var subTabsHeight = extVia.editor.baseEditor.statics.getEditorSubTabContentPanelHeight();
        
    	var epobEditorPanelCfg = {
    				title:pgjobEpobDscr, 
    				applibarId:applibar.id,
    				tbar : applibar,
    				getApplicationBar:function(){
    					return applibar;
    				},
    		    	setPagejobDscr : function setPagejobDscr(pgjobDscr){
    		    		applibar.setPagejobDscr(pgjobDscr);
    		    	},
    		    	setEpobDscr : function setEpobDscr(epobDscr){
    		    		applibar.setEpobDscr(epobDscr);
    		    	},
    		    	setSubEpobDscr : function setSubEpobDscr(subEpobDscr){
    		    		applibar.setSubEpobDscr(subEpobDscr);
    		    	},
    		    	hideSubEpobDscr : function hideSubEpobDscr(subEpobDscr){
    		    		applibar.hideSubEpobDscr(subEpobDscr);
    		    	},
    		    	getPagejobDscr : function getPagejobDscr(){
    		    		return applibar.getPagejobDscr();
    		    	},
    		    	getEpobDscr : function getEpobDscr(){
    		    		return applibar.getEpobDscr();
    		    	},
    				closable:true,
    				active:true,
    				itemId:editorMainTabItemId,
    				stateId:editorMainTabItemId,
            

                    getEditorSubTabsPanel:function(){
                       var editorSubTabsPanel = this.getComponent("editorSubTabsPanel");
                       return  editorSubTabsPanel ; 
                    },   
                    getHistoryTabPanel:function(){
                       var editorSubTabsPanel = this.getComponent("editorSubTabsPanel");
                       return  editorSubTabsPanel.getComponent('history') ; 
                    }, 
                    getVersionsTabPanel:function(){
                       var editorSubTabsPanel = this.getComponent("editorSubTabsPanel");
                       return  editorSubTabsPanel.getComponent('versionTab') ; 
                       
                    },                     
                    
                    skip:function(cfg, epob){
                     var editorSubTabsPanel = this.getComponent("editorSubTabsPanel");
                     if (editorSubTabsPanel && editorSubTabsPanel.skip){ editorSubTabsPanel.skip(cfg, epob);}
                     else{ extVia.notify({action:'skip', status:'inactive', mssg:'no sub-Navi on '+this.title});}
                    },

                    
    				       items:[ 
                            { 
                        	  xtype:'tabpanel',
                        	  border:false, margin : '0 0 0 0', 
                           	cls:'xty_hasInvisibleTabitemsX', 
                           	tabBar:{cls:'xty_subtabpanel-tabbar xty_tabbar-noborder-rl'},
                           	activeTab:  cfg.activeTab,//isPRODUCT?2:1,
                           	stateful:true,

                           	itemId:'editorSubTabsPanel',
                           	stateId:'editorSubTabsPanel',
                            skip:function(cfg, epob){
                                 var editorSubTabsPanelActiveTab = this.getActiveTab();
                                 var subItemViewPanel = editorSubTabsPanelActiveTab.getComponent('subItemViewPanel');
                                 if (subItemViewPanel && subItemViewPanel.skip){ subItemViewPanel.skip(cfg, epob);}
                                 else{ 
                                    extVia.notify({action:'skip', status:'inactive', mssg:'no sub-Navi on '+editorSubTabsPanelActiveTab.title+' Panel '});
                                 }
    		                    },
                        
			                    
    			                 doTabBadges:true,   
    			                 listeners:{          
    			                   afterrender:function(tabPanel){                      
    			                     
    			                     if(tabPanel.doTabBadges){
    			                         var ti;
    			                         for(ti =0; ti< tabPanel.items.length; ti++ ){
    			                           var tab = tabPanel.getComponent(ti);
    			                             if (tab.badgeCfg){
    			                               extVia.editor.baseEditor.statics.createTabBadge(tab, ti );
    			                             }
    			                         } 
    			                      }// eo  doTabBadges  
    			                     
    			                     }              
    			                   },
                            
                            
                            
                            

                           	defaults:{
                           	 border:false,
                           	 autoScroll:true,
                           	 height:mainContentPanelHeight,
                           	 //width:mainContentPanelWidth,
          	               
                           	 listeners:{
                              
                              
          	            	   activate:function(tab){
   
          	            		   if (tab.activate){tab.activate(tab); }
          	            		   var editorPanel = tab.ownerCt.ownerCt; 
          	            		   var moreButton = editorPanel.getApplicationBar().pagetoolbar.getComponent('more-btn');

          	            		   if (moreButton){
              	            		   if (tab.moreBtnCfg && tab.moreBtnCfg.dscr){
                                          moreButton.setTooltip(tab.moreBtnCfg.dscr);
                                          if ( tab.moreBtnCfg.menuCfg){
                                            
                                             tab.moreBtnCfg.menuCfg.itemId='moreMenu';
                                             moreButton.showMyMenu = function(){
                                              
                                              var showByEl = moreButton;  
                                              var showByAnchor = 'tr-br?'; 
                                              var showByPos =  [-6, 37];
                                                
                                              if (moreButton.myMenu.align && moreButton.myMenu.align==='tabitem'){
                                                var tabitem = tab.ownerCt.getTabItem(tab.itemId);
                                                 showByEl = tabitem;
                                                 showByAnchor = 'tl-bl?';
                                                 showByPos =  [-1, 2];                                                 
                                               }
                                               if (moreButton.myMenu.showMode && moreButton.myMenu.showMode==='slideIn'){
                                                   moreButton.myMenu.getEl().slideIn();
                                               }
                                               else{
                                                moreButton.myMenu.showBy( moreButton, "tr-br?", [-6, 37] );
                                               }                                            
  
                                             };
                                            
                                             moreButton.handler = moreButton.showMyMenu; 

                                             if (!tab.moreBtnCfg.menu){ 
                                              tab.moreBtnCfg.menuCfg.listeners={hide:function(){
                                                moreButton.pressed=false;
                                                moreButton.removeCls('x-pressed x-btn-pressed x-btn-default-toolbar-'+extVia.constants.raster.pagetoolbarCenterBtnScale+'-pressed');    
                                                }
                                               };
                                              tab.moreBtnCfg.menu = Ext.create('Ext.menu.Menu', tab.moreBtnCfg.menuCfg); 
                                              tab.moreBtnCfg.menu.myMoreBtn = moreButton;
                                              tab.moreBtnCfg.menu.myTab = tab;
                                              
                                             }
                                             moreButton.myMenu= tab.moreBtnCfg.menu;  
                                             moreButton.myTab= tab;
                                          }
                                          else{
                                            moreButton.myMenu = null;
                                            moreButton.myTab= null;
                                          }
            		            		  moreButton.show();
               	            		   }
               	            		   else{          		            		  
                		                moreButton.hide();
                		               }        	            			   
          	            		   } 
                               
                                   var finderBtnGroup = editorPanel.getApplicationBar().pagetoolbar.getComponent('finderBtnGrp');
                                   if (finderBtnGroup){
                                   if (tab.finderBtnGrpDscr){
                                      finderBtnGroup.setTooltip(tab.finderBtnGrpDscr);
                                      finderBtnGroup.show();
                                   }
                                   else{                                
                                      finderBtnGroup.hide();
                                     }                               
                               } 
                               
                               
          	            	   },
          	            	   deactivate:function(tab){
          	            		 if (tab.deactivate){tab.deactivate(tab); }
          	            	   }
          	               	}
                           	},
                        
                             html:
                           '<div id="columnsHeaderOnlyPanel" class="xty_columnsHeaderOnlyPanel-bin  x-docked  "' +
                              ' style="visibility:hidden; width: '+elementsGridsWidth+'px; height:20px; z-index:9999; left: 24px;  top: -1px; border:1px solid #C5C5C5 !important;">' +
                            
                              '<div id="gridcolumn-chkbx-fake-'+Ext.id()+'" class="x-column-header x-columXXn-header-checkbox  x-box-item x-column-header  x-column-header-align-left x-column-header-first" ' +
                                 'style="width: 24px; margin: 0px; height: 23px; left: 0px; top: 0px;border-bottom:1px solid #C5C5C5;" role="presentation">' +
                                 
                              '<div class="x-column-header-inner xty_column-header-all-switch-bin" id="gridcolumn-chkbx-fake-titleContainer-'+Ext.id()+'" data-itemId="gridcolumn-chkbx-fake-titleContainer" style="height: 16px;margXXin-left:-4px; padding: 2px;">' + 
                              // '<input style="margin-top:4px; margin-left:-1px;" class="xty_column-header-all-switch" data-qtip="Elemente ausw�hlen<br>Alle (+ STRG)"  type="checkbox"/>'+
                            
  
                               '<span class="xty_form-checkbox-switch-bin" style="height: 16px;">'+ 
                                '<input type="checkbox"  class="xty_form-checkbox-switch xty_column-header-all-switch" id="column-header-all-switch-'+getSameIdMultipleTimes(2)+'" >'+ 
                                  '<label id="inheritance-checkbox-label" class=""xty_form-checkbox-switch-label" for="column-header-all-switch-'+getSameIdMultipleTimes(2)+'"  >'+
                                    '<span class="xty_form-checkbox-switch-checked  checked" ></span>' +
                                    '<span class="xty_form-checkbox-switch-unchecked unchecked" ></span>'+ 
                                  '</label>'   +
                               '</span>'+

                               
                              '</div>' +
                              '</div>' +  
                              
                              '</div>',                           
                           
                           
                           
                           
                           	items:[
//                           	       {
//                                   	   title:'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;&nbsp;&nbsp;', 
//                                   	   disasled:true
//                                   },
                           	       {
                                   	   title:epobTabDscr, 
                                       stateful:true,
                                       stateId:editorMainTabItemId+'-metadataTab',
                                       itemId:'metadataTab',
                    	               defaults:{ // Valid for all subtab boxes
                    	            	   width:580, margin:'24 24 24 24' 
                    	               },
                                       items:[
                                              {title:'Allgemeine Metadaten', 
                                              
                                              xtype:'form',
                                              bodyStyle:'padding:8px 4px 4px 8px;',
                                              defaults:{
                                                xtype:'textfield',
                                                //margin:'2 0 2 7',
                                                labelWidth:180,
                                                width:440,
                                                msgTarget:'side'
                                                
                                              },
                                              items:[
                                              //{fieldLabel:' Hierarchytyp', hidden: !isHIERARCHY},
                                              
                                              //{xtype:'tbspacer'},
                                              
										       { fieldLabel : "Kategorien", xtype:'combo', name:'category_1',  itemId:'category_1', hidden: !isCONTENT,
										         forceSelection:false, queryMode: 'local', displayField: 'dscr',  valueField: 'value',     
										          store: Ext.create('Ext.data.Store', { model:  Ext.define('Categories', {fields: ['dscr', 'value'], extend: 'Ext.data.Model'}),
										              data:[ {dscr:'', value:'', isEmpty:true},{dscr:'Objekt-Bild'},{dscr: 'Produkt-Bild'},{dscr: 'Berechnungen'},{dscr: 'Produktfoto'},{dscr: 'Produktwissen'}]})
                                               },
                                              {hideEmptyLabel:false, xtype:'triggerfield', disabled:true,  name:'category_2',  itemId:'category_2', hidden: !isCONTENT},
                                              //{hideEmptyLabel:false, xtype:'triggerfield', disabled:true,  name:'category_3',  itemId:'category_3',hidden: !isCONTENT},
                                              {fieldLabel:'Hierarchietyp', xtype:'displayfield', hidden: !isHIERARCHY, name:'hierarchytype',  itemId:'hierarchytype', value:'Produktgruppe'},
                                              {fieldLabel:'Name', allowBlank: false, labelSeparator: reqSep,  name:'name',  itemId:'name', value:epob.dscr},
                                              {fieldLabel:'Schlagworte', xtype:'textarea', rows: 2, hidden: !isCONTENT, name:'catchwords',  itemId:'catchwords'},
                                              {fieldLabel:'Artikelnr', hidden: !isPRODUCT , name:'productnr',  itemId:'productnr'},
                                              {fieldLabel:'Bestellnr', hidden: isHIERARCHY || isCONTENT, name:'ordernr',  itemId:'ordernr'},
                                              {fieldLabel:'K&uuml;rzel', hidden: !isHIERARCHY, name:'shortcut',  itemId:'shortcut'},
                                              {fieldLabel:'ID', xtype:'displayfield', name:'epimId',  itemId:'epimId',  value: '<span data-qtip="'+epob.epobId+'">'+epob.epobId.length*100+'</span>' },
                                              {fieldLabel:'Mastersprache', xtype:'displayfield', hidden: !isPRODUCTS, name:'masterlang',  itemId:'masterlang', value:'Deutsch'},
                                              {fieldLabel:'Reihenfolge',  hideTrigger:true,  xtype:'numberfield', width:220, allowBlank: false, labelSeparator: reqSep,  hidden: isCONTENT, name:'seqOrdernr',  itemId:'seqOrdernr' }

                                              //,{xtype:'tbspacer'}
                                              ]
                                              
                                              //,html: '<img  height="'+(isCONTENT?210:188)+'px" src="../img/fakes/metadatenBox_'+(isCONTENT?'img':'prod')+'.png"/>'
                                              
                                              
                                              },
                                              {title:'Dateispezifische Metadaten', height:80 ,hidden:isPRODUCT},
                                              {title:'Workflow', height:80 },
 
                                              {title:'Verwendungsnachweis', height:80},
                                              {title:'&Auml;nderungsinfo', height:80}
                                              ]
                           	       },
                           	       {
                                   	   title: extVia.locales.attributes+extVia.editor.baseEditor.statics.addTabChooser('attributes'),      
 
                                       moreBtnCfg:{
	                                       dscr:'Sichten', 
	                                       menuCfg:{ 
	                                            defaults:{
	                                             listeners:{afterrender: function() {this.addHeaderCls('xty_accordionHd');}},
	                                             margins:'1 1 1 1'
	                                            },
	                                            items:[  
	                                             {xtype:'form', title:'Anzeige erweitern ', cls:'xty_accordionHd', iconCls:'xty_icon xty_iconInformation', 
	                                              defaults:{
	                                               style:'padding-left:4px;'
	                                              },
	                                              items:[
	                                              { xtype:'checkbox', boxLabel:'�nderungsinformation'},
	                                              { xtype:'checkbox', boxLabel:'Vererbung'}
	                                              ] 
	                                              },
	                                              {xtype:'form', title:'Sichten ', cls:'xty_accordionHd', iconCls:'xty_pgtoolbar-databaseviews', bodyBorder:false, items:[
						                          {
						                              xtype : 'boundlist',itemId:'dbViews',
	                                                  style:'border:0px; bXorder-color:#fff;',
						                              queryMode : 'local',
						                              displayField : 'dscr',
	                                                  width:320,
	                                                  height:280,
	                                                  store: extVia.stores.initDBViewsStore({}),
						                              itemTpl : '<div style="width:100%;"><span style="">' + '&nbsp; {dscr}' + '</span><span style="color:#888"> {count}</span></div>',
						                              autoScroll : true
						                            } 
	                                              ]
	                                              }
	                                            ]
	                                          }
                                          },  
                                                                
                                       stateful:true,
                                       itemId:'attributesTab',
                                       stateId:editorMainTabItemId+'-attributesTab',
                                       items:[
                                         {  
            					                     itemId:'subItemViewPanel',     
            					                     xtype:'fakepanel',
            					                     height:1800,
                               
                                         miniToolbar:Ext.create('Ext.menu.Menu', {style:'background-color:transparent;',bodyStyle:'background-color:transparent;',
                                         
                                          items:[{ border:false,xtype:'fakepanel', height:24,width:260,fake:'../img/fakes/prat/minitoolbar.png'}]
                                         
                                         }),
                               
					                     fake:'../img/fakes/prat/pratTable_6_plain.png',  

                                         html : attributesFakeHTML,
                                         listeners:{  
                                             'afterrender':function(){
//                                                  Ext.create('Ext.tip.ToolTip', {
//                                                   target: 'attributesFakeTABLE-bin',
//                                                   height:24,
//                                                   html:'<img width:"200px" src="../img/fakes/prat/minitoolbar.png" />',
//                                                   //trackMouse: true
//                                                  });
                                              }                                                 
                                          },
                               
                                         margin:'24 24 24 24',
                                         skip:function(cfg){
                                          if (cfg && cfg.dscr){
                                            var editorPanel = extVia.regApp.centerTabPan.getActiveTab();
                                            editorPanel.getApplicationBar().setSubEpobDscr('<i>'+cfg.dscr+'</i>');
                                          }
                                          if (!this.previewCnt){
                                            this.previewCnt = 1;
                                          }
                                          if (this.previewCnt >6){this.previewCnt = 0;}
                                          this.previewCnt++;
                                          this.setFake('../img/fakes/prat/pratTable_'+this.previewCnt+'.png');
                                          }
                                         }
                                       
                                       ]
                           	       },
                           	       {
                                   	   title: extVia.locales.elements, hidden:isCONTENT,
                                       stateful:true,
                                       itemId:'elementsTab',
                                       stateId:editorMainTabItemId+'-elementsTab',
                                       
                                       
                                       grids : ['allTypesGrid', 'imagesGrid', 'textsGrid', 'documentsGrid', 'prodtabGrid', 'edtabGrid', 'graphicsGrid', 'audiosGrid', 'videosGrid'],
                                       gridsSortchange:function(ct, column, direction){
                                         var gix;
                                         
                                         var sorterFn = function(v1, v2){
                                                v1 = v1.get(column.dataIndex);
                                                v2 = v2.get(column.dataIndex);
                                                return v1.length > v2.length ? 1 : (v1.length < v2.length ? -1 : 0);
                                         };
                                         
                                         
                                         for (gix = 0; gix <this.grids.length; gix++){
                                            var elemGrid = this.getComponent(this.grids[gix]);
                                            var elemgridStore  = elemGrid.getStore(); 
                                            var field = column.dataIndex;
		                                    elemgridStore.sort({
		                                        property: column.dataIndex,
		                                        direction: direction,
                                                sorterFn: sorterFn
//		                                        ,sorterFn: function(v1, v2){
//		                                            v1 = v1.get(field);
//		                                            v2 = v2.get(field);
//		                                            return v1.length > v2.length ? 1 : (v1.length < v2.length ? -1 : 0);
//		                                        }
		                                    });
                                            
                                          }
                                        },
                                        gridsGroupByThisField: function(){
                                         var gix;
                                         for (gix = 0; gix <this.grids.length; gix++){
                                            extVia.notify(' gridsGroupByThisField '+this.grids[gix]); 
                                          }
                                        },    
                                        gridsShowinGroups: function(){
                                         var gix;
                                         for (gix = 0; gix <this.grids.length; gix++){
                                            extVia.notify(' gridsShowinGroups '+this.grids[gix]); 
                                          }
                                        },                                        
                                        
                                        
                                        
                                        gridsSelectAllChange: function(evt, target){
                                         var gix;
                                         for (gix = 0; gix <this.grids.length; gix++){
                                            var elemGrid = this.getComponent(this.grids[gix]);
                                            var elemGridSelModel = elemGrid.getSelectionModel();
                                            var checkThem = target.checked;
	                                        try{
	                                           if (checkThem){elemGridSelModel.selectAll();}
	                                           else{elemGridSelModel.deselectAll();}
	                                           
	                                           var checkbxSelmodelFakeArr = Ext.query('#'+elemGrid.id+' .xty_checkbx-selmodel-fake');
	                                           var checkbxSelmodelFake =  checkbxSelmodelFakeArr[0];
	                                           checkbxSelmodelFake = Ext.get(checkbxSelmodelFake);
	                                           checkbxSelmodelFake.dom.checked = checkThem;
	                                          }
	                                          catch(selEx){
	                                           //extVia.notify(elementsGrids[gix]+' is collapsed <br>'+selEx.toString());
	                                         }
                                           
                                             var qtip = checkThem?'Alle Elemente deselektieren':'Alle Elemente selektieren';
                                             target.setAttribute('data-qtip', qtip );
                                           
                                           }
                                        },

 
                                       
                                       listeners:{ // no default listeners with moreBtn + badge functions
                                        show:function(panel){ 
                                          var editorPanel = panel.ownerCt.ownerCt; 
                                          var sawButton = editorPanel.getApplicationBar().pagetoolbar.getComponent('saw');
                                          sawButton.show();
                                        },
                                        hide:function(panel){ 
                                          var editorPanel = panel.ownerCt.ownerCt; 
                                          var sawButton = editorPanel.getApplicationBar().pagetoolbar.getComponent('saw');
                                          sawButton.hide();
                                          
                                          var columnsHeaderOnlyPanelEl  = Ext.get('columnsHeaderOnlyPanel');
                                          columnsHeaderOnlyPanelEl.setVisible(false);
                                        },

                                        afterrender: function(panel) {         
////                                           function getElementStateInScrolling(testEl, containerEl){
////	                                           var containerTop = containerEl.getScroll().top;
////	                                           var containerY = containerEl.getY();
////	                                           var containerBottom = containerTop + containerEl.getHeight();
////	                                           var elemTop = testEl.getY()-containerY +24 +26; // 24 margin 26 panelheader
////	                                           var elemBottom = elemTop + testEl.getHeight();
////	                                           //alert ('getElementStateInScrolling containerY '+containerY+'elemBottom '+elemBottom+' containerBottom'+containerBottom+' elemTop '+elemTop+' containerTop '+containerTop)
////	                                           return ((elemBottom <= containerBottom) && (elemTop >= containerTop));
////                                          };
//                                          
//                                          var getElementStateInScrollingTask = new Ext.util.DelayedTask(function(){
//                                             var showColumnsHeaderOnlyPanel = false;
//
////											var productElementsGrid = Ext.get( 'productElements-grid');
////                                            var columnheadercontainerId = productElementsGrid.dom.firstChild.nextSibling.id;
////                                            var columnheadercontainer = Ext.get( columnheadercontainerId); // 'headercontainer-1436';
////                                            var elementStateInScrolling = getElementStateInScrolling(columnheadercontainer, scrollPanelEl);
////                                            showColumnsHeaderOnlyPanel = !elementStateInScrolling;
//
//                                             var containerScrollTop = scrollPanelEl.getScroll().top;
//                                             //var containerY = scrollPanelEl.getY(); 
//                                             
//                                             //extVia.notify ('containerTop '+containerTop +' containerY '+containerY)
//                                             
//                                             if (containerScrollTop>48){showColumnsHeaderOnlyPanel=true;}
//                                             
//                                            //  var columnsHeaderOnlyPanel = panel.getComponent('columnsHeaderOnlyPanel');
//                                              
//                                              
//                                            var columnsHeaderOnlyPanelEl  = Ext.get('columnsHeaderOnlyPanel');
//                                            columnsHeaderOnlyPanelEl.setVisible(showColumnsHeaderOnlyPanel);
// 
//                                              //alert("columnsHeaderOnlyPanel "+columnsHeaderOnlyPanel)
//                                             // Ext.get(columnsHeaderOnlyPanel.id).setTop(containerTop-1);
//                                              //extVia.notify ('elementStateInScrolling '+elementStateInScrolling)
//									      });

                                          
                                          
                                          if (!panel.columnsHeaderOnlyGridInited){
                                            panel.columnsHeaderOnlyGridInited = true;
                                          }


                                          var columnsHeaderOnlyGrid = 
                                          Ext.create('Ext.grid.Panel', { 
                                             //xtype:'grid', 
                                             //hidden:true,
                                             renderTo:'columnsHeaderOnlyPanel',
                                             //title:'columnsHeaderOnlyGrid', 
                                             collapsed:false,
                                             listenerXs:null,
                                             tools:null,
                                             cls:'xty_columnsHeaderOnlyGrid',
                                             preventHeader:true,
                                             border:false,
                                             itemId:'columnsHeaderOnlyGrid', 
                                             mxargin:'0 24 36 24' ,
                                             margin:'0 0 0 24' ,
                                             //height:22,
                                             //selModel: Ext.create('Ext.selection.CheckboxModel'),
                                             features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})],
                                             columns: {items:[
                                                  //{header: '<div class="xty_checkbx-selmodel-fake-bin"><input class="xty_checkbx-selmodel-fake" style="height:10px; marsgin-top:3px; margin-left:-1px;" type="checkbox"></div>',  sortable:false,  menuDisabled : true,  width:24},
                                                  {header: 'Ansicht', headerDscr: 'Ansicht',  dataIndex: 'preview', width:66},
                                                  {header: 'Textinhalt', headerDscr: 'Textinhalt',  dataIndex: 'preview', width:266, hidden:true},
                                                  {header: '<div class="xty_icon xty_iconCrossref" style="height:18px;" title="Zuordnung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' , headerDscr: 'Zuordnung',  dataIndex: 'Inheritance', width:48},
                                                  {header: '<div class="xty_epobHierarchies" style="height:18px;" title="Vererbung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>', headerDscr: 'Vererbung',  dataIndex: 'Inheritance', width:48},
                                                  {header: 'Typ',  headerDscr: 'Typ',  dataIndex: 'epobType', width: 36},
                                                  {header: 'Name', headerDscr: 'Name', dataIndex: 'name', width:280},
                                                  {header: 'Pfad', headerDscr: 'Pfad', dataIndex: 'path',  width:320},
                                                  {header: 'EPIM-Id',headerDscr: 'EPIM-Id',  dataIndex: 'epobId', hidden:true}
                                                  ],
                                                  listeners:{
                                                   menucreate: function( ct, menu ){
                                                    var groupbyfieldMenuItem = menu.items.get(5);
//                                                    groupbyfieldMenuItem.handler = function (){
//		                                                var centerTabPanel = extVia.regApp.myRaster.getCenterTabPanel();
//		                                                var elementsTab = centerTabPanel.getActiveTab().getComponent('editorSubTabsPanel').getComponent('elementsTab');
//		                                                elementsTab.gridsGroupByThisField(ct);                 
//                                                    };
                                                    
                                                    groupbyfieldMenuItem.setText('Alle nach diesem Feld gruppieren ');
                                                    var showingroupsMenuItem = menu.items.get(6);
//                                                    showingroupsMenuItem.handler = function (){
//		                                                var centerTabPanel = extVia.regApp.myRaster.getCenterTabPanel();
//		                                                var elementsTab = centerTabPanel.getActiveTab().getComponent('editorSubTabsPanel').getComponent('elementsTab');
//		                                                elementsTab.gridsShowinGroups(ct);
//                                                    };
                                                    showingroupsMenuItem.setText('Alle in Gruppen anzeigen ');
                                                   }
                                                  }
                                             },
                                             listeners:{
                                              sortchange:function(ct, column, direction){
                                                var centerTabPanel = extVia.regApp.myRaster.getCenterTabPanel();
                                                var elementsTab = centerTabPanel.getActiveTab().getComponent('editorSubTabsPanel').getComponent('elementsTab');
                                                elementsTab.gridsSortchange(ct, column, direction);
                                                }
                                             }     
                                           });

                                          
                                          var columnsHeaderOnlyCheckboxArr = Ext.query('#columnsHeaderOnlyPanel .xty_column-header-all-switch');
                                          if (columnsHeaderOnlyCheckboxArr){
                                            var columnsHeaderOnlyCheckbox = Ext.get (columnsHeaderOnlyCheckboxArr[0]);
                                            columnsHeaderOnlyCheckbox.on('click', 
                                              function(evt, target){ 
                                                var centerTabPanel = extVia.regApp.myRaster.getCenterTabPanel();
                                                var elementsTab = centerTabPanel.getActiveTab().getComponent('editorSubTabsPanel').getComponent('elementsTab');
                                                elementsTab.gridsSelectAllChange(evt, target);  
                                              }
                                            ); 
                                          }
        
                                          
                                          
                                          
                                          var scrollPanelEl = Ext.get(panel.id+'-body');
                                          scrollPanelEl.on('scroll', function() {
                                             var showColumnsHeaderOnlyPanel = false;
                                             var containerScrollTop = scrollPanelEl.getScroll().top;
                                             if (containerScrollTop>48){showColumnsHeaderOnlyPanel=true;}
                                             var columnsHeaderOnlyPanelEl  = Ext.get('columnsHeaderOnlyPanel');
                                             columnsHeaderOnlyPanelEl.setVisible(showColumnsHeaderOnlyPanel);
                                            
                                          });  
                                        }                                       
                                       },
                                       
                                       
                                       defaults:{
                                          //collapsed:true, 
                                          width:elementsGridsWidth, //1000, 
                                          margin:'0 24 -1 24' , 
                                          //height: mainContentPanelHeight-148 , 
                                          tools:elementsTabGridTools, 
                                          overCls:'xty_elements-grid-over',
                                          cls:'xty_elements-grid', 
                                          //html: "<img  src='../img/fakes/elements/elementsTab-audios.png'/>",
                                          
                                          xtype:'grid',
                                          multiSelect : true,
                                          store: Ext.create('Ext.data.Store', {
                                                      //storeId:'elementsGridStore_type_',
                                                      allowDeselect:true,
                                                      fields: ['Inheritance','epobType','name', 'id', 'productnumber'],
                                                      data : [
                                                      {inheritance:'*', epobType:'Image',name:'SchwenkRahmen',id:'123',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'Text',name:'Schwenk',id:'456',productnumber:'56xB'},
                                                      {inheritance:'*/-', epobType:'Audio',name:'RahmensSchwenk',id:'789',productnumber:'56xC'},
                                                      {inheritance:'-', epobType:'Document',name:'Schwenkk Zenk',id:'101123',productnumber:'56xD'},
                                                      {inheritance:'-', epobType:'Graphic',name:'Benk',id:'1785623',productnumber:'56xE'},
                                                      {inheritance:'*', epobType:'Video',name:'SchwenkRahmen B',id:'123b',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'EdTable',name:'Schwenk B',id:'456b',productnumber:'56xB'},
                                                      {inheritance:'*/-', epobType:'Prodtable',name:'RahmensSchwenk B',id:'789b',productnumber:'56xC'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'Schwenkk Zenk B',id:'101123b',productnumber:'56xD'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'Benk B',id:'1785623',productnumber:'56xE'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'SchwenkRahmen C',id:'123c',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'Schwenk C',id:'456c',productnumber:'56xB'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'RahmensSchwenk C',id:'789c',productnumber:'56xC'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'Schwenkk Zenk C',id:'101123c',productnumber:'56xD'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'Benk C',id:'1785623c',productnumber:'56xE'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'SchwenkRahmen D',id:'123d',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'Schwenk D',id:'456d',productnumber:'56xB'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'RahmensSchwenk D',id:'789d',productnumber:'56xC'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'Schwenkk Zenk D',id:'101123d',productnumber:'56xD'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'Benk D',id:'1785623d',productnumber:'56xE'}
                                                      ]
                                                 }),
                                          
                                             groupByThisField: function(){},    
                                             
                                             sortBy: function(){},    
                                                 
                                             selectAll: function(){}, 
                                                 
                                                //selModel: Ext.create('Ext.selection.CheckboxModel'),
                                                 
                                                 
                                              columns:{
                                                  listeners:{
                                                    headerclick:function( ct, column, evt, targetEl ){
                                                     if (column.itemId.indexOf('checkboxSelmodel')>-1) {
                                                      // alert('checkboxSelmodel')
                                                       var elemGrid = ct.ownerCt;
	                                                   var elemGridSelModel = elemGrid.getSelectionModel();
                                                       var checkThem = targetEl.checked;
	                                                   if (checkThem){elemGridSelModel.selectAll();}
	                                                   else{elemGridSelModel.deselectAll();}    
                                                     }
                                                     
                                                   }
                                                 },
                                                 
                                                 
                                                items: [
                                                {
                                                
                                              //  header:'<div class="x-column-header-inner" id="gridcolumn-'+getSameIdMultipleTimes(2)+'-titleContainer" style="height: 22px; padding-top: 0px;"><span class="x-column-header-text" id="gridcolumn-'+getSameIdMultipleTimes(2)+'-textEl">&nbsp;</span></div>', 
                                                
                                              itemId:'checkboxSelmodel',  
                                              header:
                                              '<div itemId="gridcolumn-chkbx-fake-'+Ext.id()+'" class="x-column-header x-columXXn-header-checkbox  x-box-item x-column-header  x-column-header-align-left x-column-header-first" ' +
				                                 'style="width: 24px; margin: 0px; height: 23px; left: 0px; top: 0px;border-bottom:1px solid #C5C5C5;" role="presentation">' +
				                                '<div class="x-column-header-inner" itemId="gridcolumn-chkbx-fake-titleContainer-'+Ext.id()+'" style="height: 22px; padding-top: 0px;">' + 
				                               '<input style="margin-top:4px; margin-left:-1px;" class="xty_checkbx-selmodel-fake" itemId="chkbx-fake-'+Ext.id()+'" type="checkbox"/>'+
				                              '</div>'+
                                              '</div>',
                                                
                                                
                                                
                                                menuDisabled:true, sortable:false,
                                                width:24,
                                                
                                                 renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                  metaData.tdCls=' x-grid-cell-special ';
                                                  var html ='<div style=" text-align: left !important; margin-left:-4px;" class="x-grid-cell-inner x-unselectable" unselectable="on" >' +
                                                    '<div class="x-grid-row-checker" id="'+Ext.id()+'">&nbsp;</div>' +
                                                    '</div>';
                                                 return html;
                                                 }
                                                
                                                
                                                },
                                                 
                                                 
                                                  {header: 'Ansicht', headerDscr: 'Ansicht',  dataIndex: 'preview', width:66,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      return '<div class="xty_preview-cell" style="width:56px; height:56px; padxxding:4px 0px 4px 0px; border:1px solid #ccc ;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                      }
                                                  },
 
                                                  
                                                    
                                                    { heasder:  'Zuordnung', header:  '<div class="xty_icon xty_iconCrossref" style="height:18px;" title="Zuordnung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' , headerDscr: 'Zuordnung',  dataIndex: 'Inheritance', width:48,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      var isInherited = value.indexOf('*')>-1;
                                                      
                                                      return '<div class="xty_icon xty_icon'+ ((isInherited)?'AssignedAbove':'Here')+'" title="'+ ((isInherited) ? 'Zuordnung ererbt' :'hier zugeordnet ')+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                     }
                                                    },
                                                  
                                                  
                                                    {header_1: 'Vererbung',  header:  '<div class="xty_epobHierarchies" style="height:18px;" title="Vererbung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' ,headerDscr: 'Vererbung',  dataIndex: 'Inheritance', width:48,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      var isInherited = value.indexOf('*')>-1;
 
                                                      var noFurtherInheritance = false;
                                                      if (isInherited){
                                                        noFurtherInheritance =   value.indexOf('*/-')>-1;
                                                      }

                                                      return '<div class="xty_icon xty_icon'+ ((isInherited)? (noFurtherInheritance?'NoFurtherInheritance':'Inherited') :'NotInherited')+'" title="'+ ((isInherited) ? (noFurtherInheritance?'Weitervererbung unterbrochen ':'Vererbung aktiv') :'Vererbung unterbrochen')+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                     }
                                                    },
                                                  
                                                  {header: 'Typ',  headerDscr: 'Typ',  dataIndex: 'epobType', width: 36,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      var html=
                                                        '<div class="xty_epob'+value+'" style="height:18px;" title="'+value+'"></div>';
                                                        //+'<input type="hidden" name="groupTplRecordAccess" data-epobtype="'+record.get('assignEpobType')+'"  data-recordid="'+record.getId()+'"  data-recordix="'+rowIndex+'" />';
                                                      return html;
                                                    }
                                                  },
                                                  {header: 'Name', headerDscr: 'Name', dataIndex: 'name', width:280},
                                                  {header: 'Pfad', headerDscr: 'Pfad', dataIndex: 'path',  width:320},
                                                  {header: 'EPIM-Id',headerDscr: 'EPIM-Id',  dataIndex: 'epobId', hidden:true}
                                                  ]
                                                 },
                                          
                                          
                                          
                                          listeners: {
				                              afterrender: function(panel) {
				                                panel.header.el.on('click', function() {
				                                  if (panel.collapsed) { panel.expand();}
				                                  else {panel.collapse();}                      
				                                });
				                              }
				                           }  
                                       },
                                       items:[
                                            {
                                                xtype:'grid',
                                                overCls:'xty_elements-grid-over',
                                                id:'productElements-grid',
                                                cls:'xty_elements-grid',
                                                margin:'24 24 -1 24' , 
                                                collapsed:false,
                                                title:'&nbsp;&nbsp;alle Typen',
                                                itemId:'allTypesGrid', 
                                                menu:{
                                                 items:{text:'�rkg�we4r'}
                                                },
                                                 getGroupedColumn:function(){                            
						                           var columnFieldName = this.features[0].getGroupField();
						                           var column; 
                                                   var i;
						                           for ( i = 0; i < this.columns.length; i++){
						                            if (columnFieldName ===  this.columns[i].dataIndex){
						                              column = this.columns[i];
						                            } 
						                           }  
						                           return  column ;
						                          },
						                          
						                          getGroupedFieldName:function(){                            
						                           var columnFieldName = this.getGroupedColumn().headerDscr;
						                           return  columnFieldName ;
						                          },
                                      
                                                 getGroupedFieldRecordIxs:function(rows){  
						                            var column  = this.getGroupedColumn();
						                            var columnId = column.id;
						                            var groupedFieldRecordIxs =[];
						                            
						                            var i;
						                            for (i=0; i < rows.length;i++){
						                               var cellStr = Ext.encode(rows[i][columnId]);
						                               var recordIxIx = cellStr.indexOf('data-recordix');
						                               var recordIx = cellStr.substring(recordIxIx+16, cellStr.length);
						                               recordIx = recordIx.substring(0, recordIx.indexOf('\\'));
						                               groupedFieldRecordIxs.push(recordIx);
						                            }
						                            return  groupedFieldRecordIxs;
						                          },
					                                                
                                                
                                                features: [Ext.create('Ext.grid.feature.Grouping',{
                                                  groupHeaderTpl: '{[Ext.getCmp("productElements-grid").getGroupedFieldName()]} : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
                                                  //groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
                                                })],
                                                
                                                store: Ext.create('Ext.data.Store', {
                                                storeId:'accessoriesStore',
                                                allowDeselect:true,

                                                //              0             1        2         3       4         5         6            7                8                       9                     10                 11               12         13         
                                                fields: ['Inheritance','epobType','productNr','name','position','path', 'parentId','parentProductNr',' parentProductId ','parentProductgroupID','parentProductgroupName', 'newposition', 'checked', 'epobTypeId'],
                                                
                                                //data : extVia.editor.baseEditor.dummies.relations,
                                                data: extVia.editor.baseEditor.dummies.getRelationsAsElements(),
						                          proxy: {
						                              type: 'memory',
						                              reader: 'array'
						                          }
						                         }),
	                                            multiSelect : true,

	                                            listeners: {
                                                  afterrender: function(panel) {
			                                        panel.header.el.on('click', function() {
			                                          if (panel.collapsed) {
	                                                    panel.expand();
	                                                    if (panel.getHeight()<40){panel.setHeight(null);panel.expand();}
	                                                  }
			                                          else {panel.collapse();}                      
			                                        });
			                                      },
                                                
	                                             itemdblclick: function ( view, record, item, index, e, eOpts ){
                                                
                                                   var clickedCell = e.target.parentNode;
                                                   var clipboardText ='';
                                                   
                                                   if (clickedCell && clickedCell.className){
                                                     if (clickedCell.className.indexOf('xty_grid-name-cell')>-1){
                                                       clipboardText = record.get('name'); 
                                                     }
                                                     else if (clickedCell.className.indexOf('xty_grid-path-cell')>-1){
                                                       clipboardText = record.get('path'); 
                                                     }                                                     
                                                   }
                                                  if (e.hasModifier()){
                                                    var textEl =  Ext.get(e.target);
                                                    textEl.selectable(); 
                                                    
                                                    
//                                                    var textareaId = Ext.id();
//                                                    Ext.create('Ext.panel.Panel',{
//													    id      : 'clipboard-Panel',
//                                                        style:'position:absolute; top:100px;left:500px; z-index: 999999',
//													    renderTo   : Ext.getBody(),
//                                                        html : '<textarea id ="'+textareaId+'" rows=3 style="width:300px;height:60px;">'+clipboardText+'</textarea>'
//													});
//                                                    Ext.get(textareaId).dom.select();
//                                                    
//                                                    
//                                                    
//                                                     try {
//													    var successful = document.execCommand('copy');
//													    var msg = successful ? 'successful' : 'unsuccessful';
//													    //alert('Copying text command was ' + msg);
//													  } catch (err) {
//													    //alert('Oops, unable to copy');
//													  }
//                                                    
//                            
//                                                      var tip = Ext.create('Ext.tip.ToolTip',{
//											            target: e.target,
//											            title: 'Wanna to Copy?',
//											            html: clipboardText,
//											            autoHide : false
//											            ///closable : true,
//											            //draggable: true
//											         });
//                                                     var pos = e.getXY();
//                                                     //tip.showAt(pos[0], pos[1]);
//                                                     //tip.showAt(pos);
//                                                      
//														textEl.highlight("3399FF", {  
//														    from: {
//														        backgroundColor: '#3399FF' ,
//                                                                color: '#FFFFFF' 
//														    },
//														    to: {
//														        backgroundColor: '#FFFFFF' ,
//														        color: '#000000'
//														    },
//															duration: 8000
//														});

                                                    
                                                    }
	                                             },
                                               
                                                 itemcontextmenu: function  ( view, record, item, index, evt, eOpts ){
                                                  evt.preventDefault();

                                                  var selectionModel = view.getSelectionModel();
                                                  selectionModel.select(record); 
                                                  
                                                  var epobType = record.get('epobType'); 
                                                  var epobTypeId = record.get('epobTypeId'); 
                                                  
                                                  var isTable = epobType.indexOf('Table')>-1;
                                                  var isText = epobType.indexOf('Text')>-1;
                                                  
                                                  var epobTypeDscr =  extVia.ui.page.strings.epobs['Epob_'+epobTypeId+'_S'] ;
                                                  var inheritance = record.get('Inheritance'); 
                                                
                                                  var isInherited = inheritance.indexOf('*')>-1;
                                                  var furtherInheritance = false;
                                                  if (isInherited){
                                                    furtherInheritance =  inheritance.indexOf('*/-')>-1;
                                                  }
                                                  
                                                var action = '';
                                                
                                                var menuItemHandler = function(item){
										         
                                                 var name = record.get('name');
                                                 var width, height, html, panel;
                                                  if (item.itemId==='showText' || item.itemId==='editText'){

                                                    if (item.itemId==='editText'){
                                                      height =  560;
                                                      width = 482;
                                                      html = '<img  width="468" height="523" id="texteditor-wrap" src="../img/fakes/editor/textEditorApplet-body.png"/>';
                                                      panel = {  hesight: height-50, autoScsroll:true, html: html };
                                                    }
                                                    else{
                                                      height =  600;
                                                      width = 440;
                                                      html = extVia.versionsProto.textsText;
                                                      panel = {  height: height-50,  autoScroll:true,  html: html };
                                                    }
                                                    
                                                    
                                                    //action = '<div class="'+item.iconCls+'" style="padding-left:18px;width:100%; background-repeat:no-repeat;"> '+item.text+'</div>';
                                                    action = '<div class="'+item.iconCls+'" data-qtip="'+item.text+'" style="padding-left:18px;width:100%; background-repeat:no-repeat;"> &nbsp;'+name+' <span style="font-weight:normal;">&nbsp;(de)</span></div>';
                                                    Ext.create('Ext.window.Window', {
                                                        title: action,
                                                        cls:'xty_adjustInheritance-dialog',
                                                        //title: action + ': '+name+' (de)',
                                                        height: height,
                                                        width: width,
                                                        border:false,
                                                        items: [
//                                                        {
//                                                         border:false, 
//                                                         html:  '<div class="xty_dialog-mainInstr" style="padding:6px 6px 6px 12px;">'+name+' <span class="xty_epobdscr" style="font-style:italic; font-weight:normal"> (de)'+'</span></div>' 
//                                                        },
                                                        panel
                                                        ]
                                                        }).showAt(1200,20);
                                                  }
                                                  
                                                  
                                                  else if (item.itemId==='adjustInheritance'){
                                                    
                                                   var centerPanel = extVia.regApp.myRaster.getCenter();
                                                   // getPosition( [local] ) : Number[]
                                                   var posX = centerPanel.getWidth()-160; 
                                                    
                                                     height =  500;
                                                     width = 500;
                                                     var quickviewHtml = '<img style="" width="400" height="142" id="texteditor-wrap" src="../img/fakes/quickviews/elements-quickview-teaser-noborder.png"/>';                                                   
                                                     var epobTypy = record.get('epobType');
                                                     
                                                     var epobTyp = record.get('epobType');
                                                    
                                                     var versionA = epobTypy!=='Graphic'&& epobTypy==='Audio';
                                                     var versionB = epobTypy!=='Graphic';
                                                     var versionC = epobTypy==='Graphic';

                                                    
                                                    
                                                    var epobArtikel ='des'; // Bild Audio Video Document
                                                    var epobAppendix ='s'; // Bild Audio Video Document
                                                    if (epobTypy==='Graphic' || epobTypy.indexOf('Table')>-1 ){
                                                      epobArtikel ='der';
                                                      epobAppendix ='';
                                                    }
                                                    else if (epobTypy==='Text' || epobTypy==='Document' || epobTypy==='Image'){
                                                      epobAppendix ='es';
                                                      //epobArtikel ='den';
                                                    }
                                                    var epobTypeGenetiv =  epobArtikel+' '+ extVia.ui.page.strings.epobs['Epob_'+record.get('epobTypeId')+'_S']+epobAppendix;
                                                    if (epobTyp.indexOf('EdTable')>-1 ){
                                                      epobTypeGenetiv = epobTypeGenetiv.replace(/elle/,'ellen');
                                                    }
                                                    
                                                    
                                                    
                                                    var adjustInheritanceGrid = {
                                                      //title:'Produktvarianten von '+epob.dscr,
                                                      border:false,
                                                      xtype:'grid',
                                                      itemId:'contentGrid',
                                                      cls:'xty_adjustInheritance-grid',
                                                      refresh:function(){
                                                       extVia.notify('contentGrid refresh');
                                                      },
                                                      height: 440,
                                                      
                                                      selModel: versionA ? Ext.create('Ext.selection.CheckboxModel'):null,
                                                      
                                                      store: Ext.create('Ext.data.Store', {
                                                      fields: ['inheritance','epobType','name', 'id', 'productnumber'],
                                                      data : [
                                                      {inheritance:'*', epobType:'ProductVariant',name:'SchwenkRahmen',id:'123',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'Schwenk',id:'456',productnumber:'56xB'},
                                                      {inheritance:'*/-', epobType:'ProductVariant',name:'RahmensSchwenk',id:'789',productnumber:'56xC'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Schwenkk Zenk',id:'101123',productnumber:'56xD'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Benk',id:'1785623',productnumber:'56xE'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'SchwenkRahmen B',id:'123b',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'Schwenk B',id:'456b',productnumber:'56xB'},
                                                      {inheritance:'*/-', epobType:'ProductVariant',name:'RahmensSchwenk B',id:'789b',productnumber:'56xC'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Schwenkk Zenk B',id:'101123b',productnumber:'56xD'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Benk B',id:'1785623',productnumber:'56xE'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'SchwenkRahmen C',id:'123c',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'Schwenk C',id:'456c',productnumber:'56xB'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'RahmensSchwenk C',id:'789c',productnumber:'56xC'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Schwenkk Zenk C',id:'101123c',productnumber:'56xD'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Benk C',id:'1785623c',productnumber:'56xE'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'SchwenkRahmen D',id:'123d',productnumber:'56xA'},
                                                      {inheritance:'*', epobType:'ProductVariant',name:'Schwenk D',id:'456d',productnumber:'56xB'},
                                                      {inheritance:'-', epobType:'ProductVariant',name:'RahmensSchwenk D',id:'789d',productnumber:'56xC'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Schwenkk Zenk D',id:'101123d',productnumber:'56xD'},
                                                      {inheritance:'', epobType:'ProductVariant',name:'Benk D',id:'1785623d',productnumber:'56xE'}
                                                      ]
                                                      }),
                                                      
                                                      multiSelect:true,
                                                      getSelectionCount:function(){
                                                         var selModel = this.getSelectionModel() ;
                                                         var selections = selModel.getSelection();
                                                         return selections.length; 
                                                        },
                                                      
                                                       getDirtyCount:function(){
	                                                       var store = this.getStore();
	                                                       var records = store.getRange(); 
	                                                       var dirtyCount = 0;
				                                           var i;
                                                           for(i =0; i < records.length; i++){
				                                               var rec = records[i];
				                                               if(rec.dirty){
				                                                  dirtyCount++;
				                                               }
				                                            }
	                                                       return dirtyCount;
                                                        },
                                                        
                                                        
                                                      columns:{
                                                      listeners:{
                                                        headerclick:function( ct, column, evt, targetEl ){
                                                         if (column.itemId.indexOf('inheritance')>-1) {
                                                          var store = ct.ownerCt.getStore();
                                                          var records = store.getRange(); 
                                                          var inheritanceStatus = column.itemId === 'inheritanceActivate' ?'*':'';
                                                          
                                                          if (column.itemId === 'inheritanceActivate'){inheritanceStatus='*';}
                                                          
                                                          else if (column.itemId === 'inheritanceToggle' || column.itemId === 'inheritanceSwitch'){
                                                            if (column.lastInheritanceStatus && column.lastInheritanceStatus==='*' ){
                                                             inheritanceStatus='';
                                                            }
                                                            else{
                                                             inheritanceStatus='*';
                                                            }
                                                            column.lastInheritanceStatus = inheritanceStatus;
                                                          }
 
                                                          var i;
		                                                  for( i =0; i < records.length; i++){
		                                                     var rec = records[i];
		                                                     rec.set('inheritance',inheritanceStatus);
		                                                  }
                                                         }
                                                       }
                                                          

                                                      },

                                                      items:[ 
	                                                  { header:  '<div class="xty_menu-furtherinheritance" style="margin-left:4px;height:16px;" title="Vererbung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' , hidden: !versionA , dataIndex: 'inheritance', 
	                                                    width: 36,   
                                                       renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
	                                                      var isInherited = value.indexOf('*')>-1;
	                                                      var noFurtherInheritance = false;
	                                                      if (isInherited){
	                                                       // noFurtherInheritance =   value.indexOf('*/-')>-1;
                                                           var v4lint;
	                                                      }
	                                                      return '<div style="margin-left:6px;" class="xty_icon xty_icon'+ ((isInherited)? (noFurtherInheritance?'NoFurtherInheritance':'Inherited') :'NotInherited')+'" title="'+ ((isInherited) ? (noFurtherInheritance?'Weitervererbung unterbrochen ':'Vererbung aktiv') :'Vererbung unterbrochen')+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
	                                                     }
	                                                    },
	
                                                      {header:  'Vererbung', sortable:false, menuDisabled : true, hidsden: !versionB || versionA,
                                                        header22:  '<div class="xty_icon xty_iconActive xxty_menu-inheritance-activate" style="margin-left:4px;height:16px;width:18px;" data-qtip="Vererbungen aktivieren">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
                                                            '</div>' ,  
                                                        dataIndex: 'inheritance',  
                                                        itemId:'inheritanceSwitch',
                                                        width: 66,
                                                        renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  { 
                                                         var isInherited = value.indexOf('*')>-1;
                                                         var checkbxstatus = isInherited?'checked':'';
                                                         var qtip = 'Vererbung'+ (record.dirty?' wird':'' )+ ' '+ (isInherited?'aktiv':'unterbrochen '); 
  
                                                         var checkboxSwitcherHTML =    
                                                         '<span class="xty_form-checkbox-switch-bin" style="margin-left:4px; top:2px;">'+ 
		                                                    '<input type="checkbox"  '+checkbxstatus+' class="xty_form-checkbox-switch xty_inheritance-switch" id="inheritance-checkbox-'+record.get('id')+'" >'+ 
		                                                      '<label id="inheritance-checkbox-label" class=""xty_form-checkbox-switch-label" for="inheritance-checkbox-'+record.get('id')+'"  >'+
		                                                        '<span class="xty_form-checkbox-switch-checked xty_inheritance-switch-checked   checked" ></span>' +
		                                                        '<span class="xty_form-checkbox-switch-unchecked xty_inheritance-switch-unchecked unchecked" ></span>'+ 
		                                                      '</label>'   +
	                                                    '</span>';
   
                                                         return checkboxSwitcherHTML;
                                                         }  
                                                       },                                                      
                                                      
                                                      
                                                      

//                                                       {header1:  'Aktivieren', sortable:false, menuDisabled : true, hidden: !versionB || versionA,
//                                                        header:  '<div class="xty_icon xty_iconActive xxty_menu-inheritance-activate" style="margin-left:4px;height:16px;width:18px;" data-qtip="Vererbungen aktivieren">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
//                                                            //'<input class="xty_inheritance_radio-activate" style="margin-left:4px;" name="inheritance_radio_all" type="radio"/>' +
//                                                            '</div>' ,  
//                                                        dataIndex: 'inheritance',  
//                                                        itemId:'inheritanceActivate',
//                                                        width: 36,
//                                                        renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  { 
//                                                         var isInherited = value.indexOf('*')>-1;
//                                                         var radiostatus = isInherited?'checked':'';
//                                                         var qtip = 'Vererbung'+ (record.dirty?' wird':'' )+ ' '+ (isInherited?'aktiv':'unterbrochen '); 
//                                                         return '<input class="xty_inheritance_radio-activate" style="margin-left:6px;margin-top:2px;" name="inheritance_radio_'+record.get('id')+'" '+radiostatus+' type="radio"/>';}  
//                                                       },
//                                                       {header1:  'Unterbrechen', sortable:false, menuDisabled : true, hidden:!versionB || versionA ,
//                                                        itemId:'inheritanceBreak1',
//                                                        header:  '<div class="xty_icon xty_iconStopped xxty_menu-inheritance-break" style="margin-left:4px;height:16px;width:18px;" data-qtip="Vererbungen unterbrechen">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
//                                                             //'<input onclick="" class="xty_inheritance_radio-break" style="margin-left:4px;" name="inheritance_radio_all" type="radio"/>' +
//                                                             '</div>' ,  
//                                                        dataIndex: 'inheritance',  
//                                                        width:36,
//                                                        renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  {
//                                                          var isInherited = value.indexOf('*')>-1;
//                                                          var radiostatus = isInherited?'':'checked';  
//                                                          var qtip = 'Vererbung'+ (record.dirty?' wird':'' )+ ' '+ (isInherited?'aktiv':'unterbrochen '); 
//                                                          return '<input class="xty_inheritance_radio-break" style="margin-left:6px;margin-top:2px;" name="inheritance_radio_'+record.get('id')+'" '+radiostatus+' type="radio"/>';}
//                                                       },
                                                       
                                                      {  header:  '<div class="xty_icon xty_iconStopped xty_columnheader-inheritance-break " style="margin-left:4px;height:16px;width:18px;" data-qtip="Vererbungen unterbrechen">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' ,
                                                        sortable:false, menuDisabled : true,
                                                        itemId:'inheritanceBreak',
                                                        dataIndex: 'inheritance',  
                                                        width:36,
                                                        renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  {
                                                          var isInherited = value.indexOf('*')>-1;
                                                          var radiostatus = isInherited?'unchecked':'checked';  
                                                          var qtip = 'Vererbung'+ (record.dirty?' wird':'' )+ ' '+ (isInherited?'aktiv':'unterbrochen '); 
                                                          return '<div class="xty_inheritance-break xty_form-radio-icon xty_form-radio-icon-'+radiostatus+'"  '+radiostatus+' style="margin-left:6px;cursor:pointer; width:32px;" data-qtip="'+qtip+'"></div>';
                                                          }
                                                       },
                                                       
                                                      {  header:  '<div class="xty_icon xty_iconActive xty_columnheader-inheritance-activate " style="margin-left:4px;height:16px;width:18px;" data-qtip="Vererbungen unterbrechen">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' ,
                                                        sortable:false, menuDisabled : true,
                                                        itemId:'inheritanceActivate',
                                                        dataIndex: 'inheritance',  
                                                        width:36,
                                                        renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  {
                                                          var isInherited = value.indexOf('*')>-1;
                                                          var radiostatus = isInherited?'checked':'unchecked';  
                                                          var qtip = 'Vererbung'+ (record.dirty?' wird':'' )+ ' '+ (isInherited?'aktiv':'unterbrochen '); 
                                                          return '<div class="xty_inheritance-activate xty_form-radio-icon xty_form-radio-icon-'+radiostatus+'"  '+radiostatus+' style="margin-left:6px;cursor:pointer; width:32px;" data-qtip="'+qtip+'"></div>';
                                                          }
                                                       },
                                                       
                                                       {headser: 'Vererbung', hidden: true, //!versionC,
                                                       sortable:false, menuDisabled : true,
                                                       
                                                        header: '<div class="xty_menu-furtherinheritance" style="margin-left:4px;height:16px;vertical-align:top;" title="Vererbung ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' ,  
                                                        dataIndex: 'inheritance',  width: 42,
                                                        itemId:'inheritanceToggle',
                                                        renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  {
                                                          var isInherited = value.indexOf('*')>-1; 
                                                          var  iconstatus = isInherited?'Active':'Stopped'; 
                                                          var qtip = 'Vererbung'+ (record.dirty?' wird':'' )+ ' '+ (isInherited?'aktiv':'unterbrochen '); 
                                                          return '<div class="xty_inheritance-edit xty_icon xty_icon'+iconstatus+'" style="" data-qtip="'+qtip+'"></div>';
                                                          }
                                                       },
                                                       
                                                   
                                                       {header: 'Typ',  headerDscr: 'Typ',  dataIndex: 'epobType', width: 36,
                                                         renderer:function( value) { return '<div class="xty_epob'+value+'" style="height:18px;" title="'+value+'"></div>';}
                                                       },
                                                       {header:'Produktvariante', dataIndex:'name', flex:1},
                                                       {header:'EPIM-Id', dataIndex:'id', hidden:true},
                                                       {header:'Produktnummer', dataIndex:'productnumber'}
                                                      
                                                      ]
                                                      },
                                                      
                                                      
                                                      
                                                      listeners:{
                                                        itemclick:function(view,record, item, index, evt){
                                                         var targetEl = Ext.get(evt.target);
                                                         var targetCls = targetEl.dom.className;
                                                        
   
                                                         if (targetCls.indexOf('xty_inheritance')>-1){
                                                             var newInheritanceState ='';
                                                             if (targetCls.indexOf('NotInherited')>-1 || targetCls.indexOf('Stopped')>-1 || targetCls.indexOf('activate')>-1 || targetCls.indexOf('broken')>-1 || targetCls.indexOf('Inactive')>-1 || ( targetCls.indexOf('unchecked')>-1 && targetCls.indexOf('break')===-1) ){
                                                              newInheritanceState ='*';
	                                                         }
	                                                         else {
                                                              newInheritanceState ='-';
	                                                         }

	                                                         var selModel = view.getSelectionModel() ;
	                                                         var selections = selModel.getSelection();
                                                           

	                                                         var i;
	                                                         for ( i =0; i< selections.length; i++){
	                                                          var recy = selections[i];
	                                                          recy.set('inheritance',newInheritanceState);
	                                                         }

                                                           var store = view.getStore();
                                                           var records = store.getRange(); 
                                                           var hasDirty = false;
                                                           var di;
														   for(di =0; di < records.length && ! hasDirty; di++){
														       var rec = records[di];
														       if(rec.dirty === true){
														          hasDirty = true;
														       }
														    }
                                                            view.ownerCt.ownerCt.enableButton('adjustInheritance', hasDirty);
                                                         }
                                                        }
                                                      }
                                                    };
                                                    
                                                    var action2 = '<div class="'+item.iconCls+'" style="padding-left:18px;width:100%; background-repeat:no-repeat;"> '+item.text+'</div>';
                                                    var mainInstrEpobDscr = name; //name.substring(0,37) +'...';

                                                    Ext.create('Ext.window.Window', {
                                                        title: action2,
                                                        width: width,
                                                        bordser:false,
                                                        autoScroll:true,
                                                        tools:[{type:'refresh', handler:function(event, toolEl, headerpanel){
                                                          var window  = headerpanel.ownerCt;
                                                          window.getComponent('contentGrid').getStore().load();
                                                          window.enableButton('adjustInheritance', false);
                                                          
                                                        }}],
                                                        
                                                        getDirtyCount:function(){
                                                         return this.getComponent('contentGrid').getDirtyCount();
                                                        },
                                                        
                                                        getSelectionCount:function(){
                                                         return this.getComponent('contentGrid').getSelectionCount();
                                                        },                                                       
                                                        
                                                        
                                                        
                                                        enableButton:function(itemId, enable){
                                                         var butt = this.getDockedComponent(1).getComponent(itemId);
                                                         if (butt){ 
                                                          butt.setDisabled(!enable);
                                                          }
                                                        },
                                                        
                                                        bodyStyle:'background-color:#FFF;', // better by css
                                                        
                                                        items: [


                                                        
                                                          {
                                                            border:false,
                                                            html : 
                                                           //'<div class="xty_dialog-mainInstr" style="padding:6px 6px 6px 12px;" >Wie m�chten Sie die Weitervererbung von '+epobTypy+' <span class="xty_epobdscr" style="font-style:italic; font-weight:normal">'+mainInstrEpobDscr+'</span> anpassen?</div>' +
                                                           //'<div  style="padding:0px 6px 16px 12px;border-bottom:1px solid #99BBE8"  class="xty_dialog-supplementalInstr">W�hlen Sie Produktvarianten und passen Sie die Weitervererbung an.</div>'

//                                                           '<div class="xty_dialog-mainInstr" style="padding:6px 6px 6px 12px;" >W�hlen Sie Produktvarianten und Weitervererbung .</div>' 
//                                                          //  '<div class="xty_dialog-mainInstr" style="padding:6px 6px 6px 12px;" >Aktivieren oder unterbrechen Sie die Weitervererbung von '+epobTypy+' <span class="xty_epobdscr" style="font-style:italic; font-weight:normal">'+mainInstrEpobDscr+'</span></div>' 
//                                                           +'<div  style="padding:0px 6px 16px 12px;border-bottom:1px solid #99BBE8"  class="xty_dialog-supplementalInstr">W�hlen Sie Produktvarianten.</div>'
//                                                        
 
                                                         // '<div class="xty_dialog-mainInstr" style="padding:6px 6px 6px 12px;" >Legen Sie f�r '+epobTypy+' die Vererbung der Produktvarianten fest.</div>' 
                                                          
                                                             '<div class="xty_dialog-mainInstr" style="padding:6px 6px 0px 12px;" >Legen Sie f�r die Produktvarianten die Vererbung von <span style="font-weight:normal;">'+record.get('name')+'</span> fest.</div>'
                                                             
                                                          // '<div class="xty_dialog-mainInstr" style="padding:6px 6px 0px 12px;" >Legen Sie f�r die Produktvarianten die Vererbung <span style="font-weight:normal;">'+epobTypeGenetiv+'</span> fest.</div>'
                                                           
                                                          //   '<div class="xty_dialog-mainInstr" style="padding:6px 6px 0px 12px;" >Legen Sie f�r die Produktvarianten die Vererbung fest.</div>'
                                                          
                                                        //   '<div class="xty_dialog-mainInstr" style="padding:6px 6px 6px 12px;"> Weitervererbung von '+epobTypy+' <span class="xty_epobdscr" style="font-style:italic; font-weight:normal">'+mainInstrEpobDscr+'</span></div>' 
                                                        // +'<div  style="padding:0px 6px 16px 12px;border-bottom:1px solid #99BBE8"  class="xty_dialog-supplementalInstr">Legen Sie die Vererbungen f�r Produktvarianten fest.</div>'
                                                       //  +'<div  style="padding:0px 6px 16px 12px;border-bottom:1px solid #99BBE8"  class="xty_dialog-supplementalInstr">f�r  '+epobTypy+' <span class="xty_epobdscr" style="font-style:italic; font-weight:normal">'+mainInstrEpobDscr+'</span></div>'
                                                        
                                                       
                                                            
                                                          },

                                                       
                                                          {xtype:'fieldcontainer',
                                                           itemId:'quickview-bin',  
                                                           margin:'0 0 0 0',

                                                           layout:'hbox', width:width, // hbox needs width
                                                           style:' background:white;',
                                                          

                                                           items:[
                                                            { margin:'4 4 6 4', hesight:2, itemId:'quickview-wrap', width: width-30, border:false,  
                                                           
                                                            items:[
                                                              {  margin:'1 0 0 0', html: quickviewHtml, bodyStyle:'border-color:#C5C5C5 !important;', border:true, itemId:'quickview'}
                                                              ]
                                                            }
                                                            

                                                            
                                                            

                                                          // { xtype:'button', oversCls:'nix', width:20,  iconCls:'xty_minitool-plus', style:'border:0px; ',bodyStyle:'border:0px; position:absolute !important;z-index:9999; right:112px;top:36px;'}
                                                           ]
                                                          },
                                                          
                                                          { xtype:'button', oversCls:'nix', width:20,  iconCls:'xty_minitool-minus', style:'background:transparent; border:0px; position:absolute;z-index:9999; right:16px;top:47px;',
                                                            enableToggle:true,
                                                            handler:function(button){
                                                             var quickviewbin = button.ownerCt.getComponent('quickview-bin');
                                                             var quickviewwrap = quickviewbin.getComponent('quickview-wrap');
                                                             if (button.pressed){
                                                              quickviewwrap.setHeight(2);
                                                              button.setIconCls('xty_minitool-plus');
                                                             }
                                                             else{
                                                              quickviewwrap.setHeight(148);
                                                              button.setIconCls('xty_minitool-minus');
                                                             }
                                                            }
                                                          
                                                          },
                                                          
                                                          extVia.dialoges.getQuickviewTeaserPanel ({
                                                            containerWidth:width,
                                                            dto:{
                                                              dscr:record.get('name'),
                                                              items:[
                                                              
                                                              { "dscr": "Bild", "name": "previewimage", "type": extVia.ui.dto.ety.IMAGE, "typeName": "IMAGE", 
                                                                          "srcUrl": 'http://'+record.get('previewUrl'), aspectRatio:1.2, width:60, height:50},
                                                              
                                                              
                                                                { "dscr": "Typ", "epobType": "element-epobType",  "type": 123,  "typeName": "BASEITEM",  "value": ' <div class="xty_epobImage" style="widsdth:16px;height:16px;posistion:absolute;right:40px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bild</div>' },  
                                                                          
													            { "dscr": "Name", "name": "element-name",  "type": 123,  "typeName": "BASEITEM",  "value": record.get('name') },   
													            //{ "dscr": "Eigent&uuml;mer", "name": "element-owner",  "type": 123,  "typeName": "BASEITEM",  "value": 'John Bonham' },
													            { "dscr": "Kategorie","name": "element-categories","type": 123,"typeName": "BASEITEM", "value":  'Objekt-Bild � Aussen � WDVS' },
													            { "dscr": "Pfad", "name": "element-path",  "type": 123,  "typeName": "BASEITEM",  "value": 'WDVS' }, 
													            //{ "dscr": "Kommentar", "name": "element-comment", "type": 123, "typeName": "BASEITEM","value":  record.get('comment') },
													            { "dscr": "Letzte �nderung", "name": "element-changedate",  "type": 123,  "typeName": "BASEITEM",  "value": '11.11.2015 / John Bonham' },
													            //{ "dscr": "Erstellt am", "name": "element-creationdate",  "type": 123,  "typeName": "BASEITEM",  "value": '11.07.2008' },
													            //{ "dscr": "Epim-Id" ,"name": "element-id","type": 123, "typeName": "BASEITEM", "value": record.get('epimId')},
                                                                {
														        "dscr": "EPIM-Id",
														        "name": "assign-id",
														        "type": 41,
														        "typeName": "LINK",
														        "href": '../ajsp/Forward.jsp?p_sFromPage=ObjectsTree&p_sPageType=PageMain&p_sType=&p_sObjeId='+ record.get('epimId'),
														        "value": record.get('epimId')
														        },
                                    
                                                               { "dscr": "Typ", "epobType": "element-epobType",  "type": 123, iconCls:'xty_epobImage' , "typeName": "ICON",  "value": ' <div class="xty_epobImage" style="widsdth:16px;height:16px;posistion:absolute;right:40px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bild</div>' }  
                                    
                                    
                                                              ]
                                                            }
                                                            }),
                                                          
                                                          
                                                          
//                                                          {
//                                                           border:false,margin:'0 0 0 0',
//                                                           bodyStyle:'border-bottom:1px solid #C5C5C5 !important;',
//                                                           items:[{html: quickviewHtml, border:false,margin:'0 0 0 0' }]
//                                                          },
                                                          
                                                          
                                                        //   { xtype:'button', oversCls:'nix',   iconCls:'xty_minitool-plus', style:'border:0px;basckground:white;position:absolute;z-index:9999; right:12px;top:36px'},
                                                          
//                                                          {  
//                                                            
//                                                            border:false, html: quickviewHtml , hidden:true,
//                                                            margin:'0 0 0 0',
//                                                            listeners:{
//                                                              afterrender:function(panel){
//                                                              Ext.get(panel.id).on('click', function(){panel.hide();});
//                                                              }
//                                                            }
//                                                          },
                                                          
                                                        adjustInheritanceGrid
                                                        
                                                        ],

                                                        //buttons:[{iconCls:'xty_menu-inheritance-activate',text:'Aktivieren' }, {iconCls:'xty_menu-furtherinheritance-break',text:'Unterbrechen' }, {text:'Abbrechen', hidden:true}],
                                                        
                                                        
                                                        buttons:[
                                                          
                                                              {iconCls:'xty_icon xty_iconActive',text:'Aktivieren' , hidden:!versionA,handler:function(button){extVia.notify({action: 'Vererbungen anpassen'  , mssg:  'Die Vererbung wird auf '+button.ownerCt.ownerCt.getSelectionCount()+' Produktvarianten aktiviert'});}},
                                                              {iconCls:'xty_icon xty_iconStopped',text:'Unterbrechen' , hidden:!versionA,handler:function(button){extVia.notify({action: 'Vererbungen anpassen'  , mssg:  'Die Vererbung wird auf '+button.ownerCt.ownerCt.getSelectionCount()+' Produktvarianten unterbrochen'});}},
                                                              {itemId:'adjustInheritance', text:'Vererbungen anpassen', disabled:true , hidden:versionA ,handler:function(button){extVia.notify({action: 'Vererbungen anpassen'  , mssg:  button.ownerCt.ownerCt.getDirtyCount()+' Produktvarianten werden angepasst'});} }, 
                                                              {text:'Abbrechen', hidden:versionA ,handler:function(button){button.ownerCt.ownerCt.hide();}}]
                                                        
                                                        ,modal:true
                                                        }).showAt(posX);
                                                  }
                                                  
                                                  
                                                  
                                                  else{
                                                  
                                                   var status = 'Jump';
                                                   var mssg = 'Gehe zu <br><br><i>'+ name +'</i>';
                                                   
                                                    
                                                   if (item.itemId.indexOf('inheritance')>-1 || item.itemId.indexOf('removeItem')>-1){
                                                    status = 'Success';
                                                    mssg = 'Erfolgreich';
                                                   }
                                                    
                                                  if ( item.itemId.indexOf('removeItem')>-1){
                                                    view.getStore().removeAt(index);
                                                   }
                                                   
                                                   
                                                    action = item.text;
                                                    var actionArr = item.text.split(' ');
                                                    var actionEpob = actionArr[0];
                                                    var actionVerb = actionArr[1];
                                                    var actionVerbUpper = actionVerb.substring(0,1).toUpperCase() + actionVerb.substring(1,actionVerb.length);
                                                    

											        //var mainInstr =  'M�chten Sie die ausgew�hlten Objekte aus dem Produkt '+actionVerb+'?';
                                                    var mainInstr =  'M&oumlchten Sie die ausgew&auml;hlten '+actionEpob+'en '+actionVerb+'?';

											        var suppInstr =  '1 Bild, 2 Grafiken, 3 Texte, 4 Dokumente, 5 Produktabellen, 6 Redaktionelle Tabellen, 7 Audios, 8 Videos';
                              
                                                    var mixedSel = true;
                                                    if(mixedSel){
                                                      //suppInstr+='<br><br> Sie k�nnen keine ererbten '+actionEpob+'en  '+actionVerb+'.';
                                                      //suppInstr+='<br><br> Ererbte '+actionEpob+'en (12) k�nnen Sie nicht '+actionVerb+'.';
                                                      suppInstr+='<br><br> Ererbte '+actionEpob+'en (12) werden nicht enfernt. ';//+actionVerb+'.';
                                                    } 
                            
                                                    
                                                    //var suppInstr = 'Sie k�nnen 17 von 82 ausgew�hlten Objekte aus dem Produkt '+actionVerb+'?';
                                                    
                                                    
                                                    //var suppInstr = 'Sie k�nnen 102 Bilder, 12 Grafike, 400 Texte, 1 Dokument, 45 Produktabellen, 666 Redaktionelle Tabellen, 10 Audios, 33 Videos  aus dem Produkt '+actionVerb+'?';
                                                    
                                                     //    '88 von 99 ausgew�hlten Elementzuordnungen wurden gel�scht. Sie k�nnen keine ererbten Beziehungen l�schen.'
                              
                                                    //Sie k�nnen keine ererbten Verkn�pfungen l�schen.    
                                
											        var confirmMixedSelectionDialog = Ext.create('widget.window', {  
											            width: extVia.dialoges.dialogDefaultWidth,
											            title: action,
                                                        modal:true,
											            iconCls:'xty_icon xty_iconQuestion',
											            plain: true,
											            items : [ {
											                border : false,
											                minHeight : 200,
											                defaults : {
											                   style : 'margin:0px 10px 0px 14px; padding-bottom:4px;'
											                },
											                items : [ 
											                         extVia.dialoges.getInstructionPanel ({
											                           mainInstr: mainInstr,
											                           suppInstr:suppInstr
											                         })
											                         ]
											              }
											            ],
											            buttons:[{xtype:'tbspacer', width:30},{text: 'Ja', handler:extVia.dialoges.okButtonHandler, executeAction:'DELETE'},{text:'Nein', handler:extVia.dialoges.noButtonHandler},{text:'Abbrechen', handler:extVia.dialoges.cancelButtonHandler}]           
										        }) ;
                                                confirmMixedSelectionDialog.show();
                                                   
                                                   
                                                   
                                                   
                                                   
                                                   
                                                  var action3 = '<div class="xty_icon xty_icon'+status+'" style="padding-left:18px;width:100%"> 36 '+item.text+'<br>l�kj�j</div>';
                                                   extVia.notify({action: action3  , mssg:  mssg});
                                                  }  
                              
										         };

                                                  
                                                  // if (!view[epobType]){
                                                            view[epobType] = Ext.create('Ext.menu.Menu', {
                                                            
                                                            items: [

                                                            { text: 'Anzeigen ', iconCls:'x-tool x-tool-view', itemId:'view', handler: menuItemHandler },
                                                            { text: '&Auml;ndern', iconCls:'x-tool x-tool-edit' , itemId:'edit', handler: menuItemHandler},

                                                            { text: 'Textinhalt anzeigen', iconCls:'xty_menu-showText', hidden: !isText ,itemId:'showText', handler: menuItemHandler},
                                                            { text: 'Textinhalt &auml;ndern' , iconCls:'xty_menu-editText', hidden: !isText ,itemId:'editText', handler: menuItemHandler},
                                                            { text: 'Tabellenvorschau'  , iconCls:'xty_menu-html-preview' , hidden: !isTable,itemId:'html-preview', handler: menuItemHandler},

                                                            { text: 'Zuordnung entfernen' ,iconCls:'x-tool x-tool-removeItem', disabled: isInherited ,itemId:'removeItem',handler: menuItemHandler},

                                                            '-',
                                                            
                                                            { text: 'Vererbung unterbrechen' ,iconCls:'xty_menu-inheritance-break' , disabled : !isInherited, itemId:'inheritance-break',handler: menuItemHandler},
                                                            { text: 'Vererbung aktivieren' ,iconCls:'xty_menu-inheritance-activate', disabled: isInherited , itemId:'inheritance-glue',handler: menuItemHandler},
                                                            
                                                            
                                                            { text: 'Weitervererbung unterbrechen' ,iconCls:'xty_menu-furtherinheritance-break' , disabled : !isInherited,itemId:'furtherinheritance-break', handler: menuItemHandler},
                                                           
                                                            '-', 
                                                            
                                                            { text: 'Weitervererbungen anpassen' ,iconCls:'xty_menu-furtherinheritance' , itemId:'adjustInheritance',disabled: !isInherited ,
                                                             handler: menuItemHandler,
                                                             hxandler: function(){
                                                             
                                                             } 
                                                            }

                                                            ]
														                       });
                                                   
                                                 //  }
                                                  
                                                 view[epobType].showAt(evt.getXY());
                                                 
                                                 //evt.preventDefault();
                                                   
                                                 }
                                               
                                               
	                                            },
    
                                                selModel: Ext.create('Ext.selection.CheckboxModel'),
                                                columns: [

                                                
	                                                {header: 'Ansicht', headerDscr: 'Ansicht',  dataIndex: 'preview', width:66,
	                                                  renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
	                                                    return '<div class="xty_preview-cell" style="width:56px; height:56px; padxxding:4px 0px 4px 0px; border:1px solid #ccc ;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
	                                                    }
	                                                },
 
                                                   {header: 'Textinhalt', headerDscr: 'Textinhalt',  dataIndex: 'preview', width:266, hidden:true,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      
                                                      var epobTypeId = record.get('epobTypeId');
                                                      var isText =  epobTypeId ===  extVia.module.epob.TEXT || epobTypeId=== extVia.module.epob.TEXTVAR;
                                                      
                                                      return '<div class="xty_preview-cell xty_preview-cell-textcontent-wrap" style="width:256px; height:56px;  padxxding:4px 0px 4px 0px; border:1px solid #ccc ; ">' +
                                                        (isText?'<img  width="256" heisght:56px;  id="textcontent-fake" src="../img/fakes/editor/boysareback.png"/>':'') +  
                                                          '</div>';
                                                      }
                                                  },
                                                  
                                                    
                                                    { heasder:  'Zuordnung', header:  '<div class="xty_icon xty_iconCrossref" style="height:18px;" title="Zuordnung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' , headerDscr: 'Zuordnung',  dataIndex: 'Inheritance', width:48,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      var isInherited = value.indexOf('*')>-1;
                                                      
                                                      return '<div class="xty_icon xty_icon'+ ((isInherited)?'AssignedAbove':'Here')+'" title="'+ ((isInherited) ? 'Zuordnung ererbt' :'hier zugeordnet ')+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                     }
                                                    },
                                                  
                                                  
                                                    {header_1: 'Vererbung',  header:  '<div class="xty_epobHierarchies" style="height:18px;" title="Vererbung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' ,headerDscr: 'Vererbung',  dataIndex: 'Inheritance', width:48,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      var isInherited = value.indexOf('*')>-1;
 
                                                      var noFurtherInheritance = false;
                                                      if (isInherited){
                                                        noFurtherInheritance =   value.indexOf('*/-')>-1;
                                                      }

                                                      return '<div class="xty_icon xty_icon'+ ((isInherited)? (noFurtherInheritance?'FurtherInheritanceBroken':'InheritanceActive') :'InheritanceBroken')+'" data-qtip="'+ ((isInherited) ? (noFurtherInheritance?'Erben aktiv <br>Weitervererben unterbrochen ':'Vererbung aktiv') :'Vererbung unterbrochen')+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                     }
                                                    },
                                                  
	                                                {header: 'Typ',  headerDscr: 'Typ',  dataIndex: 'epobType', width: 36,
	                                                  renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      var html=
                                                        '<div class="xty_epob'+value+'" style="height:18px;" title="'+value+'"></div>';
                                                        //+'<input type="hidden" name="groupTplRecordAccess" data-epobtype="'+record.get('assignEpobType')+'"  data-recordid="'+record.getId()+'"  data-recordix="'+rowIndex+'" />';
	                                                    return html;
	                                                  }
	                                                },
//	                                                {header: 'Name', headerDscr: 'Name', dataIndex: 'name', width:280},
//	                                                {header: 'Pfad', headerDscr: 'Pfad', dataIndex: 'path',  width:320},
//	                                                {header: 'EPIM-Id',headerDscr: 'EPIM-Id',  dataIndex: 'epobId', hidden:true},
                                                  
                                                  
                                                  
                                                  {header: 'Name', headerDscr: 'Name', dataIndex: 'name', width:280,
                                                   renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                   metaData.tdCls="xty_grid-name-cell"; 
                                                   metaData.tdAttr=' dataIndex="name " ' ;
//                                                   +
//                                                      '  data-qtitle="OK Button" ' +
//                                                      '  data-qwidth="100" ' +
//                                                      '  data-qtip="This is a quick tip from markup!"'
                                                   
                                                   
                                                   return value; }
                                                  },
                                                  {header: 'Pfad', headerDscr: 'Pfad', dataIndex: 'path',  width:320,
                                                  renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {metaData.tdCls="xty_grid-path-cell"; return value; }
                                                  },
                                                  {header: 'EPIM-Id',headerDscr: 'EPIM-Id',  dataIndex: 'epobId', hidden:true,
                                                  renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {metaData.tdCls="xty_grid-id-cell"; return value; }
                                                  }
                                                  
                                                  
                                                  
                                                  ],
                                                  html:null
                                                },                   
                                                
                                          { title:'&nbsp;&nbsp;Bilder', features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'imagesGrid', height: mainContentPanelHeight-148 },
                                          { title:'&nbsp;&nbsp;Texte' , features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'textsGrid', height: mainContentPanelHeight-148},
                                          { title:'&nbsp;&nbsp;Dokumente' , features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'documentsGrid', height: mainContentPanelHeight-148},
                                          { title:'&nbsp;&nbsp;Produkttabellen' , features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'prodtabGrid',height: mainContentPanelHeight-148},
                                          { title:'&nbsp;&nbsp;Redaktionelle Tabellen' , features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'edtabGrid', height: mainContentPanelHeight-148},
                                          { title:'&nbsp;&nbsp;Grafiken' , features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'graphicsGrid', height: mainContentPanelHeight-148},
                                          { title:'&nbsp;&nbsp;Audio', features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'audiosGrid', height: mainContentPanelHeight-148},
                                          { title:'&nbsp;&nbsp;Video', features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})], itemId:'videosGrid', margin:'0 24 36 24'  , height: mainContentPanelHeight-148}
                                          
//                                           {xtype:'grid', hidden:true,
//                                             //title:'columnsHeaderOnlyPanel', 
//                                             collapsed:false,
//                                             listeners:null,
//                                             tools:null,
//                                             cls:'xty_columnsHeaderOnlyPanel',
//                                             style:'position: absolute; top: 500px;',
//                                             preventHeader:true,
//                                             itemId:'columnsHeaderOnlyPanel', 
//                                             margin:'0 24 36 24' ,
//                                             height:25,
//                                             columns: [
//                                                  {header: 'Ansicht', headerDscr: 'Ansicht',  dataIndex: 'preview', width:66},
//                                                  {header: 'Textinhalt', headerDscr: 'Textinhalt',  dataIndex: 'preview', width:266, hidden:true},
//                                                  {heasder:  'Zuordnung', header:  '<div class="xty_icon xty_iconCrossref" style="height:18px;" title="Zuordnung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' , headerDscr: 'Zuordnung',  dataIndex: 'Inheritance', width:48},
//                                                  {header_1: 'Vererbung',  header:  '<div class="xty_epobHierarchies" style="height:18px;" title="Vererbung">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>' ,headerDscr: 'Vererbung',  dataIndex: 'Inheritance', width:48},
//                                                  {header: 'Typ',  headerDscr: 'Typ',  dataIndex: 'epobType', width: 36},
//                                                  {header: 'Name', headerDscr: 'Name', dataIndex: 'name', width:280},
//                                                  {header: 'Pfad', headerDscr: 'Pfad', dataIndex: 'path',  width:320},
//                                                  {header: 'EPIM-Id',headerDscr: 'EPIM-Id',  dataIndex: 'epobId', hidden:true}
//                                                  ]
//                                           }
                                          
                                          
                                         ]
   
                           	       },
                           	       {
                                   	   title: extVia.locales.relations, hidden:isCONTENT,
                                       itemId:'relationsTab',
                                       stateful:true,
                                       stateId:editorMainTabItemId+'-relationsTab',
                                       defaults:{ // Valid for all subtab boxes
                                        wisdth:580, 
                                        margin:'24 24 24 24' 
                                        },
                                       items:[

                                            {
                                                xtype:'grid',
                                                height:mainContentPanelHeight-48,

                                                cls:'xty_selfilter-grid',
                                                iconCls:'xty_formbutton-showSelected ',
                                                title:'&nbsp;&nbsp;Zubeh&ouml;r',
                                                //tools:[{xtype:'button', iconCls:'xty_formbutton-filterSelected ', height:18, scale:'small'}],
                                                
                                                features: [Ext.create('Ext.grid.feature.Grouping',{groupHeaderTpl: '{name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'})],
                                                store: Ext.create('Ext.data.Store', {
                                                storeId:'accessoriesStore',
                                                allowDeselect:true,

                                                //              0             1        2         3       4         5         6            7                8                       9                     10                 11               12              
                                                fields: ['isInherited','epobType','productNr','name','position','path', 'parentId','parentProductNr',' parentProductId ','parentProductgroupID','parentProductgroupName', 'newposition', 'checked'],
                                                
                                                data : extVia.editor.baseEditor.dummies.relations,
                      
                      											    proxy: {
                      											        type: 'memory',
                      											        reader: 'array'
                      											    }
                      											   }),
                                            multiSelect : true,
                                            listeners: {
//                                             select: function( view, record, index, eOpts ){
//                                                 var task = new Ext.util.DelayedTask(function(){
//						                           record.wasSelected=true; // for itemcklick
//						                         });
//						                         task.delay(300); 
//                                             },
//                                             deselect: function( view, record, index, eOpts ){
//	                                             var task = new Ext.util.DelayedTask(function(){
//			                                       record.wasSelected=false; // for itemcklick
//			                                     });
//			                                     task.delay(300); 
//                                             },
//                                             
//                                             itemclick: function ( view, record, item, index, e, eOpts ){
////                                              if (record.wasSelected){
////                                                var store = view.getStore(); 
////                                                var selectionModel = view.getSelectionModel();
////                                                selectionModel.deselect(record); 
////                                              }
//                                             },
                                             itemdblclick: function ( view, record, item, index, e, eOpts ){
                                                var position = record.get('position');
                                                var hasPos = !Ext.isEmpty(position);
                                                if (position===-1){
                                                  record.set('position', record.oldPosition);
                                                }
                                                else{
                                                  record.oldPosition = record.get('position');
                                                  record.set('position', -1);
                                                } 
                                             },
                                             
                                             
                                              
                                              afterrender: function(panel) {
                                                var iconArr= Ext.query('#'+panel.id+' .x-panel-header-icon.xty_formbutton-showSelected ');
                                                if (iconArr){
                                                  var showSelectedEl = Ext.get(iconArr[0]);
                                                  var showSelectedHandler = function(){
                                                    
                                                   if (!showSelectedEl.filterON){
                                                    showSelectedEl.addCls('xty_formbutton-showAll');    
                                                    showSelectedEl.dom.title='Alle Zeilen zeigen';
                                                   }else{
                                                    showSelectedEl.removeCls('xty_formbutton-showAll'); 
                                                    showSelectedEl.dom.title='Ausgewählte Zeilen zeigen';
                                                   }
                                                    
                                                    var store = panel.getStore();
                                                    store.filterBy(function(filterRecord, id){
                                                          // checkbox filtering
                                                          var position = filterRecord.get('position');
                                                          var showRow = !Ext.isEmpty(position);
                                                          if (position === -2){showRow=false;}
                                                          if (showSelectedEl.filterON){
                                                           showRow = true;
                                                          }
                                                          
                                                          if ( showRow) {
                                                             filterRecord.set('rowIsHidden', false);
                                                             return true;
                                                          }
                                                          else {filterRecord.set('rowIsHidden', true);}

                                                     });   
                                                     showSelectedEl.filterON = !showSelectedEl.filterON;
                                                  };
                                                  showSelectedEl.on('click',showSelectedHandler);
                                                  showSelectedEl.dom.title='Ausgewählte Zeilen zeigen';
                                                }
                                              }
                                            },
                                              
                                
											                      columns: [
                                                    //{xtype: 'rownumberer'},
                                                    
                                                   {header1: 'hatR', header:'<div class="xty_icon xty_iconChecked" title="Reihenfolge"></div>' ,  dataIndex: 'position', width:36, 
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                      metaData.tdCls="xty_grid-seqnr-cell";
                                                      var checked = !Ext.isEmpty(value);
                                                      if (value===-1){checked = true;}
                                                      if (value===-2){checked = false;}
                                                      checked = checked ?' checked ':'';
                                                      
                                                      extVia.editor.baseEditor.inputClickHandler = function(checkboxEl){
                                                        var recordClicked = store.getAt(checkboxEl.getAttribute('data-recordix') );
                                                        var position = recordClicked.get('position');
                                                        var hasPos = !Ext.isEmpty(position);
                                                        if (position===-1){
                                                          recordClicked.set('position', record.oldPosition);
                                                          }
                                                        else{
                                                          recordClicked.oldPosition = recordClicked.get('position');
                                                          recordClicked.set('position', hasPos?-2:-1);
                                                        } 
                                                      };
                                                      
                                                      var html ='<input id="hasSequence_chbx_'+rowIndex+'" '+checked+' name="hasSequence_chbx"  onclick="extVia.editor.baseEditor.inputClickHandler(this);" data-recordid="'+record.getId()+'"  data-recordix="'+rowIndex+'"   type="checkbox" value="hasSequence_chbx_'+record.get('epobId')+'" />';
                                                      return html;
                                                      
                                                    }
                                                   },
                                                   
                                                    {header: '<div class="xty_icon xty_iconSequence" title="Reihenfolge"></div>',  dataIndex: 'position', width:42, sortable:false, hixdden:true,
                                                     renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
	                                                     var currentIx =  rowIndex+1;
	                                                     var html = value;
	                                                     if (value !== currentIx){
	                                                      //html = currentIx+' &laquo; '+value;
	                                                      
	                                                      html= '<span data-qtip="' + currentIx+' &laquo; '+value+'">' + currentIx+'</span>';
	                                                      } 
	                                                      
	                                                     //metaData.tdCls="xty_grid-seqnr-cell"; 
	                                                     return html; 
                                                     }
                                                    },
                                                    
                                                    {header: '<div class="xty_icon xty_iconSequence" style="width:40px !important;" title="Reihenfolge in der Datenbank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DB</div>',  dataIndex: 'position', width:40 , hidden:true,
                                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                     //metaData.tdCls="xty_grid-seqnr-cell"; 
                                                     return value;
                                                    }
                                                    },
                                                    {header: '<div class="xty_icon xty_iconSequence" style="width:40px !important;" title="Reihenfolge neu">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;neu</div>',  dataIndex: 'newposition', width:40, hidxden:true},


                                                    
                                                    {header: 'Typ',  dataIndex: 'epobType', width:40,
                                                      renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                        return '<div class="xty_epob'+value+'" title="'+value+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                        }
                                                    },
                                                    {header: 'Produktnummer',  dataIndex: 'productNr', hidden:true},
                                                    {header: 'Name',  dataIndex: 'name', width:280},
                              
                                                                                                       

                                                    {header: 'Pfad',  dataIndex: 'path',  width:320},
                                                    {header: 'EPIM-Id',  dataIndex: 'epobId'},
                                                    {header: 'ererbter Wert',  dataIndex: 'isInherited', width:36, hidden:true,
                                                      renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
                                                        var isInherited = value === '*';
                                                        return '<div class="xty_icon xty_icon'+ ((isInherited)?'Inherited':'Nothing')+'" title="'+ ((isInherited)?'Ererbte Werte':'')+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
                                                       }
                                                    },
                                                    {header: 'parentId',  dataIndex: 'parentId', hidden:true},
                                                    {header: 'parentProductNr',  dataIndex: 'parentProductNr', hidden:true},
                                                    {header: 'parentProductId',  dataIndex: 'parentProductId', hidden:true},
                                                    {header: 'parentProductgroupID',  dataIndex: 'parentProductgroupID', hidden:true},
                                                    {header: 'parentProductgroupName',  dataIndex: 'parentProductgroupName', hidden:true}
                                                    
                                                    
                                                    
											    ],
											    viewConfig: {
											    listeners: {
													        drop: function(node, data, dropRec, dropPosition) {
													          var sm = this.panel.selModel;
													          var records = sm.getSelection();
													          var selectedRecIds =[];
													          if (sm.hasSelection()) {
													            var rowindex=0; 
													            for(rowindex=0; rowindex<records.length; rowindex++) {
														           var record = records[rowindex];
														           var position= record.get('position');
														           var hasPos = !Ext.isEmpty(position) || (position === -1);
														           if (!hasPos){
														           record.oldPosition = record.get('position');
														             record.set('position', hasPos?-2:-1);
														           }
														           selectedRecIds.push(record.id);
														             record.dirty = true;
													            }
													          }
                                    
													          var columns = this.getGridColumns(), cell;
													          var store = this.panel.store;
													          var storeLength = store.count(), a = 0;
													          for(a = 0; a < storeLength; a++){
													            var rec = store.getAt(a);
                                                            
													            if (selectedRecIds.indexOf(rec.id)>-1) {
													             rec.set('newposition', a+1);
													            }
                                      
													            if(rec.dirty){
													              cell = this.getCell(rec, columns[0]);
																  if (cell) {
																    var row = cell.parent();
																    row.addCls('xty_grid-dirty-row');
																    cell.addCls('xty_grid-dirty-cell');
																  }
													            }
													          }
													        }
													      },
											        plugins: {
											            ptype: 'gridviewdragdrop',
											            dragText: 'Drag and drop Relations to reorganize'
											        }
											    }
											}                                 
                                       
                                       ]
 
                           	       }, 
                           	       {
                                   	   title:'Lieferant', hidden:true,
                                       moreBtnCfg:{  dscr:'Lieferanten&raquo; Niederlassungen',  menuCfg: { items:[  {iconCls:'xty_pgtoolbar-supplier',text:'Niederlassungen' }]}},  
                                       stateful:true,
                                       itemId:'supplierTab',
                                       stateId:editorMainTabItemId+'-supplierTab'
                           	       },
                           	       {
                                   	   title: extVia.locales.preview+extVia.editor.baseEditor.statics.addTabChooser('preview'), hidXXden:isCONTENT,
                                       tabchooser:true,
                                       stateful:true,
                                       moreBtnCfg:{
                                        dscr:'Vorschauen', 
                                        menuCfg: {items:[  
                                          Ext.isDefined(extVia.versionsProto) ?  extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob,width:420,title:'Vorschauen', iconCls:'xty_pgtoolbar-previews', itemId:'previews'},epob) : {}
                                          ]}
                                       },  
                                       itemId:'previewTab',
                                       stateId:editorMainTabItemId+'-previewTab'
                           	       },
                           	       Ext.isDefined(extVia.versionsProto) ?  extVia.versionsProto.statics.getVersionTabCfg({editorMainTabItemId:editorMainTabItemId},epob)  : {title:'Versionen'},
                                  
                           	       Ext.isDefined(extVia.historyProto) ? extVia.historyProto.statics.getHistoryTabCfg({editorMainTabItemId:editorMainTabItemId},epob)  : {title:'History'},
                                
                                   
                                   {
                                       title: extVia.locales.tasks, 
                                       itemId:'taskstab',
                                       badgeCfg :{
            							             cls:'xty_tabs-badge',
            							             count: 5, 
            							             tooltip: 'neue Aufgaben'
            							           },                       
                                       autoScroll:false,
                                       stateId:editorMainTabItemId+'-tasks',
                                       activate:function(tab){
                                        var applibar =    tab.ownerCt.ownerCt.getApplicationBar();
                                        applibar.getComponent('pagetoolbar').getComponent('openDiff').show();
                                       },
                                       deactivate:function(tab){
                                        var applibar =    tab.ownerCt.ownerCt.getApplicationBar();
                                        applibar.getComponent('pagetoolbar').getComponent('openDiff').hide();
                                       },                                       
                                       items:[ 
                                        {
                                        //title:'BPM',
                                        xtype:'grid', border:false, height: subTabsHeight,
                                        
                                        columns:[
                                        
                  									    {
                  									        header: "Aufgabe",
                                            defaults:{width:100},
                                                columns: [
            									            { header: "Name", tooltip:'tooltip', title:'title', qtip:'qtip',columnName: "task-name"},
                                                { header: "F&auml;lligkeit", columnName: "task-date"},
                                                { header: "Besitzer", columnName: "task-asignee"},
                                                { header: "Priorit&auml;t", columnName: "task-prio"},
                                                //{ header: "Verantwortlicher", columnName: "task-responsible", width:null,columns:[ { header: "Benutzer", columnName: "task-responsible-user-clmn", width:80},{ header: "Rolle", columnName: "task-responsible-role-clmn", width:80}]},
                                                
                                                
                                                { header: "Verantwortlicher", columnName: "task-responsible-user", width:null},
                                                { header: "Verantwortliche Rolle", columnName: "task-responsible-role", width:null},
                                                { header: "Status", columnName: "task-status", width:40},
                                                { header: "Aufgeschoben", columnName: "task-status"},
                                                { header: "Nachfolgetermin", columnName: "task-status"}
              									        ]
              									    },
              					                    {
					                          header: "Prozess",
                                              defaults:{width:100},
					                          columns: [
					                            { header: "Prozess", columnName: "process-name"},
                                                { header: "Prozessdiagramm", columnName: "process-diagram"},
                                                { header: "Deadline", columnName: "process-date"},
                                                { header: "Typ", columnName: "process-epob-type" ,width:30},
                                                { header: "Objektname", columnName: "process-epob-name"},
                                                { header: "Verantwortlicher Benutzer", columnName: "process-responsible-user", width:null},
                                                { header: "Verantwortliche Rolle", columnName: "process-responsible-role", width:null},
                                                { header: "Erstellungsdatum", columnName: "process-creationdate"}
                                                
					                          ]
					                    }                                       
                                        ]
                                       }
                                       
                                       
                                       
                                       
//                                          {
//                                          border:false,                                 
//                                          //margin:'24 24 24 24', 
//                                          html: '<div style="font-size:18pt;color:#888; margin:24px; margin-bottom: 22px;" class="xty_dialog-maisssnInstr">Aktivit&auml;ten</div>'
//                                          },
//                                          extVia.historyProto.statics.getInfoHistoryListCfg({
//	                                            bodyStyle:'border: solid 1px #c5c5c5;',
//	                                           //margin:'0 24 0 24',
//	                                            //height:500,
//	                                            //height:mainContentPanelHeight,
//	                                           height: extVia.regApp.myRaster.getCenter().getHeight()-176,
//	                                           preventHeader:true
//	                                          } ,{dscr:'alle'}, epob)
                                          ]
                                          //,html: "<img  src='../img/fakes/versio-timeline.png'/>"
                                   },
                                   
                                   
                                   
                                   {
                                     title:'Custom'
                                     
                                   }
                           	       
                           	       
                           	       
                           	       
                           	       
                           	       
                             ]
                           }
                      ]}
    	;
    	return epobEditorPanelCfg;
    },
    

    getContentSwitcherCfg : function(cfg , epob){

    	var editorMainTabItemId = cfg.editorMainTabItemId;
    	epob = cfg.epob;
    	var versionMode = cfg.versionMode;
    	
    	var isInPgjobbar = cfg.isInPgjobbar;
    	
    	
    	var isPRODUCT=true;
    	var isCONTENT=false;

        if ( epob &&( extVia.module.epob.getAreaId(epob.typeId) ===  extVia.module.epob.CONTENT ||  extVia.module.epob.getAreaId(epob.epobTypeId) ===  extVia.module.epob.CONTENT) ){
    		isPRODUCT=false;
    		isCONTENT=true;
    	}
    	
    	
    	 var currentModeIconCls = versionMode?'xty_pgtoolbar-versioning-version':'xty_pgtoolbar-versioning-work';
    	
         var uiLangIso = extVia.locales.uiLangIso;

    	 var contentSwitcherCfg ={
		           xtype: 'buttongroup',
		           itemId:'contentSwitcherBtnGrp',
		           columns: 3,
		           defaults: {
		               scale: 'small', enabsleToggle:true, xtype:'splitbutton',
		               
		               handler:function(item){
		            	   
		            	  var editorPanel =  extVia.regApp.centerTabPan.getActiveTab();
		            	  var editorSubTabsPanel = editorPanel.items.get(0); // getComponent("editorSubTabsPanel")
		            	  var editorSubTabBar = editorSubTabsPanel.getTabBar();
		            	  
		            	  var highlightScopeElement;
		            	  
		            	  if (isInPgjobbar) {
		            		 highlightScopeElement= Ext.get(editorSubTabBar.id).dom.firstChild.firstChild;
		            		  
//		            	     for (var i=1; i<8; i++){
//		            	    	 var highlightScopeTab = editorSubTabBar.items.get(i); 
//		            	    	 highlightScopeTab = Ext.get( highlightScopeTab.id+'-btnWrap');
//				            	   Ext.get(highlightScopeTab.id).highlight("ff04d9", {
//				            		    attr: "backgroundColor", //can be any valid CSS property (attribute) that supports a color value
//				            		    endColor: "fcaaef",// (current color) or "ffffff",
//				            		    easing: 'easeIn',
//				            		    duration: 2000
//				            		}); 
//		            	     }
		            	  
		            	  }
		            	  else{
		            		  highlightScopeElement = editorSubTabBar.items.get(item.relatedTabIndex); 
		            		  
		            		  highlightScopeElement = Ext.get( highlightScopeElement.id+'-btnWrap');
		            	  }		            	 
		            	 if (highlightScopeElement) {
			            	   Ext.get(highlightScopeElement.id).highlight("ff04d9", {
			            		    attr: "backgroundColor", //can be any valid CSS property (attribute) that supports a color value
			            		    endColor: "fcaaef",// (current color) or "ffffff",
			            		    easing: 'easeIn',
			            		    duration: 2000
			            		}); 
		            	 } 
		            	   
		               }
		               
		           },
		           items: [
  
				  {iconCls : 'xty_pgtoolbar-language-userX xty_icon_'+uiLangIso, cls:'xty_language-chooser', itemId:'language',tooltip:'Sprache',height:22, width:22, scale: 'small', hidden: ( isCONTENT|| !isInPgjobbar),
		              
		               menu:{
		            	   items:[{
		            		   xtype:'boundlist', 
		            		  
		            		   queryMode: 'local',
		            		   multiSelect : true,
		            		   displayField: 'dscr',
		            		   store: extVia.stores.initLanguageStore(),
		            		   listeners:{
		            			   selectionchXXange:function(view, selections, eOpts){
		            				   this.ownerCt.floatParent.setIconCls('xty_icon_'+selections[0].data.iso2);
		            				   this.ownerCt.floatParent.setTooltip(selections[0].data.dscr);
		            				   this.ownerCt.hide();
		            				   },
		            			   itemclick: function( view, record, item, index, e, eOpts ){
		            				   var iso2 = record.get('iso2');
                                       
		            				   this.ownerCt.floatParent.setIconCls('xty_icon_'+iso2);
		            				   this.ownerCt.floatParent.setTooltip(record.get('dscr'));
		            				   this.ownerCt.hide();
                           
		            				   if (iso2==='de' || iso2==='en'|| iso2==='us' || iso2==='ro' ){
		            				    extVia.ui.page.raster.reloadPage('uiLangIso='+iso2);
		            				   }
                                       
		            			   }
		            		   },
                               itemTpl : '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>',
	                           getInXXXnerTpl : function() {
	                                var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
	                                return tpl;
		                       },
		            		   
		            		   heidght:150}]
		               }  
				  },

				  {iconCls : 'xty_pgtoolbar-reference', tooltip:'Referenzen', cls : 'x-btn-disabled', disasbled:true, itemId:'reference',  hidden: true, // isCONTENT ||  !isInPgjobbar,
		              
		               menu:{
		            	   items:[   
		            	      {xtype:'panel',bordxer:false, height: 450, width:268, html: "<img  src='../img/fakes/refline.png'/>"},
		            	          
		            	      {
		            		   xtype:'boundlist', 
		            		   queryMode: 'local',
		            		   multiSelect : true,
		            		   displayField: 'dscr',
		            		   store: extVia.stores.initReferenceLineStore(),
	                           getInnerTpl : function() {
	                                var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_epob{epobTypeKey}"><span style="margin-top:-8px;color:#888;">' + '&nbsp; {path} ' + '</span><span style="margin-top:-8px;">' + '{dscr}' + '</span></div>';
	                                return tpl;
		                       },
		            		   listeners:{
		            			   selectionchange:function(view, selections, eOpts){
		            				   if (selections[0].data.id === 0){
		            					   this.ownerCt.floatParent.addCls('x-btn-disabled');
		            				   }
		            				   else {
		            					   this.ownerCt.floatParent.removeCls('x-btn-disabled');   
		            				   }
		            				   this.ownerCt.floatParent.setTooltip(selections[0].data.dscr);
		            				   this.ownerCt.hide();
		            				   }
		            		   },
		            		   width:320,
		            		   heidght:150}]
		               }   
				  
				  
				  },
				  
				  {iconCls : 'xty_pgtoolbar-view-diff', tooltip:'Vergleich', xtype:'button', clxs : 'x-btn-disabled',  itemId:'diff',hidden: true,
                     handler:function(){extVia.regApp.showDiffPanel(epob);}
                  },
				  
		          {iconCls : 'xty_menu-versioning-version', relatedTabIndex:7, itemId:'versions',tooltip:'Versionen',height:20, scale: 'small',hidden:isInPgjobbar,
					  menu:{
						 items:[
						      Ext.isDefined(extVia.versionsProto) ? extVia.versionsProto.statics.getVersionsItemsListCfg({epob:epob},epob) : {text:'VersionsItemsList'}
						    ]  
					  }
		          },	
		          {iconCls : 'xty_pgtoolbar-databaseviews', relatedTabIndex:2, cls : 'x-bxtn-disabled', itemId:'databaseviews',tooltip:'Sichten',height:20, scale: 'small', hidden: ( isInPgjobbar)}
		          
		          
		          ]           
			   };
    	 
    	 return contentSwitcherCfg; 
    },
    
    
    getSaveButtonCfg : function(editorMainTabItemId){
     
	 var epob={};
	 		
     var saveButtonCfg  = {
        xtype : 'splitbutton',
        name : 'save',
        itemId:'save',
        tooltip : 'Save',
        
        
        handler:function(){
        	
        	
        var form2save = null;//extVia.regApp.myRaster.getCenter().items.get(0).getActiveTab().getComponent(editorMainTabItemId).getComponent("epoBEditor-epob_1-metadataTab").getComponent("myFormPanel").getForm(); 	

        try{
        	form2save = extVia.regApp.myRaster.getCenter().items.get(0).getActiveTab().getComponent(editorMainTabItemId).getComponent(editorMainTabItemId+'-metadataTab').getComponent("myFormPanel").getForm(); 	
        }
        catch(ex){}
        
        var html = "";
        
        if (form2save  && !form2save.isValid()){

        	var invalidFieldNames="&bull;Name<br>&bull;XY<br>";
        	var invalidInputDscr =  "Keine g&uuml;ltige Eingabe.";
        	html =   "<b>"+invalidInputDscr +"</b><br>";//  "<br>"+invalidFieldNames;
        	
        	extVia.regApp.myRaster.getCenter().items.get(0).getActiveTab().getComponent(editorMainTabItemId).setActiveTab(editorMainTabItemId+"-metadataTab");
        	
        	var fieldsMxdColl = form2save.getFields();	  
        	var firstInvalidField = fieldsMxdColl.findBy( function(field, key){
        			return !field.isValid();	
        	});	     
        	firstInvalidField.focus();
        	
        	
        }
        else if (form2save.isDirty()){	
        	html =  Ext.encode(form2save.getValues());
        }
        else {	
        	html =  "Keine &Auml;nderungen vorhanden";
        }
      	 
        var actionDscrSave =  "Speichern"; 	

     		Ext.create('widget.uxNotification', {
				title: actionDscrSave,
				status : "ErrorValidate",
				position: 'tr',
				manager: 'instructions',
				cls: 'ux-notification-light',
				iconCls: 'ux-notification-icon-information',
				html :  html,
				autoCloseDelay: 2000,
				slideBackDuration: 500,
				slideInAnimation: 'bounceOut',
				slideBackAnimation: 'easeIn'
			}).show();
        },
       
 	    
 	   menu:{
 			   
 			   defaults:{
 				   style:'padding-left:20px', height:48
 			   },
 			   items:[ 
 			          {text:'Speichern und Schliessen',  iconCls : 'xty_pgtoolbar-saveAndClose'},
 			          
 			          Ext.isDefined(extVia.versionsProto) ?  extVia.versionsProto.statics.getCreateVersionButtonCfg({},epob,editorMainTabItemId) : {text:'CreateVersion'},
 			          {text:'Schliessen',  iconCls : 'xty_pgtoolbar-close'},
 			          {text:'L&ouml;schen',  iconCls : 'xty_pgtoolbar-remove'},
 			          {text:'Neu',  iconCls : 'xty_pgtoolbar-newEpob'},
 			          {text:'Zuordnen', iconCls : 'xty_pgtoolbar-assign'},
	 			         {
 			                text: 'Konfiguration',
 			                iconCls : 'xty_pgtoolbar-search'
 			                //menu: { items: [ ergebnisDarstellungsPanelCfg  ]}
 			           },// eo Konfiguration

 			          {text:'zu Sammlung hinzuf&uuml;gen', iconCls : 'xty_pgtoolbar-collection',menu:{items:[  {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img  src='../img/fakes/collectionWidg.png'/>"}]}}  
 			          ]
 	   },  
 	    
 	    
        iconCls : 'xty_pgtoolbar-save',
        scale : extVia.constants.raster.pagetoolbarCenterBtnScale,
        listeners : {
        }
      };
      
      return saveButtonCfg;
      
    }
    
    
    
    	
    }
});
