Ext.define("Ext.ux.grouptabnavi",{
 extend : "Ext.panel.Panel",
  
    margins:'12 24 24 24',
    height: 88,
    cls:'xty_regionNorth',
	y: 0,
	//title: 'Navigation Window',
	closable: false,
	plain: true,
    withcollapseExpand : true,
	layout: 'fit',

 
isGroupActive : function(){
	var panel = this.groupTabPanel;	
	return panel.activeTab === panel.activeGroup;
},
 
createBtn : function(config){
	var btn,
		config = Ext.apply({},config,{
		handler : this.onBtnClick
		 
	});
	btn = Ext.create('Ext.Button',config);

	btn.onTabChange && this.addListener("tabchange",Ext.bind(btn.onTabChange,btn));
	btn.onGroupChange && this.addListener("groupchange",Ext.bind(btn.onGroupChange,btn));
	return btn;
},



onBtnClick : function(btn,e){
	var panel  = this.groupTabPanel,
		selModel = panel.down('treepanel').getSelectionModel(),
		activeNode = panel.store.getNodeById(panel.activeTab.getId()),
		isGroupActive = this.isGroupActive(),
		newNode = btn.getNextNode(activeNode,isGroupActive);

		newNode && panel.onNodeSelect(selModel,newNode);
	
}, 
 
onGroupChange: function(panel,newNode,oldNode){
	
	var actionStartButton = Ext.getCmp("actionStart-button");
	if (panel.getActiveGroup().itemId.indexOf('configuration')>-1){
		
		actionStartButton.setDisabled(false);
	}
	else {
		actionStartButton.setDisabled(true);
	}
	
	
	var store = panel.store,
		haveNextSibling = store.getNodeById(newNode.getId()).nextSibling !== null  ,
		havePreviousSibling = store.getNodeById(newNode.getId()).previousSibling !== null ;
	this.fireEvent("groupchange",havePreviousSibling,haveNextSibling);	

},
 
onTabChange: function(panel,newNode,oldNode){
	var store = panel.store,
		newNode = store.getNodeById(newNode.getId()),
		isGroupActive = this.isGroupActive(),
		haveNextSibling = isGroupActive ? newNode.firstChild !== null : newNode.nextSibling !== null,
		havePreviousSibling = isGroupActive ? false :  newNode.previousSibling !== null || newNode.parentNode.fistChild !== null ;
		newNode.parentNode.expand();
		newNode.expand();
	this.fireEvent("tabchange",havePreviousSibling,haveNextSibling);	

}, 
 
onChangeHaveNextSibling : function(havePreviousSibling,haveNextSibling){	
    this.setDisabled(!haveNextSibling);
},
 
onChangeHavePreviousSibling : function(havePreviousSibling,haveNextSibling){
 this.setDisabled(!havePreviousSibling);
}, 
 
constructor : function(groupTabPanel){
	this.addEvents('tabchange','groupchange');
	
	this.onBtnClick = Ext.bind(this.onBtnClick,this);
	this.onGroupChange = Ext.bind(this.onGroupChange,this);
	this.onTabChange = Ext.bind(this.onTabChange,this);
	
	this.groupTabPanel = groupTabPanel;
	this.dynBtns =[];
	currentNode = this.groupTabPanel.store.getRootNode();
	
	while(currentNode) {
  
    currentNode = currentNode.firstChild || currentNode.nextSibling || currentNode.parentNode.nextSibling;
 
 
 
    currentNode&&currentNode.isLeaf() && this.dynBtns.push(this.createBtn({
						iconCls: currentNode.data.iconCls ||  (currentNode.isLeaf() ? 'x-btn-inner x-tree-icon-leaf ': 'x-tree-icon-parent'), 
						text: currentNode.data.text, 
						width:120,
						getNextNode : function(currentNode){
                            var currentNode = currentNode;
                            return function(activeNode,isGroupActive){
                                          return currentNode;
                                        }
                        }(currentNode)
                })
    );
  }
 
  
  this.groupTabPanel.addListener('groupchange',this.onGroupChange);
  this.groupTabPanel.addListener('tabchange',this.onTabChange);
  
	
	
	
	this.groupTabPanel.addListener('groupchange',this.onGroupChange);
	this.groupTabPanel.addListener('tabchange',this.onTabChange);
	
	this.firstItemBtn =  this.createBtn({
		 iconCls: 'xty_pgtoolbar-pagingFirst',
			tooltip: 'First item',
			getNextNode : function(activeNode,isGroupActive){
				return isGroupActive ?  activeNode : activeNode["parentNode"];
			},
			onTabChange : this.onChangeHavePreviousSibling
	});

	
	
		
	this.previousItemBtn =  this.createBtn({
        iconCls: 'xty_pgtoolbar-pagingPrev',
		tooltip: 'Previous item',
		getNextNode : function(activeNode,isGroupActive){
			return isGroupActive ?   activeNode : activeNode["previousSibling"]  ||  activeNode["parentNode"] ;
		},
		onTabChange : this.onChangeHavePreviousSibling
	});
	
	this.nextItemBtn =  this.createBtn({
    	iconCls: 'xty_pgtoolbar-pagingNext',
		tooltip: 'Next item',
		getNextNode : function(activeNode,isGroupActive){
			return newNode =isGroupActive ?  activeNode["firstChild"]  : activeNode["nextSibling"] ;
		},
		onTabChange : this.onChangeHaveNextSibling
	});
	
	this.lastItemBtn = this.createBtn({
		 iconCls: 'xty_pgtoolbar-pagingLast',
		tooltip: 'Last item',
		itemId:'last',
		getNextNode : function(activeNode,isGroupActive){
			return isGroupActive ?  activeNode["lastChild"] : activeNode["parentNode"]["lastChild"];
			return isGroupActive ?  activeNode["lastChild"] : activeNode["parentNode"]["lastChild"];
		},
		onTabChange : this.onChangeHaveNextSibling
			
    });
	
			
	this.firstGroupBtn =  this.createBtn({
		iconCls: 'xty_pgtoolbar-pagingFirst',
		scale:'large',
		tooltip: 'First group',
		getNextNode : function(activeNode,isGroupActive){
		activeNode.expand();
			return isGroupActive ? activeNode["parentNode"]["firstChild"]:activeNode["parentNode"]["parentNode"]["firstChild"];
		},
		onGroupChange : this.onChangeHavePreviousSibling
	});
	this.previousGroupBtn =  this.createBtn({
		iconCls: 'xty_pgtoolbar-pagingPrev',
		scale:'large',
		tooltip: 'Previous group',
		getNextNode : function(activeNode,isGroupActive){
		activeNode.expand();
			return isGroupActive ? activeNode['previousSibling'] : activeNode["parentNode"]['previousSibling'];
		},
		onGroupChange : this.onChangeHavePreviousSibling
	});
	this.nextGroupBtn =  this.createBtn({
		iconCls: 'xty_pgtoolbar-pagingNext',
		scale:'large',
		tooltip: 'Next group',
		getNextNode : function(activeNode,isGroupActive){
		activeNode.expand();
			return isGroupActive ? activeNode['nextSibling'] : activeNode["parentNode"]['nextSibling'];
		},
		onGroupChange : this.onChangeHaveNextSibling
    });
	
//my
this.expandGroup = this.createBtn({
tooltip:'Expand group' ,
text:'Expand group' ,
getNextNode : function(activeNode,isGroupActive){

			return activeNode.isLeaf() ? activeNode.parentNode.expand() : activeNode.expand();
		},	

});

this.collapseGroup = this.createBtn({
tooltip:'Collapse group' ,
text: 'Collapse group' ,
getNextNode : function(activeNode,isGroupActive){

			return activeNode.isLeaf() ? activeNode.parentNode.collapse() : activeNode.collapse();
		},
});
	
	this.lastGroupBtn =  this.createBtn({
		iconCls: 'xty_pgtoolbar-pagingLast',
		scale:'large',
		tooltip: 'Last group',
		getNextNode : function(activeNode,isGroupActive){
		activeNode.expand();
			return isGroupActive ? activeNode["parentNode"]["lastChild"] : activeNode["parentNode"]["parentNode"]["lastChild"];
		},
		onGroupChange : this.onChangeHaveNextSibling
    });
		
	this.tbar = [{ xtype: 'buttongroup',
				title: 'Group-Subitems',
				columns: 4,
				defaults: {
					scale: 'large'
				},
				items :[this.firstItemBtn,this.previousItemBtn,this.nextItemBtn,this.lastItemBtn],
				
			},{ xtype: 'buttongroup',
				title: 'Group',
				columns: 4,
				defaults: {
					scale: 'large'
				},
				items :[this.firstGroupBtn,this.previousGroupBtn,this.nextGroupBtn,this.lastGroupBtn]
			}];
			
			
// toolbar for direct links

	
	var btngrpHeight = 80;
	
this.tbar = [            
             
{
    xtype: 'buttongroup',
    title: 'Group',
    columns: 4,
    height:btngrpHeight,
    defaults: {
     scale: 'large'
    },
    items :[this.firstGroupBtn,this.previousGroupBtn,this.nextGroupBtn,this.lastGroupBtn]
    },
    
    {
        xtype: 'buttongroup',
        title: 'Action',

        columns: 1,
        height:btngrpHeight,
        defaults: {
         scale: 'large'
        },
        items :[
           {
        	text:'Start', 		
            id :'actionStart-button',
            itemId :'actionStart',
        	iconCls: 'xty_pgtoolbar-start',
        	iconAlign:'top',
        	disabled:true,
        	width:48,
        	handler:function(){
           		Ext.create('widget.uxNotification', {
					title: 'Action',
					position: 'tr',
					manager: 'instructions',
					cls: 'ux-notification-light',
					iconCls: 'ux-notification-icon-information',
					html: 'Ihr Export wurde gestartet',
					autoCloseDelay: 2000,
					slideBackDuration: 500,
					slideInAnimation: 'bounceOut',
					slideBackAnimation: 'easeIn'
				}).show();
        	},
    		scale:'large',
    		tooltip: 'Last group',}
           ]
        }, 
        
        '->',
        
             {  
                xtype: 'buttongroup',
                title: 'Group-Subitems',
                columns: 4,
                height:btngrpHeight,
                defaults: {
                  scale: 'large'
                },
                items :[this.firstItemBtn,this.previousItemBtn,this.nextItemBtn,this.lastItemBtn]
                  
               }
              
              ,{
               xtype: 'buttongroup',
               title: 'subitem',
               columns: 3,
               height:btngrpHeight,
               defaults: {
                scale: 'large'
               },
               items :this.dynBtns
               },
			   // expand/collapse groups
			  {
				xtype: 'buttongroup',
               title: 'Expand/collapse group',
               columns: 2,
               height:btngrpHeight,
               defaults: {
                scale: 'large'
               },
               items : [this.expandGroup, this.collapseGroup ]
			  }		
               

			   
              ];
			
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			

	this.callParent();	
    //init the btns states, sync with the groupTabPanel
	this.onTabChange(this.groupTabPanel,this.groupTabPanel.activeTab,this.groupTabPanel.activeTab);
	this.onGroupChange(this.groupTabPanel,this.groupTabPanel.activeGroup,this.groupTabPanel.activeGroup);	
	return this;
}
 
 
 
 
 
});