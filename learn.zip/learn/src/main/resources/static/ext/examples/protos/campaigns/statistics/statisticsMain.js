Ext.namespace('extVia.campaigns.statistics.main');
/**
 * @class extVia.campaigns.statistics.main Provides ui + data + models + stores + views<br>
 *        May run as subApp
 * 
 * @author Artur Taranyuk, Viamedici Software GmbH
 * @version $Date: 2013/05/06 17:07:49 $ $Revision: 1.34 $
 */
extVia.campaigns.statistics.main = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.statistics.main",
    name : "extVia.campaigns.statistics.main"
  });
};

extVia.campaigns.statistics.main.prototype = {

  /**
   * Store f�l alle charts auser Effizienz
   * 
   * @param some
   * @returns
   */
  createStore : function createStore() {

    Ext.define('Campaign1', {
      extend : 'Ext.data.Model',
      fields : [ 'Id', 'Name', 'iconCls', 'expanded', 'children', 'BudgetI', 'BudgetS', 'BudgetP', 'FGrad', 'Prio',
                'leaf' ]
    });

    var store = Ext.create('Ext.data.Store', {
      model : 'Campaign1',
      proxy : new Ext.data.MemoryProxy()
    });
    return store;

  },

  // Store f�r Effizienz
  createStoreEfficiency : function createStoreEfficiency() {

    Ext.define('efficiencyModel', {
      extend : 'Ext.data.Model',
      fields : [ 'Efficiency' ]
    });

    var store = Ext.create('Ext.data.Store', {
      model : 'efficiencyModel',
      proxy : new Ext.data.MemoryProxy()
    });
    return store;

  },

  // Sucht event mit hilfe von Id
  // Baut Statistik panel auf

  addChartsToPanel : function addChartsToPanel(record, schedulerTabPanel) {
    var event = extVia.campaigns.statistics.control.getEvent(record, record.data.Id);
    var efficiency = 0;
    // var count = extVia.campaigns.statistics.control.getCountMilestone(record, record.data.Id);
    // var countEvents = extVia.campaigns.statistics.control.getCountEvents(record, record.data.Id);
    var gaugeStoreEfficiency = extVia.campaigns.statistics.main.createStoreEfficiency();
    if (event) {
      efficiency = extVia.campaigns.statistics.control.getEfficiency(event, record.data.FGrad);
      if (efficiency > 3) {
        gaugeStoreEfficiency.add({
          Efficiency : '3'
        });
      } else {
        gaugeStoreEfficiency.add({
          Efficiency : efficiency
        });
      }
    }
    
    // var duration = extVia.campaigns.scheduler.control.getElapsedTime(event);
    var nodeChartWidth = 0; //540
    var nodeChartHeight = 259;
    var schTreeId = Ext.get('panel_mC').down('a').parent().id;
    var schTreeGridId = Ext.get(schTreeId).dom.children[0].id;
    var normalTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().normal;
    var children = false;
    normalTree.items.items[0].hide(); // Blendet Details panel aus
    normalTree.headerCt.hide(); // Blendet Details panel aus
    
    var lockedTree = Ext.getCmp(schTreeGridId).ownerCt.ownerCt.getView().locked;
    lockedTree.headerCt.setHeight(45);
    // var dbwidth = Math.round(normalTree.getWidth()/2);
    // var dbheight = Math.round(normalTree.getHeight()/2)-56;
    var panel = extVia.campaigns.statistics.view.getPanel(schedulerTabPanel.items.getAt(0).getHeight(),
        schedulerTabPanel.items.getAt(0).getWidth());
    
    var parentChartsHost = extVia.campaigns.statistics.view.getChildPanel(normalTree.getHeight() - 1, normalTree
        .getWidth(), "Kampagne", true);
    nodeChartWidth = normalTree.getWidth() - 48;

    if (record.data.children) { // falls children vorhanden sind

      var childrenChildPanel = extVia.campaigns.statistics.view.getChildPanel(normalTree.getHeight() - 20, 336,
          "Unterkampagnen", false);
      var pieStore = extVia.campaigns.statistics.main.createStore();
      var columnStore = extVia.campaigns.statistics.main.createStore();
      var gaugeStore = extVia.campaigns.statistics.main.createStore();
      pieStore.add(record.data.children);
      columnStore.add(record.data.children);
      gaugeStore.add(record.data);
      schedulerTabPanel.items.getAt(4).removeAll();
      
      var items = extVia.campaigns.statistics.view.getPieChart(pieStore);
      parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
          'Budget Ist'));
      
      items = extVia.campaigns.statistics.view.getColumnChart(columnStore);
      parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
          'Budget Ist/Soll'));

      if (gaugeStore.data.items[0].get('FGrad') != '') {
        items = extVia.campaigns.statistics.view.getGaugeChart(gaugeStore);
        // parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
        // 'Fertigungsgrad'));
      } else {
        items = {
          border : false,
          bodyStyle : 'padding:10px 10px 10px 10px',
          html : '<div class="xty_dialog-mainInstr">Fertigstellung ist noch nicht angefangen</div>'
        };
        // parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, 80,
        // 'Fertigungsgrad'));
      }

      if (efficiency >= 0) {
        items = extVia.campaigns.statistics.view.getGaugeChartEfficiency(gaugeStoreEfficiency);
        parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
            'Effizienz: ' + record.get('Name'))); // event.data.Name
      } else {

        if (event) {
          items = {
            border : false,
            bodyStyle : 'padding:10px 10px 10px 10px',
            html : '<div class="xty_dialog-mainInstr">Projekt ist noch nicht angefangen</div>'
          };
          parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, 80,
              'Effizienz: ' + event.data.Name));

        } else {
          items = {
            border : false,
            bodyStyle : 'padding:10px 10px 10px 10px',
            html : '<div class="xty_dialog-mainInstr">Es ist kein Projekt vorhanden</div>'
          };
          parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, 80, 'Effizienz'));
        }
      }
      ;

      var childItems = null;
      for ( var i = 0; i < record.data.children.length; i++) {// durchl�uft alle children und f�gt sie in panel ein
        var child = record.childNodes[i];
        if (child.data.children) {
          children = true;
          childrenChildPanel.title = 'Unterkampagnen';
          var childStore = new extVia.campaigns.statistics.main.createStore();
          childStore.add(child.data.children);
          childItems = extVia.campaigns.statistics.view.getPieChart(childStore);
          childrenChildPanel.add(extVia.campaigns.statistics.view.getChildChartPanel(childItems, 280,
              nodeChartHeight - 50, child.data.Name + " &raquo; Budget Ist"));
        }
      }
      ;

      // for(var i=0; i<record.data.children.length; i++ ){
      // var child = record.childNodes[i];
      // if(child.data.children){
      // childrenChildPanel.title='Unterkampagnen';
      // var childStore = new extVia.campaigns.statistics.main.createStore();
      // childStore.add(child.data.children);
      // childItems = extVia.campaigns.statistics.view.getPieChart(childStore);
      // childrenChildPanel.add(extVia.campaigns.statistics.view.getChildChartPanel(childItems, 280, nodeChartHeight-50,
      // child.data.Name+" &raquo; Budget Ist"));
      // }
      // };

      panel.add(parentChartsHost);
      if (children) {
        panel.add(childrenChildPanel);
      }

    } else {
      var store = extVia.campaigns.statistics.main.createStore();
      store.add(record.data);
      var items = extVia.campaigns.statistics.view.getColumnChart(store);
      parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
          'Budget Ist/Soll'));
      if (store.data.items[0].get('FGrad') != '') {
        items = extVia.campaigns.statistics.view.getGaugeChart(store);
        // parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
        // 'Fertigungsgrad'));
      } else {
        items = {
          border : false,
          bodyStyle : 'padding:10px 10px 10px 10px',
          html : '<div class="xty_dialog-mainInstr">Fertigstellung ist noch nicht angefangen</div>'
        };
        // parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, 80,
        // 'Fertigungsgrad'));
      }
      if (efficiency >= 0) {
        items = extVia.campaigns.statistics.view.getGaugeChartEfficiency(gaugeStoreEfficiency);
        parentChartsHost.add(extVia.campaigns.statistics.view.getChartPanel(items, nodeChartWidth, nodeChartHeight,
            'Effizienz: ' + record.get('Name')));
      } else {
        items = {
          border : false,
          bodyStyle : 'padding:10px 10px 10px 10px',
          html : '<div class="xty_dialog-mainInstr">Projekt ist noch nicht angefangen</div>'
        };
        parentChartsHost.add(extVia.campaigns.statistics.view
            .getChartPanel(items, nodeChartWidth, 80, 'Effizienz: ' + record.get('Name')));
      }
      panel.add(parentChartsHost);
    }

    for ( var j = 0; j < normalTree.items.items.length; j++) {// l�scht alte panels und f�gt neue ein
      if (j != 0 && normalTree.items.items[j].getXType() == 'panel') {
        normalTree.items.removeAt(j);
        normalTree.add(panel);
      } else {
        if (normalTree.items.items.length == 1) {
          normalTree.add(panel);
        }
      }
    }
  }

};

// init Object as singleton
extVia.campaigns.statistics.main = new extVia.campaigns.statistics.main();

/*
 * 
 * $Revision: 1.34 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/06 17:07:49 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */