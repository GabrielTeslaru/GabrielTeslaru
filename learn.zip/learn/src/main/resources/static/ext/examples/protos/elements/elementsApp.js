/**
 * 
 */
Ext.application({
    name: 'elements',
    
    version:'$Revision: 1.1.2.33 $',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerHeight = centerPan.getHeight();
      centerHeight-=25; // substract center-tabstrip 
      centerHeight-=66; // substract pagejobbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=60;  // substract pagetoolbar 
      }
      if (cfg && cfg.hasSubtabs){
        centerHeight-=30; // substract subtabstrip
      }      
      return centerHeight;
    },

    getCenterWidth : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerWidth = centerPan.getWidth()-50;    
      return centerWidth;
    },
    
    getWestListHeight : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
      return westHeight;
    },
    
    

    getCollectorView: function(cfg) {
      var me = this;
      Ext.define('Image', {
        extend: 'Ext.data.Model',
        fields: [
            { name:'src', type:'string' },
            { name:'caption', type:'string' }
        ]
    });

    var imagesStore  = Ext.create('Ext.data.Store', {
        id:'imagesStore',
        model: 'Image',
        dasta: [
            { src:'./img/20110215-feat-drawing.png', caption:'Drawing & Charts' },
            { src:'./img/20110215-feat-data.png', caption:'Advanced Data' },
            { src:'./img/20110215-feat-html5.png', caption:'Overhauled Theme' },
            { src:'./img/20110215-feat-perf.png', caption:'Performance Tuned' }
        ]
    });

    var imageTpl = new Ext.XTemplate(
        '<tpl for=".">',
            '<div style="margin-bottom: 10px;" class="thumb-wrap">',
              '<img style="height:160px;max-height:160px" height="160" src="{src}" />',
              '<br/><span>{caption}</span>',
            '</div>',
        '</tpl>'
    );

   var collectorView =  Ext.create('Ext.view.View', {
     itemId:'collectorView',
     cls:'xty_collector-view',
     viewConfig: {
       plugins: {
           ptype: 'gridviewdragdrop',
           dragGroup: 'collectorDDGroup',
           dropGroup: 'collectorDDGroup'
       },
       listeners: {
           drop: function(node, data, dropRec, dropPosition) {
               var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
               //Ext.example.msg("Drag from left to right", 'Dropped ' + data.records[0].get('name') + dropOn);
               //extVia.notify({action:'Drag from left to right'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
           }
       }
     },
     
     width:cfg.width,
     height:cfg.height,
     autoScroll:true,
        
     store: imagesStore, //Ext.data.StoreManager.lookup('imagesStore'),
     tpl: imageTpl,
     itemSelector: 'div.thumb-wrap',
     emptyText: 'No images available'
    });
      
    
    return collectorView;
    
    },
    
    
    
    // How should the Components be named?
    // propertysearch
    // property-searchfield 
    // propsearchfield
    // propsearch
    getPropsearchComboCfg: function(cfg) {
      var me = extVia.regApp;
      var loc = extVia.locales;
      

      

    var clearHandler= function(evt){
      var targetEl = Ext.get(evt.target.id); 
      var fieldId = targetEl.dom.parentNode.parentNode.parentNode.id;
      var field = Ext.getCmp(fieldId);
      if (field.isDirty()){field.setValue('');}
     };
   


 
    var searchResultNodesPanel;
    

    
    var searchResultCallCnt = 0;
    
    var searchResultHandler= function(field, evt){
        
      
       var  searchValue = field.getValue();
      
      
        var fieldIsEmpty = Ext.isEmpty(searchValue);
        
        field.getPicker().hide();

        if(field.resultPanel  && field.resultPanel.isHidden()){
          field.resultPanel.destroy();
          field.resultPanel = null;
        }
        
        if(field.resultPanel && fieldIsEmpty){
          field.resultPanel.destroy();
          field.resultPanel = null;
        }
        
        if(!field.resultPanel){
        
        var fieldPos = field.getPosition();

        
        var searchResultNodesPanelPos = [fieldPos[0]-100, fieldPos[1]+50];

        var nodesPanelAvailableHeight =  me.getCenterHeight();

        searchResultCallCnt++;
        var layout = (searchResultCallCnt%2===0) ? 'accordion' : 'vbox';

        //NodesListsPanel
        searchResultNodesPanel = Ext.create('extVia.ux.widgets.NodesListsPanel', {
         // itemId: 'accessAll-palette-panel',
          
          calleeCmp: field,
          
          searchValue: searchValue,
          
          
          renderTo: Ext.getBody(),
          width:420,
          height:nodesPanelAvailableHeight,
          //hidden: true,
          //y:-100,
          x:searchResultNodesPanelPos[0]+70,
          y: searchResultNodesPanelPos[1],

         // x:500, y:50,

          //layout: layout,
          autoScroll:true,
          closeAction:'hide',

          //style: 'opacity: 0;',

         showMXXe: function(){
           var me = this;

           me.getEl().animate({ duration: 200,to: {opacity: 1 }});
           //me.getEl().slideIn('t',{duration: 500 , easing: 'easeIn'  });
           //me.getEl().animate({ duration: 500,to: {opacity: 1 }});
          }

           });
        
        field.resultPanel = searchResultNodesPanel;
     
     
//        searchResultNodesPanel.showAt(0, 0, 
//          {duration: 100 , easing: 'bounceIn' ,        
//          to: {
//              opacity: 1
//          } 
//         });
      


      //searchResultNodesPanel.showAt(500,50);


      
      }

    };


    
    var autoCompleteStore =   Ext.create('Ext.data.Store', {
      fields: [ 'name','img', 'labeledType','value'], 
        data :  [ 
        {name:'a Roland 707', img:'' },  
        {name:'b Roland 727', img:'' },  
        {name:'c Roland 808', img:'' },  
        {name:'d Roland 909', img:'' },  
        {name:'Roland 627', img:'' },  
        {name:'Roland 707', img:'' }  
        ]
      });
    
    
    
    var propsearchComboCfg = {
      xtype:  'propsearchcombo',
      //itxxemId:'propsearchcombo',
      emptyText:'Want to search for something?', 
      displayField: 'name',
      store: autoCompleteStore,
      typeAhead:true,
      autocomplet:true,
      queryMode: 'local',

      defaultProp: 'Product',
      
      searchResultHandler:searchResultHandler
    };

      return propsearchComboCfg;
      
    },
    
    
    
    
    getNodesListsPanelCfg: function(cfg) {

      var me = this;
      
      //var  availableHeight = me.
      
      
      var nodesListsPanelCfg = {                              
           xtype:'nodeslistspanel',                     
           title:'nodesLists Panel Cfg'  ,  
           renderTo: Ext.getBody(),
           y:60,
           x:500,
           width:420,
           height:420
      };
      

      return nodesListsPanelCfg;
    },
    
    showNodesListsPanel: function(cfg) {
      var me = this;
      var nodesListsPanelCfg = me.getNodesListsPanelCfg({});
      var nodesListsPanel = Ext.create('extVia.ux.widgets.NodesListsPanel',  nodesListsPanelCfg );

      nodesListsPanel.show();

    },
    
    
    showEditorForListItem: function(itemIx) {

      var me = this;
      var elementsGrid = Ext.getCmp('elementsGrid');
      var view = elementsGrid.getView();
      
      var store = elementsGrid.getStore();
      var record = store.getAt(itemIx);
      
      me.showEditor(view, record, null, itemIx ); 
    },
  
    
    
    showEditor: function(view, record, item, index, evt ) {
      var me = extVia.regApp;
      var loc = extVia.locales;
      
      var epobType =  record.get('epobType');
      var  pgjobDscr =  loc.editType.replace(/\{type\}/,epobType);      
      var pgjobEpobDscr = record.get('name');

      var editorPgjobButtons =[
        //'->',
        me.getPropsearchComboCfg({})
        
       // {xtype:'tbspacer', width:4}
      ]; 
      var editorPagetoolbarButtons =[
        { itemId:'save',tooltip : 'Save'},         
        { itemId:'new',tooltip : 'New'},        
        { itemId:'collectionAddTo',tooltip : 'collectionAddTo'} 
        
      ]; 
      
      

      
      var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:pgjobDscr, epobDscr: pgjobEpobDscr,  pagetoolbarButtons: editorPagetoolbarButtons, pgjobButtons: editorPgjobButtons} );
      var editorMainTabItemId = 'elementsEditor'+ record.get('id'); //epob.epobId ; 
      var labelWidth = 180;
      var epobEditorPanelCfg = {
          title: pgjobEpobDscr, 
          applibarId:applibar.id,
          tbar : applibar,
          getApplicationBar:function(){
            return applibar;
          },
          setPagejobDscr : function setPagejobDscr(pgjobDscr){ applibar.setPagejobDscr(pgjobDscr);},
          setEpobDscr : function setEpobDscr(epobDscr){applibar.setEpobDscr(epobDscr);},
          getPagejobDscr : function getPagejobDscr(){applibar.getPagejobDscr(); },
          getEpobDscr : function getEpobDscr(){ return applibar.getEpobDscr(); },
          closable:true,
          active:true,
          itemId:editorMainTabItemId,
          //stateId:editorMainTabItemId,
          

         items:[
         
          {
                xtype:'tabpanel',
                border:false,
               // height: editorContentPanelHeight,
                activeTab:'textEntry',
                refresh:function(){extVia.notify({action: '"refresh on'  , mssg:  this.title});},
                tabBar:{  
                  
                  cls : 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',
                  
                  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
                  handler:function(button){
                      var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                      extVia.notify({action: 'Refresh Subtab'  , mssg:  '<b>'+activeTab+'</b>'}); 
                   },
                 iconCls:'x-tool x-tool-refresh'}]  }, 
                 

                 items:[
                  
                  
                  { title: epobType,
                    
                    border:false,
                    defaults:{ 
                      width:580, margin:'24 24 24 24' 
                     },
                   
                    items:[
                      {title:'Preview' },
                      {title:'General' },
                     {title:'Typespecific' },
                     {title:'Filespecific' },
                     {title:'Changeinfo' }
                   ]  
                  },
                  
                  
                  
                  {title:'Attributes' },
                  {title:'TextEntry' , 
                    itemId:'textEntry' ,
                    tbar:{height:42, cls:'xty-summernote-tbar-fake', 
                      items:[
                        {width:830, cls:'xty-summernote-tbar-fake-btns-btn', iconCls:'xty-summernote-tbar-fake-btns', height:36,margin:'0 0 0 0'},
                        {xtype:'tbfill', width: 12},
                       // me.getPropsearchComboCfg({}),
                        {xtype:'tbspacer', width: 4}
                        ]
                       },
                    
                    border:false,
                    items:[

                      me.getCollectorGrid({                      
                        width: me.getCenterWidth()+50,
                        height: 80 ,
                        renderTo:Ext.getBody(),
                        style:'position:absolute;',
                        hideHeaders:true
                        }),
                      
                      me.getCollectorView({                      
                        width: me.getCenterWidth()+50,
                        height: me.getEditorSubTabHeight()-80
                        })


                      
                      
//                       {
//                        xtype: 'htmleditor',
//                        border:false,
//                        bodyBorder:false,
//                        width: me.getCenterWidth()-4,
//                        height: me.getEditorSubTabHeight()-28,
//                        value:'123'
//                       }
                      
                    ]
                  
                  },
                  
                  {title:'Versions' },
                  {title:'Tasks' }
                  ]
              }
               
         ]// eo items    
      
     }; // eo epobEditorPanelCfg
      
      
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel(); 
      var epobEditorPanel = tabPanCenter.addAndActivate(
          epobEditorPanelCfg
        );
      
      
      var propsearchcombo = epobEditorPanel.getApplicationBar().getPagejobbar().getComponent('propsearchcombo');
      propsearchcombo.focus();
     
      
      var searchTask = new Ext.util.DelayedTask(function(){
        propsearchcombo.search(propsearchcombo);
      });
      searchTask.delay(10);

      
      
    },


    

    
    initWest: function() {

      var me = this;
      
      
      Ext.create('Ext.data.Store', {
        storeId:'elementsStore',
        fields:['id', 'epobType', 'name', 'status', 'responsible'],
        data:{'items':[
            {id:'1', epobType:'Text', name:'Flow 1', status:'Warning', responsible:'Ernie'  },
            {id:'2', epobType:'Text', name:'The UX of a banana', status:'Success', responsible:'Oskar'  },
            {id:'3', epobType:'Text', name:'Welt retten', status:'Started', responsible:'Grobi'  },
            {id:'4', epobType:'Audio', name:'Kuchen backen', status:'Danger', responsible:''  },
            {id:'5', epobType:'Graphic', name:'Datenbank zerstören', status:'Success', responsible:''  },
            {id:'6', epobType:'Video', name:'Produkte pflegen', status:'Waiting', responsible:''  },
            {id:'7', epobType:'Image', name:'Cola trinken', status:'Expired', responsible:''  }
        ]},
        proxy: {
            type: 'memory',
            reader: {
                type: 'json',
                root: 'items'
            }
        }
      });

      var epobTypeRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
          return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
        };
      var statusRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
          return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
        };

       var elementsGrid = Ext.create('Ext.grid.Panel', {
            id:'elementsGrid',
            itemId:'elementsGrid',

            viewConfig: {
              plugins: {
                  ptype: 'gridviewdragdrop',
                  //dragGroup: 'secondGridDDGroup',
                  dropGroup: 'firstGridDDGroup'
              },
              listeners: {
                  drop: function(node, data, dropRec, dropPosition) {
                      var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
                      //Ext.example.msg("Drag from left to right", 'Dropped ' + data.records[0].get('name') + dropOn);
                      extVia.notify({action:'Drag from left to right'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
                  }
              }
          },
          


             width: 400,
             border:false,
             store: Ext.data.StoreManager.lookup('elementsStore'),
             columns: [
                  { header: 'Typ',  dataIndex: 'epobType', width:32, renderer:epobTypeRenderer },
                  { header: 'Name',  dataIndex: 'name' ,  flex: 1},
                  { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
                  { header: 'Verantwortliche', dataIndex: 'client', 
                    renderer: function(){
                      var clientsHtml = 
                        '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
                          '<span class="xty_tag" title="Muppets">Muppets</span>' +
                          '<span class="xty_tag" title="Puppets" >Puppets</span>' +
                        '</span>';
                      return clientsHtml;
                    }
                  },
                { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
          ],
          height: 200,
              listeners:{
               itemdblclick: function( view, record, item, index, evt, eOpts ){
                me.showEditor(view, record, item, index, evt, eOpts);
               }
              
              }
         
      });

        var elementsList = {
            title:'Elemente',
            itemId:'elementsList',
            height: me.getWestListHeight(),
            tbar:[
            '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'Löschen', handler: me.deleteEpobDialog}
            ],
            items:[ elementsGrid ] ,
            bbxxar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
         };
      
      

         var collectorPanel  =  me.getCollectorPanel();
      
         var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
             tabBar:{ 
               tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
               handler:function(button){
                 var activeTab = button.ownerCt.ownerCt.getActiveTab();
                   extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                 }
                }
               ]
             },
             items:[elementsList, extVia.hierarchy.statics.getHierarchyTabCfg({elementsOnly:true, itemOpenEditor: me.showEditor}) ,collectorPanel   ]

             });
        extVia.regApp.myRaster.addToWest(tabPanWest);
    },
    
    
   
    
    

    getCollectorGrid: function(cfg) {
      
      var me = this;
      
      
      Ext.define('DataObjectCollector', {
        extend: 'Ext.data.Model',
        fields: ['name', 'imgSrc', 'column1', 'column2']
      });
      
//        var myData = [
//          { name : "Rec 0", column1 : "0", column2 : "0" },
//          { name : "Rec 1", column1 : "1", column2 : "1" },
//          { name : "Rec 2", column1 : "2", column2 : "2" },
//          { name : "Rec 3", column1 : "3", column2 : "3" },
//          { name : "Rec 4", column1 : "4", column2 : "4" },
//          { name : "Rec 5", column1 : "5", column2 : "5" },
//          { name : "Rec 6", column1 : "6", column2 : "6" },
//          { name : "Rec 7", column1 : "7", column2 : "7" },
//          { name : "Rec 8", column1 : "8", column2 : "8" },
//          { name : "Rec 9", column1 : "9", column2 : "9" }
//      ];
//
//      // create the data store
//      var firstGridStore = Ext.create('Ext.data.Store', {
//          model: 'DataObjectCollector',
//          data: myData
//      });


      // Column Model shortcut array
      var columns = [
          {text: "Record Name", flex: 1, sortable: true, dataIndex: 'name'},
          {text: "column1", width: 70, sortable: true, dataIndex: 'column1'},
          {text: "column2", width: 70, sortable: true, dataIndex: 'column2'}
      ];


      var collectorGridStore = Ext.create('Ext.data.Store', {
          model: 'DataObjectCollector'
      });

      // create the destination Grid
      
      

      
      var dropData = 
        [
          
          { caption:'ABC', epobType:'Image', src: "../img/fakes/previews/metabo/A1_602000.jpg", isChild: true},
          { caption:'DEF', epobType:'Image', src: "../img/fakes/previews/metabo/A1_602190.jpg", isChild: true},
          { caption:'GHI', epobType:'Image', src: "../img/fakes/previews/metabo/A2_600500.jpg", isChild: true},
          { caption:'JKL', epobType:'Image', src: "../img/fakes/previews/metabo/A2_602150.jpg", isChild: true},
          { caption:'MNO', epobType:'Image', src: "../img/fakes/previews/metabo/A3_600500.jpg", isChild: true},
          { caption:'PQR', epobType:'Image', src: "../img/fakes/previews/metabo/A4_602000.jpg", isChild: true},
          { caption:'STU', epobType:'Image', src: "../img/fakes/previews/metabo/A4_602400.jpg", isChild: true},
          { caption:'VWX', epobType:'Image', src: "../img/fakes/previews/metabo/P_602100.jpg", isChild: true},
          { caption:'XYZ', epobType:'Image', src: "../img/fakes/previews/metabo/P_602140.jpg", isChild: true},
          { caption:'XYZ', epobType:'Image', src: "../img/fakes/previews/metabo/P_602400.jpg", isChild: true},
          
          { src:'../img/fakes/previews/roland/71YFVyMwaIL._SY679_.jpg', caption:'Drawing & Charts' },
          
          { src:'./img/20110215-feat-drawing.png', caption:'Drawing & Charts' },
          { src:'./img/20110215-feat-data.png', caption:'Advanced Data' },
          { src:'./img/20110215-feat-html5.png', caption:'Overhauled Theme' },
          { src:'./img/20110215-feat-perf.png', caption:'Performance Tuned' }
      ];
      
      var dropCount = 0;
      
      
      var collectorGrid;
      
      collectorGrid = Ext.create('Ext.grid.Panel', {
          cls:'xty_collector-grid',
          width:cfg.width,
          height:cfg.height,
          hideHeaders:cfg.hideHeaders,
          border:false,
          viewConfig: {
              plugins: {
                  ptype: 'gridviewdragdrop',
                  //dragGroup: 'secondGridDDGroup',
                  dropGroup: 'firstGridDDGroup'
              },
              listeners: {
                  drop: function(node, data, dropRec, dropPosition) {

                      var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
                      //Ext.example.msg("Drag from left to right", 'Dropped ' + data.records[0].get('name') + dropOn);
                      //extVia.notify({action:'Drag from left to right'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
                     // var collectorView = Ext.getCmp('collectorView');
                      
                      var collectorView = collectorGrid.ownerCt.getComponent('collectorView'); // Why not
                      
                      //collectorView.getStore().loadData( [   dropData[dropCount] ] , true );
                      
                      collectorView.getStore().loadData( [   dropData[dropCount] ] , true );
                      
                      dropCount++;
                      
                  }
              }
          },
          store            : collectorGridStore,
          columns          : columns,
          stripeRows       : true
      });


     return collectorGrid;
      
    },    
    
    getCollectorPanel: function() {
      var me = this;
      var collectorGrid = me.getCollectorGrid({});
      var collectorPanel = Ext.create('Ext.Panel', {
          border:false,
          height  : me.getWestListHeight(),
          tbar:[
            '->',  {iconCls: 'xty_pgtoolbar-thumbsBig ', itemId:'thumbsBig'}, {iconCls: 'xty_pgtoolbar-thumbsSmall', itemId:'thumbsSmall'},{iconCls: 'xty_pgtoolbar-share',itemId:'share',  tooltip:'share'}
            ],
          title:'Collector',
          layout       : {
              type: 'hbox',
              align: 'stretch'
              //padding: 5
          },
          defaults     : { flex : 1 }, //auto stretch
          items        : [
            collectorGrid
          ],
          dockedItems: {
              xtype: 'toolbar',
              dock: 'bottom',
              items: ['->', // Fill
              {
                  text: 'Reset',
                  handler: function(){
                    collectorGrid.getStore().removeAll();
                  }
              }]
          }
      });
      return collectorPanel;
    },
    
    initCollectorTab: function() {
      var me = this;
      var collectorPanel = me.getCollectorPanel({});
      var tabPanWest = extVia.regApp.myRaster.getWestTabPanel();
      tabPanWest.addAndActivate(collectorPanel);
    },
    
    
    
    launch: function() {
      
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      var me = this;

      
      var  modulDscr = 'elements';


      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.constants.raster.mainWestWidth = 360;
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr, psropsearchEnabled: true});
      extVia.ui.page.raster.onReady(this);


      me.initWest();
     


      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
        handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
        iconCls:'x-tool x-tool-refresh'}]  }
      });

      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      
      
      // if you ned an extra App Panel:  elements-Module
      var elementsModalMask ;
      
       var elementsModuleAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Elements Editor', epobDscr: 'Module',  
         pgjobButtons: [
           //me.getPropsearchComboCfg({}),
           {xtype:'tbspacer', width:40}
         ]
         } 
       );
       

    
       var elementsModulePanel = {title:'elements', tbar: elementsModuleAppbar, closable:true,
       defaults:{
         margin:'24 24 24 24',
         collapsible:true,
         width:580
       }
       };
       

       tabPanCenter.addAndActivate(elementsModulePanel);
       
       me. showEditorForListItem(1);
       
      // me.showNodesListsPanel({});


    }
});



/*
 * 
 * $Revision: 1.1.2.33 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2019/05/03 14:35:45 $
 * $Author: slederer $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 
