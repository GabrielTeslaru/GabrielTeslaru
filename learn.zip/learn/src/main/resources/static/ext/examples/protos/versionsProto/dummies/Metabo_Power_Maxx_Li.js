extVia.versionsProto.Metabo_Power_Maxx_Li = 
[
// Metadata areaorder: 1              
{"name":"Hierarchie","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Akkuger\u00E4te  \u00bb Akku-Bohrschrauber","userWork":"Douglas Crockford","changedateWork":"06.02.2014","changetimeWork":"11:03:14","valueVersion":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Stichs&auml;ge","userVersion":"Paul Coelho","changedateVersion":"06.02.2014","changetimeVersion":"11:03:23","epimIdWork":"ms_h-2","epimIdVersion":"ms_h-2"},                    
{"name":"Name","area":"Metadata","areaorder":"1","dataType":"String","valueWork":"Metabo Power Maxx Li","userWork":"Lars Hinrichs","changedateWork":"05.02.2014","changetimeWork":"16:32:23","valueVersion":"Metabo STEb","userVersion":"Doug Engelbart","changedateVersion":"05.02.2014","changetimeVersion":"16:32:27","epimIdWork":"ms_n-1","epimIdVersion":"ms_n-1"},
{"name":"Id","area":"Metadata","areaorder":"1","dataType":"Number","valueWork":"33473","userWork":"Douglas Crockford","changedateWork":"05.02.2014","changetimeWork":"16:30:26","valueVersion":"3","userVersion":"Douglas Crockford","changedateVersion":"05.02.2014","changetimeVersion":"16:30:26","epimIdWork":"mn_i-1","epimIdVersion":"mn_i-1"},

];

