
/**
 * Provides acces to elasticsearch Server
 */
Ext.define('extVia.elastic.statics', {
    statics: {

    getObjectModelCfg : function(){
      var objectModelCfg =  {
        fields : [{
         name : 'epimId',
         mapping : '_source.epimId',
         type : 'int'
         }, {
         name : 'name',
         type : 'string',
         mapping : '_source.name'
         }, {
         name : 'typeId',
         mapping : '_source.epob_type_Id',
         type : 'int'
         }, {
         name : 'creationDate',
         mapping : '_source.epob_type_Id',
         type : 'date'
         }, {
         name : 'creationUser',
         type : 'string',
         mapping : '_source.creation_user'
         }, {
         name : 'changeDate',
         type : 'date',
         mapping : '_source.change_date'
         }, {
         name : 'changeUser',
         type : 'string',
         mapping : '_source.change_user'
         }, {
         name : 'hierarchies',
         type : 'string',
         mapping : '_source.hierarchy_names'
         }
      ]
     };
     return objectModelCfg;
    },

    getElementModelCfg : function(){
	   var elemntModelCfg=  {
	      fields : [{
	         name : 'rootId',
	         type : 'int',
	         mapping : '_source.root_obje_id'
	       }, {
	         name : 'filename',
	         type : 'string',
	         mapping : '_source.phy_file_name'
	       }, {
	         name : 'extension',
	         type : 'string',
	         mapping : '_source.phy_file_extension'
	       }, {
	         name : 'directory',
	         type : 'string',
	         mapping : '_source.phy_directory'
	       }, {
	         name : 'previewUrl',
	         type : 'string',
	         mapping : '_source.phy_preview_file'
	       }, {
	         name : 'originalFilename',
	         type : 'string',
	         mapping : '_source.orig_file_name'
	       }
	    ]
	   };
      return elemntModelCfg;
    },

    getImageModelCfg : function(){
     var imageModelCfg =  {
      fields : [{
         name : 'height',
         type : 'int',
         mapping : '_source.imag_height'
         }, {
         name : 'width',
         type : 'int',
         mapping : '_source.imag_width'
         }, {
         name : 'color',
         type : 'string',
         mapping : '_source.imag_colouring'
         }, {
         name : 'compressionRate',
         type : 'string',
         mapping : '_source.imag_compression_rate'
         }, {
         name : 'resolution',
         type : 'string',
         mapping : '_source.imag_resolution'
         }
      ]
      };
      return imageModelCfg;
    },

    getElasticResponse : function(){
     return extVia.dummies.elasticResponse;
    },

    // >>> PROD V4 Start (EPIM-7678) <<<
    baseUrl : 'http://localhost:9200/',
    // >>> PROD V4 End (EPIM-7678) <<<
    getElementsUrl : function(cfg){
     var me = this;
     return me.baseUrl+'ele_de/elementdata/_search';
    },

    categoryTreeFirstLevelIds : [5,6],
    getCategoryTreeRoot : function(callback) {
    	var me = this,
    		records,
    		store,
    		params,
    		hierarchyCache;

	    store = Ext.create('Ext.data.Store', {
		   model :  'ExtVia.model.elastic.Element',

		   proxy : {
	           type : 'ajax',
	           url : me.getElementsUrl(),
	           limitParam : 'size',
	           startParam : 'from',
	           actionMethods : {create: 'POST', read: 'POST', update: 'POST', destroy: 'POST'},
	           reader : {
	               type : 'json',
	               root : 'hits.hits',
	               totalProperty : 'hits.total',
	               successProperty : '_shards.successful'
	           }
		   },

		   listeners : {
		   	load : function(store, records) {
		   		hierarchyCache = Ext.create('ExtVia.util.HierarchyCache', {
		   			expandeLeafs : false,
		   			defaultNodeCls : 'xty_epobCategory',
		   			model :  'ExtVia.model.elastic.Element'

		   		});
		   		hierarchyCache.load(records);
		   		callback(hierarchyCache.toRoot("Kategorien"));
		   	}
		   }
	     });

	     params = {
	     	size: 39671,
			 query : {
			 	filtered : {
			 		query : {
			 			match_all : {}
			 		},
			 		filter : {
			 			bool : {
			 				must : [me.getCategoryFilters()]
			 			}
			 		}
			 	}
			 },
			  sort: [
			    {
			      'name.raw': {
			        order: 'asc'
			      }
			    }
			  ]
	     };

	     store.load({params:Ext.encode(params)});
    },

    getCategoryFilters : function() {
    	return [{
			 		exists : {
			 			field : "hierarchy_names"
			 		}
			 	}, {
 					fquery : {
 						query : {
 							query_string: {
 								fields : ["hierarchy_ids"],
 								query : this.categoryTreeFirstLevelIds.toString().replace(/,/gi, " ")
 							}
 						},
 						_cache : true
 					}
	 			}
    	];
    },

    getObjectElementImageFields : function(cfg){
      var objectModelCfg  =  extVia.elastic.statics.getObjectModelCfg();
      var elementModelCfg  =  extVia.elastic.statics.getElementModelCfg();
      var imageModelCfg  =  extVia.elastic.statics.getImageModelCfg();
      var objectElementImageFields = Ext.Array.union( objectModelCfg.fields, elementModelCfg.fields, imageModelCfg.fields );
      return objectElementImageFields;
    },

    getObjectElementImageDummyData : function(cfg){
	    var objectElementImageFields = extVia.elastic.statics.getObjectElementImageFields();
	    var elasticResponse =  extVia.dummies.elasticResponse;
	    var objectElementImageDummyData = [];
	    var ei;
	    for (ei=0; ei<elasticResponse.hits.hits.length; ei++){
	      var elasticRow = elasticResponse.hits.hits[ei]._source;
	      var row = {};
	      //field  Mapping
	      var mappingFields = objectElementImageFields;
	      var mi;
	      for (mi=0; mi<mappingFields.length; mi++){
	       var field = mappingFields[mi];
	         var mapping = field.mapping.replace(/_source./,'');
	         row[field.name] = elasticRow[mapping];
	      }
	      objectElementImageDummyData.push(row);
	    }
       return objectElementImageDummyData ;
    },

    getObjectElementImageDummyStore : function(cfg){
	  var objectElementImageFields = extVia.elastic.statics.getObjectElementImageFields();
	  var ObjectElementImageModel = Ext.define('ObjectElementImageModel', {
	    extend: 'Ext.data.Model',
	    field: objectElementImageFields
	  });
	  var store;
      var objectElementImageDummyData = extVia.elastic.statics.getObjectElementImageDummyData();
      store = Ext.create('Ext.data.Store', {
        model: 'ObjectElementImageModel',
        data: objectElementImageDummyData
      });
      return store ;
    },


    /**
     * mapping UI queryCfg to elastic queryParams
     * @param {} uiQueryCfg
     * @return {}
     */
	getElasticQueryParams : function(uiQueryCfg){

	// Finde Alles
	 var query = {match_all : {} },
	 must = [],
	 filter = {},
	 categoryFilters = {bool : {should : []}},
	 epobTypeFilters = {bool : {should : []}},
	 uiconfig = {
	  searchtext : 'Maschine',
	  filters : [{ value : 'Produkt-Bild:Preisliste sw', type:'Category'}  // Produkt-Bild ist ein Category // filters is Category filter only
	  ]
	};

	uiconfig = uiQueryCfg;

	if (uiconfig.searchtext) {
	  query = {
	     query_string : {
	       fields : ["name", "epimId"],
	       query : uiconfig.searchtext, //  + '*' Wild card nur wenn MATCHING = contains nicht WORD
	       lenient : true //Damit kein Exception geworfen wird, falls die Zahl ung�ltig ist (wegen epimId).
	     }
	  };
	}

	// mapping UI-Filters to elasticFilters
	if (uiconfig.filters) {
	    Ext.Array.forEach(uiconfig.filters, function (filter) {
	    	if (filter && filter.type){
		    	switch(filter.type) {
		    		case 'Category' :
				       categoryFilters.bool.should.push({
				         fquery : {
				           query : {
				          // >>> PROD V4 Start (EPIM-3513) <<<
				              wildcard : {
				                "hierarchy_names.hierarchyfacet" : {
				                  //value : searchCat
			                      value : filter.value + '*' // place parent Category logic here
			                      // value : filter.value + '*' // place parent Category logic here
				                }
				    // >>> PROD V4 End (EPIM-3513) <<<
				              }
				           },
				           _cache : true
				         }
				       });

		    		break;

		    		case 'epobType' :
		    			if(filter.value === extVia.enums.EpimObjects.ELEMENTS.id) {
		    				break;
		    			}
		    			epobTypeFilters.bool.should.push({
		    				term : {
		    					epob_type_Id : filter.value
		    				}
		    			});
		    		break;
		    	}
	      }
	  });

	  if(categoryFilters.bool.should.length > 0) {
	  	must.push(categoryFilters);
	  }
	  if(epobTypeFilters.bool.should.length > 0) {
	  	must.push(epobTypeFilters);
	  }
	  must = must.concat(this.getCategoryFilters());
	  filter.bool = {must:must};
	}


	// paramObj neede from elasticSearch

    var startFromIndex =  (uiconfig.pageStartsFrom - 1) * uiconfig.pageSize ;
    if (startFromIndex<0){startFromIndex=0;}
	var params = { size:uiconfig.pageSize, from: startFromIndex , query : {filtered : {query : query, filter : filter}}};
    return params;
    }

    }// eo statics
});
