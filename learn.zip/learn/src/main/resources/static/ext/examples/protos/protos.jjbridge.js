Ext.namespace('extVia.protos.jjbridge');
/**
 * @class extVia.protos.jjbridge
 * Routes to simulated backend delivering dummy-data
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2013/05/24 16:48:31 $
 *            $Revision: 1.3 $
 */

extVia.protos.jjbridge = function(config){
  Ext.apply(this,config,{    
    id          : "extVia.protos.jjbridge",
    name        : "extVia.protos.jjbridge"
  });
};
    
extVia.protos.jjbridge.prototype = {
	
	
	/**
	 * 
	 * @param callScope
	 * @param handlerName
	 * @param methodName
	 * @param parameterArray
	 * @param callbackFunction
	 * @returns
	 */		
	callRemote : function callRemote(callScope, handlerName, methodName, parameterArray, callbackFunction) {
		var result;
		var ex;
		
		try{
			result = extVia.backendSimlet[methodName](parameterArray);		
		}
		catch(remoteEx){
			if (typeof remoteEx === 'string'){
				remoteEx  = "<b>handler: </b>"+handlerName+"<br>"+"<b>method: </b>"+methodName+"<br>" +remoteEx ;
			}
			else {remoteEx.methodName = methodName;remoteEx.handlerName = handlerName;};
			ex = remoteEx ;
		}

        if(callbackFunction !== undefined && callbackFunction !== null){
          return callbackFunction(result, ex);
        }else{
          return result;
        }		
    },
		
    
    ////////////////// START copy from ~/jsp/js/jjbridge/base.js   13.05.2013 /////
    /**
     * Extract the javascript object from the returned json, forcing or not the unmarshall. 
     * 
     * @param {} result           The result returned by the server (through the bridge).
     * @param {} bForceUnmarshall Force or not the unmarshall.
     * @return {}                 The extracted javascript object.
     */
   getJSObjectFromResult : function getJSObjectFromResult(result, bForceUnmarshall) {
      if(result === null || result === undefined){
        throw new Error("jjbridge server error [result was "+result+"]");
      }
      var resultItem = toJSON(result);
      var oJSONObj = eval('(' + resultItem.json + ')');
      if (bForceUnmarshall) {
        oJSONObj = eval((typeof oJSONObj === 'string') ? '(' + oJSONObj + ')' : oJSONObj);
      }
      return oJSONObj;
    }
    
    //////////// END copy /////////////////////   
	    
  
};


extVia.protos.jjbridge = new extVia.protos.jjbridge();
jjbridge = extVia.protos.jjbridge;


/*
 * 
 * $Revision: 1.3 $
 * $Modtime: 17.05.13 9:56 $ 
 * $Date: 2013/05/24 16:48:31 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 