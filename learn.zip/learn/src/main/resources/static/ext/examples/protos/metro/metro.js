/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

Commercial Usage
Licensees holding valid commercial licenses may use this file in accordance with the Commercial Software License Agreement provided with the Software or, alternatively, in accordance with the terms contained in a written agreement between you and Sencha.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/
Ext.onReady(function() {
	
	
	
	
	
	var  getMengenStore  =    function getMengenStore(){
	   	  
	   	  var mengenData =[]; 
	   	  
	   	  var type ="fqwf";
	   	  
	   	  for (var i =0; i<9; i++){
	   		if (extVia.ui.page.strings.epobs.epobTypeIds[i]){
	   			type =   extVia.module.epob.getEpobTypeFromTypeId (	extVia.ui.page.strings.epobs.epobTypeIds[i]);
	   		}
	   		else{
	   			type =   extVia.module.epob.getEpobTypeFromTypeId (	extVia.ui.page.strings.epobs.epobTypeIds[2]);
	   		}
	   		
	   		//if (!type)type =   extVia.module.epob.getEpobTypeFromTypeId (	extVia.ui.page.strings.epobs.epobTypeIds[2]);
	   		  
	   		
	   		var typeImg ='<img title="'+type+'" src="../img/epobs/e_'+type.toLowerCase()+'_var.png" width="16px" style="margin-left:4px" />';
	   		
	   		
	   		var path ='root';//  'dieses &raquo; jenes &raquo; selles';
	   		var changeDate ="30.11.2012"
	   		
	   		if (i%5==0){
	   			path ='dieses &raquo; sonderbares &raquo; spezialformate &raquo; substitute';
	   			changeDate ="20.11.2006";
	   		}
	   		else if (i%3==0){
	   			path ='ebene 1 &raquo; ebene 2 &raquo; ebene 3';
	   			changeDate ="13.12.2004";	
	   		}
	   		else if (i%2==0){
	   			path ='level 1 &raquo; level 2';
	   			changeDate ="22.10.2008";	
	   		}

	   		
	   		mengenData.push(  { typ: typeImg,changeDate: changeDate, image:'<img src="../img/icons/asThumbsAspect.gif" widdth="48px" hedight="32px" style="" />', name:type+" "+i, path:path, epimId:i*17, parentId:i*19});
	   	  };
	   	  

	   	  
	     var mengenModel = 	Ext.define('Mengen', {
	    	    fields: [{name:'typ'},{name: 'image'},{name: 'name'},{name: 'path'},{name: 'epimId'},{name: 'parentId'}, {name:'changeDate'}],
	    	    extend: 'Ext.data.Model'
	    	});

	    	var mengenStore =   Ext.create('Ext.data.Store', {
	    	    model: mengenModel, //"Mengen",
	    	    storeId:'mengenStore',
	    	    pageSize:5,
	    	    data: mengenData,
	    	    proxy: {type: 'memory'}
	    	});
	    	
	    	//mengenStore.load({start :0, limit:25});
	    	
	    	return mengenStore;	
	    };
	    getMengenStore();
	
	
	
	var unit = 20;
	var unitH = unit/2;
	var unitQ = unit/4; //(subunit)
	
	
	//var tileSide = 8.5 * unit;
	var baseTileSide = 16 * unitH;

	var tileMargins = 2*unitH ;
	
	
	var openUrl =  function openUrl(url, target, targetDscr){
		  var result = null;
		  window.focus();
		  result = window.open(url);
		  return result;	
		};
	
	
	var tileclickHandler = function tileclickHandler(element){	
		var cmp  = Ext.getCmp(this.id);
		
		if (cmp.url){
			openUrl(cmp.url);
		}
	}; 
	
    
	
/**
 *     
 *  value : Object The data value for the current cell
 *  metaData : Object  A collection of metadata about the current cell; can be used or modified by the renderer. Recognized properties are: tdCls, tdAttr, and style.
 *  record : Ext.data.Model The record for the current row
 *  rowIndex : Number The index of the current row
 *  colIndex : Number The index of the current column
 *  store : Ext.data.Store The data store
 *  view : Ext.view.View The current view
 */
	var uebersichtItemRenderer = function uebersichtItemRenderer(  value, metaData , record , rowIndex , colIndex , store , view ){
		
		var valMargLeft ="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		
		var retStr = 
		
			'<div style="float :left">'+
				'<div style="flosat:right"> '+
					'<img style="width:48px;height:48px" src="../img/icons/thumbsSmall_32.png"/>'+
				'</div>'+	
				
				'<div style="position: absolute;margin-left:42px; margin-top:8px"> '+record.data.typ+'</div>'+
			'</div>'+
			
			'<div style="font-size:14px;font-weight:boldd">&nbsp;&nbsp;&nbsp;&nbsp;'+value+'</div>'+
			'<div title="path">'+valMargLeft+'&raquo;  j'+record.data.path+'</div>'+
			'<div><span title="epimId">'+valMargLeft+record.data.epimId+ '</span>'+  valMargLeft+  '<span  title="change Date">' +record.data.changeDate+'</span></div>'+
			'<div></div>';
			
			
		return retStr;
	};
	
	
	
    var groupsPanel = Ext.create('Ext.Panel', {
        id:'groups-panel',
        cls:'metro-hub-group',
		border:false,
		x:120,
		margins:'0 0 0 120',
		width:840,
		height:578,
        layout: {
            type: 'table',
            columns: 5
        },
        defaults: { preventHeader:true, cls:'tile groups-tile', width:baseTileSide, height: baseTileSide, listeners:{element: 'el', click: tileclickHandler}	},
        items:[
   
                   
		// ,url:'', html:'<div class="tile-dscr dscr" ></div>'

               
		{ title:'gr1�Item1 ', cls:'tile groups-tile groups-tile-left groups-tile-top turkis', url:'http://vimeo.com/30032597' ,html:'<div class="tile-dscr dscr" >Metro principles and personality</div>' },
		{ title:'gr1�Item2', cls:'tile groups-tile tile-large groups-tile-top orange', colspan:2, rowspan: 2, width:2*baseTileSide+10, height:2*baseTileSide+10, url:'http://msdn.microsoft.com/en-us/library/windows/apps/hh872191'  ,
			html:'<div class="tile-dscr dscr" >Laying out an app page</div><div class="tile-dscr-medium dscr" >Understanding the windows 8 silhouette</div>' },
        { title:'gr1�Item4', cls:'tile groups-tile groups-tile-top gras',  url:'http://msdn.microsoft.com/en-us/library/windows/apps/hh761491.aspx', html:'<div class="tile-dscr dscr" >tile template guidelines</div>'},
        { title:'gr1�Item5', cls:'tile groups-tile groups-tile-top orangeYellow'},
        
        { title:'gr1�Item6', cls:'tile groups-tile groups-tile-left purple' ,url:'http://msdn.microsoft.com/en-us/library/windows/apps/hh761500', html:'<div class="tile-dscr dscr" >Navigation design</div>' },
        { title:'gr1�Item7', cls:'tile groups-tile groxxups-tile-left' ,url:'http://msdn.microsoft.com/en-us/library/windows/apps/hh761499', html:'<div class="tile-dscr dscr" >Commanding design</div>'},
        { title:'gr1�Item8', cls:'tile groups-tile groxxups-tile-left preusic' , url:'http://msdn.microsoft.com/en-us/library/windows/apps/hh700394', html:'<div class="tile-dscr dscr" >Guidelines for fonts</div>'  },
        
        
        { title:'gr1�Item9',  cls:'tile groups-tile groups-tile-left viared', 
        	html: 
        		"<img style=' width:"+(2*baseTileSide+10)+"px;hseight:"+baseTileSide+"px;' src='../img/spacer'/>"+
        		"<img style='paddsing-top:30px;margin-top:-10px; width:"+(2*baseTileSide+10)+"px;hseight:"+baseTileSide+"px;' src='./img/metroPressed.gif'/>"},
       
        { title:'gr1�Item10', cls:'tile groups-tile gxxroups-tile-left '},
        { title:'gr1�Item11', cls:'tile groups-tile zinnober', url:'http://aozora.github.com/bootmetro/', html:'<div class="tile-dscr dscr" >bootmetro</div>'},
        { title:'gr1�Item12', cls:'tile groups-tile vmbgLight', url:'https://github.com/aozora/bootmetro', html:'<div class="tile-dscr dscr" >bootmetro github</div>'},
        { title:'gr1�Item13', cls:'tile groups-tile grxxoups-tile-left respmetro', url:'http://themeforest.net/item/start-metro-ui-responsive-admin-template/full_screen_preview/3408505', html:'<div class="tile-dscr dscr" >resp metro</div>' },
        
        
       
        
        ]
    });
	
    
    
    
    var groupsPanel2 = Ext.create('Ext.Panel', {
        id:'groups-panel2',
        cls:'metro-hub-group',
		border:false,
		//x:620,
		x:160,
		height:578,
        layout: {
            type: 'table',
            columns: 5
        },
        defaults: { preventHeader:true, cls:'groups-tile', width:baseTileSide, height: baseTileSide, listeners:{element: 'el', click: tileclickHandler}	},
        items:[
         
		//{ title:'gr2�Item1' , cls:'tile groups-tile groups-tile-left groups-tile-top zinnober'},
		{ title:'gr2�Item2', cls:'tile groups-tile groups-tile-top groups-tile-left gras', colspan:3, rowspan: 2, width:3*baseTileSide+20, height:2*baseTileSide+10,
			
		items:[
		       
		
		       
		       
		       
Ext.create('Ext.grid.Panel', {
	 
 	height:2*baseTileSide+15,
 	
 	width:3*baseTileSide+20 - 40,
 	x:unit,
 	
 	tbar : extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:"&Uuml;bersichtsliste",  pgjobbarHeight:58} ), 
 	
 	// paging bar on the bottom
    bbar: Ext.create('Ext.PagingToolbar', {
        store: Ext.data.StoreManager.lookup('mengenStore'),
    	//pageSize : 25,
    	style:'opacity:0.5',
    	border:true,
    	displayInfo: true,
        displayMsg: 'Displaying topics {0} - {1} of {2}',
        emptyMsg: "No topics to display",
        ixtems:[
            '-', {
            text: 'Show Preview'
        }]
    }),
    
    
    
	 border:false,
	 hideHeader_s:true,
	 style:'position:absolute;top:-22px !important;',
	 store: Ext.data.StoreManager.lookup('mengenStore'),
	 //selModel: Ext.create('Ext.selection.CheckboxModel'),
	 columns: [
	     { header: 'Single', dataIndex: 'name'  , width:3*baseTileSide+20 - 40, renderer:uebersichtItemRenderer},
	     { header: 'Typ', dataIndex: 'typ'  , width:36 ,hidden:true},
	     { header: 'Bild', dataIndex: 'image', width:60 ,hidden:true},
	     { header: 'Name',  dataIndex: 'name', width:180 ,hidden:true },
	     { header: 'Pfad',  dataIndex: 'path', flex: 1 ,hidden:true },
	     { header: 'EPIM-Id', dataIndex: 'epimId' , width:60 ,hidden:true},
	     { header: 'Eltern-Id', dataIndex: 'parentId'  , width:60  ,hidden:true},
	     { header: '&Auml;nderung', dataIndex: 'changeDate'  , width:90 ,hidden:true }
	 ]
	 })


		  
		       ] // eo items
		
		
		
		},
        { title:'gr2�Item4', cls:'tile groups-tile groups-tile-top' },
        { title:'gr2�Item5', cls:'tile groups-tile groups-tile-top orange'},
        
        //{ title:'gr2�Item6', cls:'tile groups-tile groups-tile-left vmbgLight' },
        { title:'gr2�Item7', cls:'tile groups-tile groxxups-tile-left metnav',url:'http://codecanyon.net/item/metnav-a-jquery-navigation-menu-based-on-metro-ui/full_screen_preview/3209194', html:'<div class="tile-dscr dscr" >jquery metnav</div>'},
        { title:'gr2�Item8', cls:'tile groups-tile groxxups-tile-left black' ,url:'http://www.drewgreenwell.com/projects/metrojs#fiddleAround', html:'<div class="tile-dscr tile-dscr-xxlarge dscr" >Metro JS</div>'},
        
        // >>> PROD V4 Start (EPIM-7678) <<<
        { title:'gr2�Item9',  cls:'tile groups-tile groups-tile-left hskaappventure'},
        { title:'gr2�Item10', cls:'tile groups-tile gxxroups-tile-left vmbgLight'},
        // >>> PROD V4 End (EPIM-7678) <<<
        { title:'gr2�Item11', cls:'tile groups-tile purple'},
        { title:'gr2�Item12', cls:'tile groups-tile vmbgDark'},
        { title:'gr2�Item13', cls:'tile groups-tile grxxoups-tile-left chocolate',  url:'http://bradfrostweb.com/blog/web/responsive-nav-patterns/' , html:'<div class="tile-dscr dscr" >responsive navigation patterns</div>'},
        ]
    });
    
    
    
	var panel = Ext.create('Ext.Panel', {
        id:'silhouette-panel',
        baseCls:'x-plain',
        renderTo: Ext.getBody(),
        lasyout: {
            type: 'table',
            columns: 2
        },
        defaults: { preventHeader:true, cls:'silhouette-tile'},
        
       // tbar:{items:[{text:'raster'}], height:48},
        
        bbar:{	
        	height:54,
        	border:false,
        	items: [
        	        
        	        '->',
        	        {tsext:'raster', 
        	        	iconCls:'metro-charms-raster',
        	        	height:48,width:48,
        	        	scale:'large',
        	        	overCls:'metro-charms-over',
        	        	pressedCls:'metro-charms-over',
        	        	//enableToggle:true,
        	        	handler:function(){
        	        		
        	        		if (Ext.getBody().hasCls("raster")){
            	        		Ext.getBody().removeCls("raster");
            	        		this.toggled = true;
        	        		}
        	        		else{
            	        		Ext.getBody().addCls("raster");
            	        		this.toggled = false;
        	        		}
        	        	}}

        	        ]
        	},
        
        	
        items:[                
			{tityle:"marginTop" , x:120, border:false, colspan:2, width:860, height:140, cls:'silhouette-tile ', html:'<div style="margin-top:30px;font-size:48pt;font-family: Segoe UI, Frutiger, Frutiger Linotype">Application header<div>'},
			
			Ext.create('Ext.Panel', {
		        id:'content-panel',
		        border:false,
		        autoScroll:true,
		        layout: {
		            type: 'table',
		            columns: 2
		        },
		        defaults: { preventHeader:true},
		        items:[                
					groupsPanel,
					groupsPanel2
					]
				})

			]
		});
	
	
	
	
	
});



/*
 * 
 * $Revision: 1.12.12.1 $
 * $Modtime: 02.11.12 12:39 $ 
 * $Date: 2019/12/10 10:53:02 $
 * $Author: lowen $
 * $viaMEDICI Release: 3.9 $
 * 
 */


