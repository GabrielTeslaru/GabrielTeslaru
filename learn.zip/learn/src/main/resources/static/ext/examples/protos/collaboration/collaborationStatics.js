


Ext.define('extVia.collaboration.statics', {
    statics: {

 
  notify : function(cfg, status, action){
    var me = extVia.collaboration.statics;
    var html = cfg;
    
    var stacy ='Information';
    var acy ='Collab';
    if (Ext.isDefined(status)){
      stacy = status;
    }
    if (Ext.isDefined(action)){
      acy = action;
    }
    if (me.isEmbedded()){      
      top.showNotification(html, stacy, acy);
    }
  },       
      
  embedded : false,
  
  isEmbedded : function(){
    var me = this;
//    if (Ext.isDefined( extVia.ui.page.strings.languageId)){ 
//      me.embedded = true;
//    }
//    
//    if (top.frames.F1 && Ext.isDefined( top.frames.F1) && Ext.isDefined( top.frames.F1.extVia) && Ext.isDefined( top.frames.F1.extVia.ui.page.strings)){ 
//      me.embedded = true;
//    }
    me.embedded = true;
    return me.embedded;
  },
  
  initCollaborations : function(cfg){
    if (!extVia.locales){
      extVia.locales = {};
    }
    
    var me = this;
    
    var epob ={};
    if(!cfg){
      cfg={};
    }
        
    if ( me.isEmbedded() ){ 

      extVia.notify = me.notify;
      //var languageISO= 'deu';  var countryISO= 'DEU';
      cfg.usersId = window.iUsersID;
      
      if (Ext.isDefined(top.frames.F1.extVia.ui.page.strings)){ 
        me.usersName = top.frames.F1.extVia.ui.page.strings.username;
        cfg.usersName = me.usersName;
      }

      // ProductsUpdate
      epob.epobId = window.sProductsID; //   <INPUT TYPE="hidden" NAME="p_sEpimId" VALUE="3000000217">
      epob.epobTypeId = (document.forms && document.forms[0] && document.forms[0].p_sTypeId)  ? document.forms[0].p_sTypeId.value : '2020'; //   <INPUT TYPE="hidden" NAME="p_sTypeId" VALUE="2020">
    }
    
    me.initLocalStorageStore();
    
    var collaborationsBtnGrpCfg = extVia.collaboration.statics.getCollaborationsBtnGrpCfg(cfg, epob); 
    collaborationsBtnGrpCfg.renderTo = 'collaborations-btngroup-bin';
    var buttonGroup = Ext.create('Ext.container.ButtonGroup', collaborationsBtnGrpCfg);

  },    
        
  
  getCollabsId: function(collabType){
    var me = this;
    var usersId = me.getUserId();
    var usersName = me.getUserName();
    var epobId = me.getEpobId();

    var collabId = collabType+'_'+me.usersId+'_'+me.epobId; 
    return collabId;
  },

  
  getEpobId: function(){
    var me = this;
    if(!Ext.isDefined( me.epobId)){
      me.epobId = '123fakeID_456';
      if ( me.isEmbedded() ){ 
        if (Ext.isDefined(top.frames.F1.extVia.ui.page.strings)){ 

          // ProductsUpdate
          me.epobId = window.sProductsID; //   <INPUT TYPE="hidden" NAME="p_sEpimId" VALUE="3000000217">
          me.epobTypeId = (document.forms && document.forms[0] && document.forms[0].p_sTypeId)  ? document.forms[0].p_sTypeId.value : '2020'; //   <INPUT TYPE="hidden" NAME="p_sTypeId" VALUE="2020">
        }
      }
    }
    return  me.epobId;
  },
  
  getEpobName: function(){
    var me = this;
    if(!Ext.isDefined( me.epobName)){
      me.epobName = '123fakeID_456';
      if ( me.isEmbedded() ){ 
        if (Ext.isDefined(top.frames.F1.extVia.ui.page.strings)){ 
          // ProductsUpdate
          me.epobName = top.frames.F32.window.sInitName; //   <INPUT TYPE="hidden" NAME="p_sEpimId" VALUE="3000000217">
        }
      }
    }
    return  me.epobName;
  },
  
  
  getUserId: function(){
    var me = this;
    if(!Ext.isDefined( me.usersId)){
      me.usersId = 'sl456';
      if ( me.isEmbedded() ){ 
        if (Ext.isDefined(top.frames.F1.extVia.ui.page.strings)){ 
          me.usersId = top.frames.F32.iUsersID;
        }
      }
    }
    return  me.usersId;
  },
  
  
  getUserName: function(){
    var me = this;
    if(!Ext.isDefined( me.usersName)){
      me.usersName = 'Simoon Leederer';
      if ( me.isEmbedded() ){ 
        if (Ext.isDefined(top.frames.F1.extVia.ui.page.strings)){ 
          me.usersName = top.frames.F1.extVia.ui.page.strings.username;
        }
      }
    }
    return  me.usersName; 
  },
  
  

  addRecentlyViewed: function(){
    var me = this;
    var collabType = 'recently';
    var collabId = me.getCollabsId(collabType); 
    
    var collabsStore = me.localStorageStore;
    Ext.data.StoreManager.lookup('localStorageStore').load(); 
    var collabRecord = collabsStore.findRecord('collabId', collabId); 
 
    var time = Date.now();
    
    //var collabsValue = 'viewed '+me.getEpobId()+' @'+time;
    var collabsValue = 'viewed @'+time;
    
    //alert('addRecentlyViewed ' + collabsValue)
    
    if(collabRecord){ 
      collabRecord.set('value', collabsValue); 
    }
    else if(!collabRecord){
      collabRecord =  Ext.create('Collaboration', { collabId: collabId,  collabType: collabType , value: collabsValue, usersId: me.usersId, usersName: me.usersName, epobId: me.epobId,  epobTypeId: me.epobTypeId, epobName: me.getEpobName(), time: time  }); 
    }
    collabRecord.save();
  },
  

  
  
  localStorageStore:null,
  initLocalStorageStore : function(){
    var me = this;  
    //if(!me.localStorageStore){
      Ext.define('Collaboration', {
        fields: ['id','collabType', 'value', 'collabId', 'usersId','usersName', 'epobId', 'epobName', 'epobTypeId', 'time'],
        extend: 'Ext.data.Model',
        proxy: {
            type: 'localstorage',
            id  : 'twitter-Searches'
        }
    });

    // Our Search model contains just two fields - id and value - plus a Proxy definition. 
    // The only configuration we need to pass to the LocalStorage proxy is an id. 
    // This is important as it separates the Model data in this Proxy from all others. 
    // The localStorage API puts all data into a single shared namespace, so by setting an id we enable LocalStorageProxy to manage the saved Search data
    // Saving our data into localStorage is easy and would usually be done with a Store:

    //our Store automatically picks up the LocalStorageProxy defined on the Search model
    var store = Ext.create('Ext.data.Store', {
        model: "Collaboration",
        storeId:'localStorageStore'
    });

    me.localStorageStore = store;
    store.load(); 
 
    me.readStorageFromFile();

    //}// eo if
    
    return me.localStorageStore;
  },
  
  
   getLocalStorageStore : function(){
    var me = this;
    //if(!me.localStorageStore){   
      me.initLocalStorageStore();
    //}
    return me.localStorageStore;
  }, 
      
  getUsersOverviewCount : function(){
    var me = this; 
    var usersOverviewCount = 0;
    var userName = me.getUserName();
    var userNameArr = userName.split(' ');
    var userForeName = userName.split(' ')[0];
    var userId =  me.getUserId();

    var localStorageStore = me.getLocalStorageStore();

    localStorageStore.each( function(item) { 
      var showRecord = true;
      var collabType = item.get("collabType");
      
      var collabId = item.get("collabId");
      
      var recUsersId =  item.get("usersId"); 
      var value =  item.get("value"); 
      showRecord = recUsersId!== userId;
      
      
     // alert(collabId +' collabType '+collabType +' usersOverviewCount '+usersOverviewCount);
      
      if (collabType==='recently'){
        showRecord = recUsersId === userId;
        
        //alert('recently  recUsersId '+recUsersId +' userId '+userId)
      }
      else if (collabType==='watch'){
        showRecord = false;
      }
      else if (collabType==='comment'){
        showRecord =  value.indexOf(userForeName)>-1 || value.indexOf(userName)>-1 ;
      }
      else if (collabType==='share'){
        showRecord = value.indexOf(userForeName)>-1 || value.indexOf(userName)>-1 ;
      }
      else if (collabType==='fave'){ 
        showRecord = recUsersId === userId;
      }
      if (showRecord){usersOverviewCount++;}
    });
    return usersOverviewCount;
  }, 
  
  
  getUsersOverviewStore : function(){
    var me = this;    
    var userName = me.getUserName();
    var userNameArr = userName.split(' ');
    var userForeName = userName.split(' ')[0];
    var userId =  me.getUserId();

    var usersOverviewStore = me.getLocalStorageStore();
    usersOverviewStore.filter([
      Ext.create('Ext.util.Filter', {filterFn: function(item) { 
        var showRecord = true;
        var collabType = item.get("collabType");
        var recUsersId =  item.get("usersId"); 
        var value =  item.get("value"); 
        showRecord = recUsersId!== userId;

        var collabId = item.get("collabId");

        
        if (collabType==='recently'){
          showRecord = recUsersId === userId;
          //showRecord = false;
          // alert(collabId +' collabType [recently] ['+collabType +'] userName['+userName+']  showRecord '+showRecord);
        }
        else if (collabType==='watch'){
          //alert(collabId +' collabType [watch] ['+collabType +'] userName['+userName+']  showRecord '+showRecord);
          showRecord = false;
        }
        else if (collabType==='comment'){
          showRecord =  value.indexOf(userForeName)>-1 || value.indexOf(userName)>-1 ;
        }
        else if (collabType==='share'){
          showRecord = value.indexOf(userForeName)>-1 || value.indexOf(userName)>-1 ;
        }
        else if (collabType==='fave'){ 
          showRecord = recUsersId === userId;
        }
        return showRecord;
      }, root: 'data'})
    ]);
    
    
    usersOverviewStore.sort({
          sorterFn: function(o1, o2){
              var time1 = o1.get('time');
              var time2 = o2.get('time');
              if (time1 === time2) {
                  return 0;
              }
              return time2 < time1 ? -1 : 1;
          }
     });
    
    
    return usersOverviewStore;
  }, 
  
  getEpobsOverviewStore : function(){
    var me = this;    
    var epobId = me.getEpobId();
    var epobsOverviewStore = me.getLocalStorageStore();
    epobsOverviewStore.filter([
      Ext.create('Ext.util.Filter', {filterFn: function(item) { 
        var showRecord = true;
        var value =  item.get("value"); 
        var recEpobId =  item.get("epobId");  
        showRecord = recEpobId === epobId;
        var collabType = item.get("collabType");
        if (collabType==='recently'){
          showRecord = false; 
        }
        return showRecord;
      }, root: 'data'})
    ]);
    
    
    epobsOverviewStore.sort({
      sorterFn: function(o1, o2){
          var time1 = o1.get('time');
          var time2 = o2.get('time');
          if (time1 === time2) {
              return 0;
          }
          return time2 < time1 ? -1 : 1;
      }
 });
    
    return epobsOverviewStore;
  }, 

  getWatchInstructions : function(cfg){
    var loc = extVia.locales;
    var watchCfg={
        epobType:'PRODUCT',
        isWatched: false,
        areaType: 'PRODUCTGROUP',
        isAreaWatched: false
    };
    
    var isWatched = cfg.isWatched;
    var isAreaWatched = cfg.isAreaWatched;
    
    var watchedEpobType = loc.thisProduct;
    var watchedAreaType = loc.thatProduct; 
    
    if (isWatched && isAreaWatched  ){
      watchedEpobType = loc.thisProductAndGroup;
      watchedAreaType = loc.thatProductAndGroup; 
    }
    
    var watchMainInstr = isWatched ? loc.situationYouAreWatchingThisEpob :  loc.situationYouAreNotWatchingThisEpob;
    watchMainInstr = watchMainInstr.replace(/\{thisEpob\}/, watchedEpobType);

    var watchSuppInstr = loc.purposeWatchingThisEpob;
    watchSuppInstr = watchSuppInstr.replace(/\{thisEpob\}/, watchedAreaType );

    return {main: watchMainInstr, supp: watchSuppInstr };    
  },
  
  
  initPersonsStore : function(btn){
    var me = this;

    if (!me.personsStore){
    var personsStore = Ext.create('Ext.data.Store', {
      model: Ext.define('Persons', {
        extend: 'Ext.data.Model',
        fields: [{type: 'string', name: 'avatar'}, {type: 'string', name: 'name'}, {type: 'string', name: 'who'}]
      }),
      storeId:'PersonsStore',
      data: [            

        {avatar:'dawnfischervansickle',name:'Dawn Fischer van Sickle', who:'vm soul'},               
        {avatar:'jurgenmuller',name:'J&uuml;rgen M&uuml;ller', who:'vm ceo'},
         
        {avatar:'michaelbauer',name:'Michael Bauer', who:'vm r&d' },               
        {avatar:'rudigerbodemer',name:'R&uuml;diger Bodemer', who:'vm ps' },               
        {avatar:'borisjusseit',name:'Boris Jusseit', who:'vm ps' },               
        {avatar:'andrehaschker',name:'Andre Haschker', who:'vm presales' },         
        {avatar:'jurgenkastle',name:'J&uuml;rgen K&auml;stle', who:'vm scrum'},
        {avatar:'sebastianbold',name:'Sebastian Bold', who:'vm text' },
        {avatar:'dariasikorski',name:'Daria Sikorski', who:'vm text' },
        {avatar:'alexanderross',name:'Alexander Ross', who:'vm dev' },
        {avatar:'philipplochbihler',name:'Philipp Lochbihler', who:'vm trainer' },
        {avatar:'simonlederer',name:'Simon Lederer', who:'vm ux' },               

        {avatar:'georgninck',name:'Georg Ninck', who:'vm ps' },
        {avatar:'haraldkrauss',name:'Harald Krauss', who:'vm ps' },
        {avatar:'sofianeayari',name:'Sofiane Ayari', who:'vm' },
        {avatar:'hansgertstiegelmeier',name:'Hans Gert Stiegelmeier', who:'vm ps scrum' },
        {avatar:'manuelkistner',name:'Manuel Kistner', who:'vm ps ' },
        {avatar:'andradedrichs',name:'Andra Dedrichs', who:'vm ps' },
        {avatar:'nadinesiemke',name:'Nadine Siemke', who:'vm ps' },
        {avatar:'saschamettler',name:'Sascha Mettler', who:'vm ps' },
        {avatar:'thomasbeuz',name:'Thomas Beuz', who:'vm ps' },
        {avatar:'jorngoeke',name:'Jörn Goeke', who:'vm ps' },
        {avatar:'horstfortner',name:'Horst Fortner', who:'vm it devops' },
        
        
        {avatar:'simoneweilacher',name:'Simone Weilacher', who:'vm ps' },   
        
        {avatar:'adinamunteanu',name:'Adina Munteanu', who:'vm dev' },               
        {avatar:'andreidumitrescu',name:'Andrei Dumitrescu', who:'vm dev' },
        {avatar:'anaamariutii',name:'Ana Amariutii', who:'vm dev' },
        {avatar:'costinelamariutii',name:'Costinel Amariutii', who:'vm dev' },
        {avatar:'ciprianbolboros',name:'Ciprian Bolboros', who:'vm dev' },        
        {avatar:'ovidiumihalache',name:'Ovidiu Mihalache', who:'vm test' },
        {avatar:'vladimirmitrea',name:'Vladimir Mitrea', who:'vm dev' },
        {avatar:'systemadministrator',name:'System Administrator', who:'vm dev' },
        
        {avatar:'laurajehle',name:'Laura Jehle', who:'vm trainung' },

       {avatar:'DougEngelbart',name:'Doug Engelbart', who:'Mother of all demos' },
       {avatar:'writers/dieterrams',name:'Dieter Rams', who:'braun design guru' },
       {avatar:'BernardPurdie',name:'Bernard Purdie', who:'Soul Drummer' },
       {avatar:'NinaSimone',name:'Nina Simone', who:'Singer' },
       {avatar:'DouglasCrockford',name:'Douglas Crockford', who:'javascript guru' },
       {avatar:'JesseJamesGarret',name:'Jesse James Garret', who:'ajax name giver' },
       
       
       {avatar:'nielspflaging',name:'Niels Pfl&auml;ging', who:'Komplexithoden' },
       {avatar:'writers/marchassenzahl',name:'Marc Hassenzahl', who:'UX Professor' },
       {avatar:'holgereggert',name:'Holger Eggert', who:'UX Evangelist' },       
       {avatar:'clemenslutsch',name:'Clemens Lutsch', who:'UX Evangelist' },
       {avatar:'SteveKrug',name:'Steve Krug', who:'Usability pro' },
       {avatar:'WernerT.Kuestenmacher',name:'Werner T.Kuestenmacher', who:'simplify founder' },
       {avatar:'LotharJ.Seiwert',name:'Lothar J. Seiwert', who:'simplify founder' },
       {avatar:'writers/guntherdueck',name:'Gunther Dueck', who:'Writer and Thinker' },
       {avatar:'writers/suzannegriegerlanger',name:'Suzanne Grieger-Langer', who:'Profiler' },
       {avatar:'leiaorgana',name:'Leia Organa', who:'Princess' },
       {avatar:'JamesDean',name:'James Dean', who:'Rebel without a cause' },
       {avatar:'JasonDorsey',name:'Jason Dorsey', who:'Twitter founder and genY' },  
       {avatar:'writers/gurdjieff',name:'Georges I. Gurdjieff', who:'Teacher Musician' },
       {avatar:'writers/harukimurakami',name:'Haruki Murakami', who:'Writer' },
       {avatar:'writers/arkadiborisstrugatzki',name:'Arkadi + Boris Strugatzki', who:'Writer' },
       {avatar:'writers/tedchiang',name:'Ted Chiang', who:'Writer' },
       {avatar:'writers/stanislawlem',name:'Stanislaw Lem', who:'Writer' },
       {avatar:'writers/paulcoelho',name:'Paul Coelho', who:'Writer' },
       {avatar:'writers/michaelende',name:'Michael Ende', who:'Writer' },
       {avatar:'writers/CarlosRuizZafon',name:'Carlos Ruiz Zafon', who:'Writer' },
       {avatar:'writers/oscarwilde',name:'Oscar Wilde', who:'Writer' },
       {avatar:'LuisaFrancia',name:'Luisa Francia', who:'Author Thinker Writer Painter' },
       {avatar:'SusanneFischer-Rizzi',name:'Susanne Fischer-Rizzi', who:'Author' },
       {avatar:'KlausberndVollmar',name:'Klausbernd Vollmar', who:'Psychologe Dreamanalyzer' },
       {avatar:'writers/LisaKekaula',name:'Lisa Kekaula', who:'BellRays' },
       {avatar:'RingoStarr',name:'Ringo Starr', who:'Beatles Drummer' },
       {avatar:'GeneKrupa',name:'Gene Krupa', who:'Jazz Drummer' },
       {avatar:'PhilRudd',name:'Phil Rudd', who:'AC/DC Drummer' },
       {avatar:'PeterCriss',name:'Peter Criss', who:'Kiss Drummer' },
       {avatar:'JohnBonham',name:'John Bonham', who:'Led Zeppelin Drummer' },
       {avatar:'KeithMoon',name:'Keith Moon', who:'Who Drummer' },
       {avatar:'BillWard',name:'Bill Ward', who:'Black Sabbath Drummer'}
      ]   
  });  
    
  me.personsStore = personsStore;
  }
  return  me.personsStore ;  
  },
  
  initUsersBoundlistItemTpl: function(){
    var me = this;

    var collabsUrl = me.getCollabsUrl();
    
    var baseUrl = me.getBaseUrl(); 
    var imgBaseUrl = baseUrl + '/../img/';
    if (me.isEmbedded()){
      imgBaseUrl = baseUrl +  '/via-img/';
    }  
    
    me.usersBoundlistItemTpl = 
    '<div style="" title="{value}" class="xty_users-boundlist-item">'+
    '<img class="xty_avatar-img"  src="'+imgBaseUrl+'spacer.gif" style="background-image: url('+imgBaseUrl+'epobs/user/avatars/{avatar}_48.png) , url('+imgBaseUrl+'epobs/user/avatars/default_48.png); ">'+
    '<span class="xty_user-name" >&nbsp;&nbsp;{name}</span>  </div>';
    
    return   me.usersBoundlistItemTpl ;
    
  },

  
//  
//  usersBoundlistItemTpl:
//    '<div style="" title="{value}" class="xty_users-boundlist-item">'+
//     '<img class="xty_avatar-img"  src="../img/icons/spacer.gif" style="background-image: url(../img/epobs/user/avatars/{avatar}_48.png) , url(../img/epobs/user/avatars/default_48.png); ">'+
//     '<span class="xty_user-name" >&nbsp;&nbsp;{name}</span>  </div>',
  
  
  
  manageWatchersHandler : function(btn){
    btn.ownerCt.ownerCt.ownerCt.hide();
    
    var me = extVia.collaboration.statics;

    var loc = extVia.locales;

    
    me.initPersonsStore();
    
    
    
    me.initUsersBoundlistItemTpl();
    
    
    Ext.create('Ext.window.Window', {
      title: loc.manageWatchers,
      modal:true,
      y:60,
      width: 720,
      layout: 'hbox',
      
      defaults:{
        border:false,
        width:360,
        height: 320
      },
      
      items: [

       {xtype:'form', itemId:'epobWatchersForm',
        items:[
          {xtype:'displayfield',  itemId:'mainInstr', margin:'12 4 4 16', cls:'xty_dialog-mainInstr', value: loc.labelWatchIt},         
          {xtype:'displayfield', itemId:'suppInstr', margin:'4 4 16 16', cls:'xty_dialog-suppInstr', value: loc.manageWatchEpobSupp}, 
          {xtype:'fieldcontainer', margin:'4 4 16 16',  layout: 'hbox',
            items:[
              {
                width:260,
                hideTrigger:true,
                xtype : 'boxselect',
                itemId : "NotificationRecipientName",
                name : 'NotificationRecipientName',
                multiSelect : true,
                allowBlank : true,
                lazyInit: false,
                queryMode : 'local',
                displayField : 'name',
                labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                store :  me.personsStore,
                listeners : {
                  afterrender : function(view, eOpts) {
                    //view.allowBlank = false; 
                  },
                  select : function(view){
                    view.ownerCt.doLayout();
                    view.collapse();
                    view.onTriggerClick();
                  },
                  beforedeselect : function( view, isDirty, eOpts ){
                    if(!Ext.isEmpty(view.ownerCt)){
                      view.ownerCt.doLayout();
                    }
                    view.collapse();
                    view.onTriggerClick();
                  },
                  validitychange : function( view, isValid, eOpts ){
                    if(!Ext.isEmpty(view.ownerCt)){
                      view.ownerCt.doLayout();
                    }
                  }
                },
                minHeight:32,
                listConfig : {
                  minWidth:200,
                  maxHeight:200,
                  itemTpl:  me.initUsersBoundlistItemTpl()               
                }
              }, 
              {xtype:'button', text:loc.labelAdd, height:22}
            ]
          },
 
          {  
            xtype: 'grid',margin:'12 4 4 16',
            hideHeaders:true,
            border: false,
            bodyBorder:false,
            columns: [
              //{header: ' ', dataIndex:'usersId', width:60},
              {header: 'Watchers', dataIndex:'usersName'}
            ],                
            store: me.localStorageStore.load()
         }
        ]

       }, 
       
       { xtype:'form',
         itemId:'areaWatchersForm',

         items:[
           {xtype:'displayfield',  itemId:'mainInstr', margin:'12 4 4 16', cls:'xty_dialog-mainInstr', value: loc.labelWatchGroup},              
           {xtype:'displayfield', itemId:'suppInstr', margin:'4 4 16 16', cls:'xty_dialog-suppInstr', value: loc.manageWatchAreaSupp}
         ]

        }
      ],
      buttons:[{text:loc.labelClose, handler:function(btn){btn.ownerCt.ownerCt.close();} }]
   }).show();
  },
 
  

  
  
  
  collabsBtnGrpBtnHandler : function(btn, evt){
    Ext.data.StoreManager.lookup('localStorageStore').load();

    var btnPos = btn.getPosition();

    var doAllCollabsMenu = false;
    var doDefaultBtnMenu = true;
    if ( btn.itemId==='more' && evt.hasModifier()){
      doAllCollabsMenu = true;
      doDefaultBtnMenu = false;
    }

    if (doDefaultBtnMenu){
      if (!btn.myMenu){
        btn.myMenu =    Ext.create('Ext.menu.Menu',btn.menuCfg);
      }
      btn.myMenu.showAt( btnPos[0]-230, btnPos[1]+30);
    }
    else if (doAllCollabsMenu){
       if (!btn.myAllMenu){
         btn.myAllMenu =    Ext.create('Ext.menu.Menu',btn.menuAllCfg);
       }
       btn.myAllMenu.showAt( btnPos[0]-230, btnPos[1]+30);
     }
    
    
//    
//   var collabsBtnWin =  Ext.create('Ext.window.Window', {
//      title: loc.manageWatchers,
//      modal:true,
//      y:60,
//      width: 720,
//      layout: 'hbox',
//      
//      defaults:{
//        border:false,
//        width:360,
//        height: 320
//      },
//      items: btn.menuCfg.items
//    });
//    collabsBtnWin.show();
  },
  

  
  
  getCollaborationsBtnGrpCfg : function(cfg, epob){
 
 
    
    var loc = extVia.locales;
    var me = this; 
    me.initLocalStorageStore();
    
    me.usersId = me.getUserId();
    me.usersName = me.getUserName();
    me.epobId = me.getEpobId();
    me.epobName= me.getEpobName();
    
    
    if (cfg){
      me.usersId =  cfg.usersId ? cfg.usersId : me.usersId;
    }

    
    
    if (epob){
      me.epobId = epob.epobId; 
      me.epobTypeId = epob.epobTypeId;
      if(epob.epobDscr){ me.epobName = epob.epobDscr;}

    }
    else{
      me.epobId = me.getEpobId();
      me.epobTypeId = '2020X';
      me.epobName= me.getEpobName();
    }

    me.addRecentlyViewed();
    
   
  
    
    var bellsbadgeTextTask = new Ext.util.DelayedTask(function(){
      var bellsBadgecount = me.getUsersOverviewCount(); 
      var bellsbadge = me.isEmbedded() ? top.bellsbadge :  Ext.getCmp('bellsbadge');
      if(bellsbadge && bellsBadgecount>0){
        var showBadge =  bellsBadgecount > 0 ;      
        var badgetext = bellsBadgecount < 100 ? bellsBadgecount : '&hellip;' ;
        bellsbadge.setText(badgetext); 
        bellsbadge.show();
        bellsbadge.setTooltip(badgetext+ ' ' +loc.newNotifications); // needs .xty_badge-bells-badge-tip hidden in MenuTopLeiste
      }
    });
    bellsbadgeTextTask.delay(500);


    
    
    

    
    
    
//    var collabsBtnHandler = function(btn){
//      
//     // Ext.data.StoreManager.lookup('localStorageStore').load();
//      
//      var btnPos = btn.getPosition();
//      if (!btn.myMenu){
//        btn.myMenu =    Ext.create('Ext.menu.Menu',btn.menuCfg);
//      }
//
//      btn.myMenu.showAt( btnPos[0]-230, btnPos[1]+30);
//    };


    var applyBtn; var collabsFormPanel;

    var applyHandler = function (btn, evt, form){ 
      if (!form){  
        if (btn.getXType()==='checkboxfield'){
          collabsFormPanel = btn.ownerCt;
        }
        else{
          collabsFormPanel = btn.ownerCt.ownerCt;
        } 
        form = collabsFormPanel.getForm(); 
      }
      

      //alert('try to submit transformed Form is valid['+form.isValid()+'] '+ Ext.encode(form.getValues()));
//      alert('try to submit transformed Form is valid['+form.isValid()+'] ' +
//            '\n form.getValues\n'+ Ext.encode(form.getValues()) +
//            '\n form.getFieldValues\n'+ Ext.encode(form.getFieldValues())
//      ); 
   
      var formVals = form.getValues();
      formVals = Ext.encode(formVals).replace(/"/g, '');
      formVals = formVals.replace(/\{/g, '');
      formVals = formVals.replace(/\}/g, '');

      var collabsValue = formVals;
      
      var collabsStore = me.localStorageStore;
      Ext.data.StoreManager.lookup('localStorageStore').load(); 
  
      var collabId =  btn.collabType+'_'+me.usersId+'_'+me.epobId; //var collabId = me.getCollabsId(btn.collabType); 
      var collabRecord;  

      if(btn.collabType==='share' || btn.collabType==='comment'){
         var count  = collabsStore.getCount()+1;
         collabId = count+'_'+ collabId;
      }
      if(btn.collabType==='watch'){
        collabRecord = collabsStore.findRecord('collabId', collabId); 
        var collaborationsBtnGrp = Ext.getCmp('collaborationsBtnGrp');
        if(collaborationsBtnGrp){
          var collaborationsBtn = collaborationsBtnGrp.getComponent(btn.collabType);
          if(collaborationsBtn){
            var shouldBePressed =  false;
            
            var isWatched =  false;
            var isAreaWatched =  false;
            
            if (collabsValue){
              isWatched =  collabsValue.indexOf('watchIt:on')>-1;
              isAreaWatched =  collabsValue.indexOf('watcharea:on')>-1;
              shouldBePressed = isWatched || isAreaWatched; 
            }
            var watchInstructions = me.getWatchInstructions({
              epobType:'PRODUCT',
              isWatched: isWatched,
              isAreaWatched: isAreaWatched
            });
            collabsFormPanel.setInstructions(watchInstructions);
            collaborationsBtn.toggle(shouldBePressed);
          }
        }
      }
      
      if(collabRecord){ 
        collabRecord.set('value', collabsValue); 
      }
      else if(!collabRecord){  
        var time = Date.now();
        collabRecord =  Ext.create('Collaboration', { collabId: collabId,  collabType: btn.collabType , value: collabsValue, usersId: me.usersId, usersName: me.usersName, epobId: me.epobId, epobName: me.epobName,  epobTypeId: me.epobTypeId, time: time  }); 
      }
      collabRecord.save();

      if(btn.collabType!=='watch'){
        btn.ownerCt.ownerCt.ownerCt.hide();
      }
  
      
      if(btn.collabType==='comment'){
        form.reset();
        Ext.getCmp('comment-message-overlay-textarea').reset();
        
        extVia.notify(loc.comment , 'Success', loc.labelAdded);
     }
      
      if(btn.collabType==='share'){
        var persons = form.findField('persons').getValue(); 
        var xothers = persons;
        
        if (persons && persons.length >1){
          var personsLen = persons.length;
          var otherPersonsCnt = personsLen-1;
          if(otherPersonsCnt===1){
            xothers = persons[0] + ' '+loc.oneOtherPerson;
          }
          else{
            xothers = persons[0] + ' '+ loc.otherPersons.replace( /\{x\}/ , otherPersonsCnt );
          }
        }

        form.reset();
        Ext.getCmp('share-message-overlay-textarea').reset(); 

        var sharedWithMsg = loc.sharedWithMsg.replace( /\{xothers\}/ ,xothers );
        extVia.notify(sharedWithMsg,'Success', loc.share);
     }
 
      
    }; // eo applyHandler
    
    

    
    var isWatched = false;
    var isAreaWatched = false;

    var collabsStore = me.localStorageStore;

    var collabId =  'watch_'+me.usersId+'_'+me.epobId; //var collabId = me.getCollabsId('watch'); 

    var collabRecord = collabsStore.findRecord('collabId', collabId); 
      if(collabRecord){
        var collabsValue = collabRecord.get('value');
        if (collabsValue){
          isWatched = collabsValue.indexOf('watchIt:on')>-1;
          isAreaWatched = collabsValue.indexOf('watcharea:on')>-1;
        }
    }


    
    var watchInstructions = me.getWatchInstructions({
        epobType:'PRODUCT',
        isWatched: isWatched,
        isAreaWatched: isAreaWatched
    });
    
    var watchMainInstr = watchInstructions.main;
    var watchSuppInstr = watchInstructions.supp;
    
    
    
    var isMyEpob = true;
    
    var watchMenuCfg= {
      showSeparator:false, 
      shadow: false,
      border: false,
      itemId : 'watch-flyout',
      componentCls : 'xty_flyout xty_watch-flyout',
      baseCls : 'xty_flyout-arrow-top xty_watch-flyout-arrow-top', 
      items: [{
       maxWidth:280, 
       height: isMyEpob ? 180 : 160,
       style:"width:380px; height:100%; background-color: white !important;",
       cls:'xty_collab-btn-menu-dialog-bin',
       xtype:'form',
       itemId:'collabsWatchFormPanel',
       setInstructions: function(cfg){
         var mainInstr  = this.getComponent('mainInstr');
         if (mainInstr && cfg.main){mainInstr.setValue(cfg.main);}
         var suppInstr  = this.getComponent('suppInstr');
         if (suppInstr && cfg.supp){suppInstr.setValue(cfg.supp);}
       },
       margin:'2 2 2 2',
       defaults:{
         margin:'4 4 4 16'
       },
       items:[
         {xtype:'button', text:'  &#10005;  ', cls:'xty_view-panel-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', 
           style:'color: #e2e2e2; background-color:white;background:none; border:0px; position:absolute;top: -4px; right:-2px;', 
           handler:function(btn){
             btn.ownerCt.ownerCt.hide();
            }
         },
         {xtype:'displayfield',  itemId:'mainInstr', margin:'12 4 4 16', cls:'xty_dialog-mainInstr', value: watchMainInstr},         
         {xtype:'displayfield', itemId:'suppInstr', margin:'4 4 16 16', cls:'xty_dialog-suppInstr', value: watchSuppInstr},
         {xtype:'checkbox', itemId:'watchIt', name:'watchIt', collabsBtnsItemId: 'watch', collabType:'watch', checked: isWatched, boxLabel: loc.labelWatchIt, handler:applyHandler }
         ,{xtype:'checkbox', itemId:'watcharea', name:'watcharea', collabsBtnsItemId: 'watch', collabType:'watch', checked: isAreaWatched, boxLabel: loc.labelWatchGroup, handler:applyHandler}         
       ],
       buttons:{ hidden: !isMyEpob, items: [{text: loc.manageWatchers, itemId:'manageWatchers', handler: me.manageWatchersHandler}]}
      } 
    ]
   };
   
    var baseUrl = me.getBaseUrl(); 
    var imgBaseUrl = baseUrl + '/../img/';
    if (me.isEmbedded()){
      imgBaseUrl = baseUrl +  '/via-img/';
    }  
    
    
    var epobsOverviewStore = extVia.collaboration.statics.getEpobsOverviewStore();     
    
    var moreMenuCfg= {
      showSeparator:false, 
      shadow: false,
      border: false,
      itemId : 'more-flyout',
      componentCls : 'xty_flyout xty_more-flyout',
      baseCls : 'xty_flyout-arrow-top xty_more-flyout-arrow-top', 
      listeners:{
        beforeshow: function(){
          epobsOverviewStore.load();
        }
      },
      items: [
        {
        xtype:'panel',
        margin:'2 2 2 2',
        style:"width:380px; height:100%; background-color: white !important;",
        items: [
          {xtype:'button', text:'  &#10005;  ', cls:'xty_view-panel-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', 
            style:'color: #e2e2e2; background-color:white;background:none; border:0px; position:absolute;top: -4px; right:-2px;', 
            handler:function(btn){
              btn.ownerCt.ownerCt.hide();
             }
          },
        {xtype:'displayfield',  margin:'12 4 14 16', cls:'xty_dialog-mainInstr', value: loc.collaborationOverview},
        {
          xtype:'grid',
          hideHeaders:true,
          itemId:'collabsEpobOverviewGrid',
          margin:'2 2 2 2',
          border:false,
          //tools:[{id:'close', handler:function(event, toolEl, panel){  panel.ownerCt.ownerCt.ownerCt.hide();} }],
          width:380, 
          height:400,
         // store: Ext.data.StoreManager.lookup('localStorageStore').load(),
          store: epobsOverviewStore, //extVia.collaboration.statics.getEpobsOverviewStore(),     

          columns: [         

//            { header: 'Type', dataIndex: 'collabType',  width:36,
//              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
//              return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon-'+value+'"><span title="'+value+'"style="marssgin-top:-8px;"></span></div>';
//            }
//            },
//            
//            { header: 'Person',  dataIndex: 'usersName', widsth:120,
//                renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
//                  return '<div style="width:100%;height:23px; padding-left:28px;" class="xty_boundlist-item-useravatar"><span title="'+value+'" style="margin-top:-8px;">'+value+'</span></div>';
//                }
//            },

            
            
            { header: 'Person',  dataIndex: 'usersName', width: 32,
              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {

               var usersTpl = '';
               if (value){
                 var avatar = value.replace(/ /,'' ).toLowerCase();
                 usersTpl = 
                    '<img class="xty_avatar-img"  src="'+imgBaseUrl+'spacer.gif" style="background-image: url('+imgBaseUrl+'epobs/user/avatars/'+avatar+'_48.png) , url('+imgBaseUrl+'epobs/user/avatars/default_48.png); ">';
               }
                return usersTpl; 
              }
            },

            
             { header: 'Value', dataIndex: 'value', flex: 0.9,
              
             
              
              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                var collabType = record.get('collabType');
               
                var whosName = record.get('usersName');
                var who = '<b>' +whosName+'</b>';
                var collabAction='';
                
                var epob = record.get('epob');
                var epobId = record.get('epobId');
                var epobName = record.get('epobName');
                if(!epobName){
                  epobName='Driller';
                }
                
                var html = value;
                if (collabType==='share'){
                  collabAction = loc.sharedThisProduct;
                  ///html='<br><a class="xty_epobProduct xty_gridcell-link" style="padding-left:18px;text-decoration:none;color:black;" target="_blank" href="'+baseUrl+'/../ajsp/Forward.jsp?p_sFromPage=QueryProductsProductgroups&p_sPageType=PageMain&p_sObpdId='+epobId+'">'+epobName+' [&raquo;] </a>';
                  var personsArrEnd = value.indexOf('],');
                  html =  ' <div style="white-space: normal;" class="xty_boundlist-item-sharedwith">'+ value.substring(9,personsArrEnd).replace(/,/g,', ') +'</div>';
                }
                
                else if (collabType==='recently'){
                  collabAction = loc.recentlyViewed;
                  //html='<br><a class="xty_epobProduct xty_gridcell-link" style="padding-left:18px;text-decoration:none;color:black;" target="_blank" href="'+baseUrl+'/../ajsp/Forward.jsp?p_sFromPage=QueryProductsProductgroups&p_sPageType=PageMain&p_sObpdId='+epobId+'">'+epobName+' [&raquo;] </a>';
                }
                
                else if (collabType==='watch'){
                  collabAction = loc.isWatchingThisProduct;
                  html='';
                }
                
                else if (collabType==='comment'){
                  collabAction = loc.commentedThis;
                  html = value.replace(/message:/,'<br>');
                  html = html.replace(/\\n/g,'<br>');
                  
                  
                  //html+=' <a class=" xty_gridcell-link" style="padding-left:18px;text-decoration:none;color:black;" target="_blank" href="'+baseUrl+'/../ajsp/Forward.jsp?p_sFromPage=QueryProductsProductgroups&p_sPageType=PageMain&p_sObpdId='+epobId+'" title="'+epobName+'">[&raquo;] </a>';
                }                
                
                
                html =   who+' '+ collabAction + html ;

               // var typeIcon = '<br><span style="width:100%; height:22px; padding-left:16px;" class="xty_collabstype-icon xty_icon-'+collabType+'"  title="'+collabType+'"></span>';

                var dt = new Date(); 
                dt.setTime( record.get('time'));
                var format = loc.extDateDscrFormat  + ' H:i';
                var timy = Ext.Date.format(dt, format);
                
                var isNewStar = '';
//                var isNew = false;
//                if(isNew){
//                  isNewStar='<span class="xty_teaser-isnew-star" title="isnew" style="color:#00aaea;font-size:16px;" >&nbsp;*&nbsp;</span> ';
//                }
                
                html+= isNewStar+'<br><span class="xty_collabscell-time" style="color:#888;">' +timy +'</span>';
                
                return html;
              }
              
              
             }
             
           ,{ header: 'Type', dataIndex: 'collabType',  width:44,
            renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon-'+value+'"><span title="'+value+'"style="marssgin-top:-8px;"></span></div>';
           }
          }
          ]
        }
        ]
      } 
    ]                          
    };
    
    var moreMenuAllCfg= {
      showSeparator:false, 
      shadow: false,
      border: false,
      itemId : 'moreall-flyout',
      componentCls : 'xty_flyout xty_moreall-flyout',
      baseCls : 'xty_flyout-arrow-top xty_moreall-flyout-arrow-top', 
      items: [ 
       {
       width:800, 
       height:400,
       stsyle:"width:380px; height:100%; background-color: white !important;",
       cls:'xty_collab-btn-menu-dialog-bin',
      
       title: loc.collaboration +' all',
       tools:[
         {id: 'refresh',  handler:function(event, toolEl, panel){ Ext.data.StoreManager.lookup('localStorageStore').load(); }},
         {id:'close', handler:function(event, toolEl, panel){  panel.ownerCt.ownerCt.hide();} }
         ],
       xtype:'grid',
       itemId:'collabsOverviewAllGrid',
       margin:'2 2 2 2',
       plugins: [ 
         Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: true            
        })],
       
        store: Ext.data.StoreManager.lookup('localStorageStore').load(),
        
        selModel:   Ext.create('Ext.selection.CheckboxModel', {checkOnly : true}),
        columns: [         

          
          { header: 'id', dataIndex: 'id', width: 40, hidden:true },
          { header: 'collabId', dataIndex: 'collabId', width: 190 ,editor: {xtype: 'textfield'}  },
          { header: 'Typ',  dataIndex: 'collabType',width: 50   },
          { header: 'value',  flex:1,  dataIndex: 'value',                                                
            editor: {xtype: 'textfield'} 
          },
          { header: 'user id', dataIndex: 'usersId', width:50},
          { header: 'user', dataIndex: 'usersName',  editor: {xtype: 'textfield'} },
          { header: 'epob', dataIndex: 'epobId', width:60},
          { header: 'epobName', dataIndex: 'epobName', width:80,  editor: {xtype: 'textfield'} },
          { header: 'epobType', dataIndex: 'epobTypeId', width:50},
          { header: 'time', dataIndex: 'time', width:100, editor: {xtype: 'numberfield'}}
        ],

        buttons:[
          {text:'Delete', marsgin:'0 240 0 0',
           handler: function(btn){   
             var grid = btn.ownerCt.ownerCt;   
             var selectedRecords = grid.getSelectionModel().getSelection();
             if (selectedRecords){
               var store =  grid.getStore();
               store.remove(selectedRecords);
               store.sync();
             } 
            }
          },
          
          {text:'Clear all', margin:'0 200 0 0',
            handler: function(btn){   
               window.localStorage.clear(); 
               //store.load();
               //store.sync();
             }
           },

          {text:'read'}, 
          {text:'write',
            handler: function(btn){   
              var grid = btn.ownerCt.ownerCt;   
              var selectedRecords = grid.getSelectionModel().getSelection();
              if (selectedRecords){
                var selectionVal='[';
                var di;
                for(di=0; di<selectedRecords.length ; di++){
                  var data = selectedRecords[di].data;
                  selectionVal+= '\n' +Ext.encode(data); 
                  if (di < selectedRecords.length-1) {selectionVal+=','; }
                }
                selectionVal+='\n]';
                
               var win =  Ext.create('Ext.window.Window', {
                  title: 'Selected Rows',
                  border:false,
                  y:80,
                  height: 200,
                  width: 800,
                  layout: 'fit',
                  items: [
                    {xtype:'textarea' , border:false, value: selectionVal}
                  ]
              }).show();
              } 
             }
          
          },  
          {text: loc.cancel , handler:function (btn){ btn.ownerCt.ownerCt.ownerCt.hide();}}],
        
        listeners:{ 
          edit : function(editor, e) {  
            editor.record.save();  
          }
         } 
      } 
    ]                          
    };
    
    var commentMainInstr = loc.comment;
    var commentMenuCfg = {
      showSeparator:false, 
      shadow: false,
      border: false,
      itemId : 'comment-flyout',
      componentCls : 'xty_flyout xty_comment-flyout',
      baseCls : 'xty_flyout-arrow-top  xty_comment-flyout-arrow-top', 
      items: [{
       height:200,
       widsth:360, 
       style:"width:380px; height:100%; background-color: white !important;",
       cls:'xty_collab-btn-menu-dialog-bin',
       xtype:'form',
       itemId:'collabsCommentFormPanel',
//       setInstructions: function(cfg){
//         var mainInstr  = this.getComponent('mainInstr');
//         if (mainInstr && cfg.main){mainInstr.setValue(cfg.main);}
//         var suppInstr  = this.getComponent('suppInstr');
//         if (suppInstr && cfg.supp){suppInstr.setValue(cfg.supp);}
//       },
       margin:'2 2 2 2',
       defaults:{
         margin:'4 4 4 16',
        // labelAlign : 'top',
         width:340, 
         labelWidth:160
       },
       items:[
         {xtype:'button', text:'  &#10005;  ', cls:'xty_view-panel-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', style:'color: #e2e2e2; background-color:white;background:none; border:0px; position:absolute;top: -4px; right:-2px;', 
           handler:function(btn){
             btn.ownerCt.ownerCt.hide();
             }
         },
         {xtype:'displayfield',  margin:'12 4 4 16', cls:'xty_dialog-mainInstr', value: commentMainInstr},
         
         {xtype:'hidden',itemId:'comment-message', allowBlank:false, id:'comment-message-hidden',  name:'message'}

         
       ], 

       listeners:{
         validitychange: function( basicform, valid){ 
           var buttons = this.getComponent('myButtons');
           var applyBtn = buttons.getComponent('add');
           applyBtn.setDisabled(!valid);
         }
       },
       buttons:{itemId:'myButtons', items:[{text:loc.labelAdd, itemId:'add', disabled:true, collabType:'comment', handler:applyHandler}, {text:loc.cancel, handler:function(btn){btn.ownerCt.ownerCt.ownerCt.hide();}}]}
      },
    
    
    // TEXTEAREA needs to be outside form because otherwise NO  onENTER keyevents (when form inside a menu)
    {xtype:'textarea', id:'comment-message-overlay-textarea',  cls:'xty_menu-overlay-textarea xty_comment-message-overlay-textarea', 
      width:340 , // fieldLabel: loc.labelComment ,  labelWidth:160,  labelAlign : 'top',  
      margin:'4 4 4 10', 
      listeners:{
        change:function(textarea){
          var val = textarea.getValue();
          var commentMessageHidden = Ext.getCmp('comment-message-hidden');
          if (commentMessageHidden){
            commentMessageHidden.setValue(val);
          }
        }
      }
    }
    ],
    listeners:{
      afterrender: function(menu){
          var task = new Ext.util.DelayedTask(function(){
            menu.setHeight(210);
          });
          task.delay(50);
      },
      show: function(menu){
        menu.setHeight(210);
      }
    }
      
   };
    
    
    
    
    me.initPersonsStore();
    var shareMainInstr = loc.mainInstrShareIt;

    var shareMenuCfg = {
      showSeparator:false, 
      shadow: false,
      border: false,
      id : 'share-flyout',
      itemId : 'share-flyout',
      componentCls : 'xty_flyout xty_share-flyout',
      baseCls : 'xty_flyout-arrow-top xty_share-flyout-arrow-top', 
      items: [
        
       {
       height:300,
       widsth:360, 
       style:"width:380px; height:100%; background-color: white !important;",
       cls:'xty_collab-btn-menu-dialog-bin',
       xtype:'form',
       itemId:'collabsFormPanel',
       setInstructions: function(cfg){
         var mainInstr  = this.getComponent('mainInstr');
         if (mainInstr && cfg.main){mainInstr.setValue(cfg.main);}
         var suppInstr  = this.getComponent('suppInstr');
         if (suppInstr && cfg.supp){suppInstr.setValue(cfg.supp);}
       },
       margin:'2 2 2 2',
       defaults:{
         margin:'4 4 4 16',
         labelAlign : 'top',
         width:340 
         //,labelWidth:160
       },
       items:[
         {xtype:'button', text:'  &#10005;  ', cls:'xty_view-panel-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', style:'color: #e2e2e2; background-color:white;background:none; border:0px; position:absolute;top: -4px; right:-2px;', 
            handler:function(btn){
              btn.ownerCt.ownerCt.hide();
              }
         },
         
         {xtype:'displayfield',  margin:'12 4 16 16', cls:'xty_dialog-mainInstr', value: shareMainInstr},
         {xtype:'combo', itemId:'person', name:'persons', allowBlank:false,  vtypeText:'You need a person to share',  fieldLabel: loc.labelAddPerson,
           //hideTrigger:true, 
           width:356, 
           triggerCls:'xty_emptyinSSSside-trigger xty_invisible-trigger',
           multiSelect : true,
           queryMode : 'local',
           displayField : 'name',
           labelSeparator : ':<span class="xty_requiredStar"> *</span>',
           store :  me.personsStore,
           listConfig : {
             maxWidth:339, 
             minWidth:356,
             maxHeight:200,
             itemTpl:  me.initUsersBoundlistItemTpl()
           }, 
           
           
           getTriggerEl: function(triggerNr){
             var combo = this;
             var triggersArr = Ext.DomQuery.select('#'+combo.id+'-triggerWrap .x-trigger-index-'+(triggerNr-1));
             var trgId =  triggersArr[0].id;
             return Ext.get(trgId);
           },
           
           
           listeners:{
            afterrender: function(combo){
              var comby = combo;
              
              var task = new Ext.util.DelayedTask(function(){
                combo.focus();
              });
              task.delay(50);
              
//              combo.getEl().on('click', 
//                function(combo){
//                  comby.getTriggerEl(1).click();
//                 }
//              );
              
            }  
           }
         },     


//             {
//               //width:260,
//               hideTrigger:true, hidden:true,
//               xtype : 'boxselect',
//               itemId : 'shareRecipientName',
//               name : 'shareRecipientName',
//               multiSelect : true,
//               allowBlank : false,
//               lazyInit: false,
//               queryMode : 'local',
//               displayField : 'id',
//               labelSeparator : ':<span class="xty_requiredStar"> *</span>',
//               store :  me.personsStore,
//               listeners : {
//                 afterrender : function(view, eOpts) {
//                   //view.allowBlank = false; 
//                 },
//                 select : function(view){
//                   view.ownerCt.doLayout();
//                   view.collapse();
//                   view.onTriggerClick();
//                 },
//                 beforedeselect : function( view, isDirty, eOpts ){
//                   if(!Ext.isEmpty(view.ownerCt)){
//                     view.ownerCt.doLayout();
//                   }
//                   view.collapse();
//                   view.onTriggerClick();
//                 },
//                 validitychange : function( view, isValid, eOpts ){
//                   if(!Ext.isEmpty(view.ownerCt)){
//                     view.ownerCt.doLayout();
//                   }
//                 }
//               },
//
//               listConfig : {
//                 minWidth:200,
//                 maxHeight:200,
//                 //itemTpl:'<div class="xty_boundlist-item-useravatar" style="border:1px solid #ccc; border-radius:12px; width:21px; height:21px;  min-width:21px; min-height:21px; "></div><div style="width:100%;padding-left:16px;" title="{value}" class="xty_epob{epob}">' + '&nbsp; {name} </div>' 
//                 itemTpl:'<div style="" title="{value}" class="xty_boundlist-item-useravatar">' + '&nbsp; {name} </div>'
//               }
//             },

         
         
         
         {xtype:'hidden',itemId:'share-message',  id:'share-message-hidden',  name:'message'}

       ], 

       listeners:{
         validitychange: function( basicform, valid){ 
           var buttons = this.getComponent('myButtons');
           var applyBtn = buttons.getComponent('apply');
           applyBtn.setDisabled(!valid);
         }
       },
       buttons:{itemId:'myButtons', items:[{text:loc.share, itemId:'apply', disabled:true, collabType:'share', handler:applyHandler}, {text:loc.cancel, handler:function(btn){btn.ownerCt.ownerCt.ownerCt.hide();}}]}
      },
        
      // TEXTEAREA needs to be outside form because otherwise NO  onENTER keyevents (when form inside a menu)
      {xtype:'textarea', fieldLabel: loc.labelIncludeMessage ,  id:'share-message-overlay-textarea',  cls:'xty_menu-overlay-textarea xty_share-message-overlay-textarea', 
        width:340 , labelWidth:160,  margin:'12 4 4 10', labelAlign : 'top',  
        listeners:{
          change:function(textarea){
            var val = textarea.getValue();
            var shareMessageHidden = Ext.getCmp('share-message-hidden');
            if (shareMessageHidden){
              shareMessageHidden.setValue(val);
            }
          }
        }
      }
    ],
    listeners:{
      afterrender: function(menu){
          var task = new Ext.util.DelayedTask(function(){
            menu.setHeight(310);
          });
          task.delay(50);
      },
      show: function(menu){
        menu.setHeight(310);
      }
    }
    
   };
    
    var collaborationsBtnGrpCfg = 
     {xtype:'buttongroup',  
       //margin:'0 8 0 0',
       id:'collaborationsBtnGrp', 
       itemId:'collaborationsBtnGrp', 
       cls:'xty_groupbuttons-btn-grp xty_collaborations-btn-grp',
       defaults:{
         //enableToggle:true,  
         handler: me.collabsBtnGrpBtnHandler
       },
       
       items:[

        {tooltip: loc.watch , itemId:'watch',   iconCls:'xty_pgtoolbar-watch', menuCfg: watchMenuCfg, pressed: isWatched, enableToggle:false },
        
        
        {tooltip: loc.comment,  itemId:'comment', menuCfg:  commentMenuCfg, iconCls:'xty_pgtoolbar-comment' },
        {tooltip: loc.share,  itemId:'share', menuCfg: shareMenuCfg,  iconCls:'xty_pgtoolbar-share' ,enableToggle:false},
       
        
        {tooltip: loc.faves,   itemId:'faves', iconCls:'xty_pgtoolbar-fave', enableToggle:true,   menuCfg:null},
        
        {tooltip: loc.collaborationOverview  , itemId:'more', enableToggle:false, width:null, iconCls:'xty_pgtoolbar-more' , menuCfg: moreMenuCfg, menuAllCfg: moreMenuAllCfg}
       ]
     };
     

    
	   return collaborationsBtnGrpCfg;   

   },
   
   
   toggleFave : function(){
     
     
   },
   
   
   handleStorageFromFile : function(fileStorage){    
     var me = this;   
     //alert(' handleStorageFromFile\n'+fileStorage) ;
     try{
       var fileData = Ext.decode(fileStorage);
       var collabsStore = me.localStorageStore; //Ext.data.StoreManager.lookup('localStorageStore').load(); 
       var i; 
       for(i = 0; i<fileData.length; i++){
          var recordDto = fileData[i];
          var collabId = recordDto.collabId;
          var collabRecord = collabsStore.findRecord('collabId', collabId); 
          if(!collabRecord){
           collabRecord =  Ext.create('Collaboration', recordDto ); 
           collabRecord.save(); 
          }
       } 
     }
     catch(ex){
       //alert('handleStorageFromFile Exception ' +ex);
     } 
   },
   
   
   getBaseUrl : function(){
     var me = this;
     if (!Ext.isDefined(me.baseUrl)){
       var baseUrl =  './';
       if ( me.isEmbedded() ){ 
         baseUrl = location.href.replace(/\/ajsp.*/,'/jsp');
       }
       baseUrl = location.href.replace(/\/jsp.*/,'/jsp');
       me.baseUrl = baseUrl; 
     }
     return me.baseUrl;
   },
   
   getCollabsUrl : function(){
     var me = this;
     if (!Ext.isDefined(me.collabsUrl)){
       var baseUrl =  './';
       if ( me.isEmbedded() ){ 
         baseUrl = location.href.replace(/\/ajsp.*/,'/jsp');
       }
       else{
         baseUrl = location.href.replace(/\/jsp.*/,'/jsp');
       }
       var collabsUrl = baseUrl + '/js/extjs/ext/examples/protos/collaboration';
       me.baseUrl = baseUrl; 
       me.collabsUrl = collabsUrl;  
     }
     return  me.collabsUrl;
   },
   
   readStorageFromFile : function(){
     var me = this;
     var collabsUrl =  me.getCollabsUrl();// baseUrl + '/js/extjs/ext/examples/protos/collaboration';
     window.fetch(collabsUrl+'/collabsStorage.json').then(response => response.text()).then(fileStorage => me.handleStorageFromFile(fileStorage));
   },
   writeStorageToFile : function(){
     
   }
   
   
   
   
	
 }



});
