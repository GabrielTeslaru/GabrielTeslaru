Ext.namespace('extVia.campaigns.projects.store');

extVia.campaigns.projects.store = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.projects.store",
    name : "extVia.campaigns.projects.store"
  });
};

extVia.campaigns.projects.store.prototype = {

  getEmptyTaskStore : function getEmptyTaskStore() {

    var emptyTaskStore = Ext.create("Gnt.data.TaskStore", {
      model : 'Gnt.model.Task',
      root : {
        name : 'root',
        expanded : true,
        children : []
      }
    });

    return emptyTaskStore;
  },

  getTasksStore : function getTasksStore() {
    
    Ext.define('MsProjectTask', {
      extend : 'Gnt.model.Task',
      inclusiveEndDate : true,
      fields : [ {
        name : 'Milestone',
        type : 'boolean',
        defaultValue : 'false'
      } ],

      isMilestone : function() {
        return this.get('Milestone');
      }
    });

    Ext.define('Tasks', {
      extend : 'Ext.data.Model',
      //extend : 'Gnt.model.Task',
      fields : [ "parentId", "index", "depth", "expanded", "expandable", "checked", "leaf", "cls", "iconCls", "icon",
                "root", "isLast", "isFirst", "allowDrop", "allowDrag", "loaded", "loading", "href", "hrefTarget",
                "qtip", "qtitle", "children", "Milestone", "StartDate", "EndDate", "Cls", "Name", "Id", "Duration",
                "Effort", "EffortUnit", "CalendarId", "PercentDone", "ManuallyScheduled", "SchedulingMode",
                "BaselineStartDate", "BaselineEndDate", "BaselinePercentDone", "Draggable", "Resizable", "PhantomId",
                "PhantomParentId", "DurationUnit" ]
    });

    var taskStore = Ext.create('Gnt.data.TaskStore', {
      model : 'MsProjectTask',
      proxy : {
        type : 'ajax',
        method : 'GET',
        url : 'projects/taskStore_formatiert.json',
        reader: {
           type: 'json'
             // ,root: 'users'
       }
      }
    });


    taskStore.load();

    return taskStore;
  },

  getTaskStor : function getTaskStor() {
    
    var taskStore = Ext.create("Gnt.data.TaskStore", {
      model : 'Gnt.model.Task',
      proxy : {
        type : 'ajax',
        method : 'GET',
        url : 'projects/tasks.xml',
        reader : {
          type : 'xml',
          record : "Task",
          root : "Tasks"
        }
      }
    });

    return taskStore;
  },

  getDependencyStore : function getDependencyStore() {

    var dependencyStore = Ext.create("Gnt.data.DependencyStore", {
      autoLoad : true,
      proxy : {
        type : 'ajax',
        url : 'projects/dependencies.xml',
        method : 'GET',
        reader : {
          type : 'xml',
          root : 'Links',
          record : 'Link'
        }
      }
    });

    return dependencyStore;
  },
  
  getGanttDummyData : function getGanttDummyData() {
    
      data ={
          "resources": [
              {
                  "Name": "VM/Kunde",
                  "Id": 1
              },
              {
                  "Name": "VM",
                  "Id": 2
              },
              {
                  "Name": "Kunde",
                  "Id": 3
              },
              {
                  "Name": "Viamedici/Armstron",
                  "Id": 4
              },
              {
                  "Name": "Viamedici",
                  "Id": 5
              },
              {
                  "Name": "Armstrong",
                  "Id": 6
              },
              {
                  "Name": "Viamedici/Customer",
                  "Id": 7
              },
              {
                  "Name": "Customer",
                  "Id": 8
              }
          ],
          "dependencies": [
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 36,
                  "Id": 0,
                  "From": 33
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 95,
                  "Id": 1,
                  "From": 33
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 93,
                  "Id": 2,
                  "From": 95
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 96,
                  "Id": 3,
                  "From": 93
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 39,
                  "Id": 4,
                  "From": 36
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 58,
                  "Id": 5,
                  "From": 39
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 57,
                  "Id": 6,
                  "From": 39
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 59,
                  "Id": 7,
                  "From": 58
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 59,
                  "Id": 8,
                  "From": 57
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 69,
                  "Id": 9,
                  "From": 59
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 90,
                  "Id": 10,
                  "From": 69
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 82,
                  "Id": 11,
                  "From": 90
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 38,
                  "Id": 12,
                  "From": 82
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 66,
                  "Id": 13,
                  "From": 38
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 60,
                  "Id": 14,
                  "From": 66
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 56,
                  "Id": 15,
                  "From": 60
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 55,
                  "Id": 16,
                  "From": 56
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 54,
                  "Id": 17,
                  "From": 60
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 53,
                  "Id": 18,
                  "From": 54
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 83,
                  "Id": 19,
                  "From": 60
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 83,
                  "Id": 20,
                  "From": 55
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 83,
                  "Id": 21,
                  "From": 53
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 91,
                  "Id": 22,
                  "From": 83
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 40,
                  "Id": 23,
                  "From": 83
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 88,
                  "Id": 24,
                  "From": 40
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 92,
                  "Id": 25,
                  "From": 88
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 51,
                  "Id": 26,
                  "From": 92
              },
              {
                  "Lag": "1.0",
                  "Type": 2,
                  "To": 50,
                  "Id": 27,
                  "From": 51
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 52,
                  "Id": 28,
                  "From": 50
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 84,
                  "Id": 29,
                  "From": 52
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 76,
                  "Id": 30,
                  "From": 83
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 75,
                  "Id": 31,
                  "From": 76
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 74,
                  "Id": 32,
                  "From": 75
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 87,
                  "Id": 33,
                  "From": 74
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 48,
                  "Id": 34,
                  "From": 84
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 47,
                  "Id": 35,
                  "From": 48
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 46,
                  "Id": 36,
                  "From": 47
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 49,
                  "Id": 37,
                  "From": 46
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 71,
                  "Id": 38,
                  "From": 84
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 72,
                  "Id": 39,
                  "From": 71
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 73,
                  "Id": 40,
                  "From": 72
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 86,
                  "Id": 41,
                  "From": 73
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 81,
                  "Id": 42,
                  "From": 49
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 98,
                  "Id": 43,
                  "From": 81
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 101,
                  "Id": 44,
                  "From": 98
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 102,
                  "Id": 45,
                  "From": 101
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 103,
                  "Id": 46,
                  "From": 102
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 78,
                  "Id": 47,
                  "From": 103
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 105,
                  "Id": 48,
                  "From": 103
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 107,
                  "Id": 49,
                  "From": 105
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 80,
                  "Id": 50,
                  "From": 107
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 79,
                  "Id": 51,
                  "From": 80
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 108,
                  "Id": 52,
                  "From": 79
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 89,
                  "Id": 53,
                  "From": 102
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 89,
                  "Id": 54,
                  "From": 105
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 89,
                  "Id": 55,
                  "From": 79
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 56,
                  "From": 82
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 57,
                  "From": 84
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 58,
                  "From": 86
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 59,
                  "From": 87
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 60,
                  "From": 89
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 61,
                  "From": 49
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 62,
                  "From": 96
              },
              {
                  "Lag": "0.0",
                  "Type": 2,
                  "To": 31,
                  "Id": 63,
                  "From": 83
              }
          ],
          "columns": [
              {
                  "xtype": "treecolumn",
                  "width": "540",
                  "dataIndex": "Name",
                  "header": "Task"
              },
              {
                  "xtype": "treecolumn",
                  "width": "110",
                  "dataIndex": "Duration",
                  "header": "Duration"
              },
              {
                  "xtype": "startdatecolumn",
                  "width": "120",
                  "header": "Start"
              },
              {
                  "xtype": "enddatecolumn",
                  "width": "120",
                  "header": "End"
              },
              {
                  "xtype": "treecolumn",
                  "width": "100",
                  "dataIndex": "Predecessors",
                  "header": "Predecessors"
              },
              {
                  "xtype": "resourceassignmentcolumn",
                  "width": "170",
                  "header": "Responsible"
              }
          ],
          "tasks": {
              "Name": "Root Node",
              "children": [{
                  "Name": "Project PIM",
                  "Milestone": false,
                  "EndDate": "2013-01-08",
                  "BaselineDuration": "0.0d",
                  "StartDate": "2012-04-02",
                  "BaselineEndDate": "2013-01-08",
                  "DurationUnit": "d",
                  "Duration": "189.0",
                  "PercentDone": 0,
                  "children": [
                      {
                          "Name": "MS - Projektstart",
                          "Milestone": true,
                          "EndDate": "2012-04-02",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-04-02",
                          "BaselineEndDate": "2012-04-02",
                          "DurationUnit": "d",
                          "Duration": "0.0",
                          "PercentDone": 0,
                          "Id": 33,
                          "leaf": true,
                          "BaselineStartDate": "2012-04-02"
                      },
                      {
                          "Name": "Projekt Kick Off",
                          "Milestone": false,
                          "EndDate": "2012-04-02",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-04-02",
                          "BaselineEndDate": "2012-04-02",
                          "DurationUnit": "d",
                          "Duration": "1.0",
                          "PercentDone": 0,
                          "Id": 36,
                          "leaf": true,
                          "BaselineStartDate": "2012-04-02"
                      },
                      {
                          "Name": "Installation Viamedici EPIM",
                          "Milestone": false,
                          "EndDate": "2012-04-03",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-04-02",
                          "BaselineEndDate": "2012-04-03",
                          "DurationUnit": "d",
                          "Duration": "2.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Installation Viamedici EPIM",
                                  "Milestone": false,
                                  "EndDate": "2012-04-02",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-04-02",
                                  "BaselineEndDate": "2012-04-02",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 95,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-04-02"
                              },
                              {
                                  "Name": "Installation Fremdprodukte",
                                  "Milestone": false,
                                  "EndDate": "2012-04-03",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-04-03",
                                  "BaselineEndDate": "2012-04-03",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 93,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-04-03"
                              },
                              {
                                  "Name": "MS - Installation fertig",
                                  "Milestone": true,
                                  "EndDate": "2012-04-03",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-04-03",
                                  "BaselineEndDate": "2012-04-03",
                                  "DurationUnit": "d",
                                  "Duration": "0.0",
                                  "PercentDone": 0,
                                  "Id": 96,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-04-03"
                              }
                          ],
                          "Id": 94,
                          "leaf": false,
                          "BaselineStartDate": "2012-04-02"
                      },
                      {
                          "Name": "Konfiguration/Datenbefuellung Viamedici EPIM \"Pilot\"",
                          "Milestone": false,
                          "EndDate": "2012-07-30",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-04-03",
                          "BaselineEndDate": "2012-07-30",
                          "DurationUnit": "d",
                          "Duration": "79.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Konfiguration",
                                  "Milestone": false,
                                  "EndDate": "2012-05-14",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-04-03",
                                  "BaselineEndDate": "2012-05-14",
                                  "DurationUnit": "d",
                                  "Duration": "27.0",
                                  "PercentDone": 0,
                                  "children": [
                                      {
                                          "Name": "Workshop Konfiguration",
                                          "Milestone": false,
                                          "EndDate": "2012-04-03",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-04-03",
                                          "BaselineEndDate": "2012-04-03",
                                          "DurationUnit": "d",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 39,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-04-03"
                                      },
                                      {
                                          "Name": "Definition Produktgruppen",
                                          "Milestone": false,
                                          "EndDate": "2012-04-19",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-04-04",
                                          "BaselineEndDate": "2012-04-19",
                                          "DurationUnit": "w",
                                          "Duration": "2.0",
                                          "PercentDone": 0,
                                          "Id": 58,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-04-04"
                                      },
                                      {
                                          "Name": "Definition Produktattribute",
                                          "Milestone": false,
                                          "EndDate": "2012-04-19",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-04-04",
                                          "BaselineEndDate": "2012-04-19",
                                          "DurationUnit": "w",
                                          "Duration": "2.0",
                                          "PercentDone": 0,
                                          "Id": 57,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-04-04"
                                      },
                                      {
                                          "Name": "Zuordnung Produktattribute zu Produktgruppen",
                                          "Milestone": false,
                                          "EndDate": "2012-05-04",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-04-20",
                                          "BaselineEndDate": "2012-05-04",
                                          "DurationUnit": "w",
                                          "Duration": "2.0",
                                          "PercentDone": 0,
                                          "Id": 59,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-04-20"
                                      },
                                      {
                                          "Name": "Import Konfigurationsdateien",
                                          "Milestone": false,
                                          "EndDate": "2012-05-11",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-05-07",
                                          "BaselineEndDate": "2012-05-11",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 69,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-05-07"
                                      },
                                      {
                                          "Name": "Training adminCONTENT/adminPRODUCT",
                                          "Milestone": false,
                                          "EndDate": "2012-05-14",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-05-14",
                                          "BaselineEndDate": "2012-05-14",
                                          "DurationUnit": "d",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 90,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-05-14"
                                      },
                                      {
                                          "Name": "MS - Konfiguration fertig",
                                          "Milestone": true,
                                          "EndDate": "2012-05-14",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-05-14",
                                          "BaselineEndDate": "2012-05-14",
                                          "DurationUnit": "d",
                                          "Duration": "0.0",
                                          "PercentDone": 0,
                                          "Id": 82,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-05-14"
                                      }
                                  ],
                                  "Id": 67,
                                  "leaf": false,
                                  "BaselineStartDate": "2012-04-03"
                              },
                              {
                                  "Name": "Datenimport",
                                  "Milestone": false,
                                  "EndDate": "2012-07-30",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-05-15",
                                  "BaselineEndDate": "2012-07-30",
                                  "DurationUnit": "d",
                                  "Duration": "52.0",
                                  "PercentDone": 0,
                                  "children": [
                                      {
                                          "Name": "Workshop Datenimport",
                                          "Milestone": false,
                                          "EndDate": "2012-05-15",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-05-15",
                                          "BaselineEndDate": "2012-05-15",
                                          "DurationUnit": "d",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 38,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-05-15"
                                      },
                                      {
                                          "Name": "Vorbereitung Produkte und Attribute",
                                          "Milestone": false,
                                          "EndDate": "2012-06-15",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-05-16",
                                          "BaselineEndDate": "2012-06-15",
                                          "DurationUnit": "w",
                                          "Duration": "4.0",
                                          "PercentDone": 0,
                                          "Id": 66,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-05-16"
                                      },
                                      {
                                          "Name": "Import Produkte und Attribute",
                                          "Milestone": false,
                                          "EndDate": "2012-06-22",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-06-18",
                                          "BaselineEndDate": "2012-06-22",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 60,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-06-18"
                                      },
                                      {
                                          "Name": "Vorbereitung Produktbeziehungen",
                                          "Milestone": false,
                                          "EndDate": "2012-07-06",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-06-25",
                                          "BaselineEndDate": "2012-07-06",
                                          "DurationUnit": "w",
                                          "Duration": "2.0",
                                          "PercentDone": 0,
                                          "Id": 56,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-06-25"
                                      },
                                      {
                                          "Name": "Import Produktbeziehungen",
                                          "Milestone": false,
                                          "EndDate": "2012-07-13",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-07-09",
                                          "BaselineEndDate": "2012-07-13",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 55,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-07-09"
                                      },
                                      {
                                          "Name": "Vorbereitung Contentelemente (Bilder, Grafiken)",
                                          "Milestone": false,
                                          "EndDate": "2012-07-20",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-06-25",
                                          "BaselineEndDate": "2012-07-20",
                                          "DurationUnit": "w",
                                          "Duration": "4.0",
                                          "PercentDone": 0,
                                          "Id": 54,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-06-25"
                                      },
                                      {
                                          "Name": "Import Contentelemente",
                                          "Milestone": false,
                                          "EndDate": "2012-07-27",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-07-23",
                                          "BaselineEndDate": "2012-07-27",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 53,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-07-23"
                                      },
                                      {
                                          "Name": "MS - Datenimport fertig",
                                          "Milestone": true,
                                          "EndDate": "2012-07-27",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-07-27",
                                          "BaselineEndDate": "2012-07-27",
                                          "DurationUnit": "d",
                                          "Duration": "0.0",
                                          "PercentDone": 0,
                                          "Id": 83,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-07-27"
                                      },
                                      {
                                          "Name": "Training viaCONTENT/viaPRODUCT",
                                          "Milestone": false,
                                          "EndDate": "2012-07-30",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-07-30",
                                          "BaselineEndDate": "2012-07-30",
                                          "DurationUnit": "d",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 91,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-07-30"
                                      }
                                  ],
                                  "Id": 68,
                                  "leaf": false,
                                  "BaselineStartDate": "2012-05-15"
                              }
                          ],
                          "Id": 28,
                          "leaf": false,
                          "BaselineStartDate": "2012-04-03"
                      },
                      {
                          "Name": "Realisierung Pilotpublikation",
                          "Milestone": false,
                          "EndDate": "2012-10-10",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-07-30",
                          "BaselineEndDate": "2012-10-10",
                          "DurationUnit": "d",
                          "Duration": "52.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Workshop Publikation",
                                  "Milestone": false,
                                  "EndDate": "2012-07-30",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-07-30",
                                  "BaselineEndDate": "2012-07-30",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 40,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-07-30"
                              },
                              {
                                  "Name": "Publikationsplanung (Beispiel)",
                                  "Milestone": false,
                                  "EndDate": "2012-08-06",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-07-31",
                                  "BaselineEndDate": "2012-08-06",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 88,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-07-31"
                              },
                              {
                                  "Name": "Training viaPUBLISH",
                                  "Milestone": false,
                                  "EndDate": "2012-08-07",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-08-07",
                                  "BaselineEndDate": "2012-08-07",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 92,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-08-07"
                              },
                              {
                                  "Name": "Realisierung DTP",
                                  "Milestone": false,
                                  "EndDate": "2012-09-04",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-08-08",
                                  "BaselineEndDate": "2012-09-04",
                                  "DurationUnit": "w",
                                  "Duration": "4.0",
                                  "PercentDone": 0,
                                  "Id": 51,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-08-08"
                              },
                              {
                                  "Name": "Kontrolle Daten/Layout",
                                  "Milestone": false,
                                  "EndDate": "2012-09-25",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-08-29",
                                  "BaselineEndDate": "2012-09-25",
                                  "DurationUnit": "w",
                                  "Duration": "4.0",
                                  "PercentDone": 0,
                                  "Id": 50,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-08-29"
                              },
                              {
                                  "Name": "Finetuning",
                                  "Milestone": false,
                                  "EndDate": "2012-10-10",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-09-26",
                                  "BaselineEndDate": "2012-10-10",
                                  "DurationUnit": "w",
                                  "Duration": "2.0",
                                  "PercentDone": 0,
                                  "Id": 52,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-09-26"
                              },
                              {
                                  "Name": "MS - Printpublikation fertig",
                                  "Milestone": true,
                                  "EndDate": "2012-10-10",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-10",
                                  "BaselineEndDate": "2012-10-10",
                                  "DurationUnit": "d",
                                  "Duration": "0.0",
                                  "PercentDone": 0,
                                  "Id": 84,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-10"
                              }
                          ],
                          "Id": 26,
                          "leaf": false,
                          "BaselineStartDate": "2012-07-30"
                      },
                      {
                          "Name": "ERP",
                          "Milestone": false,
                          "EndDate": "2012-08-13",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-07-30",
                          "BaselineEndDate": "2012-08-13",
                          "DurationUnit": "d",
                          "Duration": "11.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Workshop",
                                  "Milestone": false,
                                  "EndDate": "2012-07-30",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-07-30",
                                  "BaselineEndDate": "2012-07-30",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 76,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-07-30"
                              },
                              {
                                  "Name": "Definition Uebergabedaten",
                                  "Milestone": false,
                                  "EndDate": "2012-08-06",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-07-31",
                                  "BaselineEndDate": "2012-08-06",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 75,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-07-31"
                              },
                              {
                                  "Name": "Import in Viamedici EPIM",
                                  "Milestone": false,
                                  "EndDate": "2012-08-13",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-08-07",
                                  "BaselineEndDate": "2012-08-13",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 74,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-08-07"
                              },
                              {
                                  "Name": "MS - Schnittstelle fertig",
                                  "Milestone": true,
                                  "EndDate": "2012-08-13",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-08-13",
                                  "BaselineEndDate": "2012-08-13",
                                  "DurationUnit": "d",
                                  "Duration": "0.0",
                                  "PercentDone": 0,
                                  "Id": 87,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-08-13"
                              }
                          ],
                          "Id": 24,
                          "leaf": false,
                          "BaselineStartDate": "2012-07-30"
                      },
                      {
                          "Name": "Workflow",
                          "Milestone": false,
                          "EndDate": "2012-10-25",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-10-11",
                          "BaselineEndDate": "2012-10-25",
                          "DurationUnit": "d",
                          "Duration": "11.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Workshop",
                                  "Milestone": false,
                                  "EndDate": "2012-10-11",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-11",
                                  "BaselineEndDate": "2012-10-11",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 48,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-11"
                              },
                              {
                                  "Name": "Implementierung Workflow",
                                  "Milestone": false,
                                  "EndDate": "2012-10-18",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-12",
                                  "BaselineEndDate": "2012-10-18",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 47,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-12"
                              },
                              {
                                  "Name": "Test und Uebergabe",
                                  "Milestone": false,
                                  "EndDate": "2012-10-25",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-19",
                                  "BaselineEndDate": "2012-10-25",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 46,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-19"
                              },
                              {
                                  "Name": "MS - Abnahme Workflow",
                                  "Milestone": true,
                                  "EndDate": "2012-10-25",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-25",
                                  "BaselineEndDate": "2012-10-25",
                                  "DurationUnit": "d",
                                  "Duration": "0.0",
                                  "PercentDone": 0,
                                  "Id": 49,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-25"
                              }
                          ],
                          "Id": 22,
                          "leaf": false,
                          "BaselineStartDate": "2012-10-11"
                      },
                      {
                          "Name": "Datenaustauschformate",
                          "Milestone": false,
                          "EndDate": "2012-11-08",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-10-11",
                          "BaselineEndDate": "2012-11-08",
                          "DurationUnit": "d",
                          "Duration": "20.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Katalogformat",
                                  "Milestone": false,
                                  "EndDate": "2012-10-17",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-11",
                                  "BaselineEndDate": "2012-10-17",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 71,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-11"
                              },
                              {
                                  "Name": "Klassifikation",
                                  "Milestone": false,
                                  "EndDate": "2012-10-31",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-18",
                                  "BaselineEndDate": "2012-10-31",
                                  "DurationUnit": "w",
                                  "Duration": "2.0",
                                  "PercentDone": 0,
                                  "Id": 72,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-18"
                              },
                              {
                                  "Name": "Erstellung Elektronischer Katalog",
                                  "Milestone": false,
                                  "EndDate": "2012-11-08",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-11-02",
                                  "BaselineEndDate": "2012-11-08",
                                  "DurationUnit": "w",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 73,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-11-02"
                              },
                              {
                                  "Name": "MS - elektronischer Katalog fertig",
                                  "Milestone": true,
                                  "EndDate": "2012-11-08",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-11-08",
                                  "BaselineEndDate": "2012-11-08",
                                  "DurationUnit": "d",
                                  "Duration": "0.0",
                                  "PercentDone": 0,
                                  "Id": 86,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-11-08"
                              }
                          ],
                          "Id": 43,
                          "leaf": false,
                          "BaselineStartDate": "2012-10-11"
                      },
                      {
                          "Name": "Online",
                          "Milestone": false,
                          "EndDate": "2013-01-08",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2012-10-26",
                          "BaselineEndDate": "2013-01-08",
                          "DurationUnit": "d",
                          "Duration": "47.0",
                          "PercentDone": 0,
                          "children": [
                              {
                                  "Name": "Workshop",
                                  "Milestone": false,
                                  "EndDate": "2012-10-26",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-26",
                                  "BaselineEndDate": "2012-10-26",
                                  "DurationUnit": "d",
                                  "Duration": "1.0",
                                  "PercentDone": 0,
                                  "Id": 81,
                                  "leaf": true,
                                  "BaselineStartDate": "2012-10-26"
                              },
                              {
                                  "Name": "Konzept",
                                  "Milestone": false,
                                  "EndDate": "2012-12-04",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-10-29",
                                  "BaselineEndDate": "2012-12-04",
                                  "DurationUnit": "d",
                                  "Duration": "26.0",
                                  "PercentDone": 0,
                                  "children": [
                                      {
                                          "Name": "Konzeption Website",
                                          "Milestone": false,
                                          "EndDate": "2012-11-26",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-10-29",
                                          "BaselineEndDate": "2012-11-26",
                                          "DurationUnit": "w",
                                          "Duration": "4.0",
                                          "PercentDone": 0,
                                          "Id": 98,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-10-29"
                                      },
                                      {
                                          "Name": "Konzeptworkshop",
                                          "Milestone": false,
                                          "EndDate": "2012-11-27",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-11-27",
                                          "BaselineEndDate": "2012-11-27",
                                          "DurationUnit": "d",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 101,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-11-27"
                                      },
                                      {
                                          "Name": "Finetuning Website",
                                          "Milestone": false,
                                          "EndDate": "2012-12-04",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-11-28",
                                          "BaselineEndDate": "2012-12-04",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 102,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-11-28"
                                      },
                                      {
                                          "Name": "MS - Abnahme Konzeption Website",
                                          "Milestone": true,
                                          "EndDate": "2012-12-04",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-12-04",
                                          "BaselineEndDate": "2012-12-04",
                                          "DurationUnit": "d",
                                          "Duration": "0.0",
                                          "PercentDone": 0,
                                          "Id": 103,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-12-04"
                                      }
                                  ],
                                  "Id": 99,
                                  "leaf": false,
                                  "BaselineStartDate": "2012-10-29"
                              },
                              {
                                  "Name": "Implementierung",
                                  "Milestone": false,
                                  "EndDate": "2013-01-08",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-12-05",
                                  "BaselineEndDate": "2013-01-08",
                                  "DurationUnit": "d",
                                  "Duration": "20.0",
                                  "PercentDone": 0,
                                  "children": [
                                      {
                                          "Name": "Realisierung Website",
                                          "Milestone": false,
                                          "EndDate": "2013-01-08",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-12-05",
                                          "BaselineEndDate": "2013-01-08",
                                          "DurationUnit": "w",
                                          "Duration": "4.0",
                                          "PercentDone": 0,
                                          "Id": 78,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-12-05"
                                      },
                                      {
                                          "Name": "Realisierung spezieller Funktionen",
                                          "Milestone": false,
                                          "EndDate": "2012-12-18",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-12-05",
                                          "BaselineEndDate": "2012-12-18",
                                          "DurationUnit": "w",
                                          "Duration": "2.0",
                                          "PercentDone": 0,
                                          "Id": 105,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-12-05"
                                      },
                                      {
                                          "Name": "MS - Implementierung fertig",
                                          "Milestone": true,
                                          "EndDate": "2012-12-18",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-12-18",
                                          "BaselineEndDate": "2012-12-18",
                                          "DurationUnit": "d",
                                          "Duration": "0.0",
                                          "PercentDone": 0,
                                          "Id": 107,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-12-18"
                                      }
                                  ],
                                  "Id": 104,
                                  "leaf": false,
                                  "BaselineStartDate": "2012-12-05"
                              },
                              {
                                  "Name": "Datentransfer EPIM -> Website",
                                  "Milestone": false,
                                  "EndDate": "2013-01-08",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2012-12-19",
                                  "BaselineEndDate": "2013-01-08",
                                  "DurationUnit": "d",
                                  "Duration": "10.0",
                                  "PercentDone": 0,
                                  "children": [
                                      {
                                          "Name": "Publikationsplanung",
                                          "Milestone": false,
                                          "EndDate": "2012-12-28",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2012-12-19",
                                          "BaselineEndDate": "2012-12-28",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 80,
                                          "leaf": true,
                                          "BaselineStartDate": "2012-12-19"
                                      },
                                      {
                                          "Name": "Realisierung der Transformation",
                                          "Milestone": false,
                                          "EndDate": "2013-01-08",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2013-01-02",
                                          "BaselineEndDate": "2013-01-08",
                                          "DurationUnit": "w",
                                          "Duration": "1.0",
                                          "PercentDone": 0,
                                          "Id": 79,
                                          "leaf": true,
                                          "BaselineStartDate": "2013-01-02"
                                      },
                                      {
                                          "Name": "MS - Datenuebergabe fertig",
                                          "Milestone": true,
                                          "EndDate": "2013-01-08",
                                          "BaselineDuration": "0.0d",
                                          "StartDate": "2013-01-08",
                                          "BaselineEndDate": "2013-01-08",
                                          "DurationUnit": "d",
                                          "Duration": "0.0",
                                          "PercentDone": 0,
                                          "Id": 108,
                                          "leaf": true,
                                          "BaselineStartDate": "2013-01-08"
                                      }
                                  ],
                                  "Id": 100,
                                  "leaf": false,
                                  "BaselineStartDate": "2012-12-19"
                              },
                              {
                                  "Name": "MS - Website fertig",
                                  "Milestone": true,
                                  "EndDate": "2013-01-08",
                                  "BaselineDuration": "0.0d",
                                  "StartDate": "2013-01-08",
                                  "BaselineEndDate": "2013-01-08",
                                  "DurationUnit": "d",
                                  "Duration": "0.0",
                                  "PercentDone": 0,
                                  "Id": 89,
                                  "leaf": true,
                                  "BaselineStartDate": "2013-01-08"
                              }
                          ],
                          "Id": 23,
                          "leaf": false,
                          "BaselineStartDate": "2012-10-26"
                      },
                      {
                          "Name": "MS - Projektende",
                          "Milestone": true,
                          "EndDate": "2013-01-08",
                          "BaselineDuration": "0.0d",
                          "StartDate": "2013-01-08",
                          "BaselineEndDate": "2013-01-08",
                          "DurationUnit": "d",
                          "Duration": "0.0",
                          "PercentDone": 0,
                          "Id": 31,
                          "leaf": true,
                          "BaselineStartDate": "2013-01-08"
                      }
                  ],
                  "Id": 34,
                  "leaf": false,
                  "BaselineStartDate": "2012-04-02"
              }]
          },
          "assignments": [
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 42,
                  "TaskId": 47
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 45,
                  "TaskId": 51
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 58,
                  "TaskId": 60
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 60,
                  "TaskId": 55
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 62,
                  "TaskId": 53
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 63,
                  "TaskId": 69
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 70,
                  "TaskId": 74
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 78,
                  "TaskId": 78
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 79,
                  "TaskId": 80
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 80,
                  "TaskId": 88
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 81,
                  "TaskId": 79
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 87,
                  "TaskId": 93
              },
              {
                  "Units": 100,
                  "ResourceId": 5,
                  "Id": 88,
                  "TaskId": 95
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 31,
                  "TaskId": 36
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 32,
                  "TaskId": 39
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 33,
                  "TaskId": 38
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 34,
                  "TaskId": 40
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 41,
                  "TaskId": 48
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 43,
                  "TaskId": 46
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 47,
                  "TaskId": 52
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 48,
                  "TaskId": 58
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 49,
                  "TaskId": 57
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 50,
                  "TaskId": 59
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 65,
                  "TaskId": 71
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 66,
                  "TaskId": 72
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 67,
                  "TaskId": 73
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 68,
                  "TaskId": 76
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 69,
                  "TaskId": 75
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 71,
                  "TaskId": 81
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 83,
                  "TaskId": 90
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 84,
                  "TaskId": 91
              },
              {
                  "Units": 100,
                  "ResourceId": 7,
                  "Id": 85,
                  "TaskId": 92
              },
              {
                  "Units": 100,
                  "ResourceId": 8,
                  "Id": 46,
                  "TaskId": 50
              },
              {
                  "Units": 100,
                  "ResourceId": 8,
                  "Id": 57,
                  "TaskId": 66
              },
              {
                  "Units": 100,
                  "ResourceId": 8,
                  "Id": 59,
                  "TaskId": 56
              },
              {
                  "Units": 100,
                  "ResourceId": 8,
                  "Id": 61,
                  "TaskId": 54
              }
          ]
      };
      
      return data;
  }

};

// init Object as singleton
extVia.campaigns.projects.store = new extVia.campaigns.projects.store();

/*
 * 
 * $Revision: 1.3 $ $Modtime: 10.10.12 12:39 $ $Date: 2012/11/16 17:42:29 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */