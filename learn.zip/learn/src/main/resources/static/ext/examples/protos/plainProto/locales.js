Ext.namespace('extVia.locales' ,'extVia.plainProto.locales');
/**
 * @class extVia.plainProto.locales
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2014/07/25 10:54:07 $
 *            $Revision: 1.1 $
 */

extVia.plainProto.locales = {
        appName:'plainProto',
};

Ext.apply(extVia.locales, extVia.plainProto.locales);



/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2014/07/25 10:54:07 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 