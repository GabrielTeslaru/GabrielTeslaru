extVia.versionsProto.Metabo_Power_Maxx_BS_Quick_v1 = 
[
// Metadata areaorder: 1              

{"name":"Hierarchie","infoId":"metaSThierarchy","area":"Metadata","areaorder":"1", "baseAction":"INSERT", "dataType":"String","valueWork":"Metabo  \u00bb Elektrowerkzeuge  \u00bb Akkuger\u00E4te  \u00bb Akku-Bohrschrauber  \u00bb Metabo Power Maxx","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"11:05:00","valueVersion":"","userVersion":"","changedateVersion":"","changetimeVersion":"","epimIdWork":"ms_h-2","epimIdVersion":"ms_h-2"},                    
{"name":"EPIM Objekttyp","infoId":"metaSTepobtype","area":"Metadata","areaorder":"1","baseAction":"CREATE", "dataType":"String","valueWork":"Productvariant","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"11:05:00","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"bp_e-1","epimIdVersion":"bp_e-1"},
{"name":"Name","infoId":"metaSTname","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"String","valueWork":"Metabo Power Maxx Quick","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"11:05:00","valueVersion":"","userVersion":"","changedateVersion":"","changetimeVersion":"","epimIdWork":"ms_n-1","epimIdVersion":"ms_n-1"},
{"name":"Id","infoId":"metaNUid","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"Number","valueWork":"358","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"11:05:00","valueVersion":"","userVersion":"","changedateVersion":"","changetimeVersion":"","epimIdWork":"mn_i-1","epimIdVersion":"mn_i-1"},
{"name":"Versionsnummer","infoId":"metaNUversion","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"Number","valueWork":"1","changedateWork":"10.02.2014","valueVersion":"1","userWork":"Nina Simone","changetimeWork":"17:37:59","epimIdWork":"mn_v-11","epimIdVersion":"mn_v-11"},
     
{"name":"Artikelnummer","infoId":"metaNUartikel","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"Number","valueWork":"6.00157.50","userWork":"Dieter Rams","changedateWork":"26.02.2014","changetimeWork":"16:41:51","valueVersion":"","changedateVersion":"","epimIdWork":"mn_a-1","epimIdVersion":"mn_a-1"},
{"name":"Mastersprache","infoId":"metaLAmasterlang","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"Language","valueWork":"de","userWork":"Bernard Purdie","changedateWork":"26.02.2014","changetimeWork":"16:50:46","valueVersion":"","changedateVersion":"","epimIdWork":"ml_m-1","epimIdVersion":"ml_m-1"},
{"name":"Reihenfolge","infoId":"metaNUorder","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"Number","valueWork":"10","userWork":"Bernard Purdie","changedateWork":"29.04.2014","changetimeWork":"17:03:13","valueVersion":"","changedateVersion":"","epimIdWork":"mn_r-1","epimIdVersion":"mn_r-1"},

{"name":"Produktbild","infoId":"metaIMproductimage","area":"Metadata","areaorder":"1","baseAction":"ASSIGN","dataType":"Image","specprop-link":"","valueWork":"Produktbild Metabo Power Maxx BS Quick s|" +
    "./dummies/infoImages/elemente/Metabo_Power_Maxx_BS_Quick_side.jpg","userWork":"Gene Krupa","changedateWork":"10.02.2014","changetimeWork":"15:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"ei_p-1","epimIdVersion":"ei_p-1"},

{"name":"Anlagedatum","infoId":"metaCHcreation", "area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"ChangeInfo","valueWork":"05.02.2014","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"16:30:00","valueVersion":"","changedateVersion":"","epimIdWork":"mc_a-2","epimIdVersion":"mc_a-2"},
{"name":"\u00c4nderungsdatum","infoId":"metaCHchange","area":"Metadata","areaorder":"1","baseAction":"CREATE","dataType":"ChangeInfo","valueWork":"10.02.2014","userWork":"Bernard Purdie","changedateWork":"10.02.2014","changetimeWork":"15:45:44","valueVersion":"","changedateVersion":"","epimIdWork":"mc_\u00e4-1","epimIdVersion":"mc_\u00e4-1"},
    

// Attribute
{"name":"Allgemeine Daten","infoId":"atATal5_148247","area":"Attribute","areaorder":" 4","baseAction":"ASSIGN","dataType":"AttributeCollection","specprop-multiplicity":"1","collectionEntryType":"String","collectionEntryName":"","specprop-collectionEntries":"","specprop-link":"","valueWork":"","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:18:18","valueVersion":"","changedateVersion":"","epimIdWork":"ac_a-1","epimIdVersion":"ac_a-1"},
{"name":"Bereich","infoId":"atDIbe6_148313","area":"Attribute","areaorder":" 4","baseAction":"INSERT","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"Elektrowerkzeug","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:25:29","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"ad_b-1","epimIdVersion":"ad_b-1"},
{"name":"Kategorie","infoId":"atDIka7_148326","area":"Attribute","areaorder":" 4","baseAction":"INSERT","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"Akku-Bohrschrauber","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:32:50","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"ad_k-1","epimIdVersion":"ad_k-1"},
{"name":"Produkt","infoId":"atDIpr8_148346","area":"Attribute","areaorder":" 4","baseAction":"ASSIGN","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"4.6-Volt-Akku-Bohrschrauber Power Maxx","userWork":"Bernard Purdie","changedateWork":"05.02.2014","changetimeWork":"16:33:22","valueVersion":"4.7-Volt-Akku-Bohrschrauber Power Maxx","userVersion":"","changedateVersion":"","epimIdWork":"ad_p-2","epimIdVersion":"ad_p-2"},
{"name":"Marketing-Daten","infoId":"atDIma9_148370","area":"Attribute","areaorder":" 4","baseAction":"ASSIGN","dataType":"AttributeCollection","specprop-multiplicity":"1","collectionEntryType":"String","collectionEntryName":"","specprop-collectionEntries":"","specprop-link":"","valueWork":"","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:42:55","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"aa_m-1","epimIdVersion":"aa_m-1"},
{"name":"Marke","infoId":"atDIma1_148415","area":"Attribute","areaorder":" 4","baseAction":"UPDATE","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"Metabo","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:51:57","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"ad_m-1","epimIdVersion":"ad_m-1"},
{"name":"Claim","infoId":"atDIcl2_148445","area":"Attribute","areaorder":" 4","baseAction":"UPDATE","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"work. don't play.","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:52:34","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"ad_c-2","epimIdVersion":"ad_c-2"},

{"name":"CLAIMY","infoId":"atDIclyyy2_148445","area":"Attribute","areaorder":" 4","baseAction":"ASSIGN","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"work. don't play.","userWork":"Bernard Purdie","changedateWork":"30.04.2014","changetimeWork":"16:52:34","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"ad_c-2","epimIdVersion":"ad_c-2"},




// last Attribute
///{"name":"Bauweise","infoId":"atDIba1_150933","area":"Attribute","areaorder":" 4","dataType":"Dictionary","specprop-multiplicity":"1","specprop-link":"","valueWork":"Mittelhandgriff","userWork":"R\u00fcdiger Bodemer","changedateWork":"30.04.2014","changetimeWork":"16:34:26","valueVersion":"","userVersion":"","changedateVersion":"","epimIdWork":"ad_b-3","epimIdVersion":"ad_b-3"}


];

