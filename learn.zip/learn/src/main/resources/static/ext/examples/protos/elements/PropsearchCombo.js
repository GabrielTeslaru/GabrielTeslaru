/**
 * @author S.Lederer (s.lederer@viamedici.de)
 * 
 * Extending a combo to provide property-search, which means searching by specific properties and searchtext.<br>
 * Adds 4 Triggers:  search, property-selector, clear and extended. <br>
 * Supports  property-selection, autocomplete, previous searches and extended search. <br>
 */
Ext.define('extVia.ux.widgets.PropsearchCombo', {
  extend : 'Ext.form.field.ComboBox',
  alias:  'widget.propsearchcombo',
  componentCls:'xty_propsearch-combo xty_formfield-XL xty_has-insidetrigger', 
  itemId: "propsearchcombo",
  height:30,
  width:380,
  mode: 'local',

  pickerOffset : [ 66, 4 ],
  
   listConfig : {
     cls :'xty_propsearch-types-boundlist',
     maxWidth:180,
     itemTpl:'<div style="width:100%;padding-left:16px;height:18px;" title="{value}" class="xty_propsearch-autocomplete-item">' + '&nbsp; {name}' + '<span style="color:#ccc;"> &nbsp;&nbsp;</span></div>'
  },

  enableKeyEvents:true,
  
  
  validateOnChange: false,
  validateOnBlur: false,
  /**
   * Specify false to validate that a prop must be given to do a search.
   * Defaults true, would mean search all...
   */
  allowBlankProps: true, 
  emptyPropsText: 'Props should not be empty.', // located Text should be given by using app
  defaultProp: 'empty', // can be given by using app-statemanager
  
  validateProps:function(value){
    var me = this;
    var field = this;
    var valid =  me.emptyPropsText;
    if (!Ext.isEmpty(field.searchproperty)){
      valid = true;
    }
    return valid;
  },
  
  

  
  
  listeners:{
    focus:function(field, evt){
     //field.setWidth(500, true);
      var fieldIsEmpty = Ext.isEmpty(field.getValue());
      
      // show last searches
      if (fieldIsEmpty  && field.lastSearches){  
        field.createSearchesPicker(field);
        field.searchespickerStore.loadData(field.lastSearches);
        field.searchespicker.alignTo(field.inputEl, 'tl-bl?', [ 60, 4 ]);
        field.searchespicker.show(field.inputEl);
        
        
        
//        if (! field.searchespicker){
//          field.searchespickerStore.loadData(field.lastSearches);
//        }
//        
//        if (field.searchespickerStore){
//          field.searchespickerStore.loadData(field.lastSearches);
//        }
        
        //fieldStore.loadData( field.lastSearches );
//        if (field.searchespicker && field.searchespicker.isVisible() ){
//          field.searchespicker.hide();
//        }
//        else{
//          field.createSearchesPicker(field);
//          field.searchespickerStore.loadData(field.lastSearches);
//          field.searchespicker.alignTo(field.inputEl, 'tl-bl?', [ 84, 4 ]);
//          field.searchespicker.show(field.inputEl);
//        }  
      }
    },
    
    
    blur:function(field, evt){
       //field.hideAllPickersBut('formpicker'); You cant't select on the pickers then delay?
      
      var hideAllPickersButTask = new Ext.util.DelayedTask(function(){
        field.hideAllPickersBut('formpicker');
      });
      hideAllPickersButTask.delay(200);
    },
    
    
    change:function(field, newValue, oldValue ){
      //searchResultHandler(field, evt);
      field.hideAllPickersBut('');
    },
   
    
    keydown:function(field, evt){
     if (evt.getKey()===Ext.EventObject.ENTER){
       //queryCfg.searchtext = field.getValue();
       //me.querySubmit(queryCfg); 
       field.search(field, evt);
     }
    else if (evt.getKey()===Ext.EventObject.DELETE){
      field.setValue(''); 
    }
    } 
  }, 
  
  hideAllPickersBut: function(pickerNotToHide) {
    var field = this;
    
    if (  pickerNotToHide!=='searchespicker'   && field.searchespicker && field.searchespicker.isVisible() ){
      field.searchespicker.hide();
    }
    if ( pickerNotToHide!=='propspicker'  && field.propspicker && field.propspicker.isVisible() ){
      field.propspicker.hide();
    }
    if ( pickerNotToHide!=='formpicker'  && field.formpicker && field.formpicker.isVisible() ){
      field.formpicker.hide();
    }
    if ( pickerNotToHide!=='fieldpicker'   && field.getPicker().isVisible() ){
      field.getPicker().hide();
    }    
  },
  
  
  createSearchesPicker: function(field) {
    var me = this;
    
    var  searchespickerStore = Ext.create('Ext.data.Store', { 
      fields: [ 'name'], 
      data: field.lastSearches
    });   

    var searchespicker =  Ext.create('Ext.view.BoundList',  {
      xtype: 'boundlist',
      cls:'xty_propsearch-searchespicker-boundlist',
      itemId: 'searchespicker-boundlist',
      width:240,
      style:' position: absolute; z-index: 1999; font-size: 12pt; font-family: verdana;color: #6C6C6C;',
      renderTo: Ext.getBody(),
      //defersInitialRefresh: false,
      store: searchespickerStore,
      displayField: 'name',
      listeners:{  
        itemclick:function(boundlist, record, item, index, evt ){
          var searchVal =  record.get('name');
          if (!Ext.isEmpty(searchVal)){
            field.setValue(searchVal);
            me.searchespicker.hide();
          }
        }
      }
     });
    me.searchespickerStore = searchespickerStore;
    me.searchespicker = searchespicker;
  },
  
  
  
  
  setSearchType:function(propName){
    var field = this;
    if (field.searchproperty){
      field.removeCls('xty_propsearch-'+field.searchproperty+'-prop');
    }
    field.addCls('xty_propsearch-'+propName+'-prop');
    field.searchproperty = propName;
  },

  /**
   * For using propsearch from outside
   */
  setValueAndProp:function(value, prop){
    var me = this;
    me.setValue(value);
    me.setSearchType(prop);
  },
  /**
   * For telling  <i>search-is-finished</i> from outside, so propsearch can remove it's loading css
   */
  searchResultRendered:function(){
    var me = this;
    me.removeCls('xty_propsearch-searching');
  },
  
  
  /**
   * Validates and triggers configured searchHandler
   */
  search:function(field, evt){
    var me = this;
    var valid = me.validate();
    if (valid){
      me.addCls('xty_propsearch-searching'); /* to be used as loading-indicator */
      
      var searchVal = field.getValue();
      var fieldIsEmpty = Ext.isEmpty(searchVal);
      if (!fieldIsEmpty){
        if (!me.lastSearches){me.lastSearches=[];}  
        if (!me.lastSearchesValues){me.lastSearchesValues=[];}
        if (!Ext.Array.contains(me.lastSearchesValues, searchVal)){
          me.lastSearches.push( {name:searchVal});
          me.lastSearchesValues.push(searchVal);
        } 
      }

      if(field.resultPanel){
        field.resultPanel.close();
      }
      
      // DelayedTask is needed that searching-css has immediately effect 
      var searchResultTask = new Ext.util.DelayedTask(function(){
        me.searchResultHandler(field, evt);
      });
      searchResultTask.delay(10);
      field.hideAllPickersBut('');
    }
    else{
     // extVia.showNotification({title:'search', html: me.emptyPropsText });
     // extVia.notify({action:'search', items: 'äasjkvöä'+me.emptyPropsText });
     //extVia.notify(me.emptyPropsText );
     if (field.propspicker){field.propspicker.show();}
     else{
       me.createPropspicker(me);
       me.propspicker.alignTo(me.inputEl, 'tl-bl?', [ 24, 4 ]);
       me.propspicker.show(me.inputEl);
     }
    }
  },
  
  trigger1Cls:'xty_form-trigger-searchable-left-1' , 
  trigger2Cls:'xty_propsearch-props-trigger' , 
  trigger3Cls:'xty_inside-trigger-clear' , 
  trigger4Cls:'xty_inside-trigger-extend' , 
  
  

  
  // search
  onTrigger1Click:function(evt){
    var field = this;
    field.hideAllPickersBut('');
    this.search(field, evt);
  },

  // types
  onTrigger2Click:function(evt){
    var me = this;
    me.hideAllPickersBut('propspicker');
    var field = me;
    field.focus();
    if (me.propspicker && me.propspicker.isVisible() ){
      me.propspicker.hide();
    }
    else{
      me.createPropspicker(me);
      me.propspicker.alignTo(me.inputEl, 'tl-bl?', [ 24, 4 ]);
      me.propspicker.show(me.inputEl);
      //me.propspicker.show();
    }
  },
  
  createPropspicker: function(field) {
    var me = this;
    var SearchPropertyModel =  Ext.define('SearchProperty', {
      extend: 'Ext.data.Model',
      fields: [ 'dscr', 'epobType', 'value']
    });
    var propspicker =  Ext.create('Ext.view.BoundList',  {
      xtype: 'boundlist',
      cls:'xty_propsearch-propspicker-boundlist',
      itemId: 'propspicker-boundlist',
      width:140,
      style:' position: absolute; z-index: 999;',
      renderTo: Ext.getBody(),
      multiSelect: true,
      value: 'Product',
      defersInitialRefresh: false,
      store:   Ext.create('Ext.data.Store', { 
        //fields: [ 'dscr','epobType', 'labeledType','value'], 
        
        model: 'SearchProperty',
        
        data :  [ 
        {dscr:'Hierarchien', epobType:'Hierarchy', labeledType:'type:Hierarchy', value: extVia.module.epob.HIERARCHY},  
        {dscr:'Produkte', epobType:'Product', labeledType:'type:Product', value: extVia.module.epob.PRODUCT}, 
        {dscr:'Attribute', epobType:'Attribute',  labeledType:'type:Attribute', value: extVia.module.epob.PRODUCTATTRIBUTE},  
        
        {dscr:'Wörterbücher', epobType:'Dictionary', labeledType:'type:Dictionary', value: extVia.module.epob.PRAT_DICTIONARY},
        
       
        {dscr:'-'},  
        
        {dscr:'Elemente', epobType:'Elements', value:extVia.module.epob.ELEMENTS},  
        {dscr:'Bilder', epobType:'ImageRoot', value:extVia.module.epob.IMAGE},  
        
        {dscr:'Dokumente', epobType:'DocumentRoot',  value:extVia.module.epob.DOCUMENT},  
        {dscr:'Graphiken', epobType:'GraphicRoot', value:extVia.module.epob.GRAPHIC},  
        {dscr:'Audios', epobType:'AudioRoot', value:extVia.module.epob.AUDIO},  
        {dscr:'Videos', epobType:'VideoRoot', value:extVia.module.epob.VIDEO},  
        
        {dscr:'-'},  
        
        {dscr:'Sammlungen', epobType:'Collection',labeledType:'type:Collection', value: extVia.module.epob.COLLECTION}
       
        ]
      }),   
      itemTpl:'<div style="width:100%;padding-left:16px;height:18px;" title="{value}" class="xty_epob{epobType}">' + '&nbsp; {dscr}' + '<span style="color:#ccc;"> &nbsp;&nbsp;</span></div>',
      displayField: 'dscr',
      listeners:{  
        itemclick:function(boundlist, record, item, index, evt ){
          var epobType =  record.get('epobType');
          if (!Ext.isEmpty(epobType)){
            me.setSearchType(epobType);
            me.validate();
            me.propspicker.hide();
          } 
        }
        
      }
     });
    me.propspicker = propspicker;
  },
  
  
  

  // clear 
  onTrigger3Click: function(evt){
    var field = this;
    field.reset();
    
    
    if (evt.hasModifier()){
      field.removeCls('xty_propsearch-'+field.searchproperty+'-prop');
      field.searchproperty = '';
    }
    
    
    
    if(field.resultPanel){
      field.resultPanel.close();
    }

    
    if(field.searchespicker){
      field.searchespicker.alignTo(field.inputEl, 'tl-bl?', [ 60, 4 ]);
      field.searchespicker.show(field.inputEl);
    }
    
  },
  

  
  // extended Search
  onTrigger4Click:function(evt){
    var me = this;
    me.hideAllPickersBut('formpicker');
    var field = me;
    if (me.formpicker && me.formpicker.isVisible() ){
      me.formpicker.hide();
    }
    else{
      me.createFormpicker(me);
      me.formpicker.alignTo(me.inputEl, 'tr-br?', [ 40, 4 ]);
      me.formpicker.show(me.inputEl);
      //me.formpicker.show();
    }
  }, 

  createFormpicker: function(field) {
    var me = this;
    var formpicker;
    
    var searchBtnHandler = function (btn , evt ){
      formpicker.hide();
      me.searchResultHandler(field, evt);
    };

    var searchHandler = function (formfield , evt ){
      formpicker.hide();
      me.searchResultHandler(field, evt);
    };
    
    
    formpicker = Ext.create('Ext.form.Panel', {
      //title:'extended Search', 
      cls:'xty_propsearch-extended-picker',
      //closable:true, 
      renderTo: document.body, 
      width:  field.width - 20, //- 80,  // from 380 -> 324
      heisght:200,
      defaults:{
       // margin:'10 10 10 20', 
        //width:field.width-80,
        labelWidth: 70
      },
      
      //tbar :{  items:[{text:'111'},{text:'222'}]},
      items:[

        {  xtype:'tabpanel', height:200,  margin:'0 0 0 0',   cls:'xty_propsearch-extended-tabpanel', 

          tabBar : {
            height: 30
          },
         // activeTab: '2', // why does this crash?
          defaults:{
            xtype:'form', 
            defaults:{
              xtype:'textfield',
              margin:'10 10 10 20',
              fieldLabel:'Property',
              width:  field.width - 60 ,
              enableKeyEvents:true,
              listeners:{
                keydown:function(formfield, evt){
                  if (evt.getKey()===Ext.EventObject.ENTER){
                    //alert('formpicker formfield ENTER')
                    searchHandler(formfield, evt);
                  }
                }
              }
            },
            items:[{fieldLabel:'Name'},{fieldLabel:'Id'},{xtype:'datefield',fieldLabel:'Änderungsdatum'},{fieldLabel:'Grösse'},{fieldLabel:'Attributstyp'},{fieldLabel:'Kommentar'}]
          },
   
          items:[
            
            { title:'Allgemein', itemId: 'general', 
              items:[

                {xtype:'tbspacer', height:2},
                
                {
                  xtype:'fieldcontainer', fieldLabel:'Sprache', layout:'hbox',
                    items:[
                      {xtype: 'splitbutton', fieldLabel:'Sprache', iconCls:'xty_icon_DE',width:40, style:'padding-top:2px;'}
                    ]
                 },

                {
                  xtype: 'radiogroup',
                  fieldLabel: 'Elementsuche',
                  items: [
                      {boxLabel: 'Rootelemente', name: 'cbgrp-elements-rootsOrVariants', checked: true},
                      {boxLabel: 'Varianten', name: 'cbgrp-elements-rootsOrVariants'}
                  ]
               },

                {
                  xtype:'fieldcontainer', fieldLabel:'Änderungsdatum', layout:'hbox', hiddsen:true,
                    items:[
                    {xtype:'datefield', width:92},
                    {xtype:'displayfield', value:'&nbsp;&nbsp;bis&nbsp;&nbsp;'},
                    {xtype:'datefield',   width:92}
                    ]
                 }

                
                ]
            },
            
            
            { title:'Hierarchien', itemId: 'Hierarchy', hidden:true,
              items:[{fieldLabel:'Name'},{fieldLabel:'Id'},{xtype:'datefield',fieldLabel:'Änderungsdatum'}, {fieldLabel:'ParentName'},{fieldLabel:'Kommentar'}]
            },
            {title:'Produkte', titsle: '<span class="xty_epobProduct" data-qtip="Produkte">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>', itemId: 'Product', 
              items:[{fieldLabel:'Name'},{fieldLabel:'Id'},{fieldLabel:'OrderNr'}, {xtype:'datefield', fieldLabel:'Änderungsdatum'}, {fieldLabel:'ParentName'}]
            },
            
            {title:'Attribute',  titsle: '<span class="xty_epobAttribute"  data-qtip="Attribute" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>',itemId: 'Attribute',
              items:[{fieldLabel:'Name'},{xtype:'combo',fieldLabel:'Datentyp'}, {fieldLabel:'Oberflächentext'},{fieldLabel:'ResourceKey'},{fieldLabel:'Kommentar'}]
            },
            
            {title:'Sammlungen', itemId: 'Collection' , titlse: '<span class="xty_epobCollection"  data-qtip="Sammlungen" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>', hidden:true
            
            },
            {title:'Bilder',  titlse: '<span class="xty_epobImage"  data-qtip="Bilder" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>', itemId: 'Image',
              items:[{fieldLabel:'Name'},{fieldLabel:'Id'},{xtype:'datefield', fieldLabel:'Änderungsdatum'},{fieldLabel:'Grösse'},{fieldLabel:'Dateiname'}]
            }
            
            //,{title:' ✕  ', itemId: 'close', closable:true, disabled: true, items:[]}
            
         ]   
        },

        
        {xtype:'button', text:' ✕   ',  margin:'2 2 2 2', cls:'xty_propsearch-extended-picker-close-btn', width:24, height:24 ,overCls:'', pressedCls:'', 
          handler:function(btn){
            btn.ownerCt.hide();
          }
        },
        
//        
//        {xtype:'textfield', fieldLabel:'Property 1', margin:'18 10 10 20'},
//        {xtype:'textfield', fieldLabel:'Property 2'},
//        {xtype:'textfield', fieldLabel:'Property 3'},
//        {xtype:'textfield', fieldLabel:'Property 4'},
//        {xtype:'textfield', fieldLabel:'Property 5'},
        {xtype:'button', text:'Search', width:80,  margin:'0 10 10 260', handler:searchBtnHandler}
      ],
      
      //buttons:[{text:'Search'}],
      
      listeners:{
        render: function(panel) {         
          panel.body.on('mouseleave', function( evt, target, eOpts ) {
              me.formpicker.inCharge = false;  
          });
          panel.body.on('mouseenter', function( evt, target, eOpts ) {
              me.formpicker.inCharge = true;   
          });             
          panel.body.on('click', function( evt, target, eOpts ) {
            //var fieldsInCharge = me.formpicker.isFieldsInCharge();
            // manage Focus
            // if (!fieldsInCharge){
            //   me.focus();// providing blur, needed for hiding the picker on outside click
            // }
          });
        } 
      }
      });
     me.focus();
     me.formpicker = formpicker; 
  },
  

  
  constructor : function(config) {
    var me = this;
    
    me.searchResultHandler = config.searchResultHandler;
    me.mode='local';
    
    
    me.listeners = {
      
      blur:function( field, eOpts ){            
        //alert('propsearch blur ');
        if (this.formpicker &&  !this.formpicker.hidden && !this.formpicker.inCharge){
          //alert (this.colorpicker.inCharge);
          this.formpicker.hide();
        }

      }  
      
    };
    
    config.allowBlankProps = false;
    var allowBlankProps  = Ext.isDefined(config.allowBlankProps) ? config.allowBlankProps :  Ext.isDefined(me.allowBlankProps) ?  me.allowBlankProps : true;
    if (!allowBlankProps){
      me.validator = function(value){
        return me.validateProps(value); 
      };
    }
    var defaultProp  = Ext.isDefined(config.defaultProp) ? config.defaultProp : Ext.isDefined(me.defaultProp) ?  me.defaultProp : 'empty';
    if (defaultProp !== 'empty'){
      me.cls = 'xty_propsearch-'+defaultProp+'-prop';
      me.searchproperty = defaultProp;
    }
    
//    me.search = function(field, evt){
//      var me = this;
//      //alert('combo search '+me.getValue());
//      field.searchResultHandler(field, evt);
//    }
//    
    
    
    me.callParent(arguments);
  }


  
});
/*
 * 
 * $Revision: 1.1.2.16 $
   $Modtime: 23.01.19 16:32 $ 
   $Date: 2019/05/07 09:07:29 $
 * $Author: slederer $
 * $viaMEDICI Release: 4 $
 * 
 */ 