Ext.namespace('extVia.campaigns.projects.main');
/**
 * @class extVia.campaigns.projects.main
 */
extVia.campaigns.projects.main = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.projects.main",
    name : "extVia.campaigns.projects.main"
  });
};
/*
 * Ext.Loader.setConfig({ enabled : true, disableCaching : true });
 * 
 */

extVia.campaigns.projects.main.prototype = {

  getProjectGantt_ : function getProjectGantt_(startDate, endDate) {

    var newWidth = Ext.getCmp('panel_mC').getWidth() - 4;
    var newHeight = extVia.regApp.myRaster.getCenter().getHeight() - 15;
    // var newWidth = panelmC.getWidth();
    // var newHeight = panelmC.getHeight() - extVia.constants.raster.pgToolbarEditHeight + 45;

    Ext.require([ 'Gnt.panel.Gantt', 'Sch.plugin.TreeCellEditing', 'Gnt.column.PercentDone', 'Gnt.column.StartDate',
                 'Gnt.column.EndDate', 'Gnt.widget.AssignmentCellEditor', 'Gnt.column.ResourceAssignment',
                 'Gnt.model.Assignment' ]);

    Ext.define('MsProjectTask', {
      extend : 'Gnt.model.Task',
      inclusiveEndDate : true,
      fields : [ {
        name : 'Milestone',
        type : 'boolean',
        defaultValue : 'false'
      } ],

      isMilestone : function() {
        return this.get('Milestone');
      }
    });

    Ext.define('MSProjectImportPanel', {
      extend : 'Ext.form.Panel',
      width : 450,
      frame : true,
      title : 'Load data from MS Project',
      bodyPadding : '10 10 0',

      defaults : {
        anchor : '100%',
        allowBlank : false,
        msgTarget : 'side',
        labelWidth : 50
      },
      initComponent : function() {
        this.addEvents('dataavailable');

        Ext.apply(this, {
          items : [ {
            xtype : 'filefield',
            id : 'form-file',
            emptyText : 'Upload .mpp file',
            fieldLabel : 'File',
            name : 'mpp-file',
            buttonText : '',
            buttonConfig : {
              iconCls : 'upload-icon'
            }
          } ],
          buttons : [
                     {
                       text : 'Load',
                       handler : function() {
                         var panel = this.up('form');
                         var form = panel.getForm();
                         if (form.isValid()) {
                           form.submit({
                             url : 'projects/msp-load.php',
                             waitMsg : 'Loading data...',
                             failure : function(form, action) {
                               msg('Import failed!', 'Please make sure the input data is valid. Error message: '
                                                     + action.result.msg);
                             },
                             success : function(form, action) {
                               panel.fireEvent('dataavailable', panel, action.result.data);
                             }
                           });
                         }
                       }
                     }, {
                       text : 'Reset',
                       handler : function() {
                         this.up('form').getForm().reset();
                       }
                     } ]
        });

        this.callParent(arguments);
      }
    });

    var msg = function(title, msg) {
      Ext.Msg.show({
        title : title,
        msg : msg,
        minWidth : 200,
        modal : true,
        icon : Ext.Msg.INFO,
        buttons : Ext.Msg.OK
      });
    };

    var resourceStore = Ext.create("Gnt.data.ResourceStore", {
      autoLoad : true,
      proxy : {
        type : 'memory'
      }
    });

    var dependencyStore = Ext.create("Gnt.data.DependencyStore", {
      autoLoad : true,
      proxy : {
        type : 'memory'
      }
    });

    var assignmentStore = Ext.create("Gnt.data.AssignmentStore", {
      autoLoad : true,
      resourceStore : resourceStore,
      proxy : {
        type : 'memory'
      }
    });

    var taskStore = Ext.create("Gnt.data.TaskStore", {
      model : 'MsProjectTask',
      proxy : {
        type : 'memory'
      }
    });

    var assignmentEditor = Ext.create('Gnt.widget.AssignmentCellEditor', {
      assignmentStore : assignmentStore,
      resourceStore : resourceStore
    });

    var g = null;
    g = Ext.create('Gnt.panel.Gantt', {
      height : newHeight,
      width : newWidth,
      resourceStore : resourceStore,
      assignmentStore : assignmentStore,
      taskStore : taskStore,
      dependencyStore : dependencyStore,
      stripeRows : true,
      lockedGridConfig : {
        width : 450
      },

      leftLabelField : {
        dataIndex : 'Name',
        editor : {
          xtype : 'textfield'
        }
      },
      rightLabelField : {
        dataIndex : 'Id',
        renderer : function(value, record) {
          return 'Id: #' + value;
        }
      },
      highlightWeekends : true,
      showTodayLine : true,
      loadMask : true,
      startDate : new Date(2012, 4, 01),
      endDate : Sch.util.Date.add(new Date(2012, 4, 01), Sch.util.Date.WEEK, 20),
      viewPreset : 'weekAndMonth',

      // static column that will be removed when columns from mpp file are loaded
      columns : [ {
        xtype : 'treecolumn',
        header : 'Tasks',
        sortable : true,
        dataIndex : 'Name',
        width : 290,
        field : {
          allowBlank : false
        }
      }, {
        xtype : 'startdatecolumn',
        text : 'Start Date',
        width : 80,
        sortable : false,
        dateFormat : 'Y-m-d',
        dataIndex : 'StartDate',
        align : 'center'
      }, {
        xtype : 'enddatecolumn',
        text : 'End Date',
        width : 80,
        // dateFormat: 'd-m-Y',
        sortable : false,
        // dataIndex : 'EndDate',
        align : 'center'
      },
      // Ext.create('Gnt.column.StartDate'), Ext.create('Gnt.column.EndDate'), Ext.create('Gnt.column.PercentDone')
      ],

      tbar : [ new MSProjectImportPanel({
        listeners : {
          dataavailable : function(form, data) {
            msg('Success', 'Data from .mpp file loaded ');

            g.taskStore.setRootNode(data.tasks);
            g.resourceStore.loadData(data.resources);
            g.assignmentStore.loadData(data.assignments);
            g.dependencyStore.loadData(data.dependencies);

            var column, xtype;

            for ( var i = 0, l = data.columns.length; i < l; i++) {

              xtype = data.columns[i].xtype;
              delete data.columns[i].xtype;

              column = Ext.widget(xtype, data.columns[i]);

              g.lockedGrid.headerCt.add(column);
            }
            // g.lockedGrid.headerCt.remove(0);
            g.lockedGrid.getView().refresh();

            g.expandAll();

            var span = g.taskStore.getTotalTimeSpan();
            if (span.start && span.end) {
              g.setTimeSpan(span.start, span.end);
            }
          }
        }
      }), '->', {
        iconCls : 'icon-previous',
        scale : 'small',
        handler : function() {
          g.shiftPrevious();
        }
      }, {
        iconCls : 'icon-next',
        scale : 'small',
        handler : function() {
          g.shiftNext();
        }
      } ]
    });

    return g;

  },

  getProjectGantt : function getProjectGantt(startDate, endDate) {

    Ext.require([ 'Gnt.panel.Gantt', 'Sch.plugin.TreeCellEditing', 'Gnt.column.PercentDone', 'Gnt.column.StartDate',
                 'Gnt.column.EndDate', 'Gnt.widget.AssignmentCellEditor', 'Gnt.column.ResourceAssignment',
                 'Gnt.model.Assignment' ]);

    Ext.define('MsProjectTask', {
      extend : 'Gnt.model.Task',
      inclusiveEndDate : true,
      fields : [ {
        name : 'Milestone',
        type : 'boolean',
        defaultValue : 'false'
      } ],

      isMilestone : function() {
        return this.get('Milestone');
      }
    });

    Ext.QuickTips.init();

    var msg = function(title, msg) {
      Ext.Msg.show({
        title : title,
        msg : msg,
        minWidth : 200,
        modal : true,
        icon : Ext.Msg.INFO,
        buttons : Ext.Msg.OK
      });
    };

    Ext.define('MSProjectImportPanel', {
      extend : 'Ext.form.Panel',
      width : 300,
      frame : true,
      style : {
        'border-width' : '0px'
      },
      title : '',
      bodyPadding : '10 10 0',
      defaults : {
        anchor : '100%',
        allowBlank : false,
        msgTarget : 'side',
        labelWidth : 50
      },
      initComponent : function() {
        this.addEvents('dataavailable');

        Ext.apply(this, {
          items : [ {
            xtype : 'filefield',
            id : 'form-file',
            emptyText : 'Upload .mpp file',
            fieldLabel : 'File',
            name : 'mpp-file',
            buttonText : '',
            buttonConfig : {
              iconCls : 'upload-icon'
            }
          } ],
          buttons : [
                     {
                       text : 'Load',
                       handler : function() {
                         var panel = this.up('form');
                         var form = panel.getForm();
                         if (form.isValid()) {
                           form.submit({
                             url : 'projects/msp-load.php',
                             waitMsg : 'Loading data...',
                             failure : function(form, action) {
                               msg('Import failed!', 'Please make sure the input data is valid. Error message: '
                                                     + action.result.msg);
                             },
                             success : function(form, action) {
                               panel.fireEvent('dataavailable', panel, action.result.data);
                             }
                           });

                         }
                       }
                     }, {
                       text : 'Reset',
                       handler : function() {
                         this.up('form').getForm().reset();
                       }
                     } ]
        });

        this.callParent(arguments);
      }
    });

    // var data = extVia.campaigns.projects.store.getGanttDummyData();

    var dependencyStore = Ext.create("Gnt.data.DependencyStore", {
      autoLoad : true,
      // data: data.dependencies
      proxy : {
        type : 'memory'
      }
    });

    var resourceStore = Ext.create("Gnt.data.ResourceStore", {
      autoLoad : true,
      proxy : {
        type : 'memory'
      }
    });

    var assignmentStore = Ext.create("Gnt.data.AssignmentStore", {
      autoLoad : true,
      resourceStore : resourceStore,
      proxy : {
        type : 'memory'
      }
    });

    var taskStore = Ext.create("Gnt.data.TaskStore", {
      model : 'MsProjectTask',
      proxy : {
        type : 'memory'
      }
    });

    var assignmentEditor = Ext.create('Gnt.widget.AssignmentCellEditor', {
      assignmentStore : assignmentStore,
      resourceStore : resourceStore
    });

    var colSlider = Ext.create("Ext.slider.Single", {
      width : 120,
      value : 20,
      minValue : 20,
      maxValue : 140,
      increment : 10
    });

    var cellEditing = Ext.create('Sch.plugin.TreeCellEditing', {
      clicksToEdit : 1,
      listeners : {
        beforeedit : function() {
          // return !Ext.getCmp('demo-readonlybutton').pressed;
        }
      }
    });

    // var taskStore2 = extVia.campaigns.projects.store.getTasksStore();
    // var taskStore3 = extVia.campaigns.projects.store.getEmptyTaskStore();
    // var dependencyStore2 = extVia.campaigns.projects.store.getDependencyStore();

    var newWidth = Ext.getCmp('panel_mC').getWidth();
    var newHeight = extVia.regApp.myRaster.getCenter().getHeight();
    // var panelmC = Ext.getCmp('panel_mC');
    // var newWidth = panelmC.getWidth();
    // var newHeight = panelmC.getHeight() - extVia.constants.raster.pgToolbarEditHeight + 45;

    // var startDate = extVia.campaigns.scheduler.control.generateStartDate(); // zero-based month number!!
    // var endDate = extVia.campaigns.scheduler.control.generateEndDate(6);

    var gantt = null;
    gantt = Ext.create('Gnt.panel.Gantt', {

      height : newHeight - 135,
      width : newWidth - 4,
      border : false,

      leftLabelField : 'Name',
      highlightWeekends : false,
      loadMask : true,
      enableProgressBarResize : true,
      enableDependencyDragDrop : true,
      cascadeChanges : false,

      showTodayLine : true,
      startDate : startDate,
      endDate : Sch.util.Date.add(startDate, Sch.util.Date.WEEK, 20),
      viewPreset : 'weekAndMonth', // 'yearMonthWeek', //

      eventRenderer : function(taskRecord) {
        return {
          ctcls : taskRecord.get('Id')
        // Add a CSS class to the task element
        };
      },

      viewConfig : {
        rowHeight : 40
      },

      tooltipTpl : new Ext.XTemplate('<ul class="taskTip">', '<li><strong>Task:</strong>{Name}</li>',
          '<li><strong>Start:</strong>{[Ext.Date.format(values.StartDate, "y-m-d")]}</li>',
          '<li><strong>Duration:</strong> {Duration}d</li>', '<li><strong>Progress:</strong>{PercentDone}%</li>',
          '</ul>').compile(),

      // Setup your static columns
      columns : [ {
        xtype : 'treecolumn',
        header : 'Tasks',
        sortable : true,
        dataIndex : 'Name',
        width : 310,
        field : {
          allowBlank : false
        }
      }, {
        xtype : 'startdatecolumn',
        text : 'Start Date',
        width : 70,
        sortable : false,
        dateFormat : 'Y-m-d',
        dataIndex : 'StartDate',
        align : 'center'
      }, {
        xtype : 'enddatecolumn',
        text : 'End Date',
        width : 70,
        dateFormat : 'd-m-Y',
        sortable : false,
        // dataIndex : 'EndDate',
        align : 'center'
      },
      // Ext.create('Gnt.column.StartDate'), Ext.create('Gnt.column.EndDate'), Ext.create('Gnt.column.PercentDone')
      ],

      taskStore : taskStore,
      dependencyStore : dependencyStore,
      resourceStore : resourceStore,
      assignmentStore : assignmentStore,

      plugins : [ cellEditing ],

      lockedViewConfig : {
        plugins : {
          ptype : 'treeviewdragdrop'
        },
        collapsible : true
      },

      tbar : [

      // {
      // text : 'Add new task...',
      // iconCls : 'icon-add',
      // handler : function() {
      // var newTask = new taskStore.model({
      // Name : 'New task',
      // leaf : true,
      // PercentDone : 0
      // });
      // taskStore.getRootNode().appendChild(newTask);
      // }
      // }, {
      // enableToggle : true,
      // id : 'demo-readonlybutton',
      // text : 'Read only mode',
      // pressed : false,
      // handler : function() {
      // gantt.setReadOnly(this.pressed);
      // }
      // },
      //
      // {
      // text : 'Load MS Project',
      // width : 100,
      // handler : function() {
      // // if (!Ext.getCmp('msWindowId')) {
      // var msWindow = Ext.create('Ext.window.Window', {
      // title : 'Load data from MS Project',
      // id : 'msWindowId',
      // width : 320,
      // height : 130,
      // items : [ new MSProjectImportPanel({
      // listeners : {
      // dataavailable : function(form, data) {
      // msg('Success', 'Data from .mpp file loaded ');
      //
      // gantt.taskStore.setRootNode(data.tasks);
      // gantt.resourceStore.loadData(data.resources);
      // gantt.assignmentStore.loadData(data.assignments);
      // gantt.dependencyStore.loadData(data.dependencies);
      //
      // var column, xtype;
      //
      // for ( var i = 0, l = data.columns.length; i < l; i++) {
      //
      // xtype = data.columns[i].xtype;
      // delete data.columns[i].xtype;
      //
      // column = Ext.widget(xtype, data.columns[i]);
      //
      // gantt.lockedGrid.headerCt.add(column);
      // }
      // gantt.lockedGrid.headerCt.remove(0);
      // gantt.lockedGrid.getView().refresh();
      //
      // gantt.expandAll();
      //
      // var span = gantt.taskStore.getTotalTimeSpan();
      // if (span.start && span.end) {
      // gantt.setTimeSpan(span.start, span.end);
      // }
      //
      // this.ownerCt.close();
      // }
      // }
      // }) ]
      //
      // });
      // msWindow.show();
      // // }
      // }
      // },

      // {
      // xtype : 'label',
      // text : 'Column Width'
      // }, ' ', colSlider,

      // {
      // xtype: 'button',
      // text : 'Load Dummy MS Project',
      // iconCls : 'load',
      // width : 150,
      // height: 25,
      // margin: '0 20 0 0',
      // handler : function() {
      // if(gantt.taskStore.nodeStore){
      // gantt.taskStore.nodeStore.removeAll();
      // }
      // gantt.taskStore.setRootNode(data.tasks);
      // gantt.resourceStore.loadData(data.resources);
      // gantt.assignmentStore.loadData(data.assignments);
      // gantt.dependencyStore.loadData(data.dependencies);
      //          
      // gantt.expandAll();
      //
      // var span = gantt.taskStore.getTotalTimeSpan();
      // if (span.start && span.end) {
      // gantt.setTimeSpan(span.start, span.end);
      // }
      // }
      // },

      {
        id : 'invisibleTab4Gantt',
        disabled : true,
        width : 0
      }, {
        xtype : 'button',
        height : 25,
        itemId : 'previousBtnId',
        iconCls : 'icon-previous',
        scale : 'small',
        tooltip : 'Previous month',
        margin : '0 0 0 20',
        handler : function() {
          gantt.shiftPrevious();
        }
      },

      '->',

      {
        xtype : 'button',
        height : 25,
        iconCls : 'icon-next',
        margin : '0 0 0 0',
        scale : 'small',
        tooltip : 'Next month',
        handler : function() {
          gantt.shiftNext();
        }
      } ],

      listeners : {

        render : function(view) {
          var header = view.getSchedulingView().headerCt;

          view.tip = Ext.create('Ext.tip.ToolTip', {
            target : header.id,
            delegate : '.sch-simple-timeheader',
            showDelay : 300,
            trackMouse : true,
            anchor : 'bottom',
            dateFormat : 'Y-m-d',
            // dateFormat: 'Y-m-d, g:i a',
            listeners : {
              // Change content dynamically depending on which element triggered the show.
              beforeshow : function(tip) {
                var el = Ext.get(tip.triggerElement), position = el.getXY(), date = view.getSchedulingView()
                    .getDateFromXY(position);

                tip.update('Date: ' + Ext.Date.format(date, tip.dateFormat));
              }
            }
          });
        }
      }
    });

    var dockItem = gantt.dockedItems.getAt(0);
    if (dockItem.xtype = 'toolbar') {
      var toolbarItems = dockItem.items;
      var sumWidth = 0;
      for ( var i = 0; i < toolbarItems.length; i++) {
        if (toolbarItems.items[i].itemId !== 'previousBtnId') {
          sumWidth += toolbarItems.items[i].width;
        } else
          break;
      }
      sumWidth = gantt.lockedGrid.width - sumWidth - 20;
      Ext.getCmp('invisibleTab').setWidth(sumWidth);
      Ext.getCmp('invisibleTab4Gantt').setWidth(sumWidth);
      // dockItem.getComponent('invisibleTab4Gantt').setWidth(sumWidth);
    }

    return gantt;
  },

  addListenerToResizerGantt : function addListenerToResizerGantt(schedulerTabPanel, gantt) {

    var resizer = gantt.items.items[1];
    resizer.addListener("dragend", function() {
      var width = gantt.items.items[0].getWidth() - 175;
      schedulerTabPanel.getTabBar().items.get(2).setWidth(width);
      var width4Tbar = gantt.items.items[0].getWidth() - 25;
      Ext.getCmp('invisibleTab4Gantt').setWidth(width4Tbar);
    });

  }

};

// init Object as singleton
extVia.campaigns.projects.main = new extVia.campaigns.projects.main();

/*
 * 
 * $Revision: 1.12 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/06 17:06:46 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */