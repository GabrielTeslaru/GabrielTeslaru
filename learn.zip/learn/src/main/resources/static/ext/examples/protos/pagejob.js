Ext.namespace('extVia.ui.page');
/**
 * @class extVia.ui.page.pagejob
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2019/02/05 17:23:18 $
 *            $Revision: 1.36.6.5 $
 */

extVia.ui.page.pagejob = function(config){
  Ext.apply(this,config,{    
    id          : "extVia.ui.page.pagejob",
    name        : "extVia.ui.page.pagejob"
  });
};
    
extVia.ui.page.pagejob.prototype = {

                                    
                                    
                                
getFinderBtnGrpCfg : function (cfg){  

  // dummyHandler
  var triggerClickHandler = function (evt) {
    extVia.notify('finderBtnGrp  trigger Click <br><br>'+ evt.target.className.replace(/.*xty_/,'xty_'));
  };
  
  var searchHandler = function (evt, searchfieldId) {
    extVia.notify('finderBtnGrp  searchHandler Call <br>');
    
    var searchtrigger =  searchfieldId ? Ext.get(searchfieldId) : Ext.get(evt.target.id);

    var btnGrp = Ext.getCmp(searchtrigger.up('.x-btn-group').id);
//    var searchfield =  Ext.getCmp(searchtrigger.dom.parentNode.parentNode.parentNode.id);
//    var btnGrp = searchfield.ownerCt.id;
    
    var searchMatches = btnGrp.getComponent('searchMatches');
    searchMatches.setValue('1/11');
    searchMatches.setDisabled(false);

    var searchMatchesSpinner = btnGrp.getComponent('searchMatchesSpinner');
    searchMatchesSpinner.setDisabled(false);
    
    
  };

  
  var hideFilterBtn = cfg.hideFilterBtn ? cfg.hideFilterBtn : false;
  
  
  var finderBtnGrpCfg = {
     xtype: 'buttongroup',
     itemId:'finderBtnGrp',
     cls:'xty_searchfilter-btngrp',
     columns: 4,
     defaults: {
         scale: 'small',
         margin:'2 0 2 0'
     },
     items:[  
         
      // Matches 
      {
        xtype:'displayfield', 
        itemId:'searchMatches',
        margin:'2 4 2 4',
        tip:'Treffer',  
        disabled:true,
        value:'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
      },
   
     // Matchesspinner
      {  
      xtype:'spinnerfield', 
      itemId:'searchMatchesSpinner',
      disabled:true,
      width:16, 
      editable : false , 
      tooltip:'Skip',
      cls:'xty_spinner-plain xty_spinner-left'
      }, 
      
      
      // Searchfield
      {
        xtype:'triggerfield', 
        itemId:'searchfield',
        cls : 'xty_inside-trigger',
        margin: hideFilterBtn ? '2 2 2 0' :  '2 0 2 0',
        
        trigger1Cls : 'xty_search-inside-trigger', 
        onTriggerClick: searchHandler,
        tooltip:'Suchen',
        listeners:{
          afterrender:function(triggerfield){
            this.mapEnter = new Ext.util.KeyMap(this.getEl(),{
              key: Ext.EventObject.ENTER,
                //aslt: true,
                scope: this,
                fn: function(evt){searchHandler(evt, this.id);}
            });
  
           var tip = Ext.create('Ext.tip.ToolTip', {
           target: triggerfield.id,
           html: triggerfield.tooltip
          });
          }
        } 
       },
       
       // Filter
       {  
        xtype:'triggerfield' ,
        itemId:'filterTrigger',
        margin:'2 2 2 0',
        hidden: hideFilterBtn,
        triggerCls : 'xty_form-trigger-filter',
        onTriggerClick: triggerClickHandler,
        width:16, 
        editable : false , 
        cls:'xty_trigger-plain', 
        
        tooltip:'Filtern',
        listeners:{
         afterrender:function(button){
          var tip = Ext.create('Ext.tip.ToolTip', {
          target: button.id,
          html: button.tooltip
         });
         }
       } 
      }
     ] 
 };



 return finderBtnGrpCfg;
},
                                    
                                    
  
getBreadcrumbHTML : function (cfg){
  var breadcrumbHTML ='';    
  if (cfg && cfg.breadcrumb){

    var separator = '/'; // default is /

    if (cfg && cfg.breadcrumbSeparator ){
      separator = cfg.breadcrumbSeparator;
    }

    var breadcrumbItems = cfg.breadcrumb.split(separator);
  
    var i;
    for ( i =0; i<breadcrumbItems.length; i++){
     var crumb = breadcrumbItems[i];
     var lastcrumb = i === breadcrumbItems.length-1;
      if(!Ext.isEmpty(crumb)){
        breadcrumbHTML+= '<span class="xty_crumb xty_linked-crumb'+(lastcrumb?' xty_last-crumb':'')+' " title="'+crumb+'">'+crumb+'</span>' ;
        if (!lastcrumb ){
         breadcrumbHTML+=  '<span class="xty_breadcrumb-separator"> &raquo; </span>' ;
        }
      }
    }  
  }    

   return breadcrumbHTML;
   
  },
  
  
  
		
  /**
   * @param config 
   * config.pgjobDscr The title of the page or tab, for Example Productpflege
   * config.epobDscr The title of the worked on EPIM-Objekt
   * config.pgjobButtons  
   * config.inAppbarWidth  if the pagejobbar is inside an appbar it needs a width
   * config.pgjobbarHeight the height
   * @returns
   */
  getPagejobBar : function getPagejobBar(config){
	  		var pgjobDscr = config.pgjobDscr; 
	  		var epobDscr = config.epobDscr; 
	  		var subEpobDscr = config.subEpobDscr; 
        
            var subEpobDscrSeparator = config.subEpobDscrSeparator?config.subEpobDscrSeparator:'&raquo;'; 
	  		var pgjobButtons = config.pgjobButtons; 
	  		var inAppbarWidth = config.inAppbarWidth; 
	  		var pgjobbarHeight = config.pgjobbarHeight; 
		
		
		if (epobDscr ){	
			pgjobDscr+='<span  class="xty_pgjobDscr">:</span>';
		}
		

		var pgjobItems =[];     

		pgjobItems.push({
				xtype: 'tbtext',
				itemId:'pgjobDscrItem',
				cls:'xty_pgjobitem-dscr',
				text:'<span  class="xty_pgjobDscr">&nbsp;'+pgjobDscr+'</span>',	
				textTmplPre :'<span  class="xty_pgjobDscr">&nbsp;',	
				textTmplPost:'</span>'
				
				});
		pgjobItems.push({
				xtype: 'tbtext',
				itemId:'colon',
				cls:'xty_pgjobitem-colon',
				hidden: true ,
				text:'<span  class="xty_pgjobDscr">:</span>'
				});
		pgjobItems.push({
				xtype: 'tbtext',
				itemId:'epobdscr',
				cls:'xty_pgjobitem-epobDscr',
				hidden:  !epobDscr ,
				text:'<span  class="xty_pgjobEpobDscr">'+epobDscr+'</span>'
				});
	    
		pgjobItems.push({
			xtype: 'tbtext',
			itemId:'raquo1',
			cls:'xty_pgjobitem-raquo1',
			hidden: !subEpobDscr ,
			text:'<span  class="xty_pgjobEpobDscr">'+subEpobDscrSeparator+'</span>'
			});
		pgjobItems.push({
			xtype: 'tbtext',
			itemId:'subEpobDscr',
			cls:'xty_pgjobitem-subEpobDscr',
			hidden:  !subEpobDscr ,
			text:'<span  class="xty_pgjobEpobDscr">'+subEpobDscr+'</span>'
			});
	    

		if (!config.pgjobtnAlignLeft){
		  pgjobItems.push(  '->');
		}
		else{
		  pgjobItems.push( {xtype:'tbspacer', width:10});
		}


		if (pgjobButtons){
              var i;
	    	  for (i = 0; i<pgjobButtons.length; i++){
	    		  if (!pgjobButtons[i].iconCls && pgjobButtons[i].itemId ){
	    			  pgjobButtons[i].iconCls =   'xty_pgtoolbar-'+pgjobButtons[i].itemId;
	    		  }		  
	    	  }
			pgjobItems.push(pgjobButtons);
			//pgjobItems.push({  xtype : 'tbspacer',width:20});
		}


		var hasDropZone = config && config.hasDropZone ?  config.hasDropZone : false;
		if (hasDropZone){
			pgjobItems.push(
					{xtype: 'button', cls:'xty_pgjobitem-dropzone', itemId:'dropzoneButton',tooltip:'show / hide dropzone',
						width:10,
						handler:function(button){
							button.showDropzone(button);
						},
						
						showDropzone:function(button){
							if (button.dropzone){
								
								if (button.dropzone.isVisible()){
									button.dropzone.hide();
								}
								else {button.dropzone.show();}
							}
							else{
								var dropzone = 
									
							   		Ext.create('widget.window', {
										preventHeader:true,
										x:button.getPosition()[0]-210,
										y:button.getPosition()[1]-35,
										width:40,
										style:'border:4px solid #99BCE8;opacity:0.9;',
										cls: 'ux-notification-light xty_dropzone-bin',
										overCls:'xty_dropzone-bin-over',
										html:  'Drop your items here',
										autoCloseDelay: 2000,
										
										slideBackDuration: 500,
										slideInAnimation: 'easeIn',
										slideBackAnimation: 'easeIn'
									});
									
									dropzone.show();
									
									button.dropzone = dropzone;
								
									dropzone.getEl().on('click', function(){
										button.dropzone.hide();
								   		Ext.create('widget.uxNotification', {
											title: 'Erfolgreich ',
											position: 'tr',
											height:40,width:60,
											manager: 'instructions',
											style:'border:1px solid #00AA00;',
											cls: 'ux-notification-light xty_dropZone-bin',
											html:  'items successfully applied',
											autoCloseDelay: 500,
											slideBackDuration: 500,
											slideInAnimation: 'linear',
											slideBackAnimation: 'easeIn'
										}).show();
									});
							}	
						}// eo showDropzone
					}// eo dropzoneButton
				);
		}
		
		
       
     
    
        var hasBreadcrumb = !Ext.isEmpty(config.breadcrumb);

		var bar = Ext.create('Ext.toolbar.Toolbar', {
			
		    cls:'xty_pagejobbar xty_pgjobBin'  + (hasBreadcrumb ?' xty_pgjob-has-1line-breadcrumb':''),
			itemId:'pagejobbar',
			border : false,
			bodyBorder : false,
			height : extVia.constants.raster.pgjobEditHeight,  	
			width:inAppbarWidth,
			defaults:{scale:'medium'},
			showDropzone:function(toolbar){if (!toolbar){toolbar = this;}var butt = toolbar.getComponent("dropzoneButton"); butt.showDropzone(butt);},
			items:pgjobItems,
			plainPagejobDscr:pgjobDscr,
			plainEpobDscr:epobDscr,
			plainSubEpobDscr:subEpobDscr,
			setPagejobDscr : function setPagejobDscr(pgjobDscr){
				//this.plainEpobDscr = pgjobDscr;
				var pgjobDscrHTML = '<span  class="xty_pgjobDscr">&nbsp;'+pgjobDscr+'</span>';
				if (this.plainEpobDscr){	
					pgjobDscrHTML+='<span  class="xty_pgjobDscr">:</span>';
				}
				this.getComponent("pgjobDscrItem").setText(pgjobDscrHTML );
			},
			setEpobDscr : function setPagejobDscr(epobDscr){
				this.plainEpobDscr= epobDscr;
				var epobdscr = this.getComponent("epobdscr");
				if (!epobdscr.isVisible()){
				  epobdscr.show();
				  this.setPagejobDscr(this.plainPagejobDscr);
				}
				epobdscr.setText( '<span  class="xty_pgjobEpobDscr">'+epobDscr+'</span>');
			},
	    	setSubEpobDscr : function setSubEpobDscr(subEpobDscr){
	    		this.subEpobDscr= subEpobDscr;
	    		var subEpobText = this.getComponent("subEpobDscr");
	    		var subEpobRaquo = this.getComponent("raquo1");
	    		subEpobText.show();
	    		subEpobRaquo.show();
	    		subEpobText.setText( '<span  class="xty_pgjobEpobDscr">'+this.subEpobDscr+'</span>');
	    	},
	    	hideSubEpobDscr : function hideSubEpobDscr(subEpobDscr){
	    		var subEpobText = this.getComponent("subEpobDscr");
	    		var subEpobRaquo = this.getComponent("raquo1");
	    		subEpobText.hide();
	    		subEpobRaquo.hide();
	    	},
			getPagejobDscr : function getPagejobDscr(){
				return this.plainPagejobDscr; 
			},
			getEpobDscr : function getEpobDscr(){
				return this.plainEpobDscr; 
			},
			getSubEpobDscr : function getSubEpobDscr(){
				return this.plainSubEpobDscr; 
			},
      
			listeners: hasBreadcrumb?{
			  afterrender:function(tbar){
               if (tbar.breadcrumb){
                 Ext.get(tbar.breadcrumb.id).show();
               }
			  }
		    }:null
		});

		if (pgjobbarHeight){	
			bar.setHeight(pgjobbarHeight);
		}
		
	  if (epobDscr){	
		  bar.hasEpobDscr =true;
	  }
		
    
      if (hasBreadcrumb)  {       
       var breadcrumbHtml = this.getBreadcrumbHTML(config);
       bar.breadcrumb = bar.add({itemId:'breadcrumb',  cls:'xty_pgjobitem-breadcrumb', xtype:'tbtext', hidden:true, stsyle:'position:absolute; margin-left:10px !important; top:40px; display:block;', html:breadcrumbHtml}) ;
      }
      

	  return bar;
  },
		
  /**
   * @deprecated
   * @param pgjobDscr
   * @param pgjobEpobDscr
   */
  setPagejobText : function setPagejobText(pgjobDscr, pgjobEpobDscr ) {
	  if (!extVia.ui.page.BaseRaster.centerTabPanel) {
		  extVia.ui.page.BaseRaster.centerTabPanel = Ext.getCmp("panel_mcTabs");    
	  }
	  if (extVia.ui.page.BaseRaster.centerTabPanel) {
		  var pagejobbar = extVia.ui.page.BaseRaster.centerTabPanel.getActiveTab().getComponent("pagejobbar");  
		  var pagejobDscrItem = pagejobbar.getComponent("pgjobDscrItem");  
		  if (pagejobbar.hasEpobDscr){	
			  pgjobDscr+='<span  class="xty_pgjobDscr">:</span>';
		  }
		  pagejobDscrItem.setText( pagejobDscrItem. textTmplPre+ pgjobDscr + pagejobDscrItem. textTmplPost);	
	  }  
  },
  
  setPagejobDscr : function setPagejobDscr(pgjobDscr){
  },
  
  setEpobDscr : function setPagejobDscr(epobDscr){	  
  },
  
  /**
   * Delivers a pagejobbar or a  Applicationbar, which is a pagejobbar + pagetoolbar inside a toolbar
   * @param barCfg
   * @returns
   */
  getApplicationBar : function getApplicationBar(barCfg){

      var panelmC = Ext.getCmp('panel_mC');
      var centerWidth;
      if (panelmC){ 
    	  centerWidth = panelmC.getWidth();
      }
      
      
      barCfg.inAppbarWidth = centerWidth; 
      
      if (Ext.isEmpty(barCfg.pgjobbarHeight)){
        barCfg.pgjobbarHeight =   extVia.constants.raster.pgjobEditHeight;      
      }
      
      var pagejobbar = extVia.ui.page.pagejob.getPagejobBar( barCfg );
      var applicationbar;
      
      // extVia.notify('pagetoolbarButtons1 '+barCfg.pagetoolbarButtons);

      var pagetoolbarButtons = barCfg.pagetoolbarButtons;
      
      
      var pagetoolbarButtonCmps = [];
      
      if (pagetoolbarButtons){
          Ext.QuickTips.init();
          var i;
    	  for ( i = 0; i<pagetoolbarButtons.length; i++){
    		  if (!pagetoolbarButtons[i].iconCls && pagetoolbarButtons[i].itemId ){
    			  pagetoolbarButtons[i].iconCls =   'xty_pgtoolbar-'+pagetoolbarButtons[i].itemId;
            
    		  }		  
    	  }


          var appbarHeight = extVia.constants.raster.pgjobEditHeight ;
          var appbarItems =  [ pagejobbar ];
          pagetoolbarButtons.unshift({   xtype : 'tbspacer',width:10});
          
          var pagetoolbar = Ext.create('Ext.toolbar.Toolbar', {
            frame : false,
            cls:'xty_pagetoolbar xty_actionbar',
            itemId:'pagetoolbar',
            height : extVia.constants.raster.pgToolbarEditHeight,
            border : false,
            width : centerWidth,
            defaults:{scale: extVia.constants.raster.pagetoolbarCenterBtnScale},
            items : pagetoolbarButtons
          });
          
          appbarItems.push(pagetoolbar );
          appbarHeight = extVia.constants.raster.pgjobEditHeight  + extVia.constants.raster.pgToolbarEditHeight ;
          
          applicationbar = Ext.create('Ext.toolbar.Toolbar', {
	    	setPagejobDscr : function setPagejobDscr(pgjobDscr){
	    		pagejobbar.setPagejobDscr(pgjobDscr);
	    	},
	    	setEpobDscr : function setEpobDscr(epobDscr){
	    		pagejobbar.setEpobDscr(epobDscr);
	    	},
	    	setSubEpobDscr : function setSubEpobDscr(subEpobDscr){
	    		pagejobbar.setSubEpobDscr(subEpobDscr);
	    	},
	    	hideSubEpobDscr : function hideSubEpobDscr(subEpobDscr){
	    		pagejobbar.hideSubEpobDscr(subEpobDscr);
	    	},
	    	getPagejobbar : function getPagejobbar(){
	    		return pagejobbar;
	    	},
			getPagetoolbar : function getPagetoolbar(){
	    		return pagetoolbar;
	    	},
			getActionbar : function getActionbar(){
	    		return pagetoolbar;
	    	},
	    	getPagejobDscr : function getPagejobDscr(){
	    		return pagejobbar.getPagejobDscr();
	    	},
	    	getEpobDscr : function getEpobDscr(){
	    		return pagejobbar.getEpobDscr();
	    	},
            border : false,
            cls:'xty_applicationbar',
            itemId:'applicationbar',
            height : appbarHeight,
            layout : 'vbox',
            pagejobbar : pagejobbar,
            pagetoolbar : pagetoolbar,  
            
            toggle:function(cfg){

              if (cfg.pgtoolbar || this.collapsed){
                if (this.collapsed){
                  this.expand();
                }
                else{
                  this.collapse();
                }
              }
              

              if (cfg.pgjob || this.collapsedPagejob ){
                if (this.collapsedPagejob){
                  this.expandPagejob();
                }
                else{
                  this.collapsePagejob();
                }
              }
          		
          		
          		
          		
            },
             
 
            
            collapse:function(){         
              var toggleDiff =  extVia.constants.raster.pgToolbarEditHeight;
            	if (!this.collapsed){
            		this.setHeight(this.getHeight()- toggleDiff );
            		this.collapsed=true;
            		this.ownerCt.addCls('xty_applibar-collapsed');
            		this.ownerCt.addCls('xty_applibar-pagetoolbar-collapsed');
            		
            		this.addToSubPanelsHeight(toggleDiff);
            	}
            },
            expand:function(){
              var toggleDiff =  extVia.constants.raster.pgToolbarEditHeight;
            	if (this.collapsed){
            		this.setHeight(this.getHeight()+toggleDiff);
            		this.collapsed=false;
            		this.doLayout();
            		this.ownerCt.removeCls('xty_applibar-collapsed');
            		this.ownerCt.removeCls('xty_applibar-pagetoolbar-collapsed');
            		this.addToSubPanelsHeight(-toggleDiff);
            	}
            }, 
  
            
            collapsePagejob:function(){              
              if (!this.collapsedPagejob){
                var toggleDiff = extVia.constants.raster.pgjobEditHeight;
                this.setHeight(this.getHeight()-toggleDiff);
                this.getPagejobbar().hide();
                this.collapsedPagejob=true;
                //this.ownerCt.addCls('xty_applibar-collapsed');
                
                this.ownerCt.addCls('xty_applibar-pagejob-collapsed');
                
                this.addToSubPanelsHeight(toggleDiff);
              }
            },
            expandPagejob:function(){
              var toggleDiff = extVia.constants.raster.pgjobEditHeight;
              if (this.collapsedPagejob){
                this.setHeight(this.getHeight()+toggleDiff);
                this.getPagejobbar().show();
                this.collapsedPagejob=false;
                this.doLayout();
                //this.ownerCt.removeCls('xty_applibar-collapsed');
                
                this.ownerCt.removeCls('xty_applibar-pagejob-collapsed');
                
                this.addToSubPanelsHeight(-toggleDiff);
              }
            }, 
            
            
            addToSubPanelsHeight:function(addHeight){
        		// if applibar is used in an Editor
        		try{
            		var subTabsPanelId = 'editorSubTabsPanel';
            		var subTabsPanel = this.ownerCt.getComponent(subTabsPanelId);
            		if (subTabsPanel){
                		var activeSubTab  =  subTabsPanel.getActiveTab();
                		if(activeSubTab){
                		  activeSubTab.setHeight(activeSubTab.getHeight()+addHeight);// do all tabs
                		}	
            		}
        		}
        		catch(subPanelEx){
                    if (extVia.notify){
                      extVia.notify({action:'Applicationbar toggle ', status:'Error', mssg:'subPanelEx '+subPanelEx});
                    }
        		}
            },
            
            listeners:{ 
                resize:function(applibar,  adjWidth, adjHeight){
                  applibar.pagejobbar.setWidth(adjWidth);
                  applibar.pagetoolbar.setWidth(adjWidth);              
                },
                 
            	afterrender:function(applibar){
            		var resizerEl = Ext.get(Ext.get(applibar.id).dom.parentNode.id).createChild(
            				{
            				 tag:'div', border:true, 
            				 itemId:'pgtoolbarResizer',
            				 cls:'xty_pgtoolbar-resizer'
            				}); 
            		resizerEl.on('click',function(evt, targ){
            		  var togglePagejob = false;
            		  var togglePagetoolbar = true;
            		  if (evt.hasModifier()){
            		    togglePagejob  = evt.shiftKey;
            		    togglePagetoolbar = evt.ctrlKey;
            		  }
            		  applibar.toggle({pgjob:togglePagejob , pgtoolbar: togglePagetoolbar });
            		  },this);
            		
            	}
            },
            items : appbarItems
          });
      
      }
      else{  applicationbar = pagejobbar;}

	  return applicationbar;
	  
  },
  
  
  
		
  /**
   * Inits some Panel pagejob and epobDscr Functions, on Ext.panel.Panel.prototype
   */
  initBasicProtos : function initBasicProtos(){

    //TODO csenchiu: must be moved from here as it is code used in many apps. Why wasn't refactored it as it says in comment.
    // REFAC: -> extVia.ui.cmp.main.initBasicProtos
    //extend Ext.panel.Panel to have a setTabTip method
    Ext.panel.Panel.prototype.setTabTip = function(msg) {
      var tabPanel = this.findParentByType(Ext.tab.Panel);
      if (tabPanel) {
        var tabEl = Ext.fly(tabPanel.getTabEl(this).id);
        if (tabEl) {
          var tsTxt = tabEl.child('span.x-tab-strip-text', true);
          if (tsTxt){
            tsTxt.qtip = msg.toString();
          }
        }
      }
    };
    
    
    Ext.panel.Panel.prototype.setPagejobText = function(pgjobText, pgjobEpobDscr) {
      Ext.getCmp( this.getTopToolbar().id).setPagejobText(pgjobText, pgjobEpobDscr) ;
    };
    
    
    
    /**
     * 
     * @param title
     */
    Ext.panel.Panel.prototype.setMeasuredTabTitle = function(title) { 	
        //var shortTitle = extVia.ui.layout.factory.getMeasuredTabTitle(epobDscr);
        //this.setTitle(shortTitle);
    	//this.setTabTip(title);
    };

    
    Ext.panel.Panel.prototype.setTip = function(msg) {
       var span = Ext.getCmp(this.id).header.child('span');
       span.dom.setAttribute('ext:qtip',msg );
    };
    /**
     * Shows and Hides Tools and sets invisible Property.<br>
     * to provides persitance of visibility-State
     * <code>this.tools[toolId].invisible = !visible; </code>
     *  So the Tool can be asked about its visibility state
     * @param {String } toolId 
     * @param {boolean} visible
     */
    Ext.panel.Panel.prototype.setToolVisibility = function(toolId, visible) {
      if (this.tools && this.tools[toolId]){     
        if (visible){
          this.tools[toolId].show();
        }
        else{
         this.tools[toolId].hide();
        }        
        this.tools[toolId].invisible = !visible;   
        
      }
    };
    /**
     * Triggers our Ext.panel.Panel.prototype.setToolVisibility
     */
    Ext.panel.Panel.prototype.hideTool = function(toolId) {
      this.setToolVisibility(toolId, false);
    };    
    /**
     * Triggers our Ext.panel.Panel.prototype.setToolVisibility
     */
    Ext.panel.Panel.prototype.showTool = function(toolId) {
      this.setToolVisibility(toolId, true);
    };
    
    // ------ Start viaMenubar ------ //
//    if (extVia.regApp.myRaster.showMenubar) {
//      // prime menubar
//      //extVia.app.area.navi.main.initMenubar();
//    } 
    // ------ End viaMenubar ------ //
  } // eo initBasicProtos
  
  
};


extVia.ui.page.pagejob = new extVia.ui.page.pagejob();


/*
 * 
 * $Revision: 1.36.6.5 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2019/02/05 17:23:18 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 