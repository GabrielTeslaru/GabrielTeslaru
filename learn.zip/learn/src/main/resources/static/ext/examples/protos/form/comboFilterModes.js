/*

This file contains example usages of the Ext.ux.form.field.BoxSelect component, and is based on the
examples of comboboxes provided in Ext JS 4.

*/
Ext.require([
    'Ext.ux.form.field.BoxSelect'
]);

Ext.onReady(function() {
    Ext.tip.QuickTipManager.init();
	Ext.QuickTips.init();

    // Define the model for a State
    Ext.define('State', {
        extend: 'Ext.data.Model',
        fields: [
            {type: 'string', name: 'abbr'},
            {type: 'string', name: 'name'},
            {type: 'string', name: 'slogan'}
        ]
    });


    var states = [
        {"abbr":"AL","name":"Nahrungsmittel","slogan":""},
        {"abbr":"AK","name":"Nahrungsmittel > Obst","slogan":""},
        {"abbr":"AZ","name":"Nahrungsmittel > Gem�se","slogan":""},
        {"abbr":"AR","name":"Nahrungsmittel > Fleisch","slogan":""},
        {"abbr":"AK1","name":"Nahrungsmittel > Obst > Bio","slogan":""},
	    {"abbr":"AZ2","name":"Nahrungsmittel > Gem�se > Bio","slogan":""},
        {"abbr":"AR3","name":"Nahrungsmittel > Fleisch > Bio","slogan":""},
		{"abbr":"AR4","name":"Nahrungsmittel > Fleisch > Bio > Futtermittel","slogan":""},
		{"abbr":"AR5","name":"Nahrungsmittel > Fleisch > Bio > K�fighaltung","slogan":""},
		{"abbr":"AR6","name":"Nahrungsmittel > Fleisch > Bio > Freilaufend","slogan":""},
		
		
		
		{"abbr":"KL_1","name":"Kleidung","slogan":""},
		{"abbr":"KL_2","name":"Kleidung > Damen","slogan":""},
		{"abbr":"KL_3","name":"Kleidung > Herren","slogan":""},
		{"abbr":"KL_4","name":"Kleidung > Kinder","slogan":""},
	    {"abbr":"KL_5","name":"Kleidung > Kinder > Jungen","slogan":""},
        {"abbr":"KL_6","name":"Kleidung > Kinder > M�dchen","slogan":""},
		
	    {"abbr":"SCH_1","name":"Schuhe","slogan":""},
		{"abbr":"SCH_D","name":"Schuhe > Damen"},
		
		
		{"abbr":"SCH_D1","name":"Schuhe > Damen > Stiefeletten"},
		{"abbr":"SCH_D2","name":"Schuhe > Damen > Stiefeletten > klassische Stiefeletten"},
		{"abbr":"SCH_D3","name":"Schuhe > Damen > Stiefeletten > Schn�rstiefeletten"},
		{"abbr":"SCH_D4","name":"Schuhe > Damen > Stiefeletten > Cowboy- Bikerstiefeletten"},
		{"abbr":"SCH_D5","name":"Schuhe > Damen > Stiefel"},
		{"abbr":"SCH_D6","name":"Schuhe > Damen > Stiefel > klassische Stiefel"},
	    {"abbr":"SCH_D7","name":"Schuhe > Damen > Stiefel > Cowboy- Bikerboots"},
	    {"abbr":"SCH_D8","name":"Schuhe > Damen > Stiefel > Snowboots"},
		{"abbr":"SCH_D9","name":"Schuhe > Damen > Stiefel > Overknees"},
		{"abbr":"SCH_D10","name":"Schuhe > Damen > Stiefel > Schn�rstiefel"},
		{"abbr":"SCH_D11","name":"Schuhe > Damen > Stiefel > Keilstiefel"},	
		{"abbr":"SCH_D12","name":"Schuhe > Damen > Stiefel > Plateaustiefel"},	
		{"abbr":"SCH_D13","name":"Schuhe > Damen > Stiefel > Gummistiefel"},			
		{"abbr":"SCH_D14","name":"Schuhe > Damen > Pumps"},
		{"abbr":"SCH_D15","name":"Schuhe > Damen > Sneaker"},		
		{"abbr":"SCH_D16","name":"Schuhe > Damen > Ballerinas"},
		{"abbr":"SCH_D17","name":"Schuhe > Damen > Schn�rschuhe"},		
		{"abbr":"SCH_D18","name":"Schuhe > Damen > Halbschuhe"},
		{"abbr":"SCH_D18a","name":"Schuhe > Damen > Halbschuhe > Slipper"},
		{"abbr":"SCH_D18b","name":"Schuhe > Damen > Halbschuhe > Mokassins"},
		{"abbr":"SCH_D18c","name":"Schuhe > Damen > Halbschuhe > Espadrilles"},
		{"abbr":"SCH_D19","name":"Schuhe > Damen > High Heels"},	
		{"abbr":"SCH_D20","name":"Schuhe > Damen > Sandaletten"},		
		{"abbr":"SCH_D21","name":"Schuhe > Damen > Pantoletten"},
		{"abbr":"SCH_D21a","name":"Schuhe > Damen > Pantoletten > klassische Pantoletten"},
		{"abbr":"SCH_D21b","name":"Schuhe > Damen > Pantoletten > Clogs"},
		{"abbr":"SCH_D22","name":"Schuhe > Damen > Outdoor"},
		{"abbr":"SCH_D23","name":"Schuhe > Damen > Hausschuhe"},
		{"abbr":"SCH_D24","name":"Schuhe > Damen > Badschuhe"},
		
		
		
		
		{"abbr":"SCH_3","name":"Schuhe > Herren","slogan":""},
		{"abbr":"SCH_4","name":"Schuhe > Kinder","slogan":""},
	    {"abbr":"SCH_5","name":"Schuhe > Kinder > Jungen","slogan":""},
        {"abbr":"SCH_6","name":"Schuhe > Kinder > M�dchen","slogan":""},
		
		{"abbr":"SONDER_1","name":"Dollar > $$$$ money","slogan":""},
		{"abbr":"SONDER_1","name":"Dollar > four","slogan":""},
		
		{"abbr":"SONDER_X","name":"* $ +  $ . {[^]} ? ","slogan":""},
		{"abbr":"SONDER_dreFr","name":"Die drei ?","slogan":""},
		{"abbr":"SONDER_dreFrs","name":"Die drei ??? Fragezeichen","slogan":""},
		
		{"abbr":"FAVS_0","name":"Stars >  zero 0","slogan":""},
		{"abbr":"FAVS_1","name":"Stars > * > one 1","slogan":""},
		{"abbr":"FAVS_2","name":"Stars > ** > two 2","slogan":""},
		{"abbr":"FAVS_3","name":"Stars > *** > three 3","slogan":""},
		{"abbr":"FAVS_4","name":"Stars > **** > four 4","slogan":""},
		{"abbr":"FAVS_5","name":"Stars > ***** > five 5","slogan":""},
		
		{"abbr":"FAVS_0+","name":"Stars >  zero 0","slogan":""},
		{"abbr":"FAVS_1+","name":"Stars > + > one 1","slogan":""},
		{"abbr":"FAVS_2+","name":"Stars > ++ > two 2","slogan":""},
		{"abbr":"FAVS_3+","name":"Stars > +++ > three 3","slogan":""},
		{"abbr":"FAVS_4+","name":"Stars > ++++ > four 4","slogan":""},
		{"abbr":"FAVS_5+","name":"Stars > +++++ > five 5","slogan":""}
		
    ];




    var statesStore = Ext.create('Ext.data.Store', {
        model: 'State',
        data: states,
		filterMode:'dbWildcard'
    });
    
    

    var currentRawValue = "";
    
	
	// try 2 use Ext.Fumnction:   interceptBefore( Object object, String methodName, Function fn ) : Function
	// ??? Ext.Fumnction.interceptBefore( statesStore, filter, Function fn )???
	
    statesStore.filter =  function(filters, value) {
    
	
	 ////// start of interceptBefore ////////
     currentRawValue = value;// workaround
		 
     var modifier; 
	 if (!this.caseSensitive){
	 	modifier="i";
	 }
		 
      switch (this.filterMode) {
	   case "dbWildcard": 

         value= value.replace(/\*/g,".*");

	     value =  new RegExp(value, modifier);    
	     break;
	   case "startsWith":
	     value =  new RegExp("^"+value+".*", modifier);
	     break;
	   case "endsWith":
	     value =  new RegExp(".*"+value+"$", modifier);
	     break;
	   case "startEndRegex":
	     value =  new RegExp("^"+value+"$", modifier);
	     break; 
	   case "containsRegex":
	     value =  new RegExp(value, modifier);
	     break;  
		 
		case "containsExact":
		
		 value= value.replace(/\./g,"\\.");	
		 value= value.replace(/\^/g,"\\^");	
		 value= value.replace(/\*/g,"\\*");
		 value= value.replace(/\$/g,"\\$");
		 value= value.replace(/\+/g,"\\+");
		 value= value.replace(/\[/g,"\\[");		 
		 value= value.replace(/\]/g,"\\]");
		 value= value.replace(/\{/g,"\\{");
		 value= value.replace(/\}/g,"\\}");	
		 value= value.replace(/\?/g,"\\?");	

		
	     value =  new RegExp(value, modifier);
	     break;  
		 
		case "nodes":
		 value= value.replace(/>/g,".*> ");	
	     value =  new RegExp(value, modifier);
	     break;  
		 		  
		case "firstChilds":

		
		 value= value+".[^>]*> .[^ ]*$";	
	     value =  new RegExp(value, modifier);
	     break; 	     
		 
		case "childsOf":
		   
		 var recs =   basicSelect.getValueRecords();
		 var lastRec = recs[recs.length-1];
		 
		// alert(lastRec.data.name)
		
		// value= value+".[^>]*> .[^ ]*$";	
		 
		 if (lastRec)
		  value = lastRec.data.name+  " > " +value+".*";
		 
	     value =  new RegExp(value, modifier);
	     break; 		 
		
		 
	   default:
	     break;
         };
         
         
         ////// end of interceptBefore ////////
         
    
            if (Ext.isString(filters)) {
                filters = {
                    property: filters,
                    value: value
                };
            }
    
            var me = this,
                decoded = me.decodeFilters(filters),
                i = 0,
                doLocalSort = me.sortOnFilter && !me.remoteSort,
                length = decoded.length;
    
            for (; i < length; i++) {
                me.filters.replace(decoded[i]);
            }
    
            if (me.remoteFilter) {
                //the load function will pick up the new filters and request the filtered data from the proxy
                me.load();
            } else {
                /**
                 * A pristine (unfiltered) collection of the records in this store. This is used to reinstate
                 * records when a filter is removed or changed
                 * @property snapshot
                 * @type Ext.util.MixedCollection
                 */
                if (me.filters.getCount()) {
                    me.snapshot = me.snapshot || me.data.clone();
                    me.data = me.data.filter(me.filters.items);
    
                    if (doLocalSort) {
                        me.sort();
                    }
                    // fire datachanged event if it hasn't already been fired by doSort
                    if (!doLocalSort || me.sorters.length < 1) {
                        me.fireEvent('datachanged', me);
                    }
                }
            }
    };
    
    
   var onFilterCheck = function(){
    
      //alert( Ext.getCmp("filtermodeRadiogroup").getValue().filtermodeRadiogroup  );
      statesStore.filterMode = Ext.getCmp("filtermodeRadiogroup").getValue().filtermodeRadiogroup ;
	  statesStore.caseSensitive = Ext.getCmp("filterOptionsCheckboxgroup").getValue().caseSensitive ;
	  
	  basicSelect.typeAhead = Ext.getCmp("filterOptionsCheckboxgroup").getValue().typeAhead;
	  basicBoxSelect.typeAhead = Ext.getCmp("filterOptionsCheckboxgroup").getValue().typeAhead;
	  
	  basicSelect.outermatchHighlighting = Ext.getCmp("viewOptionsCheckboxgroup").getValue().googleHighlighting;
	  basicBoxSelect.outermatchHighlighting = Ext.getCmp("viewOptionsCheckboxgroup").getValue().googleHighlighting;
	  
	  
    };  
 
 
     var filterOptionsCheckboxgroup  =  {
	            xtype: 'checkboxgroup', 
				id:'filterOptionsCheckboxgroup',
				itemId:'filterOptionsCheckboxgroup',
	            fieldLabel: 'filter Options',width:580,laydout: 'hbox',labelWidth: 100,
	            columns: 1,
	            defaults:{width:200},
	            items: [
				    {boxLabel: 'case sensitive (default off)', name: 'caseSensitive', inputValue: true, handler: onFilterCheck},
					{id:'filterOptionsCheckboxgroup_typeAhead',
						boxLabel: 'type ahead(default off)',

					  tooltip:'true to populate and autoselect the remainder of the text being typed after a configurable delay  if it matches a known valueDefaults to: false', 
                      name: 'typeAhead', inputValue: true, handler: onFilterCheck}
					//,{boxLabel: 'blubbbblubb', name: 'blubbbblubb', inputValue: true, handler: onFilterCheck}
	            ]
        };
    
	
	
	
    var filtermodeRadiogroup  =  {
	            xtype: 'radiogroup', 
				id:'filtermodeRadiogroup',
				itemId:'filtermodeRadiogroup',
	            fieldLabel: 'filter mode',width:580,laydout: 'hbox',labelWidth: 100,
	            columns: 1,
	            defaults:{width:200},
	            items: [
				    {boxLabel: 'Starts with Exact (extjs default)', name: 'filtermodeRadiogroup', inputValue: 'default', handler: onFilterCheck},
	                {boxLabel: '<b>dbWildcard</b> (epim default)', name: 'filtermodeRadiogroup', inputValue: 'dbWildcard', checked: true, handler: onFilterCheck},
	                {boxLabel: 'Starts with + Regex', name: 'filtermodeRadiogroup', inputValue: 'startsWith', handler: onFilterCheck},
	                {boxLabel: 'Ends with + Regex', name: 'filtermodeRadiogroup', inputValue: 'endsWith', handler: onFilterCheck},
	                {boxLabel: 'startEnd + Regex', name: 'filtermodeRadiogroup', inputValue: 'startEndRegex', handler: onFilterCheck},
					
					
	                {boxLabel: '<b>contains</b> + Regex', name: 'filtermodeRadiogroup', inputValue: 'containsRegex', handler: onFilterCheck},
					{boxLabel: 'contains Exact (Sonderzeichen)',  tooltip:'no need to type escape characters ', name: 'filtermodeRadiogroup', inputValue: 'containsExact', handler: onFilterCheck},
					{xtype:'panel',border:false,height:16},
					{boxLabel: 'nodes (use >)', name: 'filtermodeRadiogroup', inputValue: 'nodes', handler: onFilterCheck},
					{boxLabel: '<b>firstChilds</b> + Regex', name: 'filtermodeRadiogroup', tooltip:'use with type Ahead. Useful when the tree is very deep',inputValue: 'firstChilds', handler: onFilterCheck},
					{boxLabel: 'childs Of + Regex',  tooltip:'Select an Entry and type: -> youll see only the childs of the last Selected Entry.<br> Similar to firstChilds ',
					 name: 'filtermodeRadiogroup', inputValue: 'childsOf', handler: onFilterCheck,
					 hXXeight:80,
					 bXXoxLabel: 'childs Of + Regex<br>'+
					 '<div  class="x-tip x-tip-default x-layer" style="position: absolute; left: 14px; top: 24px; width: 300px; height: 54px; z-index: 19001;" role="tooltip"><div class="x-tip-body  x-tip-body-default x-tip-body-default" id="tooltip-1040-body" style="left: 0px; top: 0px; width: 294px;">Select an Entry and type: -&gt; youll see only the childs of the last Selected Entry.<br> Similar to firstChilds </div><div class="x-tip-anchor x-tip-anchor-top" id="ext-gen1073" style="z-index: 1; display: none;"></div></div>'
					 }
					
	            ]
        };
    
    
	   var viewOptionsCheckboxgroup  =  {
	            xtype: 'checkboxgroup', 
				id:'viewOptionsCheckboxgroup',
				itemId:'viewOptionsCheckboxgroup',
	            fieldLabel: 'view Options',width:580,laydout: 'hbox',labelWidth: 100,
	            columns: 1,
	            defaults:{width:200},
	            items: [
				    {boxLabel: 'google like highlighting', name: 'googleHighlighting', tooltip:'Inverse. Focus on what is left, what is to be selected.', handler: onFilterCheck}
	            ]
        };
    
	
	
	
	
    
       /**
   * highlights the searchedValue inside displayValues of an autoCompleteBox
   * @param  {String} textStr  the displayValue
   * @return  {String} formattedStr 
   */
   formatAutoCompleteText = function (textStr) {
   	
	//return textStr;
    var formattedStr = textStr;
    try{ 
    
       cmp =  currentBasicSelect;
      
    	if(cmp){
          //var searchVal = cmp.getRawValue();// Why does this not work?

          var searchVal = currentRawValue;// workaround set store filters
		  //Ext.getCmp("statusfield").setValue(currentRawValue);
		  
		  
          searchVal = searchVal.replace( /[*%]/g, ".*");
          var valX  = new RegExp("("+searchVal+")", 'i');
          
		  
		  
		  // if googleHighlighting
		  if(basicSelect.outermatchHighlighting){
		     
			 // whats not found
			 //formattedStr = formattedStr.replace(valX,"</b>$1<b style='background:#eaf4f9'>");
		     //formattedStr = "<b style='background:#eaf4f9'>"+formattedStr+"</b>"
			 
			 // whats left
			 formattedStr = formattedStr.replace(valX,"$1<b style='background:#eaf4f9'>");
			 formattedStr = formattedStr+"</b>"
		  }
		  else {
		  	// whats found
		  	formattedStr = formattedStr.replace(valX,"<b style='background:#eaf4f9'>$1</b>");
		  }

		  
		  
    	}
    }
    catch(ex){ }
    return formattedStr;
  };   
 
	
  
  //Create the spotlight component
  var spot = Ext.create('Ext.ux.Spotlight', {
      easing: 'easeOut',
      duration: 300
  });
  var updateSpot = function(id) { 
      if (typeof id == 'string') {
          spot.show(id);
      } else if (!id && spot.active) {
          spot.hide();
      }
  };
  
  
    var currentBasicSelect;
    // Basic BoxSelect using the data store
    var selectCfg = {
        displayField: 'name',
        width: 580,
        labelWidth: 100,
		fieldLabel: 'Categories',
		//matchFieldWidth : false,
        listConfig : {
			width:600,
            getInnerTpl: function() {
                    return '<div  class="x-combo-list-item">{[formatAutoCompleteText(values.name)]}</div>' ;   
                }			
			},
        store: statesStore,
        queryMode: 'local',
		emptyText: 'Choose your filter-mode and type...',
		valueField: 'abbr',
		setFilterMode:function(filterMode){
			// this.getStore.setFilterMode(filterMode);
		},
		
		listeners: {
	        click: {
	            element: 'el', //bind to the underlying el property on the panel
	            fn: function(){ 
					//alert('click el'+this.id);
					
					currentBasicSelect = this;// needed for formatting
					 }
	        },
	        dblclick: {
	            element: 'el', //bind to the underlying body property on the panel
	            fn: function(event){ 
					
				var cmp = Ext.getCmp(this.id);	
				Ext.create('Ext.window.Window', {
				    title: 'Filter mode and options: '+ Ext.getCmp(this.id).fieldLabel,
				    height: 400,
				    width: 400,
					//modal:true,
				    layout: 'fit',
				    items:[
				           
				           
						Ext.create('Ext.panel.Panel', {
						    border:false,
							width:680,
						    items:[    
								{
								    xtype: 'checkboxgroup', 
									id:'filterOptionsCheckboxgroup_2',
									itemId:'filterOptionsCheckboxgroup_2',
								    fieldLabel: 'filter Options',width:580,laydout: 'hbox',labelWidth: 100,
								    columns: 1,
								    defaults:{width:200},
								    items: [
									    {boxLabel: 'case sensitive (default off)', name: 'caseSensitive', inputValue: true, handler: onFilterCheck},
										{id:'filterOptionsCheckboxgroup_typeAhead',
											boxLabel: 'type ahead(default off)',
								
										  tooltip:'true to populate and autoselect the remainder of the text being typed after a configurable delay  if it matches a known valueDefaults to: false', 
								          name: 'typeAhead', inputValue: true, handler: onFilterCheck}
										//,{boxLabel: 'blubbbblubb', name: 'blubbbblubb', inputValue: true, handler: onFilterCheck}
								    ]
								},
				           
				            {
				   	            xtype: 'radiogroup', 
				   				id:'filtermodeRadiogroup_2',
				   				itemId:'filtermodeRadiogroup_2',
				   	            fieldLabel: 'filter mode',width:580,laydout: 'hbox',labelWidth: 100,
				   	            columns: 1,
				   	            defaults:{width:200},
				   	            items: [
				   				    {boxLabel: 'Starts with Exact (extjs default)', name: 'filtermodeRadiogroup', inputValue: 'default', handler: onFilterCheck},
				   	                {boxLabel: '<b>dbWildcard</b> (epim default)', name: 'filtermodeRadiogroup', inputValue: 'dbWildcard', checked: true, handler: onFilterCheck},
				   	                {boxLabel: 'Starts with + Regex', name: 'filtermodeRadiogroup', inputValue: 'startsWith', handler: onFilterCheck},
				   	                {boxLabel: 'Ends with + Regex', name: 'filtermodeRadiogroup', inputValue: 'endsWith', handler: onFilterCheck},
				   	                {boxLabel: 'startEnd + Regex', name: 'filtermodeRadiogroup', inputValue: 'startEndRegex', handler: onFilterCheck},
				   					
				   					
				   	                {boxLabel: '<b>contains</b> + Regex', name: 'filtermodeRadiogroup', inputValue: 'containsRegex', handler: onFilterCheck},
				   					{boxLabel: 'contains Exact (Sonderzeichen)',  tooltip:'no need to type escape characters ', name: 'filtermodeRadiogroup', inputValue: 'containsExact', handler: onFilterCheck},
				   					{xtype:'panel',border:false,height:16},
				   					{boxLabel: 'nodes (use >)', name: 'filtermodeRadiogroup', inputValue: 'nodes', handler: onFilterCheck},
				   					{boxLabel: '<b>firstChilds</b> + Regex', name: 'filtermodeRadiogroup', tooltip:'use with type Ahead. Useful when the tree is very deep',inputValue: 'firstChilds', handler: onFilterCheck},
				   					{boxLabel: 'childs Of + Regex',  tooltip:'Select an Entry and type: -> youll see only the childs of the last Selected Entry.<br> Similar to firstChilds ',
				   					 name: 'filtermodeRadiogroup', inputValue: 'childsOf', handler: onFilterCheck,
				   					 hXXeight:80,
				   					 bXXoxLabel: 'childs Of + Regex<br>'+
				   					 '<div  class="x-tip x-tip-default x-layer" style="position: absolute; left: 14px; top: 24px; width: 300px; height: 54px; z-index: 19001;" role="tooltip"><div class="x-tip-body  x-tip-body-default x-tip-body-default" id="tooltip-1040-body" style="left: 0px; top: 0px; width: 294px;">Select an Entry and type: -&gt; youll see only the childs of the last Selected Entry.<br> Similar to firstChilds </div><div class="x-tip-anchor x-tip-anchor-top" id="ext-gen1073" style="z-index: 1; display: none;"></div></div>'
				   					 }
				   					
				   	            ]
				           },
				           
				           
				           
				           {
				   	            xtype: 'checkboxgroup', 
				   				id:'viewOptionsCheckboxgroup_2',
				   				itemId:'viewOptionsCheckboxgroup_2',
				   	            fieldLabel: 'view Options',width:580,laydout: 'hbox',labelWidth: 100,
				   	            columns: 1,
				   	            defaults:{width:200},
				   	            items: [
				   				    {boxLabel: 'google like highlighting', name: 'googleHighlighting', tooltip:'Inverse. Focus on what is left, what is to be selected.', handler: onFilterCheck}
				   	            ]
				           }
				           ]})//eo panel
				           
				           
				           
				           ],
				    listeners:{
				    	beforeclose:function(){  spot.hide();}
				    }
				}).showAt(event.getXY());
				     cmp.getEl().frame();
				     updateSpot(""+cmp.id);
					}
	        }
        }
		
			
    };
    


     var basicSelect = Ext.create('Ext.form.field.ComboBox', selectCfg);
	 var basicBoxSelect = Ext.create('Ext.ux.form.field.BoxSelect', selectCfg);
    basicBoxSelect.fieldLabel= 'Categories as box';
	
	
    var basicSelectContainer = Ext.create('Ext.panel.Panel', {
        renderTo: 'basicSelect',
        border:false,
		width:680,
        items:[        
//	    {
//		xtype: 'fieldcontainer',
//		fieldLabel: 'Categories',
//		layout: 'hbox',
//		width:600,
//		defaults: {
//		    flesx: 1,
//		    hideLabel: true
//		},
//		items: [
//		    //basicSelect,
//		    
//		    {width:20,xtype:'tbspacer'}
//		  
//		]
//    	},
		basicSelect,
		basicBoxSelect,
        filterOptionsCheckboxgroup,
        filtermodeRadiogroup,
		viewOptionsCheckboxgroup,
		
		
		{xtype:'displayfield', id :'statusfield', value:"", width:100}
        
        ]
        
        
    });    

   
  var addTooltips = function (container){
   var items = container.items;
   for(var i=0; i< items.length; i++){ 
    var cmp = items.getAt(i);
    if (cmp.tooltip){
		    Ext.create('Ext.tip.ToolTip', {
            target: cmp.id,
			//autoHide:false,
			//closable:true,
            html: cmp.tooltip
    });	
	}
   }	
  };
    
  addTooltips(basicSelectContainer.getComponent("filterOptionsCheckboxgroup"));
  addTooltips(basicSelectContainer.getComponent("filtermodeRadiogroup"));
  addTooltips(basicSelectContainer.getComponent("viewOptionsCheckboxgroup"));
  

   

});