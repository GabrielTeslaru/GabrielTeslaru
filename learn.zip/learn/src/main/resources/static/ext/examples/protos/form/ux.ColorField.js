/**
 * @class Ext.ux.ColorField
 * 
 *  A Triggerfield with a photoshop like ColorpickerPanel.
 *  Allowing RGB hex + hue, saturation brightness input
 * 
 * @author Simon Lederer, Viamedici Software GmbH
 * @version $Date: 2013/09/13 09:36:50 $ $Revision: 1.4 $
 */
Ext.define('Ext.ux.ColorField', { 
	  extend: 'Ext.form.field.Trigger',
	  //extend:'Ext.form.field.Picker', 
	  //extend: 'Ext.form.field.ComboBox',
	  
	  trigger1Cls:'xty_colorfield-value',
	  trigger2Cls:'xty_colorfield-trigger', 

	  hideTrigger1:false, 
	  
	  
	  alias: 'widget.colorfield',
	  triggerTip: 'Please select a color.',
	  
	  imageBase:"../form/img/",//  default protoCase  bar-hue.png" ,

	  hexX:/#?[0-9A-Fa-f]{6}/i,
	  
	  allowTransparent:false,
	  validator:function(value){

		  if (this.hexX.test(value)){
			  return true;
		  }
		  else if (this.allowTransparent&& value.toUpperCase().indexOf("TRANSPARENT")>-1){
			  return true;
		  }			  
		  else {
			  if (this.allowTransparent) return this.validatorText+this.validatorTransparentText;
			  else  return this.validatorText;
		  }
			 
	  },
	  
	  chooseColorText:'Farbe ausw&auml;hlen',  
	  chosenColorText:'gew&auml;hlte Farbe',
	  applyColorText:'Farbwert &uuml;bernehmen',
	  applyText:'&Uuml;bernehmen',
	  validatorText:"Value should be in hexadecimal format",
	  validatorTransparentText:", or <i>transparent</i>",
	  applyTransparenceText:"Transparent &uuml;bernehmen",
 
 
	  listeners:{
        render:function(){

    		var colorfieldTrigger = Ext.query('#'+this.id+' DIV[class~="xty_colorfield-trigger"]')[0].id; 
    		Ext.create('Ext.tip.ToolTip',{trackMouse: true, html: this.chooseColorText, target: colorfieldTrigger});
    		var colorfieldValue = Ext.query('#'+this.id+' DIV[class~="xty_colorfield-value"]')[0].id; 
    		Ext.create('Ext.tip.ToolTip',{trackMouse: true, html: this.chosenColorText, target: colorfieldValue}); 	
    		
    		var val = this.getValue();
    		
    		if (!val){val="#FFFFFF";}

    		var colorfieldValueEl = Ext.get(colorfieldValue);

    		colorfieldValueEl.setStyle({width:'40px'});
    		colorfieldValueEl.setStyle({borderTop:'1px solid #b5b8c8'});
    		colorfieldValueEl.setStyle({borderRight:'1px solid #b5b8c8'});
    		colorfieldValueEl.setStyle({background:val});
    		
    		this.colorfieldValueEl = colorfieldValueEl;
    		
    	},
    	change:function(){
	    	var comboValue_1 =  this.getValue();		  
	    	var opacity =1;

	    	if (comboValue_1.toUpperCase().indexOf("TRANSPARENT")>-1){
	    		opacity = 0.5;
	    	}
	    	else if (comboValue_1.indexOf('#')<0){
				comboValue_1 = '#'+comboValue_1;
			}
	    	
	   		if (this.colorfieldValueEl){
	   			this.colorfieldValueEl.setStyle({background:comboValue_1});
	   			this.colorfieldValueEl.setStyle({opacity:opacity});
	   		}
	   		if (this.colorpicker && !this.colorpicker.hidden){
				    this.colorpicker.setValue(comboValue_1);
			 }
    	}, 
    	 
    	focus:function(){
    		this.colorfieldValueEl.setStyle({borderColor:'#7eadd9'});
    	},
    	blur:function( field, eOpts ){  	
    		if (this.colorpicker &&  !this.colorpicker.hidden && !this.colorpicker.inCharge){
    			//alert (this.colorpicker.inCharge);
    			this.colorpicker.hide();
    		}
    		
    		this.colorfieldValueEl.setStyle({borderColor:'#b5b8c8'});
   		}    	
     	,destroy:function(){
    		if (this.colorpicker){
    			this.colorpicker.destroy();
    		}
   		}    	
    	
    	
     }, 
	  
     
     
     isDark : function (){
   		 return Ext.ux.ColorField.isDark(this.getValue());
     },
     
     /**
      * Creates and shows the ColorpickerPanel
      */ 
 	onTriggerClick: function() {

 		
 		var me = this;

 	    if (me.colorpicker && me.colorpicker.isVisible() ){
 	    	me.colorpicker.hide();
 	    }
 	    else{
 	 	    me.createColorpicker(me);
 		    me.colorpicker.alignTo(me.inputEl, 'tl-bl?');
 		    me.colorpicker.show(me.inputEl);
 	    }

 	},
 	
 	
    /**
     * Creates the ColorpickerPanel
     */ 
	createColorpicker: function() {
	    var me = this;
	    
    	

	var comboHSL_H_Val =0;
	var comboHSL_S_Val =0;
	var comboHSL_L_Val =0;
	var hsl_locator_left =0;
	var hsl_locator_top =0;
	var hsv;
	
	var	comboRVal=0;
	var	comboGVal=0;
	var	comboBVal=0;
	var	comboHexVal="#FFFFFF";
	var initialColorIsDark = false;
	
	var	comboHexValBright="#FF0000";
	
	var  comboValue = me.getValue();
	if (comboValue.indexOf('#')<0){
		comboValue = '#'+comboValue;
	}
	var extCol = Ext.draw.Color.fromString(comboValue);
	
	var hslLocatorId =  'hsl_locator-'+Ext.id();
	
	
	if (extCol){

		comboRVal=extCol.getRed();
		comboGVal=extCol.getGreen();
		comboBVal=extCol.getBlue();
		
		
		var hsl = extCol.getHSL();
		if (! hsl[0]){
			hsl[0] =0;
		}		
		comboHSL_H_Val= Math.round(hsl[0],0);
		
		hsv = Ext.ux.ColorField.rgbToHsv({r:comboRVal,g:comboGVal,b:comboBVal});	
		
		comboHSL_S_Val= hsv.s;
		comboHSL_L_Val= hsv.v;
		hsl_locator_left =  Math.round(comboHSL_S_Val*194/100,0);
		hsl_locator_top =  194 - Math.round(comboHSL_L_Val*194/100,0);
		
		var rgb = Ext.ux.ColorField.hsvToRgb({h:comboHSL_H_Val,s:100,v:100});
		var extColBright = new Ext.draw.Color(rgb.r, rgb.g, rgb.b);
		comboHexValBright= extColBright.toString();
		comboHexVal=comboValue;
		
		initialColorIsDark =Ext.ux.ColorField.isDark(extCol);
	}
	
	
	    
	 // START ColorpickerPanel
	
	 // Better would be Ext.define('Ext.ux.ColorpickerPanel'
	 var colorpicker = Ext.create('Ext.form.Panel', {
            
		 	// Needed when  a colorfield is extending a combo
		 	//getSelectionModel:function(){return{deselectAll:function(){return false;},};},
	     
    
		 /**
		  * checks all colorpicker fields inCharge. Needed for closing 
		  */
		 isFieldsInCharge: function() {	 
		 
		   if (!me.colorpicker.fields){
			   me.colorpicker.fields={};
        	   var colorColumnFields = me.colorpicker.getComponent('color-columns-bin').getComponent('color-column-fields'); 
        	   me.colorpicker.fields.coloHSL_H = colorColumnFields.getComponent('coloHSL_H_container').getComponent('coloHSL_H');	;            	   
        	   me.colorpicker.fields.colorRGB_R = colorColumnFields.getComponent('colorRGB_R');
        	   me.colorpicker.fields.colorRGB_G = colorColumnFields.getComponent('colorRGB_G');
        	   me.colorpicker.fields.colorRGB_B  = colorColumnFields.getComponent('colorRGB_B');
        	   me.colorpicker.fields.colorHEX = colorColumnFields.getComponent('colorHEX');   
		   }

	   		var fieldsInCharge =false;
		   
		   if (me.colorpicker.fields.coloHSL_H.inCharge){
			   fieldsInCharge = true;
		   }
		   else if (me.colorpicker.fields.colorRGB_R.inCharge){
			   fieldsInCharge = true;
		   }        		   
		   else if (me.colorpicker.fields.colorRGB_G.inCharge){
			   fieldsInCharge = true;
		   }         		   
		   else if (me.colorpicker.fields.colorRGB_B.inCharge){
			   fieldsInCharge = true;
		   } 
		   else if (me.colorpicker.fields.colorHEX.inCharge){
			   fieldsInCharge = true;
		   } 	
		   return fieldsInCharge;
			 
		 },

		 listeners:{	
			 afterrender: function(colorpickerPanel) {	
				 var focusFirstField = new Ext.util.DelayedTask(function(){
					 colorpickerPanel.getComponent('color-columns-bin').getComponent('color-column-fields').getComponent('coloHSL_H_container').getComponent('coloHSL_H').focus();	 
				 });
				 focusFirstField.delay(500);// without delay in IE it jumps around  in border Layout  
				 colorpickerPanel.inCharge=true;	 
			 },
			 
	         render: function(panel) {	 
	        	 
	        	 panel.body.on('mouseleave', function( evt, target, eOpts ) {
	        		   me.colorpicker.inCharge = false;	 
	        	 });
	        	 panel.body.on('mouseenter', function( evt, target, eOpts ) {
	        		   me.colorpicker.inCharge = true;	 
	        	 });	        	 
	        	 
        	   panel.body.on('click', function( evt, target, eOpts ) {
        		   var fieldsInCharge = me.colorpicker.isFieldsInCharge();
        		   // manage Focus
        		    if (!fieldsInCharge){
        		    	me.focus();// providing blur
        	   	   }
        	   });
	         }
		 },
		 
            bodyStyle:'padding:5px',
	        width: 380,
	        height: 208,
	        style:'z-index:29100;position:absolute;', // needed in Dialog container 
	        renderTo: document.body,
	        
	        cls:'xty_colorfield-picker xty_colorfield-valueIs'+ (initialColorIsDark?'Dark':'Light'),
	        
	        setValue: function(hexStr){
	        	var extCol = Ext.draw.Color.fromString(hexStr);
	        	this.setColorOnAllFields(extCol, {fromColorpicker:true});
	        },
	        setColorOnAllFields: function(extCol, cfg){
	
       		  var colorColumnFields = this.getComponent('color-columns-bin').getComponent('color-column-fields'); 
       		  var colorColumnRange = this.getComponent('color-columns-bin').getComponent('color-column-range'); 
       		  var colorColumnMap = this.getComponent('color-columns-bin').getComponent('color-column-map'); 


			   if (extCol){
				    		  
				    var hueVal = 0;	      
        			// hueVal = extCol.getHSL()[0];
        			var hsv = Ext.ux.ColorField.rgbToHsv({r:extCol.getRed(),g:extCol.getGreen(),b:extCol.getBlue()});		
        			hueVal = hsv.h;

	     		    if (! hueVal){
	     			   hueVal =0;
	     		    }
	     		    hueVal=Math.round(hueVal,0);
	     		    colorColumnFields.getComponent('coloHSL_H_container').hsv = hsv;
	     		    
	     		   
					/////////////////// place hsl_locator ///////////
	     		   if (!cfg.fromMap &&!cfg.fromHue &&!cfg.fromSlider) {  
		     		    //var hsl_locator_El =Ext.get(Ext.get(colorColumnMap.id).dom.firstChild.firstChild.firstChild.firstChild);
						var hsl_locator_El = Ext.get(hslLocatorId);
						
						hsl_locator_left =  Math.round(hsv.s*194/100,0)-6;
						hsl_locator_top =  194 - Math.round(hsv.v*194/100,0)-14;
				
						if (hsl_locator_top>178){hsl_locator_top = 178;}
						if (hsl_locator_top<-8){hsl_locator_top = -8;}					
						if (hsl_locator_left>178){hsl_locator_top = 178;}
						if (hsl_locator_left<-2){hsl_locator_top = -2;}					
						
						var colorIsDark = Ext.ux.ColorField.isDark(extCol);

						if (!colorIsDark){
		        			 hsl_locator_El.setStyle({color: "black"});
		        		 }
		        		 else{
		        			hsl_locator_El.setStyle({color: "white"});
		        		 }
		        		 
						hsl_locator_El.setStyle({top:hsl_locator_top+"px"});
						hsl_locator_El.setStyle({left:hsl_locator_left+"px"});
	     		    }
					/////////////////// ende place hsl_locator ///////////
   
	     		    
				   if (!cfg.fromHue)  {
					   
	     			  var coloHSL_H = colorColumnFields.getComponent('coloHSL_H_container').getComponent('coloHSL_H');	     	    	      
	     			  coloHSL_H.setValue( hueVal);  
	     		   };
	     		   
	     		   if (!cfg.fromSlider)  {
	     			   var colorSlider = colorColumnRange.getComponent('colorSlider');  	    	      
		     		   colorSlider.inCharge=false;
		     		   colorSlider.setValue(hueVal) ;  
		     		};
				   
				   
				   if (!cfg.fromHex) colorColumnFields.getComponent('colorHEX').setValue(extCol.toString().replace(/#/,'').toUpperCase());
				   if (!cfg.fromRGB) colorColumnFields.getComponent('colorRGB_R').setValue(extCol.getRed());
				   if (!cfg.fromRGB) colorColumnFields.getComponent('colorRGB_G').setValue(extCol.getGreen());
				   if (!cfg.fromRGB) colorColumnFields.getComponent('colorRGB_B').setValue(extCol.getBlue());
				  

				   var colorVALUE_El = colorColumnFields.getComponent('colorVALUE').getEl();
				   if (colorVALUE_El){
					   colorVALUE_El.setStyle({backgroundColor:extCol.toString()});
				   }
				   
				   
				   if (!cfg.fromMap) {  
	        		   var rgb = Ext.ux.ColorField.hsvToRgb({h:hueVal,s:100,v:100});
 	        		   extCol = new Ext.draw.Color(rgb.r,rgb.g,rgb.b);					   					   
 	        		   colorColumnMap.getComponent('colorMap').getEl().dom.firstChild.style.backgroundColor = extCol.toString() ;
				   }			      
			   }	
	        	
	        },

	        items: [{
	            layout:'column',
	            itemId:'color-columns-bin',
	            border:false,
	            items:[ 
	                {
	                columnWidth:.58,
	                itemId:'color-column-map',
	                border:false,
	                layout: 'anchor',
	                defaultType: 'textfield',
	                items: [         
	                   {itemId:'colorMap', xtype:'panel', width:195, height:195,  
	                	 
	                	 bodyStyle:'background-color:'+comboHexValBright+';', 
	                	 style:'cursor:crosshair;',
	                	 html:
	                		 '<div id="'+hslLocatorId+'" class="xty_hsl_locator" style="z-index:19300;color:'+(initialColorIsDark?"white":"black")+';font-size:18px;position:absolute;top:'+hsl_locator_top+'px;left:'+hsl_locator_left+'px;">&times;</div>'+
	                		 '<img width="195" height="195" src="'+me.imageBase+'/colorpicker_map-hue.png" style=" display: block;">',	 		     	
            		     	
            		     	listeners:{	
		    		         render: function(panel) {	 
		    		           panel.body.on('dblclick', function( evt, target, eOpts ) {
		    		        	   me.setValue("#"+colorpicker.getValue());
		    		        	   }
		    		           ); 
		    		        	 
	                    	   panel.body.on('click', function( evt, target, eOpts ) {
	                    		   var evtXY =evt.getXY();
	                    		   var panXY = panel.getEl().getXY();//panel.getPosition();
	                    		   var xCoord = evtXY[0]-panXY[0];
	                    		   var yCoord = evtXY[1]-panXY[1];
	                    		   
	                    		   var xVal = Math.round(xCoord*100/194,0);
	                    		   var yVal = 100 - Math.round(yCoord*100/194, 0);

	                    		   var colorColumnFields = colorpicker.getComponent('color-columns-bin').getComponent('color-column-fields'); 
	                        	   var coloHSL_H = colorColumnFields.getComponent('coloHSL_H_container').getComponent('coloHSL_H');	     	    	        		  

     	    	        		   var rgb = Ext.ux.ColorField.hsvToRgb({h:coloHSL_H.value,s:xVal,v:yVal});
     	    	        		   var extCol = new Ext.draw.Color(rgb.r,rgb.g,rgb.b);
									
									try{
	     	    	        		   	//var hsl_locator_El = Ext.get(Ext.get(target.id).dom.parentNode.firstChild);
	     	    	        		   	//var hsl_locator_El = Ext.get(Ext.query('#'+panel.id+'-body DIV[class~="xty_hsl_locator"]')[0].id); 
										var hsl_locator_El = Ext.get(hslLocatorId);

										var colorIsDark = Ext.ux.ColorField.isDark(extCol);

										
	     	    	        		   	if (!colorIsDark){
	     	    	        		   		hsl_locator_El.setStyle({color: "black"});
	     	    	        		   		me.colorpicker.removeCls("xty_colorfield-valueIsDark");
	     	    	        		   		me.colorpicker.addCls("xty_colorfield-valueIsLight");
	     	    	        		   		
	     	    	        		   	}
	     	    	        		   	else{
	     	    	        		   		me.colorpicker.removeCls("xty_colorfield-valueIsLight");
	     	    	        		   		me.colorpicker.addCls("xty_colorfield-valueIsDark");
	     	    	        		   		hsl_locator_El.setStyle({color: "white"});
	     	    	        		   	}
	     	    	        		   	
	     	    	        		   	hsl_locator_El.setStyle({top: (yCoord-12)+"px"});
	     	    	        		   	hsl_locator_El.setStyle({left:(xCoord-6)+"px"});
									}
									catch(locatorEx){
										alert("colorfield in dialog locatorEx["+locatorEx+"]\n target is null ?target.id ["+target.id*"]");
									}
     	    	        		   	colorpicker.setColorOnAllFields(extCol, {fromHue:true,fromMap:true});  
	                    	 });
	                    }//eo render     
            		  }// eo listeners
	                 }// eo colorMap
                    ]
	            },
	            
	            {
	                columnWidth:.14,
	                itemId:'color-column-range',
	                border:false,
	                layout: 'hbox',
	                items: [
	                       
	                        {itemId:'colorSlider', xtype:'slider',height:195,  vertical: true,  minValue: 0, maxValue: 359 ,value:comboHSL_H_Val,
	                        	
	                        	listeners:{
	     	    	        	   	
	     	    	        		// triggered also from any other 
	                        		change:function( slider, newValue, thumb, eOpts ){
	                        			
	                        	       // check if slider change comes from user-drag or triggered by another field
	                        			var inCharge = false;
	                        			try{
	                        				var sliderThumb_El = Ext.get(Ext.query('#'+slider.id+' DIV[class~="x-slider-thumb"]')[0]); 
		                        			inCharge = sliderThumb_El.hasCls('x-slider-thumb-over');
	                        			}catch(changeCheckEx){
	                        				alert("color slider Ex "+changeCheckEx);
	                        			}

	                        			if (inCharge){
	 	     	    	        		   var colorColumnFields = this.ownerCt.ownerCt.getComponent('color-column-fields'); 
	                        				
	                        		 	   var tHsv = colorColumnFields.getComponent('coloHSL_H_container').hsv;
		     	    	        		   if (!tHsv){tHsv={s:100,v:100};}
		     	    	        		   var rgb = Ext.ux.ColorField.hsvToRgb({h:this.getValue(),s:tHsv.s,v:tHsv.v});
		     	    	        		   var extCol = new Ext.draw.Color(rgb.r,rgb.g,rgb.b);	     	    	        		   
		     	    	        		   // colorpicker = 
		     	    	        		   this.ownerCt.ownerCt.ownerCt.setColorOnAllFields(extCol, {fromSlider:true});
	                        			}
	     	    	        	   	}
	     	    	        	 }
	                        
	                        },
	                        {
	                        	itemId:'colorRange', xtype:'panel', width:20, height:195,
	                        	html:'<img width="20" height="195" src="'+me.imageBase+'/colorpicker_bar-hue.png" style=" display: block;">',
	                        	
		                        listeners:{
		                        	render: function(panel) {
		                        		
		 		    		           panel.body.on('dblclick', function( evt, target, eOpts ) {
				    		        	   me.setValue("#"+colorpicker.getValue());
				    		        	   }
				    		           ); 
		 		    		           
		                        		panel.body.on('click', function( evt, target, eOpts ) {
				                    		   var evtXY =evt.getXY();
				                    		   var panXY = panel.getPosition();
				                    		   var yCoord = evtXY[1]-panXY[1];
				                    		   var yVal = 359-  Math.round(yCoord*359/194, 0);

								   var colorColumnFields = panel.ownerCt.ownerCt.getComponent('color-column-fields'); 
								   var tHsv = colorColumnFields.getComponent('coloHSL_H_container').hsv;
								   if (!tHsv){tHsv={s:100,v:100};}
								   if (tHsv.h==0  && tHsv.s==0  && tHsv.v==100  ){tHsv.s=100;} // initial white 
								   var rgb = Ext.ux.ColorField.hsvToRgb({h:yVal,s:tHsv.s,v:tHsv.v});
								   var extCol = new Ext.draw.Color(rgb.r,rgb.g,rgb.b);	     	    	        		   
								   panel.ownerCt.ownerCt.ownerCt.setColorOnAllFields(extCol, {frsomSlider:true});

		                        		});
		                        	}	
		                        }
	                        
	                        }]
	            },
	            
	            
	            
	            {
	                columnWidth:.25,
	                itemId:'color-column-fields',
	                border:false,
	                layout: 'anchor',
	                margin:'0 0 0 10',
	                defaultType: 'numberfield',
	    	        defaults: {
	    	           labelWidth:20,
	    	           width:80,
	    	           minValue: 0, 
	    	           maxValue: 255,
	    	           inCharge:false,
	    	           
	    	           listeners:{
	    	        	   focus:function(){this.inCharge=true;},
	    	        	   blur:function(){
	    	        		   this.inCharge=false;
	    	           			if (!me.colorpicker.inCharge){
	    	           				me.colorpicker.hide();
	    	           			}  
	    	        	   },
	    	        	   
	    	               specialkey: function(field, e){
	    	                    if (e.getKey() == e.ENTER) {
	    	                    	 me.setValue("#"+colorpicker.getValue());
	    	                    }
	    	               },
	    	        	   
	    	        	   
	    	        	   change:function(){   
	    	        		  if (this.inCharge){
	    	        			   var cfg={};
	    	        			   var extCol;
	    	        			   // RGB
		    	        		   if (this.itemId.indexOf('colorRGB')>-1){ 
			    	        		   var colR = this.ownerCt.getComponent('colorRGB_R').value;
			    	        		   var colG = this.ownerCt.getComponent('colorRGB_G').value;
			    	        		   var colB = this.ownerCt.getComponent('colorRGB_B').value;  		   
			    	        		   extCol = new Ext.draw.Color(colR, colG, colB);
			    	        		   cfg.fromRGB=true;  
		    	        		   }
		    	        		   // hex
		    	        		   else{
		    	        			   var hexCol =  '#'+this.ownerCt.getComponent('colorHEX').value;
		    	        			   extCol = Ext.draw.Color.fromString(hexCol);
		    	        			   cfg.fromHex=true;
		    	        		   }	
		    	        		   this.ownerCt.ownerCt.ownerCt.setColorOnAllFields(extCol, cfg);
	    	        		  } //eo charge
	    	        	   }// eo change
	    	        	   
	    	           }  
	    	           
	    	        },
	                items: [  
	                        {
	                            xtype: 'fieldcontainer',height:22,
	                            fieldLabel: 'H',
	                            itemId:'coloHSL_H_container',
	                            hsv : hsv,
	                            layout: 'hbox',
	                            items: [
	                                { xtype     : 'numberfield', itemId:'coloHSL_H', maxValue: 359 , minValue:0, hideTrigger:true, flex:1.2 ,value:comboHSL_H_Val,
	    	                        	listeners:{
	    	     	    	        	   	   focus:function(){this.inCharge=true;},
	    	     	    	        	   	   blur:function(){
	    	     	    	        	   		   this.inCharge=false;
	    	     		    	           			if (!me.colorpicker.inCharge){
	    	     		    	           				me.colorpicker.hide();
	    	     		    	           			}    
	    	     	    	        	   	   },
	    	     		    	               specialkey: function(field, e){
	    	     		    	                    if (e.getKey() == e.ENTER) {
	    	     		    	                    	 me.setValue("#"+colorpicker.getValue());
	    	     		    	                    }
	    	     		    	               },
	    		     	    	        	   change:function(){	    		     	    	        		   
	    		     	    	        		  if (this.inCharge){
	    		     	    	        			  
	    		     	    	        			   var tHsv = this.ownerCt.hsv;
	    		     	    	        			   if (!tHsv){tHsv={s:100,v:100};}
	    			     	    	        		   var rgb = Ext.ux.ColorField.hsvToRgb({h:this.getValue(),s:tHsv.s,v:tHsv.v});
	    			     	    	        		   var extCol = new Ext.draw.Color(rgb.r,rgb.g,rgb.b);	     	    	        		   
	    			     	    	        		   this.ownerCt.ownerCt.ownerCt.ownerCt.setColorOnAllFields(extCol, {fromHue:true});    
	    		     	    	        		  }// eo inCharge
	    		     	    	        	   	}// eo change
	    		     	    	        	 }	
	                                
	                                },
	                                { xtype     : 'displayfield', value:'&nbsp;&deg;', width:16}
	                            ]
	                        },
	                        /*
	                        {
	                            xtype: 'fieldcontainer',height:22,
	                            fieldLabel: 'S',
	                            itemId:'coloHSL_S_container',
	                            layout: 'hbox',
	                            items: [
	                                { xtype     : 'numberfield', itemId:'coloHSL_S',  maxValue: 100, hideTrigger:true, flex:1.2  },
	                                { xtype     : 'displayfield', value:'&nbsp;%', width:16}
	                            ]
	                        }, 	                          
	                        {
	                            xtype: 'fieldcontainer',height:22,
	                            fieldLabel: 'L',
	                            itemId:'coloHSL_L_container',
	                            layout: 'hbox',
	                            items: [
	                                { xtype     : 'numberfield', itemId:'coloHSL_L',  maxValue: 100, hideTrigger:true, flex:1.2 },
	                                { xtype     : 'displayfield', value:'&nbsp;%', width:16}
	                            ]
	                        }, 	                        
	                        
	                        /**/
	                        
						{itemId:'colorRGB_R', fieldLabel: 'R', hideTrigger:true, value:comboRVal},
						{itemId:'colorRGB_G',fieldLabel: 'G', hideTrigger:true, value:comboGVal},
						{itemId:'colorRGB_B',fieldLabel: 'B', hideTrigger:true,value:comboBVal},
						{itemId:'colorHEX',xtype:'textfield',fieldLabel: '#', value:comboHexVal.replace(/#/,'')},
						{itemId:'colorVALUE',cls:"xty_colorfield-apply-button", text:this.applyText, style:'margin-top:10px;background:'+comboHexVal+';cursor:hand !important;', mxargin:'10 0 0 0', xtype:'button', width:80, height:  me.allowTransparent?40:60,
						  tooltip:'<div style="margin-top:20px !important;">'+this.applyColorText+'</div>',
							handler:function(){
							  var hexCol =  this.ownerCt.getComponent('colorHEX').value;
			            	  me.setValue('#' + hexCol);
			            	  colorpicker.hide();
						 }	
						},
						{itemId:'transpVALUE', hidden:! me.allowTransparent, style:'background:white;cursor:hand !important;', margin:'2 0 0 0', xtype:'splitbutton', width:80, height:20,
							  
		                    menu: {
                                listeners: {                              	
                                	mouseenter: function(panel) {	 
                    	        		 me.colorpicker.inCharge = true;	
                                	},
				                 	mouseleave: function(panel) {	 
				                 		me.colorpicker.inCharge = false;	 
				                 	}
                                },
		                    	
		                    	
		                        items: [
		                            '-',
		                            Ext.create('Ext.ColorPalette', {
		                                listeners: {
		                                    select: function(cp, color){
		                                    	me.colorpicker.inCharge = true;	 
		                                    	me.colorpicker.setColorOnAllFields(Ext.draw.Color.fromString(color), {fromPalette:true});    
		                                    	me.colorpicker.setValue('#' + color);
		                                    }
		                                }
		                            })
		                        ]
		                    },

							  tooltip:'<div style="margin-top:0px !important;">'+this.applyTransparenceText+'</div>',
								handler:function(){
				            	  me.setValue('transparent');
				            	  colorpicker.hide();
							 }	
							}
					]
	            }// eo color-column-fields
	           ]// eo column items
	        }// eo color-columns-bin

	        ],// eo colorpicker items
	    
	        /**
	         * Returns the chosen value on the colorpicker-Panel
	         * @returns
	         */
	        getValue:function(){	
       		  var colorColumnFields = this.getComponent('color-columns-bin').getComponent('color-column-fields'); 
              var colorHEX = colorColumnFields.getComponent('colorHEX');
              return colorHEX.getValue();	
	        },
	        
	        isDark : function (){return Ext.ux.ColorField.isDark(this.getValue());}
	 

	 });
	 
	       me.colorpicker = colorpicker;  
	       return colorpicker;
	  }
	});



	Ext.ux.ColorField.addStatics({

		/**
		 * Supported formats: '#rrggbb', '#rgb', and 'rgb(r,g,b)'. Eats hex Strings with or without hash and Ext.draw.Color<br>
		 * Proves by Ext.draw.Color.getGrayScale();
		 * @param color
		 * @returns colorIsDark {Boolean}
		 */
	    isDark : function (color){		
			var colorIsDark;
			if (color){
				if (typeof color === 'string'){	
					if (color.indexOf('#')<0 && color.indexOf('rgb') ){
			   			color = '#'+color;
					}
					color = Ext.draw.Color.fromString(color);				
				}
			}
	        var grayscale  = color.getGrayscale();
	        colorIsDark = grayscale < 190;
	 		return colorIsDark;
	 	},
	
	  
	  /**
     * Copied from http://johndyer.name/photoshop-like-javascript-color-picker/
     * @param rgb
     * @returns
     */
    rgbToHsv: function (rgb) {

		var r = rgb.r / 255;
		var g = rgb.g / 255;
		var b = rgb.b / 255;

		hsv = {h:0, s:0, v:0};

		var min = 0;
		var max = 0;

		if (r >= g && r >= b) {
			max = r;
			min = (g > b) ? b : g;
		} else if (g >= b && g >= r) {
			max = g;
			min = (r > b) ? b : r;
		} else {
			max = b;
			min = (g > r) ? r : g;
		}

		hsv.v = max;
		hsv.s = (max) ? ((max - min) / max) : 0;

		if (!hsv.s) {
			hsv.h = 0;
		} else {
			delta = max - min;
			if (r == max) {
				hsv.h = (g - b) / delta;
			} else if (g == max) {
				hsv.h = 2 + (b - r) / delta;
			} else {
				hsv.h = 4 + (r - g) / delta;
			}

			hsv.h = parseInt(hsv.h * 60);
			if (hsv.h < 0) {
				hsv.h += 360;
			}
		}
		
		hsv.s = parseInt(hsv.s * 100);
		hsv.v = parseInt(hsv.v * 100);

		return hsv;
	},
    /**
     * Copied from http://johndyer.name/photoshop-like-javascript-color-picker/
     * @param hsv
     * @returns
     */
    hsvToRgb: function (hsv) {

		rgb = {r:0, g:0, b:0};
		
		var h = hsv.h;
		var s = hsv.s;
		var v = hsv.v;

		if (s == 0) {
			if (v == 0) {
				rgb.r = rgb.g = rgb.b = 0;
			} else {
				rgb.r = rgb.g = rgb.b = parseInt(v * 255 / 100);
			}
		} else {
			if (h == 360) {
				h = 0;
			}
			h /= 60;

			// 100 scale
			s = s/100;
			v = v/100;

			var i = parseInt(h);
			var f = h - i;
			var p = v * (1 - s);
			var q = v * (1 - (s * f));
			var t = v * (1 - (s * (1 - f)));
			switch (i) {
				case 0:
					rgb.r = v;
					rgb.g = t;
					rgb.b = p;
					break;
				case 1:
					rgb.r = q;
					rgb.g = v;
					rgb.b = p;
					break;
				case 2:
					rgb.r = p;
					rgb.g = v;
					rgb.b = t;
					break;
				case 3:
					rgb.r = p;
					rgb.g = q;
					rgb.b = v;
					break;
				case 4:
					rgb.r = t;
					rgb.g = p;
					rgb.b = v;
					break;
				case 5:
					rgb.r = v;
					rgb.g = p;
					rgb.b = q;
					break;
			}

			rgb.r = parseInt(rgb.r * 255);
			rgb.g = parseInt(rgb.g * 255);
			rgb.b = parseInt(rgb.b * 255);
		}

		return rgb;
	}
	
	
	});


/*
 * 
 * $Revision: 1.4 $
 * $Modtime: 12.12.12 16:49 $ 
 * $Date: 2013/09/13 09:36:50 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */

