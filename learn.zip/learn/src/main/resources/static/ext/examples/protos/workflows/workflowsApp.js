
Ext.application({
      name : 'workflows',
      wfStatePanelCfg : null,

      /**
       * Place
       */
      appMode : {},

      
      getContentPanelHeight : function() {
        var me = this;
        return me.getCenterHeight();
      },

      getEditorContentPanelHeight : function() {
        var me = this;
        return me.getCenterHeight({
          hasPagetoolbar : true
        });
      },

      getEditorSubTabHeight : function() {
        var me = this;
        return me.getCenterHeight({
          hasPagetoolbar : true,
          hasSubtabs : true
        });
      },

      getCenterHeight : function(cfg) {
        var centerPan = extVia.regApp.myRaster.getCenter();
        // var centerWidth = centerPan.getWidth()-50;
        var centerHeight = centerPan.getHeight() - 92; // ohne pagetoolbar
        if (cfg && cfg.hasPagetoolbar) {
          centerHeight -= 86;
        }
        if (cfg && cfg.hasSubtabs) {
          // centerHeight-=86;
          var jslintSomething;
        }
        return centerHeight;
      },

      getWestListHeight : function(cfg) {
        var westPan = extVia.regApp.myRaster.getWest();
        var westHeight = westPan.getHeight() - 28; // ohne tabs toolbar + bottombar
        return westHeight;
      },

      onAddbWorkflow : function(button, evt) {
        var me =  button.app;
        var workflowsGrid = null;
        var group = null;
        if (!Ext.isEmpty(button.gridview)) {
          workflowsGrid = button.gridview.ownerCt;
        }else{
          workflowsGrid = button.ownerCt.ownerCt.getComponent("workflowsGrid");
        }
        
        var selected = workflowsGrid.getSelection();
        
        if(!Ext.isEmpty(selected))
        {
          if(selected.selectionTyp === "Group")
          {
            group = selected.group;
          }else{
            group = selected.data.groupEpobType;
          }
        }
        
        me.loadEditor(null, "Workflow", group);
      },

      addWorkflowInHierarchy : function(button, evt) {
        var me = this;
        var group = null;
        if (!Ext.isEmpty(button.app)) {
          me = button.app;
        }

        me.loadEditor(null, "WorkflowInHierarchy");
      },

      onAddbWorkflowResponsiblePerson : function(button, evt) {
        
        var me =  button.app;
        var workflowsGrid = null;
        var group = null;
        if (!Ext.isEmpty(button.gridview)) {
          workflowsGrid = button.gridview.ownerCt;
        }else{
          workflowsGrid = button.ownerCt.ownerCt.getComponent("workflowsGrid");
        }
        
        var selected = workflowsGrid.getSelection();

        if(!Ext.isEmpty(selected))
        {
          if(selected.selectionTyp === "Group")
          {
            group = selected.group;
          }else{
            group = selected.data.groupEpobType;
          }
        }
        
        me.loadEditor(null, "WorkflowResponsiblePerson", group);
      },

      onEditbWorkflow : function(button, evt) {
        var me = this.app;

        var workflowsGrid = null;
        if(!Ext.isEmpty(button.gridview))
        {
          workflowsGrid = button.gridview.ownerCt;
        }else{
          workflowsGrid = button.ownerCt.ownerCt.getComponent('workflowsGrid');
        }
        
        var selection = workflowsGrid.getSelection();
        
        if (!Ext.isEmpty(selection)) {
          me.loadEditor(selection, selection.get("epobType"));
        } else {
          extVia.notify({
            action : '',
            mssg : 'Wähle eine '+extVia.locales.modul+' aus'
          });
        }
      },

      onDeleteWorkflow : function(button, evt) {
        var me = this.app;

        var workflowsGrid = null;
        if(!Ext.isEmpty(button.gridview))
        {
          workflowsGrid = button.gridview.ownerCt;
        }else{
          workflowsGrid = button.ownerCt.ownerCt.getComponent('workflowsGrid');
        }
       
        var selection = workflowsGrid.getSelection();
        if (!Ext.isEmpty(selection)) {
       
          var store = workflowsGrid.store;

          store.remove(selection);
        } else {
          extVia.notify({
            action : '',
            mssg : 'Wähle einen '+extVia.locales.modul+' aus'
          });
        }
      },

      onSave : function(button, evt) {
        var me = button.app;

        var editorPanel = button.ownerCt.ownerCt.ownerCt;
        var masterDataTab = editorPanel.getComponent('editorSubTabsPanel').getComponent('masterDataTab');
        var metadataPanel = masterDataTab.getComponent('metadata');
        var languageArray = metadataPanel.getComponent("languageTherapyPanel").items.items;
        var store = me.workflowsStore;

        if (metadataPanel.getForm().isValid()) {
          
         
          
          var epimId = metadataPanel.getComponent('epimId').value;
          var epobTyp = metadataPanel.getComponent('epobTyp').value;
          var groupEpobTypes = metadataPanel.getComponent('groupEpobTypes').value;
          var name_DE_Obj = metadataPanel.getComponent("languageTherapyFieldContainer").items.items[0];
          var name_DE_old = name_DE_Obj.oldValue;
          var name_DE = name_DE_Obj.value;
          var name_EN = me.getArrayItemFromId(languageArray, "name_EN").value;
          var name_FR = me.getArrayItemFromId(languageArray, "name_FR").value;
          var name_SP = me.getArrayItemFromId(languageArray, "name_SP").value;
          var name_ZH = me.getArrayItemFromId(languageArray, "name_ZH").value;
          var name_TR = me.getArrayItemFromId(languageArray, "name_TR").value;
          var name_KL = me.getArrayItemFromId(languageArray, "name_KL").value;
          var version = metadataPanel.getComponent("version").value;
          var responsible = metadataPanel.getComponent("responsible").rawValue;
          var responsibleOrder = metadataPanel.getComponent("responsibleOrder").value;
          var responsibleComment = metadataPanel.getComponent("responsibleComment").value;
          var status = metadataPanel.getComponent("started").value;
          
         
          
          
          if(status === "Nein"){
            status = "No";
          }
          if(status === "Ja"){
            status = "Yes";
          }
          if(epobTyp !== "Workflow"){
            status = "";
          }
           
          if(name_DE_old !== name_DE)
          {
            store.data.items.forEach(function(ArrayElement) {
              if (ArrayElement.data.name_DE === name_DE_old) {
                ArrayElement.set('name_DE', name_DE);
              }
            });
            name_DE_Obj.setOldValue(name_DE);
          }
          
          var record = null;
          store.data.items.forEach(function(ArrayElement) {
            if (ArrayElement.data.id === epimId) {
              record = ArrayElement;
            }
          });
          
          var startButton = button.ownerCt.getComponent('start');
          startButton.enable();
          
          if (Ext.isEmpty(record)) {
            store.add({
              id : epimId,
              groupEpobType : groupEpobTypes,
              epobType : epobTyp,
              name_DE : name_DE,
              name_EN : name_EN,
              name_FR : name_FR,
              name_SP : name_SP,
              name_ZH : name_ZH,
              name_TR : name_TR,
              name_KL : name_KL,
              version: version,
              status : status,
              responsible : responsible,
              responsibleOrder : responsibleOrder,
              responsibleComment : responsibleComment
            });

            
            var westPan = extVia.regApp.myRaster.getWest();
            var workflowsGrid = westPan.getComponent("panel_mwTabs").getComponent("workflowsList").getComponent("workflowsGrid");
            var grouping = workflowsGrid.features[0];
            grouping.disable();
            grouping.enable();
            
            store.data.items.forEach(function(ArrayElement) {
              if (ArrayElement.data.id === epimId) {
                record = ArrayElement;
              }
            });

            var tab = button.ownerCt.ownerCt.ownerCt;
            var stab = tab.ownerCt;
            
            stab.remove(tab.itemId);
            me.loadEditor(record, record.get("epobType"));
            
            extVia.notify({
              action : '',
              mssg : 'Gespeichert'
            });
          } else {
            record.set('groupEpobType', groupEpobTypes);
            record.set('epobType', epobTyp);
            record.set('name_DE', name_DE);
            record.set('name_EN', name_EN);
            record.set('name_FR', name_FR);
            record.set('name_SP', name_SP);
            record.set('name_ZH', name_ZH);
            record.set('name_TR', name_TR);
            record.set('name_KL', name_KL);
            record.set('version', version);
            record.set('status', status);
            record.set('responsible', responsible);
            record.set('responsibleOrder', responsibleOrder);
            record.set('responsibleComment', responsibleComment);

            extVia.notify({
              action : '',
              mssg : 'Bearbeitet'
            });
          } 
        } else {
          extVia.notify({
            status : "Warning",
            action : '',
            mssg : 'Es wurden nicht alle Pflichtfelder ausgefullt'
          });
        }

      },

      getArrayItemFromId : function(array, id) {
        var item = null;
        array.forEach(function(ArrayElement) {
          if (ArrayElement.itemId === id) {
            item = ArrayElement;
          }
        });
        return item;
      },

      showEditor : function(record) {
        var me = this;

        me.loadEditor(record, record.get("epobType"));
      },

      onNewState : function(button) {
        var me = this.app;
        var editorPanel = button.ownerCt.ownerCt.ownerCt;

        var cfg = {
          title : "Zustand hinzufügen",
          mainInstr : "Zustand hinzufügen",
          isNew : true,
          readOnly : false,
          x : 24,
          y : 89
        };

        me.showStateDialog(editorPanel, cfg);
      },

      onAddState : function(item, evt) {
        var me = this.app;

        var editorPanel = item.ownerCt.floatParent.ownerCt.ownerCt.ownerCt;

        var subTabsPanel = editorPanel.getComponent('editorSubTabsPanel');

        if (subTabsPanel.getActiveTab().itemId === 'stateTab') {

          var wfStatePanel;
          subTabsPanel.items.items.forEach(function(ArrayElement) {
            if (ArrayElement.itemId === "stateTab") {
              wfStatePanel = ArrayElement.getComponent('wfStatePanel');
            }
          });

          wfStatePanel.store.add({
            DE : "",
            EN : "",
            FR : "",
            SP : "",
            ZH : "",
            TR : "",
            KL : "",
            ExportWarning : true
          });

        } else {
          extVia.notify({
            action : '',
            mssg : 'Gehen Sie auf das "Zustände"-Tab'
          });
        }
      },

      onEditState : function(item, evt) {
        var me = this.app;
        var editorPanel = null;

        if (Ext.isEmpty(item.gridview)) {
          editorPanel = item.ownerCt.floatParent.ownerCt.ownerCt.ownerCt;
        } else {
          editorPanel = item.gridview.ownerCt.ownerCt.ownerCt.ownerCt;
        }

        var cfg = {
          title : "Zustand bearbeiten",
          mainInstr : "Zustand bearbeiten",
          isNew : false,
          readOnly : false,
          x : evt.X,
          y : evt.Y
        };

        me.showStateDialog(editorPanel, cfg);
      },

      onDeleteState : function(item, evt) {
        var me = this.app;

        var editorPanel = null;

        if (Ext.isEmpty(item.gridview)) {
          editorPanel = item.ownerCt.floatParent.ownerCt.ownerCt.ownerCt;
        } else {
          editorPanel = item.gridview.ownerCt.ownerCt.ownerCt.ownerCt;
        }

        var subTabsPanel = editorPanel.getComponent('editorSubTabsPanel');

        if (subTabsPanel.getActiveTab().itemId === 'stateTab') {

          var wfStatePanel;
          subTabsPanel.items.items.forEach(function(ArrayElement) {
            if (ArrayElement.itemId === "stateTab") {
              wfStatePanel = ArrayElement.getComponent('wfStatePanel');
            }
          });

          if (!Ext.isEmpty(wfStatePanel.getSelection())) {

            var record = wfStatePanel.getSelection();

            wfStatePanel.store.remove(record);

          } else {
            extVia.notify({
              action : '',
              mssg : 'Wähle einen Zustand aus'
            });
          }
        } else {
          extVia.notify({
            action : '',
            mssg : 'Gehen Sie auf das "Zustände"-Tab'
          });
        }
      },

      showStateDialog : function(editorPanel, cfg) {
        var me = this;
        
        var subTabsPanel = editorPanel.getComponent('editorSubTabsPanel');

        if (subTabsPanel.getActiveTab().itemId === 'stateTab' || cfg.isNew) {

          var wfStatePanel;
          subTabsPanel.items.items.forEach(function(ArrayElement) {
            if (ArrayElement.itemId === "stateTab") {
              wfStatePanel = ArrayElement.getComponent('wfStatePanel');
            }
          });

          if (!Ext.isEmpty(wfStatePanel.getSelection()) || cfg.isNew) {

            var record = null;
            var recordData = {
              DE : "",
              EN : "",
              FR : "",
              SP : "",
              ZH : "",
              TR : "",
              KL : "",
              ExportWarning : true
            };

            
            if (!cfg.isNew) {
              record = wfStatePanel.getSelection();
              
              recordData = {
                DE : record.data.DE,
                EN : record.data.EN,
                FR : record.data.FR,
                SP : record.data.SP,
                ZH : record.data.ZH,
                TR : record.data.TR,
                KL : record.data.KL,
                ExportWarning : record.data.ExportWarning === 'true'

              };

              cfg.mainInstr = 'Zustand "' + recordData.DE + (cfg.readOnly?'" anzeigen':'" bearbeiten');
            }

            var editLanguageDialog = Ext.create('widget.window', {

              width : 520, // extVia.dialoges.dialogDefaultWidth,
              y : 180,

              title : cfg.title,
              plain : true,

              items : [ {
                border : false,
                minHeight : 200,

                itemId : 'myFormPanel',
                xtype : 'form',

                dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
                  var dialogButtons = this.ownerCt.getComponent('myButtons');

                  var activate = dirty;

                },

                fieldDefaults : {
                  msgTarget : 'side'
                },
                defaults : {
                  style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                  anchor : '100%',
                  labelWidth : 150,
                  width : 350,
                  msgTarget : 'side'
                },
                items : [

                extVia.dialoges.getInstructionPanel({
                  mainInstr : cfg.mainInstr
                // suppInstr : ''
                }), {
                  xtype : 'displayfield',
                  value : '<b>Sprachen:</b>'
                },

                {
                  xtype : 'fieldcontainer',
                  fieldLabel : 'Deutsch',
                  // labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                  layout : 'hbox',
                  items : [ {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.DE,
                    name : 'DE',
                    itemId : '1',
                    allowBlank : true,
                    width : 222
                  }, {
                    itemId : 'langsinner',
                    xtype : 'button',
                    margin : '0 0 0 2',
                    tooltip : 'Sprachwerte pflegen',
                    iconCls : 'xty_pgtoolbar-customLanguagesEnable',
                    handler : function(button, evt) {
                      var languageTherapyPanel = button.ownerCt.ownerCt.getComponent('languageTherapyPanel');

                      if (languageTherapyPanel.hidden) {
                        languageTherapyPanel.show();
                      } else {
                        languageTherapyPanel.hide();
                      }
                    }
                  } ]
                }, {
                  xtype : 'panel',
                  itemId : 'languageTherapyPanel',
                  autoScroll : true,
                  height : 150,
                  border : false,
                  hidden : true,
                  defaults : {
                    style : 'margin:0px 10px 0px 0px; padding-bottom:4px;',
                    anchor : '100%',
                    labelWidth : 150,
                    width : 377,
                    msgTarget : 'side'
                  },
                  items : [ {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.EN,
                    name : 'EN',
                    itemId : '2',
                    fieldLabel : 'Englisch',
                    allowBlank : true
                  }, {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.FR,
                    name : 'FR',
                    itemId : '3',
                    fieldLabel : 'Französisch',
                    allowBlank : true
                  }, {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.SP,
                    name : 'SP',
                    itemId : '4',
                    fieldLabel : 'Spanisch',
                    allowBlank : true
                  }, {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.ZH,
                    name : 'ZH',
                    itemId : '5',
                    fieldLabel : 'Chinesisch',
                    allowBlank : true
                  }, {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.TR,
                    name : 'TR',
                    itemId : '6',
                    fieldLabel : 'Turkisch',
                    allowBlank : true
                  }, {
                    xtype : cfg.readOnly?'displayfield':'textfield',
                    value : recordData.KL,
                    name : 'KL',
                    itemId : '7',
                    fieldLabel : 'Klingonisch',
                    allowBlank : true
                  } ]
                }, {
                  xtype : 'displayfield',
                  value : '<br/>'
                }, {
                  xtype : cfg.readOnly?'displayfield':'checkbox',
                  checked : recordData.ExportWarning,
                  value : recordData.ExportWarning?'Ja':'Nein',
                  name : 'ExportWarning',
                  itemId : 'ExportWarning',
                  fieldLabel : '&nbsp;Exportwarnung'
                }

                ]
              } ],

              buttons : {
                itemId : 'myButtons',
                items : [ {
                  xtype : 'tbspacer',
                  width : 70
                }, {
                  itemId : 'btnSave',
                  hidden: cfg.readOnly,
                  text : 'Speichern',
                  disabled : false,
                  handler : function(button, evt) {

                    var formPan = button.up("window").getComponent("myFormPanel");
                    if (formPan) {
                      var values = formPan.getForm().getValues();

                      if (Ext.isEmpty(record)) {
                        wfStatePanel.store.add({
                          DE : values.DE,
                          EN : values.EN,
                          FR : values.FR,
                          SP : values.SP,
                          ZH : values.ZH,
                          TR : values.TR,
                          KL : values.KL,
                          ExportWarning : values.ExportWarning === 'on'
                        });
                      } else {
                        record.data.DE = values.DE;
                        record.data.EN = values.EN;
                        record.data.FR = values.FR;
                        record.data.SP = values.SP;
                        record.data.ZH = values.ZH;
                        record.data.TR = values.TR;
                        record.data.KL = values.KL;
                        record.data.ExportWarning = values.ExportWarning === 'on';

                        wfStatePanel.getView().refresh();
                      }

                      button.up("window").close();
                    }

                  }
                } ]
              }
            }).show();

          } else {
            extVia.notify({
              action : '',
              mssg : 'Wähle einen Zustand aus'
            });
          }
        } else {
          extVia.notify({
            action : '',
            mssg : 'Gehen Sie auf das "Zustände"-Tab'
          });
        }
      },

      onAddTransitionNotification : function(item, evt) {
        var me = item.app;

        var transitionNotificationPanel = null;
        var editorPanel = item.ownerCt.ownerCt.ownerCt;
        var transition = "";
        
        var subTabsPanel = editorPanel.getComponent('editorSubTabsPanel');

        if (subTabsPanel.getActiveTab().itemId === 'transitionNotificationTab') {
          subTabsPanel.items.items.forEach(function(ArrayElement) {
            if (ArrayElement.itemId === "transitionNotificationTab") {
              transitionNotificationPanel = ArrayElement.getComponent('transitionNotificationPanel');
              var selectedItem = transitionNotificationPanel.getSelection();
              if(!Ext.isEmpty(selectedItem) && !Ext.isEmpty(selectedItem.group)){
                transition = selectedItem.group;
              }
            } 
          });
        }else{
          subTabsPanel.items.items.forEach(function(ArrayElement) {
            if (ArrayElement.itemId === "transitionNotificationTab") {
              transitionNotificationPanel = ArrayElement.getComponent('transitionNotificationPanel');
            }
          });
        }
        
        var cfg = {
          isNew : true,
          id : Ext.id(),
          groupEpobType : editorPanel.editorData.groupEpobType,
          transition : transition,
          notificationRecipientName : "",
          notificationRecipientTyp : "",
          subject_DE : "",
          message_DE : "",
          isJoblist_Active : true,
          isEMail_Active : true
        };

        me.showtransitionNotificationDialog(transitionNotificationPanel, cfg);

      },

      onDeleteTransitionNotification : function(item, evt) {
        var me = item.app;

        var transitionNotificationPanel = null;

        if (!Ext.isEmpty(item.gridview)) {
          transitionNotificationPanel = item.gridview.ownerCt;
        } else {

          var editorPanel = item.ownerCt.floatParent.ownerCt.ownerCt.ownerCt;

          var subTabsPanel = editorPanel.getComponent('editorSubTabsPanel');

          if (subTabsPanel.getActiveTab().itemId === 'transitionNotificationTab') {

            subTabsPanel.items.items.forEach(function(ArrayElement) {
              if (ArrayElement.itemId === "transitionNotificationTab") {
                transitionNotificationPanel = ArrayElement.getComponent('transitionNotificationPanel');
              }
            });
          } else {
            extVia.notify({
              action : '',
              mssg : 'Gehen Sie auf das "Übergangsbenachrichtigung"-Tab'
            });
            return;
          }
        }

        if (Ext.isEmpty(transitionNotificationPanel.getSelection())) {
          extVia.notify({
            action : '',
            mssg : 'Wähle einene Übergangsbenachrichtigung aus'
          });
          return;
        }

        var selectedItem = transitionNotificationPanel.getSelection();

        transitionNotificationPanel.store.remove(selectedItem);

      },

      onDeleteAllNotificationOfATransition : function(item, evt) {
        var me = item.app;

        var transitionNotificationPanel = item.gridview.ownerCt;
        var notificationArray = item.gridview.getStore().getGroups(item.transition).children;

        notificationArray.forEach(function(ArrayElement) {
          transitionNotificationPanel.store.remove(ArrayElement);
        });
      },

      showtransitionNotificationDialog : function(transitionNotificationPanel, cfg) {
        var me = this;

        var title = "Benachrichtigung hinzufügen";
        if (!cfg.isNew) {
          title = 'Benachrichtigung bearbeiten';
        }
        var displayTransitionCombo = false;
        if (cfg.transition === '') {
          displayTransitionCombo = true;
        }

        var userXtype = 'displayfield';
        if (cfg.notificationRecipientName === '') {
          userXtype = 'combo';
        }
  
      

        var receiverStore = Ext.create('Ext.data.Store', {
            model: Ext.define('Receiver', {
              extend: 'Ext.data.Model',
              fields: [{type: 'string', name: 'epob'},
                       {type: 'string', name: 'name'}]
            }),
            storeId:'ReceiverStore',
            data: [
                  {id: 'Administrator ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Administrator', epob:extVia.enums.EpimObjects.ROLE.key},  
                  {id: 'Entwickler ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Entwickler', epob:extVia.enums.EpimObjects.ROLE.key},  
                  {id: 'Support ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Support', epob:extVia.enums.EpimObjects.ROLE.key},  
                  {id: 'Vertrieb ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Vertrieb', epob:extVia.enums.EpimObjects.ROLE.key},  
                  {id: 'Student ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Student', epob:extVia.enums.EpimObjects.ROLE.key},  
                  {id: 'Geschäftsführer ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Geschäftsführer', epob:extVia.enums.EpimObjects.ROLE.key},  
                  {id: 'Hausmeister ('+extVia.enums.EpimObjects.ROLE.key+")", name: 'Hausmeister', epob:extVia.enums.EpimObjects.ROLE.key},  
                  
                  {id: 'Administrator ('+extVia.enums.EpimObjects.USERGROUP.key+")", name: 'Administrator', epob:extVia.enums.EpimObjects.USERGROUP.key},  
                  {id: 'Entwickler ('+extVia.enums.EpimObjects.USERGROUP.key+")", name: 'Entwickler', epob:extVia.enums.EpimObjects.USERGROUP.key},  
                  {id: 'Support ('+extVia.enums.EpimObjects.USERGROUP.key+")", name: 'Support', epob:extVia.enums.EpimObjects.USERGROUP.key},  
                  {id: 'Vertrieb ('+extVia.enums.EpimObjects.USERGROUP.key+")", name: 'Vertrieb', epob:extVia.enums.EpimObjects.USERGROUP.key},  
                  {id: 'Student ('+extVia.enums.EpimObjects.USERGROUP.key+")", name: 'Student', epob:extVia.enums.EpimObjects.USERGROUP.key},  
                  
                  {id: 'Doug Engelbart ('+extVia.enums.EpimObjects.USER.key+")", name:'Doug Engelbart',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Dieter Rams ('+extVia.enums.EpimObjects.USER.key+")", name:'Dieter Rams',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Bernard Purdie ('+extVia.enums.EpimObjects.USER.key+")", name:'Bernard Purdie',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Nina Simone ('+extVia.enums.EpimObjects.USER.key+")",name:'Nina Simone',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Douglas Crockford ('+extVia.enums.EpimObjects.USER.key+")",name:'Douglas Crockford',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Jesse James Garret ('+extVia.enums.EpimObjects.USER.key+")",name:'Jesse James Garret',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Clemens Lutsch ('+extVia.enums.EpimObjects.USER.key+")",name:'Clemens Lutsch',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Steve Krug ('+extVia.enums.EpimObjects.USER.key+")",name:'Steve Krug',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Werner T.Kuestenmacher ('+extVia.enums.EpimObjects.USER.key+")",name:'Werner T.Kuestenmacher',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Lothar J. Seiwert ('+extVia.enums.EpimObjects.USER.key+")",name:'Lothar J. Seiwert',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Esther Derby ('+extVia.enums.EpimObjects.USER.key+")",name:'Esther Derby',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Marissa Mayer ('+extVia.enums.EpimObjects.USER.key+")",name:'Marissa Mayer',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Gunther Dueck ('+extVia.enums.EpimObjects.USER.key+")",name:'Gunther Dueck',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Lars Hinrichs ('+extVia.enums.EpimObjects.USER.key+")",name:'Lars Hinrichs',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Jason Dorsey ('+extVia.enums.EpimObjects.USER.key+")",name:'Jason Dorsey',epob:extVia.enums.EpimObjects.USER.key}, 
                  {id: 'Stanislaw Lem ('+extVia.enums.EpimObjects.USER.key+")",name:'Stanislaw Lem',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Oscar Wilde ('+extVia.enums.EpimObjects.USER.key+")",name:'Oscar Wilde',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Luisa Francia ('+extVia.enums.EpimObjects.USER.key+")",name:'Luisa Francia',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Susanne Fischer-Rizzi ('+extVia.enums.EpimObjects.USER.key+")",name:'Susanne Fischer-Rizzi',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Klausbernd Vollmar ('+extVia.enums.EpimObjects.USER.key+")",name:'Klausbernd Vollmar',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Lisa Kekaula ('+extVia.enums.EpimObjects.USER.key+")",name:'Lisa Kekaula',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Ringo Starr ('+extVia.enums.EpimObjects.USER.key+")",name:'Ringo Starr',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Gene Krupa ('+extVia.enums.EpimObjects.USER.key+")",name:'Gene Krupa',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Phil Rudd ('+extVia.enums.EpimObjects.USER.key+")",name:'Phil Rudd',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Peter Criss ('+extVia.enums.EpimObjects.USER.key+")",name:'Peter Criss',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'John Bonham ('+extVia.enums.EpimObjects.USER.key+")",name:'John Bonham',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Keith Moon ('+extVia.enums.EpimObjects.USER.key+")",name:'Keith Moon',epob:extVia.enums.EpimObjects.USER.key},
                  {id: 'Bill Ward ('+extVia.enums.EpimObjects.USER.key+")",name:'Bill Ward',epob:extVia.enums.EpimObjects.USER.key}
               ],
            groupField : 'epob',
            sorters : [ 'epob', 'name', 'name_DE'],
            filter: Ext.emptyFn,
            clearFilter: Ext.emptyFn,
            filterEpob: function (epob) {
              Ext.data.Store.prototype.clearFilter.call(this);
              
               if(epob !== "All"){
                  Ext.data.Store.prototype.filter.call(this, 'epob', new RegExp(epob+"$"));
               }
            }
        });  
        this.receiverStore = receiverStore;
        
        var dialogWindow = Ext.create('widget.window', {
          width : 520,// extVia.dialoges.dialogDefaultWidth,
          y : 180,

          title : title,
          plain : true,

          items : [ {
            border : false,
            minHeight : 200,

            itemId : 'myFormPanel',
            xtype : 'form',

            dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
              var dialogButtons = this.ownerCt.getComponent('myButtons');

              var activate = dirty;

            },

            fieldDefaults : {
              msgTarget : 'side'
            },
            defaults : {
              style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
              anchor : '100%',
              labelWidth : 150,
              width : 350,
              msgTarget : 'side'
            },
            items : [

            extVia.dialoges.getInstructionPanel({
              mainInstr : 'Benachrichtigung für den Übergang <i>' + cfg.transition + '</i>'
            // suppInstr : ''
            }), {
              fieldLabel : 'Übergang',
              xtype : 'combo',
              hidden : !displayTransitionCombo,
              itemId : "transition",
              name : 'transition',
              allowBlank : false,
              value : cfg.transition,
              labelSeparator : ':<span class="xty_requiredStar"> *</span>',
              store : me.gettransitionNotificationDescription(),
              listeners : {
                validitychange : function( view, isValid, eOpts ){
                  if(!Ext.isEmpty(view.ownerCt)){
                    view.ownerCt.doLayout();
                  }
                }
              }
            }, {
              fieldLabel : 'Empfänger',
              xtype : 'boxselect',
              itemId : "NotificationRecipientName",
              name : 'NotificationRecipientName',
              multiSelect : true,
              allowBlank : true,
              lazyInit: false,
              queryMode : 'local',
              displayField : 'id',
              trigger2Cls : 'xty_form-string-trigger',
              onTrigger2Click:function(evt){
                Ext.create('Ext.menu.Menu', {
                  items : [ {
                    text : 'Alle',
                    handler :  function(view){ view.boxselect.fireEvent('onFilter', 'All'); },
                    iconCls : 'xty_form-string-trigger',
                    boxselect : this
                  },{
                    text : 'Rolle',
                    handler :  function(view){ view.boxselect.fireEvent('onFilter', 'Role'); },
                    iconCls : 'xty_epobRole',
                    boxselect : this
                  }, {
                    text : 'Benutzer',
                    handler :  function(view){ view.boxselect.fireEvent('onFilter', 'User'); },
                    iconCls : 'xty_epobUser',
                    hidden: false,
                    boxselect : this
                  },{
                    text : 'Benutzergruppe',
                    handler :  function(view){ view.boxselect.fireEvent('onFilter', 'Usergroup'); },
                    iconCls : 'xty_epobUsergroup',
                    hidden: false,
                    boxselect : this
                  },{
                    text : 'Verantwortlicher',
                    handler :  function(view){ view.boxselect.fireEvent('onFilter', 'WorkflowResponsiblePerson'); },
                    iconCls : 'xty_epobWorkflowResponsiblePerson',
                    hidden: false,
                    boxselect : this
                  } ]
                }).showAt(evt.getXY());
               },
              
              value : cfg.notificationRecipientName.toString().replace(/,/g, ", "),
              labelSeparator : ':<span class="xty_requiredStar"> *</span>',
              store : receiverStore,
              listeners : {
                onFilter : function (value){
                  var me = this;
                  me.store.filterEpob(value);
                  
                  var el = me.triggerEl.elements[1]; 
                  el.removeCls('xty_form-string-trigger');
                  el.removeCls('xty_form-Role-trigger');
                  el.removeCls('xty_form-User-trigger');
                  el.removeCls('xty_form-Usergroup-trigger');
                  el.removeCls('xty_form-WorkflowResponsiblePerson-trigger');
                  
                  if(value === "All"){
                    el.addCls('xty_form-string-trigger');
                  }else{
                    el.addCls('xty_form-'+value+'-trigger');
                  }
                },
              
                afterrender : function(view, eOpts) {
                  view.allowBlank = false;
                  
                  me.workflowsStore.data.items.forEach(function(ArrayElement) {
                    if(ArrayElement.data.epobType === "WorkflowResponsiblePerson" && ArrayElement.data.groupEpobType.toString() === cfg.groupEpobType.toString()){
                      view.store.add({id: ArrayElement.data.name_DE + " ("+extVia.enums.EpimObjects.WF_RESPONSIBLEPERSON.key+")", name: ArrayElement.data.name_DE, epob:extVia.enums.EpimObjects.WF_RESPONSIBLEPERSON.key});
                    }
                  });
                },
                
                select : function(view){
                  view.ownerCt.doLayout();
                  view.collapse();
                  view.onTriggerClick();
                },
                
                beforedeselect : function( view, isDirty, eOpts ){
                  if(!Ext.isEmpty(view.ownerCt)){
                    view.ownerCt.doLayout();
                  }
                 
                  view.collapse();
                  view.onTriggerClick();
                },
                
                validitychange : function( view, isValid, eOpts ){
                  if(!Ext.isEmpty(view.ownerCt)){
                    view.ownerCt.doLayout();
                  }
                }
              },
              listConfig : {
                 minWidth:200,
                maxHeight:200,
                itemTpl:'<div style="width:100%;padding-left:16px;" title="{value}" class="xty_epob{epob}">' + '&nbsp; {name} </div>' // + '<span style="color:#ccc;">&nbsp;<small>({epob})</small></span></div>'
              }
            },

            {
              xtype : 'tbspacer',
              height : 8
            },
            
//              {
//              fieldLabel : 'Betreff',
//              xtype : 'textfield',
//              itemId : "subject",
//              name : 'subject',
//              value : cfg.subject
//            }, {
//              xtype : 'textareafield',
//              name : 'message',
//              itemId : 'message',
//              fieldLabel : 'Nachricht',
//              height : 36,
//              anchor : '100%',
//              labelSeparator : ':<span class="xty_requiredStar"> *</span>',
//              value : cfg.message,
//              autoScroll : true,
//              allowBlank : false
//            },
            
 {
              xtype : 'checkboxgroup',
              columns : 2,
              vertical : true,
              fieldLaabel : 'Sendekanal',
              hideEmptyLasbel : false,
              items : [ {
                xtype : 'checkbox',
                name : 'Joblist_Active',
                itemId : 'Joblist_Active',
                labelWidth : 150,
                hideEmptyLabel : false,
                boxLabel : 'Joblisteneintrag',
                checked : cfg.isJoblist_Active,
                allowBlank : true
              }, {
                xtype : 'checkbox',
                name : 'Mail_Active',
                itemId : 'Mail_Active',
                labelWidth : 70,
                hideEmptyLabel : false,
                boxLabel : 'E-Mail',
                checked : cfg.isEMail_Active,
                allowBlank : true
              } ]
            }

            ]
          },// eo defaultForm
          
          {xtype:'form', itemId:'languages',  // better itemId:'messages',
          border:false,  
           
           //height:220, 
           
           
           autoScroll:true,
          
          defaults : {
              style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
              anchor : '100%',
              labelWidth : 150,
              width : 350,
              hidden:true,
              msgTarget : 'side'
            },
          
          items:[

          
            { xtype: 'textfield', fieldLabel: 'Betreff (de)', itemId: "Subject_DE", name: 'Subject_DE', margin:'10 10 0 14',  value : cfg.subject_DE, hidden:false}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (de)',labelSeparator : ':<span class="xty_requiredStar"> *</span>',  value : cfg.message_DE,  allowBlank:false, itemId: 'Message_DE', name: 'Message_DE', height : 36,anchor : '100%',  hidden:false, autoScroll : true  },
          
            { xtype: 'textfield', fieldLabel: 'Betreff (en)', itemId: "subject_en", name: 'subject_en', margin:'10 10 0 14'}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (en)', itemId: 'message_en', name: 'message_en', height : 36,anchor : '100%', autoScroll : true },
            { xtype: 'textfield', fieldLabel: 'Betreff (fr)', itemId: "subject_fr", name: 'subject_fr', margin:'10 10 0 14'}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (fr)', itemId: 'message_fr', name: 'message_fr', height : 36,anchor : '100%', autoScroll : true },
            { xtype: 'textfield', fieldLabel: 'Betreff (it)', itemId: "subject_it", name: 'subject_it', margin:'10 10 0 14'}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (it)', itemId: 'message_it', name: 'message_it', height : 36,anchor : '100%', autoScroll : true },            
            { xtype: 'textfield', fieldLabel: 'Betreff (sp)', itemId: "subject_sp", name: 'subject_sp', margin:'10 10 0 14'}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (sp)', itemId: 'message_sp', name: 'message_sp', height : 36,anchor : '100%', autoScroll : true },              
            { xtype: 'textfield', fieldLabel: 'Betreff (pl)', itemId: "subject_pl", name: 'subject_pl', margin:'10 10 0 14'}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (pl)', itemId: 'message_pl', name: 'message_pl', height : 36,anchor : '100%', autoScroll : true },            
            { xtype: 'textfield', fieldLabel: 'Betreff (ro)', itemId: "subject_ro", name: 'subject_ro', margin:'10 10 0 14'}, 
            { xtype: 'textareafield', fieldLabel : 'Nachricht (ro)', itemId: 'message_ro', name: 'message_ro', height : 36,anchor : '100%', autoScroll : true },
           
           {xtype : 'tbspacer', height : 10}
          ]},

          
        {xtype:'form', itemId:'addLanguage-bin', border:false,            
          defaults : {
              style : 'margin:4px 10px 2px 14px; padding-bottom:4px;',
              anchor : '100%',
              labelWidth : 150,
              width : 350
            },
          items:[
          
          
          {xtype:'fieldcontainer', itemId:'addLanguage-btn-bin',  hideEmptyLabel: false, layout:'hbox',
             items:[
             

             
//                          {
//                        
//                            xtype:'combo',rowspan:2, margin:'-27 0 0 5', 
//                            itemId:'language',
//                            emptyText:'Sprachen ',
//                            overCls:'xty_btnlike-combo-over',
//                            width: 53,
//                            pickerOfafset : [10, -1], // rechts
//                            store:extVia.stores.initLanguageStore(), queryMode: 'local',displayField: 'dscr',  valueField: 'iso2',
//                            cls:'xty_btnlike-combo',
//                            triggerCls:'xty_form-splitbtn-trigger',
//  
//                            listeners:{
//                            afterrender : function(combo, newValue, oldValue) {
//                              // readonly: we must prevent user typing
//                              // but we needed input visible for boundlist key events
//                              this.inputEl.dom.setAttribute('readonly','true'); 
//                                var comboEl = combo.getEl(); 
//                                comboEl.on('mousedown', function(evt, target){
//                                  combo.addCls('xty_pressed xty_btnlike-combo-pressed');
//                                });
//                                comboEl.on('mouseup', function(){
//                                  combo.removeCls('xty_pressed xty_btnlike-combo-pressed');
//                                });                              
//
//    
//                              var triggerEl = this.triggerEl;
//                                  this.inputEl.on('click', function(evt, target){
//                                    // triggerEl is an CompositeElement holding all multi triggers
//                                    triggerEl.elements[1].dom.click();
//                                  });
//
//                               comboEl.setTooltip = function(tip){
//                               if (!comboEl.tip) {
//                                 tip = Ext.create('Ext.tip.ToolTip', {target: comboEl, html: tip });
//                                 comboEl.tip = tip;
//                                }
//                               else{
//                                comboEl.tip.update(tip);    
//                               }
//                              };
//                             }
//                            
//                            },
//
//                            name: 'language',
//                                listConfig : {
//                                   minWidth:210,
//                                   componentCls :'xty_boundlist-floating-offset',
//                                   getInnerTpl : function() {
//                                      var tpl = '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
//                                      return tpl;
//                               }
//                                  }
//                        },
             
             
             
             
             
             
             
             
             
             
             
             
             
              {xtype:'splitbutton',  itemId: 'addLanguage',tooltip:'Sprachvariante hinzufügen', iconCls:'xty_formbutton-addLanguage', wisdth:24,
              
              handler: function(button){
                var languagesForm= button.ownerCt.ownerCt.ownerCt.getComponent('languages');
                
                var en = languagesForm.getComponent('subject_en');
                var fr = languagesForm.getComponent('subject_fr');
                var it = languagesForm.getComponent('subject_it');
                var sp = languagesForm.getComponent('subject_sp');
                var pl = languagesForm.getComponent('subject_pl');
                var ro = languagesForm.getComponent('subject_ro');                
                
                if (!en.isVisible()){
                 en.show(); languagesForm.getComponent('message_en').show(); en.focus();
                }
                else if (!fr.isVisible()){
                 fr.show(); languagesForm.getComponent('message_fr').show(); fr.focus();
                }
                else if (!it.isVisible()){
                 it.show(); languagesForm.getComponent('message_it').show(); it.focus();
                }               
                else if (!sp.isVisible()){
                 sp.show(); languagesForm.getComponent('message_sp').show(); sp.focus();
                }                
                else if (!pl.isVisible()){
                 pl.show(); languagesForm.getComponent('message_pl').show(); pl.focus();
                }                
                else if (!ro.isVisible()){
                 ro.show(); languagesForm.getComponent('message_ro').show(); languagesForm.getComponent('message_ro').focus();
                 languagesForm.setHeight(440);
                 ro.focus();
                }
              }
              
              },
              
	            { xtype: 'buttongroup',  itemId: "languagesMerker-btngrp", cls:'xty_flag-btn-grp', name: 'languagesMerker-btngrp', margin:'0 0 0 '+112, frame:false,
	              defaults:{xtype:'button', enableToggle: true, border:false, osverCls:'off',    cls:'xty_formbutton-flag', tooltip:'pin Language'},items: [  
	                {iconCls:'xty_icon_de  xty_icon_deu xty_icon_deu_DEU', pressed:true, tooltip:'Deutsch immer Anzeigen'},  {iconCls:'xty_icon_en'}, {iconCls:'xty_icon_fr'}
	              ]}
               
             ]
            }
          ]}
          
          ],

          buttons : {
            itemId : 'myButtons',
            items : [ {
              xtype : 'tbspacer',
              width : 70
            }, {
              itemId : 'btnSave',
              text : 'Übernehmen',
              disabled : false,
              handler : function(button, evt) {
                var formPan = button.up("window").getComponent("myFormPanel");
                var languagesform = button.up("window").getComponent("languages");
                
                if (formPan) {

                  var form = formPan.getForm();

                  var formIsValid = form.isValid();
                  var languagesformIsValid = languagesform.getForm().isValid();
                  
                  if (!formIsValid || !languagesformIsValid) {
                    extVia.notify({
                      action : '',
                      mssg : 'Überprüfen Sie die Eingabe'
                    });
                    return;
                  }
                  
                  var NotificationRecipientArray = form.getFields().items[1].lastSelection;
                  var NotificationRecipientTyp = NotificationRecipientArray[0].data.epob;
                  if(NotificationRecipientArray.length > 1)
                  {
                    NotificationRecipientTyp = extVia.enums.EpimObjects.USERGROUP.key; 
                  }
                  
                  
                  var values = form.getValues();
                  var languagesValues = languagesform.getValues();
                    
                  if (values.Joblist_Active === "on") {
                    values.Joblist_Active = "Checked";
                  } else {
                    values.Joblist_Active = "";
                  }
                  if (values.Mail_Active === "on") {
                    values.Mail_Active = "Checked";
                  } else {
                    values.Mail_Active = "";
                  }

                  if (cfg.isNew) {
                    transitionNotificationPanel.store.add({
                      id : cfg.id,
                      Transition : values.transition,
                      NotificationRecipientName : values.NotificationRecipientName,
                      NotificationRecipientTyp : NotificationRecipientTyp,
                      Subject_DE : languagesValues.Subject_DE,
                      Message_DE : languagesValues.Message_DE,
                      Joblist_Active : values.Joblist_Active,
                      EMail_Active : values.Mail_Active
                    });
                  } else {
                    var record = transitionNotificationPanel.getSelection();
                    
                    record.set("NotificationRecipientName", values.NotificationRecipientName);
                    record.set("NotificationRecipientTyp", NotificationRecipientTyp);
                    record.set("Subject_DE", languagesValues.Subject_DE);
                    record.set("Message_DE", languagesValues.Message_DE);
                    record.set("Joblist_Active", values.Joblist_Active);
                    record.set("EMail_Active", values.Mail_Active);

                    transitionNotificationPanel.getView().refresh();
                  }

                  button.up("window").close();
                }

              }
            } ]
          }
        }).show();
      },

      showTransferTransitionNotificationDialog : function(item) {
        var me = this.app;

        var xTypeTransitionSource = 'combo';
        var xTypeTransitionTarget = 'combo';

        var dialogWindow = Ext.create('widget.window', {

          width : 520,// extVia.dialoges.dialogDefaultWidth,
          y : 180,

          title : 'Kopieren',
          plain : true,

          items : [ {
            border : false,
            minHeight : 200,

            itemId : 'myFormPanel',
            xtype : 'form',

            dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
              var dialogButtons = this.ownerCt.getComponent('myButtons');

              var activate = dirty;

            },

            fieldDefaults : {
              msgTarget : 'side'
            },
            defaults : {
              style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
              anchor : '100%',
              labelWidth : 150,
              width : 350,
              msgTarget : 'side'
            },
            items : [

            extVia.dialoges.getInstructionPanel({
              mainInstr : 'Kopieren'
            // suppInstr : 'Kopieren Sie alle Benachrichtigungen von einem Übergang zu einem anderen.'
            }), {
              fieldLabel : 'Von',
              xtype : xTypeTransitionSource,
              itemId : "transitionSource",
              name : 'transitionSource',
              allowBlank : false,
              value : item.transition,
              labelSeparator : ':<span class="xty_requiredStar"> *</span>',
              store : me.gettransitionNotificationDescription()
            }, {
              xtype : 'tbspacer',
              height : 18
            }, {
              fieldLabel : 'Zu',
              xtype : xTypeTransitionTarget,
              itemId : "transitionTarget",
              name : 'transitionTarget',
              allowBlank : false,
              value : item.transition,
              labelSeparator : ':<span class="xty_requiredStar"> *</span>',
              store : me.gettransitionNotificationDescription()
            }, {
              xtype : 'tbspacer',
              height : 18
            }, {
              xtype : 'checkbox',
              name : 'RemoveOldData',
              itemId : 'RemoveOldData',
              labelWidth : 150,
              hideEmptyLabel : false,
              boxLabel : 'Alte Benachrichtigungen überschreiben/entfernen',
              checked : false,
              allowBlank : true
            }, {
              xtype : 'tbspacer',
              height : 10
            }

            ]
          } ],

          buttons : {
            itemId : 'myButtons',
            items : [ {
              xtype : 'tbspacer',
              width : 70
            }, {
              itemId : 'btnSave',
              text : 'Starten',
              disabled : false,
              handler : function(button, evt) {

                var formPan = button.up("window").getComponent("myFormPanel");

                var form = formPan.getForm();
                if (formPan) {
                  var values = form.getValues();

                  if (values.transitionSource === values.transitionTarget) {
                    extVia.notify({
                      action : '',
                      mssg : 'Die Benachrichtigungen können nicht an den eigenen Übergang geschickt werden'
                    });
                    return;
                  }
                  if (!form.isValid()) {
                    extVia.notify({
                      action : '',
                      mssg : 'Überprüfen Sie die Eingabe'
                    });
                    return;
                  }
                  var transitionNotificationPanel = item.gridview.ownerCt;

                  var SourceNotificationArray = [];
                  var targetNotificationArray = [];

                  if (!Ext.isEmpty(item.gridview.getStore().getGroups(values.transitionSource))) {
                    SourceNotificationArray = item.gridview.getStore().getGroups(values.transitionSource).children;
                  }
                  if (!Ext.isEmpty(item.gridview.getStore().getGroups(values.transitionTarget))) {
                    targetNotificationArray = item.gridview.getStore().getGroups(values.transitionTarget).children;
                  }

                  if (values.RemoveOldData === 'on') {
                    targetNotificationArray.forEach(function(ArrayElement) {
                      transitionNotificationPanel.store.remove(ArrayElement);
                    });
                  }

                  SourceNotificationArray.forEach(function(ArrayElement) {

                    var isDoAdd = true;
                    if (values.RemoveOldData !== 'on') {
                      targetNotificationArray.forEach(function(targetArrayElement) {
                        if (targetArrayElement.data.NotificationRecipientName.toString() === ArrayElement.data.NotificationRecipientName.toString()) {
                          isDoAdd = false;
                        }
                      });
                    }

                    if (isDoAdd) {
                      transitionNotificationPanel.store.add({
                        id : Ext.id(),
                        Transition : values.transitionTarget,
                        NotificationRecipientName : ArrayElement.data.NotificationRecipientName,
                        NotificationRecipientTyp : ArrayElement.data.NotificationRecipientTyp,
                        Subject_DE : ArrayElement.data.Subject_DE,
                        Message_DE : ArrayElement.data.Message_DE,
                        Joblist_Active : ArrayElement.data.Joblist_Active,
                        EMail_Active : ArrayElement.data.EMail_Active
                      });
                    }
                  });

                  button.up("window").close();
                }

              }
            } ]
          }
        }).show();
      },

      showtransitionNotificationDialog2 : function(editorPanel, cfg) {
        var me = this;

        var editLanguageDialog = Ext.create('widget.window', {

          width : 520,// extVia.dialoges.dialogDefaultWidth,
          y : 180,

          title : "Übergänge",
          plain : true,

          items : [ {
            border : false,
            minHeight : 200,

            itemId : 'myFormPanel',
            xtype : 'form',

            dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
              var dialogButtons = this.ownerCt.getComponent('myButtons');

              var activate = dirty;

            },

            fieldDefaults : {
              msgTarget : 'side'
            },
            defaults : {
              style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
              anchor : '100%',
              labelWidth : 150,
              width : 350,
              msgTarget : 'side'
            },
            items : [

            extVia.dialoges.getInstructionPanel({
              mainInstr : 'Übergangsbenachrichtigung hinzufügen'
            // suppInstr : ''
            }), {

              fieldLabel : 'Übergang',
              xtype : 'combo',
              itemId : "Transition",
              name : 'DescriptionName',
              queryMode : 'DescriptionName',
              displayField : 'DescriptionName',
              valueField : 'DescriptionName',
              allowBlank : false,
              labelSeparator : ':<span class="xty_requiredStar"> *</span>'
              
            }, {
              fieldLabel : 'Empfänger',
              xtype : 'combo',
              itemId : "user",
              name : 'user',
              queryMode : 'local',
              displayField : 'name',
              valueField : 'value',
              allowBlank : false,
              labelSeparator : ':<span class="xty_requiredStar"> *</span>',
              store : extVia.stores.initUserStore()
            },

            {
              xtype : 'tbspacer',
              height : 8
            },

            {
              xtype : 'checkbox',
              // value : recordData.EN,
              name : 'Joblist_Active',
              itemId : 'Joblist_Active',

              fieldLabel : '<b>Joblisteneintrag</b>',
              boxLabel : 'hinzufügen',
              allowBlank : true,
              handlXer : function(button, evt) {
                var Joblist_Comment = button.ownerCt.getComponent('joblistPanel').getComponent('Joblist_Comment');
                Joblist_Comment.setDisabled(!Joblist_Comment.disabled);
              }
            },

            {
              xtype : 'tbspacer',
              height : 4
            },

            {
              xtype : 'panel', hidden:true,
              itemId : 'joblistPanel',
              autoScroll : true,
              border : false,
              hidXden : true,
              defaults : {
                style : 'margin:0px 10px 0px 0px; padding-bottom:4px;',
                anchor : '100%',
                labelWidth : 150,
                width : 483,
                msgTarget : 'side'
              },
              items : [ {
                xtype : 'textareafield',
                // value : recordData.EN,
                name : 'Joblist_Comment',
                itemId : 'Joblist_Comment',
                fieldLabel : 'Text',
                // emptyText : 'Bemerkung',
                height : 36,
                anchor : '100%',
                autoScroll : true,
                // height: 30,
                disabled : true,
                allowBlank : true
              } ]
            }, {
              xtype : 'checkbox',
              // value : recordData.EN,
              name : 'EMail_Active',
              itemId : 'EMail_Active',

              fieldLabel : '<b>E-Mail</b>',
              boxLabel : 'senden',
              allowBlank : true,
              haXndler : function(button, evt) {

                var emailPanel = button.ownerCt.getComponent('emailPanel');

                if (emailPanel.hidden) {
                  emailPanel.show();
                } else {
                  emailPanel.hide();
                }
              }
            }, {
              xtype : 'panel',
              itemId : 'emailPanel',
              autoScroll : true,
              border : false,
              hidXden : true,
              defaults : {
                style : 'margin:0px 10px 0px 0px; padding-bottom:4px;',
                anchor : '100%',
                labelWidth : 150,
                width : 483,
                msgTarget : 'side'
              },
              items : [ {
                xtype : 'tbspacer',
                height : 15
              }, {
                xtype : 'fieldset',
                title : 'Deutsch',
                collapsible : true,
                resizable : false,
                collapsed : false,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_DE',
                  itemId : 'EMail_DE',
                  emptyText : 'Betreff',
                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_DE_Text',
                  itemId : 'EMail_DE_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : false
                } ],
                setExpanded : function(expanded) {
                  var me = this, checkboxCmp = me.checkboxCmp, toggleCmp = me.toggleCmp, event;

                  expanded = !!expanded;

                  if (expanded) {
                    event = "expand";
                    me.removeCls(me.baseCls + '-collapsed');
                  } else {
                    event = "collapse";
                    me.addCls(me.baseCls + '-collapsed');
                  }
                  me.collapsed = !expanded;
                  me.doComponentLayout();
                  me.fireEvent(event, me);
                  return me;
                },
                listeners : {
                  expand : function(view, record, item, index, evt, eOpts) {
                    view.ownerCt.ownerCt.doLayout();
                  }
                }

              }, {
                xtype : 'tbspacer',
                height : 10
              }, {
                xtype : 'fieldset',
                title : 'Englisch',
                collapsible : true,
                resizable : false,
                collapsed : true,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_EN',
                  itemId : 'EMail_EN',
                  emptyText : 'Betreff',

                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_EN_Text',
                  itemId : 'EMail_EN_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : true
                } ]
              }, {
                xtype : 'tbspacer',
                height : 10
              }, {
                xtype : 'fieldset',
                title : 'Französisch',
                collapsible : true,
                resizable : false,
                collapsed : true,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_FR',
                  itemId : 'EMail_FR',
                  emptyText : 'Betreff',

                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_FR_Text',
                  itemId : 'EMail_FR_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : true
                } ]
              }, {
                xtype : 'tbspacer',
                height : 10
              }, {
                xtype : 'fieldset',
                title : 'Spanisch',
                collapsible : true,
                resizable : false,
                collapsed : true,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_SP',
                  itemId : 'EMail_SP',
                  emptyText : 'Betreff',

                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_SP_Text',
                  itemId : 'EMail_SP_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : true
                } ]
              }, {
                xtype : 'tbspacer',
                height : 10
              }, {
                xtype : 'fieldset',
                title : 'Chinesisch',
                collapsible : true,
                resizable : false,
                collapsed : true,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_ZH',
                  itemId : 'EMail_ZH',
                  emptyText : 'Betreff',

                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_ZH_Text',
                  itemId : 'EMail_ZH_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : true
                } ]
              }, {
                xtype : 'tbspacer',
                height : 10
              }, {
                xtype : 'fieldset',
                title : 'Türkisch',
                collapsible : true,
                resizable : false,
                collapsed : true,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_TR',
                  itemId : 'EMail_TR',
                  emptyText : 'Betreff',

                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_TR_Text',
                  itemId : 'EMail_TR_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : true
                } ]
              }, {
                xtype : 'tbspacer',
                height : 10
              }, {
                xtype : 'fieldset',
                title : 'Türkisch',
                collapsible : true,
                resizable : false,
                collapsed : true,
                style : 'border:transparent;',
                items : [ {
                  style : 'margin:0px 10px 0px 0px; padding-bottom:4px; padding-top:4px;',
                  xtype : 'textfield',
                  // value : recordData.EN,
                  name : 'EMail_KL',
                  itemId : 'EMail_KL',
                  emptyText : 'Betreff',

                  width : 460,
                  allowBlank : true
                }, {
                  xtype : 'textarea',
                  // value : recordData.EN,
                  name : 'EMail_KL_Text',
                  itemId : 'EMail_KL_Text',
                  emptyText : 'Text',
                  width : 460,
                  height : 48,
                  allowBlank : true
                } ]
              }, {
                xtype : 'tbspacer',
                height : 10
              }

              ]
            }, {
              xtype : 'tbspacer',
              height : 10
            }

            ]
          } ],

          buttons : {
            itemId : 'myButtons',
            items : [ {
              xtype : 'tbspacer',
              width : 70
            }, {
              itemId : 'btnSave',
              text : 'Speichern',
              disabled : false,
              handler : function(button, evt) {

                // var formPan = button.up("window").getComponent("myFormPanel");
                // if (formPan) {
                // var values = formPan.getForm().getValues();
                //
                // if(Ext.isEmpty(record))
                // {
                // wfStatePanel.store.add({
                // DE : values.DE,
                // EN : values.EN,
                // FR : values.FR,
                // SP : values.SP,
                // ZH : values.ZH,
                // TR : values.TR,
                // KL : values.KL,
                // ExportWarning : values.ExportWarning === 'on'
                // });
                // }
                // else
                // {
                // record.data.DE = values.DE;
                // record.data.EN = values.EN;
                // record.data.FR = values.FR;
                // record.data.SP = values.SP;
                // record.data.ZH = values.ZH;
                // record.data.TR = values.TR;
                // record.data.KL = values.KL;
                // record.data.ExportWarning = values.ExportWarning === 'on';
                //                  
                // wfStatePanel.getView().refresh();
                // }
                //                
                // button.up("window").close();
                // }

              }
            } ]
          }
        }).show();
      },

      showProductsTreeDialog : function(button, editordata) {
        var me = this.app;
        
        var dialogWindow = Ext.create('widget.window', {

          width : 520,// extVia.dialoges.dialogDefaultWidth,
          y : 180,

          title : 'Hierarchie auswählen',
          plain : true,

          items : [ {
            border : false,
            minHeight : 200,

            itemId : 'myFormPanel',
            xtype : 'form',

            dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
              var dialogButtons = this.ownerCt.getComponent('myButtons');

              var activate = dirty;

            },

            fieldDefaults : {
              msgTarget : 'side'
            },
            defaults : {
              style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
              anchor : '100%',
              labelWidth : 150,
              width : 350,
              msgTarget : 'side'
            },
            items : [

            extVia.dialoges.getInstructionPanel({
              mainInstr : 'Hierarchie auswählen'
            // suppInstr : ''
            }), 
            Ext.create('Ext.tree.Panel', {
              itemId:'Tree',
              rootVisible:false,
              store:  extVia.stores.initTreeStores().productsStore,
              border: false,
              height: 300,
              bodyBorder:false,
              header: false,
              useArrows: true,
              listeners: {
                afterrender : function(view, eOpts)
                {
                  if(!Ext.isEmpty(editordata.hierarchyNode)){
                   view.getSelectionModel().select(editordata.hierarchyNode);
                  }
                }
              }, 
              renderTo: Ext.getBody()
            })

            ]
          } ],

          buttons : {
            itemId : 'myButtons',
            items : [ {
              xtype : 'tbspacer',
              width : 70
            }, {
              itemId : 'btnUse',
              text : 'Auswählen',
              disabled : false,
              handler : function(useButton, evt) {

                var tree = useButton.up("window").getComponent("myFormPanel").getComponent("Tree");

                var selection = tree.getSelectionModel().getSelection()[0];
                
                editordata.hierarchyNode = selection;
                
                button.ownerCt.getComponent("hierarchy").setValue("<small>... / "+selection.parentNode.data.text + " </small>/ " +selection.data.text);
                
                useButton.up("window").close();
                
              }
            } ]
          }
        }).show();
        
      },
      
      launch : function() {

        var urlParams = extVia.ui.page.BaseRaster.prototype.getUrlParams();
        if (urlParams.modul){
         extVia.locales.modul = urlParams.modul;
        }
        
        
        Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires : new Date(new Date().getTime() + ( 1000 * 60 * 60 * 24 * 7 ))
        // 7 days from now
        }));
        extVia.regApp = this;
        var me = this;
        var modulDscr = extVia.locales.modul;
        var epobDscr = 'Alle';

        // try{
        // alert(' extVia.dummies.workflows.SYNC_Nodes '+ Ext.encode(extVia.dummies.workflows) );
        // } catch(ex){alert(ex)}

        Array.prototype.move = function(old_index, new_index) {
          if (new_index >= this.length) {
            var k = new_index - this.length;
            while (( k-- ) + 1) {
              this.push(undefined);
            }
          }
          this.splice(new_index, 0, this.splice(old_index, 1)[0]);
          return this; // for testing purposes
        };

        var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};

        extVia.constants.raster.mainWestWidth = 360;

        extVia.ui.page.raster = new extVia.ui.page.BaseRaster({
          viewCfgFromUrl : true,
          modulDscr : modulDscr
        });
        
        
        
        
        extVia.ui.page.raster.onReady(this);

        this.workflowsStore = Ext.create('Ext.data.Store', {
          storeId : 'workflowsStore',
          sorters : [ 'groupEpobType', 'epobType', 'name_DE'],
          groupField : 'groupEpobType',
          fields : [ 'id', 'groupEpobType', 'epobType', 'name_DE','version', 'status', 'responsible' ],
          data : {
            'items' : [ {
              id : Ext.id(),
              groupEpobType : 'Video',
              epobType : 'WorkflowResponsiblePerson',
              name_DE : 'Administratoren',
              version: '1',
              status : '',
              responsible : 'Hausmeister',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Video',
              epobType : 'WorkflowResponsiblePerson',
              name_DE : 'Hausmeister',
              version: '1',
              status : '',
              responsible : 'Hausmeister',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Image',
              epobType : 'WorkflowResponsiblePerson',
              name_DE : 'Verwaltung',
              version: '1',
              status : '',
              responsible : 'Hausmeister',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Product',
              epobType : 'WorkflowResponsiblePerson',
              name_DE : 'Welt retten',
              version: '1',
              status : '',
              responsible : 'Hausmeister',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Attribute',
              epobType : 'Workflow',
              name_DE : 'Übersetzung',
              version: '1',
              status : 'Yes',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Attribute',
              epobType : 'Workflow',
              name_DE : 'Freigabe',
              version: '1',
              status : 'No',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Product',
              epobType : 'Workflow',
              name_DE : 'Produkte pflegen',
              version: '1',
              status : 'Yes',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Product',
              epobType : 'Workflow',
              name_DE : 'Akku-Bohrschrauber',
              version: '1',
              status : 'Yes',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Video',
              epobType : 'Workflow',
              name_DE : 'WF 360',
              version: '1',
              status : 'Yes',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Video',
              epobType : 'Workflow',
              name_DE : 'WF 360',
              version: '2',
              status : 'Yes',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            }, {
              id : Ext.id(),
              groupEpobType : 'Video',
              epobType : 'Workflow',
              name_DE : 'WF 360',
              version: '3',
              status : 'No',
              responsible : '',
              responsibleOrder : '',
              responsibleComment : ''
            } ]
          },
          proxy : {
            type : 'memory',
            reader : {
              type : 'json',
              root : 'items'
            }
          }
        });

        this.wfHierarchyStore = Ext.create('Ext.data.Store', {
          storeId : 'wfHierarchyStore',
          sorters : [ 'name_DE' ],
          fields : [ 'id', 'name_DE', 'epobType', 'responsible' ],
          data : {
            'items' : [ {
              id : '1',
              name_DE : 'Flow 1',
              epobType : 'WorkflowInHierarchy',
              responsible : ''
            }, {
              id : '11',
              name_DE : 'Ernie',
              epobType : 'WorkflowInHierarchy',
              responsible : 'Oskar'
            }, {
              id : '2',
              name_DE : 'Bilder hochladen',
              epobType : 'WorkflowInHierarchy',
              responsible : 'Oskar'
            }, {
              id : '3',
              name_DE : 'Welt retten',
              epobType : 'WorkflowInHierarchy',
              responsible : 'Grobi'
            }, {
              id : '4',
              name_DE : 'Kuchen backen',
              epobType : 'WorkflowInHierarchy',
              responsible : ''
            }, {
              id : '5',
              name_DE : 'Datenbank zerstören',
              epobType : 'WorkflowInHierarchy',
              responsible : ''
            }, {
              id : '6',
              name_DE : 'Produkte pflegen',
              epobType : 'WorkflowInHierarchy',
              responsible : ''
            }, {
              id : '7',
              name_DE : 'Akku-Bohrschrauber',
              epobType : 'WorkflowInHierarchy',
              responsible : ''
            }, {
              id : '8',
              name_DE : 'Stichsäge',
              epobType : 'WorkflowInHierarchy',
              responsible : ''
            } ]
          },
          proxy : {
            type : 'memory',
            reader : {
              type : 'json',
              root : 'items'
            }
          }
        });

        this.StateStore = Ext.create('Ext.data.Store', {
          storeId : 'StateStore',
          fields : [ 'id', 'DE', 'EN', 'ExportWarning' ],
          data : {
            'items' : [ {
              id : '1',
              DE : 'In Planung',
              EN : 'Planing',
              ExportWarning : 'true'
            }, {
              id : '2',
              DE : 'In Bearbeitung',
              EN : 'In Prozess',
              ExportWarning : 'false'
            }, {
              id : '3',
              DE : 'Testen',
              EN : 'Testing',
              ExportWarning : 'false'
            }, {
              id : '4',
              DE : 'Freigegeben',
              EN : 'Done',
              ExportWarning : 'false'
            } ]
          },
          proxy : {
            type : 'memory',
            reader : {
              type : 'json',
              root : 'items'
            }
          }
        });
        // //>>>> Alte Version (0.1)<<<<
        // this.transitionNotificationStore = Ext.create('Ext.data.Store', {
        // storeId:'transitionNotificationStore',
        // sorters: ['Description','User'],
        // groupField : 'Description',
        // fields:['id', 'Description', 'User', 'Joblist_Comment', 'Joblist_Active', 'EMail_Comment', 'EMail_DE',
        // 'EMail_DE_Text', 'EMail_EN', 'EMail_EN_Text', 'EMail_FR', 'EMail_FR_Text', 'EMail_Active'],
        // data:{'items':[
        // {id:'1', Description:'Auftrag erhalten', Typ : 'User', User:'Max', Joblist_Comment:'Max freut sich',
        // Joblist_Active:'Checked', EMail_Comment:'', EMail_DE:'m@x.de', EMail_DE_Text:'Hallo Max, mach das mal bitte',
        // EMail_EN:'', EMail_EN_Text:'', EMail_FR:'', EMail_FR_Text:'', EMail_Active:'Checked'},
        // {id:'2', Description:'Auftrag erhalten', User:'Hanna', Joblist_Comment:'Hanna kann das',
        // Joblist_Active:'Checked', EMail_Comment:'Keine Mail', EMail_DE:'', EMail_DE_Text:'', EMail_EN:'',
        // EMail_EN_Text:'', EMail_FR:'', EMail_FR_Text:'', EMail_Active:''},
        // {id:'3', Description:'Auftrag erhalten', User:'Klaus', Joblist_Comment:'', Joblist_Active:'',
        // EMail_Comment:'Nur E-Mail', EMail_DE:'klaus@qwe.de', EMail_DE_Text:'Hallo', EMail_EN:'klaus@qwe.com',
        // EMail_EN_Text:'Hello', EMail_FR:'klaus@qwe.fr', EMail_FR_Text:'Bonjour', EMail_Active:'Checked'},
        // {id:'4', Description:'Auftrag bearbeitet', User:'Max', Joblist_Comment:'Max freut sich wieder',
        // Joblist_Active:'Checked', EMail_Comment:'', EMail_DE:'m@x.de', EMail_DE_Text:'Hallo Max, mach das mal bitte
        // auch', EMail_EN:'', EMail_EN_Text:'', EMail_FR:'', EMail_FR_Text:'', EMail_Active:'Checked'},
        // {id:'5', Description:'Auftrag bearbeitet', User:'Hanna', Joblist_Comment:'Hanna kann das, wenn Sie will',
        // Joblist_Active:'Checked', EMail_Comment:'Keine Mail', EMail_DE:'', EMail_DE_Text:'', EMail_EN:'',
        // EMail_EN_Text:'', EMail_FR:'', EMail_FR_Text:'', EMail_Active:''}
        // ]},
        // proxy: {
        // type: 'memory',
        // reader: {
        // type: 'json',
        // root: 'items'
        // }
        // }
        // });
        // //>>>> Ende alte Version (0.1)<<<<

        this.transitionNotificationStore = Ext.create('Ext.data.Store', {
          storeId : 'transitionNotificationStore',
          sorters : [ 'Transition', 'NotificationRecipientName' ],
          groupField : 'Transition',
          fields : [ 'id', 'Transition', 'NotificationRecipientName', 'NotificationRecipientTyp', 'Subject_DE', 'Message_DE',
                    'Joblist_Active', 'EMail_Active' ],
          data : {
            'items' : [ {
              id : '1',
              Transition : 'In Planung -> Testen',
              NotificationRecipientName : ['Jason Dorsey (User)'],
              NotificationRecipientTyp : 'User',
              Subject_DE : 'Los Jason',
              Message_DE : 'Hallo Jason, mach das mal bitte',
              Joblist_Active : 'Checked',
              EMail_Active : 'Checked'
            }, {
              id : '2',
              Transition : 'In Planung -> Testen',
              NotificationRecipientName : ['Peter Criss (User)'],
              NotificationRecipientTyp : 'User',
              Subject_DE : 'Peter, ich glaube an dich',
              Message_DE : 'Sers Peter, es gibt etwas zu tun',
              Joblist_Active : 'Checked',
              EMail_Active : ''
            }, {
              id : '3',
              Transition : 'In Planung -> Testen',
              NotificationRecipientName : ['Bill Ward (User)'],
              NotificationRecipientTyp : 'User',
              Subject_DE : '',
              Message_DE : 'Hallo Bill, folgendes bitte erledigen: -Produkte umbenennen, -Bilder anhängen, -Prodzuktabellen zuordnen ',
              Joblist_Active : '',
              EMail_Active : 'Checked'
            }, {
              id : '4',
              Transition : 'Testen -> Freigegeben',
              NotificationRecipientName : ['Jason Dorsey (User)'],
              NotificationRecipientTyp : 'User',
              Subject_DE : 'Es gibt etwas zu tun',
              Message_DE : 'Jason, auf auf auf',
              Joblist_Active : 'Checked',
              EMail_Active : 'Checked'
            }, {
              id : '5',
              Transition : 'Testen -> Freigegeben',
              NotificationRecipientName : ['Peter Criss (User)'],
              NotificationRecipientTyp : 'User',
              Subject_DE : 'Los los los',
              Message_DE : 'Sooo jetzt!',
              Joblist_Active : 'Checked',
              EMail_Active : ''
            } ]
          },
          proxy : {
            type : 'memory',
            reader : {
              type : 'json',
              root : 'items'
            }
          }
        });

        this.gettransitionNotificationDescription = function() {

          var itemsArray = me.StateStore.data.items;

          var transitionNotificationDescriptionArray = [];

          var i = 0;
          itemsArray.forEach(function(item_A) {
            itemsArray.forEach(function(item_B) {

              if (item_A.data.DE !== item_B.data.DE) {
                transitionNotificationDescriptionArray[i++] = item_A.data.DE + " -> " + item_B.data.DE;
              }
            });
          });

          return transitionNotificationDescriptionArray;
        };

        var warningCheckRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
          if (value === 'true' || value === true) {
            return '<div style="height:18px;padding-left:16px;" class="xty_icon xty_iconChecked" data-qtip="' + value
                   + '"></div>';
          } else {
            return '';
          }
        };
        var epobTypeRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
          return '<div style="height:18px;padding-left:16px" class="xty_epob' + value + '" data-qtip="' + value
                 + '"></div>';
        };
        var epobTypeRendererWithText = function(value, metaData, record, rowIndex, colIndex, store, view) {
          return '<div style="height:18px;padding-left:16px;padding-right:10px;float: left;" class="xty_epob' + value
                 + '" data-qtip="' + value + '"></div>' + value;
        };
        var statusRenderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
          if (value !== "") {
            return '<div style="height:18px;padding-left:16px;" class="xty_icon xty_icon' + value + '" data-qtip="'
                   + value + '"></div>';
          }
        };

        var workflowsGrid = Ext.create('Ext.grid.Panel', {
          itemId : 'workflowsGrid',
          width : 360,
          border : false,
          app : this,
          cls : 'xty_transition-grid xty_grid-group-paranthesis xty_selectable-group-grid',

          features : [ Ext.create('Ext.grid.feature.Grouping', {
            groupHeaderTpl : '{name}'
          }) ],

          store : Ext.data.StoreManager.lookup('workflowsStore'),
          columns : [ {
            header : 'EPIM-Id',
            dataIndex : 'id',
            width : 50,
            hidden : true,
            groupable : false
          }, {
            header : 'Gruppe',
            dataIndex : 'groupEpobType',
            width : 120,
            renderer : epobTypeRendererWithText,
            hidden : true
          }, {
            header : 'Typ',
            dataIndex : 'epobType',
            width : 32,
            renderer : epobTypeRenderer,
            groupable : false
          }, {
            header : 'Name',
            dataIndex : 'name_DE',
            renderer : function(value, metaData, record, rowIndex, colIndex, store, view){
              if(record.data.epobType === "Workflow" && record.data.version !== "1")
              {
                return value + " ("+record.data.version+")" ;
              }
              return value;
            },
            flex : 1,
            groupable : false
          }, {
            header : 'Gestartet',
            dataIndex : 'status',
            width : 63,
            renderer : statusRenderer
          }
          // { header: 'Verantwortliche', dataIndex: 'client',
          // renderer: function(){
          // var clientsHtml =
          // '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
          // '<span class="xty_tag" title="Muppets">Muppets</span>' +
          // '<span class="xty_tag" title="Puppets" >Puppets</span>' +
          // '</span>';
          // return clientsHtml;
          // }
          // }

          ],
          listeners : {
            itemdblclick : function(view, record, item, index, evt, eOpts) {
              me.showEditor(record);
            },
            itemcontextmenu : function(view, record, item, index, evt, eOpts) {

              view.select(index);

              evt.stopEvent();

              var isActive = record.data.status === "Yes";
              
              Ext.create('Ext.menu.Menu', {
                items : [ {
                  text : 'Bearbeiten',
                  handler : me.onEditbWorkflow,
                  iconCls : 'xty_menu-versioning-work',
                  gridview : view,
                  app : me
                }, {
                  text : 'Löschen',
                  handler : me.onDeleteWorkflow,
                  iconCls : 'xty_pgtoolbar-delete-small',
                  hidden: isActive,
                  gridview : view,
                  app : me
                } ]
              }).showAt(evt.getXY());
            },
            groupclick : function(view, node, group, evt, eOpts) {
              var me = this;
              
              var centerPan = extVia.regApp.myRaster.getCenter();
              
              
              var groupHdRow = Ext.get(node);
              var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
              var groupBodyId = groupBodytSibling.id;
              var groupBody = Ext.get(groupBodyId);
              
              
              
              if(evt.getX() - view.getEl().getLeft() < 15)
              {
                groupBody.removeCls('xty_grid-group-body-no-collapse');
                return;
              }
              
              groupBody.addCls('xty_grid-group-body-no-collapse');

              if(!Ext.isEmpty(me.selectedGroup) && group !== me.selectedGroup.group){
                me.removeGroupSelection();
              }
              view.getSelectionModel().deselectAll(true);
              
              var isSelected = groupHdRow.hasCls('xty_groupHdRow-selected');
              if (isSelected) {
                groupHdRow.removeCls('x-grid-group-hd-collapsed');
                groupHdRow.removeCls('xty_groupHdRow-selected');
                groupBody.removeCls('xty_grid-group-body-selected');
                
                me.selectedGroup = null;
              } else {
                groupHdRow.removeCls('x-grid-group-hd-collapsed');
                groupHdRow.addCls('xty_groupHdRow-selected');
                groupBody.addCls('xty_grid-group-body-selected');
                
                me.selectedGroup = {view:view, node:node, group:group, evt:evt, eOpts:eOpts};
              }
            },
            groupcontextmenu : function(view, node, group, evt, eOpts) {

              // var recordsInGroup = view.getStore().getGroups(group).children;
              // view.select(index);
              var me = this.app;
              
              evt.preventDefault();

              this.removeGroupSelection();
              this.getSelectionModel().deselectAll(true);
              
              var groupHdRow = Ext.get(node);
              var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
              var groupBodyId = groupBodytSibling.id;
              var groupBody = Ext.get(groupBodyId);
              groupHdRow.addCls('xty_groupHdRow-selected');
              groupBody.addCls('xty_grid-group-body-selected');
              this.selectedGroup = {view:view, node:node, group:group, evt:evt, eOpts:eOpts};
              
              Ext.create('Ext.menu.Menu', {
                items : [ {
                  text : extVia.locales.modul+' hinzufügen',
                  handler : me.onAddbWorkflow,
                  iconCls : 'x-btn-default-toolbar-small',
                  gridview : view,
                  transition : group,
                  app : me
                }, {
                  text : 'Verantwortliche Person hinzufügen',
                  handler : me.onAddbWorkflowResponsiblePerson,
                  iconCls : 'xty_pgtoolbar-newWorkflowResponsiblePerson',
                  gridview : view,
                  transition : group,
                  app : me
                }]
              }).showAt(evt.getXY());
            },
            selectionchange : function(view, selected, eOpts){
              var me = this;
              me.removeGroupSelection();
            }
          },
          getSelection : function() {
            var me = this;
            
            var selection = this.getSelectionModel().getSelection()[0];
            
            if(Ext.isEmpty(selection)){
                selection = me.selectedGroup;
                if(!Ext.isEmpty(selection)){
                  selection.selectionTyp = 'Group';
                }
            }else{
              selection.selectionTyp = 'Row';
            }
            
            return selection;
          },
          removeGroupSelection : function (){
            var me = this;
            
            //Deselektiere die alte Selektion
            if(!Ext.isEmpty(me.selectedGroup)){
              var delgroupHdRow = Ext.get(me.selectedGroup.node);
              var delgroupBodytSibling = Ext.get(delgroupHdRow).dom.nextSibling;
              var delgroupBodyId = delgroupBodytSibling.id;
              var delgroupBody = Ext.get(delgroupBodyId);
              
              if(!Ext.isEmpty(delgroupBody)){
                delgroupHdRow.removeCls('x-grid-group-hd-collapsed');
                delgroupHdRow.removeCls('xty_groupHdRow-selected');
                delgroupBody.removeCls('xty_grid-group-body-selected');
              }
              me.selectedGroup = null;
            }
          },
          renderTo : Ext.getBody()
        });

        var workflowsList = {
          title : extVia.locales.modul+'gruppen',
          itemId : 'workflowsList',
          height : me.getWestListHeight(),
          tbar : [ '->', {
            iconCls : 'xty_pgtoolbar-newWorkflow',
            itemId : 'addbWorkflow',
            handler : me.onAddbWorkflow,
            app : me,
            tooltip : extVia.locales.modul+' hinzufügen'
          },

          {
            iconCls : 'xty_pgtoolbar-newWorkflowResponsiblePerson',
            itemId : 'addbWorkflowResponsiblePerson',
            handler : me.onAddbWorkflowResponsiblePerson,
            app : me,
            tooltip : 'Verantwortliche Person hinzufügen'
          },

          '|',

          {
            iconCls : 'xty_pgtoolbar-edit',
            itemId : 'edit',
            handler : me.onEditbWorkflow,
            app : me,
            tooltip : 'Bearbeiten'
          }, {
            iconCls : 'xty_pgtoolbar-delete',
            itemId : 'delete',
            handler : me.onDeleteWorkflow,
            app : me,
            tooltip : 'Löschen'
          } ],
          items : [ workflowsGrid ],
          bbar : [ '->', {
            iconCls : ' xty_pgtoolbar-pagingFirst'
          }, {
            iconCls : ' xty_pgtoolbar-pagingPrev'
          }, {
            iconCls : ' xty_pgtoolbar-pagingNext'
          }, {
            iconCls : ' xty_pgtoolbar-pagingLast'
          } ]
        };

        var wfHierarchyGrid = Ext.create('Ext.grid.Panel', {
          itemId : 'wfHierarchyGrid',
          width : 360,
          border : false,

          store : Ext.data.StoreManager.lookup('wfHierarchyStore'),
          columns : [ {
            header : 'EPIM-Id',
            dataIndex : 'id',
            width : 50,
            hidden : true,
            groupable : false
          }, {
            header : 'Name',
            dataIndex : 'name_DE',
            flex : 1,
            groupable : false
          }
//          , {
//            header : 'Status',
//            dataIndex : 'status',
//            width : 40,
//            hidden : true,
//            renderer : statusRenderer
//          }
          // { header: 'Verantwortliche', dataIndex: 'client',
          // renderer: function(){
          // var clientsHtml =
          // '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
          // '<span class="xty_tag" title="Muppets">Muppets</span>' +
          // '<span class="xty_tag" title="Puppets" >Puppets</span>' +
          // '</span>';
          // return clientsHtml;
          // }
          // }

          ],
          listeners : {
            itemdblclick : function(view, record, item, index, evt, eOpts) {
              me.showEditor(record);
            }
          },
          getSelection : function() {
            return this.getSelectionModel().getSelection()[0];
          },
          renderTo : Ext.getBody()
        });

        var wfHierarchyTab = {
          title : 'Hierarchy',
          closable:true,
          itemId : 'wfHierarchyTab',
          height : me.getWestListHeight(),
          tbar : [ '->', {
            iconCls : 'xty_pgtoolbar-newWorkflowInHierarchy',
            itemId : 'addWorkflowInHierarchy',
            handler : me.addWorkflowInHierarchy,
            app : me,
            tooltip : 'Workflow in Hierarchie hinzufügen'
          },

          '|',

          {
            iconCls : 'xty_pgtoolbar-edit',
            itemId : 'edit',
            handler : me.onEditbWorkflow,
            app : me,
            tooltip : 'Bearbeiten'
          }, {
            iconCls : 'xty_pgtoolbar-delete',
            itemId : 'delete',
            handler : me.onDeleteWorkflow,
            app : me,
            tooltip : 'Löschen'
          } ],
          items : [ wfHierarchyGrid ],
          bbar : [ '->', {
            iconCls : ' xty_pgtoolbar-pagingFirst'
          }, {
            iconCls : ' xty_pgtoolbar-pagingPrev'
          }, {
            iconCls : ' xty_pgtoolbar-pagingNext'
          }, {
            iconCls : ' xty_pgtoolbar-pagingLast'
          } ]
        };

        var anythingTab = {
          title : 'Anything else',
          closable:true,
          itemId : 'Anything Tab',
          tbar : [ '->', {
            iconCls : 'xty_pgtoolbar-list'
          }, {
            iconCls : 'xty_pgtoolbar-new',
            itemId : 'new'
          }, {
            iconCls : 'xty_pgtoolbar-edit',
            itemId : 'edit'
          }, {
            iconCls : 'xty_pgtoolbar-delete',
            itemId : 'delete'
          } ]
        };

        var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
          tabBar : {
            tools : [ {
              xtype : 'button',
              cls : 'xty_striptool-button xty_striptool-button-refresh',
              iconCls : 'x-tool x-tool-refresh',
              masrgin : '0 0 0 50',
              handler : function(button) {
                var activeTab = button.ownerCt.ownerCt.getActiveTab();
                extVia.notify({
                  action : 'Refresh West ',
                  mssg : '<b>' + activeTab.title + '</b>'
                });
              }
            } ]
          },
          items : [ workflowsList, wfHierarchyTab, anythingTab ]
        });
        extVia.regApp.myRaster.addToWest(tabPanWest);

        var wfModuleAppbar = extVia.ui.page.pagejob.getApplicationBar({
          pgjobDscr : extVia.locales.modul+'modul',
          epobDscr : null
        });
        var wfModulePanel = {
          title : extVia.locales.modul+'modul',
          tbar : wfModuleAppbar,
          items : []
        };

        // Need some center Tabs?
        var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
          tabBar : {
            tools : [ {
              xtype : 'button',
              cls : 'xty_striptool-button xty_striptool-button-refresh',
              handler : function(button) {
                var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                extVia.notify({
                  action : 'Refresh Center',
                  mssg : '<b>' + activeTab.title + '</b>'
                });
              },
              iconCls : 'x-tool x-tool-refresh'
            } ]
          }
        });
        me.tabPanCenter = tabPanCenter;
        extVia.regApp.myRaster.addToCenter(tabPanCenter);
        tabPanCenter.add(wfModulePanel);

        // WorkflowEditor - wfEditor

        me.loadEditor = function(record, typ, group) {
          
          var editorData = {
            isNew : true,
            id : Ext.id(),
            groupEpobType : Ext.isEmpty(group)?"":group,
            epobType : typ,
            name : "Neu",
            version : "1",
            currentWorkflow : null,
            hierarchyNode : null,
            responsible : '',
            responsibleOrder : '',
            responsibleComment : '',
            isActive: false,
            language : {
              DE : "",
              EN : "",
              FR : "",
              SP : "",
              ZH : "",
              TR : "",
              KL : ""
            }
          };
          
          if (!Ext.isEmpty(record)) {
            editorData = {
              isNew : Ext.isEmpty(record.isSaved)?false:!record.isSaved,
              id : record.get("id"),
              groupEpobType : record.get("groupEpobType"),
              epobType : record.get("epobType"),
              name : record.get("name_DE"),
              version : record.get("version"),
              currentWorkflow : null,
              hierarchyNode : null,
              responsible : record.get("responsible"),
              responsibleOrder : record.get("responsibleOrder"),
              responsibleComment : record.get("responsibleComment"),
              isActive : record.get('status')==='Yes'?true:false,
              language : {
                DE : record.get("name_DE"),
                EN : record.get("name_EN"),
                FR : record.get("name_FR"),
                SP : record.get("name_SP"),
                ZH : record.get("name_ZH"),
                TR : record.get("name_TR"),
                KL : record.get("name_KL")
              }
            };
          }
          
          var isWorkflow = false;
          var isRespPerson = false;
          var isWorkflowInHierachy = false;

          var pgjobDscr = "";
          if (editorData.epobType === "Workflow") {
            isWorkflow = true;

            pgjobDscr = extVia.locales.modul+" "+extVia.locales.pgjobEdit;
            if (editorData.isNew) {
              pgjobDscr = extVia.locales.modul+" hinzufügen";
            }

          } else if (editorData.epobType === "WorkflowInHierarchy") {
            isWorkflowInHierachy = true;

            pgjobDscr = extVia.locales.modul+"eigenschaften in der Hierarchie "+extVia.locales.pgjobEdit;
            if (editorData.isNew) {
              pgjobDscr = extVia.locales.modul+" in Hierarchie hinzufügen";
            }
          } else if (editorData.epobType === "WorkflowResponsiblePerson") {
            isRespPerson = true;

            pgjobDscr = "Verantwortlichen "+extVia.locales.pgjobEdit;
            if (editorData.isNew) {
              pgjobDscr = "Verantwortliche Person hinzufügen";
            }
          }
          
          if(isWorkflow){ 
            if(!Ext.isEmpty(record) && !Ext.isEmpty(record.store))
            {
              record.store.data.items.forEach(function(ArrayElement) {
                if(ArrayElement.data.name_DE === editorData.language.DE){
                  if(editorData.currentWorkflow === null || ArrayElement.data.version > editorData.currentWorkflow.data.version){
                    editorData.currentWorkflow = ArrayElement;
                  }
                }
              });
            }else{
              // Ext.isEmpty(record.store) == true bei neuer Verion
              editorData.currentWorkflow = record;
            }
          }

          var boxDefaults = { // defaults for box-items
            labelWidth : 180,
            width : 460,
            msgTarget : 'side',
            xtype : 'textfield',
            margin : '4 0 4 4'
          };

          // ############################################### masterDataTab Items
          // ###############################################
          var groupXtype = "combo";
          if (isWorkflowInHierachy) {
            groupXtype = "displayfield";
            editorData.groupEpobType = "Hierarchies";
          }
          if(editorData.isActive){
            groupXtype = "displayfield";
          }
          
          var wfMetadataPanelCfg = {
            title : 'Metadaten',
            itemId : 'metadata',
            xtype : 'form',
            collapsible : true,
            defaults : boxDefaults,
            items : [

                     {
                       itemId : 'epimId',
                       xtype : 'displayfield',
                       fieldLabel : 'EPIM-Id',
                       value : editorData.id,
                       hidden : true
                     },
                     {
                       xtype : groupXtype,
                       fieldLabel : "Gruppe",
                       itemId : 'groupEpobTypes',
                       name : 'groupEpobTypes',
                       allowBlank : false,
                       labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                       emptyText : 'Objekte',
                       queryMode : 'local',
                       displayField : 'dscr',
                       valueField : 'value',
                       value : editorData.groupEpobType,
                       store : Ext.create('Ext.data.Store', {
                         storeId : 'workflowEpobTypes',
                         model : Ext.define('workflowEpobTypes', {
                           fields : [ 'dscr', 'value' ],
                           extend : 'Ext.data.Model'
                         }),
                         data : [ {
                           dscr : 'Produktbereich',
                           value : 'Productsarea'
                         }, {
                           dscr : 'Hierarchien',
                           value : 'Hierarchy'
                         }, {
                           dscr : 'Produkte',
                           value : 'Product'
                         }, {
                           dscr : 'Produktvarianten',
                           value : 'Productvariant'
                         }, {
                           dscr : 'Produkte + Varianten',
                           value : 'ProductAndVariant'
                         }, {
                           dscr : 'Produktbeziehungen',
                           value : 'ProductAssignment'
                         }, {
                           dscr : '',
                           value : ''
                         }, {
                           dscr : 'Elemente',
                           value : 'Elements'
                         }, {
                           dscr : 'Bilder',
                           value : 'Image'
                         }, {
                           dscr : 'Grafiken',
                           value : 'Graphic'
                         }, {
                           dscr : 'Dokumente',
                           value : 'Document'
                         }, {
                           dscr : 'Audios',
                           value : 'Audio'
                         }, {
                           dscr : 'Videos',
                           value : 'Video'
                         }, {
                           dscr : 'Produkttabellen',
                           value : 'ProdTable'
                         }, {
                           dscr : 'Redaktionelle&nbsp;Tabellen',
                           value : 'EdTable'
                         }

                         ]
                       }),
                       listConfig : {
                         minWidth : 180,
                         getInnerTpl : function(displayField) {
                           var tpl = '<div class="xty_epobVersionModifier" style="" ><div style="width:100%;height:18px;padding-left:16px;" class="xty_epobSearcharea xty_epob{value}"><span style="margin-top:-8px;">'
                                     + '&nbsp; {dscr}' + '</span></div></div>';
                           return tpl;
                         }
                       }
                     },
                     { 
                       xtype : 'fieldcontainer',
                       fieldLabel : 'Hierarchie',
                       itemId : 'hierarchy',
                       labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                       layout : 'hbox',
                       hidden : !isWorkflowInHierachy,
                       items : [ {
                         xtype : 'displayfield',
                         value : Ext.isEmpty(editorData.hierarchyNode)?"":editorData.hierarchyNode.data.text,
                         name : 'hierarchy',
                         itemId : 'hierarchy',
                         allowBlank : !isWorkflowInHierachy,
                         width : 248
                       },{
                         xtype : 'button',
                         margin : '0 0 0 2',
                         tooltip : 'Hierarchie auswählen',
                         iconCls : 'xty_epobWorkflowInHierarchy',
                         handler : function(button, evt) {
                           me.showProductsTreeDialog(this, editorData);
                         }
                       } ]
                     },{
                       itemId : 'epobTyp',
                       xtype : 'displayfield',
                       fieldLabel : 'Typ',
                       hidden : true,
                       value : editorData.epobType
                     },{
                       fieldLabel : 'Rolle',
                       xtype : 'combo',
                       itemId : "responsible",
                       name : 'responsible',
                       hidden : !isRespPerson,
                       queryMode : 'local',
                       displayField : 'name',
                       valueField : 'value',
                       labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                       allowBlank : !isRespPerson,
                       store : ['Administrator','Entwicklier','Geschäftsführer','Hausmeister','Student','Support','Vertrieb'],
                       value: editorData.responsible
                     },{
                       xtype : 'fieldcontainer',
                       fieldLabel : 'Name (Deutsch)',
                       itemId : 'languageTherapyFieldContainer',
                       labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                       layout : 'hbox',
                       items : [ {
                         xtype : 'textfield',
                         value : editorData.language.DE,
                         oldValue : editorData.language.DE,
                         name : 'name_DE',
                         itemId : 'name_DE',
                         allowBlank : false,
                         width : 248,
                         setOldValue : function(oldValue){
                           this.oldValue = oldValue;
                         }
                       },{
                         itemId : 'langsinner',
                         xtype : 'button',
                         margin : '0 0 0 2',
                         tooltip : 'Sprachwerte pflegen',
                         iconCls : 'xty_pgtoolbar-customLanguagesEnable',
                         handler : function(button, evt) {
                           var languageTherapyPanel = button.ownerCt.ownerCt.getComponent('languageTherapyPanel');

                           if (languageTherapyPanel.hidden) {
                             languageTherapyPanel.show();
                           } else {
                             languageTherapyPanel.hide();
                           }
                         }
                       } ]
                     }, {
                       xtype : 'panel',
                       itemId : 'languageTherapyPanel',
                       autoScroll : true,
                       // height : 150,
                       border : false,
                       hidden : true,
                       defaults : {
                         style : 'margin:0px 0px 0px 0px; padding-bottom:4px;',
                         anchor : '100%',
                         labelWidth : 180,
                         width : 460,
                         msgTarget : 'side'
                       },
                       items : [ {
                         xtype : 'textfield',
                         value : editorData.language.EN,
                         name : 'name_EN',
                         itemId : 'name_EN',
                         fieldLabel : 'Name (Englisch)',
                         allowBlank : true
                       }, {
                         xtype : 'textfield',
                         value : editorData.language.FR,
                         name : 'name_FR',
                         itemId : 'name_FR',
                         fieldLabel : 'Name (Französisch)',
                         allowBlank : true
                       }, {
                         xtype : 'textfield',
                         value : editorData.language.SP,
                         name : 'name_SP',
                         itemId : 'name_SP',
                         fieldLabel : 'Name (Spanisch)',
                         allowBlank : true
                       }, {
                         xtype : 'textfield',
                         value : editorData.language.ZH,
                         name : 'name_ZH',
                         itemId : 'name_ZH',
                         fieldLabel : 'Name (Chinesisch)',
                         allowBlank : true
                       }, {
                         xtype : 'textfield',
                         value : editorData.language.TR,
                         name : 'name_TR',
                         itemId : 'name_TR',
                         fieldLabel : 'Name (Turkisch)',
                         allowBlank : true
                       }, {
                         xtype : 'textfield',
                         value : editorData.language.KL,
                         name : 'name_KL',
                         itemId : 'name_KL',
                         fieldLabel : 'Name (Klingonisch)',
                         allowBlank : true
                       } ]
                     },

                     {
                       itemId : 'started',
                       xtype : 'displayfield',
                       fieldLabel : 'Gestartet',
                       hidden : !isWorkflow,
                       value :   editorData.isActive?'Ja':'Nein'
                     },
                     {
                       itemId : 'version',
                       xtype : 'displayfield',
                       fieldLabel : 'Version',
                       hidden: !isWorkflow,
                       value :   editorData.version
                     },
                      {
                       itemId : 'responsibleOrder',
                       xtype : 'textfield',
                       fieldLabel : 'Reihenfolge',
                       allowBlank : !isRespPerson,
                       labelSeparator : ':<span class="xty_requiredStar"> *</span>',
                       hidden : !isRespPerson,
                       value: editorData.responsibleOrder
                     }, {
                       itemId : 'responsibleComment',
                       xtype : 'textarea',
                       fieldLabel : 'Bemerkung',
                       hidden : !isRespPerson,
                       value: editorData.responsibleComment
                     }

            ]
          };

          var changeInfoPanelCfg = {
            xtype : 'form',
            title : 'Änderungsinfo',
            itemId : 'changeInfo',
            defaults : boxDefaults,
            items : [ {
              itemId : 'changeDate',
              xtype : 'displayfield',
              fieldLabel : 'Anlage',
              value : 'heute'
            }, {
              itemId : 'creationDate',
              xtype : 'displayfield',
              fieldLabel : 'letzte Änderung',
              value : ''
            } ]
          };

          // ############################################### stateTab Items
          // ###############################################
          var wfStatePanel = Ext.create('Ext.grid.Panel', {
            store : Ext.data.StoreManager.lookup('StateStore'),
            itemId : 'wfStatePanel',
            forceFit : true,
            RowSelect : true,
            border : false,
            margin : '0 0 0 0',
            width : "100%",
            height : "100%",
            columns : [ Ext.create('Ext.grid.RowNumberer'), {
              header : 'EPIM-Id',
              dataIndex : 'id',
              hidden : true
            }, {
              header : 'Deutsch',
              dataIndex : 'DE'
            }, {
              header : 'Englisch',
              dataIndex : 'EN'
            }, {
              header : 'Französisch',
              dataIndex : 'FR',
              hidden : true
            }, {
              header : 'Spanisch',
              dataIndex : 'SP',
              hidden : true
            }, {
              header : 'Chinesisch',
              dataIndex : 'ZH',
              hidden : true
            }, {
              header : 'Turkisch',
              dataIndex : 'TR',
              hidden : true
            }, {
              header : 'Klingonisch',
              dataIndex : 'KL',
              hidden : true
            }, {
              header : 'Exportwarnung',
              renderer : warningCheckRenderer,
              dataIndex : 'ExportWarning'
            } ],
            listeners : {
              
              itemdblclick: function(view, record, item, index, evt, eOpts) {

                var editorPanel = view.ownerCt.ownerCt.ownerCt.ownerCt;
                               
                var cfg = {
                  title : "Zustand "+(editorData.isActive?"anzeigen":"bearbeiten"),
                  mainInstr : "Zustand "+(editorData.isActive?"anzeigen":"bearbeiten"),
                  isNew : false,
                  readOnly : editorData.isActive,
                  x : evt.X,
                  y : evt.Y
                };

                me.showStateDialog(editorPanel, cfg);
              },
              itemcontextmenu : function(view, record, item, index, evt, eOpts) {

                view.select(index);

                evt.stopEvent();

                Ext.create('Ext.menu.Menu', {
                  items : [  {
                    text : 'Anzeigen',
                    hidden: !editorData.isActive,
                    iconCls : 'xty_menu-showText',
                    gridview : view,
                    app : me,
                    handler : function(item, e){
                      var me = this.app;
                      var editorPanel = item.gridview.ownerCt.ownerCt.ownerCt.ownerCt;
                      
                      var cfg = {
                        title : "Zustand anzeigen",
                        mainInstr : "Zustand anzeigen",
                        isNew : false,
                        readOnly : true,
                        x : evt.X,
                        y : evt.Y
                      };

                      me.showStateDialog(editorPanel, cfg);
                    }
                  }, {
                    text : 'Bearbeiten',
                    hidden: editorData.isActive,
                    handler : me.onEditState,
                    iconCls : 'xty_pgtoolbar-editItem-small',
                    gridview : view,
                    app : me
                  }, {
                    text : 'Löschen',
                    hidden: editorData.isActive,
                    handler : me.onDeleteState,
                    iconCls : 'xty_pgtoolbar-deleteItems-small',
                    gridview : view,
                    app : me
                  } ]
                }).showAt(evt.getXY());
              }
            },
            plugins : [ Ext.create('Ext.grid.plugin.CellEditing', {
              clicksToEdit : 1
            }) ],
            getSelection : function() {
              return this.getSelectionModel().getSelection()[0];
            }
          });

          // ############################################### transitionNotificationTab Items
          // ###############################################
          var transitionNotificationTabPanel = Ext.create('Ext.grid.Panel', {
            store : Ext.data.StoreManager.lookup('transitionNotificationStore'),
            features : [ Ext.create('Ext.grid.feature.Grouping', {
              groupHeaderTpl : '{name}',
              id : '{name}'
            }) ],
//            plugins : [ Ext.create('Ext.grid.plugin.CellEditing', {
//              clicksToEdit : 1
//            })],
          
            selectedGroup : null,
            //animCollapse: false,
            itemId : 'transitionNotificationPanel',
            forceFit : true,
            rowSelect : true,
            cls : 'xty_transition-grid xty_grid-group-paranthesis xty_selectable-group-grid',
            border : false,
            margin : '0 0 0 0',
            width : "100%",
            height : "100%",
            editorData : editorData,
            // //>>>> Alte Version (0.1)<<<<
            // columns: [
            // Ext.create('Ext.grid.RowNumberer'),
            // {header: 'EPIM-Id', dataIndex: 'id', hidden: true},
            // {header: 'Übergang', dataIndex: 'Description', hidden:true},
            // {header: 'Benutzer', dataIndex: 'User'},
            // {header: 'Jobliste', forceFit: true, columns: [
            // {header: 'Bemerkung', dataIndex: 'Joblist_Comment'},
            // {header: 'Aktiv', dataIndex: 'Joblist_Active', renderer: statusRenderer}
            // ]},
            // {header: 'E-Mail', forceFit: true, columns: [
            // {header: 'Bemerkung', dataIndex: 'EMail_Comment'},
            // {header: 'E-Mail (DE)', dataIndex: 'EMail_DE'},
            // {header: 'Text (DE)', dataIndex: 'EMail_DE_Text', hidden: true},
            // {header: 'E-Mail (EN)', dataIndex: 'EMail_EN'},
            // {header: 'Text (EN)', dataIndex: 'EMail_EN_Text', hidden: true},
            // {header: 'E-Mail (FR)', dataIndex: 'EMail_FR'},
            // {header: 'Text (FR)', dataIndex: 'EMail_FR_Text', hidden: true},
            // {header: 'Aktiv', dataIndex: 'EMail_Active', renderer: statusRenderer}
            // ]}
            // ],
            // //>>>> Ende alte Version (0.1)<<<<
            columns : [ Ext.create('Ext.grid.RowNumberer'), {
              header : 'EPIM-Id',
              dataIndex : 'id',
              hidden : true
            }, {
              header : 'Übergang',
              dataIndex : 'Transition',
              hidden : true
            }, {
              header : 'Typ',
              dataIndex : 'NotificationRecipientTyp',
              width : 18,
              renderer : epobTypeRenderer
            }, {
              header : 'Empfänger',
              dataIndex : 'NotificationRecipientName',
              renderer : function(value, metaData, record, rowIndex, colIndex, store, view){
                
                  var text = value[0];
                  text = text.replace(" ("+extVia.enums.EpimObjects.ROLE.key+")", "");
                  text = text.replace(" ("+extVia.enums.EpimObjects.USERGROUP.key+")", "");
                  text = text.replace(" ("+extVia.enums.EpimObjects.USER.key+")", "");
                  text = text.replace(" ("+extVia.enums.EpimObjects.WF_RESPONSIBLEPERSON.key+")", "");
                  
                  if(value.length === 1){
                    return text;
                  }
                  return text + ", ... (+"+(value.length-1)+")";
                }
            }, {
              header : 'Nachricht',
              dataIndex : 'Message_DE',
              width:200,
              renderer : function(value, metaData, record, rowIndex, colIndex, store, view){
                //metaData.tdCls='xty_message-cell';
                var subj = record.get("Subject_DE");
                var html = (subj?"<b>"+subj + "</b><br/>":'') + value; //.replace(/-/g,'<br>-');
                return html;
              }
            }, {
              header : 'Joblisteneintrag',
              dataIndex : 'Joblist_Active',
              renderer : statusRenderer
            }, {
              header : 'E-Mail',
              dataIndex : 'EMail_Active',
              renderer : statusRenderer
            } ],
            listeners : {
              
              columnresize : function(){
                //alert("svboin");
              },
            
              itemdblclick : function(view, record, item, index, evt, eOpts) {

                var transitionNotificationPanel = view.ownerCt;
                var selectedItem = transitionNotificationPanel.getSelection().data;
                
                var cfg = {
                  isNew : false,
                  id : record.data.id,
                  groupEpobType : view.ownerCt.editorData.groupEpobType,
                  transition : record.data.Transition,
                  notificationRecipientName : record.data.NotificationRecipientName,
                  notificationRecipientTyp : record.data.NotificationRecipientTyp,
                  subject_DE : record.data.Subject_DE,
                  message_DE : record.data.Message_DE,
                  isJoblist_Active : record.data.Joblist_Active || record.data.Joblist_Active === "Checked",
                  isEMail_Active : record.data.EMail_Active || record.data.EMail_Active === "Checked"
                };

                if (!evt.hasModifier()) {
                  me.showtransitionNotificationDialog(transitionNotificationPanel, cfg);
                } else {
                  me.showtransitionNotificationDialog2();
                }
              },
              itemcontextmenu : function(view, record, item, index, evt, eOpts) {

                view.select(index);

                evt.stopEvent();

                Ext.create('Ext.menu.Menu', {
                  items : [ {
                    text : 'Bearbeiten',
                    iconCls : 'xty_menu-versioning-work',
                    gridview : view,
                    app : me,
                    handler : function(item, evt) {
                      var me = item.app;

                      var transitionNotificationPanel = null;
                      var editorPanel = null;
                      
                      if (!Ext.isEmpty(item.gridview)) {
                        
                       
                        transitionNotificationPanel = item.gridview.ownerCt;
                        editorPanel = transitionNotificationPanel.ownerCt.ownerCt.ownerCt;
                      } 

                      var selectedItem = transitionNotificationPanel.getSelection().data;

                      var cfg = {
                                 isNew : false,
                                 id : selectedItem.id,
                                 groupEpobType : editorPanel.editorData.groupEpobType,
                                 transition : selectedItem.Transition,
                                 notificationRecipientName : selectedItem.NotificationRecipientName,
                                 notificationRecipientTyp : selectedItem.NotificationRecipientTyp,
                                 subject_DE : selectedItem.Subject_DE,
                                 message_DE : selectedItem.Message_DE,
                                 isJoblist_Active : selectedItem.Joblist_Active || selectedItem.Joblist_Active === "Checked",
                                 isEMail_Active : selectedItem.EMail_Active || selectedItem.EMail_Active === "Checked"
                               };
                      
                      me.showtransitionNotificationDialog(transitionNotificationPanel, cfg);
                    }
                  }, {
                    text : 'Löschen',
                    handler : me.onDeleteTransitionNotification,
                    iconCls : 'xty_pgtoolbar-delete-small',
                    gridview : view,
                    app : me
                  } ]
                }).showAt(evt.getXY());
              },
              groupclick : function(view, node, group, evt, eOpts) {
                var me = this;
                
                var centerPan = extVia.regApp.myRaster.getCenter();
                
                
                var groupHdRow = Ext.get(node);
                var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                var groupBodyId = groupBodytSibling.id;
                var groupBody = Ext.get(groupBodyId);
                
                if(evt.getX() - view.getEl().getLeft() < 15)
                {
                  groupBody.removeCls('xty_grid-group-body-no-collapse');
                  return;
                }
                
                groupBody.addCls('xty_grid-group-body-no-collapse');

                if(!Ext.isEmpty(me.selectedGroup) && group !== me.selectedGroup.group){
                  me.removeGroupSelection();
                }
                view.getSelectionModel().deselectAll(true);
                
                var isSelected = groupHdRow.hasCls('xty_groupHdRow-selected');
                if (isSelected) {
                  groupHdRow.removeCls('x-grid-group-hd-collapsed');
                  groupHdRow.removeCls('xty_groupHdRow-selected');
                  groupBody.removeCls('xty_grid-group-body-selected');
                  
                  me.selectedGroup = null;
                } else {
                  groupHdRow.removeCls('x-grid-group-hd-collapsed');
                  groupHdRow.addCls('xty_groupHdRow-selected');
                  groupBody.addCls('xty_grid-group-body-selected');
                  
                  me.selectedGroup = {view:view, node:node, group:group, evt:evt, eOpts:eOpts};
                }
              },
              groupcontextmenu : function(view, node, group, evt, eOpts) {

                // var recordsInGroup = view.getStore().getGroups(group).children;
                // view.select(index);

                //var me = this;
                
                evt.preventDefault();

                this.removeGroupSelection();
                view.getSelectionModel().deselectAll(true);
                
                var groupHdRow = Ext.get(node);
                var groupBodytSibling = Ext.get(groupHdRow).dom.nextSibling;
                var groupBodyId = groupBodytSibling.id;
                var groupBody = Ext.get(groupBodyId);
                groupHdRow.addCls('xty_groupHdRow-selected');
                groupBody.addCls('xty_grid-group-body-selected');
                this.selectedGroup = {view:view, node:node, group:group, evt:evt, eOpts:eOpts};
                
                Ext.create('Ext.menu.Menu', {
                  items : [ {
                    text : 'Benachrichtigung hinzufügen',
                    gridview : view,
                    transition : group,
                    app : me,
                    handler : function(item, evt){
                      var me = item.app;

                      var transitionNotificationPanel = null;
                      var editorPanel = null;
                      
                      if (!Ext.isEmpty(item.gridview)) {
                        transitionNotificationPanel = item.gridview.ownerCt;
                        editorPanel = transitionNotificationPanel.ownerCt.ownerCt.ownerCt;
                      } 

                      var cfg = {
                        isNew : true,
                        id : Ext.id(),
                        groupEpobType : editorPanel.editorData.groupEpobType,
                        transition : item.transition,
                        notificationRecipientName : "",
                        notificationRecipientTyp : "",
                        subject_DE : "",
                        message_DE : "",
                        isJoblist_Active : true,
                        isEMail_Active : true
                      };

                      me.showtransitionNotificationDialog(transitionNotificationPanel, cfg);

                    }
                  }, {
                    text : 'Kopieren',
                    handler : me.showTransferTransitionNotificationDialog,
                    // iconCls : 'xty_pgtoolbar-deleteItems-small',
                    gridview : view,
                    transition : group,
                    app : me

                  }, {
                    text : 'Löschen',
                    handler : me.onDeleteAllNotificationOfATransition,
                    // iconCls : 'xty_pgtoolbar-deleteItems-small',
                    gridview : view,
                    transition : group,
                    app : me
                  } ]
                }).showAt(evt.getXY());
              },
              selectionchange : function(view, selected, eOpts){
                var me = this;
                me.removeGroupSelection();
              }
            },
            getSelection : function() {
              var me = this;
              
              var selection = this.getSelectionModel().getSelection()[0];
              
              if(Ext.isEmpty(selection)){
                  selection = me.selectedGroup;
                  if(!Ext.isEmpty(selection)){
                    selection.selectionTyp = 'Group';
                  }
              }else{
                selection.selectionTyp = 'Row';
              }
              
              return selection;
            },
            removeGroupSelection : function (){
              var me = this;
              
              //Deselektiere die alte Selektion
              if(!Ext.isEmpty(me.selectedGroup)){
                var delgroupHdRow = Ext.get(me.selectedGroup.node);
                var delgroupBodytSibling = Ext.get(delgroupHdRow).dom.nextSibling;
                var delgroupBodyId = delgroupBodytSibling.id;
                var delgroupBody = Ext.get(delgroupBodyId);
                
                if(!Ext.isEmpty(delgroupBody)){
                  delgroupHdRow.removeCls('x-grid-group-hd-collapsed');
                  delgroupHdRow.removeCls('xty_groupHdRow-selected');
                  delgroupBody.removeCls('xty_grid-group-body-selected');
                }
                me.selectedGroup = null;
              }
            }
            
          });
          

          // ############################################### objecteTab Items
          // ###############################################
          
          var objecteTabProduktPanelCfg = {
            xtype : 'form',
            title : 'Produkte',
            itemId : 'objecteTabProduktPanelCfg',
            collapsible : true,
            defaults : boxDefaults,
            items : [ {
              xtype : 'combo',
              fieldLabel : 'Varianten',
              name : 'Variablen',
              editable : false,
              store : [ 'mit Varianten', 'ohne Varianten', 'nur Varianten' ],
              autoSelect : true,
              forceSelection : true
            }, {
              xtype : 'displayfield',
              value : '<b>Status:</b>'
            }, {
              xtype : 'combo',
              fieldLabel : 'WFOne',
              name : 'WFOne',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            }, {
              xtype : 'combo',
              fieldLabel : 'nach Status',
              name : 'nachStatus',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            }, {
              xtype : 'displayfield',
              value : '<b>Verantwortliche:</b>'
            }, {
              xtype : 'combo',
              fieldLabel : '[WFRole_2]',
              name : 'WFRole_2',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            } ]
          };

          var objecteTabPicsPanelCfg = {
            xtype : 'form',
            title : 'Bilder',
            itemId : 'objecteTabPicsPanelCfg',
            collapsible : true,
            defaults : boxDefaults,
            items : [ {
              xtype : 'displayfield',
              value : '<b>Verantwortliche:</b>'
            }, {
              xtype : 'combo',
              fieldLabel : '[WFRole_2]',
              name : 'WFRole_2',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            } ]
          };

          var objecteTabGrafPanelCfg = {
            xtype : 'form',
            title : 'Grafiken',
            itemId : 'objecteTabGrafPanelCfg',
            collapsible : true,
            defaults : boxDefaults,
            items : [ {
              xtype : 'displayfield',
              value : '<b>Verantwortliche:</b>'
            }, {
              xtype : 'combo',
              fieldLabel : '[WFRole_2]',
              name : 'WFRole_2',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            } ]
          };

          var objecteTabTextPanelCfg = {
            xtype : 'form',
            title : 'Grafiken',
            itemId : 'objecteTabTextPanelCfg',
            collapsible : true,
            defaults : boxDefaults,
            items : [ {
              xtype : 'displayfield',
              value : '<b>Verantwortliche:</b>'
            }, {
              xtype : 'combo',
              fieldLabel : '[WFRole_2]',
              name : 'WFRole_2',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            } ]
          };

          var objecteTabDocumentPanelCfg = {
            xtype : 'form',
            title : 'Dokumente',
            itemId : 'objecteTabDocumentPanelCfg',
            collapsible : true,
            defaults : boxDefaults,
            items : [ {
              xtype : 'displayfield',
              value : '<b>Verantwortliche:</b>'
            }, {
              xtype : 'combo',
              fieldLabel : '[WFRole_2]',
              name : 'WFRole_2',
              editable : false,
              store : [ 'V1', 'V2' ],
              autoSelect : true,
              forceSelection : true
            } ]
          };

          var graphId = Ext.id();
          
          var wfEditorSubTabsPanelCfg = {
            xtype : 'tabpanel',
            itemId : 'editorSubTabsPanel',
            border : false,
            margin : '0 0 0 0',
            cls : 'xty_wfEditorTabPanel',
            activeTab : 0,
            tabBar : {
              cls : 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl'
            },
            defaults : { // defaults for tab-panels
              border : false,
              autoScroll : true,
              height : me.getEditorSubTabHeight(),
              defaults : { // defaults for boxes
                xtype : 'form',
                width : 580,
                margin : '24 24 24 24',
                defaults : { // defaults for box-items
                  labelWidth : 180,
                  width : 380,
                  msgTarget : 'side',
                  xtype : 'textfield',
                  margin : '4 0 4 4'
                }
              }
            },
            items : [
                     {
                       title : 'Stammdaten',
                       itemId : 'masterDataTab',
                       hidden : false,
                       items : [ wfMetadataPanelCfg, changeInfoPanelCfg ]
                     },
                     {
                       title : 'Ablaufplan',
                       itemId : 'graphTab',
                       hidden : !isWorkflow,
                       items : [ {
                         html:'<div id="'+graphId+'" style="width:100%; height:100%;"></div>',
                         divId: graphId,
                         layout: 'fit',
                         margin : '0 0 0 0',
                         width:'100%',
                         height: '100%', 
                         border:false,
                         renderTo: Ext.getBody(),  
                         autoCreateViewPort:false
                       } ]
                     },
                     {
                       title : 'Zustände',
                       itemId : 'stateTab',
                       hidden : true, // Tab wird eventuell durch den Ablaufplan ersetzt 
                       items : [ wfStatePanel ]
                     },
                     {
                       title : 'Benachrichtigungen',
                       itemId : 'transitionNotificationTab',
                       hidden : !isWorkflow,
                       items : [ transitionNotificationTabPanel ]
                     },
                     {
                       title : 'Objekte',
                       itemId : 'objecteTab',
                       hidden : !isWorkflowInHierachy,
                       items : [ objecteTabProduktPanelCfg, objecteTabPicsPanelCfg, objecteTabGrafPanelCfg,
                                objecteTabTextPanelCfg, objecteTabDocumentPanelCfg ]
                     } ]
          };
          
          
          var tooltipNewVersion = "Neue Version";
          if(!editorData.isActive){
            tooltipNewVersion += "<br/>Kann nur auf gestarteten Workfows erstellt werden";
          }
          if(!Ext.isEmpty(editorData.currentWorkflow) && editorData.currentWorkflow.data.version !== editorData.version){
            tooltipNewVersion += "<br/>Kann nur auf der neusten Version des Workfows erstellt werden";
          }
          
          var wfEditorPagetoolbarButtons = [ {
            itemId : 'save',
            tooltip : 'Speichern',
            handler : me.onSave,
            app : me
          }, {
            itemId : 'start',
            tooltip : 'Starten ',
            hidden: !isWorkflow,
            disabled: editorData.isNew || editorData.isActive,
            handler : function(button, e){
              var me = button.app;
              
              var westPan = extVia.regApp.myRaster.getWest();
              var workflowsGridStore = westPan.getComponent("panel_mwTabs").getComponent("workflowsList").getComponent("workflowsGrid").store;

              var myrecord = null;
              workflowsGridStore.data.items.forEach(function(ArrayElement) {
                if (ArrayElement.data.id.toString() === editorData.id.toString()) {
                  myrecord = ArrayElement;
                }
              });
              myrecord.set("status", "Yes");
              
//              button.hide();
//              button.ownerCt.getComponent('stop').show();
              
//              var startButton = button.ownerCt.getComponent('versioning-create');
//              startButton.enable();

//              var masterDataTab = editorPanel.getComponent('editorSubTabsPanel').getComponent('masterDataTab');
//              var metadataPanel = masterDataTab.getComponent('metadata');
//              metadataPanel.getComponent("started").setValue("Ja");
              
              var tab = button.ownerCt.ownerCt.ownerCt;
              var stab = tab.ownerCt;
              stab.remove(tab.itemId);
              me.loadEditor(myrecord, myrecord.get("epobType"));
              
              
//              console.log(editorPanel.getDockedItems()[0]);
//              editorPanel.getComponent("IsActiveLabelBar").getComponent("IsActiveLabel").setIconCls('xty_icon xty_iconYes');
            },
            app : me
          }, 
//          {
//            itemId : 'stop',
//            tooltip : 'Stoppen ',
//            
//            hidden: !editorData.isActive,
//            
//            
//            handler : me.onSave,
//            app : me
//          },  
          {
            itemId : 'versioning-create',
            tooltip : tooltipNewVersion,
            disabled: !editorData.isActive || editorData.currentWorkflow.data.version !== editorData.version,
            hidden: !isWorkflow,
            handler : function(button, e){
              var me = button.app;
          
              var version = editorData.version;
              var newRecord = record.copy();
              newRecord.isSaved = false;
              newRecord.store = record.store;
              newRecord.set("id", Ext.id());
              newRecord.set("version", (parseInt(version, null)+1));
              newRecord.set("status", "No");
              
              //var newRecordArray = record.store.add(newRecord.data);
              
              button.disable();
              
              me.loadEditor(newRecord, newRecord.get("epobType"));


//              var westPan = extVia.regApp.myRaster.getWest();
//              var workflowsGrid = westPan.getComponent("panel_mwTabs").getComponent("workflowsList").getComponent("workflowsGrid");
//              var grouping = workflowsGrid.features[0];
//              grouping.disable();
//              grouping.enable();
              
            },
            app : me

          }, '|', {
            xtype : 'button', //'splitbutton',
            itemId : 'state',
            tooltip : 'Zustand hinzufügen' + (editorData.isActive ?'<br> Sie müssen erst eine neue Version erstellen':''),
            disabled: editorData.isActive,
            handler : me.onNewState,
            hidden : !isWorkflow,
            app : me
//            menu : {
//              items : [ {
//                text : 'Zustand hinzufügen (Zeile)',
//                handler : me.onAddState,
//                iconCls : 'xty_pgtoolbar-addItem-small',
//                app : me
//              }, {
//                text : 'Bearbeiten',
//                handler : me.onEditState,
//                iconCls : 'xty_pgtoolbar-edit-small',
//                app : me
//              }, {
//                text : 'Löschen',
//                handler : me.onDeleteState,
//                iconCls : 'xty_pgtoolbar-delete-small',
//                app : me
//              } ]
//            }
          }, {
            xtype : 'button', //'splitbutton',
            itemId : 'comment',
            tooltip : 'Benachrichtigung hinzufügen', //+ (editorData.isActive ?'<br> Sie müssen erst eine neue Version erstellen':''),
            //disabled: editorData.isActive,
            handler : me.onAddTransitionNotification,
            hidden : !isWorkflow,
            app : me
//            menu : {
//              items : [ {
//                text : 'Benachrichtigung bearbeiten',
//                handler : me.onEditTransitionNotification,
//                iconCls : 'xty_formbutton-clear',
//                app : me
//              }, {
//                text : 'Benachrichtigung löschen',
//                handler : me.onDeleteTransitionNotification,
//                iconCls : 'xty_formbutton-clear',
//                app : me
//              } ]
//            }
          } ];
          this.wfEditorPagetoolbarButtons = wfEditorPagetoolbarButtons;
          
          var wfEditorAppbar = extVia.ui.page.pagejob.getApplicationBar({
            itemId : 'IsActiveLabelBar',
            pgjobDscr : pgjobDscr,
            epobDscr : editorData.name + ((isWorkflow && editorData.version !== "1")?" ("+editorData.version+")":""),
            pgjobButtons : [{
              itemId : 'IsActiveLabel',
              tooltip : 'Hallo',
              height:24,
              iconCls : 'xty_icon xty_icon'+(editorData.isActive?"Yes":"No"),
              scale : extVia.constants.raster.pagetoolbarCenterBtnScale
            }],
            pagetoolbarButtons : wfEditorPagetoolbarButtons
          });

          me.wfEditorAppbar = wfEditorAppbar;
 
          var wfEditorPanel = {
            title : editorData.name + ((isWorkflow && editorData.version !== "1")?" ("+editorData.version+")":""),
            editorData : editorData,
            itemId : editorData.id,
            closable : true,
            tbar : wfEditorAppbar,
            items : [ wfEditorSubTabsPanelCfg ],
            getWfEditorAppbar : function(){
              
              //console.log(wfEditorAppbar.getComponent('IsActiveLabel'));
              
              return wfEditorAppbar;
            }
          };
          me.wfEditorPanel = wfEditorPanel;

          tabPanCenter.addAndActivate(wfEditorPanel);
          window.initGraphCreator(graphId);
        }; // eo loadEditor

      }
    });

/*
 * 
 * $Revision: 1.89.6.2 $ $Modtime: 10.10.12 12:39 $ $Date: 2019/08/20 11:50:32 $ $Author: student $ $viaMEDICI Release: 3.9 $
 * 
 */
