Ext.namespace('extVia.baseproto.subarea.main');
/**
 * @class extVia.baseproto.subarea.main
 * Provides ui + data + models + stores + views<br>
 * May run as subApp.
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2012/10/25 10:52:53 $
 *            $Revision: 1.1 $
 */

extVia.baseproto.subarea.main = function(config){
  Ext.apply(this,config,{    
    id          : "extVia.baseproto.subarea.main",
    name        : "extVia.baseproto.subarea.main"
  });
};
    
extVia.baseproto.subarea.main.prototype = {
		
/**
 * 
 * @param some
 * @returns }
 */
  getSomeThing : function getSomeThing(some){
	  var thing = {}
	  return thing;
  }
  
  
};

//init Object as singleton
extVia.baseproto.subarea.main = new extVia.baseproto.subarea.main();


/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2012/10/25 10:52:53 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 