/*


*/
Ext.application({
    name: 'publicationsApp',
    
    /**
     * Place 
     */
    appMode:{},


    
    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)), //7 days from now
    	}));
    	
    	extVia.regApp = this;

    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside


    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true,hidesNorth:true,hidseWest:true, modulxDscr:'Publications', showMenubar : false});
    	extVia.ui.page.raster.onReady(this);



    	var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight()-28;// tabstrip
    	var mainContentPanelWidth =  extVia.regApp.myRaster.getCenter().getWidth();// tabstrip
    	
    	

    	var hierachiesItemsHeight =  (mainContentPanelHeight)/2;
    	
    	var qStr = location.href.replace(/.[^\?]*\?/,'');
    	var urlParams = Ext.Object.fromQueryString(qStr);
    	
    	if (urlParams.nofake){}
    	else{Ext.getBody().addCls('xty_fake-bin');}
        
        
    	var westTabPan  =  extVia.regApp.myRaster.initWestTabPanel(
	    		{
	    	    	activeTab:'publicationsAccess',
	    	    	items:[ 
	    	    	        //extVia.query.statics.getQueryTabCfg(),
    	    	            //extVia.hierarchy.statics.getHierarchyTabCfg({}),	  
	    	    	        //extVia.publications.statics.getQueryCfg({}),
	    	    	      
	    	    	        extVia.publications.statics.getPublicationsAccessCfg({}),
	    	    	        //extVia.publications.statics.getCSVCfg({}),

	    	    	        ]
	    		}); 	    
    	extVia.regApp.westTabPan = extVia.regApp.myRaster.addToWest(westTabPan);

    	//var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel({height:mainContentPanelHeight,html:'<object style="width:100%;height:auto;overflow:scroll;"  data="productplannerFLOW.svg" type="image/svg+xml"></object>'});
    	//var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel({height:mainContentPanelHeight,html:'<img  height="700px"   src="productplannerFLOW.svg" alt="">'});

    	var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel({items:[extVia.publications.statics.getFLOWChart({epobDscr:'Katalog Fr�hjahr'})]});
    	
    	
    	
    	extVia.regApp.centerTabPan = extVia.regApp.myRaster.addToCenter(centerTabPan);

    	//extVia.publications.statics.initClickDetector();
    	
    	//extVia.regApp.centerTabPan = extVia.regApp.myRaster.addToNorth({text:'halli'});
    	Ext.get('drop-zone-text').hide();
    	Ext.get('dnd_drop_zone').hide();
    	
    	
    	
    	
    }
});




/*
 * 
 * $Revision: 1.8 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2014/03/14 10:53:53 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
