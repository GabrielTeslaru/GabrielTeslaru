Ext.namespace('extVia.locales' ,'extVia.camundaForms.locales');
/**
 * @class extVia.camundaForms.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2017/05/15 16:08:44 $
 *            $Revision: 1.2 $
 */



extVia.camundaForms.locale_DE_EN =   { 


  
     nickname: ['Spitzname','Nickname', ''],
     
     
     // basic-booking
     roundTrip:['Rundreise','Round trip',''],
     
     howDoYouLikeYourBurger:['Wie m�chten Sie Ihren Burger?', 'How do you like your burger?', '' ],


     
     //dateFormat:['n/j/Y' , 'n/j/Y', 'n/j/Y']
     
     
     // formats copied from ~/jsp/lty/pg/strings.jsp
	  //extVia.app.setup.
        extDateDscrFormat : [ "d.m.Y", "d/m/Y",''],
        extDateAltFormats : [ "d.m.y|dmy|d.m.|d.m|dmY|j.n.|j.n|j.n.Y|j.n.y", "d/m/y|dmy|d/m/|d/m|dmY|j/n/|j/n|j/n/Y|j/n/y",''],
        decSeparator : [ ",",'.',''], // iboxValidateDecSeparator
        tsSeparator   : [ ".", "", ''] // iboxValidateTsSeparator


     
     // key : ['',''],
    };


extVia.camundaForms.locales = {
        appName:'camundaForms'
};


Ext.Object.each(extVia.camundaForms.locale_DE_EN, function(key, value, myself) {
    extVia.camundaForms.locales[key] = value[extVia.locales.uiLangIsoIx];
});


Ext.apply(extVia.locales, extVia.camundaForms.locales);




/*
 * 
 * $Revision: 1.2 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2017/05/15 16:08:44 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 