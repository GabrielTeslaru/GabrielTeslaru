Ext.define('extVia.assistance.chatbot.View.statics', {
  statics:{
    
  /**
    * Creates a ChatbotButton in the bottom area
    */
   createChatbotButton: function(cfg){
     var me = this; 
     var centerPan = extVia.regApp.myRaster.getCenter();
     var centerRight = centerPan.getEl().getRight();      
     var centerBottom = centerPan.getEl().getBottom();         
     var posX = centerRight-66;     // diff to chatbotpanel posX 312
     var posY = centerBottom-70;  //  diff to chatbotpanel posY 648 

     var chatbotButton;
     chatbotButton = Ext.create('Ext.Button', {
       style:'z-index: 9999; position: absolute; opacssity: 0; border-radius:0px; visibility:hidden;',
       bodyStyle:'font-size:32px;',
       cls:'xty_chatbot-btn hvr-glow',
       //text:' [&middot; &middot;] ',
       //text:'  &#129302;  ', //       text:'  &#129502;  ',
       text:'   ',
       renderTo: Ext.getBody(),
       draggable:{
         listeners:{
           dragend: function(){
             if (me.chatbotPanel){
               var btnPos = chatbotButton.getPosition();
               var panelPos = me.chatbotPanel.getPosition();
               panelPos[0] = btnPos[0]-312;
               panelPos[1] = btnPos[1]-648;
               me.chatbotPanel.setPosition(panelPos, true);
             }
           },
           dragstart: function(){ chatbotButton.isDragged = true;}
         }
       }, 
       enableToggle:true,
       pressedCls:'chatbot-btn-pressed',
       x: posX,
       y: posY,       
       width:48, height:48,
       handler: function(btn) {
         if (!btn.isDragged){
           if (!btn.pressed){ 
             me.chatbotPanel.hideMe();
             btn.setTextDelayed(' ',  false, 50); 
           }
           else{ 
             extVia.assistance.chatbot.Chatbot.statics.startChat(cfg); 
             btn.removeCls('hvr-wobble-vertical'); 
             btn.removeCls('hvr-wobble-horizontal'); 
             btn.setTextDelayed('   ', true, 300);
           }          
         }
         else{
           btn.isDragged = false;
           btn.pressed = !btn.pressed;
         }

       },
       showMe: function(){
         var me = this;
         var btnEl = me.getEl();
         
         btnEl.slideIn('tl',{duration: 2000 , easing: 'elasticIn'  });
//         me.getEl().animate({
//          duration: 500,
//           to: {
//               opacity: 1
//           }
//          });
         
         var lastWobbleDir = 'horizontal';
         var newWobbleDir = 'vertical';
         btnEl.on('mouseenter' ,  function( evt, target){
           if (!me.pressed){
             btnEl.removeCls('hvr-wobble-'+lastWobbleDir); 
             btnEl.addCls('hvr-wobble-'+newWobbleDir); 
             var temp = lastWobbleDir;
             lastWobbleDir = newWobbleDir;
             newWobbleDir = temp;
           }
         });
         
       },
       setTextDelayed: function(text, pressed, delay){
         var btn = this;
         var showChatbotPanelTask2 = new Ext.util.DelayedTask(function(){ 
           if (pressed){
             btn.addCls('xty_chatbot-btn-pressed '); 
           }
           else{
             btn.addCls('hvr-wobble-vertical'); 
             btn.removeCls('xty_chatbot-btn-pressed'); 
           }
           btn.setText(text);
         });
         showChatbotPanelTask2.delay(550); 
       }
    });
     
     chatbotButton.showMe();
     return chatbotButton;
   },
   
   
   
   chatbotPanel: null,
   /**
    * Creates the chatbotPanel 
    */
   createChatbotPanel: function(cfg){
     var me = this; 
     
     var centerPan = extVia.regApp.myRaster.getCenter();
     var centerRight = centerPan.getEl().getRight();   
     var centerBottom = centerPan.getEl().getBottom();       

     var userId = cfg.userId;
     var langISO = cfg.langISO;

     var height = centerPan.getHeight()-222;
     var ifrPanelHeight = height;
     var ifrHeight = height;
     
     var width = 360;
     
     var posX = centerRight - 378;
     //var posY = 208;
     var posY =  centerBottom-718;
     
     var chatbotPanel = me.chatbotPanel;

     if (!chatbotPanel){
     chatbotPanel = Ext.create('Ext.panel.Panel', {
       itemId: 'chatbot-panel',
       draggable:true,
       floating: true, 
       //tools:[{id:'close', handler(event, toolEl, panel){ chatbotPanel.hideMe();}}],
       cls:'xty_chatbot-panel ',
       style:'z-index: 9998;   opacity: 0; visisbility:hidden;',
       renderTo: Ext.getBody(),
       x: posX,
       y: posY,
       height: height,
       width: width,
       showMe: function(){
         var me = this;
         chatbotPanel.getEl().slideIn('br',{duration:500});
         chatbotPanel.getEl().animate({
          duration: 500,
           to: {
               opacity: 1
           }
          });
          var showChatbotPanelTask2 = new Ext.util.DelayedTask(function(){
          //chatbotPanel.getComponent('chatbot-iframe-panel').getEl().dom.firstChild.src = 'https://console.dialogflow.com/api-client/demo/embedded/64e749ac-72bb-4751-81ea-7152cb662e01'  ;
        });
        showChatbotPanelTask2.delay(550); 
       },
       hideMe: function(){
         chatbotPanel.getEl().slideOut('br',{duration:800});
         chatbotPanel.getEl().animate({
          duration: 800,
           to: {
               opacity: 0
           }
          });
       },
       
       
       items : [
       {
        style : 'margin:0;padding:0px;',
        height: ifrPanelHeight,
        width: width,
        itemId : 'chatbot-iframe-panel',
        cls : 'xty_chatbot-iframe-panel',
        xtype : "component",

        html:'<iframe layout="fit" name="chatbotFrame" src="https://console.dialogflow.com/api-client/demo/embedded/64e749ac-72bb-4751-81ea-7152cb662e01" id="chatbot-iframe" class="x-component xty_chatbot-iframe-panel x-component-default" style="margin: 0px; massrgin-top: -110px; padding: 0px; width: 360px; height: '+ifrPanelHeight+'px;" role="presentation" height="'+ifrHeight+'" frameborder="0"></iframe>'
       }
      ]

     });
     me.chatbotPanel = chatbotPanel;
     }
     
     return me.chatbotPanel;
    }
   }
});