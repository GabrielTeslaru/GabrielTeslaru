Ext.namespace('extVia.locales' ,'extVia.fuzzyMerge.locales');
/**
 * @class extVia.fuzzyMerge.locales
 * 
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2017/07/12 15:48:55 $
 *            $Revision: 1.1 $
 */





extVia.fuzzyMerge.locales = {
        appName:'fuzzyMerge',
        modul:'FuzzyMerge',
        pgjobEdit:'bearbeiten'
};




Ext.apply(extVia.locales, extVia.fuzzyMerge.locales);



/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2017/07/12 15:48:55 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 