  ////// start constants ////// 
  // >>> copied from V3.8 14.09.2012 <<<
  Ext.namespace('extVia.module.epob','extVia.app.setup' ,'extVia.constants', 'extVia.constants.raster', 'extVia.module.chart'
  
      ,'extVia.app.setup.appModeNames' , 'extVia.enums.EpimObjects'	, 'extVia.enums.BaseActions'  ,   'extVia.enums.ActionAreas'   
  
      , 'extVia.ui.cmp.factory.component', 'extVia.ui.layout.region', 'extVia.ui.layout.region.Center'  ,'extVia.ui.page.strings.epobs' , 'extVia.ui.dto.ety' , 'extVia.util.main'  
  
  
  );
//>>> copied from V3.9 26.03.2013 <<< 
  extVia.module.epob.ALL=1;
  extVia.module.epob.EPOB=2;
  
//CONTENT AREA     
  extVia.module.epob.CONTENT=1000;
  extVia.module.epob.ELEMENTS=1111;
  extVia.module.epob.IMAGE=1010;
  extVia.module.epob.IMAGEVAR=1011;
  extVia.module.epob.GRAPHIC=1020;
  extVia.module.epob.GRAPHICVAR=1021;
  extVia.module.epob.TEXT=1030;
  extVia.module.epob.TEXTVAR=1031;
  extVia.module.epob.AUDIO=1040;
  extVia.module.epob.AUDIOVAR=1041;
  extVia.module.epob.VIDEO=1050;
  extVia.module.epob.VIDEOVAR=1051;
  extVia.module.epob.DOCUMENT=1060;
  extVia.module.epob.DOCUMENTVAR=1061;
  extVia.module.epob.EDTABLE=1070;
  extVia.module.epob.EDTABLEVAR=1071;
  extVia.module.epob.PRODUCTTABLE=1080;
  extVia.module.epob.SIMPLETEXT=1110;
  extVia.module.epob.CATEGORY=1201;
  extVia.module.epob.MYCATEGORIES=1202;
  extVia.module.epob.CONTENTATTRIBUTE=1250;
  extVia.module.epob.BATCHJOB=1300;
  extVia.module.epob.DICTIONARYENTRY=1350;
  extVia.module.epob.DICTIONARYCATEGORY=1360;
  extVia.module.epob.SELECTION=1370;

//PRODUCTS AREA    
  extVia.module.epob.PRODUCTS=2000;
  extVia.module.epob.PRODUCT=2020;
  extVia.module.epob.PRODUCTGROUP=2030;
  extVia.module.epob.PRODUCTVARIANT=2040;
  extVia.module.epob.PRODUCTANDVARIANT=2050;
  extVia.module.epob.PRODUCTGROUPHITY=2055;
  extVia.module.epob.MYPRODUCT=2060;
  extVia.module.epob.METADATA=7001;
  extVia.module.epob.METADATA_NAME=2021;
  extVia.module.epob.METADATA_ORDERNR=2022;
  extVia.module.epob.METADATA_PRODUCTNR=2023;
  extVia.module.epob.PRODUCTATTRIBUTE=2100;
  extVia.module.epob.ATTRIBUTE=2101;
  extVia.module.epob.PRAT_STRING=2110;
  extVia.module.epob.PRAT_DYNSTRING=2120;
  extVia.module.epob.PRAT_NUMBER=2130;
  extVia.module.epob.PRAT_FLAG=2140;
  extVia.module.epob.PRAT_DATE=2150;
  extVia.module.epob.PRAT_SELECTION=2160;
  extVia.module.epob.PRAT_COLLECTION=2170;
  extVia.module.epob.PRAT_DICTIONARY=2180;
  extVia.module.epob.UNIT=2131;
  extVia.module.epob.COMPARISONOPERATOR=2132;
  extVia.module.epob.PRODUCTGROUPATTRIBUTE=2200;
  extVia.module.epob.PRODUCTPREVIEW=2300;
  extVia.module.epob.PRODUCTPREVIEWDEFINITION=2310;
  extVia.module.epob.PRODUCTASSIGNMENT=2400;
  extVia.module.epob.ELEMENTASSIGNMENT=2430;
  extVia.module.epob.PRODUCTASSIGNMENTTYPE=2410;
  extVia.module.epob.PRODUCTREFERENCE=2450;
  extVia.module.epob.SUPPLIER=2500;
  extVia.module.epob.SUPPLIERBRANCH=2510;
  extVia.module.epob.HIERARCHYTYPE=2600;
  extVia.module.epob.HIERARCHY=2610;
  extVia.module.epob.HIERARCHYNODE=2620;

//PUBLISH AREA     
  extVia.module.epob.PUBLISH=3000;
  extVia.module.epob.PUBLICATION=3010;
  extVia.module.epob.PUUNTEMPLATE_PP=3020;
  extVia.module.epob.PUUNTEMPLATE_SP=3030;

//SYSTEM AREA     
  extVia.module.epob.SYSTEM=4000;
  extVia.module.epob.WF_WORKFLOWGROUP=4010;
  extVia.module.epob.WF_WORKFLOW=4020;
  extVia.module.epob.WF_STATE=4030;
  extVia.module.epob.WF_ROLE=4040;
  extVia.module.epob.WF_RESPONSIBLEPERSON=4050;
  extVia.module.epob.WF_PROCESS=4060;
  extVia.module.epob.WF_STEP=4070;
  extVia.module.epob.WF_TRANSITION=4080;
  extVia.module.epob.QUERY=4440;
  extVia.module.epob.QUERYPARAMS=4441;
  extVia.module.epob.REFERENCE=4450;
  extVia.module.epob.CROSSREFERENCE=4460;
  extVia.module.epob.LANGUAGE=4470;

//USER AREA     
  extVia.module.epob.USERAREA=5000;
  extVia.module.epob.USER=5010;
  extVia.module.epob.ROLE=5020;
  extVia.module.epob.REPORT=5030;
  extVia.module.epob.PROTOCOL=5040;
  extVia.module.epob.USERGROUP=5050;
  extVia.module.epob.JOBLIST=5060;
  extVia.module.epob.BOOKMARK=5070;
  extVia.module.epob.MENUPOINT=5080;
  extVia.module.epob.METRIC=5470;
  extVia.module.epob.CHART=5480;
  extVia.module.epob.METRICHART=5490;
  extVia.module.epob.METRIC_SCHEDULING=5500;
  extVia.module.epob.METRIC_DATA=5510;
  extVia.module.epob.METRIC_GROUP=5520;
  extVia.module.epob.METRIC_ERROR=5530;
  extVia.module.epob.METRIC_CHARTMETRIC=5540;
  extVia.module.epob.DASHBOARD=5550;
  extVia.module.epob.DASHBOARD_TEMPLATE=5560;
  extVia.module.epob.DASHBOARD_WIDGET=5570;
  extVia.module.epob.DASHBOARD_WIDGETTYPE=5580;
  extVia.module.epob.COLLECTION=5700;
  extVia.module.epob.COLLECTION_OBJECT=5710;
  extVia.module.epob.COLLECTION_FILTER=5720;
  extVia.module.epob.COLLECTION_EXPORT_LOG=5730;
  extVia.module.epob.COLLABORATION_RELEASE=5800;
  extVia.module.epob.COLLABORATION_LOG=5810;
  extVia.module.epob.BPM_PROCESS=5910;
  extVia.module.epob.BPM_TASK=5920;  
  
  extVia.module.epob.EXTERNAL_PROCESS=5960;
  extVia.module.epob.EXTERNAL_TASK=5966; 
  extVia.module.epob.EXTERNAL_ACTION=5967; 
  
  /**
   * copied from  extVia.module.epob.util 18.09.201218.09.2012
   * param {@link extVia.module.epob.data#typeId}
   * return {@link extVia.module.epob.data#type} 
   * @param {Number} typeId
   * @return  {String} type 
   */
  extVia.module.epob.getEpobTypeFromTypeId = function(typeId){  
    var prop;
    for (prop in extVia.module.epob) {
      //alert("PropName["+prop+"] val["+extVia.module.epob[prop]+"]")    
      if (extVia.module.epob[prop]===typeId){
        //alert("Das Isser ["+prop+"]\n extVia.module.epob.getNameFromTypeId  extVia.module.epob[prop]["+extVia.module.epob[prop]+"]") 
        return prop;
      }    
    }
  };
  
  extVia.module.epob.getEpobTypeIdFromType = function(type){  
    var prop;
    //alert('getEpobTypeIdFromType  '+type)
    for (prop in extVia.module.epob) {
      if (extVia.module.epob.hasOwnProperty(prop)) {
        if (prop===type.toUpperCase()){  
          //alert("Das Isser ["+prop+"]\n extVia.module.epob.getNameFromTypeId  extVia.module.epob[prop]["+extVia.module.epob[prop]+"]") 
          return extVia.module.epob[prop];
        }  
      }  
    }
  };
  
  extVia.module.epob.getEpobTypeDscrFromTypeId = function(typeId, plusing){  
    if (!plusing){plusing ="S";}
    return extVia.ui.page.strings.epobs["Epob_"+typeId+"_"+plusing];
  }; 
  
  
  /**
   * type means String-Repräsentation
   * @param {} type
   * @param {} plusing
   * @return {}
   */
   extVia.module.epob.getEpobTypeDscrFromType = function(type, plusing){  
      var epobTypeDscr = type;
      if (type){
       var epob = extVia.enums.EpimObjects[type.toUpperCase()];
       if (!epob){
         epob = extVia.enums.EpimObjects['PRAT_'+type.toUpperCase()];
       }
       if (epob){
         epobTypeDscr = extVia.module.epob.getEpobTypeDscrFromTypeId(epob.id, plusing) ;  
       }
      }  
      return epobTypeDscr;
  };  
  
  
  
  
  
  extVia.module.epob.getEpobKeyFromTypeId = function(typeId){  
	    var prop;    
	    for (prop in extVia.enums.EpimObjects) {     
	      if (extVia.enums.EpimObjects.hasOwnProperty(prop) &&  extVia.enums.EpimObjects[prop].id===typeId){
	        return extVia.enums.EpimObjects[prop].key;
	      }    
	    }
	  };
  
 
  extVia.module.epob.getAreaId = function(val){ 
    val = String(val);
    var first= val.substring(0,1);
    return parseInt(first, 10)*1000;
  };
    
  
  extVia.app.setup.appModeNames.useMain=0;extVia.app.setup.appModeNames.query=1;extVia.app.setup.appModeNames.queryRun=2;extVia.app.setup.appModeNames.queryLoad=5;extVia.app.setup.appModeNames.queryLoadRun=6;extVia.app.setup.appModeNames.queryExtend=7;extVia.app.setup.appModeNames.queryExtendRun=8;extVia.app.setup.appModeNames.queryHierarchies=9;
  extVia.app.setup.appModeNames.queryWest=11;extVia.app.setup.appModeNames.queryWestRun=12;extVia.app.setup.appModeNames.queryPlanning=13;extVia.app.setup.appModeNames.queryPlanningRun=14;extVia.app.setup.appModeNames.epobLoad=99;extVia.app.setup.appModeNames.spreadsheet=111;
  extVia.app.setup.appModeNames.mediabrowser=200;extVia.app.setup.appModeNames.navi=300;extVia.app.setup.appModeNames.upload=500;extVia.app.setup.appModeNames.welcome=700;extVia.app.setup.appModeNames.widgetrunner=900;extVia.app.setup.appModeNames.msgbus=910;extVia.app.setup.appModeNames.model=920;
  extVia.app.setup.appModeNames.tests=930;extVia.app.setup.appModeNames.tagcloud=940;extVia.app.setup.appModeNames.carousel=950;extVia.app.setup.appModeNames.portal=960;extVia.app.setup.appModeNames.imageprocessor=999;extVia.app.setup.appModeNames.metrics=1220;extVia.app.setup.appModeNames.dashboard=1320;
  
  // extVia.module.chart.BAR="bar";extVia.module.chart.LIN="line";
  // extVia.module.chart.ARE="area";extVia.module.chart.COL="column";
  // extVia.module.chart.PIE="pie";
  
  
  // Copied from ~jsp/lty/pg/enumConstants.jsp     
  
  extVia.constants.raster.mainWestWidth   = 330;
  extVia.constants.raster.appinsideWestWidth  = 600;
  extVia.constants.raster.northHeight   = 44;
  extVia.constants.raster.eastWidth   = 240;
  extVia.constants.raster.mainEastWidthState  = 282;
  extVia.constants.raster.southHeight   = 140;
  extVia.constants.raster.pgPanelMargin   = 24; 
  extVia.constants.raster.pgBoxMargin     = 24;
  extVia.constants.raster.pgjobNavHeight  = 24; 
  extVia.constants.raster.pgjobEditHeight = 64;      
  extVia.constants.raster.pgToolbarNavHeight = 28; 
  extVia.constants.raster.pgToolbarEditHeight= 44;       
  extVia.constants.raster.pagetoolbarCenterBtnScale= 'medium'; 
  
  extVia.constants.raster.appbarHeight= 108; // pgjobEditHeight (64) + pgToolbarEditHeight (44)
  
  
  ////// end constants ////// 
  
  
  
  
  // >>> copied from V3.9 18.01.2013 <<< 
  extVia.ui.dto.ety.BASEELEMENT=1;  extVia.ui.dto.ety.BASEITEM=123;  extVia.ui.dto.ety.BASECONTAINER=124;  extVia.ui.dto.ety.ICON=3;  extVia.ui.dto.ety.ELEMENTGROUP=7;  extVia.ui.dto.ety.FORMPART=4;  extVia.ui.dto.ety.FORM=5;  extVia.ui.dto.ety.FORMBIN=6; 
  extVia.ui.dto.ety.TOOLBAR=8;  extVia.ui.dto.ety.IMAGE=9;  extVia.ui.dto.ety.TOOLMODE=10;  extVia.ui.dto.ety.PANEL=11;  extVia.ui.dto.ety.SLIDER=12;  extVia.ui.dto.ety.FIELDSET=13;  extVia.ui.dto.ety.INPUTTELEMENT=20;  extVia.ui.dto.ety.HIDDEN=21; 
  extVia.ui.dto.ety.INPUTTEXT=22;  extVia.ui.dto.ety.PASSWORD=23;  extVia.ui.dto.ety.DATE=24;  extVia.ui.dto.ety.TEXTAREA=25;  extVia.ui.dto.ety.SELECT=26;  extVia.ui.dto.ety.NUMBERFIELD=27;  extVia.ui.dto.ety.AUTOCOMPLETETEXT=28;  extVia.ui.dto.ety.COMPOSITEFIELD=29; 
  extVia.ui.dto.ety.BUTTONGROUP=30;  extVia.ui.dto.ety.OPTION=31;  extVia.ui.dto.ety.OPTGROUP=32;  extVia.ui.dto.ety.CHECKBOX=33;  extVia.ui.dto.ety.RADIO=34;  extVia.ui.dto.ety.BUTTON=35;  extVia.ui.dto.ety.RIDER=36;  extVia.ui.dto.ety.TOGGLEBUTTON=37; 
  extVia.ui.dto.ety.TREESELECTION=38;  extVia.ui.dto.ety.DICTIONARYAUTOCOMPLETETEXT=39;  extVia.ui.dto.ety.COLORFIELD=40;  extVia.ui.dto.ety.LINK=41;  extVia.ui.dto.ety.PLAINTEXT=42;  extVia.ui.dto.ety.TOPIC=43;  extVia.ui.dto.ety.IFRAME=44;  extVia.ui.dto.ety.TREE=50; 
  extVia.ui.dto.ety.TREECELL=51;  extVia.ui.dto.ety.TREEMENU=52;  extVia.ui.dto.ety.TREEMENUITEM=53;  extVia.ui.dto.ety.MENU=55;  extVia.ui.dto.ety.MENUBAR=56;  extVia.ui.dto.ety.MENUITEM=57;  extVia.ui.dto.ety.CHECKMENUITEM=58;  extVia.ui.dto.ety.GRID=60; 
  extVia.ui.dto.ety.GRIDROW=61;  extVia.ui.dto.ety.GRIDCOLUMN=62;  extVia.ui.dto.ety.SELECTIONMODEL=63;  extVia.ui.dto.ety.GRIDDATA=64;  extVia.ui.dto.ety.CLOUD=68;  extVia.ui.dto.ety.PORTAL=70;  extVia.ui.dto.ety.PORTALCOLUMN=71;  extVia.ui.dto.ety.PORTLET=72; 
  extVia.ui.dto.ety.PORTLETTOOL=73;  extVia.ui.dto.ety.FLEXGRID=80;  extVia.ui.dto.ety.FLEXGRIDROW=81;  extVia.ui.dto.ety.FLEXGRIDCOLUMN=82;  extVia.ui.dto.ety.FLEXGRIDCELL=83;  extVia.ui.dto.ety.SPREADSHEETGRID=84;  extVia.ui.dto.ety.SEPARATOR=91;  extVia.ui.dto.ety.FILL=92; 
  extVia.ui.dto.ety.SPACER=93;  extVia.ui.dto.ety.BREAK=94;  extVia.ui.dto.ety.APPMODE=101;  extVia.ui.dto.ety.MESSAGE=150;  extVia.ui.dto.ety.WINDOW=160;  extVia.ui.dto.ety.NOTIFICATION=170;  extVia.ui.dto.ety.DIALOG=180;  extVia.ui.dto.ety.METRIC=260; 
  extVia.ui.dto.ety.METRICVALUE=261;  extVia.ui.dto.ety.SCHEDULE=262;  extVia.ui.dto.ety.CHART=263;  extVia.ui.dto.ety.METRICHART=264;  extVia.ui.dto.ety.EPIMCHART=265;  extVia.ui.dto.ety.CHARTWIDGET=266;  extVia.ui.dto.ety.PLUGIN=300;  extVia.ui.dto.ety.EVENT=400; 
  extVia.ui.dto.ety.KEY=410;  extVia.ui.dto.ety.MOUSE=420;  extVia.ui.dto.ety.HANDLER=430;  extVia.ui.dto.ety.PUBLISHER=450;  extVia.ui.dto.ety.SUBSCRIBER=455;  extVia.ui.dto.ety.IMAGEPREVIEW=500;  extVia.ui.dto.ety.VIAEDITORWIDGET=501;  extVia.ui.dto.ety.IMAGEPROCESSOR=502; 
  extVia.ui.dto.ety.CHARTPREVIEW=503;  extVia.ui.dto.ety.COLLECTIONLIST=504;  extVia.ui.dto.ety.COLLECTIONEDITOR=505;  extVia.ui.dto.ety.COLLECTIONVIEW=506;  extVia.ui.dto.ety.COLLECTIONTAB=507;  extVia.ui.dto.ety.MINIQUERY=508;  extVia.ui.dto.ety.DASHBOARD=510;  extVia.ui.dto.ety.DASHBOARDCELL=511; 
  extVia.ui.dto.ety.IMAGEEDITOR=600;  extVia.ui.dto.ety.EPOB=700; 
  // >>> copied from V3.9 18.01.2013 <<< 
  
  
  ////// epob strings START //////	
  // >>> copied from V3.9 26.03.2013 <<< 
  // usage Strings
  //  extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_S]  ; // ->  "Audio";   
  
  extVia.ui.page.strings.epobs.Epob_1_S="Alle";
  extVia.ui.page.strings.epobs.Epob_1_P="Alle"; 
  extVia.ui.page.strings.epobs.Epob_2_S="EPIM-Objekt";
  extVia.ui.page.strings.epobs.Epob_2_P="EPIM-Objekte";   
  extVia.ui.page.strings.epobs.Epob_1000_S="Kontent";
  extVia.ui.page.strings.epobs.Epob_1000_P="Kontent";    
  extVia.ui.page.strings.epobs.Epob_1111_S="Element";
  extVia.ui.page.strings.epobs.Epob_1111_P="Elemente";
  extVia.ui.page.strings.epobs.Epob_1010_S="Bild";
  extVia.ui.page.strings.epobs.Epob_1010_P="Bilder";   
  extVia.ui.page.strings.epobs.Epob_1011_S="Bildvariante";
  extVia.ui.page.strings.epobs.Epob_1011_P="Bildvarianten";    
  extVia.ui.page.strings.epobs.Epob_1020_S="Grafik";
  extVia.ui.page.strings.epobs.Epob_1020_P="Grafiken";    
  extVia.ui.page.strings.epobs.Epob_1021_S="Grafikvariante";
  extVia.ui.page.strings.epobs.Epob_1021_P="Grafikvarianten";    
  extVia.ui.page.strings.epobs.Epob_1030_S="Text";
  extVia.ui.page.strings.epobs.Epob_1030_P="Texte";    
  extVia.ui.page.strings.epobs.Epob_1031_S="Textvariante";
  extVia.ui.page.strings.epobs.Epob_1031_P="Textvarianten";    
  extVia.ui.page.strings.epobs.Epob_1040_S="Audio";
  extVia.ui.page.strings.epobs.Epob_1040_P="Audios";    
  extVia.ui.page.strings.epobs.Epob_1041_S="Audiovariante";
  extVia.ui.page.strings.epobs.Epob_1041_P="Audiovarianten";    
  extVia.ui.page.strings.epobs.Epob_1050_S="Video";
  extVia.ui.page.strings.epobs.Epob_1050_P="Videos";    
  extVia.ui.page.strings.epobs.Epob_1051_S="Videovariante";
  extVia.ui.page.strings.epobs.Epob_1051_P="Videovarianten";    
  extVia.ui.page.strings.epobs.Epob_1060_S="Dokument";
  extVia.ui.page.strings.epobs.Epob_1060_P="Dokumente";    
  extVia.ui.page.strings.epobs.Epob_1061_S="Dokumentvariante";
  extVia.ui.page.strings.epobs.Epob_1061_P="Dokumentvarianten";    
  extVia.ui.page.strings.epobs.Epob_1070_S="Redaktionelle Tabelle";
  extVia.ui.page.strings.epobs.Epob_1070_P="Redaktionelle Tabellen";    
  extVia.ui.page.strings.epobs.Epob_1071_S="Redaktionelle Tabellenvariante";
  extVia.ui.page.strings.epobs.Epob_1071_P="Redaktionelle Tabellenvarianten";    
  extVia.ui.page.strings.epobs.Epob_1080_S="Produkttabelle";
  extVia.ui.page.strings.epobs.Epob_1080_P="Produkttabellen";    
  extVia.ui.page.strings.epobs.Epob_1110_S="einfacher Text";
  extVia.ui.page.strings.epobs.Epob_1110_P="einfache Texte";    
  extVia.ui.page.strings.epobs.Epob_1201_S="Kategorie";
  extVia.ui.page.strings.epobs.Epob_1201_P="Kategorien";    
  extVia.ui.page.strings.epobs.Epob_1202_S="Meine Kategorie";
  extVia.ui.page.strings.epobs.Epob_1202_P="Meine Kategorien";    
  extVia.ui.page.strings.epobs.Epob_1250_S="Elementattribut";
  extVia.ui.page.strings.epobs.Epob_1250_P="Elementattribute";    
  extVia.ui.page.strings.epobs.Epob_1300_S="Bildverarbeitung";
  extVia.ui.page.strings.epobs.Epob_1300_P="Bildverarbeitungen";    
  extVia.ui.page.strings.epobs.Epob_1350_S="Wörterbucheintrag";
  extVia.ui.page.strings.epobs.Epob_1350_P="Wörterbucheinträge";    
  extVia.ui.page.strings.epobs.Epob_1360_S="Wörterbuchkategorie";
  extVia.ui.page.strings.epobs.Epob_1360_P="Wörterbuchkategorien";    
  extVia.ui.page.strings.epobs.Epob_1370_S="Auswahl";
  extVia.ui.page.strings.epobs.Epob_1370_P="Auswahl";    
  extVia.ui.page.strings.epobs.Epob_2000_S="Produkt";
  extVia.ui.page.strings.epobs.Epob_2000_P="Produkte";    
  extVia.ui.page.strings.epobs.Epob_2020_S="Produkt";
  extVia.ui.page.strings.epobs.Epob_2020_P="Produkte";    
  extVia.ui.page.strings.epobs.Epob_2030_S="Produktgruppe";
  extVia.ui.page.strings.epobs.Epob_2030_P="Produktgruppen";    
  extVia.ui.page.strings.epobs.Epob_2040_S="Produktvariante";
  extVia.ui.page.strings.epobs.Epob_2040_P="Produktvarianten";    
  extVia.ui.page.strings.epobs.Epob_2050_S="Produkt und Variante";
  extVia.ui.page.strings.epobs.Epob_2050_P="Produkte und Varianten";    
  extVia.ui.page.strings.epobs.Epob_2055_S="Hierarchietyp";
  extVia.ui.page.strings.epobs.Epob_2055_P="Hierarchietypen";    
  extVia.ui.page.strings.epobs.Epob_2060_S="Mein Produkt";
  extVia.ui.page.strings.epobs.Epob_2060_P="Meine Produkte";    
  extVia.ui.page.strings.epobs.Epob_2100_S="Produktattribut";
  extVia.ui.page.strings.epobs.Epob_2100_P="Produktattribute"; 
  extVia.ui.page.strings.epobs.Epob_2101_S="Attribut";
  extVia.ui.page.strings.epobs.Epob_2101_P="Attribute"; 
  extVia.ui.page.strings.epobs.Epob_2110_S="String";
  extVia.ui.page.strings.epobs.Epob_2110_P="Strings";    
  extVia.ui.page.strings.epobs.Epob_2130_S="Zahlenwert";
  extVia.ui.page.strings.epobs.Epob_2130_P="Zahlenwerte";    
  extVia.ui.page.strings.epobs.Epob_2140_S="Kontrollkästchen";
  extVia.ui.page.strings.epobs.Epob_2140_P="Kontrollkästchen";    
  extVia.ui.page.strings.epobs.Epob_2150_S="Datum";
  extVia.ui.page.strings.epobs.Epob_2150_P="Daten";    
  extVia.ui.page.strings.epobs.Epob_2160_S="Auswahl";
  extVia.ui.page.strings.epobs.Epob_2160_P="Auswahl";    
  extVia.ui.page.strings.epobs.Epob_2170_S="Kollektion";
  extVia.ui.page.strings.epobs.Epob_2170_P="Kollektionen";    
  extVia.ui.page.strings.epobs.Epob_2180_S="Wörterbuch";
  extVia.ui.page.strings.epobs.Epob_2180_P="Wörterbücher";    
  extVia.ui.page.strings.epobs.Epob_2200_S="Produktattribut";
  extVia.ui.page.strings.epobs.Epob_2200_P="Produktattribute";    
  extVia.ui.page.strings.epobs.Epob_2300_S="Produktvorschau";
  extVia.ui.page.strings.epobs.Epob_2300_P="Produktvorschauen";    
  extVia.ui.page.strings.epobs.Epob_2310_S="Produktvorschaudefinition";
  extVia.ui.page.strings.epobs.Epob_2310_P="Produktvorschaudefinitionen";    
  extVia.ui.page.strings.epobs.Epob_2400_S="Produktbeziehung";
  extVia.ui.page.strings.epobs.Epob_2400_P="Produktbeziehungen";  
  extVia.ui.page.strings.epobs.Epob_2401_S="in Beziehung stehende Produkt";
  extVia.ui.page.strings.epobs.Epob_2401_P="in Beziehung stehende Produkt";  
  extVia.ui.page.strings.epobs.Epob_2410_S="Produktbeziehungstyp";
  extVia.ui.page.strings.epobs.Epob_2410_P="Produktbeziehungstypen";    
  extVia.ui.page.strings.epobs.Epob_2450_S="Produktreferenz";
  extVia.ui.page.strings.epobs.Epob_2450_P="Produktreferenzen";    
  extVia.ui.page.strings.epobs.Epob_2500_S="Verkäufer";
  extVia.ui.page.strings.epobs.Epob_2500_P="Verkäufer";    
  extVia.ui.page.strings.epobs.Epob_2510_S="Verkäuferbranche";
  extVia.ui.page.strings.epobs.Epob_2510_P="Verkäuferbranchen";    
  extVia.ui.page.strings.epobs.Epob_2600_S="Hierarchietyp";
  extVia.ui.page.strings.epobs.Epob_2600_P="Hierarchietypen";    
  extVia.ui.page.strings.epobs.Epob_2610_S="Hierarchie";
  extVia.ui.page.strings.epobs.Epob_2610_P="Hierarchien";    
  extVia.ui.page.strings.epobs.Epob_2620_S="Hierarchieknoten";
  extVia.ui.page.strings.epobs.Epob_2620_P="Hierarchieknoten";    
  extVia.ui.page.strings.epobs.Epob_3000_S="Publizieren";
  extVia.ui.page.strings.epobs.Epob_3000_P="Publizieren";    
  extVia.ui.page.strings.epobs.Epob_3010_S="Publikation";
  extVia.ui.page.strings.epobs.Epob_3010_P="Publikationen";    
  extVia.ui.page.strings.epobs.Epob_3020_S="Produktplanung";
  extVia.ui.page.strings.epobs.Epob_3020_P="Produktplanungen";    
  extVia.ui.page.strings.epobs.Epob_3030_S="Strukturplanung";
  extVia.ui.page.strings.epobs.Epob_3030_P="Strukturplanungen";    
  extVia.ui.page.strings.epobs.Epob_4000_S="System";
  extVia.ui.page.strings.epobs.Epob_4000_P="Systeme";    
  extVia.ui.page.strings.epobs.Epob_4010_S="Workflow-Gruppe";
  extVia.ui.page.strings.epobs.Epob_4010_P="Workflow-Gruppen";    
  extVia.ui.page.strings.epobs.Epob_4020_S="Workflow";
  extVia.ui.page.strings.epobs.Epob_4020_P="Workflows";    
  extVia.ui.page.strings.epobs.Epob_4030_S="Status";
  extVia.ui.page.strings.epobs.Epob_4030_P="Stati";    
  extVia.ui.page.strings.epobs.Epob_4040_S="Rolle";
  extVia.ui.page.strings.epobs.Epob_4040_P="Rollen";    
  extVia.ui.page.strings.epobs.Epob_4050_S="Verantwortlicher";
  extVia.ui.page.strings.epobs.Epob_4050_P="Verantwortliche";    
  extVia.ui.page.strings.epobs.Epob_4060_S="Prozess";
  extVia.ui.page.strings.epobs.Epob_4060_P="Prozesse";    
  extVia.ui.page.strings.epobs.Epob_4070_S="Stufe";
  extVia.ui.page.strings.epobs.Epob_4070_P="Stufen";    
  extVia.ui.page.strings.epobs.Epob_4080_S="Übergang";
  extVia.ui.page.strings.epobs.Epob_4080_P="Übergänge";    
  extVia.ui.page.strings.epobs.Epob_4440_S="Suche";
  extVia.ui.page.strings.epobs.Epob_4440_P="Suchen";    
  extVia.ui.page.strings.epobs.Epob_4441_S="Suchparameter";
  extVia.ui.page.strings.epobs.Epob_4441_P="Suchparameter";    
  extVia.ui.page.strings.epobs.Epob_4450_S="Referenz";
  extVia.ui.page.strings.epobs.Epob_4450_P="Referenzen";    
  extVia.ui.page.strings.epobs.Epob_4460_S="Crossreferenz";
  extVia.ui.page.strings.epobs.Epob_4460_P="Crossreferenzen"; 
  extVia.ui.page.strings.epobs.Epob_4470_S="Sprache";
  extVia.ui.page.strings.epobs.Epob_4470_P="Sprachen"; 
  extVia.ui.page.strings.epobs.Epob_5000_S="Benutzerumgebung";
  extVia.ui.page.strings.epobs.Epob_5000_P="Benutzerumgebungen";    
  extVia.ui.page.strings.epobs.Epob_5010_S="Benutzer";
  extVia.ui.page.strings.epobs.Epob_5010_P="Benutzer";    
  extVia.ui.page.strings.epobs.Epob_5020_S="Rolle";
  extVia.ui.page.strings.epobs.Epob_5020_P="Rollen";    
  extVia.ui.page.strings.epobs.Epob_5030_S="Bericht";
  extVia.ui.page.strings.epobs.Epob_5030_P="Berichte";    
  extVia.ui.page.strings.epobs.Epob_5040_S="Protokoll";
  extVia.ui.page.strings.epobs.Epob_5040_P="Protokolle";    
  extVia.ui.page.strings.epobs.Epob_5050_S="[EpobUSERGROUP_S]";
  extVia.ui.page.strings.epobs.Epob_5050_P="[EpobUSERGROUP_P]";    
  extVia.ui.page.strings.epobs.Epob_5060_S="[EpobJOBLIST_S]";
  extVia.ui.page.strings.epobs.Epob_5060_P="[EpobJOBLIST_P]";    
  extVia.ui.page.strings.epobs.Epob_5070_S="[EpobBOOKMARK_S]";
  extVia.ui.page.strings.epobs.Epob_5070_P="[EpobBOOKMARK_P]";    
  extVia.ui.page.strings.epobs.Epob_5080_S="[EpobMENUPOINT_S]";
  extVia.ui.page.strings.epobs.Epob_5080_P="[EpobMENUPOINT_P]";    
  extVia.ui.page.strings.epobs.Epob_5470_S="Kennzahl";
  extVia.ui.page.strings.epobs.Epob_5470_P="Kennzahlen";    
  extVia.ui.page.strings.epobs.Epob_5480_S="Diagramm";
  extVia.ui.page.strings.epobs.Epob_5480_P="Diagramme";    
  extVia.ui.page.strings.epobs.Epob_5490_S="Metrikdiagramm";
  extVia.ui.page.strings.epobs.Epob_5490_P="Metrikdiagramme";    
  extVia.ui.page.strings.epobs.Epob_5500_S="Kennzahlplanung";
  extVia.ui.page.strings.epobs.Epob_5500_P="Kennzahlplanungen";    
  extVia.ui.page.strings.epobs.Epob_5510_S="Kennzahl";
  extVia.ui.page.strings.epobs.Epob_5510_P="Kennzahlen";    
  extVia.ui.page.strings.epobs.Epob_5520_S="Kennzahlgruppe";
  extVia.ui.page.strings.epobs.Epob_5520_P="Kennzahlgruppen";    
  extVia.ui.page.strings.epobs.Epob_5530_S="Kennzahlfehler";
  extVia.ui.page.strings.epobs.Epob_5530_P="Kennzahlfehler";    
  extVia.ui.page.strings.epobs.Epob_5540_S="Kennzahl";
  extVia.ui.page.strings.epobs.Epob_5540_P="Kennzahlen";    
  extVia.ui.page.strings.epobs.Epob_5550_S="[EpobDASHBOARD_S]";
  extVia.ui.page.strings.epobs.Epob_5550_P="[EpobDASHBOARD_P]";    
  extVia.ui.page.strings.epobs.Epob_5560_S="[EpobDASHBOARD_TEMPLATE_S]";
  extVia.ui.page.strings.epobs.Epob_5560_P="[EpobDASHBOARD_TEMPLATE_P]";    
  extVia.ui.page.strings.epobs.Epob_5570_S="[EpobDASHBOARD_WIDGET_S]";
  extVia.ui.page.strings.epobs.Epob_5570_P="[EpobDASHBOARD_WIDGET_P]";    
  extVia.ui.page.strings.epobs.Epob_5580_S="[EpobDASHBOARD_WIDGETTYPE_S]";
  extVia.ui.page.strings.epobs.Epob_5580_P="[EpobDASHBOARD_WIDGETTYPE_P]";    
  extVia.ui.page.strings.epobs.Epob_5700_S="Sammlung";
  extVia.ui.page.strings.epobs.Epob_5700_P="Sammlungen";    
  extVia.ui.page.strings.epobs.Epob_5710_S="Sammlungselement";
  extVia.ui.page.strings.epobs.Epob_5710_P="Sammlungselemente";    
  extVia.ui.page.strings.epobs.Epob_5720_S="Sammlungsfilter";
  extVia.ui.page.strings.epobs.Epob_5720_P="Sammlungsfilter";    
  extVia.ui.page.strings.epobs.Epob_5730_S="Exportprotokoll Sammlung";
  extVia.ui.page.strings.epobs.Epob_5730_P="Exportprotokolle Sammlung";    
  extVia.ui.page.strings.epobs.Epob_5800_S="[EpobCOLLABORATION_RELEASE_S]";
  extVia.ui.page.strings.epobs.Epob_5800_P="[EpobCOLLABORATION_RELEASE_P]";    
  extVia.ui.page.strings.epobs.Epob_5810_S="[EpobCOLLABORATION_LOG_S]";
  extVia.ui.page.strings.epobs.Epob_5810_P="[EpobCOLLABORATION_LOG_P]";
    
  extVia.ui.page.strings.epobs.Epob_5910_S="Prozess";
  extVia.ui.page.strings.epobs.Epob_5910_P="Prozesse";
  extVia.ui.page.strings.epobs.Epob_5920_S="Aufgabe";
  extVia.ui.page.strings.epobs.Epob_5920_P="Aufgaben";

  
  extVia.ui.page.strings.epobs.Epob_5960_S="externer Prozess";
  extVia.ui.page.strings.epobs.Epob_5960_P="externe Prozesse";
  extVia.ui.page.strings.epobs.Epob_5966_S="Aktion";
  extVia.ui.page.strings.epobs.Epob_5966_P="Aktionen";

  extVia.ui.page.strings.epobs.Epob_7004_S="Attribut";
  extVia.ui.page.strings.epobs.Epob_7004_P="Attribute";
  
  
  extVia.ui.page.strings.epobs.epobTypes=[
                                          extVia.ui.page.strings.epobs.Epob_1_S,//"Alle";
                                          extVia.ui.page.strings.epobs.Epob_2_S,//"EPIM-Objekt";
                                          extVia.ui.page.strings.epobs.Epob_5700_S,//"Sammlung";
                                          extVia.ui.page.strings.epobs.Epob_1201_S,//"Kategorie";
                                          extVia.ui.page.strings.epobs.Epob_1111_S,//"Element";
                                          extVia.ui.page.strings.epobs.Epob_1010_S,//"Bild";
                                          extVia.ui.page.strings.epobs.Epob_1020_S,//"Grafik";
                                          extVia.ui.page.strings.epobs.Epob_1030_S,//"Text";
                                          extVia.ui.page.strings.epobs.Epob_1040_S,//"Audio";
                                          extVia.ui.page.strings.epobs.Epob_1050_S,//"Video";
                                          extVia.ui.page.strings.epobs.Epob_1060_S,//"Dokument";
                                          extVia.ui.page.strings.epobs.Epob_1070_S,//"Redaktionelle Tabelle";
                                          extVia.ui.page.strings.epobs.Epob_1080_S,//"Produkttabelle";	    
                                          //extVia.ui.page.strings.epobs.Epob_1110_S,//"einfacher Text";	    
                                          extVia.ui.page.strings.epobs.Epob_1201_S,//"Kategorie";
  
                                          extVia.ui.page.strings.epobs.Epob_2000_S,//"Produkte";
                                          extVia.ui.page.strings.epobs.Epob_2020_S,//"Produkt";
                                          extVia.ui.page.strings.epobs.Epob_2030_S,//"Hierarchie";
                                          extVia.ui.page.strings.epobs.Epob_2040_S,//"Produktvariante";
  
                                          extVia.ui.page.strings.epobs.Epob_1350_S,//"Wörterbucheintrag";
  
                                          extVia.ui.page.strings.epobs.Epob_3010_S,//"Publikation";
                                          extVia.ui.page.strings.epobs.Epob_3010_P,//"Publikationen";
  
                                          extVia.ui.page.strings.epobs.Epob_4020_S,//"Workflow";
                                          extVia.ui.page.strings.epobs.Epob_4050_S,//"Verantwortlicher";
                                          extVia.ui.page.strings.epobs.Epob_4450_S,//"Referenz";
                                          extVia.ui.page.strings.epobs.Epob_4470_S,//"Sprache";
                                          extVia.ui.page.strings.epobs.Epob_5480_S,//"Diagramm";
                                          extVia.ui.page.strings.epobs.Epob_5030_S,//"Bericht";
                                          extVia.ui.page.strings.epobs.Epob_5040_S,//"Protokoll";
                                          
                                          extVia.ui.page.strings.epobs.Epob_5960_S//"externer Prozess";
                                          ];
  
  
  extVia.ui.page.strings.epobs.epobTypeIds=[
                                            1,//"Alle";
                                            2,//"EPIM-Objekt";
                                            5700,//"Sammlung";
                                            1201,//"Kategorie";       				// 1
                                            1111,//"Element";							// 2 
                                            1010,//"Bild";
                                            1020,//"Grafik";
                                            1030,//"Text";
                                            1040,//"Audio";
                                            1050,//"Video";
                                            1060,//"Dokument";
                                            1070,//"Redaktionelle Tabelle";
                                            1080,//"Produkttabelle";	    			// 10
                                            //1110,//"einfacher Text";	    
                                            1201,//"Kategorie";
  
                                            2000,//"Produkts";						// 13
                                            2020,//"Produkt";							// 14
                                            2030,//"Hierarchie";
                                            2040,//"Produktvariante";
  
                                            1350,//"Wörterbucheintrag";
  
                                            3010,//"Publikation";
  
                                            4020,//"Workflow";
                                            4050,//"Verantwortlicher";
                                            4450,//"Referenz";
                                            4470,//"Sprache";
                                            5480,//"Diagramm";
                                            5030,//"Bericht";
                                            5040,//"Protokoll";
                                            
                                            5960 //"externer Prozess";
                                            ];
  
  
  ////// epob strings ENDE ////// 
  
  /////////////epob enums START ////////////////////
  //>>> copied from V4.1  17.01.2014 <<< 
  extVia.enums.EpimObjects.NULL={"id":-1,"name":"NULL","key":"Null"};
  extVia.enums.EpimObjects.ALL={"id":1,"name":"ALL","key":"All"};
  extVia.enums.EpimObjects.METADATA={"shortcut":"METADATA","name":"METADATA","id":7001,"key":"Metadata"};
  extVia.enums.EpimObjects.EPOB={"id":2,"name":"EPOB","key":"Epob"};
  extVia.enums.EpimObjects.CONTENT={"id":1000,"name":"CONTENT","key":"Content"};
  extVia.enums.EpimObjects.ELEMENTS={"id":1111,"name":"ELEMENTS","key":"Elements"};
  extVia.enums.EpimObjects.IMAGE={"id":1010,"name":"IMAGE","key":"Image"};
  extVia.enums.EpimObjects.IMAGEVAR={"id":1011,"name":"IMAGEVAR","key":"ImageVar"};
  extVia.enums.EpimObjects.GRAPHIC={"id":1020,"name":"GRAPHIC","key":"Graphic" , female:true};
  extVia.enums.EpimObjects.GRAPHICVAR={"id":1021,"name":"GRAPHICVAR","key":"GraphicVar" , female:true};
  extVia.enums.EpimObjects.TEXT={"id":1030,"name":"TEXT","key":"Text" , male:true};
  extVia.enums.EpimObjects.TEXTVAR={"id":1031,"name":"TEXTVAR","key":"TextVar" , male:true};
  extVia.enums.EpimObjects.AUDIO={"id":1040,"name":"AUDIO","key":"Audio"};
  extVia.enums.EpimObjects.AUDIOVAR={"id":1041,"name":"AUDIOVAR","key":"AudioVar"};
  extVia.enums.EpimObjects.VIDEO={"id":1050,"name":"VIDEO","key":"Video"};
  extVia.enums.EpimObjects.VIDEOVAR={"id":1051,"name":"VIDEOVAR","key":"VideoVar"};
  extVia.enums.EpimObjects.DOCUMENT={"id":1060,"name":"DOCUMENT","key":"Document"};
  extVia.enums.EpimObjects.DOCUMENTVAR={"id":1061,"name":"DOCUMENTVAR","key":"DocumentVar"};
  extVia.enums.EpimObjects.EDTABLE={"id":1070,"name":"EDTABLE","key":"EdTable" , female:true};
  extVia.enums.EpimObjects.EDTABLEVAR={"id":1071,"name":"EDTABLEVAR","key":"EdTableVar" , female:true};
  extVia.enums.EpimObjects.PRODUCTTABLE={"id":1080,"name":"PRODUCTTABLE","key":"ProdTable" , female:true};
  extVia.enums.EpimObjects.PRODTABLE={"id":1080,"name":"PRODTABLE","key":"ProdTable" , female:true};
  extVia.enums.EpimObjects.SIMPLETEXT={"id":1110,"name":"SIMPLETEXT","key":"SimpleText" , male:true};
  extVia.enums.EpimObjects.CATEGORY={"id":1201,"name":"CATEGORY","key":"Category" , female:true};
  extVia.enums.EpimObjects.MYCATEGORIES={"id":1202,"name":"MYCATEGORIES","key":"MyCategories"};
  extVia.enums.EpimObjects.CONTENTATTRIBUTE={"id":1250,"name":"CONTENTATTRIBUTE","key":"Contentattribute"};
  extVia.enums.EpimObjects.BATCHJOB={"id":1300,"name":"BATCHJOB","key":"BatchJob"};
  extVia.enums.EpimObjects.DICTIONARYENTRY={"id":1350,"name":"DICTIONARYENTRY","key":"DictionaryEntry", male:true};
  extVia.enums.EpimObjects.DICTIONARYCATEGORY={"id":1360,"name":"DICTIONARYCATEGORY","key":"DictionaryCategory", female:true};
  extVia.enums.EpimObjects.SELECTION={"id":1370,"name":"SELECTION","key":"Selection" , female:true};
  extVia.enums.EpimObjects.PRODUCTS={"id":2000,"name":"PRODUCTS","key":"Products"};
  extVia.enums.EpimObjects.PRODUCT={"id":2020,"name":"PRODUCT","key":"Product"};
  extVia.enums.EpimObjects.PRODUCTGROUP={"id":2030,"name":"PRODUCTGROUP","key":"Productgroup" , female:true};
  extVia.enums.EpimObjects.PRODUCTVARIANT={"id":2040,"name":"PRODUCTVARIANT","key":"ProductVariant" , female:true};
  extVia.enums.EpimObjects.PRODUCTANDVARIANT={"id":2050,"name":"PRODUCTANDVARIANT","key":"ProductAndVariant"};
  extVia.enums.EpimObjects.PRODUCTGROUPHITY={"id":2055,"name":"PRODUCTGROUPHITY","key":"ProductgroupHity"};
  extVia.enums.EpimObjects.MYPRODUCT={"id":2060,"name":"MYPRODUCT","key":"MyProduct"};
  extVia.enums.EpimObjects.METADATA_NAME={"shortcut":"PROD_NAME","name":"METADATA_NAME","id":2021,"key":"MetadataName"}
  extVia.enums.EpimObjects.METADATA_ORDERNR={"shortcut":"PROD_ORDERNR","name":"METADATA_ORDERNR","id":2022,"key":"MetadataOrderNr"}
  extVia.enums.EpimObjects.METADATA_PRODUCTNR={"shortcut":"PROD_PRODUCTNR","name":"METADATA_PRODUCTNR","id":2023,"key":"MetadataProductNr"}
  extVia.enums.EpimObjects.PRODUCTATTRIBUTE={"id":2100,"name":"PRODUCTATTRIBUTE","key":"Productattribute"};
  extVia.enums.EpimObjects.ATTRIBUTE={"id":2101,"name":"ATTRIBUTE","key":"Attribute"};
  extVia.enums.EpimObjects.PRAT_STRING={"id":2110,"name":"PRAT_STRING","key":"AttributeString" , male:true};
  extVia.enums.EpimObjects.PRAT_NUMBER={"id":2130,"name":"PRAT_NUMBER","key":"AttributeNumber", male:true};
  extVia.enums.EpimObjects.PRAT_FLAG={"id":2140,"name":"PRAT_FLAG","key":"AttributeFlag"};
  extVia.enums.EpimObjects.PRAT_DATE={"id":2150,"name":"PRAT_DATE","key":"AttributeDate"};
  extVia.enums.EpimObjects.PRAT_SELECTION={"id":2160,"name":"PRAT_SELECTION","key":"AttributeSelection" , female:true};
  extVia.enums.EpimObjects.PRAT_COLLECTION={"id":2170,"name":"PRAT_COLLECTION","key":"AttributeCollection" , female:true};
  extVia.enums.EpimObjects.PRAT_DICTIONARY={"id":2180,"name":"PRAT_DICTIONARY","key":"AttributeDictionary"};
  extVia.enums.EpimObjects.PRODUCTGROUPATTRIBUTE={"id":2200,"name":"PRODUCTGROUPATTRIBUTE","key":"Productgroupattribute"};
  extVia.enums.EpimObjects.PRODUCTPREVIEW={"id":2300,"name":"PRODUCTPREVIEW","key":"Productpreview"};
  extVia.enums.EpimObjects.PRODUCTPREVIEWDEFINITION={"id":2310,"name":"PRODUCTPREVIEWDEFINITION","key":"Productpreviewdefinition"};
  extVia.enums.EpimObjects.PRODUCTASSIGNMENT={"id":2400,"name":"PRODUCTASSIGNMENT","key":"ProductAssignment" , female:true};
  extVia.enums.EpimObjects.PRODUCTRELATED={"id":2401,"name":"PRODUCTRELATED","key":"ProductRelated"};
  extVia.enums.EpimObjects.PRODUCTASSIGNMENTTYPE={"id":2410,"name":"PRODUCTASSIGNMENTTYPE","key":"ProductAssignmentType"};
  extVia.enums.EpimObjects.IMAGEASSIGNMENT={"id":1014,"name":"IMAGEASSIGNMENT","key":"ImageAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.IMAGEASSIGNMENTTYPE={"id":1015,"name":"IMAGEASSIGNMENTTYPE","key":"ImageAssignmentType"};
  extVia.enums.EpimObjects.GRAPHICASSIGNMENT={"id":1024,"name":"GRAPHICASSIGNMENT","key":"GraphicAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.GRAPHICASSIGNMENTTYPE={"id":1025,"name":"GRAPHICASSIGNMENTTYPE","key":"GraphicAssignmentType"};
  extVia.enums.EpimObjects.TEXTASSIGNMENT={"id":1034,"name":"TEXTASSIGNMENT","key":"TextAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.TEXTASSIGNMENTTYPE={"id":1035,"name":"TEXTASSIGNMENTTYPE","key":"TextAssignmentType"};
  extVia.enums.EpimObjects.AUDIOASSIGNMENT={"id":1044,"name":"AUDIOASSIGNMENT","key":"AudioAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.AUDIOASSIGNMENTTYPE={"id":1045,"name":"AUDIOASSIGNMENTTYPE","key":"AudioAssignmentType"};
  extVia.enums.EpimObjects.VIDEOASSIGNMENT={"id":1054,"name":"VIDEOASSIGNMENT","key":"VideoAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.VIDEOASSIGNMENTTYPE={"id":1055,"name":"VIDEOASSIGNMENTTYPE","key":"VideoAssignmentType"};
  extVia.enums.EpimObjects.DOCUMENTASSIGNMENT={"id":1064,"name":"DOCUMENTASSIGNMENT","key":"DocumentAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.DOCUMENTASSIGNMENTTYPE={"id":1065,"name":"DOCUMENTASSIGNMENTTYPE","key":"DocumentAssignmentType"};
  extVia.enums.EpimObjects.EDTABLEASSIGNMENT={"id":1074,"name":"EDTABLEASSIGNMENT","key":"EdtableAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.EDTABLEASSIGNMENTTYPE={"id":1075,"name":"EDTABLEASSIGNMENTTYPE","key":"EdtableAssignmentType"};
  extVia.enums.EpimObjects.PRODUCTTABLEASSIGNMENT={"id":1084,"name":"PRODUCTTABLEASSIGNMENT","key":"ProducttableAssignment"};/* not yet extisting epobType 08.05.2014*/
  extVia.enums.EpimObjects.PRODUCTTABLEASSIGNMENTTYPE={"id":1085,"name":"PRODUCTTABLEASSIGNMENTTYPE","key":"ProducttableAssignmentType"};
  extVia.enums.EpimObjects.PRODUCTREFERENCE={"id":2450,"name":"PRODUCTREFERENCE","key":"ProductReference"};
  extVia.enums.EpimObjects.SUPPLIER={"id":2500,"name":"SUPPLIER","key":"Supplier"};
  extVia.enums.EpimObjects.SUPPLIERBRANCH={"id":2510,"name":"SUPPLIERBRANCH","key":"SupplierBranch"};
  extVia.enums.EpimObjects.HIERARCHYTYPE={"id":2600,"name":"HIERARCHYTYPE","key":"Hierarchytype"};
  extVia.enums.EpimObjects.HIERARCHY={"id":2610,"name":"HIERARCHY","key":"Hierarchy", female:true};
  extVia.enums.EpimObjects.HIERARCHYNODE={"id":2620,"name":"HIERARCHYNODE","key":"HierarchyNode"};
  extVia.enums.EpimObjects.PUBLISH={"id":3000,"name":"PUBLISH","key":"Publish"};
  extVia.enums.EpimObjects.PUBLICATION={"id":3010,"name":"PUBLICATION","key":"Publication"};
  extVia.enums.EpimObjects.PUUNTEMPLATE_PP={"id":3020,"name":"PUUNTEMPLATE_PP","key":"Puuntemplate_pp"};
  extVia.enums.EpimObjects.PUUNTEMPLATE_SP={"id":3030,"name":"PUUNTEMPLATE_SP","key":"Puuntemplate_sp"};
  extVia.enums.EpimObjects.SYSTEM={"id":4000,"name":"SYSTEM","key":"System"};
  extVia.enums.EpimObjects.WF_WORKFLOWGROUP={"id":4010,"name":"WF_WORKFLOWGROUP","key":"Workflowgroup"};
  extVia.enums.EpimObjects.WF_WORKFLOW={"id":4020,"name":"WF_WORKFLOW","key":"Workflow"};
  extVia.enums.EpimObjects.WF_STATE={"id":4030,"name":"WF_STATE","key":"WorkflowState"};
  extVia.enums.EpimObjects.WF_ROLE={"id":4040,"name":"WF_ROLE","key":"WorkflowRole"};
  extVia.enums.EpimObjects.WF_RESPONSIBLEPERSON={"id":4050,"name":"WF_RESPONSIBLEPERSON","key":"WorkflowResponsiblePerson"};
  extVia.enums.EpimObjects.WF_PROCESS={"id":4060,"name":"WF_PROCESS","key":"WorkflowProcess"};
  extVia.enums.EpimObjects.WF_STEP={"id":4070,"name":"WF_STEP","key":"WorkflowProcessStep"};
  extVia.enums.EpimObjects.WF_TRANSITION={"id":4080,"name":"WF_TRANSITION","key":"WorkflowTransition"};
  extVia.enums.EpimObjects.TMS_PROCESS={"id":4090,"name":"TMS_PROCESS","key":"TMS_Process"};
  extVia.enums.EpimObjects.QUERY={"id":4440,"name":"QUERY","key":"Query"};
  extVia.enums.EpimObjects.QUERYPARAMS={"id":4441,"name":"QUERYPARAMS","key":"QueryParams"};
  extVia.enums.EpimObjects.REFERENCE={"id":4450,"name":"REFERENCE","key":"Reference"};
  extVia.enums.EpimObjects.CROSSREFERENCE={"id":4460,"name":"CROSSREFERENCE","key":"CrossReference"};
  extVia.enums.EpimObjects.LANGUAGE={"id":4470,"name":"LANGUAGE","key":"Language"};
  extVia.enums.EpimObjects.USERAREA={"id":5000,"name":"USERAREA","key":"Userarea"};
  extVia.enums.EpimObjects.USER={"id":5010,"name":"USER","key":"User" , male:true};
  extVia.enums.EpimObjects.ROLE={"id":5020,"name":"ROLE","key":"Role"};
  extVia.enums.EpimObjects.REPORT={"id":5030,"name":"REPORT","key":"Report"};
  extVia.enums.EpimObjects.PROTOCOL={"id":5040,"name":"PROTOCOL","key":"Protocol"};
  extVia.enums.EpimObjects.USERGROUP={"id":5050,"name":"USERGROUP","key":"Usergroup"};
  extVia.enums.EpimObjects.JOBLIST={"id":5060,"name":"JOBLIST","key":"Jobliste"};
  extVia.enums.EpimObjects.BOOKMARK={"id":5070,"name":"BOOKMARK","key":"Bookmark"};
  extVia.enums.EpimObjects.MENUPOINT={"id":5080,"name":"MENUPOINT","key":"Menupoint"};
  extVia.enums.EpimObjects.METRIC={"id":5470,"name":"METRIC","key":"Metric"};
  extVia.enums.EpimObjects.CHART={"id":5480,"name":"CHART","key":"Chart"};
  extVia.enums.EpimObjects.METRICHART={"id":5490,"name":"METRICHART","key":"MetriChart"};
  extVia.enums.EpimObjects.METRIC_SCHEDULING={"id":5500,"name":"METRIC_SCHEDULING","key":"MetricScheduling"};
  extVia.enums.EpimObjects.METRIC_DATA={"id":5510,"name":"METRIC_DATA","key":"MetricData"};
  extVia.enums.EpimObjects.METRIC_GROUP={"id":5520,"name":"METRIC_GROUP","key":"MetricGroup"};
  extVia.enums.EpimObjects.METRIC_ERROR={"id":5530,"name":"METRIC_ERROR","key":"MetricError"};
  extVia.enums.EpimObjects.METRIC_CHARTMETRIC={"id":5540,"name":"METRIC_CHARTMETRIC","key":"MetricChartMetric"};
  extVia.enums.EpimObjects.DASHBOARD={"id":5550,"name":"DASHBOARD","key":"Dashboard"};
  extVia.enums.EpimObjects.DASHBOARD_TEMPLATE={"id":5560,"name":"DASHBOARD_TEMPLATE","key":"DashboardTemplate"};
  extVia.enums.EpimObjects.DASHBOARD_WIDGET={"id":5570,"name":"DASHBOARD_WIDGET","key":"DashboardWidget"};
  extVia.enums.EpimObjects.DASHBOARD_WIDGETTYPE={"id":5580,"name":"DASHBOARD_WIDGETTYPE","key":"DashboardWidgettype"};
  extVia.enums.EpimObjects.COLLECTION={"id":5700,"name":"COLLECTION","key":"Collection"};
  extVia.enums.EpimObjects.COLLECTION_OBJECT={"id":5710,"name":"COLLECTION_OBJECT","key":"CollectionObject"};
  extVia.enums.EpimObjects.COLLECTION_FILTER={"id":5720,"name":"COLLECTION_FILTER","key":"CollectionFilter"};
  extVia.enums.EpimObjects.COLLECTION_EXPORT={"id":5730,"name":"COLLECTION_EXPORT","key":"CollectionExport"};
  extVia.enums.EpimObjects.COLLABORATION_RELEASE={"id":5800,"name":"COLLABORATION_RELEASE","key":"CollaborationRelease"};
  extVia.enums.EpimObjects.COLLABORATION_LOG={"id":5810,"name":"COLLABORATION_LOG","key":"CollaborationLog"};
  extVia.enums.EpimObjects.BPM_PROCESS={"id":5910,"name":"BPM_PROCESS","key":"BpmProcess"};
  extVia.enums.EpimObjects.BPM_TASK={"id":5920,"name":"BPM_TASK","key":"BpmTask"};
  extVia.enums.EpimObjects.PDK_PROCESS={"id":5930,"name":"PDK_PROCESS","key":"PdkProcess"};
  extVia.enums.EpimObjects.PDK_DETAIL={"id":5940,"name":"PDK_DETAIL","key":"PdkDetail"};
  extVia.enums.EpimObjects.RASTER={"id":6000,"name":"RASTER","key":"Raster"};
  extVia.enums.EpimObjects.RASTER_WEST_REGION={"id":6001,"name":"RASTER_WEST_REGION","key":"RasterWestRegion"};
  extVia.enums.EpimObjects.RASTER_NORTH_REGION={"id":6002,"name":"RASTER_NORTH_REGION","key":"RasterNorthRegion"};
  extVia.enums.EpimObjects.RASTER_EAST_REGION={"id":6003,"name":"RASTER_EAST_REGION","key":"RasterEastRegion"};
  extVia.enums.EpimObjects.RASTER_SOUTH_REGION={"id":6004,"name":"RASTER_SOUTH_REGION","key":"RasterSouthRegion"};
  extVia.enums.EpimObjects.RASTER_CENTER_REGION={"id":6005,"name":"RASTER_CENTER_REGION","key":"RasterCenterRegion"};
  extVia.enums.EpimObjects.QUERY_SET={"id":6006,"name":"QUERY_SET","key":"QuerySet"};
  extVia.enums.EpimObjects.CONTENT_QUERY_SET={"id":6019,"name":"CONTENT_QUERY_SET","key":"ContentQuerySet"};
  extVia.enums.EpimObjects.PRODUCTS_QUERY_SET={"id":6020,"name":"PRODUCTS_QUERY_SET","key":"ProductsQuerySet"};
  extVia.enums.EpimObjects.HIERARCHY_SET={"id":6007,"name":"HIERARCHY_SET","key":"HierarchySet"};
  extVia.enums.EpimObjects.COLLECTION_SET={"id":6008,"name":"COLLECTION_SET","key":"CollectionSet"};
  extVia.enums.EpimObjects.STRUCTURE_SET={"id":6009,"name":"STRUCTURE_SET","key":"StructureSet"};
  extVia.enums.EpimObjects.CROSSREFERENCE_SET={"id":6010,"name":"CROSSREFERENCE_SET","key":"CrossreferenceSet"};
  extVia.enums.EpimObjects.EXPLORER={"id":6011,"name":"EXPLORER","key":"Explorer"};
  extVia.enums.EpimObjects.QUICK_VIEW={"id":6012,"name":"QUICK_VIEW","key":"QuickView"};
  extVia.enums.EpimObjects.EDITOR={"id":6013,"name":"EDITOR","key":"Editor"};
  extVia.enums.EpimObjects.COLLECTION_EDITOR={"id":6014,"name":"COLLECTION_EDITOR","key":"CollectionEditor"};
  extVia.enums.EpimObjects.PRODUCT_EDITOR={"id":6015,"name":"PRODUCT_EDITOR","key":"ProductEditor"};
  extVia.enums.EpimObjects.VIEWER={"id":6016,"name":"VIEWER","key":"Viewer"};
  extVia.enums.EpimObjects.COLLECTION_VIEWER={"id":6017,"name":"COLLECTION_VIEWER","key":"CollectionViewer"};
  extVia.enums.EpimObjects.PRODUCT_VIEWER={"id":6018,"name":"PRODUCT_VIEWER","key":"ProductViewer"};
  /////////////epob enums ENDE ////////////////////
  
  
    

   extVia.enums.BaseActions.CREATE={"id":1,"name":"CREATE","key":"create", "dscr":"erstellen","pastDscr":"erstellt"};
   extVia.enums.BaseActions.INSERT={"id":2,"name":"INSERT","key":"insert", "dscr":"einfügen","pastDscr":"eingefügt"};
   extVia.enums.BaseActions.UPDATE={"id":3,"name":"UPDATE","key":"update", "dscr":"Ändern","pastDscr":"geändert"};
   extVia.enums.BaseActions.DELETE={"id":4,"name":"DELETE","key":"delete", "dscr":"löschen","pastDscr":"gelöscht"};
   extVia.enums.BaseActions.ASSIGN={"id":5,"name":"ASSIGN","key":"assign", "dscr":"zuordnen","pastDscr":"zugeordnet"};
   
   extVia.enums.ActionAreas.METADATA={"id":7001,"name":"METADATA","key":"metadata", "dscr":"Metadaten"};
   extVia.enums.ActionAreas.MASTERDATA={"id":7002,"name":"MASTERDATA","key":"masterdata", "dscr":"Stammdaten"};
   extVia.enums.ActionAreas.WORKFLOWS={"id":7003,"name":"WORKFLOWS","key":"workflows", "dscr":"Workflows"};
   extVia.enums.ActionAreas.ATTRIBUTES={"id":7004,"name":"ATTRIBUTES","key":"attributes", "dscr":"Attribute"};
   extVia.enums.ActionAreas.ATTRIBUTEASSIGNMENTS={"id":7005,"name":"ATTRIBUTEASSIGNMENTS","key":"attributeassignments", "dscr":"Attributszuordnungen"};
   extVia.enums.ActionAreas.ATTRIBUTEVALUES={"id":7006,"name":"ATTRIBUTEVALUES","key":"attributevalues", "dscr":"Attributswerte"};
   extVia.enums.ActionAreas.MEDIAOBJECTS={"id":7015,"name":"MEDIAOBJECTS","key":"mediaobjects", "dscr":"Medienobjekt"};
   extVia.enums.ActionAreas.PREVIEWS={"id":7016,"name":"PREVIEWS","key":"previews", "dscr":"Vorschau"};
   extVia.enums.ActionAreas.ASSIGNMENTS={"id":7017,"name":"ASSIGNMENTS","key":"assignments", "dscr":"Zuordnungen"};
   extVia.enums.ActionAreas.RELATIONS={"id":7018,"name":"RELATIONS","key":"relations", "dscr":"Beziehungen"};
   extVia.enums.ActionAreas.REFERENCES={"id":7019,"name":"REFERENCES","key":"references", "dscr":"Referenzen"};
   
   
   extVia.module.epob.getActionAreaFromArea = function(area){  
   var  actionArea = null;
   
   switch(area) {
    case 'Metadata':
      actionArea =  extVia.enums.ActionAreas.METADATA;
      break;    
    case 'changeinfo':
      actionArea =  extVia.enums.ActionAreas.METADATA;
      break;      
    case 'languages':
      actionArea =  extVia.enums.ActionAreas.METADATA;
      break;
    case 'Workflows':
      actionArea =  extVia.enums.ActionAreas.WORKFLOWS;
      break;       
    case 'masterdata':
      actionArea =  extVia.enums.ActionAreas.MASTERDATA;
      break;       
    case 'Attribute':
      actionArea =  extVia.enums.ActionAreas.ATTRIBUTES;
      break;
    case 'Elemente':
      actionArea =  extVia.enums.ActionAreas.ASSIGNMENTS;
      break;    
    case 'productrelations':
      actionArea =  extVia.enums.ActionAreas.RELATIONS;
      break;        
    case 'variants':
      actionArea =  extVia.enums.ActionAreas.RELATIONS;
      break;        
    case 'Beziehungen':
      actionArea =  extVia.enums.ActionAreas.RELATIONS;
      break;      
    case 'Referenzen':
      actionArea =  extVia.enums.ActionAreas.REFERENCES;
      break;  
    case 'publication':
      actionArea =  extVia.enums.ActionAreas.RELATIONS;
      break;  
    case 'suppliers':
      actionArea =  extVia.enums.ActionAreas.MASTERDATA;
      break;      
    case 'previews':
      actionArea =  extVia.enums.ActionAreas.METADATA;
      break;      
    default:
      actionArea =  extVia.enums.ActionAreas.MASTERDATA;
     
    } 
    return actionArea;
  };
   
   
   
   // Aktion targets
   // metadaten Stammdaten(dictionary), attribut contentobjekt, medienobjekt
  
  
  // >>> copied from V3.9  18.20.2013 <<< 
  extVia.util.main.isPathDefined = function() {
    var tokens, len, i,sPath, root, path;
    if(arguments.length === 1){ sPath  = arguments[0]; root = window;
    }else  if(arguments.length === 2){ sPath  = arguments[1]; root  = arguments[0];
    if(Ext.isEmpty(root)){ return false;}
    }else { return false; } 
    if(!Ext.isString(sPath)){return false; }
    path = root;
    tokens = sPath.split('.');
    len = tokens.length;
    for(i = 0; i < len; i++  ){ path = path[tokens[i]]; if( !Ext.isDefined(path)){ return false;}}
    return true;  
  };
  // >>> copied from V3.9  18.20.2013 ~jsp/lty/pg/strings.jsp <<<   
  Ext.apply(extVia.ui.page.strings,{
    getString :function(key){
      var path = extVia.ui.page.strings;
      if(extVia.util.main.isPathDefined(path,key)){ var  tokens = key.split('.');
      var i; var len;
      for( i = 0, len=  tokens.length ; i < len; i++ ){path = path[tokens[i]];} return path;}  
      else{ return  "Missing key :"+key; }}
  });
  // >>> ENCDE  copied from V3.9  18.20.2013 <<< 
  
  
  
  
  /*
   * 
   * $Revision: 1.37.6.7 $
   * $Modtime: 10.10.12 12:39 $ 
   * $Date: 2019/05/16 09:51:20 $
   * $Author: slederer $
   * $viaMEDICI Release: 3.9 $
   * 
   */     
