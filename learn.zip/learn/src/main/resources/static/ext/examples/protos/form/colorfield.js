/*
Simple Colorfield Example

*/
Ext.require([
    'Ext.form.*',
    'Ext.layout.container.Column'
]);


/*
 */
Ext.onReady(function(){


    Ext.QuickTips.init();

    var bd = Ext.getBody();

    /*
     * ================  Simple form  =======================
     */

    
    var colorCombo = Ext.create('Ext.ux.ColorField', {
    	xtype:'colorfield',
    	fieldLabel: 'Farbe',
    	name: 'color'
    });

    var simple = Ext.create('Ext.form.Panel', {
  	x:100,
        
        frame:true,
        title: 'Simple Form',
        bodyStyle:'padding:5px 5px 0',
        width: 350,
        fieldDefaults: {
            msgTarget: 'side',
            labelWidth: 75
        },
        defaultType: 'textfield',
        defaults: {
            anchor: '100%'
        },

        items: [{
            fieldLabel: 'First Name',
            name: 'first',
            allowBlank:false
        },{
            fieldLabel: 'Last Name',
            name: 'last'
        },{
            fieldLabel: 'Company',
            name: 'company'
        }, {
            fieldLabel: 'Email',
            name: 'email',
            vtype:'email'
        }, {
            xtype: 'timefield',
            fieldLabel: 'Time',
            name: 'time',
            minValue: '8:00am',
            maxValue: '6:00pm'
        }
        
        ,colorCombo

        ],

        buttons: [{
            text: 'Save'
        },{
            text: 'Cancel'
        }]
    });

    simple.render(document.body);

    
    // like  in extVia.ui.cmp.factory.component.createWindow
    var defaultWin = Ext.create('widget.window', {
        heisght: 220,
        width: 400,
        x: 524,
        y: 100,

        title: '{DialogHeader} must be the same as callingElement',
        
        iconCls: 'xty_icon xty-iconInformation',
        
        plain: true,
       
        
        
        
        items : [ {
        	xytpe:'form',
            border : false,
            minHeight : 200,
            bodyStyle : 'padding:5px 5px 0',
            fieldDefaults : {
            // msgTarget : 'side',
            },
            defaults : {
              // anchor : '100%',
              labelWidth : 110,
              width : 350
            },
            items : [
			  
            {xtype:'textfield', fieldLabel: 'eingabe 1',labelSeparator:': *', allowBlank:false},
            {xtype:'textfield', fieldLabel: 'eingabe 2'},
            {xtype:'textfield', fieldLabel: 'eingabe 3'},
            {xtype:'textfield', fieldLabel: 'eingabe 4'},
                     
                     
			Ext.create('Ext.ux.ColorField', {
				xtype:'colorfield',
				fieldLabel: 'Farbe',
				name: 'color'
				})
                     ]
        }
        ],

         buttons:[{xtype:'tbspacer', width:30},{text:'Ja'},{text:'Nein'},{text:'Abbrechen'}]      
    });
    defaultWin.show();
    
});



