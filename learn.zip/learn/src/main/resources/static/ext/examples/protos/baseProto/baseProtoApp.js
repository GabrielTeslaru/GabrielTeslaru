/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

Commercial Usage
Licensees holding valid commercial licenses may use this file in accordance with the Commercial Software License Agreement provided with the Software or, alternatively, in accordance with the terms contained in a written agreement between you and Sencha.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/
Ext.application({
    name: 'baseProtoApp',
    
    appMode:{},
    
	renderText : function(text) {
    	if(text.indexOf('-') >= 0 && text.indexOf('XML-') < 0 
    		&& text.indexOf('DTD-') < 0 && text.indexOf('CSV-') < 0) {
    		return text.replace('-<br />', '');
    	} 
    	return text.replace('<br />', '');
    },
    
    launch: function() {
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) // 7 days from now
    	}));
    	
    	extVia.regApp = this;

    	// this.appMode = extVia.app.setup.appMode; // preconfigured oby Url on javaside
    	
        // NOTE: This is an example showing simple state management. During development,
        // it is generally best to disable state management as dynamically-generated ids
        // can change across page loads, leading to unpredictable results. The developer
        // should ensure that stable state ids are set for stateful components in real apps.
        // Ext.state.Manager.setProvider(Ext.create('Ext.state.CookieProvider'));
	
    	var modulDscr = "BaseProto App";
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true,  modulDscr:modulDscr});
    	extVia.ui.page.raster.onReady(this);
    	
    
    	//var tabPan = extVia.regApp.myRaster.initWestTabPanel({items:[{title:'Liste'}] });
    	//extVia.regApp.myRaster.addToWest(tabPan);
    	
    	tabPan = extVia.regApp.myRaster.initCenterTabPanel();
	    extVia.regApp.myRaster.addToCenter(tabPan); 
	    
	     if(!Ext.isEmpty(localStorage.getItem('pl_target'))) {
	     	var text = localStorage.getItem('pl_target'),
	     		me = this;
			var centerTabs = extVia.regApp.myRaster.getCenterTabPanel();
				centerTabs.removeAll();
				centerTabs.add({
					title : 'Navigationsziel',
					border: false,
					frame : false,
					tbar : extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Men&uuml;eintrag', epobDscr: me.renderText(text)}),
					items : [{
						border : false,
						padding : 20,
						html : '<div style="margin:0 auto;padding:20px;text-align:center;width:100%;font-size:2em;text.align:center;color:#444;">' +
								'Sie haben <i>' +  me.renderText(text) + '</i> erreicht!' +
								'</div>', margin:'24 24 24 24'
					}]
				});
         }
	    
        function getLabelSeparator4Required(){	
            return ':<span class="xty_requiredStar"> *</span>';
        }
        
        function okButtonHandler(button, evt, okMsg){	
        	Ext.example.msg('Button Click', '{0} <br><br> execute instruction', ['OK / Speichern / Erstellen']);
        	button.ownerCt.ownerCt.hide(); 
        }
        function cancelButtonHandler(button, evt){	
        	button.ownerCt.ownerCt.hide();   
        }
        function applyButtonHandler(button, evt, applyMsg){	
        	Ext.example.msg('Button Click', '{0} <br><br> execute instruction', ['&Uuml;bernehmen']);
        }
        
        
      


        
       var showSammlungsDialog =	function getSammlungsDialog(item, cfg){
        	 
        	var sammlungsDialog = Ext.create('widget.window', {
        		title:"Elemente &uuml;bernehmen",
        		y:150,
        		// width:10,
        		// height:10,
        		floating: true,
        		items:[
        		       {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img  src='../img/fakes/collectionWidg.png'/>"}
        		       ]
        	});	
        	sammlungsDialog.show();	
        };
    	
 
	    var storagePageItemId ="storage";
	    

	    var ergebnisDarstellungsPanelCfg = 	 								
	    			{ 
	    		    xtype:'panel',
	    		    tools:[{id:'close',handler:function(){this.ownerCt.ownerCt.ownerCt.hide();}}],
	    		    title:'Einstellungen',
	    		    height:600,
				    layout: {
					        type: 'hbox',
					        padding:'5',
					        align:'middle'
					    },
					    defaults:{margins:'0 5 0 0'},
					    width:420,
					    
					   
					isValid:function(){
						var isValid = this.getComponent('formViewOptions').getForm().isValid() && this.getComponent('formViewType').getForm().isValid();
						return isValid;
					},   
					reset:function(){
						this.getComponent('formViewOptions').getForm().reset();
					    this.getComponent('formViewType').getForm().reset();
					}, 					    
					    
					    items:[  
					          {
					        	xtype:'form', 
					        	itemId:'formViewType',
					 	        frame:true,
					 	        height:120,
					 	        bodyStyle:'padding:5px 5px 0',
					 	        fieldDefaults: {
					 	            msgTarget: 'side'
					 	            // labelWidth: 50
					 	        },
					 	        defaultType: 'radio',
					 	        defaults: {
					 	            anchor: '100%'
					 	        },
								items:[	{
								    xtype: 'radiogroup', 
									itemId:'resultsasRadiogroup',
								    columns: 1,
								    width:140,
								    defaults:{width:200, margins:'0 5 0 50'},
								    items: [
										{boxLabel: 'List', name: 'resultsasRadiogroup', inputValue: 'List'},
								        {boxLabel: 'Tree', name: 'resultsasRadiogroup', inputValue: 'Tree'},
								        {boxLabel: 'Thumbs', name: 'resultsasRadiogroup', inputValue: 'Thumbs' },
								        {boxLabel: 'Thumbs small', name: 'resultsasRadiogroup', inputValue: 'Thumbs small'}
						
								    ]
								} ]
					 	    },           

								{ xtype:'form', 
					 	    	
					 	    	itemId:'formViewOptions',
							 
						        frame:true,
						        height:120,
						        bodyStyle:'padding:5px 5px 0',
						        width: 220,
						        fieldDefaults: {
						            msgTarget: 'side',
						            labelWidth: 85
						        },
						        
						        defaults: {
						            anchor: '100%'
						        },
					
						        items: [
						        { fieldLabel:'some', xtype:'textfield', labelSeparator :getLabelSeparator4Required(),  allowBlank: false},
				            	{
				            	   xtype:'combo', 
				                   hideLabel: false,
				                   width:60,
				                   fieldLabel:'Sprache',
				                   // store: 'languageStore',
				                   store:   Ext.create('Ext.data.ArrayStore', {fields: ['value', 'dscr'], data :  [  ['DE', 'Deutsch'],  ['EN', 'Englisch'], ['FR', 'Franz&ouml;sisch']] }) ,
				                   displayField: 'dscr',
				                   typeAhead: true,
				                   mode: 'local',
				                   triggerAction: 'all',
				                   emptyText:'Deutsch',
				                   selectOnFocus:true
				               },						                
				               {   xtype:'combo', 
				                   hideLabel: false,
				                   width:60,
				                   fieldLabel:'Treffermenge', 		
				                   store:   Ext.create('Ext.data.ArrayStore', {fields: ['value', 'dscr'], data :  [  ['A1', '5'],  ['B2', '10'], ['C3', '20']] }) ,	 							               
				                   displayField: 'dscr',
				                   typeAhead: true,
				                   mode: 'local',
				                   triggerAction: 'all',
				                   emptyText:'20',
				                   selectOnFocus:true
				               },
							     { fieldLabel: 'Aufgeklappt', xtype:'checkbox', checked: false },
				                 { fieldLabel: 'Platzierung', xtype:'checkbox' }        
				               ]
							}// eo form Panel2
					       ],// eo ergebnisdarstellungsPanel items
						 
			  	         buttons:{itemId:'myButtons', items:[ 
			  	                            		         {itemId:'reset',text:'Clear', handler:function(){ this.ownerCt.ownerCt.reset();this.ownerCt.ownerCt.isValid();}},
			  	                            		         {itemId:'apply',text:'&Uuml;bernehmen', handler:function(){ 
		  	                            		        		 this.ownerCt.ownerCt.ownerCt.myCaller.setValidity(this.ownerCt.ownerCt.isValid()); 
			  	                            		         }},
			  	                            		         {itemId:'ok',text:'OK' ,
			  	                            		        	 handler:function(){ 
			  	                            		        		 this.ownerCt.ownerCt.ownerCt.myCaller.setValidity(this.ownerCt.ownerCt.isValid()); 
			  	                            		        		 this.ownerCt.ownerCt.ownerCt.hide();
			  	                            		        		 }
			  	                            		            },
			  	                            		         {itemId:'cancel', text:'Abbrechen', handler:function(){ this.ownerCt.ownerCt.ownerCt.hide();}}
			  	          				  	              ] } 
	    			
	    			};// eo ergebnisdarstellungsPanel

	    var editorMainTabItemId = 'epobEditor-epob_1' ;	
	    
	    var editorPagetoolbarButtons = [];    
       	editorPagetoolbarButtons.push(extVia.editor.baseEditor.statics.getSaveButtonCfg(editorMainTabItemId));	

	    
// editorPagetoolbarButtons.push({
// xtype : 'button',
// name : 'new',
// margin : '0 0 0 10',
// tooltip : 'NewEpob',
// iconCls : 'xty_pgtoolbar-new',
// scale : 'large',
// handler:function(){addEpobDialog.show();},
// listeners : {
// }
// });
	    	    
	    editorPagetoolbarButtons.push({
	        xtype : 'button',
	        name : 'clear',
	        margin : '0 0 0 10',
	        tooltip : 'Select All',
	        iconCls : 'xty_pgtoolbar-checkAll',
	        scale : 'large',
            handler:function(){   
              var myMask = new Ext.LoadMask(Ext.get('panel_mC-body'), {msg:'Select All'  });
              myMask.show();},
	        listeners : {
	        }
	      });
	    
	    editorPagetoolbarButtons.push({xtype : 'tbspacer',width:20});
// editorPagetoolbarButtons.push('-');
// editorPagetoolbarButtons.push({
// xtype : 'button',
// name : 'start',
// margin : '0 0 0 5',
// tooltip : 'start',
// iconCls : 'xty_pgtoolbar-start',
// scale : 'large',
// listeners : {
// }
// });
//	    
// editorPagetoolbarButtons.push({
// xtype : 'button',
// name : 'stop',
// margin : '0 0 0 5',
// tooltip : 'stop',
// iconCls : 'xty_pgtoolbar-stop',
// scale : 'large',
// listeners : {
// }
// });
//	    
// editorPagetoolbarButtons.push({
// xtype : 'button',
// name : 'restart',
// cls:'xty_pgtoolbar-larger',
// //style:'width:40px !important;',
// margin : '0 0 0 5',
// tooltip : 'restart',
// iconCls : 'xty_pgtoolbar-restart',
// scale : 'large',
// listeners : {
// }
// });
	    

	    
	    // ,{xtype : 'tbspacer',width:10},'-',{xtype : 'tbspacer',width:10}
	    
	    
	    editorPagetoolbarButtons.push({
	        xtype : 'splitbutton',
	        name : 'newItem',
	        margin : '0 0 0 10',
	        tooltip : 'Neue Komponente',
	        iconCls : 'xty_pgtoolbar-newItem',

	        
	        menu:{
	 			   items:[
	 			          {text:'Freigabe'},
	 			          {text:'Weitergabe'},
	 			          {text:'Notiz'},
	 			          {text:'Projekt'},
	 			          {text:'Meilenstein'},
	 			          
	 			          {text:'aus Sammlungen',menu:{items:[  {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img  src='../img/fakes/collectionWidg.png'/>"}]}  
	 			          }
	 			          ]
	 	    },
	        
	        
	        handler:function(){addEpobDialog.show();},
	        listeners : {
	        }
	      });
	    
	    
	    
	    editorPagetoolbarButtons.push({
	        xtype : 'button',
	        name : 'deleteChecked',
	        margin : '0 0 0 10',
	        tooltip : 'deleteChecked',
	        iconCls : 'xty_pgtoolbar-deleteChecked',

			handler: function(){
				

           var startCounter = function(myMask){
            if (!this.countEl){
              var mask = this;
              mask.startTime =  new Date().getTime();
              mask.count = 0 ;
              var countEl = this.getEl().down('.xty_loadMask-counter');
              this.countEl = countEl;
              var counterRecursiveTask;
              var counterTask = new Ext.util.DelayedTask(function(){
                mask.count+=0.1;
                mask.countEl.dom.innerHTML =  mask.count.toFixed(1) +' sec '  ;
                if (mask.count<120){
                  counterRecursiveTask.delay(100);
                }
                if (mask.count>60){
                  mask.countEl.dom.style="font-size: 32px;background-color:#fa5656;";
                }
                else if (mask.count>30){
                  mask.countEl.dom.style="font-size: 24px;background-color:#fba355;";
                }
                else if (mask.count>20){
                  mask.countEl.dom.style="font-size: 16px;background-color:#fee5b0;";
// var yellow2red_B = 255-(mask.count.toFixed(1)*10);
// var yellow2red = 'background-color:rgb( 255,'+yellow2red_B+', 2);';
// mask.countEl.dom.style=yellow2red;
                }
                else if (mask.count>10){
                  mask.countEl.dom.style="font-size: 14px;background-color:#e5feb0;";
                }
                else if (mask.count>5){
                  mask.countEl.dom.style="font-size: 12px;background-color:#e5feb0;";
                }         
                else if (mask.count>3){
                  mask.countEl.dom.style="background-color:#d9fbdb;";
// var white2Yellow_B = 255-(mask.count.toFixed(1)*10);
// var white2Yellow = 'background-color:rgb( 255,255, '+white2Yellow_B+');'
// mask.countEl.dom.style=white2Yellow;
                }
                
              });
              counterRecursiveTask = counterTask;
              counterTask.delay(100);
            }
          };
          var logCounter =function(){    
            var mask = this;
            mask.endTime =  new Date().getTime();
            
            var duration = (mask.endTime - mask.startTime ) /1000 + ' sec' ;
            // alert("Dauer "+duration);
// extVia.util.Log.showNotification({
// status : "Waiting",
// title : 'Dauer',
// html :''+duration
// });
                
               
                
          };
          
       
        Ext.LoadMask.prototype.startCounter = startCounter;
        Ext.LoadMask.prototype.listeners={
	      show : function(mask){
		      var maskEl = mask.getEl().down('.x-mask-loading');
		      maskEl.dom.innerHTML =  maskEl.dom.innerHTML +'<br><span class="xty_loadMask-counter" style=""></span>';
		      mask.startCounter(mask);
	      },
          hide: function(mask){ mask.logCounter(); }
        };
        
        
		var myMask = new Ext.LoadMask(Ext.get('panel_mC-body'), {msg:'Delete Checked'  });
		myMask.show(myMask);

			},
	        listeners : {
	        }
	      });

	    editorPagetoolbarButtons.push({
	        xtype : 'button',
	        name : 'dropbox',
	        margin : '4 0 0 4',
	        tooltip : 'dropbox',
	        iconCls : 'xty_pgtoolbar-dropbox',


	        handler:function(button){
	        	
	        	
	        	document.getElementById("dropboxjs").setAttribute("data-app-key","");  // ??

	        	button.ownerCt.ownerCt.ownerCt.getComponent(editorMainTabItemId).setActiveTab(4);

	        	var dropboxOptions = {
	        		    linkType: "preview" ,// or "direct",
	        		                // "preview" (default) is a preview link to the document for sharing,
	        		                // "direct" is an expiring link to download the contents of the file.
	        		                // For more information about link types, see <a href="#link-types">Link types</a>
	        		    multiselect: true, // or false,
	        		                // false (default) limits selection to a single file,
	        		                // true enables multiple file selection.
	        		    success: function(files) {
	        		                // Required. Called when a user selects an item in the Chooser
                                    var i;
	        		                for (i =0; i < files.length && i < 50; i++){
	                      	    	   var link = '<a href ="'+files[i].link+'" target="_blank">'+files[i].link+'</a>';

                                      // var link = '<div><img style="height:120px" src="'+files[i].link+'" /></div>';
                                       var emptyStr = '';
	                      	    	   var search = Ext.create('Search', {name: emptyStr+link});
	                      	    		// uses the configured LocalStorageProxy to save the new Search to localStorage
	                      	    		search.save(); 
	        		                }
                      	    		Ext.data.StoreManager.lookup('localStorageStore').load();		        		                
	        		            },
	        		    cancel:  function() {
	        		                // Called when the user closes the dialog
	        		                // without selecting a file and does not include any parameters.
	        		            }
	        		};
	        	
	        	// Dropbox.choose(dropboxOptions);
	        	
	        },
	        
	        listeners : {
	        	
		        afterrender:function(){	
		        	// this.getEl().createChild('<input type="dropbox-chooser" name="selected-file" style="visisssbility:
              // hidden;" id="db-chooser"/>');
		        }
	        	
	        }
	      });
	    
	    
	    
	    editorPagetoolbarButtons.push({
        xtype : 'button',
        name : 'upload',
        itemId : 'upload',
        tooltip : 'upload',
        margin : '4 0 0 4',
        handler:function(btn){

          var centerTabPanel = extVia.regApp.myRaster.getCenterTabPanel();
          var activeCenterTab = centerTabPanel.getActiveTab();
          // var activeCenterTab = btn.ownerCt.ownerCt.ownerCt;
          var editorPanel = activeCenterTab;
          var subTabPanel = activeCenterTab.getComponent(editorMainTabItemId);
          var activeSubTab = subTabPanel.getActiveTab();
          var dropzonePanel = activeSubTab.getComponent('dropzone-panel');
          
          if (dropzonePanel.isVisible()){dropzonePanel.hide();}
          else{dropzonePanel.show();}
        }
        
      });
	    
	    
	    
        
         editorPagetoolbarButtons.push('->');
 
         
        var cfg = {region:'north',searchButtonMenuOFF:true, searchareaDscr:'Kategorie', searchareaProductsOFF:true};
       

         editorPagetoolbarButtons.push(
         {xtype:'pratminisearch'}
         );
	    
          
          
          
          
          
// editorPagetoolbarButtons.push("->");
// editorPagetoolbarButtons.push({
// xtype : 'splitbutton',
// handler:showSammlungsDialog,
// name : 'collection',
// menu:{items:[ {xtype:'panel',bordxer:false, height: 328, width:327, html: "<img
// src='../img/fakes/collectionWidg.png'/>"}]},
// margin : '0 0 0 10',
// tooltip : 'sammlungen',
// iconCls : 'xty_pgtoolbar-collection',
// listeners : {
// }
// });
// editorPagetoolbarButtons.push({xtype : 'tbspacer',width:10});
	    

	    var editorPgjobButtons = [];
	    
 	    
 	    var pgtoolbarButtonFactory = function pgtoolbarButtonFactory(namesArr){
 	    	var pgtoolbarButtons = [];
             var i; 
 	    	 for (i =0; i<namesArr.length; i++){
	 	    	pgtoolbarButtons.push({
	 		        xtype : 'button',
	 		        name : namesArr[i],
	 		        tooltip : namesArr[i],
	 		        iconCls : 'xty_pgtoolbar-'+namesArr[i]
	 		      }); 	
 	    	 }
 	    	  return pgtoolbarButtons;
 	    };
 	   
 	    
 	   var mengeButtonIds = [
 	                          "assign","newEpob","edit","remove",
 	                          "list","thumbsBig","thumbsSmall","tree", "refresh"];
 	   var mengePgjobButtons =  pgtoolbarButtonFactory(mengeButtonIds); 	  
 	   
 	   
 	   mengePgjobButtons[3].handler = function(item){  
 		   var toolbar = Ext.getCmp(item.ownerCt.id);
 		   toolbar.getComponent(15).hide();
 		   toolbar.getComponent(16).hide();

 		   toolbar.getComponent(10).hide();
 		   toolbar.getComponent(9).hide();
 		   toolbar.getComponent(8).hide();
 		   toolbar.getComponent(7).hide();
 		   toolbar.getComponent(6).hide();
 		   };

 	  mengePgjobButtons.splice(0,0,{xtype:'combo', triggerCls:'x-form-search-trigger'});  
 	  mengePgjobButtons.splice(1,0,'-');
 	  mengePgjobButtons.splice(6,0,'-');
 	  mengePgjobButtons.splice(11,0,'-');

 	  
 	  
	   var menge2ButtonIds = [
	                          "assign",
	                          // "edit","remove",
	                          "list"
	                          // "thumbsBig","thumbsSmall","tree",
	                          // "refresh"
	                          ];
	   var menge2PgjobButtons =  pgtoolbarButtonFactory(menge2ButtonIds); 	
	   
	   menge2PgjobButtons[0].xtype="splitbutton";
	   menge2PgjobButtons[0].menu={
			   defaults:{
				   style:'padding-left:20px', height:48
			   },
			   items:[
			          {text:'new', iconCls : 'xty_pgtoolbar-newEpob'},{text:'edit',  iconCls : 'xty_pgtoolbar-edit'},
			          {text:'delete',  iconCls : 'xty_pgtoolbar-remove'},{text:'assign',  iconCls : 'xty_pgtoolbar-assign'}
			          ]
	   };  
	   
   
     
     var sortMenuCfg = {

                items: [
                
                       {text:'Sortieren nach',
                    menu: {       
                        items: [
                            {text:'Aufsteigend',checked:true},
                            {text:'Absteigend'},
                            '-',
                            
// //{text:'<b>Elements</b>'},
// {text:'&Auml;nderungsdatum (Standard)', checked:true},
// {text:'Typ'},
// {text:'Vorschaubild'},
// {text:'Name'},
// {text:'Dateiname'},
// {text:'Sprache'},
// {text:'EPIM-ID ?', disabled:true}
    

// //{text:'<b>Products</b>'},
// {text:'&Auml;nderungsdatum (Standard)', checked:true},
// {text:'Typ'},
// {text:'Name'},
// {text:'Artikelnummer'},
// {text:'Bestellnummer'},
// {text:'Mastersprache'},
// {text:'EPIM-ID'},
// {text:'Eltern-ID (PV only?)', disabled:true},
                            
                       
                            // {text:'<b>Hierarchien</b>'},
                            {text:'&Auml;nderungsdatum (Standard)', checked:true},
                            {text:'Erstellungsdatum', checked:true},
                            {text:'Typ ?', disabled:true},
                            {text:'Name'},
                            {text:'K&uuml;rzel'},
                            {text:'Mastersprache'},
                            {text:'EPIM-ID'},
                            {text:'Eltern-ID'}
                            
                        ]
                   }
             }
                
                ]
            };
     
     
        menge2PgjobButtons[0].handler=function(){
             var sortMenu =    Ext.create('Ext.menu.Menu', sortMenuCfg);
            sortMenu.showAt(1000,180);                
       };
     
     
	   
	   menge2PgjobButtons[1].menu={
			   
			   defaults:{
				   style:'padding-left:20px', height:48
			   },
			   items:[
			          {xtype:'combo', triggerCls:'x-form-search-trigger',  style:'paddisng-left:20px', height:22},
			          {text:'list', iconCls : 'xty_pgtoolbar-list'},
			          
			          {text:'thumbs Big',  iconCls : 'xty_pgtoolbar-thumbsBig'},
			          {text:'thumbs Small',  iconCls : 'xty_pgtoolbar-thumbsSmall'},
			          {text:'tree',  iconCls : 'xty_pgtoolbar-tree'}
			          ]
	   };  
	   menge2PgjobButtons[1].xtype="splitbutton";
	   menge2PgjobButtons.splice(1,0,{xtype : 'tbspacer',width:10},'-',{xtype : 'tbspacer',width:10});
	  
	   var filterComboCfg = {
			   triggerCls:'xty_form-trigger-filter',
			   xtype:'combo',
			   displayField: 'dscr',
			   name:'mengenFilterCombo',
			   id:'mengenFilterCombo',
			   validator:function(val){
			    	  try {new RegExp(val);return true;}
			    	  catch(rgxEx){return "Die Eingabe ist nicht Regex-konform<br>"+rgxEx;}
			   },
			    queryMode: 'local',
			    mode: 'local',
			    value:'(sup)(.*)(ero)',
			    defaultListConfig :{draggasble:true, floating:true, maxHeight:48, cls:'xty_mini-bound-list'},
			    autoCompleteInsert:extVia.stores.inputTextautoCompleteInsert,
			    store:   
				   Ext.create('Ext.data.Store', {   
					            model:  Ext.define('QuickSearchField', {
					    	    fields: ['value','dscr'],
					    	    extend: 'Ext.data.Model'
					    	})
				   }) ,
			   
				   listeners:{
				
					   specialkey:  extVia.stores.inputTextautoCompleteInsertonEnter,
					   
					   change:function( combo, newValue, oldValue, eOpts ){
				        	var grid =Ext.getCmp("mengenGrid");
				        	grid.store.clearFilter();
				        	var sortX = new RegExp(newValue,'gi');
				        	if (newValue.length>0){ grid.store.filter("name", sortX);}

						   }
				   }
	   };
	   
	   
	   menge2PgjobButtons.splice(0,0,filterComboCfg,{xtype : 'tbspacer',width:10},'-');
 	  
	   var collCenterPgjobButtons =[];
	   collCenterPgjobButtons.push(
			   {
		           xtype: 'buttongroup',
		          
		           columns: 2,
		           defaults: {
		             scale : extVia.constants.raster.pagetoolbarCenterBtnScale
		           },
		           items: [
				  {iconCls : 'xty_pgtoolbar-new'},
				  {iconCls : 'xty_pgtoolbar-remove'}
		          ]           
			   },{
           xtype: 'buttongroup',
           columns: 3,
           defaults: {
             scale : extVia.constants.raster.pagetoolbarCenterBtnScale
           },
           items: [
		  {iconCls : 'xty_pgtoolbar-list'},
		  // {iconCls : 'xty_pgtoolbar-thumbsBig'},
		  {iconCls : 'xty_pgtoolbar-thumbsSmall',
             handler:function(){
             var sortMenu =    Ext.create('Ext.menu.Menu', sortMenuCfg);
             sortMenu.showAt(1000,180);                
        }
       },
      {iconCls : 'xty_pgtoolbar-tree'}
      
          ]           
	   });
	   collCenterPgjobButtons.splice(0,0,{xtype:'combo', triggerCls:'x-form-search-trigger'});  
	   collCenterPgjobButtons.splice(1,0,{xtype : 'tbspacer',width:10},'-',{xtype : 'tbspacer',width:10});
	   collCenterPgjobButtons.splice(5,0,{xtype : 'tbspacer',width:10},'-',{xtype : 'tbspacer',width:10});
	   
	   
	   
	   
	   
  	
      var panelmW = Ext.getCmp('panel_mC');
      var mengengridHeight = panelmW.getHeight()-extVia.constants.raster.pgjobEditHeight -28 ;
 	  
 	  var mengenStore = extVia.stores.initMengenStore({pageSize:extVia.stores.mengengridPageSize});
 	  var tagsStore = extVia.stores.initTagsStore({pageSize:extVia.stores.mengengridPageSize});
 	  var collectionsStore = extVia.stores.initCollectionsStore({pageSize:extVia.stores.mengengridPageSize});
 	  if ( !Ext.isIE ) {extVia.stores.initLocalStorage();}
	  
	  var mengengridPagingToolbar  = Ext.create('Ext.PagingToolbar', {
		  
		  reorderable:true,
          store: Ext.data.StoreManager.lookup('mengenStore'),
      	  pageSize : extVia.stores.mengengridPageSize,
      	  displayInfo: true,
          displayMsg: 'Treffer {0} - {1} von {2}',
          emptyMsg: "keine Treffer",
          items:[
                  
              '->', 
              
              {xtype:"tbtext", text: 'Treffer pro Seite' },
             
              {
              	xtype:"numberfield", width:60,
              	value:extVia.stores.mengengridPageSize,
              	tooltip:'pagesize',
              	text:'pagesize',
              	listeners:{
              		change:function()	{
              			// alert("paging bar textfield"+this.getValue());
              			this.ownerCt.store.pageSize = this.getValue();
              		}
              	}
              },
              { text: 'pg only' , enableToggle:true, 
            	  handler:function(){ 
            		  
            		  
            		  var grid =  this.ownerCt.ownerCt;
            		  var gridHeight= grid.getHeight()-22;
            		  var optiPageSize = ""+gridHeight/ 28;
            		  
            		  optiPageSize = optiPageSize.replace(/\.*/,"");
            		  optiPageSize = parseInt(optiPageSize)-1;
            		  
            		  var pageSizeInput = this.ownerCt.items.get(13); 
            		  
            		  pageSizeInput.optiPageSize = optiPageSize;
            		  
            		  if (this.pressed){
                		  
                		  pageSizeInput.oldVal  = pageSizeInput.getValue();
                		  pageSizeInput.setDisabled(true);
                		  pageSizeInput.setValue(pageSizeInput.optiPageSize);
                		  this.ownerCt.store.pageSize = pageSizeInput.optiPageSize;     
            		  }
            		  else{
                		  pageSizeInput.setValue(pageSizeInput.oldVal );
                		  this.ownerCt.store.pageSize = pageSizeInput.oldVal ;  
                		  pageSizeInput.setDisabled(false);
            		  }
            		  this.ownerCt.store.nextPage();
            		  
 
            		  }
              }
              
              ]
      });
	  
	  mengengridPagingToolbar.add(
			  {xtype : 'tbspacer', width:20},
			  { cls:'x-tbar-page-first', handler :function(){ this.ownerCt.store.loadPage(1);}},
			  { cls:'x-tbar-page-prev', handler :function(){  this.ownerCt.store.previousPage();}},
			  { cls:'x-tbar-page-next', handler :function(){  this.ownerCt.store.nextPage();}},
			  { cls:'x-tbar-page-last', handler :function(){  var last = this.ownerCt.getPageData().pageCount;this.ownerCt.store.loadPage(last);}}
			  );

      // check if loading dummy-data is needed
	  var pageReloadCount = Ext.isIE ? 0:localStorage.getItem("pageReloadCount");
	  

	  if (!pageReloadCount){
		  pageReloadCount = 0;
	  }
	  pageReloadCount = parseInt(pageReloadCount);
	  pageReloadCount+=1;
      if ( !Ext.isIE ) localStorage.setItem("pageReloadCount", ""+pageReloadCount);
     
      var configGridTitle="Konfigurationen";
      if (pageReloadCount>-1){configGridTitle+=" reloaded";}
      
      
      
      var searchTerm ="(sup)(.*)(ero)";
      
      // var searchTerm ="media";
      // var searchTerm ="999";
      
	  var searchTermX = new RegExp(searchTerm);

      var highlightRenderer = function highlightRenderer ( value, metaData, record, rowIndex, colIndex, store, view )  {
        
         metaData.tdAttr= ' title ="'+value+'"'; 
         metaData.tdAttr= ' data-qtip ="'+value+'"'; 
         
         metaData.tdCls = 'xty_grid-path-cell';

    	  // TODO getGrid + searchTerm = grid.getHighlightSource().getValue()
    	  searchTerm = Ext.getCmp("mengenFilterCombo").getRawValue();

    	  
    	  try {searchTermX = new RegExp(searchTerm, 'gi');}
    	  catch(rgxEx){}
    	  
    	  var valStr = value;
    	  
    	  if (value){
    		  var valStr = value.toString();
    		  if (searchTermX.test(valStr)){
    			  valStr = valStr.replace(searchTermX, '<b style="background:#F2ED6D">$&</b>'); // OK
    		  }
    	  }	  
    	  return valStr;
      };
       
      
      // Please provide behaviour: like Ext.ux.form.field.BoxSelect ( delimiter newOnEnter ...)
      // http://kveeiv.github.io/extjs-boxselect/examples/boxselect.html
      var createNewComboEntry = function createNewComboEntry ( combo )  {

	      	  var comboValue = combo.getValue();
	      	  var newComboEntryTipId = combo.getId()+"-NewComboEntryTip";
	      	  
	            function setComboToolTipVisible(visible){
	              var tip = Ext.getCmp(newComboEntryTipId);
	              if(tip){
	                if(!visible){
	                  tip.disable();
	                }else{
	                  tip.enable();
	                  tip.showBy(combo.el);
	                }
	              }else if(visible){
	                tip = Ext.create('Ext.tip.ToolTip', {
	                  id: newComboEntryTipId,
	                  target: combo.inputEl,
	                  html: 'Neuer Tabellentyp wird angelegt'
	                });
	                window.setTimeout(function(){
	                  tip.show();
	                  tip.hide();
	                  tip.showBy(combo.el);
	                }, 10);
	                
	              }
	            }
	            /**
               * If value is a String, the method finds the record for the given name (value) else the value is returned
               * 
               * @private
               * @param {String / Object}
               * @returns {String / Array}
               */
	            function getUsedRecords(value) {       		
	            	
	              var store = combo.store, a = 0, record = null, data = null;
	              if (value && Ext.isArray(value)) {
	                data = value;
	              } else {
	                for (a = store.getCount() - 1; a >= 0; a--) {
	                  record = store.getAt(a);
	                  if (record.data.name === value) {
	                    data = [ record ];
	                    break;
	                  }
	                }
	              }

	              if (data === null) {
	                data = value;
	              }

	              return data;
	            }


	            var records = getUsedRecords(comboValue);
	            
	            var recordfound = combo.store.findRecord("name", comboValue);
         		Ext.create('widget.uxNotification', {
					title: 'combo.store.findRecord',
					status : "ErrorValidate",
					position: 'tr',
					manager: 'instructions',
					cls: 'ux-notification-light',
					iconCls: 'ux-notification-icon-information',
					html :  "<b>"+comboValue +"</b><br><br>"+recordfound,
					autoCloseDelay: 2000,
					slideBackDuration: 500,
					slideInAnimation: 'bounceOut',
					slideBackAnimation: 'easeIn'
				}).show();
	            
	            
	            
	            if (records && records.length > 0) {
	              if (Ext.isArray(records)) {
	                var record = records[0];
	                var value = null;
	                try {
	                  value = Ext.JSON.decode(record.data.value);
	                } catch (e) {
	                  Ext.global.console.warn(e);
	                }
	                if (value !== null) {
	                  // combo.setFieldStyle('background: transparent;');
	                  combo.removeCls('xty_combo-newEntrySelected');
	                  setComboToolTipVisible(false);
	                }
	              } else if(records.length > 0){
	                setComboToolTipVisible(true);
	                // combo.setFieldStyle('background-color: gold;');
	                combo.addClass('xty_combo-newEntrySelected');
	               
	            	 var value = combo.getValue();
	            	 
	            	 var delimiter = ",";
	            	 if (value.substring(value.length-1,value.length)==delimiter){   
	            		 value=value.substring(0,value.length-1);
		                 combo.store.add( {"name":value, newEntry:true});
		                 
		                 combo.setValue(value);
	            	 }
	              } else{
	                setComboToolTipVisible(false);
	                // combo.setFieldStyle('background: transparent;');
	                combo.removeCls('xty_combo-newEntrySelected');
	              }
	            } else {
	              setComboToolTipVisible(false);
	              // combo.setFieldStyle('background: transparent;');
	              combo.removeCls('xty_combo-newEntrySelected');
	            }  	  
      };


      var mainContentPanelHeight =  extVia.regApp.myRaster.getCenter().getHeight() - 26 - extVia.constants.raster.appbarHeight -26  ;// tabstrip
                                                                                                                                      // appbar
                                                                                                                                      // tabstrip

      var applibar = extVia.ui.page.pagejob.getApplicationBar( { hasDropZone:true, pgjobDscr:"Epobtype actionname", epobDscr:"Epob 1",  pagetoolbarButtons: editorPagetoolbarButtons,pgjobButtons: editorPgjobButtons} );
      
      
      var chbxClmn = true;
      
      var getSetChbxClmn = function (chbxClmnVal){
        chbxClmn = chbxClmnVal;
        return chbxClmn;
      }
      
      
      
      
      
      
      
   // extVia.ui.cmp.factory.Select.statics.showIconOnField
      
    var showIconOnField =  function(field, newValue, oldValue) {
          if (!field.selectedIconEl){
            var selectedIconLeft =  ( field.labelWidth +8 ) +'px';
            var selectedIconHtml = '<div id='+field.id+'"-selected-icon" class="xty_form-icon-combo-selected-icon xty_icon xty_iconNothing" style=" width:16px; height:16px; margin-top:3px; position:absolute; z-index:99; left:'+selectedIconLeft+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
            var selectedIconEl = Ext.DomHelper.insertBefore(Ext.get(field.getEl().dom.firstChild),selectedIconHtml , true);
            field.selectedIconEl = selectedIconEl;
            
            field.addCls('xty_form-icon-combo');
            // fieldCls : 'xty_form-icon-combo-field x-form-field',
            
          }
          if (field.selectedIconEl){
            field.selectedIconEl.addCls('xty_icon'+newValue);
            field.selectedIconEl.removeCls('xty_iconNothing');
            field.selectedIconEl.removeCls('xty_icon'+oldValue);
            field.selectedIconEl.dom.setAttribute('data-qtip', field.getRawValue());
            }
         
      };
      
      
      
      
      
      
      
      
      
      
	    var tabCfg = {
	    		
	    		// cls:' xty_regionCenterCenter ',
	    		
	    		 activeTab: 0, 
	    		 layout:'fit',
	    		 autoScroll : true,
	    		
	            items: [

                   {
    		         
    		         title: 'Epob 1',
                     refresh:function(){alert("refresh on "+this.title)},
                     moveHoriz:function(){alert("einstellungen on "+this.title);},
                     preferences:function(){alert("einstellungen on "+this.title);},
                     closable:true,
                     bodyBsorder:false, // in connection with xty_subtabpanel-tabbar
    		             itemId:'epob_1',
    		             tbar : applibar, // extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:"Epobtype actionname",
                                      // epobDscr:"Epob 1", pagetoolbarButtons: editorPagetoolbarButtons,pgjobButtons:
                                      // editorPgjobButtons} ),
    		      
                   
                     items:[ 
                            Ext.createWidget('tabpanel', { 
                              border:false, 
                              margin : '0 0 0 0', 
                            	
                            	//activeTab:0,
                            	stateful:true,
                            	stateId:editorMainTabItemId,
                              tabBar:{cls:'xty_subtabpanel-tabbar xty_tabbar-noborder-rl'},
                            	defaults:{
                                   autoScroll:true,
                                   height:mainContentPanelHeight
                                },
                            	itemId:editorMainTabItemId,

                            	items:[
 
//                            	       {
//                                    	   border:false,//cls:'xty_hasInvisibleTabitems', 
//                                    	   title:'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;&nbsp;&nbsp;', 
//                                    	   disablsed:true
//                                     },
                            	       {
                                    	   border:false,
                                    	   title:'Metadaten', 
                                       	   stateful:true,
                                       	   stateId:editorMainTabItemId+'-metadataTab',
                                       	   itemId:editorMainTabItemId+'-metadataTab',
 
                                           listeners:{
                                            afterrender: function(panel) {
                                                var scrollPanelEl = Ext.get(panel.id+'-body');
                                                   scrollPanelEl.on('scroll', function() {
                                                     var containerScrollTop = scrollPanelEl.getScroll().top;
                                                     // var applibar = panel.ownerCt.getApplicationBar();
                                                     if (containerScrollTop>50){applibar.collapse();}
                                                     else{applibar.expand(); }
                                                    });
                                              }
                                           },
                                           
                                           
                                           items : [
                                             
                                             
                                             
                                             {
                                               // title:'Dropzone',
                                               margin:'24 24 24 24',
                                               itemId:'dropzone-panel',
                                               hidden:true,
                                               cls:'xty_dropzone-panel',
                                               
                                               html:'<img style="width:100%;" id="dropzone-fakepanel" src="../img/fakes/dropzone-panel.png"/>',
                                               width:580,
                                               height:320  
                                             },
                                             
                                             
                                             
                                             
                                             {

                                        	   title:'Metadaten', 
                                        	   margin:'24 24 24 24',
                                        	   cls:'xty_accordionHd',
                                        	   width:580,
                                               itemId:'myFormPanel',
                                               xtype:'form',
                                               
                                               dirtyAndValiditychange:function( basic, dirty, valid, eOpts){	
                                           		var dialogButtons = this.ownerCt.getComponent('myButtons');

                                           		var activate = dirty ;
                                           		if (!valid) {activate = false;}
                                           		
                                       			var centerTabPanel =  extVia.regApp.myRaster.getCenterTabPanel();
                                       			var tabBar = centerTabPanel.getActiveTab().getComponent(editorMainTabItemId).getTabBar();
                                       			var tabItem = tabBar.items.get(1);
                                       			var currentEditor = centerTabPanel.getActiveTab();
                                       			var saveButt = currentEditor.getComponent("applicationbar").getComponent("pagetoolbar").getComponent("save");

                                       			if (!valid){
    	                            	    		saveButt.tooltipOrg =  saveButt.tooltip;
    	                            	    		// tabItem.tooltipOrg = tabItem.tooltipOrg;
    	                            	    		saveButt.setTooltip("Ein Formular enth&auml;lt ung&uuml;ltige Eingaben");
                                           			tabItem.setTooltip("Ein Formular enth&auml;lt ung&uuml;ltige Eingaben");
                                           			tabItem.addCls("xty_tab-invalidDirty");
                                       			}
                                       			else{
                                       				tabItem.removeCls("xty_tab-invalidDirty");
                                       				if (!dirty){
	    	                            	    		saveButt.tooltipOrg =  saveButt.tooltip;
	    	                            	    		saveButt.setTooltip("Keine &Aumlnderungen");
                                       				}
                                       			}

    	                            	    	
    	                            	    	if (valid && dirty){
    	                            	    		saveButt.removeCls("x-item-disabled");
    	                            	    		saveButt.setTooltip(saveButt.tooltipOrg);
    	                            	    		saveButt.tooltipOrg =  null;
                                           			tabItem.setTooltip(tabItem.tooltipOrg);
                                           			tabItem.tooltipOrg = null;
    	                            	    	}
    	                            	    	else{
    	                            	    		// saveButt.disable();
    	                            	    		saveButt.addCls("x-item-disabled");
    	                            	    	}
                                           	},
                                     
                                           	
                                               listeners:{
                                            	   afterrender: function() {
                                            		   this.addHeaderCls('xty_accordionHd');
                                              		 },
	                                               	validitychange:function( basic, valid, eOpts ){
	                                               		this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts );	
	                                               	},	
	                                               	dirtychange:function( basic, dirty, eOpts){
// Ext.create('widget.uxNotification', {
// title: 'dirtychange event',
// position: 'tr',
// manager: 'instructions',
// cls: 'ux-notification-light',
// iconCls: 'ux-notification-icon-information',
// html: 'form is dirty: '+dirty,
// autoCloseDelay: 2000,
// slideBackDuration: 500,
// slideInAnimation: 'bounceOut',
// slideBackAnimation: 'easeIn'
// }).show();

	                                               		this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts );	
 	
            	                            	    	var currentEditor = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
            	                            	    	
            	                            	    	var currentTab = this.ownerCt;

            	                            	    	var editorHasDirtyStar = currentEditor.title.indexOf("*")>-1;
            	                            	    	var tabHasDirtyStar = currentTab.title.indexOf("*")>-1;
	                                               		
            	                            	    	if ( !currentEditor.dirtyByArr){
            	                            	    		currentEditor.dirtyByArr =[];
            	                            	    	}
            	                            	    	if (dirty){
            	                            	    		currentEditor.dirtyByArr.push(currentTab.id);
            	                            	    	}

	                                               		if (dirty && ! editorHasDirtyStar){
	                                               			currentEditor.setTitle(currentEditor.title+" *");
	                                               		}
	                                               		else  {
	                                               			currentEditor.setTitle(currentEditor.title.replace(/\*/,""));
	                                               		}
// else if (currentEditor.dirtyByArr.length==1 && currentEditor.dirtyByArr[0].id ==currentTab.id ) {
// currentEditor.setTitle(currentEditor.title.replace(/\*/,""));
// }
	                                               		
	                                               		if (dirty){
	                                               			currentTab.setTitle(currentTab.title+' *');

	                                               		}
	                                               		else {
	                                               			currentTab.setTitle(currentTab.title.replace(/\*/,""));
	                                               		}
	                                               	}
                                                },

                                               
                                               fieldDefaults : {
                                               msgTarget : 'side'
                                               },
                                               defaults : {
                                                  style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
                                                  anchor : '100%',
                                                  labelWidth : 160,
                                                  widsth : 350,
                                                  msgTarget:'side'
                                               },
                                               items : [ 
                                                    		 { xtype:'displayfield', value:'<b>Allgemeine Metadaten</b>' },	
                                                    		  
                                                    		// {xtype:'textfield', value:'Epob 1', itemId:'name',
                                                        // name:'name', fieldLabel: '&nbsp;Name', labelSeparator
                                                        // :getLabelSeparator4Required(), allowBlank:false},
                                                    		
                                                         
                                                            { xtype: 'fieldcontainer',   itemId:'nameMaybeDict-bin',  fieldLabel:'&nbsp;Name',  layout: 'hbox', labelSeparator :getLabelSeparator4Required(),

					                                         items:[ 
                                                              
                                                           { xtype: 'combo', itemId:'nameMaybeDict', name:'nameMaybeDict', width:340,
                                                           cls : 'xty_form-iconCombo xty_iconsNOVAL xty_form-iconCombo-trxiggerRight',  
                                                           trigger1Cls : 'xty_form-trigger-empty',  // trigger1Cls :
                                                                                                    // 'xty_form-trigger-iconCombo',
                                                           
                                                           listeners : {  
                                                            render:function(textarea){
                                                              var trigger2DIV = Ext.query('#'+this.id+' DIV[class~="'+this.trigger1Cls+'"]')[0].id;   
                                                              var trigger2El = Ext.get(trigger2DIV);
                                                             // trigger2El.setStyle({right:(textarea.getWidth()+134
                                                              // )+'px'});
                                                              this.trigger2El = trigger2El; 
                                                            },

                                                          focus:function(field){Ext.get(field.id+'-triggerWrap').addCls('xty_form-trigger-wrap-focus');}, 
                                                          blur:function( field ){Ext.get(field.id+'-triggerWrap').removeCls('xty_form-trigger-wrap-focus');},    
                                                          change : function(field, newValue, oldValue) {
                                                               
                                                               var isInStore = field.getStore().find( 'value', newValue);
                                                               var entryCls ='xty_form-trigger-isDict ';
                                                               if (isInStore===-1){
                                                                // entryCls ='xty_form-trigger-isNewEntry '
                                                                entryCls ='xty_form-trigger-empty ';
                                                               }

                                                               this.trigger2El.removeCls('xty_form-trigger-isDict');
                                                               this.trigger2El.removeCls('xty_form-trigger-empty');
                                                               this.trigger2El.removeCls('xty_form-trigger-isNewEntry');
                                                               this.trigger2El.removeCls('xty_iconNOVAL');
                                                               this.trigger2El.addCls(entryCls);
                                                               
                                                             }
                                                           },
                                                             listConfig : {
                                                               minWidth:150,
                                                               maxHeight:900, 
                                                               itemTpl:'<div style="width:100%;padding-left:16px; " title="{value}" class="xty_epobDictionary-gray">' + '&nbsp; {dscr}' + '<span style="color:#ccc;"> &nbsp;&nbsp;{value}</span></div>'
                                                               },
                                                         store:  extVia.stores.initStatusStore(),displayField: 'dscr',   valueField: 'value',
                                                         queryMode: 'local'
                                                     },   
                                                              
                                                              
			                                                 { xtype: 'splitter'}, 
			                                                 {iconCls:'xty_formbutton-dictionaryEdit',originalIconCls:'xty_formbutton-dictionaryEdit', validIconCls:'xty_formbutton-dictionary', xtype: 'splitbutton', width:42 ,
			                                                  menu: {  items: [   ] }}
					                                                 ]
                                                              },
                                                            
                                                              
                                                                {xtype:'textfield', value:'ep1', itemId:'shortcut', name:'shortcut', fieldLabel: '&nbsp;K&uuml;rzel',  labelSeparator :getLabelSeparator4Required(), allowBlank:false},
                                                    		 
                                                                
                                                                
                                                                
                                                                
			                                                    { xtype: 'combo', itemId:'state', name:'state', width:200,
			                                                     cls : 'xty_form-iconCombo xty_iconNOVAL xty_form-iconCombo-triggerRight',  
			                                                     trigger2Cls : 'x-form-trigger',  trigger1Cls : 'xty_form-trigger-iconCombo-right',   
			                                                     fieldLabel: '&nbsp;Status-Typen',
			                                                     listeners : {  
			                                                      render:function(combo){
			                                                        var trigger2DIV = Ext.query('#'+this.id+' DIV[class~="'+this.trigger2Cls+'"]')[0].id;   
			                                                        var trigger2El = Ext.get(trigger2DIV);
			                                                        trigger2El.setStyle({right:(combo.getWidth() - 202)+'px'});
			                                                        this.trigger2El = trigger2El; 
			                                                      },
			                                                        change : function(field, newValue, oldValue) {
			                                                         this.trigger2El.addCls('xty_icon'+newValue);
			                                                         this.trigger2El.removeCls('xty_iconNOVAL');
			                                                         this.trigger2El.removeCls('xty_icon'+oldValue);
			                                                         field.trigger2El.dom.setAttribute('data-qtip', field.getRawValue());
			                                                       }
			                                                     },
			                                                     listConfig : {
			                                                         minWidth:150,
			                                                         maxHeight:900, 
			                                                         itemTpl:'<div style="width:100%;padding-left:16px;" title="{value}" class="xty_icon xty_icon{value}">' + '&nbsp; {dscr}' + '<span style="color:#ccc;"> &nbsp;&nbsp;{value}</span></div>'
			                                                      },
			                                                     store:  extVia.stores.initStatusStore(),displayField: 'dscr',   valueField: 'value',
			                                                     queryMode: 'local'
				                                                }, 
                                                         
				                                             
				                                                
				                                                {xtype:'fieldcontainer', itemId:'summary', fieldLabel: '&nbsp;Summary' , 
				                                                  layout:'hbox',
				                                                  cls:'xty_summary-list-container',
				                                                  items:[     
				                                                 {
				                                                  xtype: 'boundlist',
				                                                  cls:'xty_summary-boundlist',
				                                                  width:386,
				                                                  height:200,
				                                                  multiSelect: true,
				                                                  name: 'summary',
				                                                  itemId: 'summaryListField',
				                                                  value: ['Standard'],
				                                                  defersInitialRefresh: false,
				                                                  
				                                                  store:   Ext.create('Ext.data.ArrayStore', { 
				                                                    fields: [ 'annotation', 'matches', 'value', 'checked'], 
				                                                    data :  [  ['LABELS', '7/10', '5'],  ['WEB', '3/10','Marylin Riot grrrl  Tattoo Punk-rock Image T-shirt Fashion Teach Me Tiger '], ['FACES', '0/10','2 jgg uzutz 75675 gdgdetter khkjhii kjkjk89i8 kjkjk kljlf908790']]
				                                                  }) ,   
				                                                  
                                                          displayField: 'annotation',
                                                          itemTpl:
                                                            '<div style="width:100%; padding-top:4px;" title="{value}" class="xty_summarylist-item xty_summarylist-annotation ">' +
                                                               '&nbsp; <b>{annotation}</b> {matches}'+
                                                               
                                                             
                                                          '<div class="xty_summary-btn-bin" style="position:absolute; right:4px; top:4px;">'+
 
                                                            '<span class="xty_form-checkbox-switch-bin" style=" top:2px;">'+
                                                             '<input checked="" class="xty_form-checkbox-switch xty_summary-switch" id="summary-checkbox-{annotation}" type="checkbox">'+
                                                              '<label id="summary-checkbox-label" class="xty_form-checkbox-switch-label" for="summary-checkbox-{annotation}">'+
                                                              '<span class="xty_form-checkbox-switch-checked xty_summary-switch-checked   checked " ></span>'+
                                                              '<span class="xty_form-checkbox-switch-unchecked xty_summary-switch-unchecked unchecked"></span>'+
                                                             '</label>'+
                                                            '</span>'+
                                                            
                                                             
//                                                            '<div class="xty_summary-targets-bin" style="margin-top:8px; margin-left:24px;" >  '+
////                                                            '<span class="xty_form-checkbox-switch-meta-bin" style=" top:2px;">'+
////                                                               '<input checked="" class="xty_form-checkbox-switch-meta xty_summary-switch-meta-meta" id="summary-checkbox-{annotation}-meta" title="Apply to meta" type="checkbox">'+
////                                                               '<label id="summary-checkbox-label" class="xty_form-checkbox-switch-meta-label" for="summary-checkbox-{annotation}-meta">'+
////                                                               '<span class="xty_form-checkbox-switch-meta-checked xty_summary-switch-meta-checked   checked " ></span>'+
////                                                               '<span class="xty_form-checkbox-switch-meta-unchecked xty_summary-switch-meta-unchecked unchecked"></span>'+
////                                                              '</label>'+
////                                                              '</span>'+  
//                                                           '</div>'+
                                                             
                                                           //  '<div class="xty_summary-details-btn" style="" >  &raquo; </div>'+
                                                             
                                                             
                                                           '</div>'+ 
                                                            
                                                            '<div style="padding-top:4px; text-overflow: ellipsis;  white-space: nowrap; overflow: hidden ; width: 320px;">&nbsp;  {value} <span style="color:#ccc;display:none;"> &nbsp;&nbsp;{value}</span>'+
                                                            '</div>'+

                                                            
                                                           // '<div class="xty_summary-details-arrow-btn" style="position:absolute; right:0px; height:42px; top:4px; line-height:30px; font-size:40px;"> &rang;</div>'+
                                                            
                                                            
                                                            '</div>'

				                                                 }
				                                                 ]
				                                                },
				                                                
				                                                
				                                                
				                                                
				                                                 { xtype: 'combo', itemId:'state2', name:'state', width:200,
				                                                  fieldLabel: '&nbsp;Status-Typen 2',
				                                                  listeners : {
// afterrender:function(combo){
// var selectedIconLeft = ( combo.labelWidth +8 ) +'px';
// var selectedIconHtml = '<div id='+combo.id+'"-selected-icon" class="xty_form-icon-combo-selected-icon xty_icon
// xty_iconNothing" style=" width:16px height:16px; margin-top:3px; position:absolute; z-index:99;
// left:'+selectedIconLeft+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>';
// var selectedIconEl = Ext.DomHelper.insertBefore(Ext.get(combo.getEl().dom.firstChild),selectedIconHtml , true);
// combo.selectedIconEl = selectedIconEl;
// },
				                                                    
				                                                      change: showIconOnField
				                                                    

				                                                      },
				                                                  listConfig : {
				                                                    minWidth:150,
				                                                    maxHeight:900, 
				                                                    itemTpl:'<div style="width:100%;padding-left:16px;" title="{value}" class="xty_icon xty_icon{value}">' + '&nbsp; {dscr}' + '<span style="color:#ccc;"> &nbsp;&nbsp;{value}</span></div>'
				                                                    },
				                                                    store:  extVia.stores.initStatusStore(),
				                                                    displayField: 'dscr',
				                                                    valueField: 'value',
				                                                    queryMode: 'local'
				                                                 }, 			                                             
				                                             
				                                             
				                                             
				                                             
				                                             
				                                             
                                                         
                                                    		 {xtype:'textarea',  cls:'xty_codefield', itemId:'description', fieldLabel: '&nbsp;Beschreibung', rows:2,
                                                         
                                                         
                                                             validator:function(v , field){       
                                                               var carriageX = /\r?\n|\r/g;
                                                               var hasLinebreaks =  carriageX.test(v);
                                                               var linebreakText='';
                                                               if (hasLinebreaks){
                                                                var linbreaksArr = v.split(carriageX);
                                                                var linbreaksCount = linbreaksArr.length;
                                                                linebreakText='You have '+(linbreaksCount-1)+' linebreaks';
                                                               }
                                                               
                                                              return (hasLinebreaks)? 'Linebreaks are not allowed.<br> '+ linebreakText     :true;
                                                             }

                                                          },
                                                         
// commentfield                                                         
{xtype:'textarea', itemId:'comment', fieldLabel: '&nbsp;Kommentar', rows:2,
	value:'*BAM* _BOOM_ BANG *BAM* _BOOM_ BANG \n'+
	 ' h2. Headline \n'+
	  '* eins \n'+
	  '** zwei  \n'+
	  '*** drei \n',
  grow:true,
	listeners:{
		afterrender:function(textarea){
			if (!textarea.commentViewPanelEl){
                 var commentViewPanelEl = Ext.DomHelper.append(textarea.id, {
                    tag: 'div',
                    id:textarea.id+'-commentViewPanel',
                    style:'margin-top:-18px;margin-left:'+(Ext.get(textarea.id+'-labelEl').getWidth()+5)+'px; height:'+textarea.getHeight()+'px;',
                    width:textarea.getWidth()-Ext.get(textarea.id+'-labelEl').getWidth(),
                    cls: 'xty_codepaXXnel xty_comment-view-panel',
                    html:'code'
                    });
                  commentViewPanelEl = textarea.getEl().appendChild( commentViewPanelEl) ;
                  textarea.commentViewPanelEl = commentViewPanelEl;
                  commentViewPanelEl.on('click', function(){
                      commentViewPanelEl.addCls("xty_displayNone");
                      var textareaBodyEl = Ext.get(textarea.id+'-bodyEl');
                      textareaBodyEl.removeCls("xty_displayNone");
                      textarea.focus();
                   });
              }
            textarea.updateCommentViewPanel(textarea);
		},
    blur:function(textarea){
         textarea.updateCommentViewPanel(textarea);
    }
	},
  startsAndEndsWith:function(word, char){
     var startsWith = word.startsWith(char);
     var endsWidth = word.endsWith(char); 
     return (startsWith && endsWidth && word.length>1);
    },
   updateCommentViewPanel:function(textarea){
         var commentViewPanelEl = Ext.get(textarea.commentViewPanelEl.id);
         var formattedHtml = ''; 
         var val2BeFormatted = textarea.value;
         if (!Ext.isDefined(textarea.value)){
           val2BeFormatted='';
         }
         var  formatWordsInLine =  function(line){ 
           var formattedWords='';
           var wordsArr = line.split(' ');
           var i;
           for (i =0; i < wordsArr.length; i++ ){
             var word = wordsArr[i];
             if (textarea.startsAndEndsWith(word, '*')){
              word=word.substring(1, word.length-1);
              formattedWords+='<span class=" xty_formatted-word xty_formatted-bold" style="font-weight:bold;">'+word+'</span>';
             }
             else if (textarea.startsAndEndsWith(word, '_')){
              word=word.substring(1, word.length-1);
              formattedWords+='<span class="xty_formatted-word xty_formatted-italic" style="font-style:italic;">'+word+'</span>';
             }
             else if (textarea.startsAndEndsWith(word, '-')){
               word=word.substring(1, word.length-1);
               formattedWords+='<span class="xty_formatted-word xty_formatted-strikethrough" style="text-decoration:line-through;">'+word+'</span>';
              }
             else if (textarea.startsAndEndsWith(word, '+')){
               word=word.substring(1, word.length-1);
               formattedWords+='<span class="xty_formatted-word xty_formatted-underline" style="text-decoration:underline;">'+word+'</span>';
             }
            // else if (word.startsWith('(') && word.endsWith(')') && word.length ===3 ){
              // word=word.substring(1, word.length-1);
              // formattedWords+=' <span class="xty_formatted-word xty_formatted-underline"
              // style="text-decoration:underline;">'+word+' </span> ';
            // }
            // Notation :) :( :P :D ;) (y) (n) (i) (/) (x) (!)
            // Notation (+) (-) (?) (on) (off) (*) (*r) (*g) (*b) (*y) (flag)
             else{
               formattedWords+=word; // ' <span class="xty_unformatted-word">'+word+' </span> ';
             }
             formattedWords+=' ';
           }
           return formattedWords;
         };
 
         var linesArr = val2BeFormatted.split('\n');
         var lineHeight = 20;
         var neededHeight = 0;
         var i;  
         for (i =0; i < linesArr.length; i++ ){
           neededHeight+=lineHeight;
           var line = linesArr[i];
           line = line.replace(/\n|\r/g, "<br>");
           var formattedWords = line;
           if (line.startsWith('***** ')){
             line=line.substring(6, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <li class="xty_formatted-line xty_list-level-5" style="list-style-type: square; margin-left:60px;">'+formattedWords+'</li> ';
           }
           else if (line.startsWith('**** ')){
             line=line.substring(5, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <li class="xty_formatted-line xty_list-level-4" style="list-style-type: square; margin-left:48px;">'+formattedWords+'</li> ';
           }
           else if (line.startsWith('*** ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <li class="xty_formatted-line xty_list-level-3" style="list-style-type: square; margin-left:36px;">'+formattedWords+'</li> ';
           }
           else if (line.startsWith('** ')){
             line=line.substring(3, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <li class="xty_formatted-line xty_list-level-2" style="list-style-type: circle ; margin-left:24px;">'+formattedWords+'</li> ';
           }  
           else if (line.startsWith('* ')){
             line=line.substring(2, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <li class="xty_formatted-line xty_list-level-1" style="list-style-type: disc; margin-left:12px;">'+formattedWords+'</li> ';
           }      
           else if (line.startsWith('h1. ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <h1 class="xty_formatted-line xty_h1" style="">'+formattedWords+' </h1> ';
           } 
           else if (line.startsWith('h2. ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <h2 class="xty_formatted-line xty_h2" style="">'+formattedWords+' </h2> ';
           } 
           else if (line.startsWith('h3. ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <h3 class="xty_formatted-line xty_h3" style="">'+formattedWords+' </h3> ';
           } 
           else if (line.startsWith('h4. ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <h4 class="xty_formatted-line xty_h4" style="">'+formattedWords+' </h4> ';
           } 
           else if (line.startsWith('h5. ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <h4 class="xty_formatted-line xty_h5" style="">'+formattedWords+' </h5> ';
           } 
           else if (line.startsWith('h6. ')){
             line=line.substring(4, line.length);
             formattedWords= formatWordsInLine(line);
             formattedHtml+=' <h6 class="xty_formatted-line xty_h6" style="">'+formattedWords+' </h6> ';
           } 
           else{
            formattedWords= formatWordsInLine(line);
            formattedHtml+=formattedWords; // ' <span class="xty_unformatted-line">'+line+' </span> ';
           } 
         }
         if (neededHeight<lineHeight){
           if (textarea.rows){neededHeight = textarea.rows*lineHeight;}
           neededHeight = 2*lineHeight;
         }
         var wordsArr = val2BeFormatted.split(' ');
           commentViewPanelEl.dom.innerHTML=formattedHtml;
           var textareaBodyEl = Ext.get(textarea.id+'-bodyEl');
           textareaBodyEl.addCls("xty_displayNone");
           commentViewPanelEl.removeCls("xty_displayNone");
           commentViewPanelEl.setHeight(neededHeight);   
           var textareaTAGEl = textareaBodyEl.dom.getElementsByTagName('textarea')[0];
           Ext.get( textareaTAGEl).setHeight(commentViewPanelEl.getHeight());
         }
},     

// EO commentfield
                                                         
                                                         
                                                         
                                                    		 {xtype:'textarea', itemId:'catchwords', fieldLabel: '&nbsp;Schlagworte', rows:2},

                                                    		    {
                                                    		        xtype: 'fieldcontainer',
                                                    		        itemId:'requiredSetting',
                                                    		        name:'requiredSetting',
                                                    		        fieldLabel: '&nbsp;Einstellungen',
                                                    		        labelSeparator :getLabelSeparator4Required(), allowBlank:false,

                                                    		        // The body area will contain three splitbuttons,
                                                                // arranged
                                                    		        // horizontally, separated by draggable splitters.
                                                    		        layout: 'hbox',
                                                    		        
                                                    		        defaults : {
                                                    		            xtype: 'button',
                                                    		            setValidity:function(isValid){
                                                    		            	if (isValid){
                                                    		            		this.setValid();
                                                    		            	}
                                                    		            	else{
                                                    		            		this.setInvalid();
                                                    		            	}
                                                    		            },
                                                    		            setValid:function(){
                                                    		            	this.removeCls("x-form-invalid-field");
                                                    		            	this.removeCls("x-btn-disabled");
                                                    		            	this.setTooltip('Einstellungen OK');
                                                    		            	if (this.validIconCls){this.setIconCls(this.validIconCls);}
                                                    		            	else{this.setIconCls("xty_formbutton-valid");}
                                                    		            	this.isValid =true;
                                                    		            },
                                                    		            setInvalid:function(){
                                                    		            	this.addCls("x-form-invalid-field");
                                                    		            	this.addCls("x-btn-disabled");
                                                    		            	this.setTooltip('Einstellungen d&uuml;rfen nicht unbearbeitet sein');
                                                    		            	if (this.invalidIconCls){this.setIconCls(this.invalidIconCls);}
                                                    		            	else{this.setIconCls(this.originalIconCls);}
                                                    		            	this.isValid=false;
                                                    		            },
                                                    		            isValid:null,
                                                    		            validate:function(){
                                                    		            	if (this.isValid){this.removeCls("x-form-invalid-field");}
                                                    		            	else{this.addCls("x-form-invalid-field");}
                                                    		            },
                                                    		            
                                                    		            
                                                    		            
                                                        			    handler: function(button) {
                                                        			    	if (button.menu){
                                                            			    	button.menu.myCaller= button;
                                                            			    	// button.showMenu();
                                                            			    	button.menu.showAt(40,-350);
                                                        			    	}
                                                        			    	else{
                                                            			    	var confirmCallback = function(confirm){
                                                            			        if (confirm==='yes'){ 
                                                            			        	button.setValid();
                                                            			        	}
                                                            			        else{
                                                            			        	button.setInvalid();
                                                            			        	}	
                                                        			    	};                                                   			    	
                                                        			    	Ext.Msg.confirm('Einstellungen', 'Mach Deine Einstellungen',confirmCallback, this);
                                                        			    	}	
                                                        			    },
                                                        			    tooltip:'Einstellungen bearbeiten'
                                                                     },

                                                    		        items: [
                                                    		                
                                                    		                
                                                    		                { iconCls:'xty_formbutton-checkEdit' , originalIconCls:'xty_formbutton-checkEdit' , validIconCls:'xty_formbutton-checked'}, 
                                                    		                { xtype: 'splitter'}, {text:"Hinzuf&uuml;gen",  iconCls:'xty_formbutton-editConfig' , originalIconCls:'xty_formbutton-editConfig', validIconCls:'xty_formbutton-configChecked'},
		                                                    		        { xtype: 'splitter'}, {iconCls:'xty_formbutton-editGroup' ,originalIconCls:'xty_formbutton-editGroup' ,menu: {  items: [ ergebnisDarstellungsPanelCfg  ] }},
		                                                    		        { xtype: 'splitter'}, {iconCls:'xty_formbutton-editTable',originalIconCls:'xty_formbutton-editTable' },
		                                                    		        { xtype: 'splitter'}, {iconCls:'xty_formbutton-editAttributes' , originalIconCls:'xty_formbutton-editAttributes',menu: {  items: [ ergebnisDarstellungsPanelCfg  ] } },
		                                                    		        { xtype: 'splitter'}, {iconCls:'xty_formbutton-dictionaryEdit',originalIconCls:'xty_formbutton-dictionaryEdit', validIconCls:'xty_formbutton-dictionary', xtype: 'splitbutton', width:42 ,menu: {  items: [ ergebnisDarstellungsPanelCfg  ] }  }
		                                                    		        
		                                                    		       // { xtype: 'splitter'},
                                                                    // {xtype:'checkbox',iconCls:'xty_formbutton-dictionaryEdit',originalIconCls:'xty_formbutton-dictionaryEdit',
                                                                    // validIconCls:'xty_formbutton-dictionary',
                                                                    // width:42 }
 
		                                                    		        ]
                                                    		    },   

                                                            
                                                            
                             {xtype:'tbspacer', height:8},          

                             
                             {xtype:'fieldcontainer', itemId:'pratviews-bin', 
                                fieldLabel: '&nbsp;Sichten-Zugeh&ouml;rigkeit',
                                height:342,
                                items:[ 
	                             {xtype:'grid', itemId:'pratviews',  
                               
                                
                                   cls : 'xty_pratviews-assignement-grid '+chbxClmn ?'xty_hasCheckbox-clmn xty_checkbox-clmn-checkall-header ':'xty_hasNOCheckbox-clmn xty_useReadonlySwitcher',
                               
                                   hideHeaders : !chbxClmn,
                                   selModel: (chbxClmn)?Ext.create('Ext.selection.CheckboxModel',{checkOnly : true, 
                                   listeners:{
                                    select: function( selModel, record, index ){record.set('checked', 'true'); },
                                    deselect: function( selModel, record, index ){record.set('checked', 'false');}
                                   }
                                   }):
                                    Ext.create('Ext.selection.RowModel',{
                                      mode:'MULTI',
                                   listeners:{
                                    select: function( selModel, record, index ){record.set('checked', 'true'); },
                                    deselect: function( selModel, record, index ){record.set('checked', 'false');}
                                   }
                                   }),
                                   multiSelect : true,
                                  height:340,      
                                  width:388,      
	                              store:extVia.stores.initDBViewsStore(),
                                
                                
                                  listeners:{
                                    select: function( selectionRowModel, record, index ){ record.set('checked', 'true'); },
                                    deselect: function( selModel, record, index ){record.set('checked', 'false');}
                                  },
                                
	                              columns:[
	                                {header:'Sicht', dataIndex:'dscr', width: chbxClmn ? 278 : 304,
                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  { 
                                     if (record.get('isReadonlyView')==='true'){
                                      metaData.tdCls='xty_node-modifier xty_node-modifier-readonly'; 
                                     } 
                                     return value;
                                    }
                                  
                                  
                                   },
	                                {header:'Nur Lesen',
                                     dataIndex:'readonly',
                                     itemId:'readonlySwitch',
                                     width: 66,
                                    renderer:function( value, metaData, record, rowIndex, colIndex, store, view )  { 
                                     var isReadonly = value.indexOf('true')>-1;
                                     
                                     var isReadonlyView = record.get('isReadonlyView')==='true';
                                     var checkedRow = record.get('checked')==='true';
                                     
                                     if (checkedRow){
                                      view.getSelectionModel().select(record, true);
                                     }
                                     
                                     var checkbxstatus = isReadonly || isReadonlyView ?'checked':'';
                                     var checkbxDisabled = (isReadonlyView || !checkedRow )  ?' disabled ':'';
                                     
 
                                     
                                     // var qtip = 'Attribute '+ (record.dirty?' ':'' )+ ' '+ (isReadonly?' werden nur
                                      // lesbar angezeigt':'k&ouml;nnen bearbeitet werden ');
                                     var qtip = 'Attribute '+ (isReadonly?' werden nur lesbar angezeigt':'k&ouml;nnen bearbeitet werden'); 
	  
	                                     var checkboxSwitcherHTML =    
	                                     '<span class="xty_form-checkbox-switch-bin '+ (checkbxDisabled?'xty_form-checkbox-switch-bin-disabled':'')+ '"  style="margin-left:4px; top:2px;" data-qtip="'+qtip+'">'+ 
	                                     '<input type="checkbox"  '+checkbxstatus+'  '+ checkbxDisabled +' class="xty_form-checkbox-switch xty_readonly-switch" id="readonly-checkbox-'+record.get('id')+'" >'+ 
	                                      '<label id="readonly-checkbox-label" class="xty_form-checkbox-switch-label" for="readonly-checkbox-'+record.get('id')+'"  >'+
	                                        '<span class="xty_form-checkbox-switch-checked xty_readonly-switch-checked   checked" ></span>' +
	                                        '<span class="xty_form-checkbox-switch-unchecked xty_readonly-switch-unchecked unchecked" ></span>'+ 
	                                      '</label>'   +
	                                     '</span>';
	                                    return checkboxSwitcherHTML;
                                    } 

                                  
                                  } 
                                  
// ,{
// sortable:false, menuDisabled : true,
//                                   
// header: 'Nur lesen' , hidden:true,
// dataIndex: 'readonly', width: 42,
// itemId:'readonlyToggle',
// renderer:function( value, metaData, record, rowIndex, colIndex, store, view ) {
// var isReadonly = value.indexOf('true')>-1;
// var iconstatus = isReadonly?'Active':'Nothing';
// var qtip = (isReadonly?'Nur Anzeigen':'Kann gepflegt werden ');
// return '<div class="xty_inheritance-edit xty_icon xty_icon'+iconstatus+'" style="" data-qtip="'+qtip+'"></div>';
// }
// }
                                  
                                  
	                              ]
	                             }
                             ]},
                                                            
                                                            
                                                            
                              {xtype:'tbspacer', height:8},          
  
                              {xtype:'combo',  
                               name:'feldgruppen',
                               itemId:'feldgruppen', 
                               valueNotFoundText : 'habisch net',
                               store: tagsStore,
                               queryMode: 'local',
                               width: 150,
                               displayField: 'name',
                               multiSelect:true,
                               emptyText: 'Feldgruppen',
                               valueField: 'id',
                               fieldLabel: '&nbsp;Feldgruppen',
						        forceSelection: true,
						       // editable: false,
						        mode: 'local',
						        triggerAction: 'all',
                                size : 30,
						        listConfig : {          
						            getInnerTpl : function() {
                                        var retHtml = '<div class="x-combo-list-item">' +
                                        '<img src="' + Ext.BLANK_IMAGE_URL + '" style="width:16px;" class="chkCombo-default-icon chkCombo" /> {name} </div>';
                                        
                                         return retHtml;
						            }
						         }  
                              },   

                                                          
                                       {xtype:'tbspacer', height:8},     
                                       {xtype:'fieldcontainer', itemId:'Multiselect', fieldLabel: '&nbsp;Multiselect' , 
                                           layout:'hbox',
                                           items:[    
                                            {
									            xtype: 'boundlist',
									            fieldLabel: 'Multiselect',
                                                width:356,
                                                height:200,
                                                multiSelect: true,
                                                displayField: 'name',
									            name: 'multiselect',
									            itemId: 'multiselectField',
                                                value: ['Standard'],
									            deferInitialRefresh: false,
                                                store: tagsStore
									        },
                          
                                        { xtype: 'buttongroup', columns:1,margin:'0 0 0 2',
                                          defaults:{
                                            handler:function(button){
				                            Ext.create('widget.uxNotification', {
				                            title: button.tooltip, html :  "not implemented",
				                            position: 'tr',cls: 'ux-notification-light',slideInAnimation: 'bounceOut'
				                            }).show();
				                            }
                                          },
                                          
                                          items:[
                                            { xtype: 'button', tooltip:'reset', itemId:'reset', iconCls:'xty_formbutton-reset'},      
                                            { xtype: 'button', tooltip:'Alle ausw&auml;hlen', itemId:'checkAll', iconCls:'xty_formbutton-checkAll'},  
                                            { xtype: 'button', tooltip:'Alle deselektieren', itemId:'uncheckAll', iconCls:'xty_formbutton-uncheckAll'},  
                                            { xtype: 'button', tooltip:'clear', itemId:'clear', iconCls:'xty_formbutton-backspace'},
                                            { xtype: 'button', tooltip:'ausgew&auml;hlte zeigen', itemId:'showSelected', iconCls:'xty_formbutton-showSelected'},
                                            { xtype: 'button', tooltip:'unselektierte ausblenden', itemId:'filterUnselected', iconCls:'xty_formbutton-filterUnselected'},
                                            { xtype: 'button', tooltip:'ausgew&auml;hlte ausblenden', itemId:'filterSelected', iconCls:'xty_formbutton-filterSelected'}

                                          ]}                 
                          
                          
                                          ]
                                        },                 
                                                          
                                                            
                                        {xtype:'tbspacer', height:8},                 
                                        {xtype:'fieldcontainer', itemId:'jslintRunBin', fieldLabel: '&nbsp;jslint output' , 
                                        layout:'hbox',
                                        items:[
                                          {   
                                            xtype:'textarea', 
                                            flex:1,
                                            cls:'xty_codefield',
                                            itemId:'jslint-output', name:'jslint-output',
                                            
                                            parseJSLintErrors : function(){
                                              
                                              var getOutputIssueFields = function(outputIssueStr){
	                                              var outputIssueFieldsArr =  outputIssueStr.split('\n');
                                                  var outputIssue ={relevant:true};
                                                  
                                                  if (Ext.isEmpty(outputIssueStr)){outputIssue.relevant=false;}
                                                
                                                  var oi;
                                                  for (oi = 0; oi < outputIssueFieldsArr.length; oi++){
                                                    var issueFieldStr = outputIssueFieldsArr[oi];
                                                    
                                                    if (issueFieldStr.startsWith('--- started ---')
                                                      || issueFieldStr.startsWith('--- finished ---')
                                                      || issueFieldStr.startsWith('v. 20')
                                                      || issueFieldStr.startsWith('Config')
                                                      || issueFieldStr.startsWith('Check')
                                                    ){
                                                     outputIssue.relevant=false;
                                                    }
                                                    else if (issueFieldStr.startsWith('    Error')){
                                                     outputIssue.error = issueFieldStr;
                                                     
                                                     if (
                                                     issueFieldStr.indexOf("-- started ---")>-1
                                                     || issueFieldStr.indexOf("Expected '===' and instead saw '=='")>-1
                                                     ||  issueFieldStr.indexOf("Expected '!==' and instead saw '!='")>-1

                                                     ){
                                                      outputIssue.relevant=false;
                                                     }
                                                    }
                                                  }
                                                
	                                             
	                                              return outputIssue;
                                              };
                                              
                                              
                                              var jslintOutput = this.getValue();
                                              var jslintOutputArr = jslintOutput.split('[jslint] ');
                                              
                                              var luntbuildRelevanceStr ='<br>';
                                              var luntbuildRelevanceCount = 0; 
                                              var i;
                                              for ( i = 0; i < jslintOutputArr.length; i++){
                                                var  jslintOutputIssueStr = jslintOutputArr[i];
                                                
                                                var issue = getOutputIssueFields(jslintOutputArr[i]);
                                                if (issue.relevant){
                                                  luntbuildRelevanceCount++;
                                                  
                                                  jslintOutputIssueStr = jslintOutputIssueStr.replace('Code >','<br>Code >');
                                                  jslintOutputIssueStr = jslintOutputIssueStr.replace('Error>','<br>Error >');
                                                  // jslintOutputIssueStr = jslintOutputIssueStr.replace(' ','&nbsp;');
                                                  
                                                  
                                                  luntbuildRelevanceStr+=jslintOutputIssueStr+'<br><br>';
                                                }

                                              }
                                              
                                              
                                              // alert('you have '+luntbuildRelevanceCount+' Luntbuild relevant JSLint
                                              // issues out of '+jslintOutputArr.length+' \n
                                              // :\n\n'+luntbuildRelevanceStr)
                                              var instructionPanelCfg = extVia.dialoges.getInstructionPanel({
                                                mainInstr: '&nbsp;you have '+luntbuildRelevanceCount+' build-relevant JSLint issues',
                                                suppInstr: '&nbsp;out of '+jslintOutputArr.length +' newcode-relevant JSLint issues'
                                               
                                              });

                                              instructionPanelCfg.style = 'padding:0px 0px 0px 0px';
                                              
                                              var iconCls ='xty_icon xty_icon' +(luntbuildRelevanceCount===0?'Success':'Warning');
                                              
                                              var luntbuildOutputParserDialog = Ext.create('widget.window', {
									            title:"parse JSLint Output",
                                                iconCls:iconCls,
									            y:100,
									            width:520,
                                                modal:true,
									            floating: true,
									            items:[
                                                  instructionPanelCfg,
									              {xtype:'panel', border:false, autoScroll:true, height: 400,  html:luntbuildRelevanceStr }
									            ]
									          }); 
                                              luntbuildOutputParserDialog.show(); 
                                            }
                                          } ,  
                                           { xtype: 'buttongroup', columns:1,margin:'0 0 0 2',items:[  
	                                          { xtype: 'button', tooltip:'parse',
	                                            itemId:'jslintRun', iconCls:'xty_formbutton-start' , margin:'0 0 0 2',
	                                            handler:function(button){
	                                             button.ownerCt.ownerCt.getComponent('jslint-output').parseJSLintErrors();
	                                             }
	                                           }, 
	                                           
	                                          { xtype: 'button', tooltip:'clear',
	                                            itemId:'jslintClear', iconCls:'xty_formbutton-backspace' , margin:'0 0 0 2',
	                                            handler:function(button){
	                                             button.ownerCt.ownerCt.getComponent('jslint-output').reset();
	                                            }
	                                           }
                                           ]}
                                           
                                           
                                          ] 
                                        },               
                     
                                        {xtype:'tbspacer', height:8},
										{   xtype:'textarea', 
                                            // xtype:'codearea',
                                            cls:'xty_codefield',
                                            itemId:'sqlCode', name:'sqlCode', fieldLabel: '&nbsp;SQL', 
                                            allowBlank:false,
                                            value: 'SELECT mi.Personalnummer AS MitNr, mi.Name, mi.Vorname, dw.ID AS DIW, dw.Kennzeichen, dw.Fahrzeugtyp_ID AS TypID, ft.Bezeichnung AS Typ, ft.Hersteller_ID AS FheID FROM Dienstwagen dw LEFT JOIN Mitarbeiter mi ON dw.Mitarbeiter_ID = mi.ID RIGHT | FULL JOIN Fahrzeugtyp ft ON dw.Fahrzeugtyp_ID = ft.ID;',
                                            // height:100,
                                            // bodyHeight:100,
                                            // value: 'SELECT ',//
                                            
                                            codeCfg:{
                                                type:'sql',
                                                forbiddens : ' alter drop delete update insert ', 
                                                
                                                
                                                
                                                funcs : ' abs avg case cast coalesce convert count current_timestamp ' +
                                                          'current_user day isnull left lower month nullif replace right ' +
                                                          'session_user space substring sum system_user upper user year ',
                                                keywords :  ' absolute action add after alter as asc at authorization begin bigint ' +
                                                          'binary bit by cascade char character check checkpoint close collate ' +
                                                          'column commit committed connect connection constraint contains continue ' +
                                                          'create cube current current_date current_time cursor database date ' +
                                                          'deallocate dec decimal declare default delete desc distinct double drop ' +
                                                          'dynamic else end end-exec escape except exec execute false fetch first ' +
                                                          'float for force foreign forward free from full function global goto grant ' +
                                                          'group grouping having hour ignore index inner insensitive insert instead ' +
                                                          'int integer intersect into is isolation key last level load local max min ' +
                                                          'minute modify move name national nchar next no numeric of off on only ' +
                                                          'open option order out output partial password precision prepare primary ' +
                                                          'prior privileges procedure public read real references relative repeatable ' +
                                                          'restrict return returns revoke rollback rollup rows rule schema scroll ' +
                                                          'second section select sequence serializable set size smallint static ' +
                                                          'statistics table temp temporary then time timestamp to top transaction ' +
                                                          'translation trigger true truncate uncommitted union unique update values ' +
                                                          'varchar varying view when where with work ',
                                                operators : ' all and any between cross in join like not null or outer some = | '
                                            },
                                            forbiddenWordsFound:[],
	                                        validator:function(value, textarea){  
	                                             var wordsArr = value.split(' ');
                                                 var returnValue = true;
                                               
                                               var i;
	                                             for ( i =0; i < wordsArr.length; i++ ){
	                                               var word = wordsArr[i];
	                                               if (this.codeCfg.forbiddens.indexOf(' '+word.toLowerCase()+' ')>-1){
                                                    if (this.forbiddenWordsFound.indexOf(word.toUpperCase())===-1){
                                                      this.forbiddenWordsFound.push(word.toUpperCase());
                                                    }  
	                                                returnValue = ''; 
	                                               }
	                                             }
                                               
                                                 var  sqlRunBin = this.ownerCt.getComponent('sqlRunBin');
                                                 var sqlRunButt;
                                                 if (sqlRunBin){ sqlRunButt = sqlRunBin.getComponent('sqlRun'); }
                                                 
                                                 if (returnValue===true){
                                                  this.forbiddenWordsFound=[];
                                                   if (sqlRunBin){ sqlRunButt.setDisabled(false); }
                                                 }
                                                 else{
                                                   // var i;
                                                   for (i =0; value && i < this.forbiddenWordsFound.length; i++ ){
                                                    var valLowerCase = value.toLowerCase();
                                                    if (this.forbiddenWordsFound[i] && valLowerCase.indexOf(this.forbiddenWordsFound[i].toLowerCase() )>-1){ var jsLintAlibi =1;}
                                                    else{
                                                      this.forbiddenWordsFound.splice(i);
                                                    }
                                                   }
                                                   // var i;
                                                   for (i =0; value && i < this.forbiddenWordsFound.length; i++ ){
                                                      returnValue+=  '<b  class="xty_syntax-forbidden" >'+this.forbiddenWordsFound[i]+'</b> ';
                                                   }
                                                   returnValue = 'contains forbidden Syntax' + returnValue;  
                                                   if (sqlRunBin){ sqlRunButt.setDisabled(true); }
                                                 }
                                                 
	                                             return returnValue;
	                                          },
											
											listeners:{
												validitychange:function (textarea, isValid ){
													if (textarea.codeViewPanelEl){
                                var codeViewPanelEl = Ext.get(textarea.codeViewPanelEl.id);
                                var remWidth = isValid?5:23;
                                codeViewPanelEl.setWidth( textarea.getWidth()-Ext.get(textarea.id+'-labelEl').getWidth()-remWidth );
													}	
												},
												
												afterrender:function(textarea){
													if (!textarea.codeViewPanelEl){
                                                         var codeViewPanelEl = Ext.DomHelper.append(textarea.id, {
								                            tag: 'div',
								                            id:textarea.id+'-codeViewPanel',
								                            style:'margin-top:-18px;margin-left:'+(Ext.get(textarea.id+'-labelEl').getWidth()+5)+'px;',
								                            width:textarea.getWidth()-Ext.get(textarea.id+'-labelEl').getWidth(),
								                            cls: 'xty_codepanel',
								                            html:'code'
								                            });
								                          codeViewPanelEl = textarea.getEl().appendChild( codeViewPanelEl) ;
								                          textarea.codeViewPanelEl = codeViewPanelEl;
                                          
                                                          codeViewPanelEl.on('click', function(){
                                                              codeViewPanelEl.addCls("xty_displayNone");
                                                              var textareaBodyEl = Ext.get(textarea.id+'-bodyEl');
                                                              textareaBodyEl.removeCls("xty_displayNone");
                                                              textarea.focus();
                                                           });
                                                      }

                                                    textarea.updateCodeViewPanel(textarea);
                                                    textarea.validate();
                          
												},
                                                blur:function(textarea){
                                                   textarea.updateCodeViewPanel(textarea);
                                                }
		
											},
                      
                      
                                             updateCodeViewPanel:function(textarea){
	                                             // var codeViewPanelEl =
                                                // textarea.ownerCt.getComponent("sqlSyntaxPanel");
                                              var codeViewPanelEl = Ext.get(textarea.codeViewPanelEl.id);
	                                             var syntaxedHtml = ''; // textarea.value;
	                                             var wordsArr = textarea.value.split(' ');
	                                             codeViewPanelEl.removeCls('x-panel-invalid');
	                                             var i;
	                                             for ( i =0; i < wordsArr.length; i++ ){
	                                               var word = wordsArr[i];
	
	                                               var syntaxCls = 'xty_syntax-word';
	                                               var forbiddenTooltipAtt ='';
	                                               if (textarea.codeCfg.forbiddens.indexOf(' '+word.toLowerCase()+' ')>-1){
	                                                syntaxCls+=' xty_syntax-forbidden';
	                                                forbiddenTooltipAtt =' title="is forbidden Syntax"';
	                                                codeViewPanelEl.addCls('x-panel-invalid');
	                                               }
	                                               
	                                               if (textarea.codeCfg.keywords.indexOf(' '+word.toLowerCase()+' ')>-1){
	                                                syntaxedHtml+=' <span '+forbiddenTooltipAtt+' class="'+syntaxCls+' xty_syntax-sqlKeyword" style="color:blue">'+word+'</span> ';
	                                               }
	                                               else if (textarea.codeCfg.operators.indexOf(' '+word.toLowerCase()+' ')>-1){
	                                                syntaxedHtml+=' <span '+forbiddenTooltipAtt+' class="'+syntaxCls+' xty_syntax-sql-operator" style="color:#2AB2EE;">'+word+'</span> ';
	                                               }
	                                               else if (textarea.codeCfg.funcs.indexOf(' '+word.toLowerCase()+' ')>-1){
	                                                syntaxedHtml+=' <span '+forbiddenTooltipAtt+' class="'+syntaxCls+' xty_syntax-sqlFunc" style="color:#288000;">'+word+'</span> ';
	                                               }
	                                               else{
	                                                syntaxedHtml+=' <span class="xty_code">'+word+'</span> ';
	                                               }
	                                             }  
	                                               codeViewPanelEl.dom.innerHTML=syntaxedHtml;
                                                   var textareaBodyEl = Ext.get(textarea.id+'-bodyEl');
                                                   textareaBodyEl.addCls("xty_displayNone");
                                                   codeViewPanelEl.removeCls("xty_displayNone");
                                                   
                                                   var textareaTAGEl = textareaBodyEl.dom.getElementsByTagName('textarea')[0];
                                                   Ext.get( textareaTAGEl).setHeight(codeViewPanelEl.getHeight());
                                                 }
											},

                                      {xtype:'fieldcontainer', itemId:'sqlRunBin', fieldLabel: '&nbsp;SQL Run' , 
                                      items:[ { xtype: 'button',tooltip:'run', itemId:'sqlRun', iconCls:'xty_formbutton-start' , disabled:true } ]
                                      
                                      },
                                      
                                      {xtype:'tbspacer', height:8},   
                      
                                                    		 {xtype:'combo', itemId:'language', name:'language', fieldLabel: '&nbsp;Sprache'},
// {xtype:'combo', itemId:'tags', name:'tags',
// store: tagsStore,
// queryMode: 'local',
// displayField: 'name',
// multiSelect:true,
// emptyText: 'Pick tags',
// valueField: 'shortcut',
// value: 'WA',
// fieldLabel: '&nbsp;Tags'},
  
                                                    		 {xtype:'combo',  name:'collections',
                                                    			 itemId:'collections', 
                                                    			 store: collectionsStore,
                                                    			 queryMode: 'local',
                                                                  width: 150,
                                                    			 displayField: 'name',
                                                    			 multiSelect:true,
                                                 	  			 emptyText: 'Pick or create a Tabtype',
                                                 	  			 valueField: 'id',
                                                    			 fieldLabel: '&nbsp;Sammlung',

                                                    			 
                                                                 listConfig : {
                                                              	   misnWidth:150, width: 150,
                                                                     getInnerTpl : function(displayField) {
                                                                       // var tpl = '{[values.newEntry ? "<img
                                                                        // src=../img/icons/newModifier_16.png/><span
                                                                        // class=xty_newComboEntry>" : ""]}' + '{name}'
                                                                        // + '{[values.newEntry ? "</span>" : ""]}';
                                                                       // var tpl = '{[values.newEntry ? "<div
                                                                        // class=xty_newComboEntry>" : ""]}' + '{name}'
                                                                        // + '{[values.newEntry ? "</div>" : ""]}';

                                                                    	 var tpl = '<div {[values.newEntry ? "class=xty_combo-list-newEntry title=neues_Entry_wird_angelegt" :  ""]}>' + '{name}' + '</div>';
                                                                       
                                                                       return tpl;
                                                                     }
                                                                   },
                                                    			 
	                                      	    	    		   listeners:{
		                                  			    		         change: function(combo) {	 
		                                  			    		        	// alert("collection-combo change");
			                                  			    		        },
				                                  			    		 
		                                  			    		         render: function(combo) {	
		                                  			    		        	// alert("collection-combo render");
		                                  			    		        	combo.getEl().on('dblclick', function( evt, target, eOpts ) { 	   
		                                  				    		        	   alert("collection-combo doubleclick");
		                                  				    		        	   }
		                                  				    		           );   
		                                  			    		        	
	                                  			    		              var delayedTaskCreateNewComboEntry = new Ext.util.DelayedTask(function(){
	                                  			    		            	createNewComboEntry(combo);
		                                  			    		           });
	                                  			    		              
	                                  			    		              var delayOnkeyup = function(){
	                                  			    		            	delayedTaskCreateNewComboEntry.delay(600);  
			                                  			    		      };	                                  			    		              

			                                  			    		      combo.getEl().on('keyup', delayOnkeyup);	
		                                  			    		        	
		                                  			    		         }
		                                  	    	    		   }
                                                    			 
                                                    			 
                                                    		  },                                                    			 
                                                    			 
                                                    		 {xtype:'tbspacer', height:8},	 
                                                    		 
// Ext.create('Ext.ux.form.field.BoxSelect', { // kills not dirtychange:false event
// fieldLabel: '&nbsp;Tags',
// displayField: 'name',
// width: 350,
// labelWidth: 130,
// store: tagsStore,
// queryMode: 'local',
// emptyText: 'Pick tags',
// valueField: 'shortcut',
// forceSelection: false,
// createNewOnEnter: true,
// createNewOnBlur: true,
// value: 'WA, TX'
// }),
                                                               
                                                            {xtype:'tbspacer', height:16},
                                                           
                                                            { xtype:'displayfield', value:'<b>Typspezifische Metadaten </b>' },	   
                                                            {xtype:'combo', itemId:'sortby', name:'sortby',fieldLabel: '&nbsp;Sortieren nach'},
                                                            {xtype:'radiogroup', itemId:'order', fieldLabel: '&nbsp;Reihenfolge', items:[  {name:'sortbyASC',boxLabel: 'Aufsteigend'}, {name:'sortbyDESC',boxLabel: 'Absteigend'}]},
                                                            
                                                            {xtype:'checkboxgroup', itemId:'showIn', name:'showIn', fieldLabel: '&nbsp;Zeige', items:[  {name:'showINTab',boxLabel: 'Text'}, {name:'showINWindow',boxLabel: 'in neuem Fenster'}]},
                                                            
                                                    		
                                                            {xtype:'tbspacer', height:16}, 
                                                            
                                                            Ext.create('Ext.ux.ColorField', {
                                                            	itemId:'color',
                                                   				xtype:'colorfield',
                                                   				labelWidth : 130,
                                                   				allowBlank:false, labelSeparator :getLabelSeparator4Required(),
                                                   				fieldLabel: '&nbsp;Farbe',
                                                   				width : 350,
                                                   				value:'#A4C143',
                                                   				name: 'color'
                                                   				}),
                                                      				
                                                      			 {xtype:'tbspacer', height:10}	
                                                        ]
                                           	}
                                           ]
                                    		   
                            	       },    
                            	       {border:false,title:'Attribute'}, {title:'Epobs'},
   
                      		            
               	                    {
                            	    	   
                  	                    title: 'Konfiguration',
                   	                    itemId:storagePageItemId,
                   	                    border:false,
               	                        closable: true,
               	                        layout:'hbox',
               	                        // layout:'anchor',
               	                       
               	                        items:[
               	                               {
               	                            	   flex:1,
               	                            	   border:false,
               	                            	   itemId:'epobColumnCenter',
               	                            	   
               	                               items:[
               	                               
               	                                {html:'<input type="dropbox-chooser" name="selected-file"   style="visisssbility: hidden;" id="db-chooser"/>'},
               	                               
               	                                Ext.create('Ext.grid.Panel', {
               	                                	borsder:false,

               	                                	viewConfig: { emptyText: 'keine Konfigurationseintr&auml;ge' } ,
               	                                	height:400,
               	                                	
               	                                	plugins: [ 
               	                                		Ext.create('Ext.grid.plugin.RowEditing', {
                        													     clicksToMoveEditor: 1,
                        													     autoCancel: false
                        													 })],


               	                                	tbar : {
                       	                        		items:[

                       	                        		    {
                            	                            	   xtype:'triggerfield',  
                            	                            	   fieldLabel: 'add value',
                            	                            	   width:400,
                            	                            	   triggerCls:'xty_form-trigger-plus',
                            	                            	   emptyText:'cvs + json allowed',
                            	                            	    onTriggerClick: function() {

                            	                            	    	var currentEditor = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                            	                            	    	
                            	                            	    	var currentTab = this.ownerCt.ownerCt.ownerCt.ownerCt;
                            	                            	    	if (!currentEditor.dirtyByArr){
                            	                            	    		currentEditor.dirtyByArr =[];
                            	                            	    	}
                            	                            	    	currentEditor.dirtyByArr.push(currentTab.id);
                            	                            	    	
                            	                            	    	
                            	                            	    	
                            	                            	    	var editorHasDirtyStar = currentEditor.title.indexOf("*")>-1;
                            	                            	    	var tabHasDirtyStar = currentTab.title.indexOf("*")>-1;
                	                                               		
                            	                            	    	
                            	                            	    	
                	                                               		if (! editorHasDirtyStar){
                	                                               			currentEditor.setTitle(currentEditor.title+" *");
                	                                               		} 
                	                                               		
                	                                               		if (! tabHasDirtyStar){
                	                                               			currentTab.setTitle(currentTab.title+" *");
                	                                               		}	
                            	                            	    	
                            	                             	       var val =this.getValue();
                            	                            	       if (!val){
                            	                            	    	   val =' localStorage ';
                            	                            	       }
                            	                            	       
                            	                            	       else if (val.indexOf(':')>-1 ){
                            	                            	    	   var obj = Ext.decode('{'+val+'}');
                            	         
                            	                            	    	   var search = Ext.create('Search', obj);
                            	                            	    	   search.save(); 
                            	                            	    	   this.setValue("");
                            	                            	    	   
                            	                            	       }
                            	                            	       else if (val.indexOf(',')>-1){
                            	                            	    	   valArr = val.split(",");
                            	                               	           var search = Ext.create('Search', {name: ''+valArr[0], query: ''+valArr[1]});
                            	                            	    	   search.save();   
                            	                            	       } 
                            	                            	       else{
                            	                            	    	   var search = Ext.create('Search', {name: ''+val});
                            	                               	    		// uses the configured LocalStorageProxy to save
                                                                      // the new Search to localStorage
                            	                               	    		search.save(); 
                            	                               	    		this.setValue("");
                            	                            	       }
                            	                            	       
                            	                            	       this.focus();
                            	                            	    	Ext.data.StoreManager.lookup('localStorageStore').load();	
                            	                            	    	
                            	                            	        
                            	                            	    }
                            	                                }
 
                       	                        		       ]
                       	                        		},

               	                                    margin:extVia.regApp.myRaster.pgBoxMargins,
               	                                    
               	                                    // title: configGridTitle,
               	                                    store: Ext.data.StoreManager.lookup('localStorageStore'),
               	                                    columns: [
               	                                        { header: 'Name',  dataIndex: 'name' , width:300 ,
               	                                        editor: {
               	                                    		xtype: 'triggerfield',
               	                                    		allowBlank: false
               	                                    	  },
                                                        
                                                        ressnderer:function( value, metaData, record, rowIndex, colIndex, store, view )  {
                                                        var url = value.replace(/(.[^>]*>)(.[^<]*)(<.*)/,'$2') ;  
                                                         var html =
                                                         '<div><iframe style="height:120px" src="'+url+'" /></div>';  
                                                         return html;
                                                          
                                                        }
                                                        
                                                        },
               	                                        { header: 'query',                	                                        
               	                                        editor: {
               	                                    		xtype: 'textfield',
               	                                    		allowsBlank: false
                            														},
                            														dataIndex: 'query'},
               	                                        { header: 'id', dataIndex: 'id' }
               	                                    ],

               	                                    listeners:{ 
               	                                    	//

                        // afterrender : function(grid) {
                        // grid.on('edit', function(editor, e) {
                        // editor.record.save();
                        // });
                        // },
                        														edit : function(editor, e) {  
                        														  editor.record.save();  
                        															// e.record.commit();
                        														}
                        
                        													 }
               	                                   
               	                                })
               	                                
               	                               ]},
    
               	                                
               	                             {
     	                            	    	   // title: 'info acc',
     	                            	    	   layout:'accordion',
     	                            	    	   
     	                            	    	   height: panelmW.getHeight()-extVia.constants.raster.pgjobEditHeight-114 ,
     	                            	    	   border:false,
     	                            	    	   style:'border-left:1px solid #99bce8',
     	                            	    	   width:320,
     	                     	                   items:[
     	                     	                          {title: 'pan 1', html:'info content 1', tools:[{id:'left'}]}
     	                     	                         ,{title: 'pan 2', html:'info content 2'}
     	                     	                         ,{title: 'pan 3', html:'info content 3'}
     	                     	                         ,{title: 'pan 4', html:'info content 4'}
     	                     	                         ,{title: 'pan 5', html:'info content 5'}
     	                     	                         ,{title: 'pan 6', html:'info content 6'}
     	                     	                          ]
     	                      	               }     
               	                        ]
               	                    }// eo Konfigurationstorage
                            	   ] } )                            
                            ] 
                   
                   }, 
                   

                   
                   
                   {
         		         title: 'Suchergebnis',
                         closable:true,
         		         itemId:'menge',
         		         
        		         tbar : extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:"Objekte mit Tag", epobDscr:"superhero",  pgjobButtons: menge2PgjobButtons} ), 
        		         items:	Ext.create('Ext.grid.Panel', {
        		        	 
        		        	 	height:mengengridHeight,
        		        	 	
        		        	 	id:"mengenGrid",

        		        	 	
        		        	 	// paging bar on the bottom
        		                bbar: mengengridPagingToolbar,
        		               
        		                
        		                features: [Ext.create('Ext.grid.feature.Grouping',{
        		                    groupHeaderTpl: 'grouped by <i>{[Ext.getCmp("mengenGrid").getColumnName()]}</i> : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
        		                })],    
    
        		        	 getColumnName:function(){        		                
        		        		 // var grid =this; //Ext.getCmp("mengenGrid");
        		        		 var columnFieldName = this.features[0].getGroupField();
        		                 return  columnFieldName ;
        		                 },

        		                
                             border:false,
        		        	 store: Ext.data.StoreManager.lookup('mengenStore'),
        		        	 selModel: Ext.create('Ext.selection.CheckboxModel'),
                             multiSelect : true,
                             columns: [
                                 {xtype: 'rownumberer', width:30},
                                 { header: 'Typ', dataIndex: 'typ'  , width:80},
                                 { header: 'Bild', dataIndex: 'image', width:60},
                                 { header: 'Name',  dataIndex: 'name', width:160, renderer:highlightRenderer },
                                 { header: 'ArtikelNr', dataIndex: 'productnumber', width:60, renderer:highlightRenderer },
                                 { header: 'Tag',  dataIndex: 'tags', flex: 1 , renderer:highlightRenderer},
                                 { header: 'Pfad',  dataIndex: 'path', flxxex: 1 },
                                 { header: 'EPIM-Id', dataIndex: 'epimId' , width:60, renderer:highlightRenderer},
                                 { header: 'Status', dataIndex: 'status', width:32 , 
                                    renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {return '<div class="xty_icon xty_icon'+value+'"></div>'; }
                                 },
                                 { header: 'Eltern-Id', hidden:true,dataIndex: 'parentId', width:60 },
                                
                                 {
                                     header: 'Progress',
                                     dataIndex: 'progress',
                                     width: 60,
                                     renderer: function (value, metadata, record) {
                                         var id = Ext.id();
                                         Ext.defer(function () {
                                             Ext.widget('progressbar', {
                                                 renderTo: id,
                                                 // text: value +'%',
                                                 value: value / 100,
                                                 width: 50
                                             });
                                         }, 50);
                                         return Ext.String.format('<div title="'+value+'%" id="{0}"></div>', id);
                                     }
                                 },
                                 
                                 { header: 'ix', dataIndex: 'dbIndex'  , width:36 }  
                             ]        
                         })
                   }, 
     		       /**/     
 
                   
                                
                 {
       		         title: 'Menge tb2',closable:true,
       		         itemId:'menge_tb2',
      		         tbar : extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:"Menge &Uuml;bersicht",  pgjobButtons: mengePgjobButtons} ), 
      		         items:[extVia.stores.initTagsDataview()]
                 }
                 
   		        // ,{title: 'electroshocker', height:mengengridHeight,html:' <iframe
              // src="http://www.staggeringbeauty.com/" style="border: 0px inset #ddd" width="100%"
              // height="100%"></iframe>'},
	            ]// eo center TabItems
	        };
	    
	    var centerTabPan  =  extVia.regApp.myRaster.initCenterTabPanel(tabCfg); 
    	extVia.regApp.myRaster.addToCenter(centerTabPan);
    	
    	
// extVia.regApp.myRaster.addToCenter({
// margin : '24 0 0 0',
// height:140,
// border:false,
// cls:'xty_regionCenterSouth',
//    			
// items:[ {border:false,region:'south',html:'abcdefg'}]
//    		
// });
//    	
        // var panelmC =
       // var centerWidth = panelmC.getWidth();
    	
        var panelmW = Ext.getCmp('panel_mC');
        var rechHeight = panelmW.getHeight()-260;
        

        
    	var treeStores = extVia.stores.initTreeStores();

	    var productsTreePan = Ext.create('Ext.tree.Panel', {
	    	rootVisible:true,
	        store: treeStores.productsStore,
	        border: false,
	        preventHeader: true,
	        header: false,
	        hideHeader: true,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true
	    });
        
	    var elementsTreePan = Ext.create('Ext.tree.Panel', {
	    	rootVisible:true,
	        store: treeStores.elementsStore,
	        border: false,
	        preventHeader: true,
	        header: false,
	        hideHeader: true,
	        viewConfig: {
	            plugins: {
	                ptype: 'treeviewdragdrop'
	            }
	        },
	        useArrows: true
	    });
        
        
	    var westTabPan  =  extVia.regApp.myRaster.initWestTabPanel(
	    	{
	    	activeTab:'hierarchy',
	    	items:[
	    	       extVia.query.statics.getQueryTabCfg() ,
	    	       extVia.query.statics.getElastictQueryTabCfg() ,
                   extVia.hierarchy.statics.getHierarchyTabCfg({}),    	       
	    	       
// {
// title: 'Hierarchie',
// id : 'hierarchy',
// itemId : 'hierarchy',
// border:false,
// margins : '0 0 0 0',
// layout:'fit',
// items:[
// {border:false,height: 690,html: "<img style='' src='../img/fakes/hierarchien.png'/>"}
// ]
// 
// },
	    	       {  
	    	    	   title: 'Sammlungen', hidden:true,
	    	    	   id : 'collections',
	    	    	   itemId : 'collections',
	    	    	   border:false,
	    	    	   margins : '0 0 0 0',
	    	    	   layout:'fit',
	    	           items:[
	    	                  {border:false,height: 550,html: "<img style='' src='../img/fakes/sammlungenWest.png'/>"}
	    	                  ]
 
	    	       },
	    	       {  
	    	    	   title: 'Tags', hidden:true,
	    	    	   id : 'tags',
	    	    	   itemId : 'tags',
	    	    	   border:false,
	    	    	   margins : '0 0 0 0',
	    	    	   layout:'fit',
	    	    	   
	    	    	   
	    	    	   defaults:{
	    	    		   listeners:{
	    	    			   
			    		         render: function(panel) {	 
				    		           panel.body.on('dblclick', function( evt, target, eOpts ) {

				    		        	   extVia.regApp.myRaster.getCenter().items.get(0).setActiveTab(1);
				    		        	   // me.setValue("#"+colorpicker.getValue());
				    		        	   }
				    		           );   
			    		         }
	    	    		   }
	    	    	   },
	    	    	   

	    	    	   
	    	           items:[
	    	                  {border:false,height:578,
	    	                	  html:"<img src='../img/fakes/tagcloud.jpg'/><img src='../img/fakes/tag_feuer.gif'/>"}
	    	           ]
	    	       }    	       
	    	       
	    
	    	       
	    	       ]}); 
	    
    	extVia.regApp.myRaster.addToWest(westTabPan);
         
        // extVia.accessArea.modules.access.openLanguageModule();
      
// var routingCfg = extVia.regApp.myRaster.getRoutingConfigFromUrl();
// if (routingCfg){
// if (routingCfg.loadType =='Naviitem'){
// if (routingCfg.loadId =='dashboardToggle'){
// var dashboardToggle =
// extVia.regApp.myRaster.getNorth().getComponent('dashbToggle-wrapper').getComponent('tbar').getComponent('dashboardToggle');
// //dashboardToggle.showMenu();
// //dashboardToggle.menu.getComponent('navis').menu.showBy(dashboardToggle);
// dashboardToggle.showMenu();
// }
// }
// }
            
      
         var removeLoadingStateTask = new Ext.util.DelayedTask(function(){Ext.getBody().removeCls("xty_body-isLoading");});
         removeLoadingStateTask.delay(100);
         // "You can't keep doing the same thing over and over and expect different results."
         
         
        

        
    }
    
   
});








/*
 * 
 * $Revision: 1.160.6.16 $ $Modtime: 10.10.12 12:39 $ $Date: 2019/02/21 16:43:57 $ $Author: slederer $ $viaMEDICI
 * Release: 3.9 $
 * 
 */ 
