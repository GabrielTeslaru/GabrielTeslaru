 
 Ext.namespace('extVia.dummies','extVia.dummies.distrib'   );
 
 


 
// users
 // >>> PROD V4 Start (EPIM-7678) <<<
 extVia.dummies.distrib.Users = {
 1 : 'Joe Smith' ,
 2 : 'Sam Jones' ,
 3 : 'Dan Simmons' ,
 4 : 'Jane Doe',
 5 : 'John Hancock'
};
 // >>> PROD V4 End (EPIM-7678) <<<
 
//  Taken from  jira 1686:  

 
 // Assettypen
extVia.dummies.distrib.SYNC_AssetTypes = {
labels:{ SYNC_TYPE:'Zeitpunkt', TYPE:'Typ',  ID:'EPIM-ID', NAME:'Name', SYAS_COMMENT:'Kommentar', CREATION_DATE:'Anlage', CREATION_USRS_ID:'', CHANGE_DATE:'Letzte &Auml;nderung', CHANGE_USRS_ID:'', NODESPECIFIC:'Standort spezifisch'},  
data: 
[  //SYNC_TYPE, TYPE, ID, NAME, SYAS_COMMENT, CREATION_DATE, CREATION_USRS_ID, CHANGE_DATE, CHANGE_USRS_ID
 
 ['sofort','File', 10,"CSVImportFile","CSVImportFile","05/08/2016 14:56:45",1,null,null],
 ['geplant', 'Profile', 12,"CustomerSpecificProfile","CustomerSpecificProfile","05/08/2016 14:56:45",1,null,null, true],
 ['geplant', 'File', 8,"CustomerXSLTScript","CustomerXSLTScript  directory is defined by parameter","05/08/2016 14:56:45",1,null,null],
 ['sofort','File', 13,"CustomJSfunction","CustomJSfunction additional functions","05/08/2016 14:56:45",1,null,null],
 ['sofort','Resource', 4,"CustomResource","CustomResource  we will sync here each entry not the whole file","05/08/2016 14:56:45",1,null,null, true], 

 ['geplant','Image', 3,"DictionaryFormulaImage","DictionaryFormulaImage  EPIMFS/daten/formula","05/08/2016 14:56:45",1,null,null], 
 
 ['sofort','File', 1,"ElementFile","ElementFile  EPIMFS/daten/Archiv","05/08/2016 14:56:45",1,null,null ],
 ['geplant','File', 2,"ElementPreviewsFile","EPIMFS/daten/preview/<customer>","05/08/2016 14:56:45",1,null,null],


 ['geplant','XML', 5,"ProductPreviewXMLExport","ProductPreviewXMLExport","05/08/2016 14:56:45",1,null,null, true],
 
 ['geplant', 'Profile', 9,"WebServiceExportSettingsProfile","WebServiceExportSettingsProfile  ..../production/WebServices/..","05/08/2016 14:56:45",1,null,null],
 
 ['geplant', 'Folder', 6,"XMLExport","XMLExport  EPIMFS/production directory","05/08/2016 14:56:45",1,null,null, true], 
 ['geplant', 'XML', 11,"XMLImportFile","XMLImportFile","05/08/2016 14:56:45",1,null,null]
 
 
] 
};
 





// Distributions = St�dte
extVia.dummies.distrib.SYNC_Nodes = {
 labels: {   
 ID:'EPIM-ID', ISACTIVE:'Aktiv', 
 SERVERNAME:'Server', SERVERSCHEME:'Schema', SERVERPORT:'Port', 
 CDNUPLOAD_SERVERNAME:'Server', CDNUPLOAD_SERVERSCHEME:'Schema', CDNUPLOAD_SERVERPORT:'Port', 
 CDNDOWNLOAD_SERVERNAME:'Server', CDNDOWNLOAD_SERVERSCHEME:'Schema', CDNDOWNLOAD_SERVERPORT:'Port', 
 STATUS:'', NAME:'Name', SYNO_COMMENT:'Kommentar', EMAILLIST:'', 
 GELOCATION_LAT :'Latitude', GELOCATION_LNG :'Longitude', TIMEZONE_UTC :'Zeitzone', TIMEZONE_DST:'Sommerzeit', 
 CREATION_DATE:'Anlage', CREATION_USRS_ID:'', CHANGE_DATE:'Letzte &Auml;nderung', CHANGE_USRS_ID :'', NODESPECIFIC:'Standort spezifisch'
 },
 // >>> PROD V4 Start (EPIM-7678) <<<
data:[  //  ID, ISACTIVE, SERVERNAME, SERVERSCHEME, SERVERPORT, CDNUPLOAD_SERVERNAME, CDNUPLOAD_SERVERSCHEME, CDNUPLOAD_SERVERPORT, CDNDOWNLOAD_SERVERNAME, CDNDOWNLOAD_SERVERSCHEME, CDNDOWNLOAD_SERVERPORT, STATUS, NAME, SYNO_COMMENT, EMAILLIST, GELOCATION_LAT , GELOCATION_LNG , TIMEZONE_UTC , TIMEZONE_DST,CREATION_DATE,CREATION_USRS_ID,CHANGE_DATE,CHANGE_USRS_ID
 [ 1,1,"192.0.2.1","HTTP://",80,"CDN.MSAZURE.DE","HTTP://",1000,"CDN.MSAZURE.DE","HTTP://",2000,"A","Berlin","Firmenzentrale Berlin RZ","joe.smith@example.com",52.5076682,13.2850553,'UTC +1 Stunde', 'Yes', '05/08/2016 14:32:21' ,1, null, null ],
 [ 2, -1,"192.0.2.2","HTTP://",80,"cdn.msazure.com","HTTP://",1000,"cdn.msazure.com","HTTP://",2000,"I","Boston","Boston RZ","jane.doe@example.com",42.3134791,-71.1271965,'UTC -4 Stunden',null , '05/08/2016 14:54:42' ,4, null, null ],
 [ 3,1,"192.0.2.3","HTTP://",80,"cdn.msazure.jp","HTTP://",1000,"cdn.msazure.jp","HTTP://",2000,"A","Tokyo","Tokyo RZ","john.hancock@example.com",35.6693878,139.6012979,'UTC +9 Stunden',null, '05/08/2016 14:54:42' ,5, null, null ]
]
 // >>> PROD V4 End (EPIM-7678) <<<
};




// Ueberwachungs-Tab Allgemein Linker Bereich
extVia.dummies.distrib.SYNC_ASSETLISTS = {
 labels: {   
  ID: 'EPIM-ID', SYNC_ASSETTYPES_ID: 'Synchronization', CDN_ASSET_ID: '', CDN_ASSET_FILENAME: 'Dateiname', STATUS: 'Status', 
  CREATION_DATE: 'Anlage', CREATION_USRS_ID: '', CHANGE_DATE: 'Letzte �nderung', SYNC_TYPE: 'Synchronisation', EPIM_ASSET_KEY: '', EPIM_TARGET_DIRECTORY: 'Ziel Verzeichnis', ACTION: 'Aktion', BOSTON: 'Boston', BERLIN: 'Berlin', TOKIO: 'Tokio'
 },
data:[  // ID, SYNC_ASSETTYPES_ID, CDN_ASSET_ID, CDN_ASSET_FILENAME, STATUS, CREATION_DATE, CREATION_USRS_ID, CHANGE_DATE, SYNC_TYPE, EPIM_ASSET_KEY, EPIM_TARGET_DIRECTORY, ACTION
 [1, 1,"A95768F42536GIR645294","Bohrhammer1400.jpg","New" ,'08/08/2016 15:04:01', 1,null,"geplant: heute 18 Uhr","ElementFile_3254","EPIMFS/Daten/Archiv/Image/2016/02/10","U" ,'Success','','Success'],
 [2, 2,"A95768F42536GFT615298","Bohrhammer1400.jpg","Running" ,'08/08/2016 15:04:59', 1,null,"sofort","ElementPreviewFile_3254","EPIMFS/Preview","U" ,'Success','','Success'],
 [3, 1,"A95768F42536GIR645294","Bohrhammer1800.jpg","Failed" ,'08/08/2016 15:04:59', 1,null,"geplant: jetzt","ElementFile_6547","EPIMFS/Daten/Archiv/Image/2016/04/27","U",'','','Error' ],
 [4, 2,"A95768F42536JUG624131","Bohrhammer1800.jpg","Running" ,'08/08/2016 15:04:59', 1,null,"sofort","ElementPreviewFile_6547","EPIMFS/Preview","U" ,'','','Success'],
 [5, 4,"A95768F42536PKH776185","ResourcesdeDE_ElementCategory.properties","Running" ,'08/08/2016 15:04:59', 1,null,"sofort","ResourcesdeDE_ElementCategory",null,"U",'Success','Success','' ],
 [6, 4,"A95768F42652ABK376542","ResourcesdeDE_PRATLength.properties","Running" ,'08/08/2016 15:04:59', 1,null,"sofort","ResourcesdeDE_PRATLength",null,"U" ,'','Success','Success'],
 [7, 4,"A95768F44829BJK748264","ResourcesdeDE_PRATHight.properties","Started" ,'08/08/2016 15:04:59', 1,null,"sofort","ResourcesdeDE_PRATHight",null,"U" ,'Uploading','Waiting','Waiting'],
 [8, 4,"A95768F46923ACB736382","ResourcesdeDE_PRATWidht.properties","Running" ,'08/08/2016 15:04:59', 1,null,"sofort","ResourcesdeDE_PRATWidht",null,"U",'Success','Success','' ]
]
};


//  Ueberwachungs-Tab Spezifisch Standorte Rechts eine Row ist eine Zelle
extVia.dummies.distrib.SYNC_ASSETLISTNODES = {
 labels: {   
ID: 'EPIM-ID', SYNC_ASSETTYPES_ID: 'Typ', SYNC_NODES_ID: '', SYNC_ASSETLISTS_ID: '', STATUS: 'Status', DIRECTION: '', 
CREATION_DATE: 'Anlage', CREATION_USRS_ID: '', CHANGE_DATE:'Letzte �nderung'
 },
data:[  // ID, SYNC_ASSETTYPES_ID, SYNC_NODES_ID, SYNC_ASSETLISTS_ID, STATUS, DIRECTION, CREATION_DATE, CREATION_USRS_ID,CHANGE_DATE
[ 1, 1,1,1,"N","U", '08/08/2016 15:04:01' ,1,null],
[ 2, 1,2,1,"N","D", '08/08/2016 15:04:01' ,1,null],
[ 3, 1,3,1,"N","D", '08/08/2016 15:04:01' ,1,null],

[ 4, 2,1,2,"S","U", '08/08/2016 15:04:59' ,1,null],
[ 5, 2,2,2,"S","D", '08/08/2016 15:04:59' ,1,null],
[ 6, 2,3,2,"N","D", '08/08/2016 15:04:59' ,1,null],

[ 7, 1,1,3,"N","D", '08/08/2016 15:04:59' ,1,null],
[ 8, 1,2,3,"S","U", '08/08/2016 15:04:59' ,1,null],
[ 9, 1,3,3,"N","D", '08/08/2016 15:04:59' ,1,null],

[ 10, 2,1,4,"S","D", '08/08/2016 15:04:59' ,1,null],
[ 11, 2,2,4,"S","U", '08/08/2016 15:04:59' ,1,null],
[ 12, 2,3,4,"N","D", '08/08/2016 15:04:59' ,1,null],

[ 13, 4,1,5,"S","D", '08/08/2016 15:04:59' ,1,null],
[ 14, 4,2,5,"N","D", '08/08/2016 15:04:59' ,1,null],
[ 15, 4,3,5,"S","U", '08/08/2016 15:04:59' ,1,null],

[ 16, 4,1,6,"S","U", '08/08/2016 15:04:59' ,1,null],
[ 17, 4,2,6,"N","D", '08/08/2016 15:04:59' ,1,null],
[ 18, 4,3,6,"N","D", '08/08/2016 15:04:59' ,1,null],

[ 19, 4,1,7,"S","U", '08/08/2016 15:04:59' ,1,null],
[ 20, 4,2,7,"N","D", '08/08/2016 15:04:59' ,1,null],
[ 21, 4,3,7,"N","D", '08/08/2016 15:04:59' ,1,null],

[ 22, 4,1,8,"S","U", '08/08/2016 15:04:59' ,1,null],
[ 23, 4,2,8,"N","D", '08/08/2016 15:04:59' ,1,null],
[ 24, 4,3,8,"N","D", '08/08/2016 15:04:59' ,1,null]
]
};



// TEMPLATE
extVia.dummies.distrib.DUMMY = {
 labels: {   

 },
data:[  // 

]
};



