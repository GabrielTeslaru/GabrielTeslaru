




Ext.application({
    //see jira  #1686
    name: 'distributions',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      //var centerWidth = centerPan.getWidth()-50;
      var centerHeight = centerPan.getHeight()-92; // ohne pagetoolbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=86;
      }
      if (cfg && cfg.hasSubtabs){
        //centerHeight-=86;
      }      
      return centerHeight;
    },
    
    
    getAssetsTypeComboCfg: function (cfg){     
       var me = this;
      
        var assetTypesComboCfg =  {
                itemId:'assetTypesCombo',
                //id:'assetTypesCombo',
                cls:'xty_assettypesCombo',
                fieldLabel: cfg && cfg.fieldLabel ? cfg.fieldLabel :null,
                emptyText:'Assettypen',
                store:extVia.stores.getDistributionAssetTypesStore({}), 
                queryMode: 'local', 
                displayField: 'dscr',  
                valueField: 'dscr',     
                xtype:'combo',
                //forceSelect:false,
                //allowBlank:false,
                value: extVia.module.epob.MYPRODUCT,
                width: cfg && cfg.width ? cfg.width :200,
               
                
                  listConfig : {
                   minWidth:280,
                   maxHeight:600,
                      getInnerTpl : function(displayField) {
                        var tpl = '<div style="width:100%;height:18px;padding-left:16px;" title="{assettType}" class="xty_distrib-asset xty_distrib-asset-{[values.assetType.toLowerCase()]}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
                        return tpl;
                      }
                    } 
            };
 
       return   assetTypesComboCfg;              
    },
    
  
   getDistributionsComboCfg: function (cfg){       
        var distributionsComboCfg =                 {
                itemId:'distributionsCombo',
                cls:'xty_distributionsCombo',
                emptyText:'Standorte',
                fieldLabel: cfg && cfg.fieldLabel ? cfg.fieldLabel :null,
                store:extVia.stores.getDistributionsStore({}), 
                queryMode: 'local', 
                displayField: 'name',  
                valueField: 'dscr',     
                xtype:'combo',
                //forceSelect:false,
                //allowBlank:false,
                width: cfg && cfg.width ? cfg.width :200

            };
 
       return   distributionsComboCfg;              
    },
    
    
    
    
	  itemcontextmenu: function( view, record, item, index, evt, eOpts ){
	    evt.preventDefault();

        
        var epobType = record.getProxy().getModel().getName();
        
        var geolocation = record.get('geolocation') ; 
        
        var epobDscr = record.get('name') ; 

        if (Ext.isEmpty(epobDscr)){
         epobDscr = record.get('dscr') ; 
        }
        
      
        
        var showEditor = function(){
          me.showEditor({itemId:'edit', epob: {epobType: epobType, dscr: epobDscr , geolocation : geolocation } } , record); 
        };
        
      
        
        
      var isStatusCell = false;
      var isSyncNodeSpecificCell = false;
      var cellCls = Ext.get(evt.target).up( '.x-grid-cell', 8 ).dom.className;
      if (cellCls. indexOf('xty_grid-status-cell')>-1 ){
        isStatusCell = true;
        isSyncNodeSpecificCell = false;
      }
      if (cellCls. indexOf('xty_nextSync-cell')>-1 ){
        isStatusCell = false;
        isSyncNodeSpecificCell = true;
      }        
      //var action = isStatusCell ? 'Status dblclick' : ( isSyncNodeSpecificCell ? 'NodeSpecific dblclick' : 'Assettype dblclick');        
      var filterBy = isStatusCell ? 'Status' : ( isSyncNodeSpecificCell ? 'Standort' : 'Assettype');
        
        
        
        
        
         var contextmenu =   Ext.create('Ext.menu.Menu', {
		    //width: 160,
		    //renderTo: Ext.getBody(),  
		    items: [
        
            { text: 'Bearbeiten' , iconCls: 'x-tool x-tool-edit',  itemId:'edit', handler: showEditor , epob: {epobType: epobType, dscr: epobDscr , geolocation : geolocation }},
              '-',
        
        
            { text: 'Sync-Planner' , itemId:'syncPlaner', iconCls: 'xty_icon xty_iconPlanned',  handler:function(){
               var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
               tabPanCenter.setActiveTab(0);
              }},


            { text: '&Uuml;berwachung' ,   iconCls: 'xty_icon xty_iconRunning', handler:function(){
               var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
               tabPanCenter.setActiveTab(1);
              }
            },
            { text: 'Protokoll', iconCls: 'xty_icon xty_iconExpired', handler:function(){
               var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
               tabPanCenter.setActiveTab(2);
             }
            
            },
            
            { iconCls: 'x-tool-filter',  text: 'Filtern nach '+filterBy}
            
            
            
            
        ]
		});
     
        contextmenu.showAt(evt.getXY());

	  },
    
    itemdblclick: function( view, record, item, index, evt, eOpts ){   
      var epobType = record.getProxy().getModel().getName();
      
      //extVia.notify({action: 'distributions.itemdblclick'  , mssg:  'showEditor 1 '+epobType}); 
      var dscr = record.get('name');
      if (Ext.isEmpty(dscr)){
        dscr = record.get('dscr');
      }
       var geolocation = record.get('geolocation') ; 
      me.showEditor({itemId:'edit', epob:{dscr:dscr, epobType:epobType, geolocation:geolocation}} , record);
    },    
    
 getAssetsTypesListItems: function (cfg){ 
   
   
   
   
    var me = this;

    if (!cfg){cfg={};}
    else{ cfg.insideEdi=true;}

    
    //extVia.notify({action: 'getAssetsTypesListItems'  , mssg:  'getAssetsTypesListItems cfg.insideEdi '+cfg.insideEdi }); 

      var assetsTypesFields = me.getFieldsFromLabels(extVia.dummies.distrib.SYNC_AssetTypes.labels);
      var assetsTypesModel = Ext.define('distrib-SYNC_AssetTypes ', {extend: 'Ext.data.Model', fields: assetsTypesFields });

      //var  assetsTypesData = [ me.getDataAsStrings(extVia.dummies.distrib.SYNC_AssetTypes.data) ];
      var assetsTypesData = [extVia.dummies.distrib.SYNC_AssetTypes.data];
      var assetsTypesStore  = Ext.create('Ext.data.Store', { storeId:'assetTypesStore', model: assetsTypesModel , data: assetsTypesData});  
      var assetsTypesColumns = me.getColumnsFromLabels(extVia.dummies.distrib.SYNC_AssetTypes.labels);
    
      
      var nameClmn = assetsTypesColumns.get('NAME');
      nameClmn.flex = 1;

      var typeClmn = assetsTypesColumns.get('TYPE');
      typeClmn.width = 42; typeClmn.hidden = false;
      typeClmn.renderer =  function ( value, metaData, record, rowIndex, colIndex, store, view )  { return '<div data-qtip="'+value+'" class="xty_distrib-asset-'+ (''+value.toLowerCase()) +'">&nbsp;</div>'; };
      
      
      var nodespeciClmn = assetsTypesColumns.get('NODESPECIFIC');
      nodespeciClmn.hidden = false; //!cfg.insideEdi;
      
      if(cfg.insideEdi){
        nodespeciClmn.header =cfg.epobDscr+' spezifisch';
      }
     
      
      nodespeciClmn.renderer =  function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
        var html;
        if (value){html = '&#10003'};
        return html
      };
      
//      assetsTypesColumns.items.splice(0,0,{ header:'Typ', dataIndex:'NAME', width:42,
//        renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { return '<div data-qtip="'+value+'" class="xty_distrib-asset-'+ (''+value.toLowerCase()) +'">&nbsp;</div>'; }  
//      });
    
      var assetsTypesGridCfg = {
       xtype:'grid',
       itemId:'assetsTypes',
       //plugins: [cellEditing],
       store: assetsTypesStore, //extVia.stores.getDistributionAssetTypesStore({rowsCount: cfg.rowsCount}),
       
       
       border: (cfg && cfg.border)?cfg.border:false ,
       
       width: (cfg && cfg.width)?cfg.width: null ,
       height: (cfg && cfg.height)?cfg.height: 620 ,
       columns: assetsTypesColumns,
       columnsX:[
       {header:'Typ', dataIndex:'assetType', width:42,
        renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {return '<div data-qtip="'+value+'" class="xty_distrib-asset-'+ (''+value.toLowerCase()) +'">&nbsp;</div>'; }
       },
       {header:'Assettyp Name', dataIndex:'dscr', width:180},
       {header:'Typ', dataIndex:'syncType',             
           editor: {   
                           xtype:'combo', 
                           margins:'0 0 0 10',
                           emptyText:'assetTypes',     
                           store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                            data :  [  ['sofort'],['SOFORT'], ['geplant'],['keine']]
                            }) ,                              
                           displayField: 'dscr',
                           typeAhead: true,
                           mode: 'local',
                           triggerAction: 'all',
                           selectOnFocus:true
           }
   
        },
     
        
        {header:'Sync hier', dataIndex:'status,', width:42, hidden: !cfg.insideEdi,
          renderer:  function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
            
            value='Here';
            
          metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value+'" class="xty_icon xty_icon'+value+'"></div>'; 
          }
         
        },
        
        
        {header:'Planung', dataIndex:'scheduling',  hidden:true,          
            editor: {
                xtype: 'textfield',
                allowBlank: false,
                minValue: 0,
                maxValue: 100000
            }
          },
        {header:'Failover', dataIndex:'failover', hidden:true} 
        
        
        
       ]
       
       ,listeners:{
          
          itemdblclick: function( view, record, item, index, evt, eOpts ){   
            var epobType = record.getProxy().getModel().getName();
            
           // extVia.notify({action: 'distributions.itemdblclick'  , mssg:  'cfg.insideEdi['+cfg.insideEdi+'] showEditor 4 '+epobType }); 
            var dscr = record.get('name');
            if (Ext.isEmpty(dscr)){
              dscr = record.get('dscr');
            }
             var geolocation = record.get('geolocation') ; 
             
             if(!cfg.insideEdi){
               me.showEditor({itemId:'edit', epob:{dscr:dscr, epobType:epobType, geolocation:geolocation}} , record);
             }
             else{
//               Ext.create('Ext.window.Window', {
//                 title : 'Synchronization',
//                 modal:true,
//                 y:120,
//                 //height: 200,
//                 width: 520,
//                 layout: 'fit',
//
//                 items : [ {
//                   border : false,
//                   minHeight : 200,
//                   itemId : 'myFormPanel',
//                   xtype : 'form',
//
//                   dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
//                     var dialogButtons = this.ownerCt.getComponent('myButtons');
//                     var activate = dirty;
//                   },
//
//                   fieldDefaults : {
//                     msgTarget : 'side'
//                   },
//                   defaults : {
//                     style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
//                     anchor : '100%',
//                     labelWidth : 150,
//                     width : 350,
//                     msgTarget : 'side'
//                   },
//
//                 items: [
//                   extVia.dialoges.getInstructionPanel({
//                     mainInstr : 'Assettyp '+record.get('NAME'), 
//                     suppInstr : 'Standortspezifische Synchronization f&uumlr '+cfg.epobDscr
//                   }),
//                   
//
//                     {   
//                         xtype:'combo', 
//                         margins:'0 0 0 10',
//                         width:2100,
//                         fieldLabel:'Typ',
//                         emptyText:'',     
//                         store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
//                          data :  [   [ 'Sofort','Started'] , [  'geplant' ,'Scheduled' ], [  'keine', 'Inactive']]
//                          }) ,                              
//                         displayField: 'dscr',
//                         valueField: 'value',
//                         typeAhead: true,
//                         mode: 'local',
//                         triggerAction: 'all',
//                         listConfig : {
//                        getInnerTpl : function(displayField) {
//                          var tpl = '<div style="width:100%;height:18px;padding-left:16px;" title="" class="xty_icon xty_icon{value} "><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
//                          return tpl;
//                        }
//                      }, 
//                      
////                      listeners:{
////                      
////                        change:function ( combo, newValue, oldValue){
////                          var panel = combo.ownerCt ;
////                          
////                          var disable = true;
////                          
////                          if (newValue =='Scheduled'){
////                           disable = false;                
////                          }                
////                          panel.getComponent('scheduling-bin').setDisabled( disable);
////                          panel.getComponent('scheduling-period-bin').setDisabled( disable);
////                          panel.getComponent('period').setDisabled( disable );
////                          panel.getComponent('failover-bin').setDisabled( disable );
////                        }
////                        
////                      },
//                      
//                      selectOnFocus:true
//                     },
//
//                     
//                     { itemId:'scheduling-period-bin',  xtype:'fieldcontainer',  fieldLabel:'Zeitraum', layout:'hbox', width : 540, items:[
//                       { itemId:'scheduling-period', xtype:'numberfield',  value:'', width:80},
//                       { itemId:'scheduling-period-unit', xtype:'combo',  margin:'0 0 0 7', width:100,
//                         store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
//                           data :  [ ['Tage'],  ['Stunden'],  ['Minuten'], ['Sekunden']]
//                           }) ,                              
//                          displayField: 'dscr',
//                          typeAhead: true,
//                          value:'Minuten',
//                          mode: 'local',
//                          triggerAction: 'all',
//                          selectOnFocus:true 
//                       }
//                     ]},
//                     
//                     
//                     { itemId:'scheduling-bin',  xtype:'fieldcontainer',  fieldLabel:'N&auml;chste Synchronisation', layout:'hbox', width : 540, items:[
//                        { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
//                        { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
//                     ]},
//                     { itemId:'failover-bin', xtype:'fieldcontainer',  fieldLabel:'Ersatz Synchronisation', layout:'hbox', width : 540, items:[
//                        { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
//                        { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
//                     ]}       
//
//                   
//                   ]
//                 },
//                      
//                 ],
//                 buttons:[  
//                   {text:'&Uuml;bernehmen', 
//                       handler:function(btn){     
//                         extVia.notify({action: '&Uuml;bernehmen'  , mssg:  'Erfolgreich'});
//                         btn.ownerCt.ownerCt.hide();
//                       } 
//                   },
//
//                   {text:'Abbrechen', handler:function(btn){btn.ownerCt.ownerCt.hide(); } }
//                   ]
//                 }
//               ).show();
               
               
               me.showNodeSpecificSyncDialog({epobDscr:cfg.epobDscr, mainInstr:'Assettype '+record.get('NAME')}, record);
               //me.showNodeSpecificSyncDialog(cfg, record);
               
               
             }
             
            
          }, 
          itemcontextmenu: me.itemcontextmenu
        }
      };
      
      
      return [assetsTypesGridCfg];
    },
    
   
 showNodeSpecificSyncDialog: function (cfg, record){
   
   Ext.create('Ext.window.Window', {
     title : 'Synchronization',
     modal:true,
     y:120,
     //height: 200,
     width: 520,
     layout: 'fit',

     items : [ {
       border : false,
       minHeight : 200,
       itemId : 'myFormPanel',
       xtype : 'form',

       dirtyAndValiditychange : function(basic, dirty, valid, eOpts) {
         var dialogButtons = this.ownerCt.getComponent('myButtons');
         var activate = dirty;
       },

       fieldDefaults : {
         msgTarget : 'side'
       },
       defaults : {
         style : 'margin:0px 10px 0px 14px; padding-bottom:4px;',
         anchor : '100%',
         labelWidth : 150,
         width : 350,
         msgTarget : 'side'
       },

     items: [
       extVia.dialoges.getInstructionPanel({
         mainInstr : cfg.mainInstr, //mainInstr'Assettyp '+record.get('NAME'), 
         suppInstr : 'Standortspezifische Synchronization f&uumlr '+cfg.epobDscr
       }),
       

         {   
             xtype:'combo', 
             margins:'0 0 0 10',
             width:2100,
             fieldLabel:'Typ',
             emptyText:'',     
             store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
              data :  [   [ 'Sofort','Started'] , [  'geplant' ,'Scheduled' ], [  'keine', 'Inactive']]
              }) ,                              
             displayField: 'dscr',
             valueField: 'value',
             typeAhead: true,
             mode: 'local',
             triggerAction: 'all',
             listConfig : {
            getInnerTpl : function(displayField) {
              var tpl = '<div style="width:100%;height:18px;padding-left:16px;" title="" class="xty_icon xty_icon{value} "><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
              return tpl;
            }
          }, 
          
//          listeners:{
//          
//            change:function ( combo, newValue, oldValue){
//              var panel = combo.ownerCt ;
//              
//              var disable = true;
//              
//              if (newValue =='Scheduled'){
//               disable = false;                
//              }                
//              panel.getComponent('scheduling-bin').setDisabled( disable);
//              panel.getComponent('scheduling-period-bin').setDisabled( disable);
//              panel.getComponent('period').setDisabled( disable );
//              panel.getComponent('failover-bin').setDisabled( disable );
//            }
//            
//          },
          
          selectOnFocus:true
         },

         
         { itemId:'scheduling-period-bin',  xtype:'fieldcontainer',  fieldLabel:'Zeitraum', layout:'hbox', width : 540, items:[
           { itemId:'scheduling-period', xtype:'numberfield',  value:'', width:80},
           { itemId:'scheduling-period-unit', xtype:'combo',  margin:'0 0 0 7', width:100,
             store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
               data :  [ ['Tage'],  ['Stunden'],  ['Minuten'], ['Sekunden']]
               }) ,                              
              displayField: 'dscr',
              typeAhead: true,
              value:'Minuten',
              mode: 'local',
              triggerAction: 'all',
              selectOnFocus:true 
           }
         ]},
         
         
         { itemId:'scheduling-bin',  xtype:'fieldcontainer',  fieldLabel:'N&auml;chste Synchronisation', layout:'hbox', width : 540, items:[
            { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
            { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
         ]},
         { itemId:'failover-bin', xtype:'fieldcontainer',  fieldLabel:'Ersatz Synchronisation', layout:'hbox', width : 540, items:[
            { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
            { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
         ]}       

       
       ]
     },
          
     ],
     buttons:[  
       {text:'&Uuml;bernehmen', 
           handler:function(btn){     
             extVia.notify({action: '&Uuml;bernehmen'  , mssg:  'Erfolgreich'});
             btn.ownerCt.ownerCt.hide();
           } 
       },

       {text:'Abbrechen', handler:function(btn){btn.ownerCt.ownerCt.hide(); } }
       ]
     }
   ).show();
   
   
   
   
 },
    
    
    
  /**
   * 
   * @return {}
   */  
  getAssetsTypesGrid: function (cfg){ 

    var me = this;
    
    
    var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
        clicksToEdit: 1
    });
      
      var assetsTypesGrid ={
       xtype:'grid',
       id:'assetTypesSyncPlanner',
       itemId:'assetTypesSyncPlanner',
       
       features: [Ext.create('Ext.grid.feature.Grouping',{
            groupHeaderTpl: 'grouped by <i>{[Ext.getCmp("assetTypesSyncPlanner").getColumnName()]}</i> : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
        })], 
         getColumnName:function(){                            
         //var grid =this; //Ext.getCmp("mengenGrid");
         var columnFieldName = this.features[0].getGroupField();
             return  columnFieldName ;
         },
       
       //plugins: [cellEditing],
       store: extVia.stores.getDistributionAssetTypesStore({}),
       border:false,
       height:me.getCenterHeight(),
       columns:[
       
       
       {header:'Status', dataIndex:'status', width:48,renderer: me.statusRenderer}, 
       
       {header:'Typ', dataIndex:'assetType', width:42,
        renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {return '<div data-qtip="'+value+'" class="xty_distrib-asset-'+ (''+value.toLowerCase()) +'">&nbsp;</div>'; }
       },
       {header:'Assettyp Name', dataIndex:'dscr', width:180,
         renderer: function( value, metaData, record, rowIndex, colIndex, store, view ){
         metaData.tdCls ='xty_name-cell';  
         return value;
         }

       },
        {
         header: 'Assets',
         dataIndex: 'progress',
         width: 60
       },
      
       {header:'SyncType', dataIndex:'syncType', width:80 , resnderer:function(){return '';}}, 
       
      // {header:'Summary', dataIndex:'schedulingSummary', width:80 , resnderer:function(){return '';}}, 
       
       {header:'Summary', dataIndex:'syncType',     width:90,
         
       renderer: function( value, metaData, record, rowIndex, colIndex, store, view ){
          var html = value;
          
          var nextSync = record.get('nextSync');
          html='<span style="color:#888">'+nextSync+'</span>';
          if (nextSync.indexOf('in')==0){
           html='<b>'+nextSync+'</b>';
          }

          html = value+'<br>'+html;
          
          if ((rowIndex + colIndex )%5 == 0){
            html+='<span class=" xty_icon xty_iconHere" style="width:18px; min-width:18px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
          }

          return html;
       }
       
        },
            

       //{header:'Planung', dataIndex:'nextSync', renderer: me.nextSyncRenderer}, 
           
		   {header:'n&auml;chste Synchronisation',columns:[  
         
           
		   {header:'Boston <span style="opacity:0.4;">GMT-4</span>', dataIndex:'nextSync', renderer: me.nextSyncRenderer}, 
		   {header:'Berlin <span style="opacity:0.4;">GMT+2</span> ', dataIndex:'nextSync', renderer: me.nextSyncRenderer}, 
		   {header:'Tokio <span style="opacity:0.4;">GMT+9</span>', dataIndex:'nextSync', renderer: me.nextSyncRenderer}
          ]}
       ]
       
       
       ,listeners:{
          itemdblclick: function( view, record, item, index, evt, eOpts ){
            
            var isStatusCell = false;
            var isAssettypeCell = false;
            var isSyncNodeSpecificCell = false;
            
            //var targetClassName = evt.target.className;   

            var cellCls = Ext.get(evt.target).up( '.x-grid-cell', 8 ).dom.className;  
            
            if (cellCls. indexOf('xty_grid-status-cell')>-1 ){
              isStatusCell = true;
              isAssettypeCell = false;
              isSyncNodeSpecificCell = false;
            }
            
            if (cellCls. indexOf('xty_name-cell')>-1 ){
              isStatusCell = false;
              isAssettypeCell = true;
              isSyncNodeSpecificCell = false;
            }
            
            if (cellCls. indexOf('xty_nextSync-cell')>-1 ){
              isStatusCell = false;
              isAssettypeCell = false;
              isSyncNodeSpecificCell = true;
            }
            
//            var action = isStatusCell ? 'Status dblclick' : ( isSyncNodeSpecificCell ? 'NodeSpecific dblclick' : 'Assettype dblclick'); 
//            var doWhat = isStatusCell ? 'Protocol' : ( isSyncNodeSpecificCell ? 'Filter current asset type and sync node' : 'Filter for current asset type');
//            extVia.notify({action: action  , mssg:  'Open  '+doWhat}); 
            
            
            if (isStatusCell){
              var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
              tabPanCenter.setActiveTab('protocols');
            }
            
            var nodeDscr = '';
            if (isAssettypeCell){
              var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
              tabPanCenter.setActiveTab('monitoring');
              tabPanCenter.getActiveTab().getApplicationbar().setEpobDscr( record.get('dscr'));
              

              
              
            }

            if (isSyncNodeSpecificCell){
              

              if (cellCls.indexOf('Boston')>-1 ){ nodeDscr='Boston';}
              if (cellCls.indexOf('Berlin')>-1 ){nodeDscr='Berlin';}
              if (cellCls.indexOf('Tokio')>-1 ){nodeDscr='Tokio';}
              
              var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
              tabPanCenter.setActiveTab('monitoring');
              tabPanCenter.getActiveTab().getApplicationbar().setEpobDscr( record.get('dscr') +' in ' + nodeDscr);
  
            }
            
            
         
          },   
          itemcontextmenu: me.itemcontextmenu
        }
       
      };

      
      return assetsTypesGrid;
    },   

    
  
	nextSyncRenderer :function( value, metaData, record, rowIndex, colIndex, store, view ){
	  
	  var cellColumnHeader = ''
	    
	  if   (colIndex === 6 ){ cellColumnHeader ='Boston'; }
	  else if   (colIndex === 7 ){ cellColumnHeader ='Berlin'; }
	  else if   (colIndex === 8 ){ cellColumnHeader ='Tokio'; }
	      
	  metaData.tdCls ='xty_nextSync-cell xty_nextSync-cell-'+cellColumnHeader;
		var html = value;

		html='<span style="color:#888">'+value+'</span>';
		if (value.indexOf('in')==0){
		 html='<b>'+value+'</b>';
		}

		// html= '<br>'+html;
    if ((rowIndex + colIndex )%5 == 0){
      html+='<span class=" xty_icon xty_iconHere" style="width:18px; min-width:18px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
    }
    html= '<br>'+html;
    
		return html;
	},
	
	
	
	
   statusCnt : 0,
   status : function (){
      var me = this; 
      var status = 'Unknown'; 
       if (me.statusCnt%3==0){status='Success';}
       if (me.statusCnt%5==0){status='Loading';}
       if (me.statusCnt%7==0){status='Waiting';}
       if (me.statusCnt%9==0){status='Error';}
       //if (me.statusCnt%11==0){status='Deprecated';}

       me.statusCnt++;
       
       status={ main:status, karlsruhe:'Unknown'}
       return status; 
   },
    
   getAssetsStore : function(cfg){ 
    
      var me = this; 
    
      var store = Ext.data.StoreManager.lookup('distributionAssetsStore');
      
      var statusCnt = 0;
      var status =  function (){
       var status = 'Unknown'; 
       
        
        if (statusCnt%3==0){status='Downloading';}
        //if (statusCnt%5==0){status='Uploading';}
       
       
       if (statusCnt%5==0){status='Success';}
//       if (statusCnt%5==0){status='Loading';}
       if (statusCnt%7==0){status='Waiting';}
       if (statusCnt%9==0){status='Error';}
       //if (statusCnt%11==0){status='Deprecated';}
       statusCnt++;
       //status={ main:status, karlsruhe:'Unknown'}
       return status; 
      };
      

      
       var statusAll =  function (){
        statusCnt = Math.floor((Math.random() * 10) + 1); 
         var statusAll={ main: status, karlsruhe:status(),ettlingen:status(),walldorf:status(),brussel:status(),kassel:status()}
         return statusAll;    
       };
      
      
      if (!store){
            var model = Ext.define('distributionAssets', {extend: 'Ext.data.Model', 
              fields: [
                  { name: 'name'}, {    name: 'status'},  { name: 'statusAll'},   { name: 'assetType'},{name: 'dscr'}, { name: 'syncType'}] });
            
        var data = [];

data.push({status: status(),statusAll:statusAll(), dscr:'Deses und das',   assetTypeDscr:"xxxxxxxxxxxxxCustom viaResource entries ", assetType:'Resource' ,syncType:'sofort'}  );
data.push({status: status(),statusAll:statusAll(), dscr:'Abc',   assetTypeDscr:"Element previews ", assetType:'File' ,syncType:'sofort'});
data.push({status: status(),statusAll:statusAll(), dscr:'e5sjsrtj',   assetTypeDscr:"Formula  images ", assetType:'Images',syncType:'sofort'} );
data.push({status: status(),statusAll:statusAll(), dscr:'LKDFJGLER()/',   assetTypeDscr:"Custom JS-Functions", assetType:'Script',syncType:'geplant'} );
data.push({status: status(),statusAll:statusAll(), dscr:'srtjsrtjsj',   assetTypeDscr:"Preview XSLTs, ", assetType:'XML',syncType:'geplant'} );
data.push({status: status(),statusAll:statusAll(), dscr:'sjsrj',   assetTypeDscr:"Preview templates ", assetType:'XML',syncType:'geplant'} );
data.push({status: status(),statusAll:statusAll(), dscr:'dtzidtzi',   assetTypeDscr:"EPIMFS/produktion directory", assetType:'Folder',syncType:'sofort'} );
data.push({status: status(),statusAll:statusAll(), dscr:'BBBtzidtzi',   assetTypeDscr:"EPIMFS/produktion directory", assetType:'Folder',syncType:'sofort'} );
data.push({status: status(),statusAll:statusAll(), dscr:'CCCdtzidtzi',   assetTypeDscr:"EPIMFS/produktion directory", assetType:'Folder',syncType:'sofort'} );

data.push({status: status(),statusAll:statusAll(), dscr:'zj56835',   assetTypeDscr:"CSV-Imports ", assetType:'',syncType:'sofort'} );
data.push({status: status(),statusAll:statusAll(), dscr:'dtzidti',   assetTypeDscr:"XML-Imports ", assetType:'',syncType:'sofort'} );
data.push({status: status(),statusAll:statusAll(), dscr:'dtzidtzi',   assetTypeDscr:"Export markupgroup XSLT", assetType:'',syncType:'geplant'} );
data.push({status: status(),statusAll:statusAll(), dscr:'srtjsrtj',   assetTypeDscr:"Export markupgroup batchjobs", assetType:'Script',syncType:'keine'} );
data.push({status: status(),statusAll:statusAll(), dscr:'lkdrgler0349',   assetTypeDscr:"WebService-ExportSettings profile", assetType:'',syncType:''} );
data.push({status: status(),statusAll:statusAll(), dscr:'sklghl34076034',   assetTypeDscr:"Support datacheck", assetType:'',syncType:''} );
data.push({status: status(),statusAll:statusAll(), dscr:'klbgl680',   assetTypeDscr:"Exportfolders", assetType:'Folder',syncType:''} );

data.push({status: status(),statusAll:statusAll(), dscr:'went nQ IQ.l4tnq',   assetTypeDscr:"Element files ",syncType:''} );   
data.push({status: status(),statusAll:statusAll(), value:  extVia.module.epob.ELEMENTS , assetType:'File',  dscr:'dfljhdr03497z034',   assetTypeDscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.ELEMENTS +"_P"],syncType:''} ); 
data.push({status: status(),statusAll:statusAll(),  value:  extVia.module.epob.IMAGE , assetType:'File',  dscr:'dlfjh53z35',   assetTypeDscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.IMAGE +"_P"],syncType:''} ); 
data.push({status: status(),statusAll:statusAll(),  value:  extVia.module.epob.AUDIO , assetType:'File',  dscr:'6546erkjerpjh',   assetTypeDscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.AUDIO +"_P"],syncType:''} ); 
data.push({status: status(),statusAll:statusAll(),  value:  extVia.module.epob.VIDEO , assetType:'File',  dscr:';XCMFBVKREJHGIOE$',   assetTypeDscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.VIDEO +"_P"],syncType:''} ); 
data.push({status: status(),statusAll:statusAll(),  value:  extVia.module.epob.GRAPHIC , assetType:'File',  dscr:'DF;GNERLGH)',   assetTypeDscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.GRAPHIC +"_P"],syncType:''} ); 
data.push({status: status(),statusAll:statusAll(),  value:  extVia.module.epob.DOCUMENT , assetType:'File',  dscr:'SDBHGOWEZG)W',   assetTypeDscr:   extVia.ui.page.strings.epobs["Epob_" + extVia.module.epob.DOCUMENT +"_P"],syncType:''} ); 
   


            store = Ext.create('Ext.data.Store', { 
              storeId:'distributionAssetsStore',
              model: model,
              //reaxder: {type: 'json',rosot: 'distributionAssets'},
              data: data
              });  
        }
      return store; 
    },
    
    statusRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value+'" class="xty_icon xty_icon'+value+'"></div>'; },
    statusNumberRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
      
      metaData.tdCls='xty_grid-status-cell'; 
     var status = ''; //value==1 ? "Active":'No';                           
	 switch(value) {
	      case '-1': status='No';   break;
	      case '0': status='Nothing';   break;
	      case '1': status='Active';   break;
	      case '2': status='Yes';   break;
          case 'Yes': status='Yes';   break;
          default: status='Nothing';   break;
	  }
     return '<div data-qtip="'+status+'" class="xty_icon xty_icon'+status+'"></div>'; 
    },
    statusMainRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value.main+'" class="xty_icon xty_icon'+value.main+'"></div>'; },
    

    statusKARenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value.karlsruhe+'" class="xty_icon xty_iconUploading '+value.main+'"></div>'; },

    statusBOSTONRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value.walldorf+'" class="xty_icon xty_icon'+value.main+'"></div>'; },
    statusBERLINRenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value.kassel+'" class="xty_icon xty_icon'+value.main+'"></div>'; },
    statusTOKIORenderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value.brussel+'" class="xty_icon xty_icon'+value.main+'"></div>'; },

    
    getSyncAssetTypeFromId : function (typeId){
       var typCfg = {typ:'unknown', name:'unknown'};
       var assetTypesStore = Ext.data.StoreManager.lookup('assetTypesStore');
       var record  = assetTypesStore.findRecord( 'ID', ''+typeId ); //, [startIndex], [anyMatch], [caseSensitive], [exactMatch] )
       typCfg.typ=record.get('TYPE');
       typCfg.name=record.get('NAME');
       return typCfg;
     },
    
    
    
    getAssetsMonitorGridCfg: function (){ 
      
      var me = this;


      
      var assetsListFields = me.getFieldsFromLabels(extVia.dummies.distrib.SYNC_ASSETLISTS.labels);
      var assetsListModel = Ext.define('distrib-SYNC_ASSETLISTS ', {extend: 'Ext.data.Model', fields: assetsListFields });
//
//      //var  assetsListData = [ me.getDataAsStrings(extVia.dummies.distrib.SYNC_AssetTypes.data) ];
      var assetsListData = [extVia.dummies.distrib.SYNC_ASSETLISTS.data];
      var assetsListStore  = Ext.create('Ext.data.Store', { storeId:'assetListsStore', model: assetsListModel , data: assetsListData});  
      var assetsListColumns = me.getColumnsFromLabels(extVia.dummies.distrib.SYNC_ASSETLISTS.labels);

      
      
      var filenameClmn = assetsListColumns.get('CDN_ASSET_FILENAME');
      filenameClmn.hidden = false;
      filenameClmn.width = 220;

      var statusClmn = assetsListColumns.get('STATUS');
      statusClmn.hidden = false;
      statusClmn.width = 42;
      statusClmn.renderer =   function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
      
      metaData.tdCls='xty_grid-status-cell'; return '<div data-qtip="'+value+'" class="xty_icon xty_icon'+value+'"></div>'; };

      var assetTypeClmn = assetsListColumns.get('SYNC_ASSETTYPES_ID');
      assetTypeClmn.width = 142; assetTypeClmn.hidden = false;
      
      
      var getSyncAssetTypeFromId = function(typeId){
       var typCfg = {typ:'unknown', name:'unknown'};
       var assetTypesStore = Ext.data.StoreManager.lookup('assetTypesStore');
       var record  = assetTypesStore.findRecord( 'ID', ''+typeId ); //, [startIndex], [anyMatch], [caseSensitive], [exactMatch] )
       typCfg.typ=record.get('TYPE');
       typCfg.name=record.get('NAME');
       return typCfg;
      };
      

      
      
      assetTypeClmn.renderer =  function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
       var typCfg = getSyncAssetTypeFromId(value);
      return '<div data-qtip="'+typCfg.name+'" style="padding-left:20px;" class="xty_distrib-asset-'+ (''+typCfg.typ.toLowerCase()) +'">&nbsp;'+typCfg.name+'</div>'; };

      var distributionNodeClmnRenderer =  function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
       if (Ext.isEmpty(value)){value='Downloading';}
       return '<div data-qtip="'+value+'"  class="xty_icon xty_icon'+ (''+value) +'">&nbsp;</div>';
       
       }; 
      
      

      assetsListColumns.items.move(3,0);
      assetsListColumns.items.move(4,0);

      
      assetsListColumns.apply('BOSTON', {hidden:false, width:42, width:58, renderer: distributionNodeClmnRenderer });
      assetsListColumns.apply('BERLIN', {hidden:false, width:42, width:58, renderer: distributionNodeClmnRenderer });
      assetsListColumns.apply('TOKIO', {hidden:false, width:42, width:58, renderer: distributionNodeClmnRenderer });
            
//      var filterBtnHolderId = Ext.id();
//      assetsListColumns.items.push( 
//          {header:'<div class="x-tool-filter" style="margin-left:96%; background-position:0px 4px;" id="'+filterBtnHolderId+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>',
//            menuDisabled : true,
//            flex:1, hidden:false, width:42, width:58
//            });
          
      

      var mbdata = true; 
      

      var   assetsGridCfg ={
       xtype:'grid',
       itemId:'distributedAssetsGrid',
       id:'distributedAssetsGrid',
       //store: me.getAssetsStore({}),
       store: mbdata ? assetsListStore :  me.getAssetsStore({}),
       
       viewConfig : { emptyText:'keine Inhalte zum Anzeigen. W&auml;hlen Sie einen Assettyp'},
       border:false,
       autoScroll:true,
       height:me.getContentPanelHeight(),
       
//       features: [Ext.create('Ext.grid.feature.Grouping',{
//            groupHeaderTpl: 'grouped by <i>{[Ext.getCmp("distributedAssetsGrid").getColumnName()]}</i> : {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
//        })],  
//        getColumnName:function(){                            
//         //var grid =this; //Ext.getCmp("mengenGrid");
//         var columnFieldName = this.features[0].getGroupField();
//             return  columnFieldName ;
//         },
         
      //columns:  assetsListColumns,
       columns: mbdata ? assetsListColumns : [
  
       {header:'Status', dataIndex:'status', width:42,
        renderer: me.statusRenderer //function ( value, metaData, record, rowIndex, colIndex, store, view )  {return '<div class="xty_icon xty_icon'+value.main+'" data-qtip="'+value.main+'"  ></div>'; }
       }, 
       
       
       {header:'Name', dataIndex:'dscr', width:180},
       {header:'Typ', dataIndex:'assetType', width:42,
        renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {return '<div data-qtip="'+value+'" class="xty_distrib-asset-'+ (''+value.toLowerCase()) +'">&nbsp;</div>'; }
       },
       {header:'Asset Typ', dataIndex:'assetTypeDscr', width:180},
       {header:'Sync Type', dataIndex:'syncType'},
       
       

       
      //  { text: 'Distributionen', hidden:true,columns: [


        {header:'Boston', dataIndex:'statusAll', width:58, renderer: me.statusBOSTONRenderer}, 
        {header:'Berlin', dataIndex:'statusAll', width:58, renderer: me.statusBERLINRenderer}, 
        {header:'Tokio', dataIndex:'statusAll', width:58, renderer: me.statusTOKIORenderer}, 
       
       
       
       {header:'Karlsruhe', dataIndex:'statusAll', width:58, renderer: me.statusKARenderer}
       

       
       
       // ] } // eo twoLines Columns Header
       
       
//                                 {
//                                     header: 'Progress',
//                                     dataIndex: 'progress',
//                                     width: 60,
//                                     renderer: function (value, metadata, record) {
//                                         var id = Ext.id();
//                                         Ext.defer(function () {
//                                             Ext.widget('progressbar', {
//                                                 renderTo: id,
//                                                 //text: value +'%',
//                                                 value: value / 100,
//                                                 width: 50
//                                             });
//                                         }, 50);
//                                         return Ext.String.format('<div title="'+value+'%" id="{0}"></div>', id);
//                                     }
//                                 }

       ]
       
       
     ,listeners:{
       
       
         afterrender:function(grid){
           
           
//           Ext.create('Ext.Button', {
//             text: 'Click me',
//             iconCls:'x-tool-filter ',
//             renderTo: filterBtnHolderId,
//             //style:'position:absolute;',
//             handler: function() {
//                 alert('show grid column Filterbar')
//             }
//         });

         },
       
     
          itemcontextmenu: me.itemcontextmenu,

          itemdblclick: function( view, record, item, index, evt ){ 
           //extVia.notify({action: 'Assets MonitorGrid itemdblclick'  , mssg:  'showEditor'}); 
            
           var assetTypesStore = Ext.data.StoreManager.lookup('assetTypesStore');
           var assetTypRecord  = assetTypesStore.findRecord( 'ID', ''+  record.get('SYNC_ASSETTYPES_ID') );  
           me.showEditor( {itemId:'edit',  epob: {dscr : assetTypRecord.get('NAME'), epobType: 'Assettype'}}, record);
          }
          
        }
       
      };

      
      return assetsGridCfg;
    },  
    
    
    getFieldsFromLabels : function (labels){
      var fields = [];
      Ext.Object.each(labels, function(key, value, iteratingObj) {
		    //alert(key + ":" + value);
            fields.push({type: 'string', name: key});
      });
      return fields; 
    },
    
    getColumnsFromLabels : function (labels){
      var columns = [];
      
      var columnsObj = {
      get: function(dataIndex){
       return this.items[this[dataIndex]];
      },
      apply: function(key,cfg){
       return Ext.apply(  this.get(key), cfg);
      },
      
      items:[]
      };
      
      var columnsIx = 0;
      Ext.Object.each(labels, function(key, value, iteratingObj) {
        var header = Ext.isEmpty(value) ? key : value;
        var column = { header: header,  dataIndex: key, hidden: key!='NAME'}
        columnsObj[key] = columnsIx++;
        //columnsObj.items.push( columnsObj[key] );
        columnsObj.items.push( column );
        
        //columns.push( column );
      });
      return columnsObj; 
    },
    
    
//    getDataAsStrings : function (data){
//      var dataAsStrings = [];
//      Ext.Array.each(data, function(row, index, iteratingObj) {
//        //alert('getDataAsStrings row '+index)
//        var rowWithStrings =[];
//        dataAsStrings.push(rowWithStrings);
//        Ext.Array.each(row, function(field, index, iteratingObj) {
//          rowWithStrings.push(''+field);
//        });
//      });
//      return dataAsStrings; 
//    },
    
    
    
    
    /**
     * 
     * @return {}
     */
    getDistributionsGridItems: function (){
      var me = this;
      
      var syncNodesFields = me.getFieldsFromLabels(extVia.dummies.distrib.SYNC_Nodes.labels);
      var syncNodesModel = Ext.define('distrib-SYNC_Nodes ', {extend: 'Ext.data.Model', fields: syncNodesFields });

      //var  syncNodesData = [ me.getDataAsStrings(extVia.dummies.distrib.SYNC_Nodes.data) ];
      var  syncNodesData = [extVia.dummies.distrib.SYNC_Nodes.data];
      var syncNodesStore  = Ext.create('Ext.data.Store', { storeId:'distributionsStore', model: syncNodesModel , data: syncNodesData});  
      var syncNodesColumns = me.getColumnsFromLabels(extVia.dummies.distrib.SYNC_Nodes.labels);
      
      //alert(Ext.encode(syncNodesColumns))
      
      //syncNodesColumns['SERVERNAME'].hidden = false;
      //syncNodesColumns.items[syncNodesColumns['SERVERNAME']].hidden = false;
      
      syncNodesColumns.get('TIMEZONE_UTC').hidden = false;
      
      var timezoneSummerClmn = syncNodesColumns.get('TIMEZONE_DST');
      timezoneSummerClmn.hidden = false;
      timezoneSummerClmn.renderer = me.statusNumberRenderer;
      timezoneSummerClmn.width = 80;
      
      var activeClmn = syncNodesColumns.get('ISACTIVE')
      activeClmn.hidden = false;
      activeClmn.width = 44;
      activeClmn.renderer = me.statusNumberRenderer;
      
      
      var  distributionsGridCfg ={
       xtype:'grid',
       itemId:'distributions',
       store: syncNodesStore,
       border:false,
       height:320,
       
       columns: syncNodesColumns, //me.getColumnsFromLabels(extVia.dummies.distrib.SYNC_Nodes.labels), 
       
       ccolumns:[

       {header:'Name', dataIndex:'name', wyidth:160, flex:1,
        renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
          
          var isUserplace = record.get('usersplace');
          var html = value;
          if (isUserplace){
            metaData.tdCls='xty_grid-cell-usersplace';
            html = value+' <span class="xty_icon xty_iconHere">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
          }
          
          return html; 
          }
       }

       ]
       ,listeners:{
          select: function( rowModel, record, index, eOpts ){},
          itemclick: function ( view, record, item, index, e, eOpts ){
            //view.ownerCt.ownerCt.hide();
          },
          itemdblclick: function( view, record, item, index, evt, eOpts ){   
            var epobType = record.getProxy().getModel().getName();
            
            //extVia.notify({action: 'distributions.itemdblclick'  , mssg:  'showEditor 3 '+epobType}); 
            var dscr = record.get('name');
            if (Ext.isEmpty(dscr)){
              dscr = record.get('dscr');
            }
             var geolocation = record.get('geolocation') ; 
            me.showEditor({itemId:'edit', epob:{dscr:dscr, epobType:epobType, geolocation:geolocation}} , record);
          }, 
          itemcontextmenu: me.itemcontextmenu
        }

      };
      
      var adjustableSize = false;
 
      var distributionsMapPanelCfg =                    
                   {
                     border:false,
                     boadyBorder:false,
                     resizable:true,
                     resizeHandles: 's' ,
                     style:'border-bottom:1px solid #99BCE8;',
                     itemId:'distributionsMapPanel',
					 //hidden:true,
					 height:300,
                     adjustSize:function(newSize){
                       if (adjustableSize){
	                       var leafletMapBin = Ext.get('leafletMap-bin');
	                       //extVia.notify({action: 'adjustSize'  , mssg:  '<b>'+newSize+'</b>'}); 
                            
                           var distribMapPanel  =  this; //distributionsList.getComponent('distributionsMapPanel'); 
                         
                           var newWidth = newSize[0];
                           var newHeight = newSize[1];
                         
                           if (newHeight){
                              newHeight = parseInt(newHeight);
                              if (newHeight && newWidth!==distribMapPanel.lastAdjustedHeight){
                              //extVia.notify({action: 'adjustHeight'  , mssg:  '<b>'+newSize+'</b>'}); 
                              leafletMapBin.setHeight(newHeight);  
                              distribMapPanel.lastAdjustedHeight = newHeight;
                              }
                           }
                         
                           if (newWidth){
                            newWidth = parseInt(newWidth);
                            if (newWidth && newWidth!==distribMapPanel.lastAdjustedWidth ){
                              //extVia.notify({action: 'adjustWidth'  , mssg:  '<b>'+newSize+'</b>'}); 
                              leafletMapBin.setWidth(newWidth); 
                              distribMapPanel.lastAdjustedWidth = newWidth; 
                            }
                           }

                       } 
                     },
                     html:'<div id="leafletMap-bin" style="height:300px"></div>',
                                  
                     setOverallView: function (){
                      this.map.setView([49, 46  ,   12],   1); 
                     },
                     
                     listeners:{      
	                       resize: function(panel,adjWidth, adjHeight){
	                        panel.adjustSize([null,adjHeight]);
	                       },
                      
                            afterrender: function(panel){                 
								var task = new Ext.util.DelayedTask(function(){
								    adjustableSize = true;
								});
								task.delay(500);
                            
                            //                             vertical      horizontal                world scale
	                        var map = L.map('leafletMap-bin').setView([49, 46  ,   12],   1); 
	                          L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
	                            attributionX: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
	                        }).addTo(map);
	                        
                          
                            panel.map = map;
                          
//                          var popup = L.popup()
//						    .setLatLng([50.8550624, 4.3051789])
//						    .setContent('<b>Brussel.</b>')
//						    .openOn(map);
						   
                
//			                var kaIcon = L.divIcon({className: 'xty_leafletMap-marker-distribution', iconAnchor:   [-10, 20], html:'<div class="xty_leafletMap-marker-text" >Karlsruhe</div>'});
//							L.marker([49.0113, 8.40248], {icon: kaIcon}).addTo(map);


                            map.doubleClickZoom.disable(); 
                          
                            var myMapLocatorShowEditor = function (dscr, evt, record){
                             //alert('my,MapLocatorClick itemId['+itemId+'] evt.latlng'+evt.latlng+ ' loc '+loc);                             
                             me.showEditor({itemId:'edit', epob:{dscr:dscr}} , record);
                            };
                          
                           
                            var iconSize = [25,41];
                            
                            map.on('dblclick', function(evt) {
                              //alert(evt.latlng); // e is an event object (MouseEvent in this case)
                              var latlng = 'xxx';
                              latlng = ''+evt.latlng; 
                              latlng = latlng.replace(/LatLng\(/,'');
                              latlng = latlng.replace(/\)/,'');
                            
                              var loc = latlng.split(',');//[49.93708, 8.59131];
                               
                              
                              
                               var fontIcon = L.divIcon({className: 'xty_leafletMap-marker-distribution', iconAnchor:   [-10, 20], html:'<div class="xty_leafletMap-marker-text" >Neu</div>'});
                               L.marker(loc, {icon: fontIcon}).addTo(map);
                               
                               me.showEditor({itemId:'new', epob:{dscr:'', geolocation: latlng }}); 
                               
                               
                               var iconNew = new L.icon({iconUrl: '../img/icons/distributions/marker-new.png', iconSize: iconSize,  iconAnchor:   [12, 48]}); 
                               var newMarker = new L.marker(loc, {title: 'Neu '+latlng, icon :iconNew }).addTo(map);
                               
                               return false;
                            });
                            
                            
                          var distributionsStore = Ext.data.StoreManager.lookup('distributionsStore');  
                          
                          var berlinRec = distributionsStore.getAt(0);
                          var bostonRec = distributionsStore.getAt(1);
                          var tokioRec = distributionsStore.getAt(2);
                            
                            
                           var distributionMarkerData = [    
                              {itemId:'berlin',    loc: [ berlinRec.get('GELOCATION_LAT') , berlinRec.get('GELOCATION_LNG')], dscr: berlinRec.get('NAME')  },
                              {itemId:'boston',  loc: [bostonRec.get('GELOCATION_LAT') , bostonRec.get('GELOCATION_LNG')],  dscr: bostonRec.get('NAME')  },
                              {itemId:'tokio',  loc: [tokioRec.get('GELOCATION_LAT') , tokioRec.get('GELOCATION_LNG')],   dscr: tokioRec.get('NAME')  }  
                            ];
                           
                            var berlinMarker, bostonMarker, tokioMarker;
                            //var markers =[  berlinMarker, bostonMarker, tokioMarker ]
                            

                            for (var i =0; i<distributionMarkerData.length; i++){
                              var markerData = distributionMarkerData[i];
                              var icon = new L.icon({iconUrl: '../img/icons/distributions/marker.png', iconSsize:iconSize, iconAnchor:   [12, 48]}); 
                              var marker = new L.marker(markerData.loc, {title: markerData.dscr, icon: icon }).addTo(map);
                              
                              
                              var fontIcon = L.divIcon({className: 'xty_leafletMap-marker-distribution', iconAnchor:   [-10, 20], html:'<div class="xty_leafletMap-marker-text" >'+markerData.dscr+'</div>'});
                              L.marker(markerData.loc, {icon: fontIcon}).addTo(map);


                              if (i==0){berlinMarker = marker;}
                              else if (i==1){bostonMarker = marker;} 
                              else if (i==2){tokioMarker = marker;} 

                            }

                             berlinMarker.on('click', function(evt) {
                                 //  vertical    horizontal    world scale
                                map.setView([50.2, 11.6  ,   12],   5); 
                                myMapLocatorShowEditor('BerlinO ',  evt, berlinRec); 
                             });
                              
                             bostonMarker.on('click', function(evt) { 
                               //  vertical    horizontal    world scale
                               map.setView([42, -70.6  ,   12],   5); 
                               myMapLocatorShowEditor('BostonO ',  evt, bostonRec); 
                             });
                             tokioMarker.on('click', function(evt) {  
                               //  vertical    horizontal    world scale
                               map.setView([38, 140  ,   12],   5); 
                               myMapLocatorShowEditor('TokioO ',  evt, tokioRec); 
                             });
                        }
                     } 
                   };
                   
      return [ distributionsMapPanelCfg, distributionsGridCfg];
    },
    
    
 showEditor: function(button, record){ // showEditorFc

      var action = button.itemId=='new' ?'anlegen':'bearbeiten';
      var epobDscr = button.itemId=='new' ?'*': button.epob ? button.epob.dscr: 'XY?'  ;

      
      if (Ext.isObject(button)){
        epobDscr = button.epob.dscr;
      }
 
      if (record){
        var name = record.get('NAME');
        if (!Ext.isEmpty(name)) {
         epobDscr = name;
        }
      }
      
    
      
      var editorPanelCfg  = { title:epobDscr,   itemId: epobDscr };
      var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel();
      var ediTab = tabPanCenter.getComponent(epobDscr);
      

    if (!ediTab) {
      
      
      var geolocation = button.epob ? button.epob.geolocation: ''  ;
      
      
      var metaDataName = button.itemId=='new' ?'': epobDscr;
      
      var epobTypeDscr = 'Standort';

      
      var isAssettype = false;
      if (button.epob &&  button.epob.epobType  &&  button.epob.epobType.toLowerCase().indexOf('assettype')>-1){
        epobTypeDscr='Assettyp ';
        isAssettype = true;
      }


      var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'delete'}];
      
      var editorAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: epobTypeDscr+' '+action , epobDscr: epobDscr,   pagetoolbarButtons: pagetoolbarButtons } );
     
      
     var boxDefaults = { // defaults for box-items
             labelWidth : 180,
             width : 460,
             msgTarget:'side',
             xtype:'textfield', 
             margin:'4 0 4 4'
            };
      
      
      var distribMetadataPanelCfg  = {
           title:'Metadaten', itemId:'metadata',
           collapsible:true,
           defaults:boxDefaults
        };
                 
        

        
    getFormFieldsFromLabels = function (labels, record, inclArr, exclArr){
      var formFields = {
	      get: function(key){
	       return this.items[this[key]];
	      },
          apply: function(key,cfg){
           return Ext.apply(  this.get(key), cfg);
          },
	      items:[]
      };

      var itemsIx = 0;
      Ext.Object.each(labels, function(labKey, labValue, iteratingObj) {
        //alert(labKey + ":" + labValue);
        
        var fieldLabel =   labValue;
        if (Ext.isEmpty(labValue)){
         var firstChar = labKey.substring(0,1);
         fieldLabel =   firstChar +labKey.toLowerCase().substring(1,labKey.length);  
        }
        
        var fieldValue = record.get(labKey);
        var field = { itemId: labKey,  fieldLabel: fieldLabel , value: fieldValue };
        
        var pushIt = Ext.isEmpty(inclArr) ? true : false;
        
        if (exclArr){
          for (var ei = 0; ei < exclArr.length ; ei ++ ){
            var exclStr = exclArr[ei];
            if (labKey.toLowerCase().indexOf(exclStr)==0){
             pushIt = false;
            }
          
          }
        }
 
        if (inclArr){
          for (var ji = 0; ji < inclArr.length ; ji ++ ){
            var inclStr = inclArr[ji];
            if (labKey.toLowerCase().indexOf(inclStr)==0){
             pushIt = true;
            }
          
          }
        }

        if (pushIt){
          formFields[labKey] = itemsIx++;
          formFields.items.push(field);
        }
        
      });
      
      return formFields; 
    };


    var metadataFormFields = getFormFieldsFromLabels (extVia.dummies.distrib.SYNC_Nodes.labels, record, [], ['cdn', 'cha', 'cre']);

    metadataFormFields.get('ID').hidden='true';

    var ISACTIVE = metadataFormFields.get('ISACTIVE');
    ISACTIVE.hidden = true;
    
    var STATUS = metadataFormFields.get('STATUS');
    
    metadataFormFields.apply('STATUS', 
        {xtype:'fieldcontainer', fieldLabel: 'Status', layout:'hbox',
         items:[
          {itemId:'STATUS', xtype:'textfield',   value: STATUS.value,width:100},
          {boxLabel: 'Aktiv', itemId:'ISACTIVE', xtype:'checkbox', checked: ISACTIVE.value==1, margin:'0 0 0 40'}
         ]
        });

    metadataFormFields.apply('TIMEZONE_DST', {xtype:'checkbox'});

    // Copied from Ext.form.field.VTypes.js START
    var trimX = /^\s+|\s+$/g;
    /**
     * True if null or whitespacesOnly
     */
    var isEmpty = function(value) {
      if (Ext.isEmpty(value) === true) {
        return true;
      } else if (value.length === 0) {
        return true;
      } else {
        var trimVal = value.replace(trimX, "");
        return trimVal.length === 0;
      }
    };
    var emailX = /^(\w+)([\-+.][\w]+)*@(\w[\-\w]*\.){1,5}([A-Za-z]){2,4}$/;
    // Copied from Ext.form.field.VTypes.js END
    
    Ext.form.field.VTypes['emaillist'] = function(v) {
      if (isEmpty(v)){return true;}
      else{

         var mailArr = v.split(';');
         var mi;
         var mailIsValid = true;
         for(mi=0; mi<mailArr.length && mailIsValid; mi++){
           var mail = mailArr[mi].replace(trimX, '');
           //mailIsValid = mail.indexOf('@')>-1;  
           mailIsValid = isEmpty(mail) || emailX.test(mail);  
           //extVia.notify({action: 'validate emaillist'  , mssg: mailIsValid+' ['+ mail+']'});
         }
      }
      return mailIsValid;
    };
    Ext.form.field.VTypes['emaillistText'] = 'Das Eingabefeld soll E-Mail-Adressen im Format "benutzer@beispiel.de" oder "b.nutzer@beispiel.de" enthalten. Trennzeichen (;). ';
    Ext.form.field.VTypes['emaillistMask'] =   /[a-z0-9_\.\-@;]/i;

    
    metadataFormFields.apply('EMAILLIST', {xtype:'textarea', height:60, vtype:'emaillist'});
    metadataFormFields.apply('SYNO_COMMENT', {xtype:'textarea', height:40});

    
    distribMetadataPanelCfg.items = metadataFormFields.items;
    distribMetadataPanelCfg.items.move(6,0);
    distribMetadataPanelCfg.items.move(6,2);
    
    
    distribMetadataPanelCfg.items.move(5,4);
    
    distribMetadataPanelCfg.items.splice(4, 0, { itemId:'serverTopic', xtype:'displayfield',  fieldLabel:'<b>Server</b>' }); 
    distribMetadataPanelCfg.items.splice(8, 0, { itemId:'collabTopic', xtype:'tbspacer', height:20, fxieldLabel:'<b>Collab</b>' }); 
    distribMetadataPanelCfg.items.splice(11, 0, { itemId:'localizeTopic', xtype:'displayfield',  fieldLabel:'<b>Lokalisation</b>' }); 
    
    
    var latFieldCfg = distribMetadataPanelCfg.items[12];
    var longFieldCfg = distribMetadataPanelCfg.items[13];

    Ext.apply( latFieldCfg, {xtype:'numberfield', maxValue:90, minValue:-90, step:0.1, hideTrigger:true, decimalPrecision:8});
    Ext.apply( longFieldCfg, {xtype:'numberfield', maxValue:180, minValue:-180, step:0.01, decimalPrecision:7});
    
   
   var assetTypeVal =  isAssettype ? record.get('TYPE') :'' ;
   var assettypeMetadataPanelCfg = {
           title:'Metadaten', itemId:'metadata',
           items:[
           { itemId:'name',  width:458, fieldLabel:'Name',  allowBlank:false, labelSeparator: extVia.dialoges.getLabelSeparator4Required(), value:epobDscr },  
           
           
           {xtype:'fieldcontainer', itemId:'type-bin', fieldLabel:'Typ',  width:458, layout:'hbox', items:[
            { itemId:'typeIcon', xtype:'displayfield', fielsdLabel:'Typ', width:22, value:  '<div class="xty_distrib-asset-file '+assetTypeVal+'" style="width:100px;paddsing-left:20px;" >&nbsp;</div>'  },
            { itemId:'type', xtype:'textfield', width:251, value: assetTypeVal} 
           ]},
           
           //{ itemId:'type', xtype:'displayfield', fielsdLabel:'Typ', value:  isAssettype ? ('<div class="xty_distrib-asset-file '+record.get('TYPE')+'" style="width:100px;padding-left:20px;" >'+record.get('TYPE')+'</div>' ):'' },
           //{ itemId:'status', xtype:'displayfield', fieldLabel:'Status', value:  isAssettype ? ('<div class="xty_icon xty_icon'+record.get('STATUS')+'" style="width:100px;padding-left:20px;" >'+record.get('STATUS')+'</div>' ):'' },
           { itemId:'comment', width:458, xtype:'textarea', fieldLabel:'Kommentar', value: isAssettype ? record.get('SYAS_COMMENT'):'' }
           ]};     
   
   
   
   
   
   var metadataPanelCfg  =   isAssettype ? assettypeMetadataPanelCfg : distribMetadataPanelCfg ;      
       
       var atBoxDefaults = { // defaults for box-items
             labelWidth : 180,
             width:380,
             msgTarget:'side',
             xtype:'textfield', 
             margin:'4 0 4 4'
        };
      
        
      var  SYNC_TYPE =   isAssettype ? record.get('SYNC_TYPE') : '';
      var immediatly = SYNC_TYPE =='sofort';
        
      var syncronizationPanelCfg =  {
           title:'Synchronisation', 
           hidden: !isAssettype,
           itemId:'syncronization',
           defaults: atBoxDefaults,
           
           items:[
           {   
               xtype:'combo', 
               margins:'0 0 0 10',
               fieldLabel:'Typ',
               emptyText:'',     
               store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                data :  [   [ 'Sofort','Started'] , [  'geplant' ,'Scheduled' ], [  'keine Synchronisation', 'Inactive']]
                }) ,                              
               displayField: 'dscr',
               valueField: 'value',
               
               value:  SYNC_TYPE, 
               typeAhead: true,
               mode: 'local',
               triggerAction: 'all',
               listConfig : {
              getInnerTpl : function(displayField) {
                var tpl = '<div style="width:100%;height:18px;padding-left:16px;" title="" class="xty_icon xty_icon{value} "><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>';
                return tpl;
              }
            }, 
            
            listeners:{
            
              change:function ( combo, newValue, oldValue){
                var panel = combo.ownerCt ;
                
                var disable = true;
                
                if (newValue =='Scheduled'){
                 disable = false;                
                }                
                panel.getComponent('scheduling-bin').setDisabled( disable);
                panel.getComponent('scheduling-period-bin').setDisabled( disable);
                panel.getComponent('period').setDisabled( disable );
                panel.getComponent('failover-bin').setDisabled( disable );

                var assettypeSpecificSyncsPan = combo.ownerCt.ownerCt.getComponent('assettypeSpecificSyncs');
                var specificSyncsGrid = assettypeSpecificSyncsPan.getComponent('distributions');
                
                
               // specificSyncsGrid.setDisabled( disable );
                
                if (newValue==='Inactive'){
                  
                  
               // var warningMsg = 'Alle standortspezifischen Synchronisationen werden beim Speichern gel&ouml;scht.';
                
                var warningMsg = 'Wenn Sie speichern, werden alle standortspezifischen Synchronisationen gel&ouml;scht.';
                
                var inactiveMsg = 'Keine standortspezifischen Synchronisationen';  
                
                var emptyText = '<div class="xty_inplaceMessage-bin"><div class="xty_inplaceMessage-empty">'+inactiveMsg+'<div><div>';
                  
                specificSyncsGrid.getView().emptyText = emptyText;
                specificSyncsGrid.getView().deferEmptyText = false;
                
                
                extVia.notify({action:'Typ: <i>Keine Synchronisation</i>', status:'Warning', mssg: warningMsg, width:260});
                
                var specificSyncStore = specificSyncsGrid.getStore();
                specificSyncStore.removeAt( 2 );
                specificSyncStore.removeAt( 1 );
                specificSyncStore.removeAt( 0 );
                }
                else{
                 // specificSyncsGrid.show(); 
                }
                
                
              }
              
            },
            
            selectOnFocus:true
           },

            {   
               xtype:'combo', 
               margins:'0 0 0 10',
               disabled: immediatly,
               fieldLabel:'Zeitraum',
               itemId:'period',     
               store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                data :  [ ['w&ouml;chentlich (168h)'],  ['t&auml;glich (alle 24h)'],  ['alle 12h'], ['alle 6h'], ['alle 4h'], ['alle 2h'], ['st&uuml;ndlich (alle 60 min)'], ['alle 30 min'], ['alle 15 min'],  ['alle 10 min'], ['alle 5 min'], ['min&uuml;tlich (alle 60 sec)'], ['alle 30 sec'] ]
                }) ,                              
               displayField: 'dscr',
               typeAhead: true,
               mode: 'local',
               triggerAction: 'all',
               selectOnFocus:true
           },
           
           { itemId:'scheduling-period-bin', disabled: immediatly, xtype:'fieldcontainer',  fieldLabel:'Zeitraum', layout:'hbox', width : 540, items:[
             { itemId:'scheduling-period', xtype:'numberfield',  value:'', width:80},
             { itemId:'scheduling-period-unit', xtype:'combo',  margin:'0 0 0 7', width:100,
               store:   Ext.create('Ext.data.ArrayStore', {fields: [ 'dscr','value'], 
                 data :  [ ['Tage'],  ['Stunden'],  ['Minuten'], ['Sekunden']]
                 }) ,                              
                displayField: 'dscr',
                typeAhead: true,
                value:'Minuten',
                mode: 'local',
                triggerAction: 'all',
                selectOnFocus:true 
             }
           ]},
           
           
           { itemId:'scheduling-bin', disabled: immediatly, xtype:'fieldcontainer',  fieldLabel:'N&auml;chste Synchronisation', layout:'hbox', width : 540, items:[
              { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
              { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
           ]},
           { itemId:'failover-bin', disabled: immediatly, xtype:'fieldcontainer',  fieldLabel:'Ersatz Synchronisation', layout:'hbox', width : 540, items:[
              { itemId:'scheduling-date', xtype:'datefield',  value:'', width:195},
              { itemId:'scheduling-time', xtype:'timefield',  format : 'H:i' , vaxlue:'12:00', margin:'0 0 0 8', width:60}
           ]}       

           ]};

     
           
      var cdnFormFields = getFormFieldsFromLabels (extVia.dummies.distrib.SYNC_Nodes.labels, record, ['cdn']);
      cdnFormFields.items.move(1,0); 
      cdnFormFields.items.move(4,3); 
           
      var  distribCDNPanelCfg =      {
           title:'Content Delivery Network', 
           //hidden: isAssettype,
           itemId:'distribCDN',
           collapsible:true,
           defaults:boxDefaults
           };
    
    
         
           
    distribCDNPanelCfg.items = cdnFormFields.items;     
    distribCDNPanelCfg.items.splice(0, 0, { itemId:'uploadTopic', xtype:'displayfield',  fieldLabel:'<b>Upload</b>' });  
    distribCDNPanelCfg.items.splice(4, 0, { itemId:'downloadTopic', xtype:'displayfield',  fieldLabel:'<b>Download</b>' });  
           
   
    var distributionSpecificSyncsPanelCfg    =           {
           title: 'Standortspezifische Synchronisationen', //''+ (isAssettype ? 'Standortspezifische Synchronisationen' : 'Assettyp Synchronisationen +Standortspezifische ' ) +'', 
           sstyle: isAssettype?'opacity:0.5':'',
           width:  580 ,
           collapsed: isAssettype,
           itemId:'distributionSpecificSyncs',
           items:[  me.getAssetsTypesListItems({border:true, rowsCount:isAssettype?5:null, wwidth:480 , heiwght:140, epobDscr:epobDscr})[0]  ]
       };       
      
       
       var changeInfoPanelCfg = {
           xtype:'form', title:'&Auml;nderungsinfo', 
           itemId:'changeInfo',
           defaults:boxDefaults,
           items:[ 
           { itemId:'changeDate', xtype:'displayfield', fieldLabel:'Anlage', value: record.get('CREATION_DATE') + ' / ' + extVia.dummies.distrib.Users[record.get('CREATION_USRS_ID')]  },
           { itemId:'creationDate', xtype:'displayfield', fieldLabel:'letzt &Auml;nderung', value:'' }
         ]};
       

       
       
       
       
       var syncNodesFields = me.getFieldsFromLabels(extVia.dummies.distrib.SYNC_Nodes.labels);
       var syncNodesModel = Ext.define('distrib-SYNC_Nodes ', {extend: 'Ext.data.Model', fields: syncNodesFields });
       var  syncNodesData = [extVia.dummies.distrib.SYNC_Nodes.data];
       var syncNodesStore  = Ext.create('Ext.data.Store', { storeId:'distributionsStore', model: syncNodesModel , data:   syncNodesData});  
       var syncNodesColumns = me.getColumnsFromLabels(extVia.dummies.distrib.SYNC_Nodes.labels);
       
       syncNodesColumns.get('TIMEZONE_UTC').hidden = false;
       
//       var timezoneSummerClmn = syncNodesColumns.get('TIMEZONE_DST');
//       timezoneSummerClmn.hidden = false;
//       timezoneSummerClmn.renderer = me.statusNumberRenderer;
//       timezoneSummerClmn.width = 80;
       
//       var activeClmn = syncNodesColumns.get('ISACTIVE')
//       activeClmn.hidden = false;
//       activeClmn.width = 40;
//       activeClmn.renderer = me.statusNumberRenderer;
       
       
       
       var  distributionsGridCfg ={
         xtype:'grid',
         itemId:'distributions',
         store: syncNodesStore,
         border:false,
         height:320,
         width:580,
         margin : '0 0 0 0', 
         viewConfig: {
           deferEmptyText: false,
           emptyText: 'Keine standortspezifischen Synchronisationen',  
         },
        /// columns: syncNodesColumns, //me.getColumnsFromLabels(extVia.dummies.distrib.SYNC_Nodes.labels), 
         
         columns:[

         {header:'Name', dataIndex:'NAME', width:120  },

         
         {header:'node id' , hidden:true},
         {header:'Typ' , data:'scheduling type' },
         {header:'Zeitraum',width:80, },
         
//         {header:'Failovera' , width:132, hidden:true, columns:[
//           {header:'max retries' ,width:66,  Hheader:'Failover max retries' },
//           {header:'time between', width:66,  Hheader:'time between two retries' },
//           ]
//         },
                 
         {header:'Failover' , 
           renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  { 
             var html=   '<span style="color:#888" >max retries:<br>time between:</span>'
             return html;
             
           }
         },
        {header:'max retries' , hidden:true,width:66,  Hheader:'Failover max retries' },
         {header:'time between', hidden:true, width:66,  Hheader:'time between two retries' },
         
         {header:'Email' , width:80},
         
         
         {header:'spezifisch', dataIndex:'NODESPECIFIC', 
           rendesrer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
             var html = value;
             return html; 
             }
          },

         

         ]
         ,listeners:{
            select: function( rowModel, record, index, eOpts ){},
            itemclick: function ( view, record, item, index, e, eOpts ){
              //view.ownerCt.ownerCt.hide();
            },
            itemdblclick: function( view, record, item, index, evt, eOpts ){   
              var epobType = record.getProxy().getModel().getName();
              
              extVia.notify({action: 'distributions.itemdblclick'  , mssg:  'show Dialog '+epobType}); 
              var dscr = record.get('name');
              if (Ext.isEmpty(dscr)){
                dscr = record.get('dscr');
              }

              
              me.showNodeSpecificSyncDialog({mainInstr:'Standort '+record.get('dscr')}, record);
              
            }, 
            itemcontextmenu: me.itemcontextmenu
          }

        };
       
       
       
       var assettypeSpecificSyncsPanelCfg    =   {
             title: 'Standortspezifische Synchronisationen', 
             width:  580 ,
             itemId:'assettypeSpecificSyncs',
             items:[  distributionsGridCfg]
         };
       
       
       
       
       assettypeTabPanelCfg = { 
                               xtype:'tabpanel',
                               itemId:'editorSubTabsPanel',
                               border:false, 
                               margin : '0 0 0 0', 
                               collapsible: false, 
                               width:null,
                               cls:'xty_assettypeEditorTabPanel', 
                               activeTab:  1, 
                               
                               tabBar:{cls:'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl'},
                               defaults:{ // defaults for tab-panels
                                          border:false,
                                          autoScroll:true, height: me.getEditorSubTabHeight(), 
                                          defaults:{ // defaults for boxes
                                           xtype:'form', width:580, margin:'24 24 24 24',
                                           defaults:{ // defaults for box-items
                                           labelWidth : 180,
                                           width : 380,
                                           msgTarget:'side',
                                           xtype:'textfield', 
                                           margin:'4 0 4 4'
                                            }
                                          }
                                       },
                               items:[
                                 {title:'Standort', heixxght:600, items:[
                                   metadataPanelCfg,
                                   changeInfoPanelCfg
                                 
                                 ]},
                                 {title:'Synchronisation', itemId:'synchronisationTab', items:[  syncronizationPanelCfg, assettypeSpecificSyncsPanelCfg]}
                               ]
                             };  
       
      var assettypeEditorPanelItems  =  [ assettypeTabPanelCfg];
  
      
      
      
      
      var distribTabPanelCfg =     { 
        xtype:'tabpanel',
        itemId:'editorSubTabsPanel',
        border:false, 
        margin : '0 0 0 0', 
        collapsible: false, 
        width:null,
        cls:'xty_distribEditorTabPanel', 
        hidden:  isAssettype,
        activeTab:  0, 
        
        tabBar:{cls:'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl'},
        defaults:{ // defaults for tab-panels
                   border:false,
                   autoScroll:true, height: me.getEditorSubTabHeight(), 
                   defaults:{ // defaults for boxes
                    xtype:'form', width:580, margin:'24 24 24 24',
                    defaults:{ // defaults for box-items
			              labelWidth : 180,
			              width : 380,
			              msgTarget:'side',
			              xtype:'textfield', 
			              margin:'4 0 4 4'
                     }
                   }
                },
        items:[
          {title:'Standort', heixxght:600, items:[
            metadataPanelCfg,
            //syncronizationPanelCfg,
            distribCDNPanelCfg,
            changeInfoPanelCfg
          
          ]},
          {title:'Synchronisation',  items:[  distributionSpecificSyncsPanelCfg]}
        ]
      };  

      var distribEditorPanelItems =  [ distribTabPanelCfg ];
      
      editorPanelCfg  = 
        {
        title:epobDscr,  
        itemId: epobDscr,
        
        tbar: editorAppbar, 
        closable:true,
        //autoScroll:true, 
        //height: me.getEditorContentPanelHeight(), 
        
        defaults: isAssettype ? {
          xtype:'form', 
          width:580, margin:'24 24 24 24',
          collapsible:true,
          defaults:{
              labelWidth : 180,
              width : 380,
              msgTarget:'side',
              xtype:'textfield', 
              margin:'4 0 4 4'
          }
        }:null,
        items:  isAssettype ? assettypeEditorPanelItems : distribEditorPanelItems
        };
        
      } // eo if not ediTab      
        
      var editorPanel = tabPanCenter.addAndActivate(editorPanelCfg);
      return editorPanel;
    
    },
    
    
    showEditDialog: function(button){
     var  addEpobDialog = extVia.dialoges.getAddEpobDialog({x:400, y:80});
     addEpobDialog.show();
    },
    
    deleteEpobDialog: function(cfg){
	    var  deleteEpobDialog = extVia.dialoges.getDeleteEpobDialog({mainInstr :'M&ouml;chten Sie die Distribution <i style="font-weight:normal">Name</i>  wirklich l&ouml;schen?', suppInstr:' '});
	    deleteEpobDialog.show();
    }, 
    
    launch: function() {
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      me = this;
      //this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside
      var  modulDscr = 'Distributions';
      var epobDscr = 'Alle';
      
//      try{
//      alert(' extVia.dummies.distrib.SYNC_Nodes '+ Ext.encode(extVia.dummies.distrib.SYNC_Nodes) );
//      } catch(ex){alert(ex)}
      
      
    Array.prototype.move = function (old_index, new_index) {
	    if (new_index >= this.length) {
	        var k = new_index - this.length;
	        while ((k--) + 1) {
	            this.push(undefined);
	        }
	    }
	    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
	    return this; // for testing purposes
    };
      
      
      
      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      
      extVia.constants.raster.mainWestWidth = 360;
      
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);

      
      var pgjobStartBtn = {itemId:'start', scale:'large', xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}};
      var pgjobStopBtn = {itemId:'stop', scale:'large'};
      
      var pagejobButtons = [pgjobStartBtn,pgjobStopBtn];
      
      
      
      
      var pagetoolbarButtons = [{itemId:'save'},{itemId:'new'},{itemId:'search'}];
      
       var showMap = function(button){
	    var mapPanel = button.ownerCt.ownerCt.getComponent('distributionsMapPanel');
        mapPanel.setOverallView();
	   };

      var distributionsList = {
          title:'Standorte',
          itemId:'distributionsList',
          tbar:[
          
          '->',    {iconCls: 'xty_pgtoolbar-showMap',handler:showMap}, {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'L&ouml;schen', handler: me.deleteEpobDialog}
          ],
          
          items:me.getDistributionsGridItems()
          
          };

          
      var showAssettypesEditor = function (){
        me.showEditor({itemId:'edit', epob:{dscr:'assetTypesList selection?', epobType:'Assettype'} } );
      }    
          
          
      var assetTypesList = { 
        title:'Synchronizationen', 
        //closable:true,
        itemId:'assetTypes',
        tbar:[
          
          '->',    {iconCls: 'xty_pgtoolbar-list'}, {iconCls: 'xty_pgtoolbar-new', itemId:'new'}, {iconCls: 'xty_pgtoolbar-edit',itemId:'edit', handler:showAssettypesEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete'}
          ], 
          
          items:  me.getAssetsTypesListItems()}    
          
          
      var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
          tabBar:{ 
            tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
            handler:function(button){
              var activeTab = button.ownerCt.ownerCt.getActiveTab();
                extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
              }
             }
            ]
          },
          
          items:[distributionsList, assetTypesList]
          
          ,listeners:{      
             resize: function(panel, adjWidth, adjHeight){
              var distributionsList  = panel.getComponent('distributionsList');
              if (distributionsList){
                  var distributionsMapPanel  = distributionsList.getComponent('distributionsMapPanel');
                  if (distributionsMapPanel){
                    var newWestWidth = extVia.regApp.myRaster.getWestTabPanel().getWidth(); //alert('getWestTabPanel '+);
                    distributionsMapPanel.adjustSize( [newWestWidth, null] );
                  }
              }
             }
          }

          });
      extVia.regApp.myRaster.addToWest(tabPanWest);


        // Your App
        var distributionsAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'Standorte' } );
        var distributionsPanel = {title:'Distribution &Uuml;bersicht',closable:true,  tbar: distributionsAppbar, items:[{html:'hello Distributions App', margin:'24 24 24 24'}] }
        //extVia.regApp.myRaster.addToCenter(appPanel); //  set BaseRaster modulDscr to null
      

      // Need some center Tabs?

      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel(  {
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
       handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
      iconCls:'x-tool x-tool-refresh'}]  } });
      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      //tabPanCenter.add(distributionsPanel);

      

      
      var distributionsCombo = me.getDistributionsComboCfg();
      //distributionsCombo.margin='0 160 0 0';

       pagejobButtons =  ['->' ,pgjobStartBtn, pgjobStopBtn] ;
      
       var date = new Date();
       //var time = date.toString().replace(/(.*2017 )(.*)(:\d\d)( GMT.*)/,'$2'); //'$2<span style="opacity:0.2;">$3$4</span>');
       var time = Ext.Date.format( date, 'H:i {T P' ).replace('{','<span class="xty_pgjobEpobDscr xty_pgjobEpob-specifier " >' )+'</span>';

     
       
       
      var appbarAssetOverviewTypes = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Synchronisationsplanung' , epobDscr: time} );
      var assetTypesOverviewPanel  = {title:'Planung',  tbar: appbarAssetOverviewTypes, xiconCls: 'xty_icon xty_iconPlanned',
        items:[ me.getAssetsTypesGrid({}) ] 
        
      };
      tabPanCenter.add(assetTypesOverviewPanel);    
      
      var assetTypesCombo = me.getAssetsTypeComboCfg();
      assetTypesCombo.margin='0 6 0 0';
      assetTypesCombo.triggerCls='xty_form-trigger-filter ';
      //assetTypesCombo.emptyText='View Types';

     pagejobButtons =[ '->' , pgjobStartBtn, pgjobStopBtn, 
     
//       {xtype:'buttongroup', items:[
//         {cls:'x-tool-filter ',   width:20, margin:'0 6 0 0'},
//         {cls:'x-tool-filter ',   width:20, margin:'0 6 0 0'},
//         {cls:'x-tool-filter ',   width:20, margin:'0 6 0 0'}
//         ]
//       },
       
       
       {cls:'x-tool-filter ',   width:20, margin:'0 6 0 0'}
     ] ;
     
     pagejobButtons =[ ] ;
//     pagejobButtons.push({ 
//       xtype:'splitbutton', 
//       text:   'Custom Resource',
//       tooltip: 'tooltip', 
//       itemId:'filter-query-CustomResource',
//       //iconCls:'x-tool-filter',  
//       cls:'xty_actionbar-filter-item',  
//       scale:'small'
//     });
//     
//     
//     
//     pagejobButtons.push({ 
//       xtype:'splitbutton', 
//       text:   'Berlin',
//       tooltip: 'tooltip', 
//       itemId:'filter-query-Berlin',
//       //iconCls:'x-tool-filter',  
//       cls:'xty_actionbar-filter-item',  
//       scale:'small'
//     });
     
     
     pagejobButtons.push({  
       tooltip: 'clear filter', 
       itemId:'clearfilter',
       iconCls:'x-tool-filterOff',  
       margin:'0 4 0 0',
       scale:'small'
     });
     
     
     
     
      var appbarMonitoring = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Synchronisations&uuml;berwachung' , epobDscr: 'Alle ',   pagetoolbarButxxtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var monitoringPanel  = {
        title:'&Uuml;berwachung',  itemId:'monitoring', xiconCls: 'xty_icon xty_iconRunning',
        tbar: appbarMonitoring, 
        getApplicationbar:function(){return appbarMonitoring;},
        items:[ me.getAssetsMonitorGridCfg() ] 
        
      };
      tabPanCenter.add(monitoringPanel);
      
      
      pagejobButtons =[ me.getAssetsTypeComboCfg()] ;
      
      var appbarProtocols = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Protokolle Assets' , eposbDscr: 'Assettype XY',   pagetoolbarsButtons: pagetoolbarButtons, pgjobButtons: pagejobButtons } );
      var protocolsPanel  = {title:'Protokolle', itemId:'protocols',  xiconCls: 'xty_icon xty_iconExpired', tbar: appbarProtocols, items:[{htsml:'Protocols', margin:'24 24 24 24'}] };
      tabPanCenter.add(protocolsPanel);
      
      
      var distributionsStore = Ext.data.StoreManager.lookup('distributionsStore');  
      var berlinRec = distributionsStore.getAt(0);
      //me.showEditor({itemId:'edit', epob:{dscr:''}} , berlinRec);
      
      
    }
});



/*
 * 
 * $Revision: 1.50.2.7 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2018/07/19 14:08:20 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
