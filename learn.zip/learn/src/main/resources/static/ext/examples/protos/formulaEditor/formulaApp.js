/**
 * 
 */
Ext.application({
  name: 'elements',

  version:'$Revision: 1.1.2.10 $',

  /**
     * Place 
     */
  appMode:{},


  getContentPanelHeight : function (){
    var me = this;
    return me.getCenterHeight(); 
  },

  getEditorContentPanelHeight : function (){
    var me = this;
    return me.getCenterHeight({hasPagetoolbar: true}); 
  },

  getEditorSubTabHeight : function (){
    var me = this;
    return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
  },

  getCenterHeight : function (cfg){
    var centerPan =  extVia.regApp.myRaster.getCenter();
    var centerHeight = centerPan.getHeight();
    centerHeight-=25; // substract center-tabstrip 
    centerHeight-=66; // substract pagejobbar 
    if (cfg && cfg.hasPagetoolbar){
      centerHeight-=60;  // substract pagetoolbar 
    }
    if (cfg && cfg.hasSubtabs){
      centerHeight-=30; // substract subtabstrip
    }      
    return centerHeight;
  },

  getCenterWidth : function (cfg){
    var centerPan =  extVia.regApp.myRaster.getCenter();
    var centerWidth = centerPan.getWidth()-50;    
    return centerWidth;
  },

  getWestListHeight : function (cfg){
    var westPan =  extVia.regApp.myRaster.getWest();
    var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
    return westHeight;
  },

  showEditor: function(view, record, item, index, evt ) {
    var me = this;
    var loc = extVia.locales;
    var epobType =  record.get('epobType');
    var pgjobDscr =  epobType + ' editor';      
    var pgjobEpobDscr = record.get('name');

    var editorPagetoolbarButtons = [
      { itemId:'save',tooltip : 'Save'},         
      { itemId:'new',tooltip : 'New'},        
      { itemId:'collectionAddTo',tooltip : 'collectionAddTo'} 
    ]; 

    var applibar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:pgjobDscr, epobDscr: pgjobEpobDscr,  pagetoolbarButtons: editorPagetoolbarButtons} );
    var editorMainTabItemId = 'elementsEditor'+ record.get('id'); //epob.epobId ; 
    var labelWidth = 180;
    var epobEditorPanelCfg = {
      title: pgjobEpobDscr, 
      applibarId:applibar.id,
      tbar : applibar,
      getApplicationBar:function(){
        return applibar;
      },
      setPagejobDscr : function setPagejobDscr(pgjobDscr){ applibar.setPagejobDscr(pgjobDscr);},
      setEpobDscr : function setEpobDscr(epobDscr){applibar.setEpobDscr(epobDscr);},
      getPagejobDscr : function getPagejobDscr(){applibar.getPagejobDscr(); },
      getEpobDscr : function getEpobDscr(){ return applibar.getEpobDscr(); },
      closable:true,
      active:true,
      itemId:editorMainTabItemId,
      items:[{
        xtype:'tabpanel',
        border:false,
        activeTab: 'Accordion',
        refresh:function(){extVia.notify({action: 'refresh on'  , mssg:  this.title});},
        tabBar:{
          cls : 'xty_subtabpanel-tabbar   xty_tabbar-noborder-rl',

          tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
                  handler:function(button){
                    var activeTab = 'activeTab to be checked '; //extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                    extVia.notify({action: 'Refresh Subtab'  , mssg:  '<b>'+activeTab+'</b>'}); 
                  },
                  iconCls:'x-tool x-tool-refresh'}]  },
        items:[
          {title:'Accordion',
           itemId:'Accordion',
           border:false,
           activeOnTop: false,
           items:[{
             width: '100%',
             height: 650,
             layout: 'border',
             border:false,
             items: [{
               title: 'Formulas and Symbols',
               region:'east',
               xtype: 'panel',
               layout: {
                 type: 'accordion',      
                 animate: true,
                 multi: true,
               },
               width: 320,
               collapsible: true,   
               id: 'east-region-container',
               split: true,
               items:[{
                 hidden:true
               },
                      {title: '&#8723;   X   &#247;',
                       autoScroll:true,
                       items: [{
                         xtype: 'image',
                         height: 300,
                         width: 320,
                         src:'img/1.jpg'
                       }]}
                      ,{title: '&#8804; &#8776; &#8774;',
                        autoScroll:true,
                        items: [{
                          xtype: 'image',
                          height: 158,
                          width: 320,
                          src:'http://www.sencha.com/img/sencha-large.png'
                        }]}
                      ,{title: '&#8734; &#8838; &#8712;',
                        autoScroll:true,
                        items: [{
                          xtype: 'image',
                          height: 158,
                          width: 320,
                          src:'http://www.sencha.com/img/sencha-large.png'
                        }]}
                      ,{title: '&#8826; &#8781; &#8737;',
                        autoScroll:true,
                        items: [{
                          xtype: 'image',
                          height: 158,
                          width: 320,
                          src:'http://www.sencha.com/img/sencha-large.png'
                        }]}
                      ,{title: '&#8658; &#8634; &#8620;',
                        autoScroll:true,
                        items: [{
                          xtype: 'image',
                          height: 328,
                          width: 320,
                          src:'img/4.jpg'
                        }]}
                      ,{title: 'A &#8651; B &#8596; C ',
                        autoScroll:true,
                        items: [{
                          xtype: 'image',
                          height: 125,
                          width: 320,
                          src:'http://www.sencha.com/img/sencha-large.png'
                        }]},
                      {title: 'Brackets',
                       autoScroll:true,
                       items: [{
                         xtype: 'image',
                         height: 200,
                         width: 320,
                         src:'img/6.jpg'
                       }]},
                      {title: 'Functions',
                       autoScroll:true,
                       items: [{
                         xtype: 'image',
                         height: 158,
                         width: 320,
                         src:'http://www.sencha.com/img/sencha-large.png'
                       }]},
                      {title: 'Accents',
                       autoScroll:true,
                       items: [{
                         xtype: 'image',
                         height: 158,
                         width: 320,
                         src:'http://www.sencha.com/img/sencha-large.png'
                       }]},
                      {title: 'Limits and logs',
                       autoScroll:true,
                       items: [{
                         xtype: 'image',
                         height: 500,
                         width: 320,
                         src:'img/7.jpg'
                       }]},
                      {title: 'Matrix',
                       autoScroll:true,
                       items: [{
                         xtype: 'image',
                         height: 158,
                         width: 320,
                         src:'img/5.jpg'
                       }]}
                     ]
             },{
               layout: 'border',
               id: 'layout-browser',
               region:'center',
               border: false,
               split:true,
               width: 275,
               minSize: 100,
               maxSize: 500,
               items: [{
                 region: 'center',
                 xtype: 'panel',
                 layout: 'border',
                 border: false,
                 items:[{
                   title: 'Editor',
                   region:'north',
                   split:true,
                   height: 450,
                   flex:1,
                   items: [{
                     xtype: 'image',
                     height: 450,
                     width: 650,
                     src:'img/9.jpg'
                   }]
                 },{
                   title: 'Quick preview',
                   region:'center',
                   height: 325,
                   flex:1,
                   border: false,
                   items: [{
                     xtype: 'image',
                     height: 160,
                     width: 490,
                     src:'img/8.jpg'
                   }]
                 }]
               }]
             }]
           }]
          },{ 
            title: 'Ribbon - 1 line',
            layout: 'border',
            width: '100%',
            height: 650,
            border:'none',
            items: [{
              title: 'Quick preview',
              region: 'south',     // position for region
              xtype: 'panel',
              height: 300,
              split: true,
              items: [{
                xtype: 'image',
                height: 100,
                width: 350,
                src:'img/8.jpg'
              }]
            },{
              region: 'center',
              xtype: 'panel',
              border:'none',
              tbar: [{
                xtype: 'button',
                text: 'Fraction',
                menu: [{xtype: 'buttongroup',
                        columns: 5,
                        defaults: {
                          xtype: 'button',
                          scale: 'small',
                          iconAlign: 'center'
                        },
                        items: [
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                          {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'}]
                       }]},
                     {xtype:'button',text: 'Scripts',menu: [{xtype:'container',height: 158,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 158,width: 320,src:'img/5.jpg'}]}]},'-',
                     {xtype:'button',text: 'Radical',menu: [{xtype:'container',height: 158,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 158,width: 320,src:'img/5.jpg'}]}]},
                     {xtype:'button',text: 'Integral',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/1.jpg'}]}]},
                     {xtype:'button',text: 'Large operators',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/2.jpg'}]}]},'-',
                     {xtype:'button',text: 'Brackets',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/3.jpg'}]}]},
                     {xtype:'button',text: 'Functions',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/4.jpg'}]}]},
                     {xtype:'button',text: 'Accents',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/2.jpg'}]}]},'-',
                     {xtype:'button',text: 'Limits and log',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/3.jpg'}]}]},
                     {xtype:'button',text: 'Operators',menu: [{xtype:'container',height: 250,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 250,width: 320,src:'img/4.jpg'}]}]},
                     {xtype:'button',text: 'Matrix', menu: [{xtype:'container',height: 158,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 158,width: 320,src:'img/5.jpg'}]}]}],
              items: [{xtype: 'image',height: 450,width: 650,src:'img/9.jpg'}]
            }]},
          { 
            title: 'Ribbon - groups',
            layout: 'border',
            width: '100%',
            height: 650,
            border:'none',
            items: [{
              title: 'Quick preview',
              region: 'south',     // position for region
              xtype: 'panel',
              border:'none',
              height: 300,
              split: true,
              items: [{
                xtype: 'image',
                height: 100,
                width: 350,
                src:'img/8.jpg'
              }]
            },{
              region: 'center',
              xtype: 'panel',
              border:'none',
              tbar: [{
                xtype: 'buttongroup',
                columns: 4,
                border:'none',
                title: 'Simbols',
                items: [{
                  xtype:'button',
                  text: 'Fractions',
                  iconCls: 'xty_pgtoolbar-thumbsSmall',
                  menu: [{xtype: 'buttongroup',
                          columns: 5,
                          defaults: {
                            xtype: 'button',
                            scale: 'small',
                            iconAlign: 'center'
                          },
                          items: [
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'}]
                         }]
                },
                        {xtype:'button',text: 'Scripts',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 258,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 258,width: 320,src:'img/1.jpg'}]}]},
                        {xtype:'button',text: 'Integrals',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 258,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 258,width: 320,src:'img/3.jpg'}]}]},
                        {xtype:'button',text: 'Operators',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 258,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 258,width: 320,src:'img/4.jpg'}]}]}

                       ]
              },{
                xtype: 'buttongroup',
                columns: 4,
                title: 'Formulas',
                items: [{
                  xtype:'button',
                  text: 'Large operators',
                  iconCls: 'xty_pgtoolbar-thumbsSmall',
                  menu: [{xtype: 'buttongroup',
                          columns: 5,
                          defaults: {
                            xtype: 'button',
                            scale: 'small',
                            iconAlign: 'center'
                          },
                          items: [
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:yellow;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:gray;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:green;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:red;margin:3px 3px 3px 3px;'},
                            {iconCls: 'add',width: 'auto',tooltip: 'Add symbol',style:'background-color:blue;margin:3px 3px 3px 3px;'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'},
                            {iconCls: 'xty_pgtoolbar-thumbsSmall',width: 'auto',tooltip: 'Add symbol'}]
                         }]
                },
                        {xtype:'button',text: 'Brackets',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 258,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 258,width: 320,src:'img/1.jpg'}]}]},
                        {xtype:'button',text: 'Accents',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 258,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 258,width: 320,src:'img/2.jpg'}]}]},
                        {xtype:'button',text: 'Limits and logs',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 158,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 158,width: 320,src:'img/5.jpg'}]}]}]
              },{
                xtype: 'buttongroup',
                columns: 2,
                title: 'Characters',
                items: [{xtype:'button',text: 'Matrix',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 158,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 158,width: 320,src:'img/5.jpg'}]}]},
                        {xtype:'button',text: 'Radicals',iconCls: 'xty_pgtoolbar-thumbsSmall', menu: [{xtype:'container',height: 258,width: 320,border: false,style:'border-bottom:1px solid #dddddd',items: [{xtype: 'image',height: 258,width: 320,src:'img/2.jpg'}]}]}]
              }],
              items: [{xtype: 'image',height: 450,width: 650,src:'img/9.jpg'}]
            }]}
        ]
      }

            ]// eo items    

    }; // eo epobEditorPanelCfg


    var tabPanCenter = extVia.regApp.myRaster.getCenterTabPanel(); 
    tabPanCenter.addAndActivate(
      epobEditorPanelCfg
    );         
  },

  initWest: function() {

    var me = this;

    Ext.create('Ext.data.Store', {
      storeId:'elementsStore',
      fields:['id', 'epobType', 'name', 'status', 'responsible'],
      data:{'items':[
        {id:'1', epobType:'Dictionary', name:'Dictionary 1', status:'Warning', responsible:'Ernie'  },
        {id:'2', epobType:'Dictionary', name:'Dictionary 2', status:'Success', responsible:'Oskar'  },
        {id:'3', epobType:'Dictionary', name:'Dictionary 3', status:'Started', responsible:'Grobi'  },
        {id:'4', epobType:'Dictionary', name:'Dictionary 4', status:'Danger', responsible:''  },
        {id:'5', epobType:'Dictionary', name:'Dictionary 5', status:'Success', responsible:''  },
        {id:'6', epobType:'Dictionary', name:'Dictionary 6', status:'Waiting', responsible:''  },
        {id:'7', epobType:'Dictionary', name:'Dictionary 7', status:'Expired', responsible:''  }
      ]},
      proxy: {
        type: 'memory',
        reader: {
          type: 'json',
          root: 'items'
        }
      }
    });

    var epobTypeRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
      return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
    };
    var statusRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
      return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
    };

    var elementsGrid = Ext.create('Ext.grid.Panel', {
      id:'elementsGrid',
      itemId:'elementsGrid',
      viewConfig: {
        plugins: {
          ptype: 'gridviewdragdrop',
          dropGroup: 'firstGridDDGroup'
        },
        listeners: {
          drop: function(node, data, dropRec, dropPosition) {
            var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
            extVia.notify({action:'Drag from left to right'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
          }
        }
      },
      width: 400,
      border:false,
      store: Ext.data.StoreManager.lookup('elementsStore'),
      columns: [
        { header: 'Typ',  dataIndex: 'epobType', width:32, renderer: epobTypeRenderer },
        { header: 'Name',  dataIndex: 'name' ,  flex: 1},
        { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
        { header: 'Verantwortliche', dataIndex: 'client', 
         renderer: function(){
           var clientsHtml = 
               '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
               '<span class="xty_tag" title="Muppets">Muppets</span>' +
               '<span class="xty_tag" title="Puppets" >Puppets</span>' +
               '</span>';
           return clientsHtml;
         }
        },
        { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
      ],
      height: 200,
      listeners:{
        itemdblclick: function( view, record, item, index, evt, eOpts ){
          me.showEditor(view, record, item, index, evt, eOpts);
        }
      }
    });

    var elementsList = {
      title:'Dictionaries',
      itemId:'elementsList',
      height: me.getWestListHeight(),
      tbar:[
        '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'Löschen', handler: me.deleteEpobDialog}
      ],
      items:[ elementsGrid ] ,
      bbxxar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
    };

    var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
      tabBar:{ 
        tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
                handler:function(button){
                  var activeTab = button.ownerCt.ownerCt.getActiveTab();
                  extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                }
               }
              ]
      },
      items:[elementsList]

    });
    extVia.regApp.myRaster.addToWest(tabPanWest);
  },   

  launch: function() {

    Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
      expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    }));
    extVia.regApp = this;
    var me = this;
    var modulDscr = 'Dictionary';
    var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
    extVia.constants.raster.mainWestWidth = 360;
    extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr, propsearchEnabled: false});
    extVia.ui.page.raster.onReady(this);

    me.initWest();

    // Need some center Tabs?
    var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
      tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
                        handler:function(button){
                          var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
                          extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                        },
                        iconCls:'x-tool x-tool-refresh'}]  }
    });

    me.tabPanCenter = tabPanCenter;
    extVia.regApp.myRaster.addToCenter(tabPanCenter); 

    var elementsModuleAppbar = extVia.ui.page.pagejob.getApplicationBar(
      { pgjobDscr:'Dictionary',
       epobDscr: 'Module'
      } 
    );

    var elementsModulePanel = {
      title:'Formula',
      tbar: elementsModuleAppbar, closable:true,
      defaults:{
        margin:'24 24 24 24',
        collapsible:true,
        width:580
      }
    };

    tabPanCenter.addAndActivate(elementsModulePanel);

  }
});



/*
 * 
 * $Revision: 1.1.2.10 $
   $Modtime: 05.01.18 09:43 $ 
   $Date: 2019/03/22 12:10:27 $
 * $Author: dantohi $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 
