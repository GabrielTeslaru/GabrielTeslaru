/*
*/
Ext.application({
    name: 'collaborationsOverview',
    
    appMode:{},

    
    
    
    embedded : false,
    isEmbedded : function(){
      var me = this;
//      if (location.href.indexOf('&ownerId=') >-1){
//        me.embedded = true;
//      }
      me.embedded = true;
      return me.embedded;
    },
    
    
    
    getBaseUrl : function(){
      var me = this;
      if (!Ext.isDefined(me.baseUrl)){
        var baseUrl =  './';
        if ( me.isEmbedded() ){ 
          baseUrl = location.href.replace(/\/ajsp.*/,'/jsp');
        }
        baseUrl = location.href.replace(/\/jsp.*/,'/jsp');
        me.baseUrl = baseUrl; 
      }
      return me.baseUrl;
    },
    
    
    
    launch: function() {

    var me = this;
    
    var size = {x:416, y:620};
    
    
    if (me.isEmbedded()){
      //location.href.indexOf('.html?size=') >-1);
      size.y = 540;
      size.x =  420;
    }    

    
//  var userName =   extVia.collaboration.statics.getUserName();
//  var userId =   extVia.collaboration.statics.getUserId();
    
  
  

    var loc = extVia.locales;
    
    var store = extVia.collaboration.statics.getUsersOverviewStore();
    store.load();
    
    var baseUrl = me.getBaseUrl(); 
    var imgBaseUrl = baseUrl + '/../img/';
    if (me.isEmbedded()){
      imgBaseUrl = baseUrl +  '/via-img/';
    }  
    

    
      
    var collabsOverviewGrid =  Ext.create('Ext.grid.Panel', {
      
        border:false,
        title: loc.notifications, // +' for '+userName + ' '+userId,    
            
        hideHeaders:true,
        
        cls:'xty_collabs-overview-grid',
            
        tools: [
          {xtype:'button', 
            cls:'xty_tool-more',
            width: 18, height:15, 
            menu:{
              defaults:{handler:function(item){}},
              items: [{text: loc.recentlyViewed, iconCls:'xty_icon-recently'},{text: loc.watched, iconCls:'xty_icon-watch'},{text:loc.faves, iconCls:'xty_icon-fave'},{text: loc.shared, iconCls:'xty_icon-share'},{text: loc.comments, iconCls:'xty_icon-comment'},{text: loc.allNotifications, iconCls:'xty_icon-bell'}]
            },
            handler: function(event, headerEL, header, tool) {  }
          },
          
          {type: 'refresh', 
            handler: function(event, headerEL, header, tool) { 
              //store.load();
              var locationhref = location.href;
              location.href = locationhref;
            }
          },
          {type: 'close', 
          handler: function(event, headerEL, header, tool) { 
           //var me = this;
           if(!me.isEmbedded() ){top.bellsFlyoutClose();}
           top.frames.F1.myMenuController.menuItemClick('close', 'bells-flyout-panel'); 
          }}],
        store: store,
        columns: [

          
//          { header: 'Type', dataIndex: 'collabType',  width:24, hidden:true,
//            renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
//            return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_collabstype-icon xty_icon-'+value+'"><span title="'+value+'"style="marssgin-top:-8px;"></span></div>';
//           }
//          },
//          
          { header: 'Person',  dataIndex: 'usersName', width: 40,
              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {

               var usersTpl = '';
               if (value){
                 var avatar = value.replace(/ /,'' ).toLowerCase();
                 usersTpl = 
                    '<img class="xty_avatar-img"  src="'+imgBaseUrl+'spacer.gif" style="background-image: url('+imgBaseUrl+'epobs/user/avatars/'+avatar+'_48.png) , url('+imgBaseUrl+'epobs/user/avatars/default_48.png); ">';
               }
                return usersTpl; 
              }
            },

            
            
            { header: 'Value', dataIndex: 'value', flex: 1,
              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
                var collabType = record.get('collabType');
               
                var whosName = record.get('usersName');
                var who = '<b>' +whosName+'</b>';
                var collabAction='';
                
                var epob = record.get('epob');
                var epobId = record.get('epobId');
                var epobName = record.get('epobName');
                
                var epobTypeId = record.get('epobTypeId');
                var epobType ='Product';
                if(epobTypeId==='2040'  ){
                  epobType ='Productvariant';
                }
  
                if(!epobName){
                  epobName='Driller';
                }
                
                var html = value;
                if (collabType==='share'){
                  collabAction = loc.sharedWithYou;
                  html='<br><a class="xty_epob'+epobType+' xty_gridcell-link" style="padding-left:18px;text-decoration:none;color:black;" target="_blank" href="'+baseUrl+'/../ajsp/Forward.jsp?p_sFromPage=QueryProductsProductgroups&p_sPageType=PageMain&p_sObpdId='+epobId+'">'+epobName+' [&raquo;] </a>';
//                  var personsArrEnd = value.indexOf('],');
//                  html =  ' <div style="white-space: normal;" class="xty_boundlist-item-sharedwith">'+ value.substring(9,personsArrEnd).replace(/,/g,', ') +'</div>';
                }
                
                else if (collabType==='recently'){
                  collabAction = loc.recentlyViewed;
                  html='<br><a class="xty_epob'+epobType+' xty_gridcell-link" style="padding-left:18px;text-decoration:none;color:black;" target="_blank" href="'+baseUrl+'/../ajsp/Forward.jsp?p_sFromPage=QueryProductsProductgroups&p_sPageType=PageMain&p_sObpdId='+epobId+'">'+epobName+' [&raquo;] </a>';
                }
                
                else if (collabType==='comment'){
                  collabAction = loc.commentedForYou;
                  html = value.replace(/message:/,'<br>');
                  html = html.replace(/\\n/,'<br>');
                  html = html.replace(/\\n/,'<br>');
                  html = html.replace(/\\n/g,'  ');
                  
                  
                  html+=' <a class=" xty_gridcell-link" style="padding-left:18px;text-decoration:none;color:black;" target="_blank" href="'+baseUrl+'/../ajsp/Forward.jsp?p_sFromPage=QueryProductsProductgroups&p_sPageType=PageMain&p_sObpdId='+epobId+'" title="'+epobName+'">[&raquo;] </a>';
                }                
                
                
                html =   who+' '+ collabAction + html ;

               // var typeIcon = '<br><span style="width:100%; height:22px; padding-left:16px;" class="xty_collabstype-icon xty_icon-'+collabType+'"  title="'+collabType+'"></span>';

                var dt = new Date(); 
                dt.setTime( record.get('time'));
                var format = loc.extDateDscrFormat  + ' H:i';
                var timy = Ext.Date.format(dt, format);
                
                var isNewStar = '';
//                var isNew = false;
//                if(isNew){
//                  isNewStar='<span class="xty_teaser-isnew-star" title="isnew" style="color:#00aaea;font-size:16px;" >&nbsp;*&nbsp;</span> ';
//                }
                
                html+= isNewStar+'<br><span class="xty_collabscell-time" style="color:#888;">' +timy +'</span>';
                
                return html;
              }
            
            }
            
            
            
//            ,{ header: 'Time',  dataIndex: 'time', hidden:true,
//              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
//                var dt = new Date(); 
//                dt.setTime(value);
//                var format = loc.extDateDscrFormat  + ' <br> H:i';
//                return   Ext.Date.format(dt, format);
//              }
//           }
            
            
            
            ,{ header: 'Type', dataIndex: 'collabType',  width:30, 
              renderer: function ( value, metaData, record, rowIndex, colIndex, store, view )  {
              return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_collabstype-icon xty_icon-'+value+'"><span title="'+value+'"style="marssgin-top:-8px;"></span></div>';
             }
            }
            
            
            
        ],
        height: size.y,
        width: size.x,
        renderTo: Ext.getBody()
    });
        
    }
});


