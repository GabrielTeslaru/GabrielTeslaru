/**
 * @author aweber@viamedici.de (Adrian Weber)
 * @docauthor aweber@viamedici.de (Adrian Weber)
 * 
 * The Breadcrumb shows the labels of the sections in the hierarchical path that lead to the
 * current page being viewed. Each label is a link to a section. In addition to it this
 * implementation shows the anderlaying sections of the current page. These labels are also
 * linked sections (dissents the Breadcrumb pattern).
 * In Addition to that the children of the current section could be displayed in a clickable
 * tooltip at the bottom of the current section's label.
 */
Ext.define('extVia.nav.Breadcrumb', {
	extend: 'Ext.toolbar.Toolbar',
	cls: 'xty_navi-container xty_navi-breadcrumb',
	border: false,
	width: 1000,
	
	/**
	 * @cfg {Boolean} mouseover
	 * `true` to display a tooltip with a subemnu under the currently selected section.
	 * (Defaults to `true`).
	 */
	mouseover: true,
	 
	 /**
	  * @private
	  * @cfg {Number} subMenuAdditionalWidth
	  * The number of pixesl to add after a width calculation for the submenu.
	  * (Defaults to `65`).
	  */
	subMenuAdditionalWidth : 65,

	//@private
	initComponent : function() {
		var me = this,
			root = Ext.data.StoreManager.lookup('navigationStore').getRootNode();
			
		me.callParent(arguments);
		me.refreshBreadcrumb(root, true);			
	},
	
	/**
	 * Refresh the Breadcrumb with a new selection.
	 * 
	 * @private
	 * @param {Ext.data.NodeInterface} node The new selection
	 * @param {Boolean} select `true` if the new selection should be 
	 					marked as selected
	 */
	refreshBreadcrumb : function(node, select) {
		var me = this,
			parent,
			path = [],
			item,
			i = 0;
		
		if(node.isLeaf()) {
			return;
		}
		
		me.removeAll();
		item = me.createItem(node, true, true);
		
		if(select) {
			me.setSelection(item);
		}
		
		path.push(item);
		parent = node.parentNode;
		
		//Builds the breadcrumb
		for(;parent;parent = parent.parentNode) {
			path.push(me.createItem(parent, true));
		}
		path.reverse();
		
		for(;i < path.length; ++i) {
			me.add(path[i]);
		}//eo build breadcrumb
		
		//builds the subitems of the current section
		node.eachChild(function(child) {
			me.add(me.createItem(child));
		});
	},
	
	/**
	 * Returns the selected item.
	 * 
	 * @return {Ext.button.Button} The currently selected item
	 */
	getSelection : function() {
		return this.selection;
	},
	
	/**
	 * Sets the new selection.
	 * 
	 * @private
	 * @param {Ext.button.Button} selection The new selection
	 */
	setSelection : function(selection) {
		this.selection = selection;
	},
	
	/**
	 * Returns if the node should be rendered with subitems.
	 * 
	 * @private
	 * @param {Ext.data.NodeInterface} node
	 * @return {Boolean} `true` if the node has a submenu, `false` if not.
	 */
	hasSubItems : function(node) {
		if(!node) {
			return false;
		}
		return (!node.isLeaf() && !node.isRoot());
	},
	
	/**
	 * Returns if the subemnu of a node should be rendered.
	 * 
	 * @private
	 * @param {Ext.data.NodeInterface} node
	 * @return {Boolean} `true` if the submenu should be rendered, `false` if not.
	 */
	isSubemnuVisible : function(node, selection) {
		return (this.mouseover && (selection && !node.isLeaf() && node !== selection));
	},
	
	/**
	 * Creates a {@link Ext.button.Button} item for each navigation node.
	 * Items which could have subitems will be marked.
	 * 
	 * @private
	 * @param {Ext.data.NodeInterface} node The data node for the item
	 * @param {Boolean} parent `true` if the node is from the breadcrumb
	 * @param {Boolean} select `true` if the new selection should be 
	 					marked as selected
	 * @return {Ext.button.Button} The item as button
	 */
	createItem : function(node, parent, select) {
		var me = this,
			subItems,
			width,
			selection ,
			config = {
				xtype : 'button',
				text : node.get('text'),
				node : node,
				id : node.id,
				listeners : {
					click : function(item) {
						me.setSelection(item);
						me.refreshBreadcrumb(item.node);
					}
				}
			};
		
		selection = select ? node : me.getSelection();
		
		if(node.isRoot()) {
			config.iconCls = node.get('iconCls');
		}
		if(parent) {
			config.cls  = 'xty_navi-breadcrumb-active';
		} else if(me.hasSubItems(node)) {
			config.xtype = 'splitbutton';
		}
		
		if(me.isSubemnuVisible(node, selection)) {
			subItems = me.createSubItems(node);
			width = me.calculateSubmenuWidth(subItems);
			config.listeners.afterrender = function(item) {
				item.submenu = me.createSubmenu(item, subItems, width);
			};	
		}	
		return config;
	},
	
	/**
	 * Creates a submenu using a {@link Ext.tip.ToolTip tooltip}.
	 * 
	 * @private
	 * @param {Ext.button.Button} item  The item with the submenu
	 * @param {Array} subItems The items of the subemnu
	 * @param {Number} width The calculated with for the subemenu
	 * @return {Ext.tip.ToolTip} submenu in a tooltip
	 */
	createSubmenu : function(item, subItems, width) {
		
		var submenu = Ext.create('Ext.tip.ToolTip', {
            target: item.getId(),
            anchor: 'bottom',
            showDelay: 0,
            border: false,
            items : [{
				xtype : 'toolbar',
				width : width,
				items : subItems,
				componentCls : 'xty_navi-container',
				border : false
			}],
            html: null,
            autoHide: false,
            listeners : {
            	show : function(ttip) {
                   if (extVia.nav.Breadcrumb.lastSubMenu){
					    extVia.nav.Breadcrumb.lastSubMenu.hide();
					}
            	   extVia.nav.Breadcrumb.lastSubMenu = ttip;
            	},
            	
            	afterrender : function() {
            		item.submenu.getEl().on('mouseleave', function(){
						item.submenu.hide();
					});
            	}
            }
		});

		return submenu;
	},
	
	/**
	 * Creates submenu from a data nodes children.
	 * 
	 * @private
	 * @param {Ext.Data.NodeInterface} node The data node
	 * @return {Array} The submenu items for the node
	 */
	createSubItems : function(node) {
		var me = this,
			subItems = [];
			
		node.eachChild(function(child){
			subItems.push({
				text : child.get('text'),
				node : child,
				listeners : {
					click : me.handleSubItemClick,
					scope : me
				}
			});
		});
		
		return subItems;
	},
	
	/**
	 * Handles the click on a subItem. Refreshes the breadcrumb if there 
	 * is a parent item and closes the subemnu.
	 * 
	 * @private
	 * @param {Ext.button.Button} subItem The subItem
	 */
	handleSubItemClick : function(subItem) {
		var me = this,
			node = subItem.node;
		
		me.setSelection(subItem);
		if(node.parentNode) {
			me.refreshBreadcrumb(node.parentNode);
		}
		
		subItem.up('tooltip').hide();
	},
	
	/**
	 * Calulates the with for the subemnu by using the text of the items
	 * and a user defined offset.
	 * 
	 * @private
	 * @param {Array} subItems The submenu items
	 * @return {Number} The calculated with
	 */
	calculateSubmenuWidth: function(subItems) {
		var me = this,
			width = 0,
			i = 0;
		
		for(; i < subItems.length; ++i) {
			width += Ext.util.TextMetrics.measure(Ext.getBody(), subItems[i].text).width;
		}
			
		return (width + me.subMenuAdditionalWidth);
	}
});