/**
 * 
 */
Ext.application({
    name: 'customTab',
    
    /**
     * Place 
     */
    appMode:{},

 
    getContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight(); 
    },
 
    getEditorContentPanelHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true}); 
    },
    
    getEditorSubTabHeight : function (){
     var me = this;
     return me.getCenterHeight({hasPagetoolbar: true, hasSubtabs:true }); 
    },
    
    getCenterHeight : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerHeight = centerPan.getHeight();
      centerHeight-=25; // substract center-tabstrip 
      centerHeight-=66; // substract pagejobbar 
      if (cfg && cfg.hasPagetoolbar){
        centerHeight-=60;  // substract pagetoolbar 
      }
      if (cfg && cfg.hasSubtabs){
        centerHeight-=30; // substract subtabstrip
      }      
      return centerHeight;
    },

    getCenterWidth : function (cfg){
      var centerPan =  extVia.regApp.myRaster.getCenter();
      var centerWidth = centerPan.getWidth()-50;    
      return centerWidth;
    },
    
    getWestListHeight : function (cfg){
      var westPan =  extVia.regApp.myRaster.getWest();
      var westHeight = westPan.getHeight()-28; // ohne tabs toolbar + bottombar    
      return westHeight;
    },
    

    showEditor: function() {
      extVia.notify({action: 'show Editor '  , mssg:  'Wo isser ?'}); 
    },
    
    
    
    initWest: function() {

      var me = this;
      
      Ext.create('Ext.data.Store', {
         storeId:'whateverStore',
         fields:['id', 'epobType', 'name', 'status', 'responsible'],
         data:{'items':[
             {id:'1', epobType:'Product', name:'Flow 1', status:'Warnung', responsible:'Ernie'  },
             {id:'2', epobType:'Image', name:'Bilder hochladen', status:'', responsible:'Oskar'  },
             {id:'3', epobType:'Video', name:'Welt retten', status:'Start', responsible:'Grobi'  },
             {id:'4', epobType:'User', name:'Kuchen backen', status:'Danger', responsible:''  },
             {id:'5', epobType:'Attribute', name:'Datenbank zerstören', status:'Success', responsible:''  },
             {id:'6', epobType:'Product', name:'Produkte pflegen', status:'Wait', responsible:''  }
         ]},
         proxy: {
             type: 'memory',
             reader: {
                 type: 'json',
                 root: 'items'
             }
         }
       });

       var epobTypeRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div title="'+value+'" style="height:18px;padding-left:16px;vertical-align:bottom;" class="xty_epob'+value+'"> &nbsp;&nbsp;&nbsp;</div>';
         };
       var statusRenderer = function ( value, metaData, record, rowIndex, colIndex, store, view )  {
           return '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon xty_icon_'+value+'"><span title="'+value+'"style="margin-top:-8px;"></span></div>';
         };

        var whateverGrid = Ext.create('Ext.grid.Panel', {
          itemId:'whateverGrid',
              width: 400,
              border:false,
              store: Ext.data.StoreManager.lookup('whateverStore'),
              columns: [
                   { header: 'Typ',  dataIndex: 'epobType', width:32, renderer:epobTypeRenderer },
                   { header: 'Name',  dataIndex: 'name' ,  flex: 1},
                   { header: 'Status', dataIndex: 'status', width:40, renderer: statusRenderer },
                   { header: 'Verantwortliche', dataIndex: 'client', 
                     renderer: function(){
                       var clientsHtml = 
                         '<span class="xty_grid-cell-tags xty_grid-cell-2-tags">' +
                           '<span class="xty_tag" title="Muppets">Muppets</span>' +
                           '<span class="xty_tag" title="Puppets" >Puppets</span>' +
                         '</span>';
                       return clientsHtml;
                     }
                   },
                 { header: 'EPIM-Id',  dataIndex: 'id', hidden: true}
           ],
           height: 200,
               listeners:{
                itemdblclick: function( view, record, item, index, evt, eOpts ){
                 me.showEditor(record);
                }
               
               }
          
       });

         var whateverList = {
             title:'Whatever',
             itemId:'whateverList',
             height: me.getWestListHeight(),
             tbar:[
             '->',  {iconCls: 'xty_pgtoolbar-new', itemId:'new', handler: me.showEditor}, {iconCls: 'xty_pgtoolbar-edit', itemId:'edit',handler: me.showEditor},{iconCls: 'xty_pgtoolbar-delete',itemId:'delete',  tooltip:'Löschen', handler: me.deleteEpobDialog}
             ],
             items:[ whateverGrid ] ,
             bbar:['->',{iconCls:' xty_pgtoolbar-pagingFirst'},{iconCls:' xty_pgtoolbar-pagingPrev'},{iconCls:' xty_pgtoolbar-pagingNext'},{iconCls:' xty_pgtoolbar-pagingLast'}]
          };
  
         
         
         
         var structureTreeStore = Ext.create('Ext.data.TreeStore', {
           root: {
               expanded: true,

               text: "Bohrmaschine",
               iconCls:'xty_epobProduct',
               children: [
                   { text: "Audios"},
                   { text: "Bilder", expanded: true, children: [
                       { text: "book report", leaf: true, iconCls:'xty_epobImage'},
                       { text: "alegrbra", leaf: true,  iconCls:'xty_epobImage'}
                   ] },
                   { text: "Texte"}
               ]
           }
       });

       var structureTreePanel = Ext.create('Ext.tree.Panel', {
           title: 'Produktstruktur',
           useArrows : true,  
           viewConfig: {
             plugins: {
                 ptype: 'treeviewdragdrop'
             }
           },
           itemId:'structureTreeTab',
           border:false,
           store: structureTreeStore,
           tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign'}]
       });
         
         
         
         var structureTreeTab = { 
                title:'Produktstruktur', 
                itemId:'structureTreeTab',
                tbar:[ '->',    {text:'MAM', iconCls: 'xty_pgtoolbar-mam-assign', itemId:'mam'}, {xtype:'splitbutton', iconCls: 'xty_pgtoolbar-assignToLeft', text:'Zuordnen', itemId:'assign'}],
                items:[structureTreePanel]
          }; 
 
         var hierarchyTab = extVia.hierarchy.statics.getHierarchyTabCfg({});
         
         var tabPanWest = extVia.regApp.myRaster.initWestTabPanel({
             tabBar:{ 
               tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', iconCls:'x-tool x-tool-refresh', masrgin:'0 0 0 50',  
               handler:function(button){
                 var activeTab = button.ownerCt.ownerCt.getActiveTab();
                   extVia.notify({action: 'Refresh West '  , mssg:  '<b>'+activeTab.title+'</b>'}); 
                 }
                }
               ]
             },
             items:[structureTreePanel, hierarchyTab, whateverList]
             });
            extVia.regApp.myRaster.addToWest(tabPanWest);

    },
    
    
    
  getDnDGridsPanel: function(cfg) {
    
    Ext.define('DataObject', {
      extend: 'Ext.data.Model',
      fields: ['name', 'column1', 'column2']
    });
    
      var myData = [
        { name : "Rec 0", column1 : "0", column2 : "0" },
        { name : "Rec 1", column1 : "1", column2 : "1" },
        { name : "Rec 2", column1 : "2", column2 : "2" },
        { name : "Rec 3", column1 : "3", column2 : "3" },
        { name : "Rec 4", column1 : "4", column2 : "4" },
        { name : "Rec 5", column1 : "5", column2 : "5" },
        { name : "Rec 6", column1 : "6", column2 : "6" },
        { name : "Rec 7", column1 : "7", column2 : "7" },
        { name : "Rec 8", column1 : "8", column2 : "8" },
        { name : "Rec 9", column1 : "9", column2 : "9" }
    ];

    // create the data store
    var firstGridStore = Ext.create('Ext.data.Store', {
        model: 'DataObject',
        data: myData
    });


    // Column Model shortcut array
    var columns = [
        {text: "Record Name", flex: 1, sortable: true, dataIndex: 'name'},
        {text: "column1", width: 70, sortable: true, dataIndex: 'column1'},
        {text: "column2", width: 70, sortable: true, dataIndex: 'column2'}
    ];

    // declare the source Grid
    var firstGrid = Ext.create('Ext.grid.Panel', {
        multiSelect: true,
        viewConfig: {
            plugins: {
                ptype: 'gridviewdragdrop',
                dragGroup: 'firstGridDDGroup',
                dropGroup: 'secondGridDDGroup'
            },
            listeners: {
                drop: function(node, data, dropRec, dropPosition) {
                    var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
                    //Ext.example.msg("Drag from right to left", 'Dropped ' + data.records[0].get('name') + dropOn);
                    extVia.notify({action:'Drag from right to left'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
                    
                }
            }
        },
        store            : firstGridStore,
        columns          : columns,
        stripeRows       : true,
        title            : 'First Grid',
        margins          : '0 2 0 0'
    });

    var secondGridStore = Ext.create('Ext.data.Store', {
        model: 'DataObject'
    });

    // create the destination Grid
    var secondGrid = Ext.create('Ext.grid.Panel', {
        viewConfig: {
            plugins: {
                ptype: 'gridviewdragdrop',
                dragGroup: 'secondGridDDGroup',
                dropGroup: 'firstGridDDGroup'
            },
            listeners: {
                drop: function(node, data, dropRec, dropPosition) {
                    var dropOn = dropRec ? ' ' + dropPosition + ' ' + dropRec.get('name') : ' on empty view';
                    //Ext.example.msg("Drag from left to right", 'Dropped ' + data.records[0].get('name') + dropOn);
                    extVia.notify({action:'Drag from left to right'  , mssg:  'Dropped ' + data.records[0].get('name') + dropOn}); 
                }
            }
        },
        store            : secondGridStore,
        columns          : columns,
        stripeRows       : true,
        title            : 'Second Grid',
        margins          : '0 0 0 3'
    });

    //Simple 'border layout' panel to house both grids
    var displayPanel = Ext.create('Ext.Panel', {
        width        : 650,
        height       : 300,
        layout       : {
            type: 'hbox',
            align: 'stretch',
            padding: 5
        },

        defaults     : { flex : 1 }, //auto stretch
        items        : [
            firstGrid,
            secondGrid
        ],
        dockedItems: {
            xtype: 'toolbar',
            dock: 'bottom',
            items: ['->', // Fill
            {
                text: 'Reset both grids',
                handler: function(){
                    //refresh source grid
                    firstGridStore.loadData(myData);

                    //purge destination grid
                    secondGridStore.removeAll();
                }
            }]
        }
    });

      var dndGridsDisplayPanel = displayPanel; //{title:'acdc'};
      return dndGridsDisplayPanel;
      
    },
    
    
    
    launch: function() {
      Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
          expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
      }));
      extVia.regApp = this;
      var me = this;
      var  modulDscr = 'custom Tab';


      var viewCfg;// = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
      extVia.constants.raster.mainWestWidth = 360;
      extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscr:modulDscr});
      extVia.ui.page.raster.onReady(this);


       me.initWest();
      

      // Need some center Tabs?
      var tabPanCenter = extVia.regApp.myRaster.initCenterTabPanel({
       tabBar:{  tools:[{xtype:'button', cls:'xty_striptool-button xty_striptool-button-refresh', 
        handler:function(button){
           var activeTab = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
           extVia.notify({action: 'Refresh Center'  , mssg:  '<b>'+activeTab.title+'</b>'}); 
        },
        iconCls:'x-tool x-tool-refresh'}]  } 
      });

      me.tabPanCenter = tabPanCenter;
      extVia.regApp.myRaster.addToCenter(tabPanCenter); 
      
      
      // if you ned an extra App Panel:  customTab-Module
       var customModuleAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr:'customTab modul', epobDscr:null,  pgjobButtons: [{itemId:'search',  xtype:'splitbutton',menu:{items:[{text:'retry Full'},{text:'retry Test'}]}}] } );
       var customModulePanel = {title:'customTab modul', tbar: customModuleAppbar, items:[] };
       tabPanCenter.addAndActivate(customModulePanel);

      // ProductEditor - prodEditor

     var prodEdiBoxDefaults = { labelWidth : 180, width : 460,  msgTarget:'side',  xtype:'textfield',   margin:'4 0 4 4' };

     var editorSubTabHeight = me.getEditorSubTabHeight();
     
     var striptoolHandler = function(button){
       var editorPan = extVia.regApp.myRaster.getCenterTabPanel().getActiveTab();
       var editorSubTabsActiveTab = editorPan.getComponent('editorSubTabsPanel').getActiveTab().title;
       extVia.notify({action: button.itemId+' Center SubTab'  , mssg:  '<b>'+editorSubTabsActiveTab+'</b>'}); 
     };
     
     var appIsInsideWebserver = location.href.indexOf('http://')>-1;
     
     var prodEditorSubTabsPanelCfg =     { 
        xtype:'tabpanel',
        itemId:'editorSubTabsPanel',
        border:false, 
        margin : '0 0 0 0', 
        cls:'xty_prodEditorTabPanel', 
        activeTab:  3, 
        tabBar:{cls:'xty_subtabpanel-tabbar',   
          tools:[
            {xtype:'tbfill'},
            {xtype:'button', itemId:'maximize', handler:striptoolHandler, cls:'xty_striptool-button xty_striptool-button-maximize', iconCls:'x-tool x-tool-maximize',style:'margin-top:2px;'},
            {xtype:'button', itemId:'refresh',  handler:striptoolHandler, cls:'xty_striptool-button xty_striptool-button-refresh',  iconCls:'x-tool x-tool-refresh',style:'margin-top:2px;'}
           ]
          }, 

        defaults:{ // defaults for tab-panels
                   border:false,
                   XautoScroll:true, height: editorSubTabHeight, 
                   defaults:{ // defaults for boxes
                    xtype:'form', width:580, margin:'24 24 24 24',
                    defaults:{ // defaults for box-items
                    labelWidth : 180,
                    width : 380,
                    msgTarget:'side',
                    xtype:'textfield', 
                    margin:'4 0 4 4'
                     }
                   }
                },
        items:[
          {title:'Produkt', items:[
            { xtype:'form', title:'Metadaten', itemId:'metadata',  collapsible:true,
              defaults:prodEdiBoxDefaults, items:[{fieldLabel:'Name', allowBlank:false, value:'Bohrmaschine'}]
            },
            { xtype:'form', title:'Änderungsinfo', itemId:'changeInfo', defaults:prodEdiBoxDefaults,
             items:[  { itemId:'changeDate', xtype:'displayfield', fieldLabel:'Anlage', value:'heute' }, { itemId:'creationDate', xtype:'displayfield', fieldLabel:'letzt Änderung', value:'' }]
            }
           ]
          },
          {title:'Attribute', itemId:'attributes',  items:[  ]},
          {title:'Elemente',  itemId:'elements', items:[  ]},

          ////////////////// -- Cosmin start -- //////////////////
          {title:'Asset Sorting', itemId:'asset-sorting', 
            items:[ 
              me.getDnDGridsPanel({})  
            ]
          },
          ////////////////// -- Cosmin end -- //////////////////
          
          
          {title:'custom Tab', itemId:'customTab-1', items:[       
            { xtype:'form', title:'Search', itemId:'search',  collapsible:true,collapsed:true,
              defaults:prodEdiBoxDefaults, items:[
                  {fieldLabel:'Name'},
                  {fieldLabel:'Id'},
                  Ext.create('Ext.form.ComboBox', {
                    fieldLabel:'Attribute', labelWidth:180,
                      store:  Ext.create('Ext.data.Store', {
                        fields: ['abbr', 'name'],
                        data : [
                            {"abbr":"AL", "name":"Easy"},
                            {"abbr":"AK", "name":"Medium"},
                            {"abbr":"AZ", "name":"Advanced"}
                        ]
                      }),
                      queryMode: 'local',
                      displayField: 'name',
                      valueField: 'abbr'
                  }),
                  {fieldLabel:'Date', xtype:'datefield'}  
                  ]
            },
            
            Ext.create('Ext.grid.Panel', {
              title: 'Users', collapsible:true,collasdpsed:true,
              height:400,
              maxHeight:400,
              store: Ext.create('Ext.data.Store', {
              model: Ext.define('User', {
                  extend: 'Ext.data.Model',
                  fields: [
                      {name: 'name', type: 'string'},
                      {name: 'id',   type: 'string'},
                      {name: 'born', type: 'string'},
                      {name: 'who',  type: 'string'}                            
                  ]
              }),

              xdata:[
                {"name": "Oscar Wilde", "id": "12327","born": "1854", "who": "Writer" },     
                {"name": "Werner T.Kuestenmacher", "id": "12312", "born": "1953 ","who": "simplify founder"},
                {"name": "Kira Kr&auml;mer","id": "1239", "born": "1972", "who": " Design Thinking Teacher"}
              ],
              // >>> PROD V4 Start (EPIM-7678) <<<
              proxy: {
                  type: 'ajax',
                  url : '../data/users.json',
                  reader: {
                      type: 'json',
                      root: 'users'
                  }
              },
              // >>> PROD V4 End (EPIM-7678) <<<
              autoLoad: true
              }),
            
              columns: [
                  { header: 'Name', width:184, dataIndex: 'name' },
                  { header: 'Born', dataIndex: 'born'  },
                  { header: 'Profession', dataIndex: 'who', flex: 1 },
                  { header: 'id', dataIndex: 'id', hidden: true }
              ]  
          }),

            {title:'some extjs example links',xtype:'form', xtsype:'toolbar', collapsible:true,collapsed:true,  
              defaults:{xtype:'button'}  , 
              items:[ 
                {text:'4.07<br>view multisort',  href:'http://docs.sencha.com/extjs/4.0.7/#!/example/view/multisort/multisort.html'},
                {text:'4.07<br> grid dnd', href:'http://docs.sencha.com/extjs/4.0.7/extjs-build/examples/dd/dnd_grid_to_grid.html'},
                {text:'4.07<br> tree dnd', href:'http://docs.sencha.com/extjs/4.0.7/extjs-build/examples/tree/two-trees.html'},
                {text:'4.07<br> treegrid', href:'/http://docs.sencha.com/extjs/4.0.7/extjs-build/examples/tree/treegrid.html'},
                {xtype:'tbseparator'},
                {text:'4.2.4<br>view multisort', href:'http://docs.sencha.com/extjs/4.2.4/extjs-build/examples/build/KitchenSink/ext-theme-classic/#dataview-multisort'},
                {text:'4.2.4<br>multisort json', href:'http://docs.sencha.com/extjs/4.2.4/extjs-build/examples/build/KitchenSink/ext-theme-classic/resources/data/sencha-touch-examples.json'},
                {xtype:'tbseparator'},              
                {text:'6.5<br>view multisort', href:'http://examples.sencha.com/extjs/6.5.0/examples/kitchensink/?classic#dataview-multisort'},  
                {text:'6.5<br>', href:'https://www.sencha.com/products/extjs/#overview'} 
              ]
            }
            ]
          },
          
          {
            itemId:'customTab-2-iframe',
            margin:'0 0 0 0',
            title:'custom: ext6.5 dashboard',
            html : '<iframe width="100%" height="100%" id="customTab-2-iframe"  frameborder="0" src="http://examples.sencha.com/extjs/6.5.0/examples/admin-dashboard/#dashboard" ></iframe>'
            
          },
          
          {title:'custom: ext6.5 examples',  itemId:'customTab-3', items:[ 
                {
                  itemId:'customTab-3-iframePanel-dashb',
                  tools:[{id:'maximize'}, {id:'minus', handler:function(event, toolEl, panel){
                    if (panel.ownerCt.collapsed)  {panel.ownerCt.expand();}
                    else{panel.ownerCt.collapse();} 
                   }
                  }],
                  width: null, 
                  margin:'10 10 10 10',
                  height: editorSubTabHeight-20, // substract 2* margin
                  title:'customApp iframe Panel',
                  html : '<iframe width="100%" height="100%" id="customTab-3-iframe"  frameborder="0" src="http://examples.sencha.com/extjs/6.5.0/examples/kitchensink/?classic#all" ></iframe>'
                }
            ]
          },
        {
          itemId:'customTab-4-justified',
          margin:'-300  0 0 0',
          title:'justified jquery',
          html : '<iframe width="100%" height="100%" id="customTab-4-iframe"  frameborder="0" src="http://nitinhayaran.github.io/Justified.js/demo/" ></iframe>'
          
        },
        {
          itemId:'customTab-5-iframe',
          margin:'-300  0 0 0',
          title:'justified flickr',
          html : '<iframe width="100%" height="100%" id="customTab-4-iframe"  frameborder="0" src="http://code.flickr.net/2016/04/05/our-justified-layout-goes-open-source/" ></iframe>'
            
         }         
        ]
      };  


      
      var epob = {epobId:'drill_1', dscr:'Bohrmaschine', epobType:'Product'};

      
      var uiLangIso = extVia.locales.uiLangIso;
      
      var prodEditorPagetoolbarButtons =  [{itemId:'save'},{itemId:'export'},{itemId:'collectionAddTo'},{xtype:'splitbutton', itemId:'versioning-create'}] ;
      // >>> PROD V4 Start (EPIM-7678) <<<
      var prodEditorAppbar = extVia.ui.page.pagejob.getApplicationBar( { pgjobDscr: 'Produktpflege' , epobDscr: epob.dscr,    
        pgjobButtons: [  
          {
            xtype: 'buttongroup',
            itemId:'contentSwitcherBtnGrp',
            items:[
              {iconCls : 'xty_icon_'+uiLangIso, cls:'xty_language-chooser', itemId:'language',tooltip:'Sprache',height:22, width:22, scale: 'small',
                menu:{
                  items:[{
                    xtype:'boundlist', 
                    queryMode: 'local',
                    multiSelect : true,
                    displayField: 'dscr',
                    store: extVia.stores.initLanguageStore(),
                    listeners:{
                      itemclick: function( view, record, item, index, e, eOpts ){
                        var iso2 = record.get('iso2');         
                        this.ownerCt.floatParent.setIconCls('xty_icon_'+iso2);
                        this.ownerCt.floatParent.setTooltip(record.get('dscr'));
                        this.ownerCt.hide();
                        if (iso2==='de' || iso2==='en'|| iso2==='us' || iso2==='ro' ){
                         extVia.ui.page.raster.reloadPage('uiLangIso='+iso2);
                        }    
                      }
                    },
                    itemTpl : '<div style="width:100%;height:18px;padding-left:16px;" class="xty_icon_{iso2}"><span style="margin-top:-8px;">' + '&nbsp; {dscr}' + '</span></div>',
                    heidght:150}]
                }  
              }
            ]
           }
          ], pagetoolbarButtons: prodEditorPagetoolbarButtons, breadcrumb:'ACME/Elektrowerkzeuge/Akkuger&aumlte/Akku-Bohrschrauber' } );
          // >>> PROD V4 End (EPIM-7678) <<<
   
      var prodEditorPanel  = {title: epob.dscr, itemId:'editorPanel', closable:true, tbar: prodEditorAppbar,
        items:[prodEditorSubTabsPanelCfg  ] 
      };
      tabPanCenter.addAndActivate(prodEditorPanel);    

 
      

      
      
    }
});



/*
 * 
 * $Revision: 1.7.6.2 $
 * $Modtime: 18.07.17 09:39 $ 
 * $Date: 2019/12/11 07:30:26 $
 * $Author: lowen $
 * $viaMEDICI Release: 4.1 $
 * 
 */ 
