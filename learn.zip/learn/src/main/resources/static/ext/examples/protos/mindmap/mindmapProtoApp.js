/*


*/
Ext.application({
    name: 'mindmap App',
    
    /**
     * Place 
     */
    appMode:{},

    
    launch: function() {
		Ext.util.CSS.createStyleSheet('.xty-mindmap-leaf button{border:0px; font-size:0.9em;background:none;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-leaf button:hover{color:#287DC7;cursor:move;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-root button{color:white;border:0px;padding:7px;font-size:1.3em;background:none;cursor:move;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-root-split-right{background: transparent no-repeat right center;background-color:#287DC7;box-shadow: 3px 3px 5px 0px rgba(0,0,0,0.75);padding: 7px;background-image: url(s-collapse.gif);padding-right: 14px !important;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-root-split-right:hover{background-color:#67B3F5;cursor:pointer;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-node button{font-size:1.0em;border:0px;background:none;padding:7px;cursor:move;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-node-split-right{background: transparent no-repeat right center;background-color:#E6E6E6;box-shadow: 3px 3px 5px 0px rgba(0,0,0,0.75);padding: 7px;background-image: url(s-collapse.gif);padding-right: 14px !important;}');
		Ext.util.CSS.createStyleSheet('.xty-mindmap-node-split-right:hover{background-color:#EDEDED;cursor:pointer;}');
    	
    	Ext.state.Manager.setProvider(new Ext.state.CookieProvider({
    	    expires: new Date(new Date().getTime()+(1000*60*60*24*7)) //7 days from now
    	}));
    	extVia.regApp = this;
    	//this.appMode = extVia.app.setup.appMode; // preconfigured obj Url on javaside
    	var  modulDscr = 'Mindmap';
    	var viewCfg = {hideNorth:false,hideWest:false, showEast:false, showSouth:false};
    	extVia.ui.page.raster = new extVia.ui.page.BaseRaster({viewCfgFromUrl:true, modulDscXXr:modulDscr});
    	extVia.ui.page.raster.onReady(this);
      
       var treeStores = extVia.stores.initTreeStores();

       
        // Need some west?  
       var westPan = extVia.regApp.myRaster.getWest();
       if (westPan){
        //westPan. collapse();
       }
       
      var eastPan = extVia.regApp.myRaster.getEast();
      if (eastPan){
        eastPan. collapse();
      }
     
      
    	var westTabPan = extVia.regApp.myRaster.initWestTabPanel({
              items:[
                 extVia.hierarchy.statics.getHierarchyTabCfg({}) 
               ] 
              });
    	extVia.regApp.myRaster.addToWest(westTabPan);

    	
        var centerPan = extVia.ui.page.raster.getCenter();
		var centerWidth = centerPan.getWidth()-50;
        var centerHeight = centerPan.getHeight()-138;

      
    	var centerTabPan = extVia.regApp.myRaster.initCenterTabPanel({
			moduleCfg: {
			title: '',
			pgjobDscr: 'Mindmap App Settings',   
            tbar:{
	            defaults:{
	               enableToggle:true
	            },
	            items:[
	              { scale:'large',enableToggle:true, iconCls:'xty_pgtoolbar-subPanelList',  tooltip:  'Preferences',
                
                   menu:{
                   defaults:{
                      handler: function(item){                                    
                       window.open(item.url,"newwindow"); 
                      }
                   },
     
                   items:[
                   {text:'mindmup', url:'https://www.mindmup.com/#m:a1333f2b10212f0132790312f982e2670b'},
                   {text : 'Hierarhien als Mindmup', url: 'https://www.mindmup.com/#m:a1535bba702a1201322d0c16e3a69dd419'},
                   {text:'mindmup', url:' https://www.mindmup.com/#m:a17588db5021fd0132177452ccee387ac8'},
                  
                   
                   {text:'mindmeister', url:'http://www.mindmeister.com/de/demo/455632208'}
                   
                   ]}
                
                } 
	            ]
            },
            style:'width:100%; height:100%;',
            border:false,
            html:'<div id="minmapFake-bin" style="width:'+centerWidth+'px;"><img width="1000" src="./defaultMindmap.png"/></div>',
			showTabItem: true
			}
		   });
       
       
    	extVia.regApp.myRaster.addToCenter(centerTabPan);
    	

    },
    
    draculaMindmap : null,
    
    arborMindmap : null,
    
    hyperTree :null,
    
    extjsMindmap : null,
    
    mindmapPanel : null,
    
    currentMindmap : null,
    
    showMindmap : function (id) {
    	var me =this;
    	if(id === "arbor") {
    		me.mindmapPanel.removeAll();
    		me.mindmapPanel.add(me.arborMindmap);
    	} else if(id === "dracula") {
    		me.mindmapPanel.removeAll();
    		me.mindmapPanel.add(me.draculaMindmap);
    	}else if(id === "hypertree") {
    		me.mindmapPanel.removeAll();
    		me.mindmapPanel.add(me.hyperTree);
    	}else if(id === "extjs") {
    		me.mindmapPanel.removeAll();
    		me.mindmapPanel.add(me.extjsMindmap);
    		me.extjsMindmap.draw();
    	}
    },
    
    createExtjsMindmap : function(node) {
    	var mindmap = new extVia.component.Mindmap({
    		border : false,
      		itemId: 'extjsMindmap',
    		width: 2000,
    		height: 1500,
    	});
    	this.extjsMindmap = new Ext.panel.Panel({
    		items : [mindmap],
			width: 1515,
			height: 784,
			border : false,
			autoScroll: true,
			draw : function() {
				mindmap.draw();
			},
			setRoot : function(node) {
				mindmap.setRoot(node);
			}
    	});
    	this.extjsMindmap.setRoot(node);
    },
    
    createHyperTree : function(node) {
    	this.hyperTree = new Ext.panel.Panel({
    		itemId: 'hyperTree',
    		border : false,
    		divId : null,
    		width: 1515,
    		height: 766,
    		root: node,
    		setRoot: function(node) {
    			this.root = node;
    		},
    		listeners : {
				afterrender : function(me) {
					me.draw();
				},
				beforerender : function(me) {
					me.divId = Ext.id();
					me.html = '<div id="'+me.divId+'"></div>';
				}
			},
			
		    copyChildren : function(copy, node) {
		    	var me = this;
		    	me.html = '<div id="'+me.divId+'"></div>';
		    	var copyChild = {
		        		id : node.id,
		        		name : node.data.text,
		        		children:[]
		        };
		    	node.childNodes.forEach(function(child) {
		    		me.copyChildren(copyChild, child);
		    	});
		    	copy.children.push(copyChild);
		    },
			
			draw : function() {
				var me = this;
				var hypertree = new $jit.Hypertree({
					injectInto : me.divId,
					width : me.width,
					height: me.height,
					Node : {
						dim: 9,
						color: '#f00'
					},
					Edge : {
						 lineWidth: 2,
				         color: "#088"
					},
					onCreateLabel: function(domElement, node){
				          domElement.innerHTML = node.name;
				          $jit.util.addEvent(domElement, 'click', function () {
				        	  hypertree.onClick(node.id, {
				                  onComplete: function() {
				                	  hypertree.controller.onComplete();
				                  }
				              });
				          });
				      },
				      
				      onPlaceLabel: function(domElement, node){
				          var style = domElement.style;
				          style.display = '';
				          style.cursor = 'pointer';
				          if (node._depth <= 1) {
				              style.fontSize = "0.8em";
				              style.color = "#000";

				          } else if(node._depth == 2){
				              style.fontSize = "0.7em";
				              style.color = "#222";

				          } else {
				              style.display = 'none';
				          }

				          var left = parseInt(style.left);
				          var w = domElement.offsetWidth;
				          style.left = (left - w / 2) + 'px';
				      },
				      
				      onComplete: function(){
				          var node = hypertree.graph.getClosestNodeToOrigin("current");
				          var html = "<h4>" + node.name + "</h4><b>Connections:</b>";
				          html += "<ul>";
				          node.eachAdjacency(function(adj){
				              var child = adj.nodeTo;
				              if (child.data) {
				                  var rel = (child.data.band == node.name) ? child.data.relation : node.data.relation;
				                  html += "<li>" + child.name + " " + "<div class=\"relation\">(relation: " + rel + ")</div></li>";
				              }
				          });
				          html += "</ul>";
				         // $jit.id('inner-details').innerHTML = html;
				      }
				});
				

		    	var json = {
					id: me.root.id,
					name: me.root.data.text,
					children:[]
		    	};

		    	me.root.childNodes.forEach(function(child) {
		    		me.copyChildren(json, child);
		    	});
		    	
		    	console.log(json);
		    	
		    	hypertree.loadJSON(json);
		    	hypertree.refresh();
		    	hypertree.controller.onComplete();
			}
    	});
    	

    },

    
    createArborMindmap : function(node) {
    	this.arborMindmap =  new extVia.component.ArborMindmap({
      		border : false,
      		itemId: 'arborMindmap',
    		width: 1515,
    		height: 766,
    		root: node
    	});
    },
   
    
    createDraculaMindmap : function(node) {
    	this.draculaMindmap =  new Ext.panel.Panel({
			itemId: 'dracualMindmap',
			border: false,
			canvasId : null,
			graph : new Graph(),
			width: 1515,
			height: 766,
			nodeRenderer : function(r, n) {
				var me = this;
				var text = (n.label || n.id);
				var rect = r.rect(n.point[0]-30, n.point[1]-13, (text.length * 7.5), 35);
				rect.attr({"fill": text === node.data.text ? '#2E9AFE' : "#E0E0E0", r : "12px", "stroke-width" : "1px", "cursor" : "pointer" });
	            var set = r.set().push(
	            		rect
	                ).push(
	                	r.text(n.point[0] + (text.length < 14 ? (text.length * 0.5) : (text.length * 2)), n.point[1] + 5, text).attr({"font-weight": 700, "font-size" : "10px", "cursor" : "pointer"})
	                );
	            return set;
	        },
			root : node,
			draw : function() {
				var me = this;
				var root = me.root;
				var text = root.data.text;
				me.graph.addNode(text, {render:me.nodeRenderer});
				root.eachChild(function(child) {
					me.addChildToMap(text, child)
				});
				
				var layouter = new Graph.Layout.Spring(me.graph);
				var renderer = new Graph.Renderer.Raphael(me.canvasId, me.graph, me.getWidth(), me.getHeight());
			    layouter.layout();
		        renderer.draw();
			},
			addChildToMap : function(parentText, node) {
				var me = this;
				var text = node.data.text;
				me.graph.addNode(text, {render:me.nodeRenderer});
				me.graph.addEdge(parentText, text);
				node.eachChild(function(child) {
					me.addChildToMap(text, child);
				});
			},
			listeners : {
				afterrender : function(me) {
					me.draw();
				},
				beforerender : function(me) {
					me.canvasId = Ext.id();
					me.html = '<div id="'+me.canvasId+'"></div>';
				}
			},
			setRoot : function(node) {
				this.root = node;
			}
		});
    },
    
    showExplorerPanel: function(cfg, epob) {
		var me = this;
		
		if(!me.draculaMindmap) {
			me.createDraculaMindmap(cfg.record);
		}
		if(!me.arborMindmap) {
			me.createArborMindmap(cfg.record);
		}
		if(!me.hyperTree) {
			me.createHyperTree(cfg.record);
		}
		if(!me.extjsMindmap) {
			me.createExtjsMindmap(cfg.record);
		}
    	
		if(!me.mindmapPanel) {
			var pagejobButtons = [{
				 scale : 'large',
				 itemId: 'mindmap',
			menu : {
					 items: [{
						 text : 'Arbor.js',
						 handler : function() {
							 me.showMindmap('arbor');
							 me.currentMindmap = 'arbor';
						 }
					 }, {
					 	 text : 'Dracula.js',
					 	 handler : function() {
					 		 me.showMindmap('dracula');
					 		 me.currentMindmap = 'dracula';
					 	 }
					 }, {
						 text : 'Jit.js',
						 handler : function() {
							 me.showMindmap('hypertree');
							 me.currentMindmap ='hypertree';
						 }
					 }, {
						 text : 'Extjs Mindmap',
						 handler : function() {
							 me.showMindmap('extjs');
							 me.currentMindmap = 'extjs';
						 }
					 }]
				   }
			}];
			var pagetoolbarButtons = null; //[{itemId:'minmap'},{itemId:'list'},{itemId:'thumbsBig'},{itemId:'thumbsSmall'}]; 
      
			var epobDscr = 'some epob.dscr';
			if (epob){epobDscr = epob.dscr;}
      
			var appbar = extVia.ui.page.pagejob.getApplicationBar({
				  pgjobDscr: "Mindmap",
				  epobDscr:epobDscr,
				  pagetoolbarButtons: null,
				  pgjobButtons: pagejobButtons 
			});
			
			me.mindmapPanel =  new Ext.panel.Panel({
				closable :true,
				itemId: 'mindmapPanel',
				title: 'Mindmap Examples',
				bubbleEvents: ['click'],
				tbar: appbar,
				border: false
			});
		}
     
		
		
		if(me.currentMindmap === 'arbor') {
			me.arborMindmap.setRoot(cfg.record);
			me.arborMindmap.draw();
		} else if(me.currentMindmap === 'dracula') {
			me.draculaMindmap.setRoot(cfg.record);
			me.draculaMindmap.draw();
		}else if(me.currentMindmap === 'hypertree') {
			me.hyperTree.setRoot(cfg.record);
			me.hyperTree.draw();
		} else if(me.currentMindmap === 'extjs') {
			me.extjsMindmap.setRoot(cfg.record);
			me.extjsMindmap.draw();
		}
		var mindmapPanel = extVia.regApp.myRaster.getCenterTabPanel().addAndActivate(me.mindmapPanel);
    }
});



/*
 * 
 * $Revision: 1.10 $
 * $Modtime: 10.10.12 12:39 $ 
 * $Date: 2015/11/16 15:53:02 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 
