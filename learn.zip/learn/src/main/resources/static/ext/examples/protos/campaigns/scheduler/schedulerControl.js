Ext.namespace('extVia.campaigns.scheduler.control');


extVia.campaigns.scheduler.control = function(config) {
  Ext.apply(this, config, {
    id : "extVia.campaigns.scheduler.control",
    name : "extVia.campaigns.scheduler.control"
  });
};

extVia.campaigns.scheduler.control.prototype = {

  generateStartDate : function generateStartDate() {
    return new Date();
  },

  /**
   * 
   * @param weeks
   * @returns
   */
  generateEndDate : function generateEndDate(weeks) {
    var startDate = this.generateStartDate();
    var endDate = Sch.util.Date.add(startDate, Sch.util.Date.WEEK, weeks);

    return endDate;
  },
  
  
  /**
   * 
   * @param event
   * Return Elapsed time from Project or String if projekt didn't started
   */
  getElapsedTime : function getElapsedTime(event){
  	if(event){
  	  var date = new Date();	
//  	  var delta = Date.parse(event.data.EndDate) - Date.parse(event.data.StartDate);
  //		var days = parseInt(delta / 86400000);
  		var deltaFGrad = Date.parse(date) - Date.parse(event.data.StartDate);
  		var daysFgrad = parseInt(deltaFGrad / 86400000);
	  	if(daysFgrad==1){
	        return daysFgrad+' Tag';
	    }else if(daysFgrad<0){
	        return 'Projekt noch nicht angefangen';
	    }else{
	        return daysFgrad+' Tage';
	    }
  	}else{
  		return 'Es ist kein Projekt vorhanden';
  	}
  },
  
  
  /**
   * 
   * @param id
   * @param eventStore
   * remove all events by id from eventStore
   */
  removeEvents : function removeEvents(id, eventStore){
  
  	for(var i=0; i<eventStore.data.items.length; i++){
  		if(eventStore.data.items[i].get("ResourceId")==id){
  			eventStore.remove(eventStore.data.items[i]);
  		}
  	};
  	eventStore.sync();
  },
 

  /**
   * 
   * @param campaign
   * @param resource
   * @param meta
   * @param row
   * Colors milestones and display names for events
   */
  getEventRenderer : function getEventRenderer(campaign, resource, meta, row) {

    // Add a custom CSS class to the event element
    if (campaign.get('Type') === 'Milestone') {
      var color = campaign.get('Style');
      if (color === "") {
        color = "gold";
      }
      meta.cls = 'milestone-diamond-' + color;

    } else {
      var style = campaign.get('Style');
      meta.cls = 'normalEvent';
      meta.style = "background-color: #" + style;

     // if (campaign.data.ResourceId === 1 || campaign.data.ResourceId === 3 || campaign.data.ResourceId === 4
      //    || campaign.data.ResourceId === 6) {
        return campaign.data.Name;
     // }

    }

    // if (resource.data.leaf) {
    //
    // var d1 = 0;
    // d1 = Math.round(( meta.end - meta.start ) / 86400000);
    // var t1 = 'Tag';
    // if (d1 > 1) {
    // t1 = 'Tage';
    // }
    // return campaign.data.Name + ' [' + d1 + ' ' + t1 + ']';
    //
    // } else {
    //
    // var d2 = 0;
    // d2 = Math.round(( meta.end - meta.start ) / 86400000);
    // var t2 = 'Tag';
    // if (d2 > 1) {
    // t2 = 'Tage';
    // }
    // return campaign.data.Name + ' [' + d2 + ' ' + t2 + ']';
    // }

  },

  /**
   * 
   * @returns {view preset}
   */
  getYearMonthWeek : function getYearMonthWeek() {

    // http://bryntum.com/docs/#!/api/Sch.preset.ViewPresetHeaderRow-cfg-dateFormat
    // http://www.bryntum.com/docs/#!/api/Sch.preset.ViewPreset-cfg-timeResolution

    var yearMonthWeek = {

      displayDateFormat : 'Y-m-d',
      shiftIncrement : 1,
      shiftUnit : "DAY",
      timeColumnWidth : 90,
      timeResolution : {
        unit : "DAY",
        increment : 1
      },
      headerConfig : {
        bottom : {
          unit : "WEEK",
          // dateFormat : 'W'
          renderer : function(start, end, cfg) {
            var kw = Ext.Date.getWeekOfYear(start);
            var kWoche = 'KW' + kw;

            return kWoche;
            // Ext.String.format('FQ{0} {1}', fiscalQuarter, start.getFullYear() + (fiscalQuarter === 1 ? 1 : 0));
          }
        },
        middle : {
          unit : "MONTH",
          // dateFormat : 'F'
          renderer : function(start, end, cfg, nr) {
            var monate = [ 'Januar', 'Februar', 'M&auml;rz', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September',
                          'Oktober', 'November', 'Dezember' ];

            var mNr = start.getMonth();
            var mAndYear = monate[mNr] + ' ' + start.getFullYear();

            return mAndYear;
            // Ext.String.format('FQ{0} {1}', fiscalQuarter, start.getFullYear() + (fiscalQuarter === 1 ? 1 : 0));
          }
        }
      
//       ,top : { unit : "YEAR", cellGenerator : function(viewStart, viewEnd) { var cells = []; return [{ start :
//       viewStart, end : viewEnd, header : 'Jahr ' + (viewStart.getFullYear()) }]; } }
       
      }
    };

    return yearMonthWeek;
  },
  
 
//  addListenerColorfield : function addListenerColorfield(win){
//  		var colorWin = Ext.getCmp(win.getId()); 
//  		var display = colorWin.items.items[0].items.items[5].items.items[1].getId();
//  		var trigger = colorWin.items.items[0].items.items[5].items.items[3].getId();
//  		Ext.get(display).addListener("click", function(e, htmlButtEl) {
//		      Ext.getCmp(trigger).onTriggerClick();
//		    });
//  	},

	getColorfieldMlst : function getColorfieldMlst(eventConfig, width){
	
			var colorFieldMlst = Ext.create('Ext.container.Container', {
		      width : 230,
		      itemId : 'colorFieldMlstId',
		      layout : {
		        type : 'hbox'
		      },
		      margin : '0 0 5 0',
		      items : [ {
		        xtype : 'label',
		        // forId: '',
		        text : 'Symbol:',
		        width : 105
		      }, {
		        xtype : 'button',
		        text : eventConfig.mlstColor ? 'Chosen: ' + eventConfig.mlstColor : 'Symbol w&auml;hlen',
		        iconCls : 'milestone-' + eventConfig.mlstColor,
		        width : width,
		        height : 23,
		        disabled : false,
		        menu : Ext.create('Ext.menu.Menu', { // COMBOBOX statt menu???
		          width : 128,
		          defaults : {
		            handler : function(item, browEvnt) {
		              var color = item.iconCls;
		              color = color.split('-');
		              eventConfig.mlstColor = color[1];
		              this.ownerCt.ownerButton.setIconCls(item.iconCls);
		              this.ownerCt.ownerButton.setText('Chosed: ' + color[1]);
		            }
		          },
		          items : [ {
		            iconCls : 'milestone-red',
		            text : 'red'
		          }, {
		            iconCls : 'milestone-gold',
		            text : 'gold'
		          }, {
		            iconCls : 'milestone-blue',
		            text : 'blue'
		          }, {
		            iconCls : 'milestone-green',
		            text : 'green'
		          }, {
		            iconCls : 'milestone-orange',
		            text : 'orange'
		          }, {
		            iconCls : 'milestone-purple',
		            text : 'purple'
		          } ]
		        })
		      } ]
		    });
		return colorFieldMlst;
	},
	getMilestoneConfig : function getMilestoneConfig(eventConfig, colorFieldMlst){
	
			var milenstoneField = Ext.create('Ext.form.FieldSet', {
		          //xtype : 'fieldset',
		          title : 'Milestone: '+eventConfig.mlstName,
		          collapsible : true,
		          // collapsed : eventConfig.milestone ? false : true,
		          fieldDefaults : {
		            msgTarget : 'side',
		            labelWidth : 70
		          },
		          defaults : {
		            anchor : '100%'
		          },
		          items : [ {
		            xtype : 'textfield',
		            itemId : 'mlstNamefieldId',
		            name : 'name',
		            fieldLabel : 'Name * ',
		            allowBlank : false,
		            maxLength : 100,
		            value : eventConfig.mlstName,
		            listeners : {
		              blur : function(field, browserEv) {
		                eventConfig.mlstName = field.getValue();
		              }
		            }
		          }, {
		            xtype : 'datefield',
		            fieldLabel : 'Date * ',
		            allowBlank : false,
		            itemId : 'mlstDatefieldId',
		            name : 'date',
		            format : 'd-m-Y',
		            minValue : eventConfig.startD,
		            value : eventConfig.mlstDate, // ? eventConfig.mlstDate : eventConfig.startD,
		            listeners : {
		              change : function(field, browserEv) {
		                eventConfig.mlstDate = field.getValue();
		              }
		            }
		          },
		
		          colorFieldMlst,
		
		          {
		            xtype : 'textareafield',
		            itemId : 'mlstDscrfieldId',
		            grow : false,
		            name : 'dscr',
		            height : 50,
		            fieldLabel : 'Description',
		            value : eventConfig.mlstDscr,
		            listeners : {
		              blur : function(field, browserEv) {
		                eventConfig.mlstDscr = field.getValue();
		              }
		            }
		          } ]
		        });
		        return milenstoneField;
			
	},
	
	
	addEditMilestones : function addEditMilestones(eventConfigArr, editEventWin){
		var milenstoneField;
	  	var colorFieldMlst;
		for (var i = 0; i<eventConfigArr.length; i++){
		      colorFieldMlst = extVia.campaigns.scheduler.control.getColorfieldMlst(eventConfigArr[i], 220);
	  		  milenstoneField= extVia.campaigns.scheduler.control.getMilestoneConfig(eventConfigArr[i], colorFieldMlst);
	  		  editEventWin.items.items[0].items.items[0].add(milenstoneField);
	    }
  	},
  	
  	addMilestone : function addMilestone(eventConfigArr, editEventWin){
		var milenstoneField;
	  	var colorFieldMlst;
		colorFieldMlst = extVia.campaigns.scheduler.control.getColorfieldMlst(eventConfigArr[eventConfigArr.length-1], 220);
		milenstoneField= extVia.campaigns.scheduler.control.getMilestoneConfig(eventConfigArr[eventConfigArr.length-1], colorFieldMlst);
		editEventWin.items.items[0].items.items[0].add(milenstoneField);
  	},
  	
  	
  /**
   * 
   * @returns {edit dialog}
   */
  getEventEditDialog : function getEventEditDialog(event) {
    var eventStore = event.store;
    var resId = event.get('ResourceId');
    var eventStart = event.get('StartDate');
    var eventEnd = event.get('EndDate');
    var mlst = null;
    var mlstArr = [];
    var eventConfigArr = [];
	
    eventStore.findBy(function(record) {
     var eventConfigTemp;
      if (resId === record.get('ResourceId') && record.get('Type') === 'Milestone' && record.get('StartDate') >= eventStart && record.get('StartDate')<= eventEnd) {
        mlstArr.push(record);
        eventConfigTemp = {
		      name : event.get('Name'),
		      startD : event.get('StartDate'),
		      endD : event.get('EndDate'),
		      color : event.get('Style'),
		      milestone : record ? true : false,
		      mlstName : record ? record.get('Name') : 'TestMilenstone',
		      mlstDate : record ? record.get('StartDate') : event.get('StartDate'),
		      mlstColor : record ? record.get('Style') : '',
		      mlstDscr : record ? record.get('Dscr') : ''
		    };
		 eventConfigArr.push(eventConfigTemp);  
      }
    });

    var eventConfig = {
      name : event.get('Name'),
      startD : event.get('StartDate'),
      endD : event.get('EndDate'),
      color : event.get('Style'),
      milestone : mlst ? true : false,
      mlstName : mlst ? mlst.get('Name') : 'TestMilenstone',
      mlstDate : mlst ? mlst.get('StartDate') : event.get('StartDate'),
      mlstColor : mlst ? mlst.get('Style') : '',
      mlstDscr : mlst ? mlst.get('Dscr') : ''
    };


    var startDate = this.generateStartDate();
    
    var editEventWin = null;
    editEventWin = Ext.create('Ext.window.Window', {
      maxHeight : 440,
      width : 385,
      maxWidth : 385,
      autoHeight : true,
      title : 'Projekt bearbeiten',
      closable : true,
      plain : true,
      autoScroll: true,
      // layout : 'fit',
      items : [ {
        border : false,
        minHeight : 200,
        bodyStyle : 'padding:5px 5px 0',
        fieldDefaults : {
        // msgTarget : 'side',
        },
        defaults : {
          // anchor : '100%',
          labelWidth : 110,
          width : 350
        },
        items : [ {
            border : false,
            minHeight : 200,
            
            itemId:'myFormPanel',
            xtype:'form',
            
            dirtyAndValiditychange:function( basic, dirty, valid, eOpts){	
        		var dialogButtons = this.ownerCt.ownerCt.getComponent('myButtons');

        		var activate = dirty ;
        		if (!valid) activate = false;
        		
				if (activate) dialogButtons.getComponent('apply').enable();
                else dialogButtons.getComponent('apply').disable();
        		if (activate) dialogButtons.getComponent('ok').enable();
        		else dialogButtons.getComponent('ok').disable();
	
        	},
  
            listeners:{
            	
            	validitychange:function( basic, valid, eOpts ){
            		this.dirtyAndValiditychange( basic, this.getForm().isDirty(), valid, eOpts );	
            	},	
            	dirtychange:function( basic, dirty, eOpts){
            		this.dirtyAndValiditychange( basic, dirty, this.getForm().isValid(), eOpts );	
            	},	
            	
            	dirtychangeOLD:function( basic, dirty, eOpts){	
            		var dialogButtons = this.ownerCt.ownerCt.getComponent('myButtons');
      
            		
            		var activate = dirty ;
            		
            		if (!this.getForm().isValid()) activate = false;
            		
            		
            		if (activate) dialogButtons.getComponent('apply').enable();
            		else dialogButtons.getComponent('apply').disable();
            		if (activate) dialogButtons.getComponent('ok').enable();
            		else dialogButtons.getComponent('ok').disable();
            		
            		
            	}
             },

            
            fieldDefaults : {
            // msgTarget : 'side',
            },
            defaults : {
               style : 'margin:0px 10px 4px 14px;',
               anchor : '100%',
               labelWidth : 130,
               width : 350
            },
        items : [ {
          border : false,
          bodyStyle : 'padding:0px 0px 10px 0px',
          html:'<div class="xty_dialog-mainInstr">Bearbeiten Sie den <i>Projekt: </i><i style="font-weight:normal">'+event.get('Name')+'</i></div>'   
        }, {
          border : false,
          bodyStyle : 'padding:0px 0px 15px 0px',
          html : '<div class="xty_dialog-supplementalInstr">Optional k&ouml;nnen Sie Milesteine hinzuf&uuml;gen</div>'
        }, {
          xtype : 'textfield',
          itemId : 'evntNameId',
          fieldLabel : 'Name * ',
          // id: 'testtestId',
          name : 'name',
          value : eventConfig.name,
          allowBlank : false,
          listeners : {
            blur : function(field, browserEv) {
              eventConfig.name = field.getValue();
            }
          }
        }, {
          xtype : 'datefield',
          fieldLabel : 'Start Date * ',
          allowBlank : false,
          itemId : 'evntStartDateId',
          name : 'from_date',
          value : eventConfig.startD,
          // emptyText : '',
          format : 'd-m-Y',
          minValue : startDate,
          listeners : {
            change : function(field, browserEv) {
              eventConfig.startD = field.getValue();
            }
          }
        }, {
          xtype : 'datefield',
          fieldLabel : 'End Date * ',
          allowBlank : false,
          itemId : 'evntEndDateId',
          value : eventConfig.endD,
          name : 'to_date',
          format : 'd-m-Y',
          maxValue : Sch.util.Date.add(startDate, Sch.util.Date.WEEK, 20),
          listeners : {
            change : function(field, browserEv) {
              eventConfig.endD = field.getValue();
            }
          }
        },
        // colorField,
        
        {
          xtype : 'colorfield',
          // fieldLabel : 'text',
          value : eventConfig.color, // ABCDEF or Numbers (3 or 9) without '#'
          fieldLabel: 'Farbe',
    	  name: 'color',
          itemId : 'colorfieldId'
        }, {
          xtype : 'button',
          icon : '../img/icons/add_16.png',
          //text : 'Add',
          margin: '5 0 0 325',
          width : 22,
          height : 22,
          handler: function() {
  		  		var eventConfigMilenstone = {
  				      name : event.get('Name'),
  				      startD : event.get('StartDate'),
  				      endD : event.get('EndDate'),
  				      color : event.get('Style'),
  				      milestone : mlst ? true : false,
  				      mlstName : mlst ? mlst.get('Name') : 'TestMilenstone',
  				      mlstDate : mlst ? mlst.get('StartDate') : event.get('StartDate'),
  				      mlstColor : mlst ? mlst.get('Style') : '',
  				      mlstDscr : mlst ? mlst.get('Dscr') : ''
  				    };
  		  		 eventConfigArr.push(eventConfigMilenstone);
  		  		 var milestone = {
                             ResourceId : event.get('ResourceId'),
                             Name : eventConfig.mlstName,
                             StartDate : eventConfigArr[eventConfigArr.length-1].mlstDate,
                             EndDate : eventConfigArr[eventConfigArr.length-1].mlstDate,
                             Style : eventConfigArr[eventConfigArr.length-1].mlstColor ? eventConfigArr[eventConfigArr.length-1].mlstColor : 'blue',
                             Dscr : eventConfigArr[eventConfigArr.length-1].mlstDscr,
                             Resizable : false,
                             Type : 'Milestone'
                           };
  		  		 eventStore.add(milestone);  
  		  		 mlstArr.push(eventStore.getAt(eventStore.getCount()-1));     
  		       extVia.campaigns.scheduler.control.addMilestone(eventConfigArr, editEventWin);
  		       eventStore.sync();
  		   }
        
        }
        
     

        ]
      } ]
      }],
      // tbar:[{text:"Bitte geben Sie ..."}],
      buttons:{itemId:'myButtons', items:[
                 {
                   text : 'OK',
                   itemId:'ok',
                   disabled:true,
                   tooltip : 'Save and close',
                   handler : function() {

                     // var fields, endDate, name, startDate;
                     var fieldsOwner = this.ownerCt.ownerCt.items.items[0].items.items[0];

                     // name = fieldsOwner.getComponent('evntNameId').getValue();
                     // startDate = fieldsOwner.getComponent('evntStartDateId').getValue();
                     // endDate = fieldsOwner.getComponent('evntEndDateId').getValue();
                     // mStone = fieldsOwner.getComponent('mlstGroupId').getChecked()[0].milestone;
                     // dscr = fieldsOwner.getComponent('mlstDscrId').getValue();

                     if (eventConfig.mlstName !== '' && eventConfig.mlstDate !== '' && eventConfig.name !== ''
                         && eventConfig.startD !== '' && eventConfig.endD !== '') {

                       var color = fieldsOwner.getComponent('colorfieldId').getValue();
                       eventConfig.color = color.replace('#', '');

                       event.setName(eventConfig.name);
                       event.setStartDate(eventConfig.startD);
                       event.setEndDate(eventConfig.endD);
                       event.setStyle(eventConfig.color);

                    if (mlstArr !== null) {
	                       for(var i = 0;i<mlstArr.length; i++){
	                         mlstArr[i].setName(eventConfigArr[i].mlstName);
	                         mlstArr[i].setDscr(eventConfigArr[i].mlstDscr);
	                         mlstArr[i].setStyle(eventConfigArr[i].mlstColor ? eventConfigArr[i].mlstColor : 'blue');
	                         mlstArr[i].setStartDate(eventConfigArr[i].mlstDate);
	                         mlstArr[i].setEndDate(eventConfigArr[i].mlstDate);
	                         }
                       } /*else if (mlst === null) {
                         eventStore.add({
                           ResourceId : event.get('ResourceId'),
                           Name : eventConfig.mlstName,
                           StartDate : eventConfig.mlstDate,
                           EndDate : eventConfig.mlstDate,
                           Style : eventConfig.mlstColor ? eventConfig.mlstColor : 'blue',
                           Dscr : eventConfig.mlstDscr,
                           Resizable : false,
                           Type : 'Milestone'
                         });
                       }*/
						eventStore.sync();
						this.ownerCt.ownerCt.close();
                     }
                     // setDirty
                     // setDraggable
                     // setResizable
                     // setResource
                     // setResourceId
                     // setType
                   }
                 }, {
                   text : 'Abbrechen',
                   handler : function() {
                     this.ownerCt.ownerCt.close();
                   }
                 }, {
                   text : '&Uuml;bernehmen',
                   itemId:'apply',
                   disabled:true,
                   tooltip : 'Save',
                   handler : function() {
                     var fieldsOwner = this.ownerCt.ownerCt.items.items[0].items.items[0];

                     if (eventConfig.mlstName !== '' && eventConfig.mlstDate !== '' && eventConfig.name !== ''
                         && eventConfig.startD !== '' && eventConfig.endD !== '') {

                       var color = fieldsOwner.getComponent('colorfieldId').getValue();
                       eventConfig.color = color.replace('#', '');

                       event.setName(eventConfig.name);
                       event.setStartDate(eventConfig.startD);
                       event.setEndDate(eventConfig.endD);
                       event.setStyle(eventConfig.color);
					
                       if (mlstArr !== null) {
	                       for(var i = 0;i<mlstArr.length; i++){
	                         mlstArr[i].setName(eventConfigArr[i].mlstName);
	                         mlstArr[i].setDscr(eventConfigArr[i].mlstDscr);
	                         mlstArr[i].setStyle(eventConfigArr[i].mlstColor ? eventConfigArr[i].mlstColor : 'blue');
	                         mlstArr[i].setStartDate(eventConfigArr[i].mlstDate);
	                         mlstArr[i].setEndDate(eventConfigArr[i].mlstDate);
	                         }
                       } /*else if (mlst === null) {
                         eventStore.add({
                           ResourceId : event.get('ResourceId'),
                           Name : eventConfig.mlstName,
                           StartDate : eventConfig.mlstDate,
                           EndDate : eventConfig.mlstDate,
                           Style : eventConfig.mlstColor ? eventConfig.mlstColor : 'blue',
                           Dscr : eventConfig.mlstDscr,
                           Resizable : false,
                           Type : 'Milestone'
                         });
                       }*/

                     }
                     eventStore.sync();
                   }
                 }]
               }
    });
    extVia.campaigns.scheduler.control.addEditMilestones(eventConfigArr, editEventWin);
    return editEventWin.show();
  },

  /**
   * 
   * @remove child from localStorage
   */
   
  removefromLocalStorage : function removefromLocalStorage(child){
  
    var root = JSON.parse(localStorage.StoreJSBlob);
			  //localStorage.setItem("LoadetRoot", root);
			  
			  function search (parent){
				    if (parent.children.length>0){
				     for(var i = 0; i<parent.children.length; i++){
				     	if (child.data.Id==parent.children[i].Id){
							parent.children.splice(i,1);
				     		break;
				     	}else if(parent.children[i].leaf == true){
				     		continue;
				     	}else{
				     		search(parent.children[i]);
				     	}
				     }
				    }else{
				    	return false;
				    }
			  };
//	var node = search(root);
	localStorage.StoreJSBlob = JSON.stringify(root);
  
  },
   /**
   * 
   * @returns {scheduler listeners}
   */
  getSchedulerListeners : function getSchedulerListeners() {

    var listeners = {
	
	  'dragcreateend'	: function(scheduler, newEventRecord){

	  	if(newEventRecord.get('Type')==''){
	  		newEventRecord.set('Type','Event');
	  	}
	  },
	  
	  'afterdragcreate'	: function(scheduler){
	  	scheduler.eventStore.sync();
	  	
	  },
	  
	  'eventresizeend'	: function(scheduler){
	  	scheduler.eventStore.sync();
	  },
		
	  'aftereventdrop'	: function(scheduler){
	  	scheduler.eventStore.sync();
	  },
		
		
      'eventmouseenter' : function(view, eventRecord, e, eOpts) {
        if (eventRecord.get('Type') === 'Milestone') {
          var target = Ext.get(view.id + "-" + eventRecord.internalId);
          tip = Ext.create('Ext.tip.ToolTip', {
            target : target,
            // Each grid row
            delegate : view.itemSelector,
            trackMouse : false,
            listeners : {
              // Change content dynamically
              beforeshow : function updateTipBody(tip) {
                tip.update('<li><b>Name:</b> ' + eventRecord.get('Name') + '</li>' + '<li><b>Dscr:</b> '
                           + eventRecord.get('Dscr') + '</li>' + '<li><b>Date:</b> '
                           + Ext.Date.format(eventRecord.get('StartDate'), 'd-m-Y') + '</li>');
              }
            }
          });

        }
      },

      'scheduleclick' : function(scheduler, clickedDate, rowIndex, e, eOpts) {
        if (e.altKey === true) {
          extVia.campaigns.scheduler.view.createMilestoneDialogOnSchClick(scheduler, clickedDate, rowIndex);
        } else if (e.ctrlKey === true) {
        }
      },

      'itemcontextmenu' : function(view, record, itemSel, rowIndex, e, eOpts) {
        if (view.xtype === 'treeview') {

          e.stopEvent();
          var treeStore = view.getStore();

          if (Ext.getCmp('newTreeContextMenuId')) {
            Ext.getCmp('newTreeContextMenuId').close();
          }

          var treeCtxMenu = Ext.create('Ext.menu.Menu', {
            id : 'newTreeContextMenuId',
            width : 140,
            items : []
          });

          if (record.get('leaf') === false) {
            treeCtxMenu.add({
              text : 'Neu Kampagne',
              iconCls : '',
              handler : function() {
                extVia.campaigns.scheduler.view.addTreeNodeRightClick(view, record); //  editTreeNode
              }
            });
          }

          treeCtxMenu.add({
            text : 'Kampagne l&ouml;schen',
            iconCls : 'icon-delete',
            handler : function() {
	          Ext.Msg.confirm('Confirm',  'Are you sure you want to do that?', function(btn){
				      if (btn == 'yes'){
		              var children = record.get('children');
		              if (children !== null) {
		                for ( var q = 0; q < children.length; q++) {
		                  var child = treeStore.getById(children[q].Id);
		                  var childChildren = child.get('children');
		                  if (childChildren !== null) {
		                    for ( var p = 0; p < childChildren.length; p++) {
		                      var childChild = treeStore.getById(childChildren[p].Id);
		                      extVia.campaigns.scheduler.control.removefromLocalStorage(childChild);
		                      treeStore.remove(childChild);
		                      extVia.campaigns.scheduler.control.removeEvents(childChild.data.Id, view.store.eventStore);
		                    }
		                  }
		                  extVia.campaigns.scheduler.control.removefromLocalStorage(child);
		                  treeStore.remove(child);
		                  extVia.campaigns.scheduler.control.removeEvents(child.data.Id, view.store.eventStore);
		                }
		              }
		              extVia.campaigns.scheduler.control.removefromLocalStorage(record);
		              treeStore.remove(record);
		              extVia.campaigns.scheduler.control.removeEvents(record.data.Id, view.store.eventStore);
		            }
            	});
            }
          }, {
            text : 'Statistic anzeigen',
            handler : function() {
              var schedulerTabPanel = view.ownerCt.ownerCt.ownerCt.ownerCt;
              extVia.campaigns.statistics.main.addChartsToPanel(record, schedulerTabPanel);
            }
          }, {
            text : '&Uuml;bersicht anzeigen',
            handler : function() {
              // var schedulerTabPanel = view.ownerCt.ownerCt.ownerCt.ownerCt;
              extVia.campaigns.statistics.main.showEvents();
            }
          }, {
            text : 'Info',
            iconCls : '',
            handler : function() {
              var data = Ext.encode(record.data);
              var splittedData = data.split(",");

              Ext.Msg.alert('Info', splittedData[0] + ', ' + splittedData[1] + ', ' + splittedData[2] + ', '
                                    + splittedData[3] + ', ' + '\n' + splittedData[4] + ', ' + splittedData[5] + ', '
                                    + splittedData[6] + ', ' + splittedData[7] + ', ' + '\n' + splittedData[8] + ', '
                                    + splittedData[9] + splittedData[10] + ', ' + splittedData[11] + ', \n'
                                    + splittedData[12] + ', ' + splittedData[13] + ', ' + splittedData[14] + ', '
                                    + splittedData[15] + ', \n' + splittedData[16] + ', ' + splittedData[17] + ', '
                                    + splittedData[18] + ', ' + splittedData[19] + ', \n' + splittedData[20] + ', '
                                    + splittedData[21] + ', ' + splittedData[22] + ', ' + splittedData[23] + ', \n'
                                    + splittedData[24] + ', ' + splittedData[25] + ', ' + splittedData[26] + ', '
                                    + splittedData[27]);
            }
          });

          treeCtxMenu.showAt(e.getXY());
        }
      },

      'select' : function(model, record, eOpts) {
        if (record.$className === "Campaign") {
          var tbId = Ext.getCmp('panel_mC').down('toolbar').items.items[0].id;
          if (tbId && tbId !== null) {
            Ext.getCmp(tbId).getComponent('campaignText1').setText('Kampagne: ');
            Ext.getCmp(tbId).getComponent('campaignText2').setText(record.data.Name);

            var schedulerTabPanel = model.view.ownerCt.ownerCt.ownerCt.ownerCt;
            schedulerTabPanel.items.getAt(4).setDisabled(false);
            if (schedulerTabPanel.getTabBar().items.getAt(4).active) {
              extVia.campaigns.statistics.main.addChartsToPanel(record, schedulerTabPanel);
            }
          }
        }
      },

      'eventdblclick' : function(schedulerView, eventRecord, e, eOpts) {

        var schedulerTabPanel = schedulerView.ownerCt.ownerCt.ownerCt.ownerCt;
        schedulerTabPanel.getComponent('DetailsTabId').setDisabled(true);
        schedulerTabPanel.getComponent('StatistikTabId').setDisabled(true);
        var projektplanTab = schedulerTabPanel.getComponent('ProjektplanTabId');
        projektplanTab.removeAll();
        var tool = Ext.getCmp('mainToolbarId');
        tool.getComponent('mainSplitButton').show();
        tool.getComponent('editProjektButton').hide();
        tool.getComponent('newProjektButton').hide();
        tool.getComponent('deleteProjektButton').hide();
        var startDate = eventRecord.get('StartDate');
        var startDate2 = Sch.util.Date.add(startDate, Sch.util.Date.WEEK, 0);
        var endDate = eventRecord.get('EndDate');
        var endDate2 = Sch.util.Date.add(endDate, Sch.util.Date.WEEK, 2);
        var gantt = extVia.campaigns.projects.main.getProjectGantt(startDate2, endDate2);
        var taskStore = gantt.getTaskStore();
        extVia.campaigns.projects.main.addListenerToResizerGantt(schedulerTabPanel, gantt);
        var newTask = new taskStore.model({
          Name : eventRecord.get('Name'),
          leaf : false,
          PercentDone : 20,
          StartDate : startDate,
          EndDate : endDate,
          Duration : 15,
          expanded : true
        });

        var newTask2 = new taskStore.model({
          Name : 'Erfassung',
          PercentDone : 100,
          StartDate : startDate,
          EndDate : Sch.util.Date.add(endDate, Sch.util.Date.DAY, -20),
          Duration : 4,
          leaf : true
        });
        
        var newTask3 = new taskStore.model({
          Name : 'Layout',
          PercentDone : 10,
          StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 8),
          EndDate : Sch.util.Date.add(endDate, Sch.util.Date.DAY, -13),
          Duration : 4,
          leaf : true
        });
		
        var newTask4 = new taskStore.model({
          Name : 'Druckvorlagenerstellung',
          PercentDone : 0,
          StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 15),
          EndDate : Sch.util.Date.add(endDate, Sch.util.Date.DAY, -11),
          Duration : 4,
          leaf : true
        });
        var newTask5 = new taskStore.model({
          Name : 'Druck',
          PercentDone : 0,
          StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 17),
          EndDate : Sch.util.Date.add(endDate, Sch.util.Date.DAY, -7),
          Duration : 4,
          leaf : true
        });
        
        var newTask6 = new taskStore.model({
          Name : 'Versendung',
          PercentDone : 0,
          StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 21),
          EndDate : Sch.util.Date.add(endDate, Sch.util.Date.DAY, -4),
          Duration : 4,
          leaf : true
        });
        
        var newTask7 = new taskStore.model({
          Name : 'Digital Publishing',
          PercentDone : 0,
          StartDate : Sch.util.Date.add(startDate, Sch.util.Date.DAY, 24),
          EndDate : Sch.util.Date.add(endDate, Sch.util.Date.DAY, -0),
          Duration : 4,
          leaf : true
        });
        
        var child = new taskStore.model({
          Name : 'Abgabe',
          StartDate : startDate,
          EndDate : endDate,
          leaf : true,
          // Draggable: false,
          // PercentDone : 0,
          // Priority : 0,
          // Duration : 0,
          // Progress: 0,
          Milestone : true
        });

        // newTask.addSubtask(newTask2); //appendChild
        taskStore.getRootNode().appendChild(newTask);

        newTask.addSubtask(newTask2); // appendChild
        newTask.addSubtask(newTask3);
        newTask.addSubtask(newTask4);
        newTask.addSubtask(newTask5);
        newTask.addSubtask(newTask6);
        newTask.addSubtask(newTask7);
        newTask.addTaskBelow(child);
        // newTask2.setStartEndDate(newTask.getEndDate(), newTask.getEndDate());

        // removes red outline -> deselect of an event
        schedulerView.getSelectionModel().clearSelections();
        schedulerView.refresh();

        // gantt.getSchedulingView().setRowHeight(40);
        projektplanTab.add(gantt);
        projektplanTab.setDisabled(false);
        schedulerTabPanel.setActiveTab(1);
        var width = schedulerTabPanel.getTabBar().items.get(2).getWidth()+275;
        schedulerTabPanel.getTabBar().items.get(2).setWidth(width);

      },

      // deselect : function(schedulerView, eventRecord, e, eOpts) {},

      // Contextmenu with handler fn
      eventcontextmenu : function(ownerCt, event, contMenu, mouseevent) {

        contMenu.stopEvent();
//        var eventElId = ownerCt.id + '-' + event.internalId;
        var evStore = ownerCt.getEventStore();
        // var dataIndex = evStore.data.indexOfKey(event.internalId);

        if (Ext.getCmp('newContextMenuId')) {
          Ext.getCmp('newContextMenuId').close();
        }

        var cMenu = Ext.create('Ext.menu.Menu', {
          id : 'newContextMenuId',
          width : 140,
          items : []
        });

        var colorMenu = Ext.create('Ext.menu.ColorPicker', {
          handler : function(cm, color) { // select
            event.set('Style', '#' + color);

            // Ext.get(eventElId).dom.style.setProperty("background-color", '#'+color);
            // Ext.get(eventElId).applyStyles("background-color:#"+color);
            // Ext.get(eventElId).addCls('normalEvent2');
          }
        });

        if (event.get('Type') !== 'Milestone') {
          cMenu.add({
            text : 'Projekt bearbeiten',
            iconCls : '',
            handler : function() {
              var win = extVia.campaigns.scheduler.control.getEventEditDialog(event);
              //extVia.campaigns.scheduler.control.addListenerColorfield(win);
            }
          },
          // {
          // text : 'Change color',
          // iconCls : '',
          // menu : colorMenu
          // },
          // {
          // text : 'Add a Milestone',
          // iconCls : '',
          // handler : function() {
          // extVia.campaigns.scheduler.view.createMilestoneDialog(ownerCt.id, event.internalId);
          // }
          // },
          {
            text : 'Projekt l&ouml;schen',
            iconCls : 'icon-delete',
            handler : function() {
              evStore.remove(event);
              evStore.sync();
            }
          });
        }

        else if (event.get('Type') === 'Milestone') {
          cMenu.add({
            text : 'Meilenstein l&ouml;schen',
            iconCls : 'icon-delete',
            handler : function() {
              // evStore.removeAt(dataIndex);
              evStore.remove(event);
              evStore.sync();
            }
          });
        }

        cMenu.add({
              text : 'Info',
              iconCls : '',
              handler : function() {
//                var data = Ext.encode(event.data);
//                var splittedData = data.split(",");

                var retTitle = "<div title='Information' style='float:left;margin-top:1px;' class='xty_icon xty_iconInformation'></div>"
                               + "<span style='margin-left:6px;'>Projekt / Event Information</span>";
                
                var col = event.get('Style');
                if(col === ''){col = 'B5D8F2';}
                
                var EventInfoWin = Ext.create('widget.window', {
                  // height: 220,
                  width : 373,
//                  autoHeight : true,
                  title : retTitle,
                  plain : true,
                  items : [ {
                    border : false,
                    bodyStyle : 'padding:0px 5px 10px 10px',
                    items : [
                    // {
                    // border:false,
                    // bodyStyle:'padding:5px 5px 5px',
                    // html:'<div class="xty_dialog-mainInstr">{EpobtypPronoun} {Epobtyp} <span
                    // class="xty_dialog-mainInstr-epobDscr">{EpobDscr}</span> wurde ge�ndert</div>'
                    //         
                    // },
                     {
                       border : false,
                       //bodyStyle : 'padding:5px 5px 5px',
                       html : '<div class="xty_dialog-supplementalInstr">'+
                         '<table>'+
                           '<tr><td class="xty_dialog-tableLayout">Name:</td><td class="xty_dialog-tableLayout">' + event.get('Name') + '</td></tr>'+
                           '<tr><td class="xty_dialog-tableLayout">Start Date:</td><td class="xty_dialog-tableLayout">' + Ext.Date.format(event.get('StartDate'), 'd-m-Y') + '</td></tr>'+
                           '<tr><td class="xty_dialog-tableLayout">End Date:</td><td class="xty_dialog-tableLayout">'+ Ext.Date.format(event.get('EndDate'), 'd-m-Y') +'</td></tr>'+
                           '<tr><td class="xty_dialog-tableLayout">Color:</td><td class="xty_dialog-tableLayout">#' + col + '</td></tr>'+
                           '<tr><td class="xty_dialog-tableLayout">Resource Id:</td><td class="xty_dialog-tableLayout">'+ event.get('ResourceId') + '</td></tr>'+
                         '</table></div>'
                     }]
                  } ],
                  buttons : [ {
                    xtype : 'tbspacer',
                    width : 30
                  }, {
                    text : 'Ok',
                    handler: function(){
                      this.ownerCt.ownerCt.close();
                    }
                  } ]
                });
                EventInfoWin.show();

                // Ext.Msg.alert('Info', splittedData[0] + ', ' + splittedData[1] + ', ' + splittedData[2] + ', '
                // + splittedData[3] + ', ' + '\n' + splittedData[4] + ', ' + splittedData[5] + ', '
                // + splittedData[6] + ', ' + splittedData[7] + ', ' + '\n' + splittedData[8] + ', '
                // + splittedData[9]);
              }
            });

        cMenu.showAt(contMenu.getXY());
      }
    };

    return listeners;
  },

  /**
   * 
   * @param dragEventRecords
   * @param targetRowRecord
   * @param newStartDate
   * @param duration
   * @param e
   * @returns {Boolean}
   */
  getDndValidatorFn : function getDndValidatorFn(dragEventRecords, targetRowRecord, newStartDate, duration, e) {

    var a;
    var valid = false;
    // var eventArr = [];
    var schRowEvents = [];
    var minMaxDates = {};
    var eStore = targetRowRecord.getEventStore();

    for (a = 0; a < dragEventRecords.length; a++) {

      // wenn es eine andere Zeile ist
      if (dragEventRecords[a].get('ResourceId') !== targetRowRecord.internalId) { // targetRowRecord.get('Id')
        return false;
      }

      // wenn es die selbe Zeile ist und es kein "Milestone" ist
      else if (dragEventRecords[a].get('ResourceId') === targetRowRecord.internalId
               && dragEventRecords[a].get('Type') !== 'Milestone') {

        var newEndDate = new Date(newStartDate.getTime()
                                  + ( dragEventRecords[a].get('EndDate').getTime() - dragEventRecords[a].get(
                                      'StartDate').getTime() ));

        eStore
            .each(function(record, id) {
              if (record.get('ResourceId') === dragEventRecords[a].get('ResourceId')
                  && record.get('Type') !== 'Milestone') {
                schRowEvents.push({
                  event : record
                });
              }
            });

        if (schRowEvents.length === 1) {
          valid = true;
        }

        else if (schRowEvents.length > 1) {
          minMaxDates = this.getMinMaxDateValidator(schRowEvents, dragEventRecords[a].internalId);
          if (newStartDate.getTime() > minMaxDates.minValue.getTime()
              && newEndDate.getTime() < minMaxDates.maxValue.getTime()) {
            valid = true;
          }
        }
        return valid;
      }
    }

  },

  getResizeValidatorFn : function getResizeValidatorFn(resourceRecord, eventRecord, startDate, endDate) {
    var sRowEvents = [];
    var minMaxDates = {};
    var valid = false;
    var eStore = resourceRecord.getEventStore();

    // Alle Events (ausser Milestones) der Zeile in ein Array packen
    eStore.each(function(record, id) {
      if (record.get('ResourceId') === eventRecord.get('ResourceId') && record.get('Type') !== 'Milestone') {
        sRowEvents.push({
          event : record
        });
      }
    });

    if (sRowEvents.length === 1) {
      valid = true;
    }

    else if (sRowEvents.length > 1) {
      minMaxDates = this.getMinMaxDateValidator(sRowEvents, eventRecord.internalId);
      if (startDate.getTime() > minMaxDates.minValue.getTime() && endDate.getTime() < minMaxDates.maxValue.getTime()) {
        valid = true;
      }
    }
    return valid;
  },

  /**
   * End- und Startdatum bestimmen
   * 
   * @param eventArray
   * @param internalId
   * @returns {minMaxDates}
   */
  getMinMaxDateValidator : function getMinMaxDateValidator(eventArray, internalId) {

    var c;
    var minMaxDates = {
      minValue : null,
      maxValue : null
    };

    for (c = 0; c < eventArray.length; c++) {

      if (eventArray[0].event.internalId === internalId) {
        minMaxDates.maxValue = eventArray[1].event.get('StartDate');
        minMaxDates.minValue = new Date(1970, 1, 1);
        return minMaxDates;
      } else if (eventArray[eventArray.length - 1].event.internalId === internalId) {
        minMaxDates.minValue = eventArray[eventArray.length - 2].event.get('EndDate');
        minMaxDates.maxValue = new Date(2050, 1, 1);
        return minMaxDates;
      } else if (eventArray[c].event.internalId === internalId) {
        minMaxDates.minValue = eventArray[c - 1].event.get('EndDate');
        minMaxDates.maxValue = eventArray[c + 1].event.get('StartDate');
        return minMaxDates;
      }
    }

  },

  /**
   * Fuegt ein Milestone dem Eventstore
   * 
   * @param thatId
   * @param mStone
   * @param msDate
   */
  addMilestoneFn : function addMilestoneFn(ownerId, recordId, mStone, msDate) {
    // var parentNodeId = thatId.split('-');
    // var ownerId = parentNodeId[0] + '-' + parentNodeId[1];
    // var recordId = parentNodeId[2] + '-' + parentNodeId[3] + '-' + parentNodeId[4];

    var evStore = Ext.getCmp(ownerId).getEventStore();

    var choosedRecord = evStore.data.getByKey(recordId);
    var resourceId = choosedRecord.get('ResourceId');
    var startDate = new Date(choosedRecord.get('StartDate'));

    if (msDate === "" || msDate < startDate) {
      msDate = startDate;
    }

    evStore.add({
      ResourceId : resourceId,
      Name : '',
      StartDate : Ext.Date.format(msDate, 'Y-m-d'),
      EndDate : Ext.Date.format(msDate, 'Y-m-d'),
      Resizable : false,
      Style : mStone,
      Type : 'Milestone'
    });

    Ext.getCmp('createMilestoneDialogId').close();
  },

  getCreateValidatorFn : function getCreateValidatorFn(newEvent, startDate, endDate) {

    var thisRowEvents = [];
    var valid = false;
    var isEndDateValid = null;
    var isStartDateValid = null;
    var eStore = newEvent.getEventStore();

    // Alle Events (ausser Milestones) der Zeile in ein Array packen
    eStore.each(function(record, id) {
      if (record.get('ResourceId') === newEvent.get('Id') && record.get('Type') !== 'Milestone') {
        thisRowEvents.push({
          event : record
        });
      }
    });

    for ( var a = 0; a < thisRowEvents.length; a++) {
      isStartDateValid = Ext.Date.between(startDate, thisRowEvents[a].event.get('StartDate'), thisRowEvents[a].event
          .get('EndDate'));
      isEndDateValid = Ext.Date.between(endDate, thisRowEvents[a].event.get('StartDate'), thisRowEvents[a].event
          .get('EndDate'));
      if (isStartDateValid === true || isEndDateValid === true) {
        break;
      }
    }

    if (isStartDateValid === false && isEndDateValid === false || thisRowEvents.length === 0) {
      valid = true;
    }

    return valid;
  }

};

// init Object as singleton
extVia.campaigns.scheduler.control = new extVia.campaigns.scheduler.control();

/*
 * 
 * $Revision: 1.38 $ $Modtime: 10.10.12 12:39 $ $Date: 2013/05/07 10:23:33 $ $Author: student2 $ $viaMEDICI Release: 3.9 $
 * 
 */