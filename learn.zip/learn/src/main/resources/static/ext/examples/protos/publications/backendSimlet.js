Ext.namespace('extVia.protos.backendSimlet');
/**
 * @class extVia.backendSimlet
 * simulated backend delivering dummy-data
 * 
 * @author    Simon Lederer, Viamedici Software GmbH
 * @version   $Date: 2014/02/27 17:01:15 $
 *            $Revision: 1.1 $
 */

extVia.backendSimlet = function(config){
  Ext.apply(this,config,{    
    id          : "extVia.backendSimlet",
    name        : "extVia.backendSimlet"
  });
};
    
extVia.backendSimlet.prototype = {

	getEpobDummyData : function ( parameterArray) {
		
//////////// START  simulated errrors ///////////////
		//throw "extVia.backendSimlet server error [result was FUCK]";
		//var strynger; var stryLen = strynger.length; // null Pointer
//////////// END try simulated exeptions ///////////////	

 		return extVia.stores.getEpobDummyData();	
    }

};


extVia.backendSimlet = new extVia.backendSimlet();



/*
 * 
 * $Revision: 1.1 $
 * $Modtime: 17.05.13 9:56 $ 
 * $Date: 2014/02/27 17:01:15 $
 * $Author: slederer $
 * $viaMEDICI Release: 3.9 $
 * 
 */ 