 // >>> PROD V3.8 Start (8344) <<<
/**
 * Extension for TwinCombo [ -> Combobox -> TriggerField] to display the drop list as tree
 * 
 *  v3.7 -> Start point : TreeCombo - @author Animal [Ext - Community Support Team]
 *  v3.8 -> Update to ExtJS 4.0.7 - Picker
 *  v3.8 (Patch 1) & v3.9 - hybrid with TreePicker
 * 
 * @class Ext.ux.TwinTreeCombo
 * @extends Ext.ux.TwinCombo
 */

  Ext.define('Ext.ux.TwinTreeCombo', {    
  extend:'Ext.form.field.Picker',  
  requires : ["Ext.tree.Panel"],
  alias: ['widget.treeCombo', 'treeCombo'],  
  editable: false,
  
  /**
   * init combobox list with a tree
   */
  initComponent: function() {
    this.addEvents(            
            'select',
            
            'beforeselect',
            
            'beforeexpand'
        );
    this.callParent(arguments);
  },

  /**
   * the tree that will represent combobox drop-down list body
   * 
   * @return {Ext.tree.TreePanel}
   */
  createPicker: function(){
      var me = this;  	 
      if (!Ext.isDefined(this.list) || this.list == null) {          
        me.picker = Ext.create('Ext.tree.Panel', {
            store: me.store,
            // >>> PROD V3.8 Start (8855) <<<
            autoScroll: true,
            maxHeight: 400,
            // >>> PROD V3.8 End (8855) <<<
            floating: true,
            hidden: true,
            displayField: me.displayField,
            columns: me.columns,
            maxHeight: me.maxTreeHeight,
            shadow: false,
            manageHeight: false,
            listeners: {
                select: Ext.bind(me.selectItem, me),
                beforeselect: Ext.bind(me.onBeforeTreeNodeSelect, me)
            },
            viewConfig: {
                listeners: {
                    render: function(view) {
                        view.getEl().on('keypress', me.onPickerKeypress, me);
                    }
                }
            }
        });
        var view = me.picker.getView();

        view.on('render', me.setPickerViewStyles, me);

        if (Ext.isIE9 && Ext.isStrict) {
            // In IE9 strict mode, the tree view grows by the height of the horizontal scroll bar when the items are highlighted or unhighlighted.
            // Also when items are collapsed or expanded the height of the view is off. Forcing a repaint fixes the problem.
            view.on('highlightitem', me.repaintPickerView, me);
            view.on('unhighlightitem', me.repaintPickerView, me);
            view.on('afteritemexpand', me.repaintPickerView, me);
            view.on('afteritemcollapse', me.repaintPickerView, me);
        }
      }else{
        me.picker = this.list;
        me.picker.on('select', me.selectItem, me);
        me.picker.on('beforeitemclick', me.onBeforeTreeNodeSelect, this);
        me.picker.getSelectionModel().on('beforeselect', me.onBeforeTreeNodeSelect, this);   
      }       
     return me.picker;
  },
  
  /**
   * Sets min/max height styles on the tree picker's view element after it is rendered.
   * @param {Ext.tree.View} view
   * @private
   */
  setPickerViewStyles: function(view) {
      view.getEl().setStyle({
          'min-height': this.minPickerHeight + 'px',
          'max-height': this.maxPickerHeight + 'px'
      });
  },

  /**
   * repaints the tree view
   */
  repaintPickerView: function() {
      var _style = this.picker.getView().getEl().dom.style;

      // can't use Element.repaint because it contains a setTimeout, which results in a flicker effect
      style.display = _style.display;
  }, 
  

  /**
   * Handles a keypress event on the picker element
   * @private
   * @param {Ext.EventObject} e
   * @param {HTMLElement} el
   */
  onPickerKeypress: function(e, el) {
      var key = e.getKey();

      if(key === e.ENTER || (key === e.TAB && this.selectOnTab)) {
          this.selectItem(this.picker.getSelectionModel().getSelection()[0]);
      }
  },

  /**
   * Changes the selection to a given record and closes the picker
   * @private
   * @param {Ext.selection.TreeModel} treeModel
   * @param {Ext.data.Model}          sel
   * @param {int}                     index
   */
  selectItem: function(treeModel, record, index, opts) {
      var me = this;
      me.setValue(record.get('id'));
      // >>> PROD V3.8 Start (8619) <<<
      me.setRawValue(record.get('text'));
      // >>> PROD V3.8 End (8619) <<<
      me.picker.ownerCt.hide();
      //me.inputEl.focus();
      me.picker.fireEvent('itemclick', me.picker, record);
  },

  /**
   * Sets the specified value into the field
   * @param {Mixed}                  value
   * @return {Ext.ux.TwinTreeCombo}  this
   */
  setValue: function(v) {
      this.startValue = this.value = v;
      if (this.picker) {
          var n = this.picker.getStore().getNodeById(v);
          if (n) {
              this.setRawValue(n.data.text);
          }else{
          	 this.setRawValue(v);
             //this.triggerBlur();
          }
      }
  },

  /**
   * Returns the current data value of the field (the idProperty of the record)
   * @return {Number}
   */
  getValue: function() {
      return this.value;
  },
  
  /**
   * before selection prove if disabled items, to make them unselectable
   * 
   * @param {Ext.select.RowModel} rowModel
   * @param {Ext.data.Model}      model
   * @param {int}                 idx
   * @param {Object}              opts
   * @return {}
   */
  onBeforeTreeNodeSelect: function(rowModel, model,  idx, opts){
    var doSelect = (model.data.disabled === true) ? false : true;      
    return Ext.isDefined(model.data.disabled) ?  doSelect : true;
  },
  // >>> PROD V3.8 End (8344) <<<
 
  /**
   * override -  aling and customize picker body
   */
  alignPicker : function() {
  var me = this, picker, isAbove, aboveSfx = '-above';
    if (this.isExpanded) {
      picker = me.getPicker();
      if (me.matchFieldWidth) {
        picker.setWidth(me.bodyEl.getWidth());
      }
      if (picker.isFloating()) {
        picker.alignTo(me.inputEl, "", me.pickerOffset);
        isAbove = picker.el.getY() < me.inputEl.getY();
        me.bodyEl[isAbove ? 'addCls' : 'removeCls'](me.openCls + aboveSfx);
        picker.el[isAbove ? 'addCls' : 'removeCls'](picker.baseCls + aboveSfx);
      }
    }
  }
});

  /*
 $Revision: 1.17 $
 $Modtime: 10.08.23 14:01 $
 $Date: 2014/06/10 14:59:54 $
 $Author: vbucur $
 $viaMEDICI Release: 3.7 $
 */ 