Ext.define('extUser.form.field.BoxSelect', {
  extend: 'Ext.ux.form.field.BoxSelect',
  
  constructor : function(config){
    
    var me = this,
        outerAutocomleteTask = null, 
        innerAutocomleteTask = null,
        onKeyUpFn = null,
        pickerStore = null,
        valueCache = {},
        actualChars = '',
        actualValue = '';

    var isControllingKey = function isAllowedKey(event){
      var isAllowed = true;
      var key = event.getKey();
      if(event.shiftKey || event.altKey || event.ctrlKey){
        isAllowed = false;
        Ext.global.console.info('!isAllowed');
      }
      return isAllowed;
    };
    
    var isAlphaNumericKey = function isAlphaNumericKey(event){
      var isAlphaNumeric = false;
      var key = event.getKey();
      if((key >= 48 && key <= 57) || (key >= 65 && key <= 90 )){
        isAlphaNumeric = true;
      }
      return isAlphaNumeric;
    };
    
    var isDelKey = function isDelKey(event){
      var isDel = false;
      var key = event.getKey();
      if(key === event.BACKSPACE || key === event.DELETE){
        isDel = true;
      }
      return isDel;
    };
    
    var isNavigationKey = function isNavigationKey(event){
      var isKey = false;
      var key = event.getKey();
      if(key === event.DOWN || key === event.UP || key === event.LEFT || key === event.RIGHT){
       isKey = true; 
      }
      return isKey;
    };

    var clearBox = function(t){
      me.collapse();
      t.value = '';
      actualValue = '';
    };
    
    var innerAutocomlete = function innerAutocomlete(e, t){
      actualValue = t.value;
      var end = t.value.length;
      var start = actualChars.length;
      t.setSelectionRange(start, end);
      outerAutocomleteTask = innerAutocomleteTask = null;
    };
    
    var outerAutocomlete = function outerAutocomlete(e, t){
      onKeyUpFn.call(me, e, t);
      var key = e.getKey();
      if(key !== e.ENTER){
	      innerAutocomleteTask = window.setTimeout(function(){
	        innerAutocomlete(e, t);
	      }, 500);
      }else{
        clearBox(t);
      }
    };
    
    var setCursorOnKeyUp = function setCursorOnKeyUp(e, t){
      var key = e.getKey();
      if(!isNavigationKey(e)){
	      actualChars = t.value;
	      
	      if(outerAutocomleteTask !== null){
	        window.clearTimeout(outerAutocomleteTask);
	      }
	      if(innerAutocomleteTask != null){
	        window.clearTimeout(innerAutocomleteTask);
	      }
	
	      outerAutocomleteTask = window.setTimeout(function(){
	        outerAutocomlete(e, t);
	      }, 20);
      }

    };

    this.callParent(arguments);
        
    onKeyUpFn = this.onKeyUp;
    this.onKeyUp = setCursorOnKeyUp;
  }

});