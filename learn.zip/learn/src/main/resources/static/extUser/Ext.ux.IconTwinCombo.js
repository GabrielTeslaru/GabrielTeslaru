// Create user extensions namespace (Ext.ux)
Ext.namespace('Ext.ux');
 
/**
  * Ext.ux.IconTwinCombo Extension Class
  *
  * @author  Mathias Kuehlmann
  * @version 1.0
  *
  * @class Ext.ux.IconTwinCombo
  * @extends Ext.ux.IconCombo
  * @constructor
  * @param {Object} config Configuration options
  */
Ext.ux.IconTwinCombo = function(config) {
 
    // call parent constructor
    Ext.ux.IconTwinCombo.superclass.constructor.call(this, config);
 
    this.tpl = config.tpl ||
 '<tpl for=".">'
+ '<div class="x-combo-list-item x-icon-combo-item {'
+ this.iconClsField
+ '}">{'
+ this.displayField
+ '}</div>'
+ '</tpl>'
    ;
 
    this.on({
        render:{scope:this, fn:function() {
            var wrap = this.el.up('div.x-form-field-wrap');
            this.wrap.applyStyles({position:'relative'});
            this.el.addCls('x-icon-combo-input');
            this.flag = Ext.DomHelper.append(wrap, {
                tag: 'div', style:'position:absolute'
            });
        }}
    });
}; // end of Ext.ux.IconTwinCombo constructor
 //Ext.reg('IconTwinCombo', Ext.ux.IconTwinCombo);  
// extend
Ext.extend(Ext.ux.IconTwinCombo, Ext.ux.IconCombo, {
 
   
        
    initComponent : function(){
        Ext.form.TwinTriggerField.superclass.initComponent.call(this);


                if(this.transform){
            this.allowDomMove = false;
            var s = Ext.getDom(this.transform);
            if(!this.hiddenName){
                this.hiddenName = s.name;
            }
            if(!this.store){
                this.mode = 'local';
                var d = [], opts = s.options;
                for(var i = 0, len = opts.length;i < len; i++){
                    var o = opts[i];
                    var value = (Ext.isIE ? o.getAttributeNode('value').specified : o.hasAttribute('value')) ? o.value : o.text;
                    if(o.selected) {
                        this.value = value;
                    }
                    d.push([value, o.text]);
                }
                this.store = new Ext.data.SimpleStore({
                    'id': 0,
                    fields: ['value', 'text'],
                    data : d
                });
                this.valueField = 'value';
                this.displayField = 'text';
            }
            s.name = Ext.id(); // wipe out the name in case somewhere else they have a reference
            if(!this.lazyRender){
                this.target = true;
                this.el = Ext.DomHelper.insertBefore(s, this.autoCreate || this.defaultAutoCreate);
                Ext.removeNode(s); // remove it
                this.render(this.el.parentNode);
            }else{
                Ext.removeNode(s); // remove it
            }
        }
        //auto-configure store from local array data
        else if(Ext.isArray(this.store)){
      if (Ext.isArray(this.store[0])){
        this.store = new Ext.data.SimpleStore({
            fields: ['value','text'],
            data: this.store
        });
            this.valueField = 'value';
      }else{
        this.store = new Ext.data.SimpleStore({
            fields: ['text'],
            data: this.store,
            expandData: true
        });
            this.valueField = 'text';
      }
      this.displayField = 'text';
      this.mode = 'local';
    }

        this.selectedIndex = -1;
        if(this.mode === 'local'){
            if(this.initialConfig.queryDelay === undefined){
                this.queryDelay = 10;
            }
            if(this.initialConfig.minChars === undefined){
                this.minChars = 0;
            }
        };

        this.triggerConfig = {
            tag:'span', cls:'x-form-twin-triggers', cn:[
            {tag: "img", src: Ext.BLANK_IMAGE_URL, cls: "x-form-narrow-trigger " + "x-form-twin-trigger"},
            {tag: "img", src: Ext.BLANK_IMAGE_URL, cls: "x-form-narrow-trigger " + "x-form-twin-trigger"}
        ]};
    },
    
    initTrigger : function(){
        var ts = this.trigger.select('.x-form-narrow-trigger', true);
        this.wrap.setStyle('overflow', 'hidden');
        var triggerField = this;
        ts.each(function(t, all, index){
            t.hide = function(){
                var w = triggerField.wrap.getWidth();
                this.dom.style.display = 'none';
                triggerField.el.setWidth(w-triggerField.trigger.getWidth());
            };
            t.show = function(){
                var w = triggerField.wrap.getWidth();
                this.dom.style.display = '';
                triggerField.el.setWidth(w-triggerField.trigger.getWidth());
            };
            var triggerIndex = 'Trigger'+(index+1);

            if(this['hide'+triggerIndex]){
                t.dom.style.display = 'none';
            }
            t.on("click", this['on'+triggerIndex+'Click'], this, {preventDefault:true});
            t.addClsOnOver('x-form-trigger-over');
            t.addClsOnClick('x-form-trigger-click');
        }, this);
        //this.triggers = ts.elements;
        
        
        
        
        
        
    },
    
    getTrigger : function(index){
        return this.triggers[index];
    },
//Event Handling     
    onTrigger1Click : function(){
      window.alert('onTrigger1Click ');
                    if(this.disabled){
            return;
        }
        if(this.isExpanded()){
            this.collapse();
            this.el.focus();
        }else {
            this.onFocus({});
            if(this.triggerAction === 'all') {
                this.doQuery(this.allQuery, true);
            } else {
                this.doQuery(this.getRawValue());
            }
            this.el.focus();
        }
      
      
    },
    onTrigger2Click : function(){
      window.alert('onTrigger2Click ');
      

        
    }
    
    
    
    
    
    
    
    
    
    
 
}); // end of extend
 
// end of file




  /*
 $Revision: 1.7 $
 $Modtime: 08.09.23 14:01 $
 $Date: 2013/12/09 15:47:16 $
 $Author: hstaeck $
 $viaMEDICI Release: 3.7 $
 */ 