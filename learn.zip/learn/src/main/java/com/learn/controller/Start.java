package com.learn.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Start {

    @RequestMapping("/index" )
    public String Message(){
        return "index";
    }
}
